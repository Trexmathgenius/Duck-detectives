'use strict';
/* ===== THE MYSTERIOUS STRANGER AND THE TALE OF GORDAMOM ===== */
let stranger=null;
function strangerActive(){ return !g.story.ghostHeard&&(g.day>3||(g.day===3&&g.clock>=8)); }
function strangerObj(){
  if(stranger) return stranger;
  const t=getTown(2,0);
  stranger={special:'stranger',name:'Mysterious Duck',pal:{body:'#5b5470',wing:'#3f3a52',head:'#5b5470',bill:'#c9a24a'},acc:{head:'hood',neck:null},persona:0,owl:true,still:true,idx:999,
    sx:(t.x0+2.5)*TS, tx:(t.cx+3.5)*TS, y:(t.cy+1.95)*TS, x:(t.x0+2.5)*TS, hx:0, hy:0, dir:'right', moving:false, t:0, phase:0, talking:false,
    deco:(c,n,time)=>{
      c.fillStyle='rgba(30,24,48,0.92)'; c.beginPath(); c.moveTo(n.x-8,n.y-17); c.lineTo(n.x+8,n.y-17); c.lineTo(n.x+13,n.y-1); c.lineTo(n.x-13,n.y-1); c.closePath(); c.fill();
      c.fillStyle='rgba(120,90,200,0.5)'; c.fillRect(n.x-10,n.y-3,20,2);
      const gl=0.7+0.3*Math.sin(time*6); circ(c,n.x+(n.dir==='left'?-12:12),n.y-9,3,'rgba(255,200,100,'+gl.toFixed(2)+')');
    }};
  stranger.y=(t.cy+1.95)*TS; stranger.hx=stranger.tx; stranger.hy=stranger.y;
  return stranger;
}
function strangerNpcs(list){
  if(!strangerActive()) return;
  const n=strangerObj(), t=getTown(2,0);
  if(Math.abs(g.px/TS-t.cx)<40&&Math.abs(g.py/TS-t.cy)<30) list.push(n);
}
function strangerMark(n){
  if(n.talking||!strangerActive()) return null;
  return {ch:'?',col:'#b388ff'};
}
function strangerCanTell(){ return strangerActive()&&((g.day===3&&g.clock>=19)||g.day>3); }
function strangerTalk(n){
  n.dir=OPP[g.dir]; n.moving=false; n.talking=true;
  const done=()=>{ n.talking=false; };
  if(!g.story.metStranger){
    g.story.metStranger=1;
    if(strangerCanTell()) { g.story.metStranger=1; }
    else { say(n.name,['...Ah. A small traveler. You walk like someone who has not yet been told the story of this forest.','I have come a long way from the north. Three days of road, and every night a different campfire.','Find me at the fountain after dark. I will tell you a tale. The kind you do not forget.'],done); return; }
  }
  if(!strangerCanTell()){ say(n.name,['Not yet. A story told in daylight is only half a story. Come back after dark, by the fountain.'],done); return; }
  choose(n.name,'The night is quiet and the lamps are low. Shall I tell it now?',['Tell me the story','Not yet'],k=>{
    if(k===0) startGhostStory(n); else done();
  },1);
}

function storyUpdate(dt){
  /* the stranger walks in from the west gate during the morning of day 3 */
  if(strangerActive()){
    const n=strangerObj();
    const p=g.day>3?1:Math.max(0,Math.min(1,(g.clock-8)/1.2));
    if(!n.talking){
      n.x=n.sx+(n.tx-n.sx)*p;
      n.moving=p<1; if(n.moving){ n.dir='right'; n.phase+=dt*9; } else if(n.dir==='right') n.dir='down';
    }
  }
  const tx=Math.floor(g.px/TS), ty=Math.floor((g.py-2)/TS);
  if(g.scene!=='world'||g.mode!=='play') return;
  /* arrival at the kingdom */
  if(!g.story.kfound&&inK(tx,ty)){
    g.story.kfound=1;
    say('',['The trees fall away. Beyond the glittering moat stands a great walled city, and in its heart, a castle with banners of gold and blue.','The Duck Kingdom of Mallardia. It is real.','This is a place to explore slowly. There is more here than the road shows.']);
    return;
  }
  /* day 3 morning: the stranger arrives */
  if(g.day===3&&g.clock>=8&&g.clock<12&&!g.story.strangerToast){
    const tw=townAtTile(tx,ty);
    if(tw&&tw.key===PUD){ g.story.strangerToast=1; toast('A hooded stranger has arrived in the square...',4200); }
  }
  /* dusk: he calls the town together */
  if(strangerCanTell()&&!g.story.callAsked){
    const t=getTown(2,0), n=strangerObj();
    if(Math.abs(g.px-n.x)<TS*9&&Math.abs(g.py-n.y)<TS*7&&townAtTile(tx,ty)===t){
      g.story.callAsked=1;
      say(n.name,['Come closer, little one. The fire is low and the night is long.'],()=>strangerTalk(n));
    }
  }
}
function storyObjective(){
  if(!g.flags.town) return null;
  if(!g.story.ghostHeard){
    if(g.day>=3&&strangerActive()){
      if(strangerCanTell()) return 'A hooded stranger waits by the fountain in Puddlewick. Face him and press <b>Z</b> to hear his tale.';
      return 'A hooded stranger has arrived in Puddlewick. He will tell a story <b>after dark</b>, by the fountain.';
    }
    if(g.day<3&&g.towns.has(PUD)&&!g.story.calSeen) return 'Read the <b>village calendar</b> on the notice board in Puddlewick. Something is planned for day 3.';
    return null;
  }
  if(!g.story.kfound) return 'Follow the <b>North Road</b> from Puddlewick to the Duck Kingdom of Mallardia (about 1000 waddles north).';
  if(!g.story.castleSeen) return 'Find the castle in the heart of the city of Kingsbill. Ask the guards why the gate is closed.';
  return null;
}

/* ===== CUTSCENE ENGINE =====
   Beats alternate between the storyteller by the fire (typed dialogue) and animated pictures of the tale. */
const cut={beats:[],i:0,t:0,typed:0,state:'in',fade:0,W:0,H:0,ctx:null,skipT:0,sx:1,ox:0,oy:0,onEnd:null,stars:[]};
const LW=320, LH=180;
const TALE=[
 {k:'teller',pages:['Sit, little one. Closer to the fire. The night is long, and this tale is longer.','It begins a hundred years ago, in the Duck Kingdom of Mallardia, three days\' journey north of here. A kingdom of green hills, golden banners, and a castle that glittered like a crown.']},
 {k:'anim',scene:'kingdom',dur:9,cap:'Mallardia, a century ago'},
 {k:'teller',pages:['But even a bright kingdom casts shadows. In those days there was a law: the Red Edict. Any duck born with red feathers was said to bring bad luck.','So they were cast out. Families, children, whole villages of them. Sent north into the cold hills with nothing but what they could carry.']},
 {k:'anim',scene:'edict',dur:10,cap:'The Red Edict'},
 {k:'teller',pages:['Among them was a young drake named Gordamom. Clever. Proud. And very, very angry.','He gathered the outcasts. Hundreds of them, then thousands, a hungry army stitched together by one idea: that the kingdom owed them a place.']},
 {k:'anim',scene:'gather',dur:10,cap:'Gordamom raises an army'},
 {k:'teller',pages:['And one cold night, he marched them south. They carried torches and ladders and a tower built from stolen barns.','They besieged the kingdom for seven days and seven nights.']},
 {k:'anim',scene:'siege',dur:10,cap:'The siege of Mallardia'},
 {k:'teller',pages:['But the king of Mallardia was no ordinary duck. King Eider was a warlock, the finest the north had ever seen.','On the seventh night, when the walls began to crack, he stood upon the battlements, raised his staff, and spoke a single word.']},
 {k:'anim',scene:'king',dur:9,cap:'King Eider, the warlock'},
 {k:'teller',pages:['There was a flash, and a sound like a thousand reeds snapping.','And where Gordamom had stood... there was a tree.']},
 {k:'anim',scene:'tree',dur:9,cap:'...a tree'},
 {k:'teller',pages:['The army fled. And the king, fearing that the tree might one day remember its anger, burned it. Burned it to the ground, to ash and ember, so that nothing would remain.']},
 {k:'anim',scene:'burn',dur:8,cap:'Burned to the ground'},
 {k:'teller',pages:['That is the story they tell. But I am an old duck, and I have walked these forests for many years.','And on certain nights, deep in the woods... a tree is watching. A tree that remembers.','It is said that Gordamom still lurks in the forest.']},
 {k:'anim',scene:'lurk',dur:10,cap:'Still lurking...',last:true},
 {k:'teller',pages:['...Sleep well, little one.','If you ever travel north to Mallardia, ask the guards why the castle gate is closed. I think the king remembers, too.'],final:true}
];
function startGhostStory(n){
  startCutscene(TALE,ghostEnd,{hint:'Press X again to skip the story'});
  if(n) n.talking=false;
}
/* generic cutscene runner: beats = [{k:'teller',pages,who?,bg?} | {k:'anim',scene,dur,cap}], onEnd runs when it finishes or is skipped */
function startCutscene(beats,onEnd,opts){
  opts=opts||{};
  cut.beats=beats; cut.i=0; cut.t=0; cut.typed=0; cut.page=0; cut.state='in'; cut.fade=1; cut.skipT=0; cut.anim=0;
  cut.onEnd=onEnd||null; cut.hint=opts.hint||'Press X again to skip';
  cut.stars=[]; for(let i=0;i<70;i++) cut.stars.push([Math.random()*LW,Math.random()*95,Math.random()*6.28]);
  const cvs=document.getElementById('cutc'); cvs.hidden=false; cut.ctx=cvs.getContext('2d'); cutSize();
  g.mode='cut'; el.dialog.hidden=true;
  quack();
}
function cutSize(){
  const cvs=document.getElementById('cutc'), w=Math.max(1,stage.clientWidth), h=Math.max(1,stage.clientHeight), d=Math.min(2,window.devicePixelRatio||1);
  if(cvs.width!==Math.floor(w*d)||cvs.height!==Math.floor(h*d)){ cvs.width=Math.floor(w*d); cvs.height=Math.floor(h*d); }
  cut.W=cvs.width; cut.H=cvs.height;
  cut.sx=Math.min(cut.W/LW,cut.H/LH); cut.ox=(cut.W-LW*cut.sx)/2; cut.oy=(cut.H-LH*cut.sx)/2;
}
function cutBeat(){ return cut.beats[cut.i]; }
function cutGo(){
  cut.state='out'; cut.fade=0;
}
function cutNext(){
  const b=cutBeat();
  if(b.k==='teller'&&cut.page<b.pages.length-1){ cut.page++; cut.typed=0; return; }
  if(cut.i>=cut.beats.length-1){ cutFinish(); return; }
  cutGo();
}
function cutPress(k){
  const b=cutBeat();
  if(k==='z'){
    if(cut.state!=='show') return;
    if(b.k==='teller'){
      const full=b.pages[cut.page];
      if(cut.typed<full.length){ cut.typed=full.length; return; }
      blip(); cutNext();
    } else if(cut.t>1.5){ blip(); cutGo(); }
  } else if(k==='x'){
    if(cut.skipT>0){ cutFinish(); } else { cut.skipT=2.2; }
  }
}
function cutFinish(){
  document.getElementById('cutc').hidden=true;
  g.mode='play';
  const f=cut.onEnd; cut.onEnd=null;
  if(f) f();
}
function ghostEnd(){
  g.story.ghostHeard=1; g.story.callAsked=1;
  const need=((5.7-g.clock)+24)%24; advanceClock(need); fade(1.6);
  g.camX=g.px; g.camY=g.py-10;
  say('',['The fire has burned down to embers. Dawn is creeping over the rooftops of Puddlewick.','The stranger is gone. All that is left of him is a small trail of footprints, heading north.','North... to the Duck Kingdom of Mallardia. You find the road beyond the town, and wonder what is waiting at its end.']);
  g.flags.story=1;
}
function cutRender(dt){
  cutSize();
  const c=cut.ctx, b=cutBeat();
  cut.t+=dt; if(cut.skipT>0) cut.skipT=Math.max(0,cut.skipT-dt);
  if(cut.state==='out'){ cut.fade+=dt/0.45; if(cut.fade>=1){ cut.fade=1; if(cut.i>=cut.beats.length-1){ cutFinish(); return; } cut.i++; cut.t=0; cut.typed=0; cut.page=0; cut.state='in'; } }
  else if(cut.state==='in'){ cut.fade-=dt/0.55; if(cut.fade<=0){ cut.fade=0; cut.state='show'; } }
  const cb=cutBeat();
  if(cb.k==='teller'){ cut.typed=Math.min(cb.pages[cut.page].length,cut.typed+dt*38); }
  else if(cut.state==='show'&&cut.t>=cb.dur) cutGo();
  c.setTransform(1,0,0,1,0,0); c.fillStyle='#000'; c.fillRect(0,0,cut.W,cut.H);
  c.setTransform(cut.sx,0,0,cut.sx,cut.ox,cut.oy);
  c.save(); c.beginPath(); c.rect(0,0,LW,LH); c.clip();
  if(cb.k==='teller') drawTeller(c,cut.t,cb);
  else{ SCENES[cb.scene](c,cut.t,cut); }
  /* cinematic bars */
  const bar=cb.k==='teller'?0:14;
  if(bar){ c.fillStyle='#000'; c.fillRect(0,0,LW,bar); c.fillRect(0,LH-bar,LW,bar); }
  if(cb.k==='anim'){
    const a=Math.min(1,cut.t/1.2), txt=cb.cap.slice(0,Math.floor(Math.min(cb.cap.length,cut.t*14)));
    c.globalAlpha=a; c.fillStyle='#f6e19a'; c.font='700 9px ui-monospace,"Courier New",monospace'; c.textAlign='center'; c.textBaseline='middle';
    c.fillText(txt,LW/2,LH-7); c.globalAlpha=1;
  }
  if(cb.k==='teller') drawTextBox(c,cb);
  c.restore();
  c.setTransform(1,0,0,1,0,0);
  if(cut.fade>0){ c.fillStyle='rgba(0,0,0,'+cut.fade.toFixed(3)+')'; c.fillRect(0,0,cut.W,cut.H); }
  /* hints */
  c.setTransform(cut.sx,0,0,cut.sx,cut.ox,cut.oy);
  c.font='600 6px ui-monospace,"Courier New",monospace'; c.textAlign='right'; c.textBaseline='top'; c.fillStyle='rgba(234,242,220,0.7)';
  c.fillText(cut.skipT>0?(cut.hint||'Press X again to skip'):'Z next  -  X skip',LW-5,4);
  c.setTransform(1,0,0,1,0,0);
}
function wrapText(c,text,maxW){
  const words=text.split(' '), lines=[]; let cur='';
  for(const w of words){ const t=cur?cur+' '+w:w; if(c.measureText(t).width>maxW&&cur){ lines.push(cur); cur=w; } else cur=t; }
  if(cur) lines.push(cur); return lines;
}
function drawTextBox(c,b){
  const full=b.pages[cut.page], txt=full.slice(0,Math.floor(cut.typed));
  c.fillStyle='rgba(18,28,24,0.94)'; c.fillRect(8,LH-58,LW-16,50); c.strokeStyle='#eaf2dc'; c.lineWidth=1; c.strokeRect(8.5,LH-57.5,LW-17,49);
  c.fillStyle='#ff9d2e'; c.fillRect(14,LH-65,Math.max(70,(b.who||'Mysterious Duck').length*5+10),10); c.fillStyle='#2a1700'; c.font='700 7px ui-monospace,"Courier New",monospace'; c.textAlign='left'; c.textBaseline='middle';
  c.fillText(b.who||'Mysterious Duck',17,LH-60);
  c.font='600 8px ui-monospace,"Courier New",monospace'; c.fillStyle='#eaf2dc'; c.textBaseline='top';
  c.save(); c.font='600 8px ui-monospace,"Courier New",monospace';
  const lines=wrapText(c,full,LW-40), shown=wrapText(c,txt,LW-40);
  for(let i=0;i<Math.min(4,shown.length);i++) c.fillText(shown[i],16,LH-52+i*10);
  c.restore();
  if(cut.typed>=full.length&&cut.state==='show'&&Math.floor(cut.t*2)%2===0){ c.fillStyle='#ff9d2e'; c.fillText('Z',LW-20,LH-18); }
}

/* ---- the storyteller's fire ---- */
function drawTeller(c,t){
  { const cb0=cutBeat(); if(cb0&&cb0.bg&&typeof TELLERBG!=='undefined'&&TELLERBG[cb0.bg]){ TELLERBG[cb0.bg](c,t,cb0); return; } }
  const g1=c.createLinearGradient(0,0,0,LH); g1.addColorStop(0,'#0a1030'); g1.addColorStop(0.7,'#1a2250'); g1.addColorStop(1,'#12301f'); c.fillStyle=g1; c.fillRect(0,0,LW,LH);
  for(const s of cut.stars){ const a=0.4+0.6*Math.abs(Math.sin(t*1.5+s[2])); c.fillStyle='rgba(255,255,230,'+a.toFixed(2)+')'; c.fillRect(s[0],s[1],1,1); }
  circ(c,262,34,12,'#f4efd0'); circ(c,257,30,10,'#0a1030'); circ(c,262,34,12,'rgba(244,239,208,0.0)');
  c.fillStyle='#0e2418'; c.beginPath(); c.moveTo(0,110); for(let x=0;x<=LW;x+=20) c.lineTo(x,104+Math.sin(x*0.05)*8); c.lineTo(LW,LH); c.lineTo(0,LH); c.fill();
  for(let i=0;i<9;i++){ const x=i*38+((i*17)%13), h=40+((i*29)%24); c.fillStyle='#0a1a12'; c.beginPath(); c.moveTo(x,108); c.lineTo(x+11,108-h); c.lineTo(x+22,108); c.fill(); }
  c.fillStyle='#14341f'; c.fillRect(0,128,LW,52);
  /* fire glow */
  const fl=0.85+0.15*Math.sin(t*9)+0.05*Math.sin(t*23);
  const gr=c.createRadialGradient(160,128,2,160,128,100*fl); gr.addColorStop(0,'rgba(255,170,70,0.55)'); gr.addColorStop(1,'rgba(255,120,40,0)'); c.fillStyle=gr; c.fillRect(0,40,LW,140);
  /* teller */
  const talking=cut.typed<cutBeat().pages[cut.page].length;
  c.save(); c.translate(0,0);
  drawDuck(c,96,150,'right',talking?t*14:0,talking,stranger?stranger.pal:{body:'#5b5470',wing:'#3f3a52',head:'#5b5470',bill:'#c9a24a'},{scale:2.6,head:'hood'});
  c.fillStyle='rgba(30,24,48,0.95)'; c.beginPath(); c.moveTo(80,112); c.lineTo(110,112); c.lineTo(122,148); c.lineTo(70,148); c.closePath(); c.fill();
  c.restore();
  drawDuck(c,235,150,'left',0,false,{body:'#ffd84a',wing:'#f0b921',bill:'#ff8a1f'},{scale:2});
  /* town ducks listening */
  const sil=(x,y,s,col)=>{ ell(c,x,y-4*s,5*s,3.6*s,col); circ(c,x+3*s,y-9*s,2.8*s,col); };
  sil(190,160,2.2,'#2a1f3a'); sil(60,163,2,'#1f2a3a'); sil(278,158,2,'#2a2a1f');
  /* campfire */
  for(let i=0;i<8;i++){ const a=i*0.785; ell(c,160+Math.cos(a)*14,150+Math.sin(a)*5,5,3.5,'#5d6068'); }
  rect(c,148,145,24,4,'#4a3018'); rect(c,150,141,20,4,'#5a3d22');
  const f1=Math.sin(t*10)*2.5, f2=Math.sin(t*14+1)*2;
  c.fillStyle='#ff7a2a'; c.beginPath(); c.moveTo(147,146); c.quadraticCurveTo(150+f2,122,160,108+f1); c.quadraticCurveTo(171,124,173,146); c.fill();
  c.fillStyle='#ffd166'; c.beginPath(); c.moveTo(152,146); c.quadraticCurveTo(155,128,160,120+f2); c.quadraticCurveTo(166,130,168,146); c.fill();
  c.fillStyle='#fff3c4'; c.beginPath(); c.moveTo(156,146); c.quadraticCurveTo(158,136,160,132); c.quadraticCurveTo(163,138,164,146); c.fill();
  for(let i=0;i<6;i++){ const tt=(t*0.5+i*0.17)%1; c.fillStyle='rgba(255,200,100,'+(1-tt).toFixed(2)+')'; c.fillRect(152+i*3+Math.sin(tt*7+i)*4,120-tt*50,1,1); }
}

/* ---- tiny helpers for the animated scenes ---- */
function sky(c,top,bot,n){ n=n||24; for(let i=0;i<n;i++){ const k=i/(n-1); const a=hexMix(top,bot,k); c.fillStyle=a; c.fillRect(0,i*LH/n,LW,LH/n+1); } }
function hexMix(a,b,k){ const A=parseInt(a.slice(1),16), B=parseInt(b.slice(1),16); const r=((A>>16)&255)*(1-k)+((B>>16)&255)*k, g2=((A>>8)&255)*(1-k)+((B>>8)&255)*k, bl=(A&255)*(1-k)+(B&255)*k; return 'rgb('+(r|0)+','+(g2|0)+','+(bl|0)+')'; }
function mini(c,x,y,col,dir,s,bob,cap){
  const f=dir==='left'?-1:1;
  ell(c,x,y-1,4*s,1.2*s,'rgba(0,0,0,0.3)');
  ell(c,x,y-4*s+(bob||0),5*s,3.6*s,col); circ(c,x+3.4*s*f,y-8.5*s+(bob||0),2.6*s,col);
  rect(c,x+(f>0?5.4:-8.2)*s,y-8.8*s+(bob||0),2.8*s,1.2*s,'#ff9d2e');
  if(cap) rect(c,x+(f>0?1.4:-3.8)*s,y-12*s+(bob||0),2.6*s,1*s,cap);
}
function castle(c,x,base,s,col,roof,t,banner){
  const w=60*s;
  c.fillStyle=col; c.fillRect(x-w/2,base-40*s,w,40*s);
  for(let i=0;i<7;i++) c.fillRect(x-w/2+i*w/7,base-44*s,w/14,4*s);
  for(const dx of [-w/2-4*s,w/2-8*s]){ c.fillRect(x+dx,base-62*s,12*s,62*s); c.fillStyle=roof; c.beginPath(); c.moveTo(x+dx-2*s,base-62*s); c.lineTo(x+dx+6*s,base-80*s); c.lineTo(x+dx+14*s,base-62*s); c.fill(); c.fillStyle=col; }
  c.fillRect(x-12*s,base-78*s,24*s,60*s); c.fillStyle=roof; c.beginPath(); c.moveTo(x-15*s,base-78*s); c.lineTo(x,base-104*s); c.lineTo(x+15*s,base-78*s); c.fill();
  rect(c,x-1,base-122*s,1.5,20*s,'#e0b84a'); if(banner){ const w2=Math.sin(t*4)*2; c.fillStyle=banner; c.beginPath(); c.moveTo(x,base-120*s); c.lineTo(x+14*s+w2,base-116*s); c.lineTo(x,base-110*s); c.fill(); }
  c.fillStyle='rgba(0,0,0,0.5)'; c.fillRect(x-4*s,base-14*s,8*s,14*s);
}
function rockBase(c,y,col){ c.fillStyle=col; c.beginPath(); c.moveTo(0,y); for(let x=0;x<=LW;x+=16) c.lineTo(x,y+Math.sin(x*0.07)*6); c.lineTo(LW,LH); c.lineTo(0,LH); c.fill(); }
function flame(c,x,y,s,t){ const f=Math.sin(t*12+x)*1.5*s; c.fillStyle='#ff7a2a'; c.beginPath(); c.moveTo(x-3*s,y); c.quadraticCurveTo(x-3*s,y-6*s,x+f,y-11*s); c.quadraticCurveTo(x+4*s,y-6*s,x+3*s,y); c.fill(); c.fillStyle='#ffd166'; c.beginPath(); c.moveTo(x-1.5*s,y); c.quadraticCurveTo(x-1.5*s,y-4*s,x+f*0.5,y-7*s); c.quadraticCurveTo(x+2*s,y-4*s,x+1.5*s,y); c.fill(); }

const SCENES={
 kingdom(c,t){
  const k=Math.min(1,t/6);
  sky(c,'#5f9bdc','#f7d083',20);
  circ(c,230,130-k*52,16,'#fff3b0'); circ(c,230,130-k*52,24,'rgba(255,240,170,0.22)');
  for(let i=0;i<3;i++){ const x=((t*6+i*120)%420)-50; ell(c,x,34+i*18,26,7,'rgba(255,255,255,0.85)'); ell(c,x+14,30+i*18,16,6,'rgba(255,255,255,0.85)'); }
  c.fillStyle='#6fae5a'; c.beginPath(); c.moveTo(0,130); for(let x=0;x<=LW;x+=10) c.lineTo(x,122+Math.sin(x*0.04)*8); c.lineTo(LW,LH); c.lineTo(0,LH); c.fill();
  c.fillStyle='#8fc46e'; c.beginPath(); c.moveTo(0,150); for(let x=0;x<=LW;x+=10) c.lineTo(x,146+Math.sin(x*0.06+2)*6); c.lineTo(LW,LH); c.lineTo(0,LH); c.fill();
  castle(c,160,138,1.1,'#d8d2c0','#3a5f9c',t,'#e0b84a');
  castle(c,60,148,0.45,'#c9c3b2','#3a5f9c',t+1,'#e0b84a'); castle(c,270,148,0.5,'#c9c3b2','#3a5f9c',t+2,'#e0b84a');
  for(let i=0;i<5;i++){ const x=((t*(8+i*2)+i*70)%360)-20; mini(c,x,168-(i%2)*6,['#f4f4ee','#8d7352','#9aa4ad','#d9a066','#87b4d8'][i],'right',1.2,-Math.abs(Math.sin(t*8+i))*1); }
  for(let i=0;i<4;i++){ const bx=((t*18+i*90)%380)-30, by=40+i*7+Math.sin(t*3+i)*3; c.strokeStyle='#222'; c.lineWidth=1; c.beginPath(); c.moveTo(bx-4,by+Math.sin(t*14+i)*2); c.lineTo(bx,by); c.lineTo(bx+4,by+Math.sin(t*14+i)*2); c.stroke(); }
 },
 edict(c,t){
  sky(c,'#c98a5a','#f3c88a',20);
  c.fillStyle='#8a7a6a'; c.fillRect(0,120,LW,60);
  for(let x=0;x<LW;x+=24) for(let y=120;y<LH;y+=12){ c.fillStyle=((x/24+y/12)&1)?'#7c6d5e':'#86766a'; c.fillRect(x,y,24,12); }
  c.fillStyle='#d8d2c0'; c.fillRect(0,40,LW,82); c.fillStyle='#c9c3b2'; for(let x=0;x<LW;x+=40) c.fillRect(x,40,20,6);
  c.fillStyle='#a8793f'; c.fillRect(110,76,70,30); c.fillStyle='#f6e19a'; c.fillRect(114,80,62,22);
  c.fillStyle='#8a1a1a'; c.font='700 9px ui-monospace,"Courier New",monospace'; c.textAlign='center'; c.textBaseline='middle'; c.fillText('THE RED',145,87); c.fillText('EDICT',145,97);
  rect(c,150,108,6,18,'#6b4a2f');
  /* herald */
  mini(c,196,134,'#f4f4ee','left',2,0,'#e0b84a'); rect(c,185,118,12,10,'#f6e19a'); rect(c,186,120,10,1,'#8a1a1a');
  /* crowd with their backs turned */
  const cols=['#9aa4ad','#d9a066','#87b4d8','#f4f4ee','#8d7352','#e9b7c8'];
  for(let i=0;i<8;i++) mini(c,18+i*17+(i%2)*4,148+(i%3)*5,cols[i%6],'right',1.9,0);
  /* the red ducks leaving */
  const p=Math.min(1,t/9);
  for(let i=0;i<9;i++){
    const x=230+i*10-(i%3)*3+p*85-18, y=140+(i%3)*7; const bob=-Math.abs(Math.sin(t*5+i))*1.2;
    mini(c,x,y,i===0?'#c0392b':'#d9503f','right',i===0?2.4:1.8,bob);
    if(i%2===0) rect(c,x-6,y-12+bob,5,6,'#a8793f');
  }
  const gx=230+p*85-18; circ(c,gx+4,132,1,'#9fd2ff');
 },
 gather(c,t){
  sky(c,'#14052a','#5a1a3a',24);
  circ(c,238,48,17,'#c0392b'); circ(c,238,48,26,'rgba(192,57,43,0.18)');
  for(let i=0;i<50;i++){ const a=0.3+0.5*Math.abs(Math.sin(t+i)); c.fillStyle='rgba(255,230,230,'+a.toFixed(2)+')'; c.fillRect((i*47)%LW,(i*29)%80,1,1); }
  rockBase(c,118,'#1e1426'); rockBase(c,140,'#150e1c');
  const n=Math.min(40,6+Math.floor(t*4));
  for(let i=0;i<n;i++){ const x=16+(i*37)%300, y=150+((i*13)%24); mini(c,x,y,i%3?'#7a1f1a':'#5a1410','right',1.6+((i%3)*0.2),0); if(i%4===0) flame(c,x+6,y-14,0.7,t+i); }
  /* the rock and Gordamom */
  c.fillStyle='#2b2233'; c.beginPath(); c.moveTo(120,150); c.lineTo(132,116); c.lineTo(190,116); c.lineTo(204,150); c.fill();
  mini(c,160,116,'#e04a3a','right',3,Math.sin(t*3)*0.5);
  rect(c,172,70,2,48,'#6b4a2f'); const w=Math.sin(t*4)*3; c.fillStyle='#c0392b'; c.beginPath(); c.moveTo(174,72); c.lineTo(204+w,78); c.lineTo(174,92); c.fill(); circ(c,184,80,3,'#1a0a0a');
  for(let i=0;i<14;i++){ const x=((i*53)%LW), prog=Math.min(1,Math.max(0,(t-1-i*0.4)/1.5)); if(prog>0) flame(c,x,100+Math.sin(i)*8,1*prog,t+i); }
 },
 siege(c,t){
  sky(c,'#0b0b24','#321b3c',22);
  c.fillStyle='#2a2438'; c.fillRect(0,128,LW,52);
  /* castle wall on the right */
  c.fillStyle='#8a919e'; c.fillRect(200,70,130,70); for(let i=0;i<9;i++) c.fillRect(200+i*15,64,8,8);
  c.fillStyle='#727987'; for(let y=76;y<140;y+=10) c.fillRect(200,y,130,1);
  c.fillStyle='#46608f'; c.fillRect(250,28,34,60); c.beginPath(); c.moveTo(246,28); c.lineTo(267,4); c.lineTo(288,28); c.fill();
  rect(c,266,20,2,-14,'#e0b84a');
  rect(c,260,50,14,18,'#ffd98a');
  for(let i=0;i<7;i++) mini(c,206+i*16,64,'#87b4d8','left',1.3,Math.sin(t*5+i)*0.8,'#aab4c0');
  /* army */
  const adv=Math.min(1,t/10)*40;
  for(let i=0;i<22;i++){ const x=((i*31)%150)+adv, y=140+((i*17)%34); mini(c,x,y,i%3?'#7a1f1a':'#9a2a22','right',1.6,-Math.abs(Math.sin(t*6+i))*1); if(i%3===0) flame(c,x+6,y-12,0.6,t+i); }
  /* siege tower */
  const tx=96+adv; c.fillStyle='#6b4a2f'; c.fillRect(tx,70,30,70); c.fillStyle='#4a3018'; for(let y=80;y<140;y+=14) c.fillRect(tx,y,30,2); circ(c,tx+7,142,8,'#3b2a18'); circ(c,tx+23,142,8,'#3b2a18'); flame(c,tx+15,70,1.4,t);
  /* flaming arrows */
  for(let i=0;i<9;i++){
    const tt=((t*0.7+i*0.11)%1), x=40+i*14+tt*150, y=140-Math.sin(tt*Math.PI)*110-i*2;
    c.fillStyle='#ffcf6a'; c.fillRect(x,y,3,1); flame(c,x,y,0.5,t);
    if(tt>0.93){ const a=1-(tt-0.93)/0.07; c.fillStyle='rgba(255,230,160,'+(a*0.8).toFixed(2)+')'; c.fillRect(196,80+i*7,10,6); }
  }
  c.fillStyle='rgba(255,120,40,'+(0.05+0.03*Math.sin(t*11)).toFixed(2)+')'; c.fillRect(0,14,LW,LH-28);
 },
 king(c,t){
  const fl=(Math.sin(t*3.7)>0.97||Math.sin(t*5.3)>0.985||(t>6.5&&t<7.2))?1:0;
  sky(c,fl?'#e0d0ff':'#1a0b3a',fl?'#a98ae0':'#42246a',24);
  for(let i=0;i<5;i++){ ell(c,((t*10+i*80)%400)-40,22+i*14,40,8,'rgba(30,10,60,0.8)'); }
  c.fillStyle='#8a919e'; c.fillRect(0,128,LW,52); for(let i=0;i<11;i++) c.fillRect(i*30,120,16,10);
  c.fillStyle='#727987'; for(let y=134;y<180;y+=10) c.fillRect(0,y,LW,1);
  /* the king */
  const sc=1; c.fillStyle='#4b2a8a'; c.beginPath(); c.moveTo(140,128); c.lineTo(180,128); c.lineTo(190,80); c.lineTo(130,80); c.closePath(); c.fill();
  c.fillStyle='#6a3dbd'; c.beginPath(); c.moveTo(160,128); c.lineTo(180,128); c.lineTo(190,80); c.lineTo(160,80); c.closePath(); c.fill();
  drawDuck(c,160,128,'down',0,false,{body:'#f4f4ee',wing:'#d4d8cf',bill:'#ff9d2e'},{scale:2.7,head:'wizard'});
  /* staff and magic */
  rect(c,196,34,3,98,'#6b4a2f'); const p=0.6+0.4*Math.sin(t*5);
  circ(c,197.5,30,10+Math.min(30,t*3.5),'rgba(120,220,255,'+(0.16*p).toFixed(2)+')'); circ(c,197.5,30,6,'#9fe8ff'); circ(c,197.5,30,3,'#fff');
  for(let i=0;i<8;i++){ const a=t*2+i*0.785, r=14+Math.min(40,t*4); c.fillStyle='rgba(180,240,255,0.8)'; c.fillRect(197+Math.cos(a)*r,30+Math.sin(a)*r*0.7,2,2); }
  if(t>4){ const k=Math.min(1,(t-4)/3); c.strokeStyle='rgba(200,240,255,'+(0.8*k).toFixed(2)+')'; c.lineWidth=2; c.beginPath(); c.moveTo(197,30); let x=197,y=30; for(let i=0;i<9;i++){ x-=17+Math.sin(i*7+t*30)*5; y+=9+Math.cos(i*3+t*20)*8; c.lineTo(x,y); } c.stroke(); }
  if(fl){ c.fillStyle='rgba(255,255,255,0.35)'; c.fillRect(0,0,LW,LH); }
 },
 tree(c,t){
  const p=Math.max(0,Math.min(1,(t-1.2)/5.5));
  sky(c,'#12062a','#4a1d52',24);
  rockBase(c,128,'#1c1426');
  /* purple beam from the sky */
  const bw=10+Math.sin(t*20)*2; c.fillStyle='rgba(190,120,255,0.55)'; c.beginPath(); c.moveTo(20,0); c.lineTo(36,0); c.lineTo(168+bw,128); c.lineTo(152-bw,128); c.closePath(); c.fill();
  c.fillStyle='rgba(255,255,255,0.4)'; c.beginPath(); c.moveTo(26,0); c.lineTo(30,0); c.lineTo(164,128); c.lineTo(156,128); c.closePath(); c.fill();
  for(let i=0;i<14;i++){ const a=t*5+i; c.fillStyle='rgba(220,180,255,0.8)'; c.fillRect(160+Math.cos(a)*(14+p*30)+Math.sin(i*5)*10,128-((t*40+i*17)%100),2,2); }
  /* fleeing army */
  for(let i=0;i<10;i++){ const x=((i*37)%140)+10-Math.max(0,(t-2))*(8+i%3*3), y=146+((i*13)%20); mini(c,x,y,'#7a1f1a','left',1.4,-Math.abs(Math.sin(t*9+i))*1.2); }
  /* Gordamom turns */
  if(p<1){ c.save(); c.globalAlpha=1-p; drawDuck(c,160,130,'down',0,false,{body:'#e04a3a',wing:'#a83a2d',bill:'#ff9d2e'},{scale:3.5*(1-p*0.3)}); c.restore(); }
  const h=p*66;
  c.fillStyle='#4a3524'; c.beginPath(); c.moveTo(152,130); c.lineTo(156,130-h); c.lineTo(164,130-h); c.lineTo(168,130); c.closePath(); c.fill();
  if(p>0.25){ const k=(p-0.25)/0.75; c.strokeStyle='#4a3524'; c.lineWidth=3; for(const b of [[-1,0.5],[1,0.6],[-1,0.8],[1,0.9]]){ c.beginPath(); c.moveTo(160,130-h*b[1]); c.lineTo(160+b[0]*28*k,130-h*b[1]-18*k); c.stroke(); }
    circ(c,160,130-h-6,22*k,'#2f5d2a'); circ(c,146,130-h+4,15*k,'#2f5d2a'); circ(c,174,130-h+4,15*k,'#2f5d2a'); circ(c,160,130-h-12,14*k,'#3a7a35'); }
  if(p>0.7){ const a=Math.min(1,(p-0.7)/0.3); c.fillStyle='rgba(255,50,50,'+a.toFixed(2)+')'; c.fillRect(155,130-h*0.55,3,3); c.fillRect(162,130-h*0.55,3,3); }
 },
 burn(c,t){
  const p=Math.max(0,Math.min(1,(t-1)/6));
  sky(c,'#14040a','#6b2410',24);
  rockBase(c,130,'#1c1210');
  const sh=1-p*0.92;
  c.save(); c.translate(160,132); c.scale(1,sh);
  c.fillStyle='#2c2018'; c.fillRect(-8,-66,16,66);
  circ(c,0,-72,24,p<0.5?'#2f5d2a':'#2c2018'); circ(c,-17,-62,16,p<0.5?'#2f5d2a':'#2c2018'); circ(c,17,-62,16,p<0.5?'#2f5d2a':'#2c2018');
  c.restore();
  c.fillStyle='#3a3330'; c.beginPath(); c.ellipse(160,132,10+p*26,3+p*3,0,0,6.2832); c.fill();
  const n=Math.floor(20*(1-p*0.8));
  for(let i=0;i<n;i++){ const x=140+((i*17)%40), y=130-((i*29)%(70*sh)); flame(c,x,y,1.8-p,t+i); }
  for(let i=0;i<24;i++){ const tt=((t*0.4+i*0.043)%1); c.fillStyle='rgba(255,'+(140+tt*80|0)+',60,'+(1-tt).toFixed(2)+')'; c.fillRect(150+Math.sin(i*3+t)*30,130-tt*110,2,2); }
  for(let i=0;i<6;i++){ const tt=((t*0.2+i*0.17)%1); ell(c,160+Math.sin(i*2+t*0.5)*26,60-tt*50,10+tt*12,6+tt*4,'rgba(60,50,50,'+(0.5*(1-tt)).toFixed(2)+')'); }
  /* the king, watching, at the edge of the frame */
  c.fillStyle='rgba(20,10,30,0.95)'; c.beginPath(); c.moveTo(270,150); c.lineTo(302,150); c.lineTo(296,100); c.lineTo(276,100); c.fill(); drawDuck(c,286,150,'left',0,false,{body:'#2a2535',wing:'#1c1825',bill:'#8a6a20'},{scale:2.4,head:'wizard'});
 },
 lurk(c,t){
  sky(c,'#04060f','#10182a',24);
  circ(c,70,34,14,'#d7dff0'); circ(c,66,31,12,'#04060f');
  for(let i=0;i<40;i++){ const a=0.3+0.5*Math.abs(Math.sin(t*0.8+i)); c.fillStyle='rgba(220,230,255,'+a.toFixed(2)+')'; c.fillRect((i*53)%LW,(i*31)%90,1,1); }
  const layer=(y,col,sp,sz)=>{ c.fillStyle=col; for(let i=-1;i<12;i++){ const x=i*34-((t*sp)%34)*0+Math.sin(t*0.6+i)*1; c.beginPath(); c.moveTo(x,y); c.lineTo(x+16,y-sz-((i*13)%20)); c.lineTo(x+32,y); c.fill(); } c.fillRect(0,y,LW,LH-y); };
  layer(118,'#0a1220',0.3,40); layer(134,'#070d17',0.6,52); layer(150,'#04080f',0.9,68);
  for(let i=0;i<4;i++){ const x=((t*7+i*90)%420)-60; ell(c,x,138+i*6,70,6,'rgba(160,170,200,0.10)'); }
  /* the tree, far away between the trunks */
  const k=Math.min(1,t/4);
  c.fillStyle='#030609'; c.fillRect(150,98,8,38); c.strokeStyle='#030609'; c.lineWidth=2; for(const b of [[-14,-10],[14,-12],[-8,-24],[10,-22]]){ c.beginPath(); c.moveTo(154,112); c.lineTo(154+b[0],112+b[1]); c.stroke(); }
  if(t>3){
    const open=Math.min(1,(t-3)/1.4), blink=Math.sin(t*1.3)>-0.93?1:0.15, zoom=t>7?Math.min(2.2,1+(t-7)*0.5):1;
    const ex=154, ey=112, sp=3*zoom, sz=(1.5+2*open)*zoom;
    c.fillStyle='rgba(255,40,40,'+(0.9*blink).toFixed(2)+')'; c.fillRect(ex-sp-sz,ey,sz*1.5,sz); c.fillRect(ex+sp,ey,sz*1.5,sz);
    circ(c,ex-sp,ey+1,6*zoom,'rgba(255,40,40,'+(0.18*open).toFixed(2)+')'); circ(c,ex+sp+2,ey+1,6*zoom,'rgba(255,40,40,'+(0.18*open).toFixed(2)+')');
  }
  if(t>8.5){ c.fillStyle='rgba(0,0,0,'+Math.min(1,(t-8.5)/1.3).toFixed(2)+')'; c.fillRect(0,0,LW,LH); }
 }
};
