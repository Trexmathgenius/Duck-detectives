'use strict';
/* ===== STORY SCENES (SX): rooms you walk through, with stealth, puzzles, escorts and dreams =====
   A scene is a small tile map with objects, NPCs, patrolling guards, triggers and optionally a companion.
   Chapters define scenes with sxDef(id,{...}) and enter them with sxEnter(id). Everything persists through S.fl
   (saved in g.story.s2.sx[id].fl), so a half-solved puzzle stays half-solved. */

const SX={defs:{},S:null,dark:null};
function sxDef(id,d){ d.id=id; SX.defs[id]=d; return d; }

/* ---------- hosted scenes ----------
   A scene is either a ROOM (it replaces the screen; S.host is null) or HOSTED in the open world
   (S.host={x0,y0,w,h,flip}: the scene's tiles are laid onto the world map at tile x0,y0, optionally mirrored).
   Everything inside a scene (tiles, guards, npcs, triggers, scripts) stays in the scene's own LOCAL pixel/tile
   coordinates. Only the player's g.px/g.py are world coordinates when hosted, so scene code that needs the
   player's place uses these helpers. For rooms they are the identity. (s12host.js does the world side.) */
function sxMir(d){ return d==='left'?'right':d==='right'?'left':d; }
function sxLX(S){ const h=S&&S.host; if(!h) return g.px; const wx=g.px-h.x0*TS; return h.flip?h.w*TS-wx:wx; }
function sxLY(S){ const h=S&&S.host; return h?g.py-h.y0*TS:g.py; }
function sxLDir(S){ const h=S&&S.host; return (h&&h.flip)?sxMir(g.dir):g.dir; }
function sxToWX(S,lx){ const h=S&&S.host; if(!h) return lx; return h.x0*TS+(h.flip?h.w*TS-lx:lx); }
function sxToWY(S,ly){ const h=S&&S.host; return h?h.y0*TS+ly:ly; }
function sxPlace(S,lx,ly,dir){ g.px=sxToWX(S,lx); g.py=sxToWY(S,ly); if(dir) g.dir=(S&&S.host&&S.host.flip)?sxMir(dir):dir; }
/* the point d pixels in front of the player, in scene coordinates */
function sxFacing(S,d){ const v=DIRV[sxLDir(S)], fx=sxLX(S)+v.x*d, fy=sxLY(S)-6+v.y*d; return {fx:fx,fy:fy,tx:Math.floor(fx/TS),ty:Math.floor(fy/TS)}; }
function sxIn(){ return !!SX.S&&(g.scene==='sx'||!!SX.S.host); }

const SXT={
  stone:{f:['#6a6e78','#62666f'],w:['#3a3d46','#26282f'],c:'#7a2a3a'},
  castle:{f:['#c9c3b2','#bdb7a5'],w:['#6a7aa5','#46567f'],c:'#2a3a7a'},
  crypt:{f:['#4a4658','#443f52'],w:['#241f30','#171320'],c:'#3a2a5a'},
  wood:{f:['#2c4a2e','#274229'],w:['#16281a','#0e1a11'],c:'#3a5a3a'},
  hearth:{f:['#6a3a30','#62342b'],w:['#4a1c1e','#2e1214'],c:'#c0392b'},
  archive:{f:['#8a6a45','#7e613f'],w:['#3b2b1e','#271c13'],c:'#7a2a3a'},
  dream:{f:['#3a2f58','#352b52'],w:['#1b1530','#110d22'],c:'#5a3a8a'},
  tower:{f:['#4a5a85','#43527c'],w:['#1f2a4a','#141c34'],c:'#2a3a7a'},
  ash:{f:['#3a3836','#34322f'],w:['#1a1918','#100f0e'],c:'#4a3a30'},
  grove:{f:['#2a3a2a','#263624'],w:['#101a12','#0a110b'],c:'#4a3a5a'}
};

/* build a walled room quickly: ops are [x,y,ch] or [x,y,w,h,ch] */
function sxGrid(w,h,ops){
  const m=[]; for(let y=0;y<h;y++){ const r=[]; for(let x=0;x<w;x++) r.push((x===0||y===0||x===w-1||y===h-1)?'#':'.'); m.push(r); }
  for(const o of ops){ if(o.length===3) m[o[1]][o[0]]=o[2]; else { for(let j=o[1];j<o[1]+o[3];j++) for(let i=o[0];i<o[0]+o[2];i++) m[j][i]=o[4]; } }
  return m.map(r=>r.join(''));
}
/* ---------- state ---------- */
function sxStore(id){ const q=s2(); return q.sx[id]||(q.sx[id]={fl:{},n:0}); }
function sxMake(def,host){
  const st=sxStore(def.id);
  const S={host:host||null,id:def.id,def:def,fl:st.fl,t:0,tiles:{},det:0,caught:0,cast:'',lumen:0,veil:0,speed:0,seekT:0,timer:null,check:null,
    npcs:[],guards:[],follow:null,trail:[],objs:{},frozen:false,doors:{},msgT:0,lastTrig:''};
  (def.doors||[]).forEach(d=>{ S.doors[d.tx+','+d.ty]=d; });
  for(const n of (def.npcs||[])) S.npcs.push(Object.assign({},n,{x:(n.tx+0.5)*TS,y:(n.ty+0.95)*TS,dir:n.dir||'down',phase:0,moving:false,t:Math.random()*2,acc:{head:n.head||null,neck:n.neck||null},pal:typeof n.pal==='number'?PALS[n.pal]:(n.pal||PALS[3])}));
  S.guards=(def.guards||[]).map(gd=>sxGuard(gd));
  if(def.follow) S.follow={name:def.follow.name,pal:def.follow.pal,head:def.follow.head||null,scale:def.follow.scale,x:0,y:0,dir:'down',phase:0,moving:false};
  return S;
}
function sxGuard(gd){
  const p=gd.path?gd.path[0]:[gd.tx,gd.ty];
  return Object.assign({speed:38,range:4.5,fov:70,wait:0.7,dir:'down',pal:{body:'#9aa4ad',wing:'#6f7a84',bill:'#e6c441'},head:'helm',loop:true},gd,
    {x:(p[0]+0.5)*TS,y:(p[1]+0.95)*TS,wp:1,fwd:1,face:gd.face!==undefined?gd.face:Math.PI/2,pause:0,alert:0,phase:0,moving:false,sweepT:0});
}
function sxEnter(id,tx,ty,dir){
  const def=SX.defs[id]; if(!def){ console.warn('no scene',id); return; }
  if(typeof sxHostEnter==='function'&&sxHostEnter(id,tx,ty,dir)) return;   /* laid onto the world map (s12host.js) */
  if(g.scene==='world') g.saved={x:g.px,y:g.py,dir:g.dir};
  const S=sxMake(def); SX.S=S; g.scene='sx'; g.target=null;
  const st=def.start||[1,1], sx0=tx!==undefined?tx:st[0], sy0=ty!==undefined?ty:st[1];
  g.px=(sx0+0.5)*TS; g.py=(sy0+0.95)*TS; g.dir=dir||st[2]||'down'; fade(0.5); quack();
  S.check=[sx0,sy0];
  if(S.follow){ S.follow.x=g.px; S.follow.y=g.py+10; S.trail=[]; for(let i=0;i<14;i++) S.trail.push({x:g.px,y:g.py+i}); }
  hudCache.obj=null;
  if(def.name) toast(def.name,2800);
  if(def.onEnter) def.onEnter(S);
}
function sxLeave(wx,wy){
  const S=SX.S; if(!S) return;
  if(S.host){ sxHostLeave(S,wx,wy); return; }
  const def=S.def;
  g.scene='world'; SX.S=null; g.target=null;
  if(wx!==undefined){ const sp=snapFree(wx,wy,4); g.px=(sp[0]+0.5)*TS; g.py=(sp[1]+0.95)*TS; }
  else if(g.saved){ g.px=g.saved.x; g.py=g.saved.y; }
  g.dir='down'; fade(0.5); g.camX=g.px; g.camY=g.py-10; tileCache.clear(); blip(); hudCache.obj=null;
  if(def.onLeave) def.onLeave();
}
function sxGoto(id,tx,ty,dir){ if(SX.S&&SX.S.host){ sxEnter(id,tx,ty,dir); return; } const keep=g.saved; SX.S=null; g.scene='world'; sxEnter(id,tx,ty,dir); g.saved=keep; }

/* ---------- tiles ---------- */
function sxCh(S,tx,ty){
  const rows=S.def.rows;
  if(ty<0||ty>=rows.length||tx<0||tx>=rows[ty].length) return ' ';
  const k=tx+','+ty;
  if(S.tiles[k]!==undefined) return S.tiles[k];
  const d=S.doors[k]; if(d) return S.fl[d.key]?'.':'+';
  return rows[ty][tx];
}
function sxObjAt(S,tx,ty){
  const ch=sxCh(S,tx,ty), o=S.def.objs&&S.def.objs[ch]; if(!o) return null;
  if(o.when&&!o.when(S)) return null;
  return o;
}
function sxSolid(S,tx,ty){
  const ch=sxCh(S,tx,ty);
  if(ch==='#'||ch===' '||ch==='~'||ch==='+') return true;
  const o=sxObjAt(S,tx,ty);
  if(o&&o.solid!==false) return true;
  return false;
}
function sxSight(S,tx,ty){ const ch=sxCh(S,tx,ty); if(ch==='#'||ch===' '||ch==='+') return true; const o=sxObjAt(S,tx,ty); return !!(o&&o.block); }
function sxLOS(S,x0,y0,x1,y1){
  const d=Math.hypot(x1-x0,y1-y0), n=Math.ceil(d/8);
  for(let i=1;i<n;i++){ const x=x0+(x1-x0)*i/n, y=y0+(y1-y0)*i/n; if(sxSight(S,Math.floor(x/TS),Math.floor(y/TS))) return false; }
  return true;
}
function sxOpen(S,key,msg){ S.fl[key]=1; if(msg) toast(msg,3200); coin(); }
function sxSet(S,tx,ty,ch){ S.tiles[tx+','+ty]=ch; }
function sxSay(S,who,pages,cb){ say(who,Array.isArray(pages)?pages:[pages],cb); }

/* ---------- spells in scenes (red route) ---------- */
function sxCan(sp){
  if(!g.story.isRed) return false;
  const i=SPELLS.findIndex(s=>s[0]===sp); if(i<0) return false;
  if(magicDays()<i+1) return false;
  const need=SPNEED[sp]; if(need&&!g.inv[need]) return false;
  return true;
}
function sxKnown(){ return SPELLS.map(s=>s[0]).filter(sxCan); }
function sxNeed(S,o,spells,solve,alts,hint){
  /* The thing tells you what it is. Which spell answers it is YOUR call: choose a spell on the spell bar (Q / E) and press C
     while facing it. Only non-spell ways (a key, your wings, a lantern) are offered here as choices. */
  o.cast=o.cast||{};
  for(const sp in spells) if(!o.cast[sp]) o.cast[sp]=(S_,ob)=>solve(S_,ob,sp);
  const opts=[], acts=[];
  (alts||[]).forEach(a=>{ let ok=true; try{ ok=!a.cond||a.cond(S); }catch(e){ ok=false; } if(ok){ opts.push(a.t); acts.push(()=>a.fn(S,o)); } });
  if(!opts.length){ say(o.name||'',[o.desc||'It is not going to explain itself.']); return; }
  opts.push('Leave it');
  choose(o.name||'',o.desc||'What do you do?',opts,k=>{ if(k<acts.length) acts[k](); },opts.length-1);
}
/* cast a named spell from the spell bar, straight at whatever you are facing */
function sxCastNamed(sp){
  const S=SX.S; if(!S) return;
  let known=[]; try{ known=spKnown(); }catch(e){}
  if(!known.length){ toast(g.story.isRed?'You know no spells yet.':'You are not a wizard. You will have to think your way through this.',2600); return; }
  if(known.indexOf(sp)<0){ toast('You have not learned '+sp+' yet.',2200); return; }
  if(!sxCan(sp)){ const need=SPNEED[sp]; toast(need&&!g.inv[need]?'You have no '+ITEMS[need].name+'. '+sp+' needs it.':sp+' is no use in here.',2600); return; }
  try{ spSetSel(sp); }catch(e){}
  sxCast(sp);
}
function sxCastSel(){ let sp='Spark'; try{ sp=spGetSel(); }catch(e){} sxCastNamed(sp); }
function sxCastMenu(){
  const S=SX.S; if(!S) return;
  const list=sxKnown();
  if(!list.length){ say('',[g.story.isRed?'You know no spell that helps here.':'You are not a wizard. You will have to think your way through this.']); return; }
  pagedChoose('Cast','Which spell?',list,i=>sxCast(list[i]));
}
function sxCast(sp){
  const S=SX.S; if(!S) return;
  switch(sp){
    case 'Lumen': S.lumen=60; toast('Lumen: a circle of light blooms around you.',2600); return;
    case 'Veil': S.veil=30; toast('Veil: you become wonderfully uninteresting for a while.',2600); return;
    case 'Spark': S.speed=25; toast('Spark: you feel quick.',2400); return;
    case 'Hearthsong': S.lumen=45; S.veil=25; S.speed=25; toast('Hearthsong: light, veil and speed, all at once.',3000); return;
    case 'Seek': {
      const t=S.def.seek?S.def.seek(S):null;
      if(!t){ if(S.def.onSeek&&S.def.onSeek(S)===true) return; toast('The beetle spins. Nothing here to seek.',2400); return; }
      S.seekT=14; S.seekTo=t; toast('Seek: the beetle points the way.',2400); if(S.def.onSeek) S.def.onSeek(S); return; }
  }
  const f=sxFacing(S,16), tx=f.tx, ty=f.ty;
  const o=sxObjAt(S,tx,ty);
  if(o&&o.cast&&o.cast[sp]){ o.cast[sp](S,o,tx,ty); return; }
  toast('Nothing here answers to '+sp+'. Face the thing you mean to ask.',2600);
}
{
  const _press=press;
  press=function(k){
    if(sxIn()&&g.mode==='play'){
      if(k==='c'){ sxCastSel(); return; }
      if(k==='m'&&!SX.S.host){ toast('There is no map for this place.',1800); return; }
    }
    _press(k);
  };
}

/* ---------- interaction ---------- */
function sxFind(){
  g.target=null; if(g.mode!=='play') return;
  const S=SX.S; if(!S) return;
  const f14=sxFacing(S,14), fx=f14.fx, fy=f14.fy;
  for(const n of S.npcs){ if(n.when&&!n.when(S)) continue; if(Math.hypot(n.x-fx,(n.y-8)-fy)<18){ g.target={k:'sx',npc:n,x:n.x,y:n.y-30}; return; } }
  const tx=f14.tx, ty=f14.ty;
  const o=sxObjAt(S,tx,ty);
  if(o&&(o.use||o.cast||o.desc)){ g.target={k:'sx',obj:o,tx:tx,ty:ty,x:(tx+0.5)*TS,y:ty*TS-6}; return; }
  const ch=sxCh(S,tx,ty);
  if(S.def.exits&&S.def.exits[ch]){ g.target={k:'sx',exit:ch,tx:tx,ty:ty,x:(tx+0.5)*TS,y:ty*TS-6}; }
}
function sxUse(tg){
  const S=SX.S; if(!S) return;
  if(tg.npc){ const n=tg.npc; n.dir=OPP[sxLDir(S)]; if(n.talk) n.talk(S,n); else say(n.name,n.lines||['...']); return; }
  if(tg.obj){ const o=tg.obj; if(o.use) o.use(S,o,tg.tx,tg.ty); else if(o.desc) say(o.name||'',[o.desc]); return; }
  if(tg.exit){ sxExitUse(S,tg.exit); }
}
function sxExitOn(S,ch){ const h=S.host; return !(h&&h.exitOff&&h.exitOff.indexOf(ch)>=0); }   /* hosted: the entrances are just open ground */
function sxExitUse(S,ch){
  const e=S.def.exits[ch]; if(!e) return;
  if(!sxExitOn(S,ch)) return;
  if(e.cond&&!e.cond(S)){ say('',[e.msg||'You cannot go that way yet.']); return; }
  if(e.fn){ e.fn(S); return; }
  if(e.to==='world') sxLeave(e.wx,e.wy);
  else sxGoto(e.to,e.tx,e.ty,e.dir);
}
{
  const _solid=solidTile;
  solidTile=function(tx,ty){ if(g.scene==='sx'&&SX.S&&!SX.S.host) return sxSolid(SX.S,tx,ty); return _solid(tx,ty); };
  const _blocked=blockedAt;
  blockedAt=function(x,y){
    if(_blocked(x,y)) return true;
    if(g.scene==='sx'&&SX.S&&!SX.S.host){ for(const n of SX.S.npcs){ if(n.when&&!n.when(SX.S)) continue; if(Math.abs(n.x-x)<11&&Math.abs(n.y-y)<7) return true; } }
    return false;
  };
  const _ft=findTarget;
  findTarget=function(){ if(g.scene==='sx'){ sxFind(); return; } _ft(); };
  const _int=interact;
  interact=function(){ const tg=g.target; if(g.scene==='sx'){ if(tg&&tg.k==='sx'){ quack(); sxUse(tg); } return; } _int(); };
  const _an=areaName;
  areaName=function(){ if(g.scene==='sx'&&SX.S) return SX.S.def.area||SX.S.def.name||'...'; return _an(); };
  const _drawInt=drawInterior;
  drawInterior=function(c,W,H,kd2,time){ if(g.scene==='sx'&&SX.S){ sxDraw(c,W,H,kd2,time); return; } _drawInt(c,W,H,kd2,time); };
  const _su=storyUpdate;
  storyUpdate=function(dt){ if(g.scene==='sx'){ sxUpdate(dt); return; } _su(dt); };
}

/* ---------- per-frame ---------- */
function sxUpdate(dt){
  const S=SX.S; if(!S||g.mode==='title') return;
  const def=S.def;
  if(g.mode==='play') S.t+=dt;
  S.lumen=Math.max(0,S.lumen-dt); S.veil=Math.max(0,S.veil-dt); S.speed=Math.max(0,S.speed-dt); S.seekT=Math.max(0,S.seekT-dt);
  if(S.speed>0&&g.boost<0.5) g.boost=0.6;
  const pX=sxLX(S), pY=sxLY(S);
  const ptx=Math.floor(pX/TS), pty=Math.floor((pY-2)/TS);
  if(g.mode==='play'){
    /* follower trail */
    const lt=S.trail[S.trail.length-1];
    if(!lt||Math.hypot(pX-lt.x,pY-lt.y)>4){ S.trail.push({x:pX,y:pY}); if(S.trail.length>60) S.trail.shift(); }
    if(S.follow){
      const tp=S.trail[Math.max(0,S.trail.length-11)], f=S.follow, dx=tp.x-f.x, dy=tp.y-f.y, d=Math.hypot(dx,dy);
      f.moving=d>2; if(f.moving){ f.phase+=dt*10; f.dir=Math.abs(dx)>Math.abs(dy)?(dx>0?'right':'left'):(dy>0?'down':'up'); }
      f.x+=dx*Math.min(1,dt*9); f.y+=dy*Math.min(1,dt*9);
    }
    /* npcs idle */
    for(const n of S.npcs){ if(n.still!==false) continue; }
    /* guards */
    sxGuards(S,dt);
    /* triggers */
    for(const t of (def.trig||[])){
      const key='t_'+t.id;
      const inside=ptx>=t.tx&&ptx<t.tx+(t.w||1)&&pty>=t.ty&&pty<t.ty+(t.h||1);
      if(!inside){ t._in=false; continue; }
      if(t._in) continue;
      if(t.when&&!t.when(S)) continue;
      if(t.once!==false&&S.fl[key]) continue;
      t._in=true; if(t.once!==false) S.fl[key]=1;
      t.fn(S); break;
    }
    /* timer */
    if(S.timer){
      S.timer.t-=dt;
      if(S.timer.t<=0){ const tm=S.timer; S.timer=null; if(tm.onEnd) tm.onEnd(S); }
    }
  }
  if(def.tick&&g.mode==='play') def.tick(S,dt);
  if(!S.host){ g.camX=g.px; g.camY=g.py-10; }
  if(S.exitCool>0) S.exitCool-=dt;
  if(g.mode==='play'&&!(S.exitCool>0)){ const ch=sxCh(S,ptx,pty); const e=def.exits&&def.exits[ch]; if(e&&e.auto!==false&&sxExitOn(S,ch)){ S.exitCool=2.5; sxExitUse(S,ch); } }
}
function sxGuards(S,dt){
  let worst=0;
  const pX=sxLX(S), pY=sxLY(S), targets=[{x:pX,y:pY-8,tx:Math.floor(pX/TS),ty:Math.floor((pY-2)/TS)}];
  if(S.follow&&S.def.follow.seen!==false) targets.push({x:S.follow.x,y:S.follow.y-8,tx:Math.floor(S.follow.x/TS),ty:Math.floor((S.follow.y-2)/TS)});
  for(const gd of S.guards){
    if(gd.off&&gd.off(S)) { gd.alert=0; continue; }
    /* patrol */
    if(gd.path&&gd.path.length>1){
      if(gd.pause>0){ gd.pause-=dt; gd.moving=false; if(gd.scan) gd.face+=Math.sin(S.t*2.2)*dt*1.4; }
      else{
        const wp=gd.path[gd.wp], tx=(wp[0]+0.5)*TS, ty=(wp[1]+0.95)*TS, dx=tx-gd.x, dy=ty-gd.y, d=Math.hypot(dx,dy);
        if(d<2){
          gd.pause=wp[2]!==undefined?wp[2]:gd.wait;
          if(gd.loop){ gd.wp=(gd.wp+1)%gd.path.length; }
          else { if(gd.wp+gd.fwd>=gd.path.length||gd.wp+gd.fwd<0) gd.fwd*=-1; gd.wp+=gd.fwd; }
        } else {
          const sp=gd.speed*dt; gd.x+=dx/d*Math.min(sp,d); gd.y+=dy/d*Math.min(sp,d); gd.moving=true; gd.phase+=dt*9;
          gd.face=Math.atan2(dy,dx);
        }
      }
    } else if(gd.sweep){ gd.face=(gd.base!==undefined?gd.base:(gd.base=gd.face))+Math.sin(S.t*gd.sweepSpeed*1||S.t)*gd.sweep; }
    gd.dir=Math.abs(Math.cos(gd.face))>Math.abs(Math.sin(gd.face))?(Math.cos(gd.face)>0?'right':'left'):(Math.sin(gd.face)>0?'down':'up');
    /* sight */
    let seen=false;
    for(const t of targets){
      const dx=t.x-gd.x, dy=t.y-(gd.y-8), d=Math.hypot(dx,dy);
      let rng=gd.range*TS;
      if(S.veil>0) rng*=0.3;
      if(sxCh(S,t.tx,t.ty)===',') rng*=0.5;
      if(d>rng) continue;
      let da=Math.atan2(dy,dx)-gd.face; while(da>Math.PI) da-=Math.PI*2; while(da<-Math.PI) da+=Math.PI*2;
      if(Math.abs(da)>gd.fov*Math.PI/360) continue;
      if(!sxLOS(S,gd.x,gd.y-8,t.x,t.y)) continue;
      seen=true; break;
    }
    if(seen) gd.alert=Math.min(1,gd.alert+dt*1.8); else gd.alert=Math.max(0,gd.alert-dt*0.9);
    worst=Math.max(worst,gd.alert);
    if(gd.alert>=1){ sxCaught(S,gd); return; }
  }
  S.det=worst;
}
function sxCaught(S,gd){
  S.caught++; sxStore(S.id).n=(sxStore(S.id).n||0)+1;
  S.det=0; for(const x of S.guards) x.alert=0;
  const def=S.def;
  if(def.onCaught){ def.onCaught(S,gd); return; }
  const lines=def.caughtLines||['"HALT!" The spear drops across your path.','You are marched back to where you started, and told, firmly, not to come in again. You come in again.'];
  fade(0.6); advanceClock(0.4);
  say(gd.name||'Guard',lines,()=>{
    const c=S.check||def.start, rx=(c[0]+0.5)*TS, ry=(c[1]+0.95)*TS;
    sxPlace(S,rx,ry); S.trail=[]; for(let i=0;i<14;i++) S.trail.push({x:rx,y:ry});
    if(S.follow){ S.follow.x=rx; S.follow.y=ry+10; }
    for(const x of S.guards){ const p=x.path?x.path[0]:[x.tx,x.ty]; x.x=(p[0]+0.5)*TS; x.y=(p[1]+0.95)*TS; x.wp=1; x.pause=1.2; }
    if(def.onReset) def.onReset(S);
    if(S.caught>=3&&def.hint&&!S.hinted){ S.hinted=1; toast(def.hint,6000); }
  });
}
function sxTimer(S,secs,label,onEnd){ S.timer={t:secs,max:secs,label:label,onEnd:onEnd}; }
function sxCheckpoint(S,tx,ty){ S.check=[tx,ty]; toast('Checkpoint.',1400); }

/* ---------- drawing ---------- */
function sxEdge(S,tx,ty){ const ch=sxCh(S,tx,ty); return ch==='#'||ch===' '; }
const SXG={
  chest:(c,x,y,t,o,S)=>{ const on=S.fl[o.key]; ell(c,x+16,y+27,12,4,'rgba(0,0,0,0.25)'); rect(c,x+5,y+13,22,14,o.col||'#8a5a2b'); rect(c,x+5,y+(on?6:10),22,5,'#a5703a'); rect(c,x+14,y+16,4,5,'#e0b84a'); },
  shelf:(c,x,y,t,o)=>{ rect(c,x,y,TS,TS,'#5b4430'); rect(c,x+2,y+2,TS-4,TS-4,'#3b2b1e'); const sp=['#e0b84a','#3a7ca5','#f4efe0','#c0392b','#5aa05a']; for(let r=0;r<3;r++){ rect(c,x+2,y+3+r*9+8,TS-4,1.5,'#8a6a45'); for(let k=0,xx=x+3;k<6;k++){ const w=3+((r*3+k)%3); rect(c,xx,y+3+r*9,w,8,sp[(r*2+k)%5]); xx+=w+0.5; } } },
  table:(c,x,y)=>{ rect(c,x+2,y+10,28,6,'#8a6238'); rect(c,x+2,y+10,28,2,'#b98a55'); rect(c,x+4,y+16,3,10,'#5b3f22'); rect(c,x+25,y+16,3,10,'#5b3f22'); },
  bed:(c,x,y)=>{ rect(c,x+3,y+8,26,18,'#5b3f22'); rect(c,x+5,y+10,22,14,'#e8e0c0'); rect(c,x+5,y+10,22,5,'#b8c9e0'); },
  pillar:(c,x,y,t,o)=>{ ell(c,x+16,y+28,11,4,'rgba(0,0,0,0.25)'); rect(c,x+9,y+2,14,26,o.col||'#b9b4a4'); rect(c,x+7,y,18,4,'#d9d4c4'); rect(c,x+7,y+26,18,3,'#8a8574'); rect(c,x+12,y+2,2,24,'rgba(255,255,255,0.25)'); },
  brazier:(c,x,y,t,o,S)=>{ const on=o.lit?o.lit(S):true; rect(c,x+11,y+16,10,10,'#4a3a2a'); rect(c,x+8,y+14,16,4,'#6a5a4a'); if(on){ c.fillStyle='#ff7a2a'; c.beginPath(); c.moveTo(x+10,y+14); c.quadraticCurveTo(x+13,y+4+Math.sin(t*9)*2,x+16,y); c.quadraticCurveTo(x+21,y+6,x+22,y+14); c.fill(); c.fillStyle='#ffd166'; c.beginPath(); c.moveTo(x+13,y+14); c.quadraticCurveTo(x+15,y+8,x+16,y+5); c.quadraticCurveTo(x+19,y+9,x+19,y+14); c.fill(); circ(c,x+16,y+10,22,'rgba(255,170,80,0.13)'); } },
  torch:(c,x,y,t)=>{ rect(c,x+14,y+8,4,14,'#4a3018'); c.fillStyle='#ff9d2e'; c.beginPath(); c.ellipse(x+16,y+5,3.5,5+Math.sin(t*10),0,0,6.3); c.fill(); circ(c,x+16,y+6,20,'rgba(255,190,90,0.12)'); },
  crystal:(c,x,y,t,o,S)=>{ const a=0.5+0.3*Math.sin(t*3), on=o.lit?o.lit(S):true, col=on?(o.col||'#6ab7ff'):'#4a5060'; c.fillStyle=col; c.beginPath(); c.moveTo(x+16,y-4); c.lineTo(x+26,y+16); c.lineTo(x+16,y+30); c.lineTo(x+6,y+16); c.fill(); c.fillStyle='rgba(255,255,255,0.4)'; c.beginPath(); c.moveTo(x+16,y-4); c.lineTo(x+16,y+30); c.lineTo(x+6,y+16); c.fill(); if(on) circ(c,x+16,y+14,30,'rgba(110,180,255,'+(0.13*a).toFixed(2)+')'); },
  altar:(c,x,y,t,o)=>{ rect(c,x+2,y+10,28,16,'#d9d2bf'); rect(c,x+2,y+10,28,3,'#fff'); rect(c,x+2,y+24,28,3,'#a39a82'); },
  lever:(c,x,y,t,o,S)=>{ const on=S.fl[o.key]; rect(c,x+8,y+20,16,8,'#5a5a64'); c.save(); c.translate(x+16,y+22); c.rotate(on?0.7:-0.7); rect(c,-2,-16,4,16,'#9a9aa4'); circ(c,0,-17,3.5,on?'#5aa05a':'#c0392b'); c.restore(); },
  candle:(c,x,y,t,o,S)=>{ const on=S.fl[o.key]; rect(c,x+13,y+14,6,13,'#f4efe0'); rect(c,x+11,y+26,10,3,'#8a6a2a'); if(on){ c.fillStyle='#ffb347'; c.beginPath(); c.ellipse(x+16,y+10,2.4,4+Math.sin(t*9),0,0,6.3); c.fill(); circ(c,x+16,y+10,17,'rgba(255,200,100,0.14)'); } else rect(c,x+15,y+10,2,4,'#222'); },
  statue:(c,x,y,t,o)=>{ ell(c,x+16,y+28,11,4,'rgba(0,0,0,0.25)'); rect(c,x+8,y+20,16,8,'#9a9eaa'); rect(c,x+11,y+8,10,13,o.col||'#b9bdc8'); circ(c,x+16,y+6,5,o.col||'#b9bdc8'); },
  tree:(c,x,y,t,o)=>{ ell(c,x+16,y+28,12,4,'rgba(0,0,0,0.3)'); rect(c,x+12,y+10,8,18,'#4a3a2a'); c.fillStyle=o.col||'#2f5a34'; c.beginPath(); c.arc(x+16,y+8,13,0,6.3); c.fill(); circ(c,x+12,y+4,6,'rgba(255,255,255,0.08)'); },
  charred:(c,x,y,t,o,S)=>{ ell(c,x+16,y+28,12,4,'rgba(0,0,0,0.3)'); rect(c,x+11,y+4,10,24,'#1e1a18'); rect(c,x+14,y+6,2,18,'#3a2a22'); rect(c,x+6,y+8,8,3,'#1e1a18'); rect(c,x+19,y+12,8,3,'#1e1a18'); if(o.glow) circ(c,x+16,y+14,26,'rgba(255,120,60,'+(0.08+0.05*Math.sin(t*2)).toFixed(2)+')'); },
  sleeper:(c,x,y,t,o,S)=>{ ell(c,x+16,y+28,11,4,'rgba(0,0,0,0.3)'); rect(c,x+11,y+6,10,22,'#3a2f28'); c.fillStyle=o.col||'#5a4a3a'; c.beginPath(); c.arc(x+16,y+6,10,0,6.3); c.fill(); const a=0.5+0.5*Math.sin(t*1.4+x*0.1); circ(c,x+16,y+14,22,'rgba(160,130,255,'+(0.08*a).toFixed(2)+')'); if(S.fl[o.key]) circ(c,x+16,y+12,5,'rgba(255,230,150,0.8)'); },
  rock:(c,x,y,t,o)=>{ ell(c,x+16,y+26,12,4,'rgba(0,0,0,0.25)'); ell(c,x+16,y+19,12,9,o.col||'#7d838c'); ell(c,x+13,y+15,5,3,'rgba(255,255,255,0.15)'); },
  boulder:(c,x,y,t,o,S)=>{ ell(c,x+16,y+27,13,4,'rgba(0,0,0,0.3)'); ell(c,x+16,y+18,13,11,'#6a6e78'); ell(c,x+12,y+13,6,4,'rgba(255,255,255,0.14)'); rect(c,x+14,y+12,1,12,'#44464e'); },
  thorns:(c,x,y,t,o)=>{ c.fillStyle='#3a1a1a'; for(let i=0;i<7;i++){ c.beginPath(); c.moveTo(x+3+i*4,y+28); c.lineTo(x+6+i*4+Math.sin(i)*3,y+6+(i%3)*4); c.lineTo(x+8+i*4,y+28); c.fill(); } for(let i=0;i<5;i++) circ(c,x+6+i*5,y+10+(i%2)*8,1.4,'#c0392b'); },
  curse:(c,x,y,t,o,S)=>{ const a=0.5+0.5*Math.sin(t*4); c.strokeStyle='rgba(190,60,255,'+(0.5+0.4*a).toFixed(2)+')'; c.lineWidth=2; c.beginPath(); c.arc(x+16,y+16,10,0,6.3); c.stroke(); c.beginPath(); c.moveTo(x+8,y+16); c.lineTo(x+24,y+16); c.moveTo(x+16,y+8); c.lineTo(x+16,y+24); c.stroke(); circ(c,x+16,y+16,18,'rgba(190,60,255,'+(0.1*a).toFixed(2)+')'); },
  fog:(c,x,y,t,o)=>{ for(let i=0;i<4;i++){ const dx=Math.sin(t*0.6+i*1.7+x*0.05)*5; c.fillStyle='rgba(210,215,230,0.55)'; c.beginPath(); c.ellipse(x+8+i*5+dx,y+8+((i*7)%16),11,7,0,0,6.3); c.fill(); } },
  book:(c,x,y)=>{ ell(c,x+16,y+27,9,3,'rgba(0,0,0,0.2)'); rect(c,x+7,y+14,18,12,'#7a2a4a'); rect(c,x+7,y+14,3,12,'#4a1430'); rect(c,x+12,y+17,10,1,'#e8d8ff'); rect(c,x+12,y+20,8,1,'#e8d8ff'); },
  scroll:(c,x,y)=>{ ell(c,x+16,y+27,9,3,'rgba(0,0,0,0.2)'); rect(c,x+7,y+14,18,10,'#f2e6c4'); rect(c,x+5,y+13,3,12,'#c9a46a'); rect(c,x+24,y+13,3,12,'#c9a46a'); rect(c,x+10,y+17,12,1,'#8a6a3a'); rect(c,x+10,y+20,9,1,'#8a6a3a'); },
  gate:(c,x,y,t,o,S)=>{ rect(c,x,y,TS,TS,'#2a2a32'); for(let i=0;i<5;i++) rect(c,x+3+i*6,y+2,3,TS-4,'#8a8a96'); rect(c,x,y+10,TS,3,'#6a6a76'); },
  crate:(c,x,y,t,o)=>{ ell(c,x+16,y+28,11,3,'rgba(0,0,0,0.25)'); rect(c,x+5,y+9,22,18,o.col||'#8a6a45'); rect(c,x+5,y+9,22,3,'#a5855a'); rect(c,x+14,y+9,4,18,'#6b4a2f'); },
  mirror:(c,x,y,t,o,S)=>{ rect(c,x+7,y+2,18,26,'#6a5a3a'); rect(c,x+9,y+4,14,22,'#9ac0d8'); rect(c,x+11,y+6,3,16,'rgba(255,255,255,0.4)'); },
  desk:(c,x,y)=>{ rect(c,x+1,y+10,30,8,'#6a4a2a'); rect(c,x+1,y+10,30,2,'#9a7a4a'); rect(c,x+4,y+18,3,9,'#4a3018'); rect(c,x+25,y+18,3,9,'#4a3018'); rect(c,x+10,y+7,10,4,'#f2e6c4'); },
  cage:(c,x,y,t,o)=>{ rect(c,x+4,y+4,24,24,'rgba(0,0,0,0.25)'); for(let i=0;i<5;i++) rect(c,x+5+i*5,y+4,2,24,'#8a8a96'); rect(c,x+4,y+4,24,2,'#8a8a96'); },
  rug:(c,x,y,t,o)=>{ rect(c,x+2,y+6,28,20,o.col||'#7a2a3a'); rect(c,x+4,y+8,24,16,'rgba(255,255,255,0.08)'); },
  well:(c,x,y)=>{ ell(c,x+16,y+22,13,8,'#6a6e78'); ell(c,x+16,y+20,10,6,'#1a2a4a'); rect(c,x+4,y+6,3,16,'#5a3a22'); rect(c,x+25,y+6,3,16,'#5a3a22'); rect(c,x+4,y+5,24,3,'#5a3a22'); },
  door:(c,x,y,t,o)=>{ rect(c,x+2,y+2,28,28,'#4a2c18'); rect(c,x+4,y+4,24,24,o.col||'#7a4a24'); circ(c,x+23,y+17,1.8,'#e0b84a'); },
  lamp:(c,x,y,t)=>{ rect(c,x+15,y+8,2,20,'#4a4a50'); circ(c,x+16,y+7,5,'#ffd166'); circ(c,x+16,y+7,18,'rgba(255,200,100,0.12)'); },
  fireplace:(c,x,y,t,o,S)=>{ const on=S.fl.hearth; rect(c,x,y,TS,TS,'#6a6e78'); rect(c,x+4,y+8,TS-8,TS-8,'#14100e'); rect(c,x+2,y+4,TS-4,5,'#8a8e98'); if(on){ c.fillStyle='#ff7a2a'; c.beginPath(); c.moveTo(x+8,y+TS-4); c.quadraticCurveTo(x+11,y+14+Math.sin(t*8)*2,x+16,y+8); c.quadraticCurveTo(x+22,y+16,x+24,y+TS-4); c.fill(); c.fillStyle='#ffd166'; c.beginPath(); c.moveTo(x+12,y+TS-4); c.quadraticCurveTo(x+14,y+20,x+16,y+16); c.quadraticCurveTo(x+19,y+21,x+20,y+TS-4); c.fill(); circ(c,x+16,y+20,34,'rgba(255,150,70,0.12)'); } },
  chair:(c,x,y,t,o,S)=>{ const ok=S.fl.chair; ell(c,x+16,y+27,9,3,'rgba(0,0,0,0.2)'); rect(c,x+9,y+16,14,4,'#8a6238'); rect(c,x+9,y+20,3,7,'#5b3f22'); rect(c,x+20,y+20,3,7,'#5b3f22'); if(ok) rect(c,x+9,y+4,3,13,'#8a6238'); else { c.save(); c.translate(x+10,y+17); c.rotate(-0.8); rect(c,0,-12,3,12,'#8a6238'); c.restore(); } },
  shutter:(c,x,y,t,o,S)=>{ rect(c,x+3,y+4,26,22,'#3a2a1a'); rect(c,x+5,y+6,22,18,S.fl.shutter?'#9ac0d8':'#1a2a3a'); rect(c,x+15,y+6,2,18,'#3a2a1a'); if(!S.fl.shutter){ c.save(); c.translate(x+27,y+8); c.rotate(0.5); rect(c,-10,0,10,16,'#5b3f22'); c.restore(); } },
  plank:(c,x,y,t,o,S)=>{ rect(c,x+2,y+10,28,6,'#8a6238'); rect(c,x+2,y+10,28,1,'#b98a55'); if(S.fl.box){ rect(c,x+8,y+14,16,10,'#14100e'); rect(c,x+10,y+16,12,7,'#7a2a4a'); rect(c,x+14,y+14,4,2,'#e0b84a'); } else { const a=0.5+0.5*Math.sin(t*4); circ(c,x+16,y+14,10,'rgba(122,255,200,'+(0.3*a).toFixed(2)+')'); } },
  none:()=>{}
};
function sxDrawTile(c,S,tx,ty,px,py,th,time){
  const ch=sxCh(S,tx,ty);
  if(ch===' ') return;
  if(ch==='#'){
    const below=!sxEdge(S,tx,ty+1);
    rect(c,px,py,TS,TS,th.w[0]);
    if(below){ rect(c,px,py+TS-10,TS,10,th.w[1]); rect(c,px,py+TS-10,TS,1,'rgba(255,255,255,0.08)'); }
    return;
  }
  rect(c,px,py,TS,TS,((tx+ty)&1)?th.f[0]:th.f[1]);
  if(ch==='~'){ rect(c,px,py,TS,TS,'#2a4a7a'); for(let i=0;i<3;i++) rect(c,px+4+((time*8+i*9+tx*5)%24),py+6+i*9,6,1,'rgba(255,255,255,0.35)'); return; }
  if(ch===','){ rect(c,px,py,TS,TS,'rgba(0,0,10,0.35)'); }
  else if(ch==='r'){ rect(c,px+4,py,TS-8,TS,S.def.carpet||th.c); rect(c,px+4,py,2,TS,'rgba(224,184,74,0.7)'); rect(c,px+TS-6,py,2,TS,'rgba(224,184,74,0.7)'); }
  else if(ch==='i'){ rect(c,px,py,TS,TS,'#bfe3f2'); rect(c,px+4,py+6,10,2,'rgba(255,255,255,0.7)'); rect(c,px+16,py+20,9,2,'rgba(255,255,255,0.6)'); }
  else if(ch==='+'){ rect(c,px,py,TS,TS,'#2a2a32'); for(let i=0;i<5;i++) rect(c,px+3+i*6,py+2,3,TS-4,'#8a8a96'); rect(c,px,py+10,TS,3,'#6a6a76'); }
  else if(S.def.exits&&S.def.exits[ch]){ const e=S.def.exits[ch]; rect(c,px+2,py+4,TS-4,TS-4,e.col||'#8a5a2b'); rect(c,px+2,py+TS-6,TS-4,2,'rgba(0,0,0,0.3)'); }
}
function sxDraw(c,W,H,kd2,time){
  const S=SX.S, def=S.def, th=SXT[def.theme||'stone']||SXT.stone;
  const vw=W/kd2, vh=H/kd2, RW=def.rows[0].length*TS, RH=def.rows.length*TS;
  const fx=vw>=RW?(RW/2-vw/2):Math.max(-10,Math.min(RW-vw+10,g.px-vw/2)), fy=vh>=RH?(RH/2-vh/2):Math.max(-30,Math.min(RH-vh+10,g.py-14-vh/2));
  const ox=Math.round(fx*kd2)/kd2, oy=Math.round(fy*kd2)/kd2;
  S.ox=ox; S.oy=oy;
  c.setTransform(kd2,0,0,kd2,-ox*kd2,-oy*kd2);
  const rows=def.rows.length, cols=def.rows[0].length;
  for(let ty=0;ty<rows;ty++) for(let tx=0;tx<cols;tx++) sxDrawTile(c,S,tx,ty,tx*TS,ty*TS,th,time);
  if(def.draw) def.draw(c,S,time,'under');
  /* things sorted by y */
  const list=[];
  for(let ty=0;ty<rows;ty++) for(let tx=0;tx<cols;tx++){
    const o=sxObjAt(S,tx,ty); if(!o) continue;
    list.push({y:ty*TS+(o.sortY||TS),k:'o',o:o,tx:tx,ty:ty});
  }
  for(const n of S.npcs){ if(n.when&&!n.when(S)) continue; list.push({y:n.y,k:'n',n:n}); }
  for(const gd of S.guards){ if(gd.off&&gd.off(S)) continue; list.push({y:gd.y,k:'g',n:gd}); }
  if(S.follow) list.push({y:S.follow.y,k:'f'});
  list.push({y:g.py,k:'p'});
  list.sort((a,b)=>a.y-b.y);
  for(const it of list){
    if(it.k==='o'){ const fn=SXG[it.o.glyph||'none']; if(fn) fn(c,it.tx*TS,it.ty*TS,time,it.o,S); }
    else if(it.k==='n'){ const n=it.n; drawDuck(c,n.x,n.y,n.dir,n.phase,n.moving,n.pal,{head:n.acc.head,neck:n.acc.neck,scale:n.scale}); if(n.mark&&g.mode==='play'){ const m=typeof n.mark==='function'?n.mark(S):n.mark; if(m) drawMark(c,n.x,n.y-34,time,m,'#ffd166'); } }
    else if(it.k==='g'){ const n=it.n; drawDuck(c,n.x,n.y,n.dir,n.phase,n.moving,n.pal,{head:n.head,neck:null}); if(n.alert>0.05){ c.fillStyle='rgba(255,60,60,'+Math.min(1,n.alert+0.2).toFixed(2)+')'; c.font='700 14px Georgia,serif'; c.textAlign='center'; c.fillText('!',n.x,n.y-34); c.textAlign='left'; } }
    else if(it.k==='f'){ const f=S.follow; drawDuck(c,f.x,f.y,f.dir,f.phase,f.moving,f.pal,{head:f.head,scale:f.scale}); }
    else drawMe(c,time);
  }
  if(def.draw) def.draw(c,S,time,'over');
  /* guard cones */
  for(const gd of S.guards){
    if(gd.off&&gd.off(S)) continue;
    let rng=gd.range*TS*(S.veil>0?0.3:1), half=gd.fov*Math.PI/360, a=Math.min(1,gd.alert);
    const x0=gd.x, y0=gd.y-8;
    c.fillStyle='rgba('+(255)+','+Math.round(220-160*a)+','+Math.round(80-60*a)+','+(0.10+0.2*a).toFixed(2)+')';
    c.beginPath(); c.moveTo(x0,y0);
    for(let i=0;i<=10;i++){
      const ang=gd.face-half+(half*2)*i/10; let r=0;
      for(;r<rng;r+=6){ if(sxSight(S,Math.floor((x0+Math.cos(ang)*r)/TS),Math.floor((y0+Math.sin(ang)*r)/TS))) break; }
      c.lineTo(x0+Math.cos(ang)*r,y0+Math.sin(ang)*r);
    }
    c.closePath(); c.fill();
  }
  /* darkness with lights */
  if(def.dark){
    const lights=[{x:g.px,y:g.py-10,r:(def.lightR||80)+(S.lumen>0?70:0)}];
    for(const o of Object.values(def.objs||{})){ void o; }
    for(let ty=0;ty<rows;ty++) for(let tx=0;tx<cols;tx++){ const o=sxObjAt(S,tx,ty); if(o&&o.light){ const on=typeof o.light==='function'?o.light(S):o.light; if(on) lights.push({x:(tx+0.5)*TS,y:(ty+0.5)*TS,r:o.lightR||60}); } }
    for(const l of (def.lights||[])) lights.push({x:(l.tx+0.5)*TS,y:(l.ty+0.5)*TS,r:l.r||70});
    if(S.follow) lights.push({x:S.follow.x,y:S.follow.y-10,r:34});
    if(!SX.dark) SX.dark=document.createElement('canvas');
    const dc=SX.dark; if(dc.width!==W||dc.height!==H){ dc.width=W; dc.height=H; }
    const d2=dc.getContext('2d'); d2.setTransform(1,0,0,1,0,0); d2.globalCompositeOperation='source-over'; d2.clearRect(0,0,W,H);
    d2.fillStyle='rgba(3,3,14,'+(def.dark===true?0.9:def.dark)+')'; d2.fillRect(0,0,W,H);
    d2.globalCompositeOperation='destination-out';
    for(const l of lights){ const sx0=(l.x-ox)*kd2, sy0=(l.y-oy)*kd2, r=l.r*kd2; const gr=d2.createRadialGradient(sx0,sy0,r*0.2,sx0,sy0,r); gr.addColorStop(0,'rgba(0,0,0,1)'); gr.addColorStop(1,'rgba(0,0,0,0)'); d2.fillStyle=gr; d2.beginPath(); d2.arc(sx0,sy0,r,0,6.3); d2.fill(); }
    c.setTransform(1,0,0,1,0,0); c.drawImage(dc,0,0);
    c.setTransform(kd2,0,0,kd2,-ox*kd2,-oy*kd2);
  }
  /* seek arrow */
  if(S.seekT>0&&S.seekTo){ const a=Math.atan2(S.seekTo[1]*TS+16-(g.py-10),S.seekTo[0]*TS+16-g.px); for(let i=1;i<=5;i++) circ(c,g.px+Math.cos(a)*i*14,g.py-10+Math.sin(a)*i*14,2.2,'rgba(122,255,200,'+(0.9-i*0.12).toFixed(2)+')'); }
  if(def.fx==='dream'){ for(let i=0;i<22;i++){ const tt=(time*0.08+i*0.047)%1, x=ox+((i*61)%Math.round(vw)), y=oy+vh-tt*vh; c.fillStyle='rgba(190,170,255,'+(0.35*(1-tt)).toFixed(2)+')'; c.fillRect(x,y,2,2); } }
  if(g.target&&g.mode==='play') drawBubble(c,g.target.x,g.target.y,time,'Z');
  c.setTransform(1,0,0,1,0,0);
  /* hud: detection bar and timer */
  if(S.det>0.03){ const w=120*kd2/2, h=6; c.fillStyle='rgba(0,0,0,0.55)'; c.fillRect(W/2-w/2-1,12,w+2,h+2); c.fillStyle='rgb(255,'+Math.round(200-170*S.det)+',60)'; c.fillRect(W/2-w/2,13,w*S.det,h); }
  if(S.timer){ c.font='700 '+Math.round(11*kd2/2+7)+'px ui-monospace,monospace'; c.textAlign='center'; const m=Math.floor(S.timer.t/60), s=Math.ceil(S.timer.t%60); c.fillStyle=S.timer.t<10?'#ff6a5a':'#fff3d4'; c.fillText((S.timer.label||'')+' '+m+':'+(s<10?'0':'')+(s===60?'59':s),W/2,36); c.textAlign='left'; }
  const a2=ambient(g.clock);
  if(!def.dark&&def.daylight!==false&&a2[3]>0.1&&!def.indoor){ c.fillStyle='rgba(20,18,50,'+(a2[3]*0.12).toFixed(2)+')'; c.fillRect(0,0,W,H); }
}
