'use strict';
/* ===== THE WILDS: hooks that make the biomes visible =====
   Ground colours, decorations, species painters, water, the explored map, area names, drifting particles. */

/* ---------- persistent wild data lives inside the story object, so it saves with everything else ---------- */
function WD(){
  const s=g.story||(g.story={});
  let w=s.wd;
  if(!w){ w=s.wd={}; }
  if(!w.picked) w.picked={};      /* "x,y" -> day foraged */
  if(!w.seen) w.seen={};          /* species id -> times found */
  if(!w.got) w.got={};            /* item id -> total ever found */
  if(!w.biomes) w.biomes={};      /* biome id -> day first visited */
  if(!w.dug) w.dug={};            /* "x,y" -> day dug */
  if(!w.hunts) w.hunts=[];        /* open treasure-map hunts */
  if(!w.cases) w.cases={};        /* townKey -> daily case */
  if(!w.stats) w.stats={};
  if(!w.gone) w.gone={};          /* "x,y" -> plants collected and used up */
  if(w.day!==g.day){
    w.day=g.day;
    for(const k in w.picked) if(w.picked[k]!==g.day) delete w.picked[k];
    for(const k in w.dug) if(w.dug[k]!==g.day) delete w.dug[k];
  }
  return w;
}
const wlPicked=(x,y)=>{ const w=g.story&&g.story.wd; return !!(w&&w.day===g.day&&w.picked&&w.picked[x+','+y]===g.day); };

/* ---------- ground: biome palettes through the existing styleAt hook ---------- */
{
  const _styleAt2=styleAt;
  styleAt=function(x,y){
    const s=_styleAt2(x,y); if(s) return s;
    const b=wlBiomeAt(x,y);
    return b&&b.style||null;
  };
}
const WL_DECOR={
  meadow:(c,x,y,px,py)=>{ if(hash(x,y,610)<0.35){ const cols=['#ffffff','#f6e27a','#f4a6c3','#b8d4ff']; for(let i=0;i<2;i++) rect(c,px+((hash(x,y,611+i)*28)|0),py+((hash(x,y,613+i)*28)|0),2,2,cols[(hash(x,y,615+i)*4)|0]); } },
  leaves:(c,x,y,px,py)=>{ const cols=['#b8321c','#d9582b','#e8b13a','#a8432b']; for(let i=0;i<3;i++) if(hash(x,y,620+i)<0.5) rect(c,px+((hash(x,y,623+i)*27)|0),py+((hash(x,y,626+i)*27)|0),3,2,cols[(hash(x,y,629+i)*4)|0]); },
  snow:(c,x,y,px,py)=>{ if(hash(x,y,630)<0.25){ rect(c,px+((hash(x,y,631)*22)|0),py+((hash(x,y,632)*24)|0),8,3,'rgba(255,255,255,0.85)'); } if(hash(x,y,633)<0.12){ rect(c,px+((hash(x,y,634)*26)|0),py+((hash(x,y,635)*26)|0),2,2,'#cfe6ff'); } },
  pebbles:(c,x,y,px,py)=>{ for(let i=0;i<2;i++) if(hash(x,y,640+i)<0.45){ const qx=px+((hash(x,y,642+i)*26)|0), qy=py+((hash(x,y,644+i)*26)|0); ell(c,qx+2,qy+1,2.4,1.5,'#8c9096'); rect(c,qx+1,qy,1,1,'#b3b7bd'); } },
  dunes:(c,x,y,px,py)=>{ c.fillStyle='rgba(176,140,80,0.34)'; const o=(hash(x,y,650)*10)|0; c.fillRect(px+2+o,py+9,14,1); c.fillRect(px+10-o,py+22,12,1); c.fillStyle='rgba(255,244,200,0.45)'; c.fillRect(px+4+o,py+10,10,1); if(hash(x,y,651)<0.12) rect(c,px+((hash(x,y,652)*26)|0),py+((hash(x,y,653)*26)|0),2,1,'#a8884e'); },
  litter:(c,x,y,px,py)=>{ c.fillStyle='rgba(10,40,20,0.35)'; for(let i=0;i<3;i++) if(hash(x,y,660+i)<0.55) c.fillRect(px+((hash(x,y,663+i)*26)|0),py+((hash(x,y,666+i)*26)|0),4,2); if(hash(x,y,669)<0.1) rect(c,px+((hash(x,y,670)*26)|0),py+((hash(x,y,671)*26)|0),3,2,'#6a9a3a'); },
  bog:(c,x,y,px,py)=>{ if(hash(x,y,680)<0.28){ const qx=px+4+((hash(x,y,681)*14)|0), qy=py+6+((hash(x,y,682)*14)|0); ell(c,qx+5,qy+2,6,2.6,'rgba(40,60,30,0.7)'); ell(c,qx+4,qy+1.5,3,1,'rgba(160,200,140,0.35)'); } if(hash(x,y,683)<0.18) rect(c,px+((hash(x,y,684)*26)|0),py+((hash(x,y,685)*26)|0),2,3,'#4a6a3a'); },
  bamboo:(c,x,y,px,py)=>{ for(let i=0;i<2;i++) if(hash(x,y,690+i)<0.45){ c.fillStyle=i?'#b8c860':'#8ab050'; c.save(); c.translate(px+((hash(x,y,692+i)*24)|0)+3,py+((hash(x,y,694+i)*24)|0)+3); c.rotate(hash(x,y,696+i)*3); c.fillRect(-4,-1,8,2); c.restore(); } },
  petals:(c,x,y,px,py)=>{ for(let i=0;i<3;i++) if(hash(x,y,700+i)<0.55) rect(c,px+((hash(x,y,703+i)*27)|0),py+((hash(x,y,706+i)*27)|0),2,2,hash(x,y,709+i)<0.5?'#f6b0c8':'#ffffff'); },
  specks:(c,x,y,px,py)=>{ for(let i=0;i<3;i++) if(hash(x,y,720+i)<0.5){ const col=['#7affd0','#b8a0ff','#7ff0ff'][(hash(x,y,723+i)*3)|0]; c.globalAlpha=0.7; rect(c,px+((hash(x,y,726+i)*28)|0),py+((hash(x,y,729+i)*28)|0),2,2,col); c.globalAlpha=1; } },
  purple:(c,x,y,px,py)=>{ for(let i=0;i<4;i++) if(hash(x,y,740+i)<0.5) rect(c,px+((hash(x,y,744+i)*28)|0),py+((hash(x,y,748+i)*28)|0),2,3,hash(x,y,752+i)<0.5?'#9a7ad8':'#b8a0e8'); },
  shells:(c,x,y,px,py)=>{ c.fillStyle='rgba(205,180,120,0.5)'; const o=(hash(x,y,760)*10)|0; c.fillRect(px+3+o,py+12,12,1); c.fillRect(px+10-o,py+25,10,1); if(hash(x,y,761)<0.16){ const qx=px+((hash(x,y,762)*24)|0)+2, qy=py+((hash(x,y,763)*24)|0)+2; ell(c,qx,qy,2.4,1.8,'#f6d6c8'); rect(c,qx-1,qy-1,2,1,'#fff'); } },
  tallgrass:(c,x,y,px,py)=>{ c.strokeStyle='#8f8030'; c.lineWidth=1; for(let i=0;i<4;i++) if(hash(x,y,770+i)<0.6){ const qx=px+((hash(x,y,774+i)*26)|0)+2, qy=py+((hash(x,y,778+i)*20)|0)+8; c.beginPath(); c.moveTo(qx,qy+7); c.lineTo(qx+(i&1?2:-2),qy); c.stroke(); } }
};
{
  const _drawGrass=drawGrass;
  drawGrass=function(c,x,y,px,py,dk,st){
    _drawGrass(c,x,y,px,py,dk,st);
    if(st&&st.biome&&!(dk>0.2)){
      const f=WL_DECOR[st.biome.decor]; if(f) f(c,x,y,px,py);
    }
    if(typeof wlGroundMarks==='function') wlGroundMarks(c,x,y,px,py);
  };
}

/* ---------- water takes on the colour of the country ---------- */
{
  const _drawWater=drawWater;
  drawWater=function(c,x,y,px,py,time){
    _drawWater(c,x,y,px,py,time);
    const b=wlBiomeAt(x,y);
    if(!b||!b.waterTint) return;
    c.fillStyle=b.waterTint; c.fillRect(px,py,TS,TS);
    if(b.ice){
      c.strokeStyle='rgba(255,255,255,0.7)'; c.lineWidth=1; c.beginPath();
      const o=hash(x,y,790)*20; c.moveTo(px+o,py); c.lineTo(px+o+6,py+14); c.lineTo(px+o-4,py+TS); c.stroke();
      rect(c,px+4+((hash(x,y,791)*18)|0),py+6+((hash(x,y,792)*18)|0),5,2,'rgba(255,255,255,0.65)');
    }
    if(b.lilies&&hash(x,y,793)<0.22){
      const lx=px+8+((hash(x,y,794)*14)|0), ly=py+8+((hash(x,y,795)*14)|0);
      ell(c,lx,ly,6,3.4,'#4f8f45'); ell(c,lx-1,ly-0.5,4,2,'#68ad5a'); wlTri(c,lx,ly,lx+7,ly-3,lx+7,ly+1,'rgba(40,70,40,0.8)');
      if(hash(x,y,796)<0.4){ circ(c,lx+1,ly-1,2,'#f6a6c8'); circ(c,lx+1,ly-1,0.8,'#f6e27a'); }
    }
  };
}

/* ---------- the species painters take over trees, flowers, bushes, mushrooms, rocks and stumps ---------- */
{
  const _drawTree=drawTree;
  drawTree=function(c,x,y,px,py,time,dark,glint){
    if(!dark){
      const sp=wlSpeciesAt(x,y,T.TREE);
      if(sp){ wlPaintTree(c,x,y,px,py,time,sp,wlPicked(x,y)); return; }
    }
    _drawTree(c,x,y,px,py,time,dark,glint);
  };
  const _drawFlower=drawFlower;
  drawFlower=function(c,x,y,px,py){
    const sp=wlSpeciesAt(x,y,T.FLOWER);
    if(sp){ wlPaintFlowerTile(c,x,y,px,py,sp,g.time,wlPicked(x,y)); return; }
    _drawFlower(c,x,y,px,py);
    if(wlPicked(x,y)) wlPickedMark(c,px,py);
  };
  const _drawBush=drawBush;
  drawBush=function(c,px,py){
    /* drawBush has no coordinates: recover the tile from the pixel position */
    const x=Math.round(px/TS), y=Math.round(py/TS), sp=wlSpeciesAt(x,y,T.BUSH);
    if(sp){ wlPaintTile(c,'bush',x,y,px,py,g.time,sp,wlPicked(x,y)); return; }
    _drawBush(c,px,py);
  };
  const _drawRock=drawRock;
  drawRock=function(c,x,y,px,py){
    const sp=wlSpeciesAt(x,y,T.ROCK);
    if(sp){ wlPaintTile(c,'rock',x,y,px,py,g.time,sp,wlPicked(x,y)); return; }
    _drawRock(c,x,y,px,py);
  };
  const _drawStump=drawStump;
  drawStump=function(c,px,py){
    const x=Math.round(px/TS), y=Math.round(py/TS), sp=wlSpeciesAt(x,y,T.STUMP);
    if(sp){ wlPaintTile(c,'stump',x,y,px,py,g.time,sp,wlPicked(x,y)); return; }
    _drawStump(c,px,py);
  };
  const _drawMush=drawMush;
  drawMush=function(c,x,y,px,py,dk,time){
    if(!(dk>0.3)){
      const sp=wlSpeciesAt(x,y,T.MUSH);
      if(sp){ wlPaintTile(c,'mush',x,y,px,py,time,sp,wlPicked(x,y)); return; }
    }
    _drawMush(c,x,y,px,py,dk,time);
  };
}
function wlPickedMark(c,px,py){ c.fillStyle='rgba(30,30,20,0.16)'; c.fillRect(px+6,py+20,20,6); }

/* ---------- the explored map paints the right colours ---------- */
{
  const _mapColor=mapColor;
  mapColor=function(x,y){
    const b=wlBiomeAt(x,y);
    if(b&&b.style){
      const t=tileAt(x,y);
      if(t===T.TREE) return b.mapTree;
      if(t===T.WATER&&b.mapWater) return b.mapWater;
      if(t===T.BUSH) return b.mapGrass;
    }
    return _mapColor(x,y);
  };
}

/* ---------- names and weather ---------- */
{
  const _areaName=areaName;
  areaName=function(){
    const n=_areaName();
    if(g.scene!=='world') return n;
    if(n==='Forest'||n==='Meadow'){
      const tx=Math.floor(g.px/TS), ty=Math.floor((g.py-2)/TS), b=wlBiomeAt(tx,ty);
      if(b) return b.name;
    }
    return n;
  };
  const partFor=kind=>{
    if(g.scene!=='world') return kind;
    if(kind&&kind!=='fly') return kind;
    const b=wlBiomeAt(Math.floor(g.px/TS),Math.floor((g.py-2)/TS));
    if(b&&b.part&&(b.part!=='fly'||true)) return b.part;
    return kind;
  };
  const _up=updateParts, _dp=drawParts;
  updateParts=function(dt,kind,W,H){ _up(dt,partFor(kind),W,H); };
  drawParts=function(c,kind,kd){ _dp(c,partFor(kind),kd); };
}

/* ---------- first visits ---------- */
{
  let t0=0;
  const _storyUpdate2=storyUpdate;
  storyUpdate=function(dt){
    _storyUpdate2(dt);
    if(g.mode==='title'||g.scene!=='world') return;
    t0-=dt; if(t0>0) return; t0=0.6;
    const b=wlBiomeAt(Math.floor(g.px/TS),Math.floor((g.py-2)/TS));
    if(!b) return;
    const w=WD();
    if(!w.biomes[b.id]){
      w.biomes[b.id]=g.day;
      if(g.mode==='play'&&Object.keys(w.biomes).length>1) toast('New place: '+b.name,3200);
      else if(b.id!=='forest') toast('New place: '+b.name,3200);
    }
  };
}
