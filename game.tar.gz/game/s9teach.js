'use strict';
/* ===== TEACHING THE DEEP ART (v1.23) =====
   Red road: Mistress Vesper's Second Course, after the Academy. Verses are not taught to everyone. They are noticed.
   Crown road: you are banished. You keep whatever you learned before; you can be taught by the few who will still teach you, at a stricter measure;
   and you can be taken back in, if you have been the kind of duck the Hearth takes back in. */

const verseState=(v,strict)=>{
  if(ART().taught[v.n]) return 'learned';
  if(artChap()<v.gate) return 'later';
  if(!v.qual(!!strict)) return 'notyet';
  return 'ready';
};

const TEACH={
 Truthlight:{seen:'I have kept notes on you since the first night. In a hundred and four entries you said a hard thing plainly eleven times. I counted. Counting is what I am for.',
  pages:['Truthlight is not a lamp. A lamp shows everything and cares about nothing. Truthlight shows what is true, and cares who is looking.','Hold the true thing in the open wing. Say nothing. Let it be bright. If someone needs to see, they will; if they do not, it is not yours to make them.'],
  after:'"Go gently with it. You will be tempted to light a face. Do not light a face. Light the room."'},
 Softfall:{seen:'You are kind in a way that has cost you something, and you have not made it a policy. That is the right way round.',
  pages:['Softfall is not a spell for making people feel better. It is a spell for making the room safer to feel in.','You do not aim it. You let it fall. Whoever needs it finds it. Whoever does not stays dry, and nobody has been insulted.'],
  after:'"If a duck says no, put it away. That is not the verse failing. That is the verse."'},
 Standfast:{seen:'People lean on you. I have watched it from the Hearth steps. You do not announce it, and you do not complain. It is a rare combination, and it is wearing you thin.',
  pages:['A Standfast is a ring, not a wall. The difference is that a ring has an inside, and the inside is for whoever needs it.','Say the name of the thing that is hardest, and set your weight down beside it. The ring will hold the rest.'],
  after:'"It lasts as long as you remember who it is for."'},
 Lanternwalk:{seen:'You notice the small ones. The child at the edge of the room, the shy hand. It is not a talent. It is a habit, and it will take you where the road forgot to go.',
  pages:['A lantern does not know where it is going. It knows who is waiting.','Ask it, and be quiet. It will go ahead. When it stops, it has stopped for a reason, and the reason is usually a person.'],
  after:'"Do not follow it for the shortcut. Follow it for the company."'},
 Quietcoat:{seen:'You leave doors on the latch. I know the habit. I have had it sixty years. I will not call it a fault. I will call it a coat, and show you how to wear it without it wearing you.',
  pages:['The coat makes you uninteresting. It does not make you absent, and it does not make you false. There is a very old distinction between a door left on the latch and a door painted on a wall.','You may be quiet. You may not be false. If the coat begins to make you lie, take it off and sit in the cold until you remember who you are.'],
  after:'"Wear it for the weather. Not for the war."'},
 Remembrance:{seen:'You have carried names. I have watched you not put them down. I keep one ledger of what people say, and a second of what they carry, and you are in the second.',
  pages:['Remembrance will not remember for you what you have not done. It remembers back to you what you have, in your own words.','It is not kind and not unkind. It is only exact. Ask for what you want back, and be ready to want it.'],
  after:'"Do not use it to win an argument. It is not that sort of verse."'},
 Bloom:{seen:'The Hearth does not trust easily. It has trusted you with things that mattered. That is the whole of the prerequisite, and I wish it were more complicated.',
  pages:['Bloom is the oldest verse we have. It is also the one most abused, by well-meaning ducks who wanted to be thanked.','Ask the land. Ask the one who works it. Then bloom what they ask you to, and not one stem more.'],
  after:'"A garden is a conversation. Do not interrupt."'},
 Banner:{seen:'You have been right a great many times, and each time it has taken a little more of the room. I would rather you learned this from me than found it in the dark.',
  pages:['A Banner is the oldest temptation we have. It is gold, and lovely, and it works. Cast at a crowd, it makes them stand quiet and bow, and afterwards they will thank you, and it will not be them thanking you.','The Art does not take a will. That is the second law, and it is the only one with a corpse in it. Cast it at an empty hill. Cast it in a prayer. Never at a duck.'],
  after:'"I teach it so that you know what it is, and so that, when someone asks, you can say no and mean something by it."'}
};

/* ---------- a lesson ---------- */
function verseLesson(v,ctx,done){
  ctx=ctx||{}; done=done||(()=>{});
  const A=ART(), M=ctx.master||v.master, T=TEACH[v.n];
  if(A.breach>0){ atone(M,done); return; }
  if(A.last===g.day){ say(M,['One verse a day. The Art is not a feast. Come back tomorrow.'],done); return; }
  if(!ctx.fire&&g.clock>=19.5){ say(M,['It is too late in the day. Verses are taught by daylight.'],done); return; }
  const rite=()=>{
    say(M,['"Now. I will not ask you what it means. I will give you something to do with it."','(The room changes. Whatever has been conjured, it is not on any map.)'],()=>pracStart(v,ctx,learn,done));
  };
  const learn=()=>{
    A.taught[v.n]=1; A.last=g.day; coin(); fade(1.0); if(!ctx.fire) advanceClock(2);
    try{ spSetSel(v.n); }catch(e){}
    say(M,[T.after],()=>{ toast('A verse is yours: '+v.n+'. ('+LAWS[v.n==='Banner'?1:0]+')',5200); done(); });
  };
  seq([[M,(ctx.pre||[]).concat([T.seen])],[M,T.pages]],rite);
}

/* ---------- when the Art goes quiet ---------- */
function atone(M,done){
  const A=ART(), names=Object.keys(A.coerced), who=names[names.length-1]||'them';
  say(M,['(They look at you for a long moment. Then at the wing you cast with.)','"The Art went quiet in you. I felt it from across the town. A verse cast at a person who has not agreed is not a verse. It is a leash that happens to be pretty."','"I will not scold. A scolding is something that happens to people who want to be told they are bad. I am asking what you intend to do about it."'],()=>{
    choose(M,'What do you intend?',['Go to '+who+', tell them plainly what I did, and ask what they need.','Do something kind, unasked, and say nothing about why.','Nothing. It will pass.'],k=>{
      if(k===2){ say(M,['"It will not pass. But you are the one who decides how long it takes."'],()=>{ S4.note('lie',1); done(); }); return; }
      A.breach=0; A.mended++; A.hist.push('mended it');
      S4.note(k===0?'truth':'mercy',1); try{ s2led(k===0?'truth':'mercy',1); }catch(e){}
      say(M,[k===0?'"Plainly. Yes. That is the hard way, and the only one that holds. Go early, before you have a better story."':'"A kindness unasked. It will not undo it. It is a debt paid in the only coin that was ever any good."','(The Art settles back into you a little at a time, like a room warming.)'],()=>{ toast('You mended what you broke. The verses come back to full strength.',4200); done(); });
    },2);
  });
}

/* ---------- the Academy, after the twelve days ---------- */
const VESPER='Mistress Vesper';
function theoryScene(done){
  const A=ART(); A.seen.theory=1;
  seq([
    [VESPER,['On your first day you asked, or would have if you were a duck who asked, what the Elders hoped to learn by sending you to me for twelve days instead of twelve years.','I said I had a theory. I said I would not share it before you passed. You passed.']],
    [VESPER,['The Elders asked: is the Art a thing of the blood, or of the heart? It is a good question, and the wrong one.','It is neither. It is a thing of the pause. The half-second before you act, in which you ask, and are quiet, and listen for what the world says back.']],
    [VESPER,['Red ducklings learn the pause young, because we are a small people in a large cold place, and we have never been able to afford not listening. You learned it in twelve days, because you had been practising all your life: every time you were kind, or careful, or plain.','That is all the Academy has ever taught. The rest is warmth and wand-waving.']],
    [VESPER,['So. The Three Laws. Every red child knows them before they know their own name.','"Ask, then be quiet." "Harm nothing that cannot be mended." "Spend it for another."','The last is the hardest. The Art is not yours. It is lent. A spell cast only for yourself is a debt, and the Hearth keeps accounts.']]
  ],()=>{
    choose(VESPER,'Will you keep the Three Laws?',['I will keep them.','I will try. I think that is the honest word.','I will not promise what I cannot keep.'],k=>{
      A.oath=['keep','try','honest'][k]; S4.note(['trust','mercy','truth'][k],1);
      say(VESPER,[['"Say it again in a year and I will believe it." (She does not smile, and then, slightly, does.)','"Good. \'Try\' is the oldest word in the Art. The rest is decoration."','"Hm. Then you are already better at the second law than most of my graduates."'][k]],()=>{
        say(VESPER,['There is a Second Course. It is not twelve days. It is a verse here and a verse there, over a life, and they are not given. They are noticed.','Come when you have been the kind of duck a verse is shaped like, and I will find the right master. Or the right master will find you.','And Detective: the hat was a joke. The Laws were not.'],done);
      });
    },1);
  });
}
function secondCourse(){
  const A=ART(), strict=!artWelcome();
  const labels=ARTV.map(v=>{ const s=verseState(v,strict); return v.n+'   ['+({learned:'yours',ready:'ready to learn',later:'later on the road',notyet:'not yet'})[s]+']'; });
  pagedChoose('The Second Course','Which verse?',labels,i=>{
    const v=ARTV[i], s=verseState(v,strict);
    if(s==='learned') say(v.master,[v.blurb,'(Law: "'+LAWS[v.n==='Banner'?1:0]+'")']);
    else if(s==='later') say(VESPER,['Not yet. The road has to ask something of you first. That verse is for later.']);
    else if(s==='notyet') say(v.master,[v.hint]);
    else verseLesson(v,{master:v.master,pre:['(In the hall behind the Academy, '+v.master+' is waiting, as if they had been told.)']},()=>{});
  },6);
}
{
  const _st=schoolTalk;
  schoolTalk=function(){
    const sp=schoolProgress();
    if(sp.days<12||!artWelcome()) return _st();
    if(!ART().seen.theory){ theoryScene(()=>{}); return; }
    choose(VESPER,'You have graduated. What can I do for you?',['The Second Course','The Three Laws','What have I learned?','Leave'],k=>{
      if(k===0) secondCourse();
      else if(k===1) say(VESPER,['"Ask, then be quiet." "Harm nothing that cannot be mended." "Spend it for another."','Your oath, if I remember it right, was: '+({keep:'that you would keep them',try:'that you would try, which is the honest word',honest:'that you would not promise what you could not keep'}[ART().oath]||'not yet given')+'.'+(ART().breach>0?' And I think you know which of them has been troubling you.':'')]);
      else if(k===2) say(VESPER,SPELLS.slice(0,12).map(s=>s[0]+': '+s[1]).concat(verseKnown().map(n=>n+': '+VBY[n].blurb)));
    },3);
  };
}

/* ---------- by the fire: those who still teach you ---------- */
const FIRE_T=[
 {n:'Lanternwalk',who:'Hermit Mallow',arr:'(Mallow sets his lantern beside yours. For a while neither of you says anything, which is how you know it is serious.)',
  hard:'"I am not supposed to. I was a duckling when they cast me out, and I learned this one from my mother\'s hands. It is hardly theirs to forbid."',easy:'"Sit. I have been saving this one for a night like this."'},
 {n:'Softfall',who:'Thread-Mother Tansy',arr:'(Thread-Mother Tansy has come up the road with a ball of grey wool, and says she was passing. She was not passing.)',
  hard:'"The Hearth would call this theft. I call it thread. Both of us are right, and the thread does not care."',easy:'"Thread and petals, dear. It is the same craft. Hold out your wing."'},
 {n:'Remembrance',who:'Old Rue',arr:'(Old Rue has walked a long way, with a stick and an opinion. She sits down very carefully and looks at the fire as if it owed her something.)',
  hard:'"Nobody asked me whether the dead were allowed to teach. I have decided it is not a question for the living."',easy:'"The graves hum. I have thought a long time about how to say what they hum. This is the nearest I have come."'}
];
function firesideLesson(done){
  const acc=artAccess(), A=ART();
  if(acc==='none') return done();
  const strict=!artWelcome();
  if(A.breach>0){
    const m=FIRE_T[0];
    if(A.seen.fireAtone) return done();
    A.seen.fireAtone=1;
    say(m.who,[m.arr,'"Sit. Something has gone quiet in you, and I have been waiting to be asked."'],()=>atone(m.who,done));
    return;
  }
  const t=FIRE_T.find(f=>verseState(VBY[f.n],strict)==='ready'&&!A.seen['fd_'+f.n]);
  if(!t) return done();
  const v=VBY[t.n];
  say(t.who,[t.arr,strict?t.hard:t.easy],()=>{
    choose(t.who,'They are offering a verse: '+v.n+'.',['Yes. Teach me.','Not tonight.'],k=>{
      if(k===1){ A.seen['fd_'+t.n]=1; say(t.who,['"Of course. Verses keep. People, less so."'],done); return; }
      verseLesson(v,{master:t.who,fire:true},done);
    },1);
  });
}
{
  const _fin=S2.finish;
  S2.finish=function(id,msg){
    try{
      if(/^[bx]\d+$/.test(id)){
        const q=s2(); q.fl=q.fl||{};
        if(!q.fl[id]){ q.fl[id]=1; firesideLesson(()=>_fin(id,msg)); return; }
      }
    }catch(e){ console.error(e); }
    return _fin(id,msg);
  };
}

/* ---------- the Art in the story's scenes: the Crown road keeps what it learned ---------- */
const SCENEV=new Set(['Truthlight','Lanternwalk','Quietcoat','Standfast','Softfall']);
{
  const _sxc=sxCan;
  sxCan=function(sp){
    if(VBY[sp]) return SCENEV.has(sp)&&spKnown().indexOf(sp)>=0&&artAccess()!=='none';
    const st=g.story;
    if(!st.isRed&&artAccess()==='trained'&&sp!=='Emberlight'){ const was=st.isRed; st.isRed=true; try{ return _sxc(sp); } finally{ st.isRed=was; } }
    return _sxc(sp);
  };
  const _sxcast=sxCast;
  sxCast=function(sp){
    if(!VBY[sp]) return _sxcast(sp);
    const S=SX.S; if(!S) return;
    if(sp==='Truthlight'||sp==='Lanternwalk'){
      const t=S.def.seek?S.def.seek(S):null;
      if(t){ S.seekT=14; S.seekTo=t; S.lumen=Math.max(S.lumen||0,40); toast(sp+': the light finds the way.',2600); if(S.def.onSeek) S.def.onSeek(S); }
      else { S.lumen=Math.max(S.lumen||0,50); toast(sp+': a steady light. Nothing here is hiding.',2600); }
    } else if(sp==='Quietcoat'){ S.veil=Math.max(S.veil||0,90); toast('Quietcoat: you are grey, and quiet, and not a liar.',3000); }
    else if(sp==='Standfast'){ if(S.timer&&!S.stood){ S.stood=1; S.timer.t+=22; S.timer.max+=22; toast('Standfast: the ring holds. You have longer than you thought.',3000); } else toast('Standfast: the ring holds, and steadies you.',2400); S.speed=Math.max(S.speed||0,15); }
    else if(sp==='Softfall'){ S.veil=Math.max(S.veil||0,20); toast('Softfall: the room breathes out a little.',2600); }
  };
}

/* ---------- what the verses do for you, in the hard moments ---------- */
const artSecs=()=>{ const x=XS(), n=xAbs(); return (x.standUntil>n?25:0)+(x.truthUntil>n?8:0); };
{
  const _tm=sxTimer;
  sxTimer=function(S,secs,label,onEnd){ _tm(S,secs+artSecs(),label,onEnd); };
  const _tc=timedChoose;
  timedChoose=function(who,text,texts,cb,sec,defIdx){ return _tc(who,text,texts,cb,sec+Math.round(artSecs()/4),defIdx); };
  const _p=S2.persuade;
  S2.persuade=function(d){
    try{
      if(d&&!d.__soft&&XS().softUntil>xAbs()){
        d.__soft=1; d.need=Math.max(1,(d.need||1)-1);
        d.intro=(d.intro||[]).concat(['(Petals are still falling, very slowly, in the corner of the room. Nobody mentions them. Everyone is a little more willing to listen.)']);
      }
    }catch(e){ console.error(e); }
    return _p(d);
  };
}

/* ---------- Crown road: taken back in ---------- */
function readmitScore(){
  const h=S6.get('hearth'), p=P1(); let s=0;
  s+=h>=2?2:0; s+=h>=4?1:0; s+=S6.get('mallow')>=2?1:0;
  s+=p.told==='all'?-2:p.told==='soft'?1:0;
  s+=(S4.has('gentle')||S4.has('tender')||S4.has('candid'))?1:0;
  s+=p.purse==='left'?1:0;
  s-=ART().breach*2;
  return s;
}
const readmitWaiting=()=>{ const st=g.story; return !!(st.banished&&!ART().readmit&&g.story.s2&&s2route()==='crown'&&artChap()>=14&&artChap()<99); };
function readmitScene(){
  const st=g.story;
  seq([
    ['',['You walk to the gate you were cast out of. The red runes are still there, hand-high, humming. As you come within a duck\'s length of them, they stop.']],
    ['Elder Cinder',['(Cinder is on the wall, alone, with a lantern.) "I have been up here every night since the Hollow Door. I did not know what I was waiting for. I think it was this."','"The Elders met. It was not a vote I was proud of the first three times. The fourth time, it was."']],
    ['Warden Ruddock',['I voted no, you will remember. I said write it down.','Sorrel, write this down: I vote yes. Underline it. It is the first time in thirty years I have been glad to be wrong.']]
  ],()=>{
    choose('Elder Cinder','The runes are fading, one by one. What do you say at the gate?',['"I am sorry."','"Thank you for the door under the Hearth."','"I would like to learn."'],k=>{
      S4.note(['truth','kin','trust'][k],1);
      const r=[['"Yes," says Cinder. "You are. It is a good place to begin, and a bad place to stay."'],['"It was not mine to give," says Cinder. "It was only mine to leave unlocked. Come in."'],['"Then you are in the right town," says Cinder, and for the first time since you met her, smiles.']][k];
      say('Elder Cinder',r.concat(['The last rune goes out. Somewhere inside, a lantern is lit, and then another.']),()=>{
        st.banished=0; ART().readmit=1; tileCache.clear();
        toast('Emberwick is open to you again. Mistress Vesper will teach you what you did not finish.',6000);
        say('Hermit Mallow',['(He is on the other side of the gate, and has been all night.)','"I did not say anything. I thought you would want to do it yourself." (He is crying a little. He pretends it is the cold.)']);
      });
    },2);
  });
}
function readmitHint(){
  const A=ART(), p=P1(), why=[];
  if(A.breach>0) why.push('"The Art went quiet in you, and has not come back. The runes can feel it."');
  if(p.told==='all') why.push('"The king\'s men know where our gate is. I am not asking who told them. I am telling you the runes can count."');
  if(S6.get('hearth')<2) why.push('"You have spent yourself on the Crown\'s side of the ledger. The Hearth keeps one too, and it is not in the black."');
  if(!why.length) why.push('"The runes are not sure of you. They are very old, and very careful, and they have been wrong before. Come back with something they can read."');
  say('Elder Cinder',['(Cinder is on the wall. She does not come down.)'].concat(why.slice(0,2),['"I am not sending you away. I am telling you what the gate says. It has never been a liar. It has only been afraid."']));
}
{
  const _su=storyUpdate; const tick={t:0};
  storyUpdate=function(dt){
    _su(dt);
    try{
      if(g.mode!=='play'||g.scene!=='world'||!readmitWaiting()) return;
      tick.t+=dt; if(tick.t<1) return; tick.t=0;
      if(Math.hypot(g.px/TS-(RX0+36),g.py/TS-(RY0+RH))>=9) return;
      const A=ART(), ch=artChap();
      if(A.gate[ch]) return; A.gate[ch]=1;
      if(readmitScore()>=3) readmitScene(); else readmitHint();
    }catch(e){ console.error(e); }
  };
}
/* the news is carried to you, if the runes have begun to flicker */
echo('eReadmit',14,()=>readmitWaiting()&&readmitScore()>=3,'Elder Cinder',['(A note, folded very small, comes by a child you have never met. The handwriting is square and a little cross.)','"The runes on the gate have begun to flicker. I do not know what you did. Come to the gate. Do not bring the king."']);

/* ---------- the story asks you to use it as a weapon ---------- */
beat('c15r:1',{who:'Hearthwarden Pyre',fmt:'choice',
  pre:['The Lantern Road runs for half a mile past a stand of grey scrub where the Hands\' scouts have been seen. Poppy is walking behind you with a sandwich, pretending not to look at the scrub.','Pyre has come along, and has not said why. Now he stops, and looks at your wing, and then at the scrub.','"I know what you could do with the Art here, and so do you. A Banner would turn them round without a drop of blood, and without a word. It would also turn Poppy round, and every duck behind her, and it would be very easy to tell yourself afterwards that nobody was hurt."','"I am not telling you what to do. I am telling you that I would have, once, and that I have been trying to forget how good it felt."'],
  q:'The scrub is still. The sandwich is still. Pyre is waiting.',
  opts:[
   T6o('Walk it as we are, lanterns lit, and let them look.',{cap:{hearth:1},led:{trust:1},h:'steady',flag:'walk',mem:'walked a watched road with the lanterns lit and used no Art at all',say:['You walk. The lanterns swing. Somewhere in the scrub a scout stands up, very slowly, and does not do anything. He watches you pass. A child with a sandwich waves.','Pyre exhales, like a man putting a heavy thing down on a table. "Yes," he says. "That is the oldest verse. It has no spell."']}),
   T6o('Cast Standfast round the children, and nothing else.',{cap:{hearth:1,sleepers:1},led:{mercy:1},h:'gentle',flag:'ring',mem:'set a ring of runes round the children and left the scouts alone',say:['A ring of runes comes up round Poppy, round the lantern-bearers, round the sandwich. It does not extend one inch toward the scrub.','Nothing happens. That is the entire point. "A ring has an inside," Pyre murmurs, "and you have given it to the people who needed one."']}),
   T6o('Use the Art on them. Quickly. Nobody will be hurt.',{cap:{crown:1,hearth:-1},led:{pride:1},h:'proud',flag:'weapon',mem:'turned a watched road with the Art, and told yourself nobody was hurt',set:()=>{ const A=ART(); A.breach++; A.coerced['the road']=1; A.hist.push('used the Art on the Hands\' scouts'); },say:['The scrub goes very quiet. The scouts stand up, one at a time, with the faces of ducks who have been told to; they turn, and they walk away. Nobody is hurt.','Poppy has stopped chewing. Pyre does not look at you. "Nobody was hurt," he says, as if reading it from a card. "I said that, once, too."','(Something went out of the air, like a candle in a closed room.)']})]});
beat('c15c:1',{who:'Captain Halbeak',fmt:'choice',
  pre:['The watch-fires are laid, five of them, in a ring on the hill. You have a coal in a cup and a duty in a ledger. Captain Halbeak has not stopped looking at the coal.','"I will ask, and you will refuse, and then I will have asked. The fires are the only light on that hill. If they can warm, they can burn. A flank of scouts, in the dry grass, by the east ridge. Quick. Clean. It would end tonight."','"I am not a cruel man. I am a tired one. Do you know how long a long night is, when you are the one who has to decide who sleeps?"'],
  q:'The coal is warm in your wing. Halbeak is waiting, and does not look away.',
  opts:[
   T6o('Light the five fires to be seen, not to burn.',{cap:{crown:1,hearth:1},led:{truth:1},h:'candid',flag:'seen',mem:'lit five fires to be seen, not to burn',say:['You light them. The ring goes up, steady and gold, and from the east ridge a handful of scouts sees it, and counts, and goes to report that the hill is held and not hidden.','"That is not what I asked for," Halbeak says. He sounds, to his own surprise, relieved. "It is what I wanted."']}),
   T6o('Light them, and ward the line: nothing will cross that would be hurt by it.',{cap:{crown:1,hearth:0,sleepers:1},led:{mercy:1},h:'gentle',flag:'ward',mem:'lit five fires and warded the line against anything it would hurt',say:['You light them, and speak quietly to the coal. A line comes up between the fires, thin as a held breath. In the night, three scouts find it, stop, and sit down at a polite distance, looking embarrassed.','"They will be there in the morning," Halbeak says. "Alive. I had forgotten that was an option."']}),
   T6o('Burn the scouts\' flank. Quickly.',{cap:{crown:2,hearth:-1},led:{pride:1},h:'proud',flag:'burn',mem:'burned a flank of scouts to end a long night',set:()=>{ const A=ART(); A.breach++; A.coerced['the east ridge']=1; A.hist.push('burned the scouts\' flank'); },say:['The east ridge goes up in a line. It is quick, and clean, and over by the third bell. Nobody on the hill says anything for a long time.','Halbeak does not thank you. He takes his helmet off, and holds it, and looks at it. "That is not what a fire is for," he says, very quietly, and goes to see to his men.','(The coal is cold in its cup. It will light again. It will take a while.)']})]});

/* ---------- the journal ---------- */
function artJournal(sec,line){
  const A=ART(), known=verseKnown(), acc=artAccess();
  if(!known.length&&!A.oath&&acc==='none'&&!g.story.banished) return;
  if(!known.length&&!A.oath&&magicDays()<1&&!A.readmit) return;
  sec('The Deep Art');
  line('The Three Hearth-laws: ask, then be quiet. Harm nothing that cannot be mended. Spend it for another.','jdim');
  if(A.oath) line('You told Mistress Vesper '+({keep:'you would keep them.',try:'you would try, which is the honest word.',honest:'you would not promise what you could not keep.'}[A.oath]),'jdim');
  known.forEach(n=>line(n+'. '+VBY[n].blurb));
  const left=ARTV.filter(v=>!A.taught[v.n]).length;
  if(left) line('Verses not yet shown to you: '+left+'. They are not taught to everyone. They are noticed.','jdim');
  if(A.breach>0) line('The Art has gone quiet in you. You know why. Mend it with a teacher, or by a fire, and it will come back.');
  if(A.mended) line('You mended what you broke with the Art: '+A.mended+(A.mended>1?' times.':' time.'),'jdim');
  if(g.story.banished&&!A.readmit) line(magicDays()>0?'You are cast out of Emberwick, but you keep what you learned. A few will still teach you, at a stricter measure.':'You are cast out of Emberwick, and have learned nothing of the Art. It cannot be learned, now, unless the Hearth takes you back.','jdim');
  if(A.readmit) line('The runes on the gate went out for you. Emberwick has taken you back.','jdim');
}
{
  const _j=journalExtra;
  journalExtra=function(sec,line){ _j(sec,line); try{ artJournal(sec,line); }catch(e){ console.error(e); } };
}

/* ---------- the epilogue remembers what you did with it ---------- */
{
  const _ec=epiCard;
  epiCard=function(label,title,sub,pages,theme,cb){
    try{
      if(label==='EPILOGUE'&&Array.isArray(pages)){
        const A=ART(), n=verseKnown().length;
        if(A.oath||n>=2) pages=pages.concat(['In the Hollow, children now learn the Three Laws between the alphabet and the sums. Nobody can say who started it. Vesper says it was the Wood. The Wood says it was Vesper.']);
        if(A.breach>0) pages=pages.concat(['There is one verse you do not sing aloud. Vesper knows which. She has not asked, and she has left the door on the latch.']);
        else if(A.mended>0) pages=pages.concat(['You mended what you broke with the Art. It is in no book. Ruddock has added it to the ledger of things that cannot be taught.']);
        if(g.story.banished&&!A.readmit) pages=pages.concat(['The runes on Emberwick\'s gate went out the morning of the ending. Nobody will say who put them out. Ruddock says it was the wind. Ruddock is a poor liar.']);
        if(n>=5) pages=pages.concat(['You know '+n+' verses, which is more than most red ducks do in a lifetime. You have never once cast them for yourself alone, and that, Vesper says, is the only part of the Art that counts.']);
      }
    }catch(e){ console.error(e); }
    return _ec(label,title,sub,pages,theme,cb);
  };
}

/* ---------- red ducks watch you cast, and remember the laws ---------- */
const WIT_N={
 'Little Poppy':{Truthlight:'"Ooh. It found my sandwich. It found it before I did." (She considers.) "Is it allowed to find sandwiches?"',Softfall:'"It is SNOWING PETALS." Poppy is delighted past speech. Then, remembering something: "Did you ask the room first?"',Standfast:'Poppy steps inside the ring and sits down in the exact centre. "It is the safest place in the world," she explains, and does not move.',Lanternwalk:'"Can it carry me? No? Can it carry the sandwich?"',Quietcoat:'"You are all grey. You are a ghost. Are you a ghost? I will not tell."',Bloom:'Poppy picks a flower, gives it to you, then picks another one, and gives it to herself, which is fairer.'},
 'Warden Ruddock':{Truthlight:'"Hm." Ruddock does not look at the light. "A good verse. I would not use it on the Elders. They would find they had nothing to hide and I should have to find work."',Softfall:'Ruddock looks at the petals on his shoulder with the expression of a duck who has been given an unexpected present and is afraid to ask who from.',Standfast:'"A ring, not a wall," says Ruddock. It is as close as he comes to a compliment.',Lanternwalk:'"I had a lantern like that," says Ruddock, and nothing else.',Quietcoat:'"Coat." A pause. "Mine was darker. Yours is more honest."',Bloom:'Ruddock looks at the flowers. "That one is a weed," he says, with some feeling, and does not pull it.'},
 'Elder Cinder':{Truthlight:'"Oh, that is Sorrel\'s." Cinder\'s mouth twitches. "She will want to hear that you did it well."',Softfall:'"That one is Vesper\'s," says Cinder, softly. "She cried the first time anyone got it right. She told them it was hay fever."',Standfast:'Cinder steps into the ring and says nothing at all. After a moment she says, quietly, "Thank you."',Lanternwalk:'"The Hearth lit one like that, once." Cinder watches it go. "It is easier to follow than to light."',Quietcoat:'Cinder smiles. "Ruddock\'s verse. He will not admit it is his."',Bloom:'Cinder kneels in the flowers, which is not something Elders do, and stays there a long time.'},
 'Hearthwarden Pyre':{Truthlight:'"Careful. Truthlight shows the room. It does not tell you what to do about the room."',Softfall:'Pyre closes his eyes in the petals. "I have not stood in one of these since I was your age. I had forgotten they were allowed."',Standfast:'"A fine ring." Pyre steps in, uninvited, and stands very straight. "I used to do that on purpose. Now I just do it."',Lanternwalk:'"Follow it, but ask where it is going. Lanterns have been wrong."',Quietcoat:'"A coat is not a lie," says Pyre. "Keep that in your pocket. It is the whole of the thing."',Bloom:'Pyre says "very nice", and then, because he is Pyre, "mind the neighbour\'s turnips".'},
 'Archivist Sorrel':{Truthlight:'Sorrel writes something down. "Truthlight, third time cast, within the walls. I have underlined the third."',Remembrance:'Sorrel looks at you for a long moment. "Be careful. You are now an archive. Archives are lonely."'},
 'Mistress Vesper':{Softfall:'"There. Now you know why I cried." Vesper wipes a petal off her glasses. "Do not tell the students."',Lanternwalk:'"Good," says Vesper. "Now let it go further than you are comfortable with."'},
 'Hermit Mallow':{Truthlight:'"My mother would have liked that one," Mallow says. "She was a duck who could not abide a closed door."',Softfall:'Mallow holds out his wing, and a petal lands in it. "Flour," he says. "Her hands smelled of flour."',Standfast:'Mallow steps into the ring, and sits, and looks, for a moment, like a duckling.',Lanternwalk:'"Ah," Mallow says. "You learned it. You are better at it than I was. I never trusted the lantern. I should have."',Bloom:'Mallow lifts his face into the flowers. "I have not smelled a field in a hundred years," he says, and nothing else.'}
};
const WIT_ANY={Truthlight:'A passing red duck nods at the light, approving. "Candid. Good. We could use more of that."',Softfall:'A red duckling stops in the petals, mouth open, and a mother behind it says "Softfall" like a prayer.',Standfast:'A red duck passing by touches the edge of the ring with one wingtip, as one touches a doorframe, for luck.',Lanternwalk:'"Oh," says a red duck nearby, softly. "Someone is being looked for."',Quietcoat:'A red duck looks past you, politely, in a way that is itself a courtesy.',Bloom:'A red duck smiles at the flowers and says, to nobody, "The first law."'};
const WITT={t:0};
function verseWitness(n){
  if(n==='Banner'||!g.story||g.scene!=='world'||g.mode!=='play') return;
  if(WITT.t&&Date.now()-WITT.t<45000) return;
  const A=ART(), near=verseNear(120).sort((a,b)=>Math.hypot(a.x-g.px,a.y-g.py)-Math.hypot(b.x-g.px,b.y-g.py));
  for(const m of near){
    const nm=m.name||''; if(!nm) continue;
    const key='w_'+nm+'_'+n; if(A.seen[key]) continue;
    let line=(WIT_N[nm]||{})[n];
    if(!line&&!WIT_N[nm]&&typeof inRed==='function'&&inRed(Math.floor(m.x/TS),Math.floor((m.y-4)/TS))) line=WIT_ANY[n];
    if(!line) continue;
    A.seen[key]=1; WITT.t=Date.now();
    say(WIT_N[nm]?nm:nm,[line]); return;
  }
}
{
  const _sc=spellCast;
  spellCast=function(n){ const had=!!SPF.windup; const r=_sc(n); if(VBY[n]&&!had&&SPF.windup) setTimeout(()=>{ try{ verseWitness(n); }catch(e){ console.error(e); } },1500); return r; };
}

/* ---------- the Crown road sees the Art, and learns what it costs to be outside it ---------- */
beat('c8c:2',{who:'Hermit Mallow',fmt:'choice',
  pre:['Mallow has watched you do three small things, the lamp, the door, the well, and has not said a word about any of them. Now he opens his wing, and a small lantern of light stands in it, like a bird that has been taught to be patient.','It floats to your shoulder, considers you, and goes back. He closes his wing around it as if it were a thing that could be dropped.','"I was seven when they cast us out. I did not learn the Academy\'s verses. I learned what my mother could do with a ball of flour and a quiet room. It is not the same. It is not lesser. I am telling you so you know what you are looking at."'],
  q:'The lantern is back in his wing. He is not sure what you will ask.',
  opts:[
   T6o('"Can the Art be learned by someone like me?"',{led:{truth:1},h:'candid',flag:'asked',mem:'asked a red hermit whether the Art could be learned by an outcast',say:['"By a yellow duck, banished, with the king\'s purse in her pocket." He does not smile. "Not from me. I am not the Academy. But if the gate takes you back, the Academy will take you again."','"The runes do not read what you say. They read what you have been. Be the kind of duck the Hearth takes back, and they will fade. Be the other kind, and I will still sit with you. I will not be able to open the gate."','"And if you learned anything before they closed it, you keep it. The Art does not leave when the gate shuts. That is the one mercy in the design."']}),
   T6o('"What is it for?"',{led:{kin:1},h:'tender',flag:'for',mem:'asked a hermit what the Art was for',say:['"For asking, and then being quiet. For not harming what cannot be mended. For spending it on someone else."','"Three laws. Every red child knows them before their own name. I have kept them a hundred years, with nobody to keep them for. It is a strange thing to keep a law for the sake of keeping it." He looks at the fire. "I would do it again."']}),
   T6o('Say nothing. Watch the lantern.',{led:{trust:1},h:'steady',flag:'watch',mem:'sat beside a hermit and watched a small light, and asked for nothing',say:['The lantern comes out again, a little shyly. It goes round the fire, once, and settles on the top of the stone where the old camp-kettle sits, which immediately seems warmer.','Mallow says nothing. After a while, he says: "Thank you for not asking me for anything." It is the nicest thing he has said to you, and he says it to the fire.']})]});

/* ---------- the third law: spend it for another, at the Great Hearth ---------- */
const PETS={
 Truthlight:{who:'A child by the Bankers\' hall',pre:['A duckling is standing in the door of the Bankers\' hall with a snapped bell-rope in her wing. Three adults are looking at it. She has said, twice, that it was already broken. It was not.','You do not light her face. You light the room. The corners are quiet, and bright, and nobody is looking at anyone.','After a while she says, very small: "It was me. I pulled it to see if it would ring."'],
  end:'Nobody shouts. The Bankers\' hall, to everyone\'s embarrassment, finds the whole thing rather sweet. A new rope is bought. She is asked to hold the end of it, on Sundays.',led:{truth:1,mercy:1}},
 Softfall:{who:'A baker with a cold oven',pre:['The baker in the north lane has not said a word since his oven cracked on the first frost. Customers have started leaving things on the step: soup, a scarf, a very small cheese.','You stand across the lane. You ask, silently, and wait. He does not look up, but he does not shut the door.','The petals come down over the lane, slowly, over the step and the soup and the scarf and him.'],
  end:'He says nothing. In the morning there is bread on your step, slightly burnt, with a note: it is the first loaf from the borrowed oven. It is the best bread you have had.',led:{mercy:1,kin:1}},
 Standfast:{who:'A mother at the Banking',pre:['At six, in the Banking, a woman is standing very straight beside the ledgers, waiting for news of a son on the ward-stone watch. She has been standing for three hours. Nobody has asked her to sit.','You do not say anything. You cast the ring beside her, not round her, and leave the inside empty.','After a long time she steps in. She does not say anything either. She puts her weight down.'],
  end:'The news, when it comes, is good. She does not tell you. She walks past you the next day with a loaf under her wing, and puts it in yours, and keeps walking, very straight, and is weeping the whole way.',led:{trust:1,kin:1}},
 Lanternwalk:{who:'A lost duckling at dusk',pre:['It is nearly dark and a mother is calling the same name from three doorways. The lantern goes ahead of you, bobbing, uncertain, the way a good idea does.','It stops at the back of the granary, behind the empty barrels. It stops, and hovers, and goes dim, and then very bright.'],
  end:'The duckling is behind the barrels, asleep, with a stolen biscuit. The mother arrives, and sits down on the ground with her, and does not say a word for a quarter of an hour. The lantern goes out on its own, like a conscience satisfied.',led:{kin:1,mercy:1}},
 Quietcoat:{who:'A shy singer',pre:['A girl in the choir has a solo on Sunday and has not slept for four days. Every time she opens her beak, she sees everyone looking.','You do not tell her it will be fine. You cast the coat round her, a grey, ordinary, uninteresting coat, and she goes very still, and then, very slowly, forgets to be watched.','She sings. It is not perfect. It is hers.'],
  end:'Nobody in the hall is looking at her, in the sense that they are all looking at the ceiling, and each other, and their own hands, and the sound. It is the best any of them have ever heard. Afterwards she takes the coat off herself, and hangs it on the wall like a thing that has done its work.',led:{trust:1,mercy:1}},
 Remembrance:{who:'An old duck and a forgotten tune',pre:['Old Orr has lost a song. He sings the first two notes, and then the road in his head forks, and he sits down with his hands over his face.','You ask, and are quiet. The Art does not remember for him. It remembers back to him what he has already said to you, a verse at a time, in his own voice, from the afternoons you spent together.','A third note. A fourth. It is a lullaby.'],
  end:'He does not say he is grateful. He says, "It had four notes," as if the answer to a puzzle, and goes home with a hand on the wall. Somewhere in the lane, a window opens, and somebody begins to hum it, a little flat.',led:{truth:1,kin:1}},
 Bloom:{who:'A farmer and a dead field',pre:['A farmer at the east edge of the town has a field that went under in the first frost. It has been grey since autumn. He is standing at the gate with his hands in his pockets, not asking.','You could bloom it from the road, and he would find it in the morning, and be astonished, and perhaps not forgive you.'],
  ask:true,end:'',led:{kin:1}},
 Banner:{who:'The empty hill outside the wall',pre:['The hill outside the east wall is empty at dusk, and has been since the siege. The town goes up it, on the longest night, to light a lantern for the ones who did not come home. Nobody is up there yet.','You walk up alone. You stand at the top, in the wind, and cast it at the sky: the sigil, the gold, the whole dazzling arrogant thing, at nobody.'],
  end:'It stands over the hill for a long breath. In the town, windows open. Nobody comes up. They look, from their doorways, for the length of a held breath, and a lantern is lit in every one. Pyre, in the Hearth steps, says, to no one: "That is what it was for."',led:{kin:1,truth:1}}
};
function hearthPetition(n,done){
  const P=PETS[n], A=ART(); A.spent=A.spent||{};
  if(A.spent[n]){ say('',['You have already spent that verse here. The Hearth remembers it, and is satisfied. Come back when you have another.'],done); return; }
  const fin=(led,extra)=>{
    A.spent[n]=1; A.law3=(A.law3||0)+1; A.hist.push('spent '+n+' for '+P.who);
    for(const k in led){ try{ s2led(k,led[k]); }catch(e){} S4.note(k,led[k]); }
    advanceClock(1); coin(); fade(0.8);
    say('',[extra],()=>{ toast(n+' was spent for another. (The third law.)',4200); done(); });
  };
  if(P.ask){
    say('',P.pre,()=>{
      choose('The farmer\'s gate','What do you do?',['Walk down to the gate, and ask him which part he would like help with.','Bloom the whole field from the road, and leave before he sees.'],k=>{
        if(k===0) say('The farmer',['"Which part." He looks at the field, and then at you, and takes his hands out of his pockets. "The west corner. The rest I will do myself, when the ground lets me. I just need to know it is not dead."'],()=>{
          fin({kin:1,trust:1},'The west corner blooms. Not the rest. He will do the rest himself, over the spring, and be prouder of it than he would have been of the whole. The west corner, he says, is the best part, and he will not say why.');
        });
        else fin({pride:1,mercy:0},'In the morning the field is a blaze. He stands at the gate for an hour. He does not thank anyone. In the autumn, he lets it go fallow, and is not sure why.');
      },1);
    });
    return;
  }
  seq([['',P.pre]],()=>fin(P.led,P.end));
}
function hearthMenu(done){
  const A=ART(); A.spent=A.spent||{};
  const known=verseKnown();
  if(!known.length){ done(); return; }
  const labels=known.map(n=>n+(A.spent[n]?'   [spent]':'   ['+PETS[n].who+']'));
  pagedChoose('The Great Hearth','The Hearth is warm. A verse spent here goes to somebody who needs it. Which will you spend?',labels,i=>hearthPetition(known[i],()=>{}),6);
}
{
  const _hi=redHearthInteract;
  redHearthInteract=function(){
    const st=g.story;
    if(artWelcome()&&verseKnown().length){
      choose('The Great Hearth','The Hearth is warm, and has been for a hundred years.',['Spend a verse for someone who needs it','Warm your wings','Leave'],k=>{
        if(k===0) hearthMenu(()=>{});
        else if(k===1) _hi();
      },2);
      return;
    }
    return _hi();
  };
}
