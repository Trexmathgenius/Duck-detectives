'use strict';
/* ===== EMBERWICK: THE RED TOWN =====
   Once the hermit vouches for you, the Hollow Wood stops moving and the trees fall back from a real town: a palisade, a
   red castle, a church with its own faith, an archive, monuments, and shops you will not find anywhere else.
   It is a proper town to the rest of the game (shops, work, favors, notice board), with one difference: no deed, however
   kind, ever raises your standing here.
   This file: geography, tiles, art, shops, items, culture. The story beats live in chapter3.js. */

/* ---------- geography (the town box sits in the middle of the Hollow Wood grid) ---------- */
const RW=72, RH=56, RX0=WCX-RW/2, RY0=WCY-RH/2;
const RRX=Math.floor((WCX+24)/REG), RRY=Math.floor((WCY+24)/REG), RKEY=RRX+','+RRY;
let RED=null;
function inRed(x,y){ return x>=RX0&&x<RX0+RW&&y>=RY0&&y<RY0+RH; }
function redOutside(x,y){ return Math.max(RX0-x,0,x-(RX0+RW-1),RY0-y,0,y-(RY0+RH-1)); }
function redOpen(){ return !!(g.story&&g.story.redOpen); }
function onRedRegion(rx,ry){
  const a=Math.floor((RX0+24)/REG), b=Math.floor((RX0+RW-1+24)/REG), c=Math.floor((RY0+24)/REG), d=Math.floor((RY0+RH-1+24)/REG);
  return rx>=a&&rx<=b&&ry>=c&&ry<=d;
}

/* ---------- new tiles ---------- */
const RWALL=65, RPOST=66, RCSTONE=67, RCROOF=68, RCWIN=69, RCGATE=70, RBROOF=71, RBWALL=72, RBWIN=73, RBDOOR=74,
      RLANT=75, RHEARTH=76, RMON=77, RBANNER=78, RCOLD=79;
[RWALL,RPOST,RCSTONE,RCROOF,RCWIN,RCGATE,RBROOF,RBWALL,RBWIN,RBDOOR,RLANT,RHEARTH,RMON,RBANNER,RCOLD].forEach(c=>SOLID.add(c));
[RPOST,RCSTONE,RCWIN,RCGATE,RBWIN,RBDOOR,RLANT,RHEARTH,RMON,RBANNER,RCOLD,RWALL].forEach(c=>INTERACTIVE.add(c));
[RPOST,RLANT,RBANNER,RMON,RHEARTH,RCOLD].forEach(c=>KTALL.add(c));
Object.assign(MAPCOL,{65:'#6b3a2a',66:'#8a3a2a',67:'#9b4a3c',68:'#6d2328',69:'#d9a85a',70:'#3a1a14',71:'#8a2a2a',72:'#d9b8a0',73:'#d9a85a',74:'#3a1a14',75:'#ff6a3a',76:'#ff8a2a',77:'#c9a24a',78:'#c0392b',79:'#6b6f78'});

/* ---------- the town's own look ---------- */
const RED_STYLE={id:'ember',label:'a hidden town of red ducks',plaza:'ember',snow:false,
  grass:['#5d7a3a','#63833e','#587536'],blade:'#47622d',tuft:'#7f9d52',
  roofs:['#7a2a22','#9b3a2a','#6b3a2a','#8a4a2a','#a8432b'],walls:['#f0cfc0','#e8d9b5','#e2c4b0','#d9b8a0'],
  tree:{cols:['#8a3a22','#a8482a','#c9622e']},centers:['bonfire'],patterns:['band'],decor:{tree:0,flower:.05,hay:0,mush:0,crate:0,stall:0},part:'embers',
  pre:['Ember'],suf:['wick'],map:{plaza:'#8a4a3a',grass:'#5d7a3a'}};
const RED_PALS=[{body:'#c0392b',wing:'#962d22',bill:'#ff9d2e'},{body:'#d9503f',wing:'#a83a2d',bill:'#e6c441'},{body:'#b5322a',wing:'#8a2620',bill:'#ff9d2e'},{body:'#e0603f',wing:'#b24a30',bill:'#e6c441'},{body:'#a82a2a',wing:'#7f1f1f',bill:'#d9902a'}];

/* ---------- layout (all local to the town box: lx 0..71, ly 0..55) ---------- */
/* the shops: [kind, x, y] (6 wide, 4 tall, door at the bottom middle) */
const RSHOPS=[['rbake',20,39],['rcafe',27,39],['rcandle',41,39],['rloom',48,39],['rtoy',27,46],['rforge',41,46],['rherb',48,46]];
/* the three grand buildings: [type, x, y, w, h, doorCol] */
const RSPECIAL=[['church',4,17,12,7,6],['library',5,43,10,6,5],['school',11,4,9,7,4]];
/* castle blocks: [x0,x1,y0,y1,roofRows] */
const RCAS=[[29,42,2,13,3],[24,28,6,13,2],[43,47,6,13,2],[20,23,3,13,3],[48,51,3,13,3]];
const RHOUSEPOS=[];
for(const x of [4]) for(const y of [3,9]) RHOUSEPOS.push([x,y]);
for(const x of [53,61]) for(const y of [4,10,16,22,28,34,46]) RHOUSEPOS.push([x,y]);
RHOUSEPOS.push([20,46]);
/* monuments: 'lx,ly' -> kind */
const RMONS={};
RMONS['27,24']='march'; RMONS['44,24']='empty'; RMONS['30,17']='bell';
for(let i=6;i<=9;i++) RMONS[i+',28']='founders';
const RCOLDPOS=[[14,35],[13,38],[10,39],[7,38],[6,35],[7,32],[10,31],[13,32]];

function redBuildingTileCode(b,lx,ly){
  const col=lx-b.lx, row=ly-b.ly, roofRows=b.h-2;
  if(b.type==='church'||b.type==='library'||b.type==='school'){
    if(row<roofRows) return RBROOF;
    if(row===b.h-1&&col===b.doorCol) return RBDOOR;
    if(row===b.h-2&&col%3===1&&col!==b.doorCol) return RBWIN;
    return RBWALL;
  }
  if(row<2) return T.ROOF;
  if(row===3&&col===3) return b.enterable?T.DOOR:T.HOUSEDOOR;
  if(row===2&&(col===1||col===4)) return T.WINDOW;
  return T.WALL;
}
function redCastleCode(lx,ly){
  for(const r of RCAS){
    if(lx<r[0]||lx>r[1]||ly<r[2]||ly>r[3]) continue;
    const ry=ly-r[2], col=lx-r[0], keep=r===RCAS[0];
    if(ry<r[4]) return RCROOF;
    if(keep&&(lx===35||lx===36)&&ly>=12) return RCGATE;
    if(keep&&(ly===7||ly===10)&&col%3===1) return RCWIN;
    if(!keep&&r[1]-r[0]>=4&&ly===10&&(col===1||col===3)) return RCWIN;
    if(!keep&&r[1]-r[0]<4&&(ly===8||ly===11)&&col===1) return RCWIN;
    return RCSTONE;
  }
  return 0;
}
function redBuildingAtLocal(lx,ly){
  const t=RED||getRed();
  for(const b of t.all) if(lx>=b.lx&&lx<b.lx+b.w&&ly>=b.ly&&ly<b.ly+b.h) return b;
  return null;
}
/* paving */
function redCobble(lx,ly){
  if(lx>=34&&lx<=37&&ly>=14) return true;
  if(lx>=26&&lx<=45&&ly>=22&&ly<=37) return true;
  if(lx>=20&&lx<=51&&ly>=14&&ly<=21) return true;
  if(ly===38&&lx>=20&&lx<=51) return true;
  if(ly>=43&&ly<=45&&lx>=4&&lx<=52) return true;
  if(ly>=50&&ly<=51&&lx>=4&&lx<=52) return true;
  if(lx>=18&&lx<=19&&ly>=2&&ly<=54) return true;
  if(lx>=4&&lx<=17&&ly>=24&&ly<=27) return true;
  if(ly===49&&lx>=5&&lx<=17) return true;
  return false;
}
function redPath(lx,ly){
  for(const h of RHOUSEPOS){ if((ly===h[1]+4||ly===h[1]+5)&&lx>=h[0]-1&&lx<=h[0]+6) return true; }
  return false;
}
function redTreeOK(lx,ly){
  if(lx>=20&&lx<=25&&ly>=22&&ly<=37) return true;
  if(lx>=46&&lx<=51&&ly>=14&&ly<=37) return true;
  if(lx<=3||lx>=68) return true;
  if(ly>=52) return true;
  if(ly<=1) return true;
  if(lx>=52&&ly<=3) return true;
  return false;
}

function buildRed(){
  const t={rx:RRX,ry:RRY,key:RKEY,cx:RX0+36,cy:RY0+30,x0:RX0,y0:RY0,w:RW,h:RH,name:'Emberwick',style:RED_STYLE,layout:'R',pattern:'band',center:'bonfire',
    buildings:[],houses:[],specials:[],all:[],npcs:[],kids:[],priceSeed:0.5,fixed:new Map(),lamps:[],board:{x:RX0+39,y:RY0+25},sells:new Set(),spots:null,favCache:{},isRed:true};
  RED=t;   /* set early: tile lookups below need it */
  const SH={
    rbake:{n:'Cinder & Crust',roof:'#8a2a22',wall:'#f0cfc0',keeper:['Baker Ember',0,'wizard','bowtie']},
    rcafe:{n:'The Banked Fire',roof:'#6b3a2a',wall:'#e8d9b5',keeper:['Innkeeper Pepper',2,null,'scarf']},
    rcandle:{n:'Wick & Flint',roof:'#a8432b',wall:'#e2c4b0',keeper:['Chandler Wick',1,'wizard',null]},
    rloom:{n:'The Scarlet Loom',roof:'#9b2d4a',wall:'#f0cfc0',keeper:['Weaver Tansy',3,'bow',null]},
    rtoy:{n:'Ashwood Playthings',roof:'#8a4a2a',wall:'#d9b8a0',keeper:['Tinker Pip',4,'wizard',null]},
    rforge:{n:"The Tinker's Forge",roof:'#4a3a3a',wall:'#d9b8a0',keeper:['Smith Cobb',2,null,null]},
    rherb:{n:'Hearthleaf Remedies',roof:'#5a6b3a',wall:'#e8d9b5',keeper:['Herbalist Sage',1,'wizard',null]}
  };
  RSHOPS.forEach((s,i)=>{
    const d=SH[s[0]], x=RX0+s[1], y=RY0+s[2];
    SHOP_NAMES[s[0]]=[d.n,d.n,d.n];
    const b={kind:s[0],enterable:true,idx:t.buildings.length,x:x,y:y,w:6,h:4,lx:s[1],ly:s[2],name:d.n,roof:d.roof,wall:d.wall,doorX:x+3,doorY:y+3,snow:false,
      keeper:{name:d.keeper[0],pal:RED_PALS[d.keeper[1]],acc:{head:d.keeper[2],neck:d.keeper[3]}}};
    t.buildings.push(b); t.all.push(b);
    (STOCK[s[0]]||[]).forEach(id=>t.sells.add(id));
  });
  RHOUSEPOS.forEach((p,i)=>{
    const x=RX0+p[0], y=RY0+p[1];
    const b={kind:'house',enterable:false,idx:t.houses.length,x:x,y:y,w:6,h:4,lx:p[0],ly:p[1],name:'',roof:RED_STYLE.roofs[Math.floor(hash(p[0],p[1],7710)*RED_STYLE.roofs.length)],
      wall:RED_STYLE.walls[Math.floor(hash(p[0],p[1],7711)*RED_STYLE.walls.length)],doorX:x+3,doorY:y+3,snow:false};
    t.houses.push(b); t.all.push(b);
  });
  RSPECIAL.forEach(s=>{
    const nm=s[0]==='church'?'Hearth of the First Ember':s[0]==='school'?'Academy of the Ember Arts':'The Ashen Archive';
    const b={kind:'special',type:s[0],enterable:false,idx:t.specials.length,x:RX0+s[1],y:RY0+s[2],w:s[3],h:s[4],lx:s[1],ly:s[2],doorCol:s[5],name:nm,
      roof:s[0]==='church'?'#8a2a2a':s[0]==='school'?'#4a3a7a':'#5a3a4a',wall:s[0]==='church'?'#e8d3c0':s[0]==='school'?'#e0d4e8':'#d9c8b5',doorX:RX0+s[1]+s[5],doorY:RY0+s[2]+s[4]-1,snow:false};
    t.specials.push(b); t.all.push(b);
  });
  const castle={kind:'special',type:'castle',enterable:false,idx:t.specials.length,x:RX0+20,y:RY0+2,w:32,h:12,lx:20,ly:2,name:'Castle Cinderhold',roof:'#6d2328',wall:'#9b4a3c',doorX:RX0+35,doorY:RY0+13,snow:false,isCastle:true};
  t.specials.push(castle);   /* not in t.all: its tiles are drawn from redCastleCode */
  /* furniture */
  const fx=(lx,ly,code)=>t.fixed.set(lx+','+ly,code);
  for(const p of [[33,16],[38,16],[33,20],[38,20],[33,40],[38,40],[33,47],[38,47],[33,53],[38,53],[5,27],[16,27],[24,24],[47,24],[19,36],[19,12]]){ fx(p[0],p[1],RLANT); t.lamps.push({x:RX0+p[0],y:RY0+p[1]}); }
  for(const lx of [28,30,32,39,41,43]) fx(lx,35,T.STALL);
  fx(39,25,T.BOARD);
  for(const lx of [35,36]) for(const ly of [29,30]) fx(lx,ly,RHEARTH);
  for(const k in RMONS) { const a=k.split(','); fx(+a[0],+a[1],RMON); }
  RCOLDPOS.forEach(p=>fx(p[0],p[1],RCOLD));
  fx(31,15,RBANNER); fx(40,15,RBANNER);
  fx(33,15,T.FIRE); fx(38,15,T.FIRE);
  for(const p of [[28,31],[43,31],[22,28],[49,28],[47,16]]) fx(p[0],p[1],T.BENCH);
  return t;
}
function getRed(){ return RED||buildRed(); }

function redTile(x,y){
  const t=getRed();
  const lx=x-RX0, ly=y-RY0;
  if(lx===0||ly===0||lx===RW-1||ly===RH-1){
    if(ly===RH-1&&lx>=34&&lx<=37) return (g.story&&g.story.banished)?RWALL:T.COBBLE;
    if(ly===RH-1&&(lx===33||lx===38)) return RPOST;
    return RWALL;
  }
  const f=t.fixed.get(lx+','+ly); if(f!==undefined) return f;
  const cc=redCastleCode(lx,ly); if(cc) return cc;
  const b=redBuildingAtLocal(lx,ly); if(b) return redBuildingTileCode(b,lx,ly);
  if(redCobble(lx,ly)) return T.COBBLE;
  if(redPath(lx,ly)) return T.PATH;
  if(redTreeOK(lx,ly)&&hash(x,y,7720)<0.10) return T.TREE;
  const h=hash(x,y,7721);
  if(h<0.06) return T.FLOWER;
  return T.GRASS;
}
/* the Wood, once it has settled: dense forest, with the Ember Road down the middle of it */
const RRD_Y1=RY0+RH+8;
const UWX=310;   /* the Umbral Trail leaves the Ember Road here and climbs north out of the wood */      /* the road turns east along these two rows */
function openWoodTile(x,y){
  const gateX=RX0+36, yb=WY0+WSZ-1;
  const inA=(x===WX0+6||x===WX0+7)&&y<=yb&&y>=RRD_Y1;
  const inB=(y===RRD_Y1||y===RRD_Y1+1)&&x>=WX0+6&&x<=gateX;
  const inC=(x===gateX-1||x===gateX)&&y<=RRD_Y1+1&&y>=RY0+RH-1;
  const inE=(y===RRD_Y1||y===RRD_Y1+1)&&x>gateX&&x<=UWX+1;
  const inF=(x===UWX-1||x===UWX||x===UWX+1)&&y<=RRD_Y1+1&&y>=WY0;
  if(inA||inB||inC||inE||inF) return T.PATH;
  /* lanterns on the flanks */
  const nearA=(x===WX0+5||x===WX0+8)&&y<=yb&&y>=RRD_Y1-1&&(y%6===0);
  const nearB=(y===RRD_Y1-1||y===RRD_Y1+2)&&x>=WX0+6&&x<=gateX&&(x%6===0);
  const nearC=(x===gateX-2||x===gateX+1)&&y<=RRD_Y1&&y>=RY0+RH&&(y%6===0);
  if(nearA||nearB||nearC) return RLANT;
  /* a clear verge either side of the road */
  const dA=(x>=WX0+4&&x<=WX0+9&&y<=yb&&y>=RRD_Y1-2), dB=(y>=RRD_Y1-2&&y<=RRD_Y1+3&&x>=WX0+4&&x<=gateX+2), dC=(x>=gateX-3&&x<=gateX+2&&y<=RRD_Y1+2&&y>=RY0+RH-1);
  if(dA||dB||dC) return hash(x,y,7402)<0.08?T.FLOWER:T.GRASS;
  const h=hash(x,y,7400);
  if(h<0.56) return hash(x,y,7401)<0.1?T.ROCK:T.TREE;
  return hash(x,y,7403)<0.22?T.MUSH:T.GRASS;
}

/* ---------- hook the red town into the world ---------- */
{
  const _woodTile=woodTile;
  woodTile=function(x,y){
    if(g.story&&g.story.redOpen){
      if(inRed(x,y)) return redTile(x,y);
      const gx=x-WX0, gy=y-WY0;
      if(gx>=0&&gy>=0&&gx<WSZ&&gy<WSZ) return openWoodTile(x,y);
    }
    return _woodTile(x,y);
  };
  const _ch2Dark=ch2Dark;
  ch2Dark=function(x,y){
    if(g.story&&g.story.redOpen){
      const d=redOutside(x,y);
      if(d<=0) return 0;
      return _ch2Dark(x,y)*Math.min(1,d/10);
    }
    return _ch2Dark(x,y);
  };
  const _getTown=getTown;
  getTown=function(rx,ry){ if(g.story&&g.story.redOpen&&onRedRegion(rx,ry)) return getRed(); return _getTown(rx,ry); };
  const _townAtTile=townAtTile;
  townAtTile=function(x,y){ if(g.story&&g.story.redOpen&&inRed(x,y)) return getRed(); return _townAtTile(x,y); };
  const _nearTown=nearTown;
  nearTown=function(x,y,m){ if(g.story&&g.story.redOpen&&x>=RX0-m&&x<RX0+RW+m&&y>=RY0-m&&y<RY0+RH+m) return true; return _nearTown(x,y,m); };
  const _styleAt=styleAt;
  styleAt=function(x,y){ if(g.story&&g.story.redOpen&&x>=RX0-3&&x<RX0+RW+3&&y>=RY0-3&&y<RY0+RH+3&&(inWood(x,y))) return RED_STYLE; return _styleAt(x,y); };
  const _isPlaza=isPlaza;
  isPlaza=function(t,lx,ly){ if(t&&t.isRed) return redCobble(lx,ly); return _isPlaza(t,lx,ly); };
  const _townTile=townTile;
  townTile=function(t,x,y){ if(t&&t.isRed) return redTile(x,y); return _townTile(t,x,y); };
  const _townSpots=townSpots;
  townSpots=function(t){
    if(!(t&&t.isRed)) return _townSpots(t);
    if(t.spots) return t.spots;
    const a=[];
    for(let ly=2;ly<RH-2;ly++) for(let lx=2;lx<RW-2;lx++){
      const x=RX0+lx, y=RY0+ly, c=redTile(x,y);
      if((c===T.GRASS||c===T.FLOWER)&&!(Math.abs(lx-36)<=3&&Math.abs(ly-30)<=3)) a.push([x,y]);
    }
    t.spots=a; return a;
  };
  /* several of the game's loops walk a 3x3 block of regions; the box spans four, so de-duplicate the people */
  const _collectNpcs=collectNpcs;
  collectNpcs=function(){
    _collectNpcs();
    const seen=new Set(), out=[];
    for(const n of g.npcs){ if(seen.has(n)) continue; seen.add(n); out.push(n); }
    if(out.length!==g.npcs.length){ g.npcs.length=0; for(const n of out) g.npcs.push(n); }
  };
}
