'use strict';
/* ===== SAVE REPAIR =====
   If a save is caught half-way through something (an update mid-dialogue, a closed tab, an old build), the story step
   and the flags/items it depends on can disagree, and the hint at the bottom then points at something already done.
   healSave() compares them and nudges the story forward / hands back anything that was supposed to be given.
   It only ever moves things FORWARD or fills in something missing; it never undoes progress.
   It runs on its own every couple of seconds while you play. */
(function(){
const log=[];
const T=(f)=>{ try{ return !!f(); }catch(e){ return false; } };
const cnt=(ks)=>ks.filter(k=>s2fl(k)).length;
/* [chapter, step range, condition, step to move to, what it was] */
const STEP_RULES=[
  ['c5r',[3,3],()=>[0,1,2,3,4].every(j=>s2fl('lt'+j)),4,'all five lanterns lit'],
  ['c5r',[4,4],()=>typeof grievDone==='function'&&grievDone()>=3,5,'all three grievances heard'],
  ['c7r',[0,1],()=>s2fl('letterRead'),2,'Bree\'s letter read'],
  ['c13r',[1,1],()=>cnt(['e_sor','e_pyr','e_rud'])>=2,2,'council persuaded'],
  ['c13c',[1,1],()=>cnt(['c_gander','c_teal','c_plume'])>=2,2,'court persuaded'],
  ['c14r',[0,1],()=>typeof fireCount==='function'&&fireCount()>=5,2,'all five fires out'],
  ['c15c',[0,1],()=>typeof watchCount==='function'&&watchCount()>=5,2,'all five watch-fires lit']
];
/* [flag, item]: the flag says it was handed over; make sure the item really is in the pack */
const ITEM_RULES=[['key','breekey','c7r'],['letterRead','breeletter','c7r']];
function note(m){ log.push(m); try{ console.info('[save repair] '+m); }catch(e){} }
function healSave(loud){
  if(!g||!g.story||!g.story.s2||g.mode!=='play') return 0;
  const q=s2(); let n=0;
  if(!q.ch||q.ch==='end') return 0;
  if(!(q.step>=0)){ q.step=0; n++; note('bad step reset'); }
  const here=(typeof SX!=='undefined'&&SX.S)||g.scene!=='world';
  /* a chapter already marked done but still current: carry on to the next one */
  if(!here&&q.done[q.ch]&&T(()=>s2next(q.ch))){ const nx=s2next(q.ch); note(q.ch+' was done; moving to '+nx); S2.begin(nx,true); return 1; }
  /* a chapter that no longer exists in this build */
  if(!S2.ch[q.ch]&&!here){
    const last=Object.keys(q.done).filter(k=>S2.ch[k]).sort((a,b)=>s2num(b)-s2num(a))[0];
    const nx=last&&s2next(last); if(nx&&S2.ch[nx]){ note(q.ch+' is gone; moving to '+nx); S2.begin(nx,true); return 1; }
  }
  for(const [ch,rg,cond,to,why] of STEP_RULES){
    if(q.ch!==ch||q.step<rg[0]||q.step>rg[1]||q.step>=to) continue;
    if(T(cond)){ q.step=to; hudCache.obj=null; n++; note(ch+': '+why+', step '+to); }
  }
  for(const [fl,it,onlyIn] of ITEM_RULES){
    if(q.ch===onlyIn&&s2fl(fl)&&!(g.inv&&g.inv[it])&&typeof addItem==='function'&&!(q.healed&&q.healed[it])){ (q.healed||(q.healed={}))[it]=1; addItem(it); n++; note('gave back '+it); }
  }
  if(n&&loud!==false){ try{ toast('Your story was caught half-way; it has been put right.',3600); }catch(e){} }
  return n;
}
window.healSave=healSave; window.healLog=log;
setInterval(()=>{ try{ healSave(); }catch(e){} },2000);
})();
