'use strict';
/* ===== NEW LANDS (v1.18): the Ashlands, the Sealed North and the ruins of the first Emberwick =====
   Terrain is drawn with tiles the game already knows (ash, charred stumps, stones, graves, water, paths) so nothing here needs new art.
   THE ASHLANDS lie north of the kingdom, above the Burnt Wood, and hold the Ash Road:
     the Cinder Fields (east), Weeping Ridge (middle) and the Ashen Fen (west), with a river between the Ridge and the Fen.
   THE SEALED NORTH lies north of Emberwick, past the Hollow Wood. A cold road leads to the Sealing Stones and, beyond them, the
     ruins of the first camp of the exiles, the place Gordamom gathered them. The Elders sealed it after the siege. */

const SWR={
  ash:{x0:-90,x1:176,y0:-1300,y1:-1086},
  seal:{x0:110,x1:285,y0:-1450,y1:-1296}
};
const swIn=(r,x,y)=>x>=r.x0&&x<=r.x1&&y>=r.y0&&y<=r.y1;

/* the river that splits Weeping Ridge from the Ashen Fen */
const swRiverX=y=>Math.round(-26+6*Math.sin(y*0.045));
const SW_FERRY={x:swRiverX(-1165),y:-1165};
/* the Ash Road: a winding path from the kingdom's north edge, out through the Cinder Fields, across the Ridge, over the river and
   back down to the north rim of the Burnt Wood */
const SW_ROAD=[[58,-1087],[84,-1108],[112,-1128],[124,-1152],[108,-1178],[80,-1196],[52,-1206],[30,-1212],[6,-1200],[-14,-1182],[SW_FERRY.x+6,SW_FERRY.y],[SW_FERRY.x-6,SW_FERRY.y],[-44,-1146],[-34,-1118],[-8,-1098],[18,-1090],[30,-1089]];
/* the cold road north from Emberwick to the Sealing Stones and the ruins */
const SW_EXILE=[[266,-1247],[264,-1272],[258,-1296],[246,-1316],[232,-1336],[218,-1358],[204,-1376]];
const SW_STONES={x:232,y:-1334};
const SW_RUIN={x:200,y:-1384,w:34,h:22};
/* the waypoints the chapters use */
const SW_WP={
  mile:{x:122,y:-1146,name:'Cinder Mile-Stone'},
  ridge:{x:30,y:-1212,name:'Weeping Ridge overlook'},
  ferry:{x:SW_FERRY.x,y:SW_FERRY.y,name:'the Ashen Fen crossing'},
  rim:{x:30,y:-1089,name:'the north rim of the Burnt Wood'},
  seal:{x:SW_STONES.x,y:SW_STONES.y,name:'the Sealing Stones'},
  hall:{x:SW_RUIN.x,y:SW_RUIN.y,name:'the Hall of Names'}
};
function swSegDist(pts,x,y){
  let best=1e9;
  for(let i=0;i<pts.length-1;i++){
    const ax=pts[i][0], ay=pts[i][1], bx=pts[i+1][0], by=pts[i+1][1], dx=bx-ax, dy=by-ay;
    const L=dx*dx+dy*dy, t=L?Math.max(0,Math.min(1,((x-ax)*dx+(y-ay)*dy)/L)):0;
    const d=Math.hypot(x-(ax+t*dx),y-(ay+t*dy)); if(d<best) best=d;
  }
  return best;
}
const SW_NEAR=[];       /* spots kept clear of obstacles: [x,y,r] */
for(const k of ['mile','ridge','ferry','rim','seal','hall']) SW_NEAR.push([SW_WP[k].x,SW_WP[k].y,k==='hall'?9:5]);
function swClear(x,y){ for(const n of SW_NEAR) if(Math.hypot(x-n[0],y-n[1])<=n[2]) return true; return false; }
const swZoneOf=(x,y)=>{
  if(swIn(SWR.ash,x,y)){
    const bx=x+Math.round(7*vnoise(y*0.04,3,7001))-3;
    return bx<-5?'fen':bx<76?'ridge':'cinder';
  }
  if(swIn(SWR.seal,x,y)) return 'sealed';
  return '';
};

/* ---------------- terrain ---------------- */
function swTile(x,y){
  const z=swZoneOf(x,y); if(!z) return null;
  const road=z==='sealed'?swSegDist(SW_EXILE,x,y):swSegDist(SW_ROAD,x,y);
  if(z==='sealed') return swSealedTile(x,y,road);
  const rx=swRiverX(y);
  /* the Ward Wall: old standing stones along the kingdom's north edge */
  if(y===-1088&&x>=-10&&x<=76&&(x%8===0)&&swSegDist(SW_ROAD,x,y)>3) return KSTONES;
  /* the river, and the crossing */
  if(y<-1100&&Math.abs(x-rx)<=2){
    if(Math.abs(y-SW_FERRY.y)<=1) return swBridgeDone()?KBRIDGE:(Math.abs(x-rx)===2?KBRIDGE:T.WATER);
    return T.WATER;
  }
  if(y<-1100&&Math.abs(x-rx)<=4&&Math.abs(y-SW_FERRY.y)<=1) return KBRIDGE;     /* the stubs of the old bridge */
  if(road<=1.2) return T.PATH;
  if(road<=2.2&&hash(x,y,7010)<0.5) return T.PATH;
  const clear=swClear(x,y)||road<=3.2;
  const h=hash(x,y,7020), h2=hash(x,y,7021);
  if(z==='cinder'){
    const ash=vnoise(x*0.07,y*0.07,7030)>0.34;
    if(clear) return ash&&h<0.7?KASH:T.GRASS;
    if(hash(x,y,7022)<0.024) return KCHAR;
    if(h<0.014) return T.TREE;
    if(h<0.020) return T.FLOWER;
    if(h<0.028) return T.ROCK;
    if(h<0.034) return T.BUSH;
    if(h<0.0365) return T.MUSH;
    if(h<0.0385) return T.STUMP;
    if(h2<0.0016) return KRUIN;
    return ash?KASH:T.GRASS;
  }
  if(z==='ridge'){
    const wall=vnoise(x*0.085,y*0.085,7040);
    if(!clear&&wall>0.67) return T.ROCK;
    const ash=vnoise(x*0.08,y*0.08,7041)>0.52;
    if(clear) return ash?KASH:T.GRASS;
    if(h<0.05) return T.TREE;
    if(h<0.062) return T.ROCK;
    if(h<0.072) return T.STUMP;
    if(h<0.088) return T.BUSH;
    if(h<0.098) return T.MUSH;
    if(h<0.108) return T.FLOWER;
    if(hash(x,y,7023)<0.012) return KCHAR;
    return ash?KASH:T.GRASS;
  }
  /* the fen */
  const pool=fbm(x*0.07+40,y*0.07-20,7050);
  if(!clear&&pool>0.64) return T.WATER;
  if(clear) return hash(x,y,7024)<0.2?KASH:T.GRASS;
  if(h<0.035) return T.TREE;
  if(h<0.145) return T.BUSH;
  if(h<0.18) return T.MUSH;
  if(h<0.19) return T.FLOWER;
  if(h<0.196) return T.STUMP;
  if(h<0.2) return T.ROCK;
  return hash(x,y,7025)<0.16?KASH:T.GRASS;
}
function swSealedTile(x,y,road){
  const R=SW_RUIN, cx=R.x, cy=R.y, lx=x-cx, ly=y-cy;
  /* the Sealing Stones: a ring around a crystal */
  const sd=Math.hypot(x-SW_STONES.x,y-SW_STONES.y);
  if(sd<0.5) return KCRYSTAL;
  if(Math.abs(sd-6)<0.6){
    const a=Math.atan2(y-SW_STONES.y,x-SW_STONES.x), f=((a/(Math.PI/4))%1+1)%1;
    if(f<0.2||f>0.8){ if(!(Math.abs(x-SW_STONES.x)<=1&&y>SW_STONES.y)) return KSTONES; }     /* leave a gap to the south, where the road comes in */
  }
  if(sd<5) return hash(x,y,7060)<0.08?KASH:T.GRASS;
  /* the first camp: a ring of fallen walls, tents and the Hall of Names */
  if(Math.abs(lx)<=R.w/2+1&&Math.abs(ly)<=R.h/2+1){
    const edge=Math.abs(lx)>=R.w/2-1||Math.abs(ly)>=R.h/2-1;
    const gate=(ly>0&&Math.abs(lx)<=2)||(lx<0&&Math.abs(ly)<=1);
    if(edge&&!gate&&hash(x,y,7061)<0.72) return KRUIN;
    if(lx===0&&ly===0) return KCHAR;
    if(Math.abs(lx)<=1&&Math.abs(ly)<=1) return KASH;
    if(ly===-5&&Math.abs(lx)<=9&&lx%2===0) return KGRAVE;
    if(ly===-6&&Math.abs(lx)<=9&&lx%2!==0) return KSTONES;
    if(Math.abs(Math.abs(lx)-9)<=1&&Math.abs(ly-4)<=1&&hash(x,y,7062)<0.9) return KTENT;
    if(Math.abs(Math.abs(lx)-5)<=1&&Math.abs(ly-6)<=1&&hash(x,y,7063)<0.7) return KRUIN;
    if(road<=1.5) return T.PATH;
    if(hash(x,y,7064)<0.05) return KCHAR;
    return hash(x,y,7065)<0.3?KASH:T.GRASS;
  }
  if(road<=1.2) return T.PATH;
  if(road<=2.2&&hash(x,y,7066)<0.5) return T.PATH;
  const clear=road<=3.2||swClear(x,y);
  const h=hash(x,y,7067), pond=fbm(x*0.05+7,y*0.05+11,7068);
  if(!clear&&pond>0.68) return T.WATER;
  if(clear) return T.GRASS;
  if(h<0.11) return T.TREE;
  if(h<0.125) return T.ROCK;
  if(h<0.133) return T.STUMP;
  if(h<0.15) return T.BUSH;
  if(h<0.158) return T.MUSH;
  if(h<0.168) return T.FLOWER;
  return T.GRASS;
}
function swBridgeDone(){ const q=g.story&&g.story.s2; return !!(q&&q.fl&&q.fl.fenBridge); }

/* ---------------- hooks: tiles, towns, names, weather ---------------- */
{
  const _kt=kingdomTile;
  kingdomTile=function(x,y){ const t=swTile(x,y); if(t!==null) return t; return _kt(x,y); };
  const _bt=kingdomBlocksTown;
  kingdomBlocksTown=function(rx,ry){
    const cx=rx*REG, cy=ry*REG;
    for(const r of [SWR.ash,SWR.seal]) if(cx>=r.x0-50&&cx<=r.x1+50&&cy>=r.y0-50&&cy<=r.y1+50) return true;
    return _bt(rx,ry);
  };
  const _ka=kingdomArea;
  kingdomArea=function(tx,ty){
    const z=swZoneOf(tx,ty);
    if(z){
      if(z==='sealed'){
        if(Math.abs(tx-SW_RUIN.x)<=SW_RUIN.w/2+3&&Math.abs(ty-SW_RUIN.y)<=SW_RUIN.h/2+3) return 'Gordamom\'s Hold (ruins)';
        if(Math.hypot(tx-SW_STONES.x,ty-SW_STONES.y)<=9) return 'The Sealing Stones';
        if(swSegDist(SW_EXILE,tx,ty)<=3) return 'The Exile Road';
        return 'The Sealed North';
      }
      if(swSegDist(SW_ROAD,tx,ty)<=1.5) return 'The Ash Road';
      return z==='cinder'?'The Cinder Fields':z==='ridge'?'Weeping Ridge':'The Ashen Fen';
    }
    return _ka(tx,ty);
  };
}

/* a drifting ash-haze over the new lands, so they feel different from the green world around them */
const SW_HAZE={cinder:[96,84,78,0.13],ridge:[120,132,150,0.12],fen:[80,104,92,0.15],sealed:[196,216,248,0.09]};
{
  const _dw=drawWorld;
  drawWorld=function(c,W,H,kd2,camX,camY,time){
    _dw(c,W,H,kd2,camX,camY,time);
    if(g.scene!=='world') return;
    const p=s2tile(), z=swZoneOf(p.x,p.y); if(!z) return;
    const h=SW_HAZE[z]; if(!h) return;
    c.setTransform(1,0,0,1,0,0);
    const pulse=0.75+0.25*Math.sin(time*0.6);
    c.fillStyle='rgba('+h[0]+','+h[1]+','+h[2]+','+(h[3]*pulse).toFixed(3)+')'; c.fillRect(0,0,W,H);
  };
}
/* the map: label the new lands */
{
  const _dm=drawMap;
  drawMap=function(){
    _dm();
    const c=mctx, z=m.z, tx0=m.cx-mapW/2/z, ty0=m.cy-mapH/2/z;
    c.setTransform(dpr,0,0,dpr,0,0);
    const mk=(x,y,t,col)=>{
      const sx=(x-tx0)*z, sy=(y-ty0)*z; if(sx<-60||sy<-20||sx>mapW+60||sy>mapH+20||z<0.28) return;
      c.font='600 12px ui-monospace,"Courier New",monospace'; c.textAlign='center'; c.textBaseline='middle'; c.lineWidth=3; c.strokeStyle='#0d1613'; c.strokeText(t,sx,sy); c.fillStyle=col; c.fillText(t,sx,sy);
    };
    if(g.story&&g.story.s2&&g.story.s2.ch){
      mk(100,-1190,'The Ashlands','#d8cfc4'); mk(200,-1384,'Gordamom\'s Hold','#cfe0ff'); mk(232,-1334,'Sealing Stones','#cfe0ff');
    }
  };
}
