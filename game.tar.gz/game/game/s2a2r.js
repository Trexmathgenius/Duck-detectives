'use strict';
/* ===== ACT II, RED PATH: TAKING A SIDE ===== chapters 5 to 8 ===== */

function redNpc(name){ const t=getRed(); return t&&t.npcs.find(n=>n.name===name); }
function redStanding(){ return (g.rep[RKEY]||0); }
function s2kit(){
  for(const id of ['emberwand','lumenorb','gustcharm','wardcharm','runestone','seekerbeetle']) if(!g.inv[id]) addItem(id);
  if(!g.inv.grimoire) addItem('grimoire');
  const st=g.story; st.school=st.school||{}; if((st.school.days||0)<12) st.school.days=12;
}
/* new items */
ITEMS.keeperlantern={name:'Keeper\'s Lantern',desc:'The lantern the First Hearth was lit from. Its flame leans, steadily, toward the north-west. Away from home.',use:'note',note:'The flame leans toward the Burnt Wood. When you walk that way, it brightens.',nogift:true};
ITEMS.breeletter={name:'Bree\'s Letter',desc:'A letter written a century ago, to a boy of seven. The ash has not touched a word of it.',use:'note',note:'"If you come home, light this, and know that I did not stop."',nogift:true};
Object.assign(RICON,{
  keeperlantern:(R,C,E)=>{ R(7,2,2,2,'#555'); R(4,4,8,10,'#3a2a1a'); R(5,5,6,8,'#ffd166'); C(8,9,5,'rgba(255,200,100,0.35)'); R(9,6,2,3,'#fff3c4'); },
  breeletter:(R,C,E)=>{ R(3,4,10,8,'#f2e6c4'); R(3,4,10,2,'#d9c9a0'); R(5,8,6,1,'#8a6a3a'); R(5,10,4,1,'#8a6a3a'); R(7,6,2,2,'#c0392b'); }
});
PGLYPH.bell=(c,x,y,col,t)=>{ rect(c,x+4,y+2,24,3,'#5a3a22'); rect(c,x+8,y+2,2,8,'#5a3a22'); rect(c,x+22,y+2,2,8,'#5a3a22'); c.fillStyle='#c9a24a'; c.beginPath(); c.moveTo(x+11,y+10); c.quadraticCurveTo(x+10,y+22,x+7,y+26); c.lineTo(x+25,y+26); c.quadraticCurveTo(x+22,y+22,x+21,y+10); c.fill(); rect(c,x+13,y+12,2,10,'rgba(255,255,255,0.3)'); rect(c,x+6,y+25,20,2,'#8a6a2a'); };
PGLYPH.tlamp=(c,x,y,col,t)=>{ const on=col==='on'; rect(c,x+15,y+8,2,20,'#4a4a50'); rect(c,x+10,y+3,12,10,on?'#ff9d2e':'#5a3a30'); if(on){ rect(c,x+12,y+5,8,6,'#ffe9a8'); circ(c,x+16,y+8,24,'rgba(255,170,80,0.16)'); } };

/* =========================================================
   CHAPTER 5 (RED): STANDING
   ========================================================= */
const LANTERNS=[[18,22],[52,24],[44,44],[22,42],[38,34]];
S2.h.c5r_lant=function(){
  if(!s2at('c5r')) return;
  const q=s2(); for(let i=0;i<5;i++) delete q.fl['lt'+i];
  hudCache.obj=null;
  say('Warden Ruddock',['Dark. Half of them are dark.','You were slow. I have relit them myself, which I do not enjoy, and which I will not forget.','If you still want the proof, speak to me again.'],()=>{ if(s2at('c5r')) s2set(2); });
};
const GRIEF=[
  {n:'Old Garnet',flag:'gar',q:'Old Garnet will not look at you. "You wear our colour. Do you know what it cost to keep?"',o:[
    {t:'"No. Please tell me."',p:2,led:{truth:1},say:['She looks at you for a long moment.','"My husband carried the old on his back for eight nights, and set down a pack, and a promise. I carry both. Come sit, small one. Come sit."']},
    {t:'"I read the Wall. Forty-one families."',p:1,say:['"Reading is not carrying."','But she moves over on the bench, one hand\'s width.']},
    {t:'"It is only a colour, Garnet."',p:0,led:{pride:1},say:['"Only a colour." She turns her face to the wall.','"Go away, apprentice. Come back when you are sorry."']}]},
  {n:'Widow Ash',flag:'ash',q:'Widow Ash stands in her doorway with her arms folded. "Your king\'s Council cut my husband\'s name from every stone in the kingdom. Why should I speak to a yellow duck?"',o:[
    {t:'"I am sorry. It was not me. It was one of us, and I am sorry."',p:2,led:{truth:1},say:['Her arms come down, slowly.','"Hm. You said \'us\'. A century, and the first yellow to say \'us\'."']},
    {t:'"Then let me help you carve it back."',p:2,led:{mercy:1},say:['"...Tomorrow. At the Wall. Bring a chisel. Bring a long patience."']},
    {t:'"I was not hatched then."',p:0,led:{pride:1},say:['"No. You are quite new. It shows."','She shuts the door. Not hard.']}]},
  {n:'Gossip Marrow',flag:'mar',q:'Gossip Marrow circles you like a kestrel. "What does the yellow one really want? Spying for the king? Come now. I will know."',o:[
    {t:'"I want to belong somewhere."',p:1,say:['"Everyone wants that, dear. Few say it aloud."','"Hm. I shall tell them you said it. They will not believe me."']},
    {t:'"Honestly? I do not know yet."',p:2,led:{truth:1},say:['Marrow blinks. For once, she has nothing ready.','"...I shall tell them you said that. That one, they might believe."']},
    {t:'"I am nobody\'s spy. Ask the hermit."',p:1,say:['"Mallow vouches for you. Mallow vouches for the weather."','"But I will take it. I will take it as a start."']}]}
];
function grievDone(){ return GRIEF.filter(x=>s2fl('g_'+x.flag)).length; }
S2.ch.c5r={route:'red',title:'Standing',sub:'In Emberwick, your deeds count. Prove it.',
  intro:['The Potion does not wash off. You have checked.','In the kingdom, your name is gone. In Emberwick, for the first time, it is yours to earn. The red ducks have been told they may begin to believe you. They have not been told they must.','Three proofs. The Warden will set them. He will not be kind about it.'],
  recap:'Three proofs: the bell, the lanterns, the grievances. Ruddock admitted the Hearth is failing.',
  start(){
    s2kit();
    seq([
      ['Elder Cinder',['Stand straight, Apprentice. You are not a guest now. That is no kindness. Guests are forgiven everything.','The Art taught you a door. The town will teach you a house. Warden Ruddock will set you three proofs. Do them well. Do them quietly. Nobody will thank you, and everybody will notice.']],
      [H3,['A satchel from the Elders. A wand, an orb, a feather, a knot, a stone, a beetle. You know what each is for. Remember how they were taught: asked, never commanded.','I am so proud of you I cannot say it. So I shall say it very badly: you look like you belong.']],
      ['',['Your standing in Emberwick begins at nothing. Every proof and every kindness will raise it. Reputation in the kingdom is gone. Here, it counts.']]
    ],()=>s2set(0));
  },
  obj(s){
    return ['Report to <b>Warden Ruddock</b> at the south gate of Emberwick. He will set you three proofs.',
      'Proof one: ring the <b>Dawn Bell</b> (in the square) at first light.',
      'Report to <b>Warden Ruddock</b> again. He has the second proof.',
      'Proof two: light all <b>five lanterns</b> of Emberwick with Kindle before the time runs out ('+[0,1,2,3,4].filter(i=>s2fl('lt'+i)).length+'/5). Press C near a lantern, or face it and press Z.',
      'Proof three: hear the town\'s grievances. Talk to <b>Old Garnet</b>, <b>Widow Ash</b> and <b>Gossip Marrow</b> ('+grievDone()+'/3 heard).',
      'Return to <b>Warden Ruddock</b>. The three proofs are done.'][s];
  },
  journal(line){ line('Standing in Emberwick: '+redStanding()+' ('+RANKS[rankOf(redStanding())].n+').','jdim'); },
  mark(n){
    const s=s2step();
    if(n.name==='Warden Ruddock'&&(s===0||s===2||s===5)) return {ch:'!',col:'#ffd166'};
    const gx=GRIEF.find(x=>x.n===n.name); if(gx&&s===4&&!s2fl('g_'+gx.flag)) return {ch:'!',col:'#ffd166'};
    return null;
  },
  talk(n,done){
    const s=s2step(), R='Warden Ruddock';
    if(n.name===R){
      if(s===0){
        seq([[R,['So. Red now. It suits you about as well as a borrowed hat. Do not take that as an insult. I wear one too.','Three proofs. I do not care whether you are clever. I care whether you turn up, and whether you do the dull thing well.','First: the Dawn Bell. Every hearth in Emberwick is Kindled by its note, and every morning it is rung by someone who did not want to get up. Be that someone. Ring it at first light.']]],()=>{ s2set(1); done(); });
      } else if(s===1) say(R,['The bell, apprentice. First light. Not noon. Not "later".'],done);
      else if(s===2){
        seq([[R,['Hm. The bell rang. A hundred people noticed, and four said so. That is a good morning.','Second proof. Five lanterns hang in Emberwick: east, west, north, south, and the middle. Light each with the Wand. Kindle is a question, not a command.','Four hours. If you fail, I relight them myself, and I will say nothing, and you will feel it for a week.']]],()=>{ S2.deadline('lant',4,'Lanterns','c5r_lant'); s2set(3); done(); });
      } else if(s===3) say(R,['Lanterns, apprentice. Four hours. The clock is not interested in your feelings.'],done);
      else if(s===4) say(R,['Garnet, Ash, Marrow. Hear them. Do not defend yourself. Defending is for ducks with nothing to learn.'],done);
      else if(s===5){
        const hl=grievDone();
        seq([[R,['Three proofs. The bell, the lanterns, and the grievances. Garnet says you listened. Ash says you were sorry. Marrow says you were honest, which she did not expect and has not forgiven.','I voted no. I have not changed my vote. But I will say this once, and not again: you did the dull things well.']],
          [R,['Now. Come here. Closer. I have a thing to tell you and I would rather not have it heard by the lanterns.','The Hearth is dimming. Not much. A flicker, at dusk, three nights now. Every flame in Emberwick leans, just a little, to the north-west. I have told no one. The Elders would ask me what I did wrong.']]],()=>{
          choose(R,'What do you say?',['"I will keep it between us."','"The Elders must be told. Today."','"Do you think it is the ward?"'],k=>{
            if(k===0){ led_('trust',1); s2fl('ruddockSecret',1); say(R,['Good. That is all I wanted. Somebody I did not have to explain things to.'],fin); }
            else if(k===1){ led_('truth',1); s2fl('ruddockSecret',0); say(R,['...Yes. Yes, you are right. I am a coward who dresses as a wall.','Come. Cinder will want to hear it from the one who found it. That is you, now.'],fin); }
            else { led_('truth',1); s2fl('ruddockSecret',1); say(R,['What ward? The king\'s? What do you know of that?','...Never mind. Not now. But you are not stupid. I shall remember that.'],fin); }
          },2);
          function fin(){ addRep(getRed(),4); S2.finish('c5r'); done(); }
        });
      }
      return true;
    }
    const gx=GRIEF.find(x=>x.n===n.name);
    if(gx&&s===4){
      if(s2fl('g_'+gx.flag)){ say(n.name,['We have spoken. It is enough for today.'],done); return true; }
      S2.persuade({who:n.name,intro:[gx.q],rounds:[{q:'What do you say?',opts:gx.o}],need:1,
        win:()=>{ s2fl('g_'+gx.flag,1); addRep(getRed(),3); coin(); if(grievDone()>=3){ toast('All three heard. Return to Warden Ruddock.',4000); s2set(5); } done(); },
        lose:()=>{ say('',['That did not go well. You could try again, once she has had time to cool.'],done); }});
      return true;
    }
    return false;
  }
};
function led_(k,n){ return s2led(k,n); }
/* the Dawn Bell */
S2.prop({id:'dawnbell',red:[30,27],glyph:'bell',when:()=>!!(g.story&&g.story.redOpen),mark:()=>s2at('c5r',1)?'!':false,use(){
  if(!s2at('c5r',1)){ say('',['The Dawn Bell, in its frame at the head of the square. Warden Ruddock rings it once a day, at first light, to Kindle every hearth in Emberwick at once. A strip of red cloth is tied round the clapper at all other hours.']); return; }
  const ring=()=>{
    seq([['',['You take the rope in both wings. It is heavier than it looks, and warmer, as if the bell has been waiting.','You pull. A single note rolls out over Emberwick, round and low. Chimneys answer it one after another, each lighting itself as the sound passes. A hundred small flames, all at once.']],
      ['',['Doors open. Ducks come out into the cold blue light. Nobody looks at you. Several of them nod, not at you, at the bell, which is the same thing.']]],()=>{ addRep(getRed(),5); toast('Proof one: the Dawn Bell.',3200); s2set(2); });
  };
  if(g.clock>=5&&g.clock<8) ring();
  else choose('The Dawn Bell','It is not first light. The bell is for the dawn.',['Wait until first light','Come back later'],k=>{ if(k===0){ fade(1.2); advanceClock(((5.3-g.clock)+24)%24); setTimeout(ring,300); } },1);
}});
LANTERNS.forEach((p,i)=>S2.prop({id:'lamp'+i,red:p,glyph:'tlamp',colf:()=>s2fl('lt'+i)?'on':null,when:()=>s2at('c5r',3),mark:()=>s2fl('lt'+i)?null:'!',
  use(d){
    if(s2fl('lt'+i)){ say('',['Lit. It burns steadily, and a little smugly.']); return; }
    say('Lantern',['One of the town\'s five lanterns, on its post. The glass is cold and the wick is dry.']);
  },
  cast:{Kindle(d){
    if(s2fl('lt'+i)){ say('',['Lit. It burns steadily, and a little smugly.']); return; }
    s2fl('lt'+i,1); coin();
    const n=[0,1,2,3,4].filter(j=>s2fl('lt'+j)).length;
    toast('Kindle: the lantern wakes. ('+n+'/5)',2400);
    if(n>=5){ S2.clearDeadline('lant'); addRep(getRed(),5); toast('Proof two: the lanterns.',3400); s2set(4); }
    hudCache.obj=null;
  }}}));

/* =========================================================
   CHAPTER 6 (RED): THE WILD ART
   ========================================================= */
function wildOpen(){ return s2at('c6r',1,3); }
S2.ch.c6r={route:'red',title:'The Wild Art',sub:'The Art is asking. The Wood is listening.',
  intro:['The Hearth has been dimming at dusk. The Elders have not told the town. The town knows anyway. A hundred ducks in a hundred doorways, watching one flame.','The First Hearth was lit from a lantern. The lantern was left in a shrine in the Hollow Wood, the day the town was founded. Nobody has gone to look in a hundred years. Nobody has dared ask the Wood.'],
  recap:'You brought the Keeper\'s Lantern out of the shrine. Its flame leans toward the Burnt Wood.',
  start(){
    seq([
      ['Hearthwarden Pyre',['You are late. I did not say a time. You are late anyway.','Come to the Hearth. Look at it. Tell me what you see.']],
      ['',['The Great Hearth burns tall and gold. Then, as you watch, every flame in the basin bows, together, a little to the north-west. As though something very far away has said its name.']],
      ['Hearthwarden Pyre',['Three nights. Ruddock thought I did not know. Hearthwardens know.','The First Hearth was lit from the Keeper\'s Lantern, in the shrine of the first glade, the day we built the town. It has hung there a century. A lantern is a kind of promise, and the Hearth answers it.','Something is pulling the promise away. If you bring it here, we can see where it leans. And perhaps hold it.','The shrine is past the south gate, on the old road. The Wood may ask things of you. Answer as you were taught.']]
    ],()=>s2set(0));
  },
  obj(s){
    return ['Leave Emberwick by the <b>south gate</b>, follow the Ember Road to the pale-pebble <b>shrine path</b> and walk east into the Hollow Wood'+hostWhere(268,-1131)+'.',
      'The Thorn Road: clear the way east. Four things bar it: thorn, dark, fog and a curse. Use the Art. (C to cast, or Z on an obstacle.)',
      'The Singing Stream (east of the Thorn Road): cross it, and pass the Grove Warden unseen.',
      'The Keeper\'s Shrine (the glade beyond the stream): be still, and ask.',
      'Take the lantern back west along the road to <b>Hearthwarden Pyre</b> at the Great Hearth, in the middle of Emberwick.'][s];
  },
  talk(n,done){
    if(n.name==='Hearthwarden Pyre'&&s2step()===4){
      seq([['Hearthwarden Pyre',['You have it. Oh. It is warm. It remembers the Hearth. It remembers us.','Look at the flame. It leans. Not a flicker: a pointing. North-west.','The Burnt Wood. We have all told ourselves it was only a place where something happened. It is a place where something is happening.']],
        [H3,['What have they done, Pyre? What has anyone done?']],
        ['Hearthwarden Pyre',['Nothing. That is the dreadful part. It is not a deed. It is a debt, and it has come due.','Keep the lantern. Keep it dry, keep it warm, and do not let anyone take it from you, least of all out of fear. I will tell the Elders. You will go home to Mallow.']]],()=>{ S2.finish('c6r'); done(); });
      return true;
    }
    if(n.name==='Hermit Mallow'&&s2step()<4){ say(H3,['The shrine path is past the south gate. I would come, but the Wood has opinions about the old. I will wait at the Hearth and hold it warm.','Be still when it asks you. That is the whole secret of the Hollow. It always was.'],done); return true; }
    return false;
  }
};
S2.prop({id:'shrinepath',wx:264,wy:-1136,snap:2,glyph:'stone',when:()=>s2at('c6r',0,0),mark:'!',use(){
  say('',['The old shrine path: a track of pale pebbles leaving the Ember Road to the east, under black trees, into the dim. The pebbles are worn by something older than feet.','(Follow it east. The Thorn Road begins where the trees close in.)']);
}});

/* ---- the Thorn Road ---- */
function sxSpellObj(o,spells,solve,hint,alts){ o.use=(S,ob)=>sxNeed(S,ob,spells,solve,alts,hint); o.cast={}; for(const sp in spells) o.cast[sp]=(S,ob)=>solve(S,ob,sp); return o; }
sxDef('ws1',{name:'The Thorn Road',theme:'wood',dark:0.62,lightR:92,start:[1,3,'right'],seek:S=>[19,2],
  rows:[
  '#######################',
  '#..#ba#.........#....##',
  '#..#..#.........#....##',
  'D..T..#.........F...C.>',
  '#..#..#.........#....##',
  '#..#.c#.........#....##',
  '#######################'],
  exits:{D:{to:'world',wx:RX0+40,wy:RY0+54},'>':{to:'ws2',tx:1,ty:3,dir:'right'}},
  objs:{
    T:sxSpellObj({name:'Thorn wall',glyph:'thorns',desc:'A wall of black thorns, red-berried and shivering. Something old grew this to keep the road.',solid:true,
      when:S=>!S.fl.thorn},{Kindle:'ask the thorns to burn'},(S,o)=>{ S.fl.thorn=1; coin(); say('',['You point the wand and ask, quietly. The thorns remember being wood. They burn politely down to ash, and the ash lies down in a tidy line.']); },'Thorns burn. The Ember Wand remembers fire.'),
    a:{name:'Rune stone',glyph:'stone',key:'ra',use:(S,o)=>runeUse(S,'a')},
    b:{name:'Rune stone',glyph:'stone',key:'rb',use:(S,o)=>runeUse(S,'b')},
    c:{name:'Rune stone',glyph:'stone',key:'rc',use:(S,o)=>runeUse(S,'c')},
    F:sxSpellObj({name:'Fog',glyph:'fog',desc:'A bank of grey fog, thick as wool. Nothing in it moves, except it.',solid:true,when:S=>!S.fl.fog},{Gust:'blow it away, softly'},(S)=>{ S.fl.fog=1; coin(); say('',['"Away," you whisper, to the charm. A shy wind unrolls from it, and the fog goes, grumbling, in a long grey line down the road.']); },'Fog is air. A gust will move air.'),
    C:sxSpellObj({name:'Curse-mark',glyph:'curse',desc:'A mark glows on the road: a circle, a cross, a very old sentence. It hums at you.',solid:true,when:S=>!S.fl.curse},{Ward:'hold the knot to your heart'},(S)=>{ S.fl.curse=1; coin(); say('',['You hold the Ward Charm to your heart and think of home. The mark flares violet, flinches, and goes out like a candle in a draught.']); },'A curse is turned by a ward, held to the heart.')
  },
  doors:[{tx:6,ty:3,key:'runes'}],
  onEnter(S){ if(s2fl('letterRead')&&s2at('c7r',1)){ s2set(2); hudCache.obj=null; } if(!S.fl.hint){ S.fl.hint=1; say('',['The Thorn Road. It is very dark. Four things bar the way, and each one answers to a different part of the Art.','(Press C to cast. Or face an obstacle and press Z.)']); } },
  trig:[{id:'dark',tx:4,ty:2,w:1,h:3,once:true,fn:S=>{ if(!S.fl.runes) say('',['A room of three flat stones, each with a single mark worn into it. There is a gate beyond, shut. You cannot read the marks in this dark. You would need a light that does not lie about walls.']); }}]
});
/* The rune stones had no picture, so they were invisible. Draw a flat slab; Lumen shows its mark (1, 2 or 3 dots). */
SXG.stone=(c,x,y,t,o,S)=>{
  ell(c,x+16,y+27,12,4,'rgba(0,0,0,0.3)');
  c.fillStyle='#6a6e78'; c.beginPath(); c.moveTo(x+6,y+27); c.lineTo(x+8,y+9); c.lineTo(x+16,y+5); c.lineTo(x+25,y+9); c.lineTo(x+27,y+27); c.closePath(); c.fill();
  c.fillStyle='#82868f'; c.beginPath(); c.moveTo(x+8,y+9); c.lineTo(x+16,y+5); c.lineTo(x+25,y+9); c.lineTo(x+22,y+12); c.lineTo(x+11,y+12); c.closePath(); c.fill();
  const solved=S.fl&&S.fl.runes, lit=S.lumen>0;
  const n={ra:3,rb:1,rc:2}[o.key]||1;
  const col=solved?'#7ad67a':(lit?'#ffd166':'#4a4d56');
  for(let i=0;i<n;i++){ const dx=(i-(n-1)/2)*6; circ(c,x+16+dx,y+19,2.2,col); }
  if(lit&&!solved) circ(c,x+16,y+17,16,'rgba(255,210,110,0.10)');
};
const RUNE_ORDER=['b','c','a'];
function runeUse(S,k){
  if(S.fl.runes){ say('',['The stones are still. The gate is open. They look pleased with themselves.']); return; }
  if(S.lumen<=0){ say('',['A mark, worn smooth. You cannot read it in this light. Perhaps something that shows would help.']); return; }
  const nums={a:'three',b:'one',c:'two'}[k];
  const seq=S.rseq||(S.rseq=[]);
  seq.push(k); coin();
  const ok=seq.every((x,i)=>RUNE_ORDER[i]===x);
  if(!ok){ S.rseq=[]; say('',['The mark under your wing, in the orb\'s light, reads "'+nums+'". You press it. It is the wrong place in the song. All three stones go cold, and forget.','(Read the marks by Lumen. Press them in order: one, two, three.)']); return; }
  if(seq.length===3){ S.fl.runes=1; sxOpen(S,'runes','The stones sing. The gate opens.'); say('',['All three stones warm at once, and hum a single low chord. The gate grinds open.']); }
  else toast('"'+nums+'". The stone hums. Good.',1800);
}
/* ---- the Singing Stream ---- */
sxDef('ws2',{name:'The Singing Stream',theme:'wood',start:[1,3,'right'],seek:S=>[19,3],hint:'The Warden sweeps the bridge. Veil makes you uninteresting. Or wait for it to turn.',
  rows:[
  '######################',
  '#.....~~~~.....#.....#',
  '#.....~~~~.....#.....#',
  '<..w..~~~~.....S.....>',
  '#.....~~~~.....#.....#',
  '#.....~~~~.....#.....#',
  '######################'],
  exits:{'<':{to:'ws1',tx:21,ty:3,dir:'left'},'>':{to:'ws3',tx:1,ty:3,dir:'right'}},
  objs:{
    w:sxSpellObj({name:'Singing water',glyph:'none',on:'~',desc:'The stream sings, very quietly, in a language of cold. A single note, over and over.',solid:false,when:S=>!S.fl.ice},{Frost:'ask the water to slow and still'},(S)=>{ S.fl.ice=1; for(let x=6;x<=9;x++) sxSet(S,x,3,'i'); coin(); say('',['"Slow," you ask. "Still." The song drops half a note, and the water in a single lane goes white and quiet. A narrow bridge of ice, singing under your feet.']); },'Cold slows and stills. Ask the water.'),
    S:sxSpellObj({name:'Fallen boulder',glyph:'boulder',desc:'A grey boulder across the path. It looks like it has been waiting a long while to be asked.',solid:true,when:S=>!S.fl.stone},{Stone:'ask it to break along its seams'},(S)=>{ S.fl.stone=1; coin(); say('',['You press the Rune Stone to the face of the boulder and ask. A hairline crack runs from top to bottom. It splits in three tidy pieces and settles with a sigh.']); },'Stone is asked. It is not struck.')
  },
  guards:[{name:'Grove Warden',path:[[11,1],[11,5]],speed:26,range:6,fov:70,pause:0.8,scan:true,
    pal:{body:'#6a7a5a',wing:'#4a5a3a',bill:'#8a9a6a'},head:'hood'}],
  caughtLines:['The Grove Warden turns toward you. It is not angry. It is simply certain that you do not belong.','You are lifted, gently, and set down at the beginning of the stream.'],
  onEnter(S){ if(!S.fl.hint){ S.fl.hint=1; say('',['The stream sings. A grey shape paces the far bank: the Grove Warden, the Wood\'s own watch. It sees what moves. It does not hurry.','You cannot cross without ice. You cannot be seen to cross. (Veil makes you uninteresting. Or watch its path.)']); } }
});
/* ---- the Keeper's Shrine ---- */
const WHISPERS=['"Do you belong here?"','"A yellow duck, they said."','"Be still. Be still. The Wood is listening."','"What do you want?"','"Not to take. To ask."','"Whose child are you?"'];
sxDef('ws3',{name:'The Keeper\'s Shrine',theme:'wood',dark:0.72,lightR:72,start:[1,3,'right'],
  rows:[
  '################',
  '#..............#',
  '#..............#',
  '<......L.......#',
  '#..............#',
  '#..............#',
  '################'],
  exits:{'<':{to:'ws2',tx:21,ty:3,dir:'left'},H:{to:'world',wx:RX0+40,wy:RY0+54,col:'#c9a24a'}},
  objs:{L:{name:'The Keeper\'s Lantern',glyph:'lamp',solid:true,light:S=>!!S.fl.lit,lightR:120,desc:'An old lantern on a stone plinth. Dark. Cold. The glass is clean, as if somebody still wipes it.',
    use:(S,o)=>{
      if(S.fl.took){ say('',['The plinth is bare. The Wood is quiet, in a way that sounds like trust.']); return; }
      if(!S.fl.lit){ say('',['Dark. Cold. The Wood wants you to be still. Not here, at the lantern. Near it. Close enough to be heard, and quiet enough to hear.','(Stand near the plinth and do not move. Stillness is the whole secret of the Hollow.)']); return; }
      S.fl.took=1; addItem('keeperlantern'); coin(); hudCache.obj=null; sxSet(S,15,3,'H');
      seq([['',['The Wood opens a way home behind the shrine, a path of pale pebbles. The flame has leaned toward you, as if to be sure. You lift the lantern from the plinth. It does not resist.','The flame turns, slowly, and settles. It points north-west. Steady. Patient. Certain.']]],()=>{ s2set(4); toast('Received: the Keeper\'s Lantern.',4200); });
    }}},
  onEnter(S){ S.stillT=0; S.lastW=0; if(!S.fl.hint){ S.fl.hint=1; say('',['A round shrine in the heart of the glade. A plinth, a dark lantern, and a very large silence.','The Hollow Wood moves when it is afraid. It listens when you are still.']); } },
  tick(S,dt){
    if(S.fl.lit||S.fl.took) return;
    const dx=sxLX(S)-7.5*TS, dy=sxLY(S)-3.9*TS;
    if(Math.hypot(dx,dy)<TS*3){
      if(!g.moving&&g.mode==='play'){
        S.stillT+=dt;
        const idx=Math.floor(S.stillT/1.6);
        if(idx>S.lastW&&idx<=WHISPERS.length){ S.lastW=idx; toast(WHISPERS[idx-1],1500); }
        if(S.stillT>=10){ S.fl.lit=1; coin(); say('',['The lantern catches. Not with a spark. With a decision.','A small gold flame stands up in the glass, and listens.']); }
      } else { if(S.stillT>1.5&&g.moving) toast('The Wood stirs. Be still.',1400); S.stillT=0; S.lastW=0; }
    } else { S.stillT=0; S.lastW=0; }
  }
});

/* =========================================================
   CHAPTER 7 (RED): THE KIN
   ========================================================= */
PGLYPH.cottage=(c,x,y,col,t)=>{
  ell(c,x+16,y+30,24,5,'rgba(0,0,0,0.25)'); rect(c,x-8,y-14,48,42,'#e2c4b0'); rect(c,x-8,y+24,48,4,'#b99a84');
  c.fillStyle='#8a2a22'; c.beginPath(); c.moveTo(x-14,y-12); c.lineTo(x+16,y-34); c.lineTo(x+46,y-12); c.fill();
  rect(c,x+10,y+6,12,22,'#4a2c18'); rect(c,x-2,y-2,8,8,'#2a3a5a'); rect(c,x+26,y-2,8,8,'#2a3a5a');
  rect(c,x+36,y-30,5,12,'#6b3a2a'); if(col!=='lit'){ rect(c,x+10,y+6,12,1,'rgba(255,255,255,0.1)'); } else { circ(c,x+16,y+14,26,'rgba(255,170,80,0.18)'); }
};
S2.ch.c7r={route:'red',title:'The Kin',sub:'Every house is a question somebody forgot to ask.',
  intro:['Mallow has not slept. He has sat all night at the Great Hearth, beside the Keeper\'s Lantern, watching its flame lean north-west like a flower following a sun he cannot see.','At dawn he stands up, and asks you the only thing he has asked anyone in a hundred years.','"Will you come home with me? I have never been inside."'],
  recap:'Bree\'s cottage held a music box and a letter: Mallow\'s mother left Emberwick that first spring to join the three hundred, and look for her son.',
  start(){ seq([[H3,['Bree\'s house. My mother\'s house. The neighbours kept it. A hundred years, and not one has moved a chair.','I am too old to be afraid of a door. I am afraid anyway. Will you come? Poppy has the key. She has kept it for me since before she was born, she says, which is not possible, and I believe her.']]],()=>s2set(0)); },
  obj(s){ return ['Go with Mallow to <b>Bree\'s cottage</b>, just outside Emberwick\'s south gate. <b>Little Poppy</b> has the key.',
    'Bree\'s cottage: look around. Mallow\'s mother hid something in this house. When you find it, read the letter. Tidying up is up to you.',
    'The Elders have sent for you at the <b>Great Hearth</b>. Take the letter.'][s]; },
  journal(line){ if(s2fl('letterRead')) line('"I am going back for you. Do not follow. I will bring you home." Bree, a century ago.','jdim'); },
  talk(n,done){
    if(n.name==='Hermit Mallow'&&s2step()===0){ say(H3,['Poppy has the key. Find her near the house. She is small, and loud, and rather wonderful.'],done); return true; }
    if(n.name==='Hermit Mallow'&&s2step()===2){ say(H3,['Go to the Hearth. I will follow. I need a minute with the letter first. A hundred years is a very long time to wait for one page.'],done); return true; }
    return false;
  }
};
S2.npc({id:'poppy7',name:'Little Poppy',wx:260,wy:-1141,pal:3,head:null,when:()=>s2at('c7r',0),mark:'!',talk(n,done){
  if(s2fl('key')){ say('Little Poppy',['It is the door with the red knocker! Mallow is very tall for a boy.'],done); return; }
  seq([['Little Poppy',['You came! You are red now. Mama says you were yellow. I like yellow. I like red. I like both.','I kept this. It was Granny\'s, then Mama\'s, then mine. It is for the boy who got lost. Mallow, is it you? It has your name on it. See?']],
    [H3,['Oh, little one. Oh, thank you. It is me. It was always going to be me.']]],()=>{ s2fl('key',1); s2led('kin',1); addItem('breekey'); toast('Received: Bree\'s key.',3000); done(); });
}});
ITEMS.breekey={name:'Bree\'s Key',desc:'A small iron key on a red thread. It fits one door in Emberwick.',use:'note',note:'It is warm. It has been held a great deal.',nogift:true};
Object.assign(RICON,{breekey:(R,C,E)=>{ C(5,6,3,'#c9a24a'); R(7,5,7,2,'#c9a24a'); R(11,7,2,3,'#c9a24a'); R(9,7,1,2,'#c9a24a'); R(4,6,2,2,'#7a2a22'); }});
S2.prop({id:'breehouse',wx:257,wy:-1141,glyph:'cottage',colf:()=>s2fl('hearthLit')?'lit':null,when:()=>s2at('c7r',0,2),mark:()=>s2at('c7r',0)&&s2fl('key')?'!':null,use(){
  if(!s2fl('key')){ say('',['A small cottage with a red knocker, shuttered for a century and kept swept. The door is locked. Somewhere near, a very small voice is singing about beetroot.']); return; }
  s2set(1); say('',['The key turns on the first try, as if it had been practising. The door opens on a smell of old wood and cold ash, and a very long quiet.'],()=>sxEnter('bree'));
}});
sxDef('bree',{name:'Bree\'s Cottage',theme:'archive',indoor:true,start:[6,7,'up'],seek:S=>S.fl.box?null:[2,5],
  rows:sxGrid(13,9,[[6,8,'D'],[1,1,'h'],[4,1,'t'],[9,1,'w'],[2,3,'b'],[10,3,'c'],[2,5,'p'],[8,5,'x']]),
  exits:{D:{to:'world',wx:257,wy:-1140}},
  objs:{
    h:sxSpellObj({name:'Cold hearth',glyph:'fireplace',desc:'A stone hearth, swept clean a hundred times. There is a kettle on the hook. Nobody has lit it since.',solid:true},{Kindle:'ask a flame to come home'},(S)=>{ if(S.fl.hearth){ say('',['The fire is steady, and kind.']); return; } S.fl.hearth=1; s2fl('hearthLit',1); coin(); sxSay(S,'',['"Kindle," you ask. A flame stands up, looks around the room, and seems to recognise it.','The light finds the corners one at a time. A rug. A shawl on a nail. A child\'s drawing of a duck, with far too many legs.']); },'Without a flame, you cannot see the house properly.'),
    t:{name:'Table',glyph:'table',desc:'A table set for two. One plate is cracked. Somebody has glued it, carefully, with a lot of patience and not enough glue.'},
    w:sxSpellObj({name:'Loose shutter',glyph:'shutter',desc:'The shutter hangs by one hinge. It has been banging, very softly, for a hundred years, whenever the wind turns north-west.',solid:true},{Bind:'hold it loosely, like a ribbon'},(S)=>{ if(S.fl.shutter){ say('',['The shutter holds, as if it is thinking about something nice.']); return; } S.fl.shutter=1; s2led('mercy',1); coin(); sxSay(S,'',['You bind it loosely, like a ribbon on a wrist. The shutter settles against the frame and stops its knocking.','Through the glass you see the whole town, red-roofed in the dawn. It was a good view to grow up with.']); },'A shutter is held, not nailed.'),
    b:{name:'Small bed',glyph:'bed',desc:'A bed made for a child of seven. The blanket is folded as if someone was about to come back and unfold it.'},
    c:sxSpellObj({name:'Broken chair',glyph:'chair',desc:'A chair with a broken back, leaning against the wall where it was set down, once, to be mended later.',solid:true},{Mend:'match the thread to the cloth'},(S)=>{ if(S.fl.chair){ say('',['The chair stands, a little proud.']); return; } S.fl.chair=1; s2led('mercy',1); coin(); sxSay(S,'',['"Mend what is broken, not what is gone." You match the grain to the grain, and the break closes like a held breath.','You cannot find the join. The chair has decided it was always whole.']); },'A chair is mended, not hammered.'),
    p:{name:'Loose board',glyph:'plank',when:S=>S.fl.seeked,desc:'A board with a little give in it, glowing faintly where the beetle looked.',use:(S,o)=>{
      if(S.fl.box&&s2fl('letterRead')){ say('',['The little hollow under the floor is empty now. The music box sits on the table, resting.']); return; }
      S.fl.box=1; coin(); if(!(g.inv&&g.inv.breeletter)) addItem('breeletter'); hudCache.obj=null;
      cutSeq({story:[['floorboard'],['floorboard',{seq:['siegeGraves','siegeGraves']},'motherSings'],['foldedLetter']]},[['',['You lift the board. Under it, in a hollow wrapped in a child\'s scarf: a small wooden music box, red-painted, with a duck on the lid.','You wind it. It plays, thinly and a little out of tune, a lullaby of four slow notes.']],
        [H3,['That song.','I have heard that song. Not here. Not as a child. In the kingdom, once, at the graves in the old Siege Field, when the wind was right. A hum. An old gardener said they all hummed it, the graves. I thought: what a strange coincidence.','It is my mother\'s song.']],
        ['',['Tucked in the lid, folded small, a single page. It has been waiting a hundred years. Mallow holds out one wing, and then does not take it. He looks at you.']]],()=>{
          choose(H3,'"Would you read it? I do not think I can."',['Read it aloud, every word','Read it aloud, but gently','Give it back to him, and say you will wait'],k=>{
            if(k===0){ s2led('truth',1); s2led('trust',1); } else if(k===1){ s2led('mercy',1); } else { s2led('kin',1); }
            const letter=['"My Mallow. If you are reading this, you came home, and I am so glad, and so sorry I was not here to open the door."','"The walkers are going back down the road, all of us who can still stand, to find every child we lost on the way. Gordamom says he will bring them home or bring back the road. He is angry. He is not wrong about the children."','"Light the hearth. Eat something. Do not follow. I will bring you home. I am your mother, and I do not stop. - Mama"'];
            const after=()=>{ cutSeq({story:[['walkersBack','marchNorth','woodOfTrees'],['hugLeg'],['hugLeg']]},[[H3,['"The walkers." "Gordamom\'s walkers."','Three hundred followed him from the fifth fire, and they searched the roads for years. The siege was theirs. And in the first spring my mother went to join them. She did not go to make war. She went back for me.','...Cinder said the three hundred became trees. I thought: that is somebody else\'s grief. It is mine.']],
              ['Little Poppy',['Is Mallow sad? I do not like when Mallow is sad. Can I hug him? I can hug his leg.']],
              [H3,['Yes, little one. Yes, please. Oh. That is the best thing anyone has said all week.']]],()=>{ s2fl('letterRead',1); s2set(2); toast('Received: Bree\'s Letter. The Elders have sent for you.',4800); }); };
            if(k===2){ say(H3,['...Thank you. Yes. I think, in a minute, I could.','(He reads it himself, silently. You wait. It takes a very long time.)'],after); }
            else cutSeq({story:[['motherWrites','walkersBack','motherLeaves']]},[['Bree\'s Letter',letter]],after);
          },2);
        });
    }},
    x:{name:'Rug',glyph:'rug',solid:false,col:'#7a2a22'}
  },
  npcs:[{name:'Hermit Mallow',tx:6,ty:5,pal:RED_PALS[0],head:'hood',talk:(S,n)=>{
    if(S.fl.box) say(H3,['I am here. I have never been so here in my life.'],null);
    else if(!S.fl.hearth) say(H3,['It is so cold. It has been cold a long time. A fire would be a courtesy.'],null);
    else say(H3,['My mother used to say the best things in a house are under the floor, and under the bed, and under the third step. Bree thought like a mouse.'],null);
  }}],
  follow:{name:'Little Poppy',pal:RED_PALS[3],head:null,scale:0.7,seen:false},
  onEnter(S){ if(!S.fl.hint){ S.fl.hint=1; sxSay(S,'Little Poppy',['It is so DUSTY. Mama says it is respect dust, not neglect dust. There is a difference.']); } },
  onSeek(S){ if(!S.fl.seeked){ S.fl.seeked=1; sxSay(S,'',['The beetle turns, ticks, and stops. Its eye glows green toward the far corner of the floor, where one board is very slightly paler than the others.']); } }
});
SX.defs.bree.onLeave=function(){ if(s2fl('letterRead')&&s2at('c7r',2)) { /* walk to the Hearth */ } };
S2.zone({id:'council7',red:[36,31],r:6,when:()=>s2at('c7r',2),fn(){
  seq([
    ['Elder Cinder',['Come. Sit. All of you, quiet.','Mallow has shown me the letter. I have read it three times. It is in his mother\'s hand. I would know it anywhere. Bree taught me my letters, on the same slate she later taught her boy.']],
    ['Archivist Sorrel',['The three hundred who followed Gordamom were not all soldiers. I have the March records. Seventy-one of them are listed as "mothers and fathers, seeking".','Not an army. A search party that turned into a siege.']],
    ['Keeper Brand',['An army does not need to mean to be one. A grove that wakes in grief is a grove that wakes angry. Three hundred, in their hundredth year of sleep. Think about what a dream like that does to a duck.']],
    ['Warden Ruddock',['I voted no on this duck. I will vote no again, on this. I do not think they are monsters. I think they are tired and very, very afraid, and I would not wake them for any reason.']],
    ['Elder Cinder',['We will not decide in anger. The Hearth leans. The ward weakens. The king has not spoken to us in a hundred years, and we have not spoken to him.','Keep the lantern, Detective. Keep the letter. I think we are going to need both.']],
    ['',['(You notice, as the council breaks up, that Keeper Brand does not go home. He goes toward the Archive, quickly, with his hood up.)']]
  ],()=>{ S2.finish('c7r'); });
}});

/* =========================================================
   CHAPTER 8 (RED): COLD FIRE
   ========================================================= */
const CF={id:'cf',title:'Cold Fire',
  clues:{ashby:'Night-watch Ashby: grey cloaks gather at the Archive cellar door at midnight, three nights running.',candles:'Acolyte Wren: a dozen vigil candles have gone missing from the Academy store.',note:'Courier Jay: he carried a sealed note to Keeper Brand. It smelled of tallow. It was addressed "to the Hands".',brand:'Gossip Marrow: Brand has stopped coming to the Hearth at dusk. "At prayer in the Archive", he says.',chalk:'Scout Fennel: a chalk circle, drawn fresh, and tallow drippings, in the old root cellar by the east wall.'},
  links:[{a:'candles',b:'chalk',id:'ritual',t:'Vigil candles and a chalk circle. This is a rite, not a theft.'},{a:'ashby',b:'note',id:'cult',t:'Grey cloaks, and a note to "the Hands". An organised group meets at midnight.'},{a:'brand',b:'note',id:'leader',t:'The note was addressed to Brand, who has stopped attending the Hearth. He leads them.'}],
  need:['ritual','cult','leader'],q:'What are the Hands planning, and where?',
  answers:[{t:'To burn the Archive',no:'The Archive stands. That is not it. An hour is lost.'},{t:'The Closing Rite: to sever the Hearth from the Burnt Wood, tonight, in the root cellar',ok:1,yes:'That is it. Everything fits: the candles, the circle, the cloaks, the leader, the hour. A rite to cut the Hearth from whatever it leans toward, and Brand at the centre.'},{t:'A coup against the Elders'},{t:'A feast'}]};
const CFNPC={'Night-watch Ashby':'ashby','Acolyte Wren':'candles','Courier Jay':'note','Gossip Marrow':'brand','Scout Fennel':'chalk'};
const CFTALK={ashby:['Ashby, on the night watch, speaks low and without looking round.','"Grey cloaks. Four, five of them. Midnight, the Archive cellar door, three nights. When I called out, they went very still, like deer. I have been a night-watch for fifty years. I know what a plan looks like."'],
  candles:['Acolyte Wren looks at you with enormous eyes.','"A dozen vigil candles. Gone from the Academy store. I counted twice. I counted thrice. I have said nothing. I did not know who to say it to. Please, will you say it for me?"'],
  note:['Courier Jay hesitates, then lowers his voice.','"I carried a note to Keeper Brand. Sealed in tallow. I am not supposed to say. It was addressed to... to \'the Hands\'. I thought it was a club. It does not feel like a club."'],
  brand:['Gossip Marrow, for once, is not pleased to have news.','"Brand has stopped coming to the Hearth at dusk. \'At prayer in the Archive\', he says. A man who prays that often is asking for something, dear. Or hiding from it."'],
  chalk:['Scout Fennel crouches, drawing in the dust with one claw.','"A circle, so big. Chalk, very fresh. Tallow dripped round it, like beads. In the root cellar, by the east wall. I thought: children playing a game. Then I thought: children do not play with candles that size."']};
function riteMidnight(){ const n=s2now(); let m=Math.floor(n/24)*24+24; if(m-n<2) m+=24; return m; }
S2.h.c8r_rite=function(){ s2fl('riteLate',1); hudCache.obj=null; if(s2at('c8r',1)) say('',['Midnight. Somewhere underneath Emberwick, a bell that is not a bell begins to toll. Every flame in the town bows, together, to the north-west, and the Great Hearth gutters to a single blue thread.','You have missed the start of the rite. You can still stop it. Go. Go now.']); };
S2.ch.c8r={route:'red',title:'Cold Fire',sub:'Fear is the most organised thing in the world.',
  intro:['Every lantern in Emberwick has gone out, one by one, in the night. Nobody has touched them.','By morning the flame of the Great Hearth is the colour of a bruise. The town is saying, loudly, what it has been whispering for a week: the Wood is dying, the Hearth is dying, and somebody had better do something.','Somebody already has.'],
  recap:'You exposed the Closing Rite and its leader. The Elders asked you to carry their letter and the lantern to the king.',
  start(){ s2set(0); },
  obj(s){ return ['Find who is behind the lantern-snuffing. Ask: <b>Ashby, Wren, Jay, Marrow, Fennel</b> ('+Object.values(CFNPC).filter(k=>S2.hasClue('cf',k)).length+'/5 notes). When you have enough, talk to <b>Hermit Mallow</b> to open the case board.',
    'Midnight. The <b>root cellar</b> by the east wall of Emberwick. Stop the Closing Rite.',
    'Return to the <b>Great Hearth</b>. The Elders are waiting.',
    'Cinder has set you a task: take the lantern and her letter to <b>Quackenhold</b>, the king\'s castle.'][s]; },
  mark(n){ const k=CFNPC[n.name]; if(k&&s2at('c8r',0)&&!S2.hasClue('cf',k)) return {ch:'!',col:'#ffd166'}; if(n.name==='Hermit Mallow'&&s2at('c8r',0)&&Object.values(CFNPC).filter(k=>S2.hasClue('cf',k)).length>=5) return {ch:'?',col:'#86e29a'}; return null; },
  talk(n,done){
    const s=s2step();
    if(s===0&&CFNPC[n.name]){
      const k=CFNPC[n.name];
      if(S2.hasClue('cf',k)){ say(n.name,['I have told you what I know. I shall not say more. It is not safe to.'],done); return true; }
      say(n.name,CFTALK[k],()=>{ S2.clue('cf',k,'Clue: '+n.name+'.'); hudCache.obj=null; done(); }); return true;
    }
    if(s===0&&n.name==='Hermit Mallow'){
      if(Object.values(CFNPC).filter(k=>S2.hasClue('cf',k)).length<2){ say(H3,['Something is wrong in the town. Ask the watch. Ask the children. Ask those who talk too much.'],done); return true; }
      S2.board(CF,()=>{ s2set(1); S2.deadline('rite',Math.max(1,riteMidnight()-s2now()),'Midnight','c8r_rite'); seq([[H3,['The Closing Rite. Brand means to cut the Hearth from the Burnt Wood. He thinks it will make us safe.','Little detective. The lantern leans toward my mother. If the Hearth is severed, what happens to the sleepers?']],[P3,['I do not know. I think they die.']],[H3,['Then we have until midnight.']]],()=>{ done(); }); });
      return true;
    }
    if(s===2&&n.name==='Elder Cinder'){ return false; }
    return false;
  }
};
S2.prop({id:'rootcellar',red:[58,38],glyph:'door',col:'#3a2a1a',when:()=>s2at('c8r',1),mark:'!',use(){
  const t=s2now()%24;
  if(!s2fl('riteLate')&&t<22&&t>6){ say('',['The root cellar door. Shut. Cold air breathes under it. Voices, very low, are not talking.','It is too early. The Hands meet at midnight. (Come back at night.)']); return; }
  say('',['The cellar door gives, quietly. Stone steps lead down into a dark that smells of tallow and old roots. Somewhere below, many voices are saying the same word, over and over, in a rhythm that is almost a lullaby and not.'],()=>sxEnter('cellar'));
}});
const GREY={body:'#6a6068',wing:'#4a4048',bill:'#c9a24a'};
sxDef('cellar',{name:'The Root Cellar',theme:'ash',dark:0.7,lightR:70,start:[1,5,'right'],caughtLines:['"WHO GOES?" A grey-cloaked duck raises a candle, and several more voices raise themselves behind him.','You are hustled to the cellar door and, with some force, out of it. You come back down the steps a minute later, with your feathers rearranged.'],
  hint:'Shadows (dark floor) halve what they see. Veil makes you uninteresting. The pillars block their sight.',
  rows:sxGrid(26,11,[[0,5,'D'],[3,2,'P'],[22,2,'P'],[3,8,'P'],[22,8,'P'],[5,4,5,3,','],[16,4,5,3,','],[11,2,'a'],[19,2,'b'],[11,8,'c'],[12,5,'N'],[8,4,'P'],[17,6,'P']]),
  exits:{D:{to:'world',wx:RX0+58,wy:RY0+39}},
  objs:{
    P:{name:'Pillar',glyph:'pillar',block:true,col:'#5a5460'},
    a:sxSpellObj({name:'Roaring brazier',glyph:'brazier',lit:S=>!S.fl.ba,light:S=>!S.fl.ba,lightR:96,desc:'A tall brazier burning with a hungry red flame, ringed in chalk.',solid:true},{Frost:'cold is the other half of warmth'},(S)=>{ brazierOut(S,'a','Frost: the flame stiffens, whitens, and goes still as a candle in a photograph.'); },'It roars. What is the opposite of a roaring fire?'),
    b:sxSpellObj({name:'Smoking brazier',glyph:'brazier',lit:S=>!S.fl.bb,light:S=>!S.fl.bb,lightR:96,desc:'A brazier choked with grey smoke. The smoke is thick enough to hold.',solid:true},{Gust:'move smoke, not stone'},(S)=>{ brazierOut(S,'b','Gust: the smoke leaves in a polite line, and the flame, with nothing left to hide in, dies of exposure.'); },'It smokes. What moves smoke?'),
    c:sxSpellObj({name:'Warded brazier',glyph:'brazier',lit:S=>!S.fl.bc,light:S=>!S.fl.bc,lightR:96,desc:'The brazier is ringed in a purple curse-mark. It will bite anything that touches it.',solid:true},{Ward:'turn the curse, then the flame'},(S)=>{ brazierOut(S,'c','Ward: you hold the knot to your heart. The mark turns on itself, quarrels, and goes out, taking the flame with it.'); },'It is cursed. What turns a curse?'),
    N:{name:'Keeper Brand',glyph:'none',solid:false}
  },
  npcs:[{name:'Keeper Brand',tx:12,ty:5,pal:RED_PALS[1],head:'wizard',talk:(S,n)=>{
    if(S.fl.over) return;
    say('Keeper Brand',['Not you. Not tonight. Go home, Detective. I am doing what none of them dare to.','The Closing Rite makes us safe. A hundred years of fear, and tonight it ends.'],null);
  }}],
  guards:[
    {name:'Grey Hand',path:[[2,1],[23,1],[23,9],[2,9]],speed:36,range:5,fov:64,pal:GREY,head:'hood',off:S=>!!S.fl.ruddock||!!S.fl.over},
    {name:'Grey Hand',path:[[7,3],[7,7],[18,7],[18,3]],speed:32,range:5,fov:64,pal:GREY,head:'hood',off:S=>!!S.fl.ruddock||!!S.fl.over}
  ],
  onEnter(S){
    S.over=false; delete S.fl.over; delete S.fl.ruddock; for(const k of ['ba','bb','bc']) delete S.fl[k];
    sxTimer(S,s2fl('riteLate')?70:150,'The Rite',(S2_)=>{ riteFails(S2_); });
    sxSay(S,'',['A chalk circle, wide as a cart. Three braziers burn at its points, red and smoking and warded. In the middle, Keeper Brand, with his arms raised, chanting.','Grey-cloaked ducks walk the walls. Keep to the shadows. Snuff all three braziers before the circle closes.']);
  },
  tick(S,dt){
    if(S.timer&&!S.fl.ruddock&&s2fl('ruddockSecret')&&S.timer.t<S.timer.max*0.5){ S.fl.ruddock=1; sxSay(S,'Warden Ruddock',['(A familiar, grudging shape comes down the steps behind you, and every grey cloak turns to look at him.)','"Stand down. All of you. I said I would keep your secret, apprentice. I did not say I would keep theirs."','"Brand, you are a fool. Hands, put out your candles. The Warden says so, and the Warden is very, very tired."']); }
  }
});
function brazierOut(S,k,msg){
  S.fl['b'+k]=1; coin(); toast(msg,3600);
  if(S.fl.ba&&S.fl.bb&&S.fl.bc&&!S.fl.over){ S.fl.over=1; S.timer=null;
    seq([['Keeper Brand',['No. No, no. The circle. The last flame. They will wake, you do not understand, they will wake angry and the Hollow will burn...']],
      ['',['The chalk circle flares once, white, and goes cold. The grey cloaks put down their candles one by one, as if they have just woken up from something.']]],()=>aftermath8(S,false)); }
}
function riteFails(S){
  S.fl.over=1; s2fl('riteDone',1); S.timer=null;
  seq([['',['The circle closes with a sound like a held breath finally let go. Above you, through stone and earth, the Great Hearth gutters, flares blue, and settles lower, steadier, quieter.','Something that was pulling, a very long way away, stops pulling. The cold-fire does not hurt. That is the dreadful part.']],
    ['Keeper Brand',['It is done. It is... quieter. It is quieter. That is all I wanted.']]],()=>aftermath8(S,true));
}
function aftermath8(S,failed){
  S2.clearDeadline('rite'); S.timer=null;
  const R='Warden Ruddock', E='Elder Cinder';
  const lines=[[R,['(Ruddock comes down the cellar stair with two wardens and a lantern. He does not look at you. He looks at Brand.)','"Keeper Brand. You have used the Hearth\'s own flame against the Hearth. I have never wanted so much to be wrong about someone."']],
    ['Keeper Brand',['I was trying to save you. All of you. If the ward fails, three hundred sleepers wake, in a hundred years of dream, and they come for the Hollow. I would cut the Hearth from the Burnt Wood and let them sleep for good, and our children live.','Tell me where I was wrong.']],
    [H3,['(Mallow has come down the steps behind the wardens. He is very small in the lantern light.)','"You would have killed them, Brand. My mother is one of them. Is that where you were wrong?"']],
    ['Keeper Brand',['...Bree\'s boy. I did not... I did not know.']]];
  if(failed) lines.push([E,['The rite is done. The Hearth is lower. It is not lost, Brand, but you have taken a year from it, and from them. A year you did not have the right to spend.']]);
  seq(lines,()=>{
    choose(E,'What will you say for Brand?',['Let the Elders judge him','He was afraid, not wicked. Speak for him','He should be sent away from Emberwick'],k=>{
      if(k===0){ s2led('trust',1); } else if(k===1){ s2led('mercy',2); } else { s2led('pride',1); }
      seq([[E,[['The Elders will judge him. In their own time, and with their own sorrow.','You say it as a mother would. He lowers his head. I have not heard that in this town for a hundred years.','Then he will go, and I will pretend I did not agree. We are a small people. We do not have the luxury of exiles.'][k]]],
        [E,['Detective. Come to the Hearth at dawn. I have a task for you, and it is a great one, and I would rather not ask it.']]],()=>{
        sxLeave(RX0+58,RY0+39); s2set(2);
      });
    },2);
  });
}
S2.zone({id:'hearth8',red:[36,31],r:6,when:()=>s2at('c8r',2),fn(){
  addItem('elderletter'); coin();
  seq([['Elder Cinder',['The ward is Eider\'s. We all know it. We have never said so. A hundred years ago he spoke a word on his castle wall, and the Burnt Wood stopped. We have felt it hold. We have felt it tire.','If it breaks, three hundred sleepers wake, in grief. If it holds, the king who holds it is dying, and he is the only one who knows how it was made.']],
    ['Elder Cinder',['He has not spoken to us in a hundred years. We have not spoken to him. One of us has to be first.','Take the Keeper\'s Lantern. Take this letter, in my own hand. Take Bree\'s letter, if Mallow lets you. Go to Quackenhold. Tell Eider the Hollow remembers, and does not wish him dead.']],
    [H3,['I would come. Cinder says no: I am too old, and the king\'s guards know what a red hermit looks like. I am so sorry, little detective.','You will be an outcast in his kingdom. They will not open the gate for a red feather. You will have to find another way in. You have the Art. You have a beetle. You have, I think, a very great deal of nerve.']],
    ['Warden Ruddock',['(He stands at the edge of the Hearth\'s light, arms folded.)','I voted no. I vote yes on this. Come back alive, apprentice. I should hate to have to find a new person to be wrong about.']]],()=>{
    toast('Received: Elder Cinder\'s Letter.',4200); S2.finish('c8r');
  });
}});
ITEMS.elderletter={name:'Elder Cinder\'s Letter',desc:'A letter in a stern hand, sealed with a red flame. It begins: "Eider. It has been a hundred years."',use:'note',note:'It is addressed to the king. You do not open it.',nogift:true};
Object.assign(RICON,{elderletter:(R,C,E)=>{ R(3,4,10,8,'#f2e6c4'); R(3,4,10,2,'#d9c9a0'); R(6,8,4,3,'#c0392b'); R(7,7,2,5,'#ff9d2e'); }});
