/* Mallow used to tag along for the rest of the game (even into the Burnt Wood, where the story puts a
   second Mallow at his own house). He now walks with you until Bree's cottage, then stays home there. */
(function(){
  function released(){ const q=s2(); return !!(q&&q.done&&q.done.c7r); }
  const _fu=followUpdate;
  followUpdate=function(dt){
    const st=g.story;
    if(st.hermitFollow&&!st.hermitHome&&released()){
      st.hermitFollow=0; st.hermitHome=1;
      const n=hermitObj();
      if(n){ const p=snapFree(258,-1140,4); n.x=(p[0]+0.5)*TS; n.y=(p[1]+0.95)*TS; n.moving=false; n.talking=false; n.still=true; n.dir='down'; }
    }
    return _fu(dt);
  };
})();
