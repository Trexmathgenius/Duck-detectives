'use strict';
/* ===== MORE EVENT GAMES for the other towns' calendars ===== */
Object.assign(MG_BY_TITLE,{
 'Detective Trivia Night':'trivia','Tea & Gossip Social':'gossip','Moonlit Dance':'dance','Hay Bale Maze':'haymaze','Shell Hunt':'shells','Quack-Off Talent Show':'quackoff'
});
const MGSHUF=a=>{ a=a.slice(); for(let i=a.length-1;i>0;i--){ const j=(Math.random()*(i+1))|0; [a[i],a[j]]=[a[j],a[i]]; } return a; };

/* Detective Trivia Night */
const TRIVIA=[   /* everything here is common knowledge in a village: nothing that gives away the hidden town or the story */
 ['Which animal stole the Great Bun in 1840?',['A raccoon','A duck','A heron'],0],
 ['What does a Pie-Eating Contest forbid?',['Forks','Napkins','Seconds'],0],
 ['What does a Detective Hat make you?',['More mysterious','Faster','Taller'],0],
 ['What is Pond-Water Tea steeped in?',['Actual pond','Rainwater','Fountain water'],0],
 ['How often are village events held?',['Every other day','Every day','Once a week'],0],
 ['What does a Magnifying Glass make big?',['Small clues','Distant hills','Hot tea'],0],
 ['What does everyone carry in the Lantern Parade?',['A paper lantern','A candle stub','An umbrella'],0],
 ['What do you toss into the fountain on Fountain Wishing Day?',['A crumb','A pebble','A feather'],0],
 ['What is a Honey Scone dangerously good with?',['Tea','Cheese','Pickles'],0],
 ['What is said at the Tea & Gossip Social?',['Strictly secret things','The day\'s news, loudly','Nothing at all'],0],
 ['Which of these does a bakery sell?',['Berry Muffins','Rubber duckies','Lanterns'],0],
 ['What is a Flower Crown woven from?',['Daisies and violets','Reeds and rope','Straw and feathers'],0]
];
MG.trivia={
 cap:90,
 hint:'Answer the quiz-master\'s questions.', keys:'Up / Down choose, Z answer',
 how:['The quiz-master reads a question about the world.','Up and Down to choose, Z to answer.','Six questions, twelve seconds each.'],
 hud:s=>'Question '+Math.min(6,s.n+1)+'/6  |  Right '+s.ok,
 init(s){ s.q=MGSHUF(TRIVIA).slice(0,6).map(q=>{ const o=MGSHUF([0,1,2]); return {q:q[0],o:o.map(i=>q[1][i]),a:o.indexOf(q[2])}; }); s.n=0; s.ok=0; s.sel=0; s.ph='ask'; s.tm=12; s.w=0; },
 update(s,dt){
  s.score=s.ok*10/6;
  if(s.ph==='ask'){ s.tm-=dt; if(s.tm<=0){ s.msg='Time!'; mgTone(0); s.ph='res'; s.w=0.9; } }
  else { s.w-=dt; if(s.w<=0){ s.n++; if(s.n>=6){ s.done=1; s.score=s.ok*10/6; } else { s.ph='ask'; s.tm=12; s.sel=0; s.msg=''; } } }
 },
 press(s,k){
  if(s.ph!=='ask') return;
  if(k==='up') s.sel=(s.sel+2)%3; else if(k==='down') s.sel=(s.sel+1)%3;
  else if(k==='z'){ const q=s.q[s.n]; if(s.sel===q.a){ s.ok++; s.msg='Correct!'; mgTone(1); } else { s.msg='It was: '+q.o[q.a]; mgTone(0); } s.ph='res'; s.w=1.1; }
 },
 draw(s,c,t){
  mgSky(c,'#2a2050','#4a3a78'); rect(c,0,215,MGW,55,'#2a1e3a'); rect(c,0,215,MGW,4,'#5a4a8a');
  for(let i=0;i<14;i++) circ(c,20+i*34,12+((i*7)%3)*5,3,'#ffd166');
  mgDuck(c,60,230,1.5,'#fff'); mgDuck(c,430,232,1.1,'#d9503f'); mgDuck(c,380,232,1,'#6ec1ff');
  const q=s.q[Math.min(5,s.n)]; rect(c,40,36,400,48,'rgba(255,244,224,0.94)'); mgT(c,q.q,240,60,12,'#2a1e3a');
  q.o.forEach((o,i)=>{ const on=i===s.sel&&s.ph==='ask', ok=s.ph==='res'&&i===q.a; rect(c,110,98+i*34,260,28,ok?'#9be08a':on?'#ffd166':'rgba(255,244,224,0.85)'); mgT(c,o,240,112+i*34,12,'#2a1e3a'); });
  mgBar(c,110,206,260,6,s.tm/12,s.tm<4?'#e0452f':'#ffd166');
 }
};

/* Tea & Gossip Social: pair the whispers */
MG.gossip={
 hint:'Turn over two cups at a time. Match the pairs.', keys:'Arrows move, Z turn',
 how:['Twelve teacups sit face down.','Move with the arrows, press Z to turn one over.','Find all six pairs in as few turns as you can.'],
 hud:s=>'Pairs '+s.pairs+'/6  |  Turns '+s.turns,
 CC:['#e0452f','#f2d45a','#5aa0e0','#6fd08a','#c58aff','#ff9a3a'],
 init(s){ s.c=MGSHUF([0,0,1,1,2,2,3,3,4,4,5,5]).map(v=>({v:v,up:0,done:0})); s.cur=0; s.open=[]; s.pairs=0; s.turns=0; s.lock=0; },
 update(s,dt){
  if(s.lock>0){ s.lock-=dt; if(s.lock<=0){ const [a,b]=s.open; if(s.c[a].v===s.c[b].v){ s.c[a].done=s.c[b].done=1; s.pairs++; mgTone(1); s.msg='A match!'; } else { s.c[a].up=s.c[b].up=0; mgTone(0); s.msg=''; } s.open=[]; } }
  s.score=Math.max(0,s.pairs*10/6-Math.max(0,s.turns-9)*0.35);
  if(s.pairs>=6){ s.done=1; s.score=Math.max(2,Math.min(10,10-Math.max(0,s.turns-8)*0.7)); }
  else if(s.turns>=20){ s.done=1; s.score=Math.max(0,s.pairs*10/6*0.7); }
 },
 press(s,k){
  if(s.lock>0) return;
  if(k==='left') s.cur=s.cur%4===0?s.cur+3:s.cur-1; else if(k==='right') s.cur=s.cur%4===3?s.cur-3:s.cur+1;
  else if(k==='up') s.cur=(s.cur+8)%12; else if(k==='down') s.cur=(s.cur+4)%12;
  else if(k==='z'){ const cd=s.c[s.cur]; if(cd.up||cd.done) return; cd.up=1; s.open.push(s.cur); blip(); if(s.open.length===2){ s.turns++; s.lock=0.8; } }
 },
 draw(s,c,t){
  mgSky(c,'#f2e2c0','#e4cc9a'); rect(c,0,222,MGW,48,'#b98a55');
  for(let i=0;i<12;i++){ const cd=s.c[i], x=110+(i%4)*76, y=30+((i/4)|0)*62, on=i===s.cur;
   rect(c,x,y,60,50,cd.up||cd.done?'#fff4e0':'#a8683a'); c.strokeStyle=on?'#ffd166':'#5a3a1a'; c.lineWidth=on?4:2; c.strokeRect(x,y,60,50);
   if(cd.up||cd.done){ ell(c,x+30,y+30,16,10,this.CC[cd.v]); rect(c,x+14,y+14,32,18,this.CC[cd.v]); rect(c,x+44,y+20,8,3,this.CC[cd.v]); if(cd.done) mgT(c,'ok',x+30,y+8,10,'#3a7a3a'); }
   else mgT(c,'?',x+30,y+27,22,'#e0b070'); }
  mgDuck(c,50,235,1.2); mgDuck(c,430,235,1.2,'#f4f4ee');
 }
};

/* Moonlit Dance: the same notes, a different floor */
MG.dance=Object.assign({},MG.song,{
 hint:'Follow the steps as they reach the floor tiles.', keys:'Arrows on the beat',
 how:['Dance steps glide down four lanes.','Press the matching arrow as each lands on the floor.','Keep the rhythm. The fiddler is watching.'],
 hud:s=>'Steps '+s.hit+'/'+s.notes.length,
 init(s){ MG.song.init(s); for(const n of s.notes) n.t=n.t*0.9+0.1; },
 draw(s,c,t){
  mgSky(c,'#1a1a3a','#3a2a5a'); circ(c,420,40,24,'#f4efd8'); circ(c,412,34,24,'#2a2450');
  for(let i=0;i<14;i++) circ(c,((i*53)%MGW),((i*29)%110)+8,1.5,'#fff');
  rect(c,0,222,MGW,48,'#2a2040');
  for(let i=0;i<16;i++) rect(c,i*30+((i%2)*0),228+(i%2)*12,28,10,i%3?'#3a2e5a':'#5a3e7a');
  const ks=['left','up','down','right'];
  for(let i=0;i<4;i++){ const x=150+i*60; rect(c,x-26,0,52,222,'rgba(255,255,255,0.04)'); ell(c,x,206,24,8,RGCOL[ks[i]]+'66'); rgArrow(c,x,206,ks[i],9,RGCOL[ks[i]]); }
  for(const n of s.notes){ if(n.r!==null) continue; const y=202-(n.t-s.t)*160; if(y<-10||y>230) continue; const x=150+ks.indexOf(n.k)*60; ell(c,x,y,14,7,RGCOL[n.k]); rgArrow(c,x,y,n.k,6,'#fff'); }
  const sw=Math.sin(t*6)*6; mgDuck(c,70+sw,246,1.3,'#ffd84a'); mgDuck(c,420-sw,246,1.3,'#f4f4ee');
 }
});

/* Hay Bale Maze */
MG.haymaze={
 cap:60,
 hint:'Find your way to the far corner of the maze (bottom right).', keys:'Arrows move',
 how:['A maze made of hay bales. You start in the top-left corner; the prize is waiting in the far corner, bottom right.','Move with the arrows. Hold to keep walking.','The faster you find the mouse, the better your prize.'],
 hud:s=>Math.max(0,Math.ceil(s.dur-s.t))+'s',
 init(s){
  const W=11,H=7; s.W=W; s.H=H; s.t=0; s.dur=34; s.px=0; s.py=0; s.mv=0;
  s.cell=[]; for(let y=0;y<H;y++){ s.cell.push([]); for(let x=0;x<W;x++) s.cell[y].push({v:0,w:[1,1,1,1]}); }   /* walls: up,right,down,left */
  const st=[[0,0]]; s.cell[0][0].v=1;
  while(st.length){ const [x,y]=st[st.length-1], nb=[];
   if(y>0&&!s.cell[y-1][x].v) nb.push([x,y-1,0,2]); if(x<W-1&&!s.cell[y][x+1].v) nb.push([x+1,y,1,3]); if(y<H-1&&!s.cell[y+1][x].v) nb.push([x,y+1,2,0]); if(x>0&&!s.cell[y][x-1].v) nb.push([x-1,y,3,1]);
   if(!nb.length){ st.pop(); continue; }
   const n=nb[(Math.random()*nb.length)|0]; s.cell[y][x].w[n[2]]=0; s.cell[n[1]][n[0]].w[n[3]]=0; s.cell[n[1]][n[0]].v=1; st.push([n[0],n[1]]); }
 },
 step(s,k){ const d={up:0,right:1,down:2,left:3}[k]; if(d===undefined) return; const c=s.cell[s.py][s.px]; if(c.w[d]) return; s.px+={0:0,1:1,2:0,3:-1}[d]; s.py+={0:-1,1:0,2:1,3:0}[d]; blip(); },
 update(s,dt){
  s.t+=dt; s.mv-=dt;
  if(s.mv<=0){ for(const k of ['up','down','left','right']) if(keys[k]){ this.step(s,k); s.mv=0.12; break; } }
  if(s.px===s.W-1&&s.py===s.H-1){ s.done=1; s.score=Math.min(10,5+5*(1-s.t/s.dur)); }
  else if(s.t>=s.dur){ s.done=1; s.score=Math.max(0,(s.px+s.py)/(s.W+s.H-2)*3); }
 },
 press(s,k){ this.step(s,k); s.mv=0.2; },
 draw(s,c,t){
  mgSky(c,'#cfe6a8','#e8d890'); rect(c,0,0,MGW,MGH,'#d8c070');
  const cs=34, ox=(MGW-s.W*cs)/2, oy=(MGH-s.H*cs)/2+4;
  rect(c,ox,oy,s.W*cs,s.H*cs,'#e8d890');
  c.strokeStyle='#a8782e'; c.lineWidth=5; c.lineCap='round'; c.beginPath();
  for(let y=0;y<s.H;y++) for(let x=0;x<s.W;x++){ const w=s.cell[y][x].w, X=ox+x*cs, Y=oy+y*cs;
   if(w[0]){ c.moveTo(X,Y); c.lineTo(X+cs,Y); } if(w[3]){ c.moveTo(X,Y); c.lineTo(X,Y+cs); }
   if(y===s.H-1&&w[2]){ c.moveTo(X,Y+cs); c.lineTo(X+cs,Y+cs); } if(x===s.W-1&&w[1]){ c.moveTo(X+cs,Y); c.lineTo(X+cs,Y+cs); } }
  c.stroke(); c.lineCap='butt';
  ell(c,ox+(s.W-0.5)*cs,oy+(s.H-0.5)*cs+4,9,6,'#9a9aa0'); circ(c,ox+(s.W-0.5)*cs+6,oy+(s.H-0.5)*cs,3,'#9a9aa0'); mgT(c,'prize',ox+(s.W-0.5)*cs,oy+(s.H-0.5)*cs-14,9,'#7a4a1e');
  mgDuck(c,ox+(s.px+0.5)*cs,oy+(s.py+0.9)*cs,0.9,'#ffd84a');
  mgBar(c,ox,oy+s.H*cs+8,s.W*cs,6,1-s.t/s.dur,'#e0902f');
 }
};

/* Shell Hunt: dig and read the clues */
MG.shells={
 hint:'Dig for shells. Each hole tells you how many are near.', keys:'Arrows move, Z dig',
 how:['Shells are buried in the sand: six of them.','A hole shows how many shells lie in the squares around it.','You have fourteen digs.'],
 hud:s=>'Digs '+s.digs+'  |  Shells '+s.found+'/6',
 init(s){ s.W=7; s.H=5; s.cur=0; s.digs=14; s.found=0; s.sh=new Set(); while(s.sh.size<6) s.sh.add((Math.random()*35)|0); s.dug={}; },
 near(s,i){ const x=i%7, y=(i/7)|0; let n=0; for(let dy=-1;dy<=1;dy++) for(let dx=-1;dx<=1;dx++){ if(!dx&&!dy) continue; const a=x+dx, b=y+dy; if(a<0||b<0||a>=7||b>=5) continue; if(s.sh.has(b*7+a)) n++; } return n; },
 update(s,dt){
  s.score=Math.min(10,s.found*10/5);
  if(s.found>=6||s.digs<=0){ s.done=1; s.score=Math.min(10,s.found*10/5); }
 },
 press(s,k){
  const x=s.cur%7, y=(s.cur/7)|0;
  if(k==='left') s.cur=y*7+(x+6)%7; else if(k==='right') s.cur=y*7+(x+1)%7; else if(k==='up') s.cur=((y+4)%5)*7+x; else if(k==='down') s.cur=((y+1)%5)*7+x;
  else if(k==='z'){ if(s.dug[s.cur]) return; s.dug[s.cur]=1; s.digs--; if(s.sh.has(s.cur)){ s.found++; s.msg='A shell!'; mgTone(1); } else { s.msg=''; blip(); } }
 },
 draw(s,c,t){
  mgSky(c,'#bfe6f4','#f4e8c0'); rect(c,0,0,MGW,40,'#4aa6d0'); for(let i=0;i<10;i++) rect(c,(i*52+t*20)%MGW,18+Math.sin(i+t*2)*4,34,3,'rgba(255,255,255,0.5)');
  rect(c,0,40,MGW,230,'#e8d49a');
  const cs=44, ox=(MGW-7*cs)/2, oy=52;
  for(let i=0;i<35;i++){ const x=ox+(i%7)*cs, y=oy+((i/7)|0)*cs, d=s.dug[i];
   rect(c,x+2,y+2,cs-4,cs-4,d?'#b8975a':'#dcc486');
   if(d){ if(s.sh.has(i)){ ell(c,x+cs/2,y+cs/2+2,12,9,'#f4c6e0'); c.strokeStyle='#c98ab0'; c.lineWidth=1.5; c.beginPath(); c.moveTo(x+cs/2,y+cs/2+10); c.lineTo(x+cs/2,y+cs/2-6); c.stroke(); } else mgT(c,String(this.near(s,i)),x+cs/2,y+cs/2,16,['#8a8a8a','#3a7ac8','#3a9a4a','#c8463a','#8a3ac8','#c8463a','#c8463a','#c8463a','#c8463a'][this.near(s,i)]); } }
  const cx=ox+(s.cur%7)*cs, cy=oy+((s.cur/7)|0)*cs; c.strokeStyle='#ffd166'; c.lineWidth=3; c.strokeRect(cx+1,cy+1,cs-2,cs-2);
  mgDuck(c,50,255,1.1);
 }
};

/* Quack-Off Talent Show: hold the note */
MG.quackoff={
 hint:'Follow the melody with your voice.', keys:'Hold Up / Down',
 how:['A melody line drifts across the stage.','Hold Up to raise your pitch, Down to lower it.','Stay on the line. The judges are listening.'],
 hud:s=>Math.max(0,Math.ceil(s.dur-s.t))+'s  |  On key '+Math.round(s.on/s.dur*100)+'%',
 init(s){ s.t=0; s.dur=16; s.p=0.5; s.on=0; s.ph=Math.random()*6; },
 tgt(s,t){ return 0.5+Math.sin(t*0.9+s.ph)*0.3+Math.sin(t*2.3+s.ph*2)*0.12; },
 update(s,dt){
  s.t+=dt; if(keys.up) s.p+=0.7*dt; if(keys.down) s.p-=0.7*dt; s.p=mgClamp(s.p,0.02,0.98);
  s.good=Math.abs(s.p-this.tgt(s,s.t))<0.09; if(s.good) s.on+=dt;
  s.score=Math.min(10,s.on/s.dur*11);
  if(s.t>=s.dur){ s.done=1; s.score=Math.min(10,s.on/s.dur*11); }
 },
 press(s,k){},
 draw(s,c,t){
  mgSky(c,'#3a1030','#6a2050'); rect(c,0,205,MGW,65,'#4a2a1a'); rect(c,0,205,MGW,5,'#8a5a3a');
  c.fillStyle='rgba(255,230,160,0.15)'; c.beginPath(); c.moveTo(200,0); c.lineTo(280,0); c.lineTo(340,205); c.lineTo(140,205); c.fill();
  for(let x=0;x<MGW;x+=6){ const tt=s.t+(x-120)/70, y=30+(1-this.tgt(s,tt))*150; rect(c,x,y,6,6,x<120?'rgba(255,255,255,0.15)':'#ffd166'); }
  const py=30+(1-s.p)*150; circ(c,120,py+3,9,s.good?'#7fd37a':'#ff8a8a');
  mgDuck(c,60,228,1.6,'#ffd84a'); rect(c,66,200,8,10,'#333');
  for(let i=0;i<5;i++) mgDuck(c,250+i*44,252,0.8,['#d9503f','#f4f4ee','#6ec1ff','#c58aff','#6fd08a'][i]);
  if(s.good) mgT(c,'~ quack ~',150,py-14,12,'#fff4c2');
 }
};

/* ---- mark the events as games ---- */
(function(){
  const MINI={talent:['Follow the melody with your voice.'],trivia:['Answer the quiz-master\'s questions.'],tea:['Match the teacups.'],dance:['Follow the steps on the floor.'],haymaze:['Find the way through the maze.'],shells:['Dig for shells.']};
  const all=EV_ALL.concat(...Object.values(EV_STYLE));
  for(const e of all){ if(MINI[e.id]){ e.mini=1; e.say=MINI[e.id][0]; if(e.desc.indexOf('(A game')<0) e.desc+=' (A game: take part to earn crumbs.)'; } }
  const T2={talent:'Quack-Off Talent Show',trivia:'Detective Trivia Night',tea:'Tea & Gossip Social',dance:'Moonlit Dance',haymaze:'Hay Bale Maze',shells:'Shell Hunt'};
  for(const e of all) if(T2[e.id]&&e.title!==T2[e.id]) console.warn('title mismatch',e.id,e.title);
})();
