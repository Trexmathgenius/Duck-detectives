'use strict';
/* ===== STORY II: THE LONG ROAD (chapters 5 to 20) =====
   One engine for everything after the fork:
   - a chapter state machine (S2.ch[id] = {num,title,route,start,obj,journal,tick,...}),
   - the ward clock (the Burnt Wood weakens as the story advances),
   - the consequence ledger (what you told, who you spared),
   - world helpers (story NPCs, props, zones, deadlines),
   - three reusable challenge systems: the clue board, persuasion, and (in s2sx.js) story scenes with stealth, puzzles and escorts. */

const S2={ch:{},props:new Map(),npcs:[],zones:[],h:{},bootT:0,hum:0};

/* ---------- state ---------- */
function s2(){ const st=g.story; if(!st.s2) st.s2={ch:'',step:0,fl:{},led:{},dl:{},clue:{},done:{},z:{},sx:{},route:''}; return st.s2; }
function s2on(){ const st=g.story; return !!(st&&st.s2&&st.s2.ch&&st.s2.ch!=='end'); }
function s2cur(){ return g.story&&g.story.s2?g.story.s2.ch:''; }
function s2step(){ return s2().step; }
function s2at(id,a,b){ const q=s2(); if(q.ch!==id) return false; if(a===undefined) return true; if(b===undefined) return q.step===a; return q.step>=a&&q.step<=b; }
function s2set(n){ s2().step=n; hudCache.obj=null; }
function s2fl(k,v){ const q=s2(); if(v===undefined) return q.fl[k]; q.fl[k]=v; return v; }
function s2led(k,n){ const q=s2(); if(n===undefined) return q.led[k]||0; q.led[k]=(q.led[k]||0)+n; return q.led[k]; }
function s2route(){ const q=s2(); return q.route||(g.story.isRed?'red':'crown'); }
function s2red(){ return s2route()==='red'; }
function s2num(id){ return id==='end'?21:parseInt(String(id).slice(1)); }
/* the short label shown in the objective bar and journal: "Ch 9", but a quiet hour is a "Quiet hour", never a chapter number */
function s2lab(id){
  const c=S2.ch[id], nl=c&&c.numLabel;
  if(nl&&/QUIET/i.test(nl)) return 'Quiet hour';
  const m=nl&&/^CHAPTER\s+(\S+)/i.exec(nl); if(m) return 'Ch '+m[1];
  return 'Ch '+s2num(id);
}
function s2done(id){ return !!s2().done[id]; }
function s2tile(){ return {x:Math.floor(g.px/TS), y:Math.floor((g.py-2)/TS)}; }
/* absolute hours (absT is defined in chapter3.js) */
function s2now(){ return g.day*24+g.clock; }

/* ---------- chapter flow ---------- */
const ACTS={5:'ACT II  -  TAKING A SIDE',9:'ACT III  -  THE TWO WORDS',13:'ACT IV  -  THE SLEEPERS',17:'ACT V  -  UNTIL IT IS SAFE'};
const NEXT={c5r:'c6r',c6r:'c7r',c7r:'c8r',c8r:'c9r',c9r:'c10',c5c:'c6c',c6c:'c7c',c7c:'c8c',c8c:'c9c',c9c:'c10',c10:'c11',c11:'c12',
  c13r:'c14r',c14r:'c15r',c15r:'c16r',c16r:'c17',c13c:'c14c',c14c:'c15c',c15c:'c16c',c16c:'c17',c17:'c18',c18:'c19',c19:'c20'};
function s2next(id){
  if(id==='c12') return s2red()?'c13r':'c13c';
  return NEXT[id]||null;
}
S2.begin=function(id,skipCard){
  const q=s2(), c=S2.ch[id]; if(!c){ console.warn('no chapter',id); return; }
  q.ch=id; q.step=0; q.dl={}; hudCache.obj=null; /* a new chapter never inherits the last one's deadlines */
  const go=()=>{ if(c.start) c.start(); hudCache.obj=null; };
  if(skipCard) go(); else S2.card(c,go);
};
S2.finish=function(id,msg){
  const q=s2(); q.done[id]=1; q.dl={}; /* ...and a finished chapter leaves none behind */
  const nx=s2next(id);
  if(msg) toast(msg,5200);
  if(nx) S2.begin(nx); else { q.ch='end'; hudCache.obj=null; }
};
S2.card=function(c,done){
  const num=c.numLabel||s2num(Object.keys(S2.ch).find(k=>S2.ch[k]===c)||'c0');
  const pages=(c.intro&&c.intro.length)?c.intro:[c.sub||''];
  startCutscene([{k:'teller',bg:'s2card',who:c.who||'Narrator',title:c.title,num:num,act:ACTS[num]||'',sub:c.sub||'',rt:c.theme||(c.route==='red'?'red':c.route==='crown'?'crown':'both'),pages:pages}],done,{hint:'Press X again to skip'});
};
TELLERBG.s2card=function(c,t,b){
  const pal={red:['#2a0a10','#5a1a1c','#ff9d2e'],crown:['#0a1230','#1c2c5a','#e0b84a'],both:['#150c28','#3a2455','#c9a6ff'],dark:['#050308','#1c1224','#8a6bff']}[b.rt]||['#150c28','#3a2455','#c9a6ff'];
  const g1=c.createLinearGradient(0,0,0,LH); g1.addColorStop(0,pal[0]); g1.addColorStop(1,pal[1]); c.fillStyle=g1; c.fillRect(0,0,LW,LH);
  for(let i=0;i<26;i++){ const tt=(t*0.18+i*0.071)%1, x=(i*53)%LW, y=LH-tt*LH; c.fillStyle='rgba(255,220,150,'+(0.5*(1-tt)).toFixed(2)+')'; c.fillRect(x,y,1.5,1.5); }
  c.fillStyle='rgba(0,0,0,0.25)'; c.fillRect(0,48,LW,64);
  c.fillStyle=pal[2]; c.fillRect(70,49,180,1); c.fillRect(70,111,180,1);
  c.textAlign='center'; c.textBaseline='middle';
  if(b.act){ c.font='700 6px ui-monospace,"Courier New",monospace'; c.fillStyle=pal[2]; c.fillText(b.act,LW/2,22); }
  c.font='600 7px ui-monospace,"Courier New",monospace'; c.fillStyle='rgba(234,242,220,0.8)'; c.fillText(typeof b.num==='string'?b.num:'CHAPTER '+b.num,LW/2,60);
  c.font='700 15px Georgia,serif'; c.fillStyle='#fff3d4'; c.fillText(b.title,LW/2,80);
  c.font='italic 600 7px Georgia,serif'; c.fillStyle='rgba(234,242,220,0.75)'; c.fillText(b.sub||'',LW/2,99);
  c.textAlign='left';
  vignette(c,0.45);
};

/* ---------- the ward clock ---------- */
function s2ward(){
  const id=s2cur(); if(!id) return 0; if(id==='end') return 6;
  const n=s2num(id); return n<5?0:n<9?1:n<13?2:n<17?3:n<20?4:5;
}
const WARD_LINES=[[],
  ['The ground hums. Faintly, once, like a note held by someone very far away.','A crow turns back at the edge of the north-west woods, and will not say why.'],
  ['The hum is audible now, in the quiet. The candle flames lean north-west.','The windmill sails turn on their own for a moment. Toward the Burnt Wood.'],
  ['Every shadow at the edge of the wood is a little longer than it should be.','Something cracks, far off. Not wood. Something older.'],
  ['The whole sky hums. The crystal at the castle is a sore blue thing now.','Birds sit in rows on the rooftops, all facing the same way.'],
  ['The ward is a held breath. It will not be held much longer.']];
const BW={x0:KX-92,x1:KX-40,y0:KY-82,y1:KY-47};
function inBW(x,y){ return x>=BW.x0&&x<=BW.x1&&y>=BW.y0&&y<=BW.y1; }
function s2wardUpdate(dt){
  const st=s2ward(); if(!st||st>5||g.scene!=='world'||g.mode!=='play') return;
  S2.hum-=dt; if(S2.hum>0) return; S2.hum=70+Math.random()*40;
  const p=s2tile(); if(!(inK(p.x,p.y)||inBW(p.x,p.y)||inRed(p.x,p.y))) return;
  toast(pick(WARD_LINES[Math.min(5,st)]),4200);
}
function s2wardMeter(){ const n=s2ward(); let s=''; for(let i=0;i<5;i++) s+=i<n?'#':'-'; return s; }

/* ---------- ledger ---------- */
const LED_NAMES={truth:'Truths told',lie:'Lies told',mercy:'Mercies shown',pride:'Pride swallowed',trust:'Mallow\'s trust',kin:'Poppy\'s trust',crown:'Favour of the Crown',ember:'Favour of the Hearth'};
function s2ledgerLines(line){
  /* the tally is never shown to the player */
}

/* coordinates may be absolute (wx,wy) or relative to Emberwick (red:[x,y]) or the kingdom (k:[x,y]); resolved lazily, once the world exists */
function s2xy(d){
  if(d._r) return;
  if(d.red){ d.wx=RX0+d.red[0]; d.wy=RY0+d.red[1]; } else if(d.k){ d.wx=KX+d.k[0]; d.wy=KY+d.k[1]; }
  const r=d.snap===undefined?(d.isZone?0:2):d.snap;
  if(r>0){ const p=snapFree(d.wx,d.wy,r); d.wx=p[0]; d.wy=p[1]; }
  d.key=d.wx+','+d.wy; d._r=1;
}
/* ---------- story NPCs in the world ---------- */
/* S2.npc({id,name,wx,wy,pal,head,neck,when(),talk(n,done),mark,deco,dir,still}) : wx,wy are absolute tile coordinates */
S2.npc=function(d){ S2.npcs.push(d); return d; };
function s2npcObj(d){
  if(d._o) return d._o;
  if(d.snap===undefined) d.snap=3;
  s2xy(d);
  d._o=K(d.name,d.wx-KX,d.wy-KY,d.pal===undefined?3:d.pal,d.head||null,d.neck||null,[['...']],{special:'s2',still:d.still!==false,dir:d.dir||'down',deco:d.deco,owl:true,idx:5000+S2.npcs.indexOf(d),s2:d});
  return d._o;
}
/* a chapter may define talk(n,done) to take over any NPC's conversation; return true if handled */
function s2chTalk(n){
  const q=g.story&&g.story.s2; if(!q||!q.ch) return false;
  const c=S2.ch[q.ch]; if(!c||!c.talk) return false;
  const prev=n.dir; n.dir=OPP[g.dir]; n.moving=false; n.talking=true;
  const done=()=>{ n.talking=false; n.t=1; };
  let r=false; try{ r=c.talk(n,done); }catch(e){ console.error(e); }
  if(r===true) return true;
  n.talking=false; n.dir=prev; return false;
}
{
  const _extraNpcs=extraNpcs;
  extraNpcs=function(list){
    _extraNpcs(list);
    if(g.scene!=='world'||!g.story||!g.story.s2) return;
    for(const d of S2.npcs){
      let on=false; try{ on=!d.when||d.when(); }catch(e){ on=false; }
      if(!on) continue;
      const o=s2npcObj(d);
      if(Math.abs(o.x-g.px)<TS*40&&Math.abs(o.y-g.py)<TS*30) list.push(o);
    }
  };
  const _specialTalk=specialTalk;
  specialTalk=function(n){
    if(n.special==='s2'&&n.s2){
      n.dir=OPP[g.dir]; n.talking=true; n.moving=false;
      const done=()=>{ n.talking=false; n.t=1; };
      try{ n.s2.talk(n,done); }catch(e){ console.error(e); done(); }
      return;
    }
    if(s2chTalk(n)) return;
    _specialTalk(n);
  };
  const _talkTo=talkTo;
  talkTo=function(n){ if(s2chTalk(n)) return; _talkTo(n); };
  const _npcMark=npcMark;
  npcMark=function(n){
    const q=g.story&&g.story.s2;
    if(q&&q.ch&&!n.talking){ const c=S2.ch[q.ch]; if(c&&c.mark){ let m=null; try{ m=c.mark(n); }catch(e){} if(m) return m; } }
    return _npcMark(n);
  };
  const _specialMark=specialMark;
  specialMark=function(n){
    { const q=g.story&&g.story.s2; if(q&&q.ch&&!n.talking&&n.special!=='s2'){ const c=S2.ch[q.ch]; if(c&&c.mark){ let m=null; try{ m=c.mark(n); }catch(e){} if(m) return m; } } }
    if(n.special==='s2'&&n.s2){
      if(n.talking) return null;
      const m=typeof n.s2.mark==='function'?n.s2.mark():n.s2.mark;
      if(m===false) return null;
      return {ch:m||'!',col:n.s2.markCol||'#ffd166'};
    }
    return _specialMark(n);
  };
}

/* ---------- story props in the world ---------- */
/* S2.prop({id,wx,wy,glyph,col,when(),use(p),solid}) ; absolute tile coordinates */
S2.prop=function(d){ S2.props.set(d.id,d); return d; };
function s2propAt(tx,ty){
  const k=tx+','+ty;
  for(const d of S2.props.values()){
    let on=true; try{ on=!d.when||d.when(); }catch(e){ on=false; }
    if(!on) continue;
    s2xy(d);
    if(d.key===k) return d;
  }
  return null;
}
const PGLYPH={
  stone:(c,x,y,col,t)=>{ ell(c,x+16,y+26,11,4,'rgba(0,0,0,0.25)'); c.fillStyle=col||'#6b6f78'; c.beginPath(); c.moveTo(x+6,y+26); c.lineTo(x+9,y+8); c.lineTo(x+22,y+6); c.lineTo(x+26,y+26); c.fill(); rect(c,x+14,y+12,3,10,'#ffb347'); rect(c,x+12,y+15,7,3,'#ffb347'); },
  candle:(c,x,y,col,t)=>{ rect(c,x+13,y+14,6,13,'#f4efe0'); rect(c,x+11,y+26,10,3,'#8a6a2a'); c.fillStyle='#ffb347'; c.beginPath(); c.ellipse(x+16,y+10,2.4,4+Math.sin(t*9),0,0,6.3); c.fill(); circ(c,x+16,y+10,16,'rgba(255,200,100,0.12)'); },
  scroll:(c,x,y,col)=>{ ell(c,x+16,y+26,9,3,'rgba(0,0,0,0.2)'); rect(c,x+7,y+14,18,10,'#f2e6c4'); rect(c,x+5,y+13,3,12,'#c9a46a'); rect(c,x+24,y+13,3,12,'#c9a46a'); rect(c,x+10,y+17,12,1,'#8a6a3a'); rect(c,x+10,y+20,9,1,'#8a6a3a'); },
  crystal:(c,x,y,col,t)=>{ const a=0.5+0.3*Math.sin(t*3); c.fillStyle=col||'#6ab7ff'; c.beginPath(); c.moveTo(x+16,y-2); c.lineTo(x+25,y+16); c.lineTo(x+16,y+28); c.lineTo(x+7,y+16); c.fill(); c.fillStyle='rgba(255,255,255,0.45)'; c.beginPath(); c.moveTo(x+16,y-2); c.lineTo(x+16,y+28); c.lineTo(x+7,y+16); c.fill(); circ(c,x+16,y+14,26,'rgba(110,180,255,'+(0.12*a).toFixed(2)+')'); },
  lantern:(c,x,y,col,t)=>{ rect(c,x+14,y+6,4,3,'#555'); rect(c,x+10,y+9,12,16,'#3a2a1a'); rect(c,x+12,y+11,8,12,'#ffd166'); circ(c,x+16,y+17,20,'rgba(255,190,90,'+(0.14+0.04*Math.sin(t*7)).toFixed(2)+')'); },
  chest:(c,x,y,col)=>{ ell(c,x+16,y+27,12,4,'rgba(0,0,0,0.25)'); rect(c,x+5,y+13,22,14,col||'#8a5a2b'); rect(c,x+5,y+10,22,5,'#a5703a'); rect(c,x+14,y+16,4,5,'#e0b84a'); },
  board:(c,x,y,col)=>{ rect(c,x+6,y+4,20,16,'#6b4a2f'); rect(c,x+8,y+6,16,12,'#e8d9b5'); rect(c,x+9,y+8,8,1,'#8a6a3a'); rect(c,x+9,y+11,12,1,'#8a6a3a'); rect(c,x+9,y+14,6,1,'#8a6a3a'); rect(c,x+15,y+20,3,8,'#6b4a2f'); },
  hearth:(c,x,y,col,t)=>{ rect(c,x+3,y+14,26,14,'#3a2a28'); rect(c,x+7,y+18,18,10,'#120808'); c.fillStyle='#ff7a2a'; c.beginPath(); c.moveTo(x+9,y+28); c.quadraticCurveTo(x+12,y+14+Math.sin(t*8)*2,x+16,y+8); c.quadraticCurveTo(x+22,y+16,x+23,y+28); c.fill(); c.fillStyle='#ffd166'; c.beginPath(); c.moveTo(x+12,y+28); c.quadraticCurveTo(x+14,y+20,x+16,y+16); c.quadraticCurveTo(x+19,y+21,x+20,y+28); c.fill(); circ(c,x+16,y+18,24,'rgba(255,150,70,0.12)'); },
  grave:(c,x,y,col)=>{ ell(c,x+16,y+27,10,3,'rgba(0,0,0,0.2)'); c.fillStyle=col||'#8a8e98'; c.beginPath(); c.moveTo(x+8,y+27); c.lineTo(x+8,y+12); c.quadraticCurveTo(x+16,y+2,x+24,y+12); c.lineTo(x+24,y+27); c.fill(); rect(c,x+14,y+11,4,9,'#5b5f68'); rect(c,x+11,y+14,10,3,'#5b5f68'); },
  banner:(c,x,y,col)=>{ rect(c,x+15,y+2,2,26,'#6b4a2f'); c.fillStyle=col||'#c0392b'; c.beginPath(); c.moveTo(x+17,y+4); c.lineTo(x+28,y+7); c.lineTo(x+17,y+16); c.fill(); },
  box:(c,x,y,col)=>{ ell(c,x+16,y+27,11,4,'rgba(0,0,0,0.25)'); rect(c,x+6,y+12,20,15,col||'#8a6a45'); rect(c,x+6,y+12,20,3,'#a5855a'); rect(c,x+14,y+12,4,15,'#6b4a2f'); },
  star:(c,x,y,col,t)=>{ const a=0.6+0.4*Math.sin(t*5); circ(c,x+16,y+14,14,'rgba(255,230,150,'+(0.18*a).toFixed(2)+')'); c.fillStyle=col||'#ffe9a8'; c.fillRect(x+15,y+6,2,16); c.fillRect(x+8,y+13,16,2); },
  door:(c,x,y,col)=>{ rect(c,x+6,y+2,20,26,'#4a2c18'); rect(c,x+8,y+4,16,22,col||'#7a4a24'); circ(c,x+22,y+16,1.5,'#e0b84a'); }
};
function s2drawProps(c,time){
  if(!S2.props.size) return;
  const vw=cv.width/kd, vh=cv.height/kd, ox=view.ox, oy=view.oy;
  c.setTransform(kd,0,0,kd,-ox*kd,-oy*kd);
  for(const d of S2.props.values()){
    let on=true; try{ on=!d.when||d.when(); }catch(e){ on=false; }
    if(!on) continue;
    s2xy(d);
    const px=d.wx*TS, py=d.wy*TS;
    if(px<ox-TS||px>ox+vw+TS||py<oy-TS*2||py>oy+vh+TS) continue;
    const fn=PGLYPH[d.glyph||'stone']; if(fn) fn(c,px,py,d.colf?d.colf(d):d.col,time);
    if(d.mark){ const m=typeof d.mark==='function'?d.mark():d.mark; if(m) drawMark(c,px+16,py-6,time,m,d.markCol||'#ffd166'); }
  }
  c.setTransform(1,0,0,1,0,0);
}
{
  const _drawWorld=drawWorld;
  drawWorld=function(c,W,H,kd2,camX,camY,time){
    _drawWorld(c,W,H,kd2,camX,camY,time);
    if(!g.story||!g.story.s2) return;
    s2drawProps(c,time);
    const st=s2ward();
    if(st>0){
      const p=s2tile();
      if(inBW(p.x,p.y)){
        const vw=W/kd2, vh=H/kd2, ox=view.ox, oy=view.oy;
        c.setTransform(kd2,0,0,kd2,-ox*kd2,-oy*kd2);
        const pulse=0.5+0.5*Math.sin(time*(1.2+st*0.4));
        c.fillStyle='rgba(110,70,200,'+(0.025*st+0.03*st*pulse).toFixed(3)+')'; c.fillRect(ox,oy,vw,vh);
        c.setTransform(1,0,0,1,0,0);
      }
    }
  };
  const _solidTile=solidTile;
  solidTile=function(tx,ty){
    if(g.scene==='world'&&g.story&&g.story.s2&&S2.props.size){ const p=s2propAt(tx,ty); if(p&&p.solid!==false) return true; }
    return _solidTile(tx,ty);
  };
  const _findTarget=findTarget;
  findTarget=function(){
    _findTarget();
    if(g.scene!=='world'||g.mode!=='play'||!g.story||!g.story.s2||!S2.props.size) return;
    const v=DIRV[g.dir], fx=g.px+v.x*14, fy=g.py-6+v.y*14, tx=Math.floor(fx/TS), ty=Math.floor(fy/TS);
    let p=s2propAt(tx,ty);
    if(!p){ const ox=Math.floor(g.px/TS), oy=Math.floor((g.py-2)/TS); p=s2propAt(ox,oy); }
    if(p&&!g.target) g.target={k:'s2p',p:p,x:(p.wx+0.5)*TS,y:p.wy*TS-12};
  };
  const _interact=interact;
  interact=function(){
    const tg=g.target;
    if(tg&&tg.k==='s2p'){ quack(); try{ tg.p.use(tg.p); }catch(e){ console.error(e); } return; }
    _interact();
  };
}

/* ---------- zones and deadlines ---------- */
/* S2.zone({id,wx,wy,r,when(),once,fn()}) */
S2.zone=function(d){ d.isZone=true; S2.zones.push(d); return d; };
let zoneT=0;
function s2zones(dt){
  zoneT-=dt; if(zoneT>0) return; zoneT=0.25;
  if(g.scene!=='world'||g.mode!=='play') return;
  const p=s2tile(), q=s2();
  for(const z of S2.zones){
    s2xy(z);
    if(Math.abs(p.x-z.wx)>z.r||Math.abs(p.y-z.wy)>z.r) { z._in=false; continue; }
    let on=true; try{ on=!z.when||z.when(); }catch(e){ on=false; }
    if(!on) continue;
    if(z.once!==false&&q.z[z.id]) continue;
    if(z._in) continue;
    z._in=true; if(z.once!==false) q.z[z.id]=1;
    z.fn(); return;
  }
}
/* deadlines: st.s2.dl[id]={at,label,key}; failure handler S2.h[key](id) */
S2.deadline=function(id,hours,label,key){ s2().dl[id]={at:s2now()+hours,label:label,key:key}; hudCache.obj=null; };
S2.clearDeadline=function(id){ delete s2().dl[id]; hudCache.obj=null; };
function s2deadlineText(){
  const q=s2(); let out='';
  for(const id in q.dl){ const d=q.dl[id], left=d.at-s2now(); out+='  <b>['+d.label+': '+(left>=1?Math.ceil(left)+'h':Math.max(1,Math.ceil(left*60))+'m')+' left]</b>'; }
  return out;
}
function s2deadlines(dt){
  if(!gameRunning()) return; /* a failure handler opens dialogue, so only fire it from live play */
  const q=s2(); if(!q.dl) return;
  for(const id in q.dl){
    const d=q.dl[id];
    if(s2now()>=d.at){ delete q.dl[id]; const h=S2.h[d.key]; if(h) h(id); hudCache.obj=null; }
  }
}

/* ---------- the clue board ---------- */
/* board def: {id,title,clues:{id:text},links:[{a,b,id,t}],need:[ids],q,answers:[{t,ok,no}],yes(),late}
   S2.clue(boardId,clueId,msg) adds a clue; S2.board(def,onSolved) opens it. */
S2.clue=function(bid,cid,msg){
  const q=s2(); const b=q.clue[bid]||(q.clue[bid]={have:{},solved:0});
  if(b.have[cid]) return false;
  b.have[cid]=1; coin(); toast(msg||'Clue added to your board.',3200); return true;
};
S2.hasClue=function(bid,cid){ const b=s2().clue[bid]; return !!(b&&b.have[cid]); };
S2.clueCount=function(bid){ const b=s2().clue[bid]; return b?Object.keys(b.have).length:0; };
S2.board=function(def,onSolved){
  const q=s2(); const b=q.clue[def.id]||(q.clue[def.id]={have:{},solved:0});
  const known=()=>Object.keys(b.have);
  const text=id=>def.clues[id]||(def.links.find(l=>l.id===id)||{}).t||id;
  const menu=()=>{
    choose('Case board: '+def.title,'You have '+known().length+' notes pinned. What now?',['Read the notes','Link two notes together','Name the answer','Close the board'],k=>{
      if(k===0){ const ids=known(); if(!ids.length){ say('',['The board is empty. Go and ask around.'],menu); return; } say('Notes',ids.map(text),menu); }
      else if(k===1){
        const ids=known(); if(ids.length<2){ say('',['You need at least two notes to link.'],menu); return; }
        pagedChoose('Link','Pick the first note.',ids.map(i=>text(i).slice(0,70)),a=>{
          pagedChoose('Link','Link it to...',ids.map(i=>text(i).slice(0,70)),b2=>{
            const A=ids[a], B=ids[b2];
            if(A===B){ say('',['A note linked to itself is just a note.'],menu); return; }
            const l=def.links.find(x=>(x.a===A&&x.b===B)||(x.a===B&&x.b===A));
            if(!l){ say('',['You pin string between them, step back, and frown. They do not fit.'],menu); return; }
            if(b.have[l.id]){ say('',['You have already made that connection.'],menu); return; }
            b.have[l.id]=1; coin(); say('Deduction',[l.t],menu);
          });
        });
      }
      else if(k===2){
        const need=(def.need||[]).filter(id=>!b.have[id]);
        if(need.length){ say('',['You are not sure enough yet. ('+need.length+' more connection'+(need.length>1?'s':'')+' to make.)'],menu); return; }
        choose('Case board: '+def.title,def.q,def.answers.map(a=>a.t),i=>{
          const a=def.answers[i];
          if(a.ok){ b.solved=1; say('',[a.yes||'That is it. Everything fits.'],()=>{ if(onSolved) onSolved(); }); }
          else { advanceClock(1); say('',[a.no||'You name it. Silence. Nobody believes it. An hour is lost making your case.'],menu); }
        },def.answers.length-1);
      }
    },3);
  };
  menu();
};

ITEMS.caseboard={name:'Case Board',desc:'A cork board in a leather folio, with pins and red string. Open it to read your notes and link clues together.',use:'caseboard',nogift:true};
Object.assign(RICON,{caseboard:(R,C,E)=>{ R(3,3,10,10,'#8a6238'); R(4,4,8,8,'#c9a46a'); R(5,5,2,2,'#c0392b'); R(9,6,2,2,'#3a7ca5'); R(6,9,4,1,'#c0392b'); R(7,6,3,1,'#c0392b'); }});
{
  const _u=useItem;
  useItem=function(id){
    const it=ITEMS[id];
    if(it&&it.use==='caseboard'){
      closeInv();
      const c=S2.ch[s2cur()];
      if(c&&c.board){ const b=c.board(); if(b){ S2.board(b.def,b.solved); return; } }
      say('',['The board is empty. There is nothing to pin up yet.']); return;
    }
    _u(id);
  };
}
function crownStanding(){ let best=0; for(const tw of g.towns.values()){ if(typeof RKEY!=='undefined'&&tw.key===RKEY) continue; best=Math.max(best,rankOf(g.rep[tw.key]||0)); } return best; }
/* ---------- persuasion ---------- */
/* S2.persuade({who,intro:[..],rounds:[{q, opts:[{t,p,say,req(),led:{truth:1}}]}],need,win(),lose()}) */
S2.persuade=function(d){
  let score=0, i=0;
  const next=()=>{
    if(i>=d.rounds.length){ if(score>=d.need) d.win(score); else d.lose(score); return; }
    const r=d.rounds[i++];
    const opts=r.opts.filter(o=>{ try{ return !o.req||o.req(); }catch(e){ return false; } });
    choose(d.who,r.q,opts.map(o=>o.t),k=>{
      const o=opts[k]; score+=o.p||0;
      if(o.led) for(const key in o.led) s2led(key,o.led[key]);
      if(o.fn){ try{ o.fn(); }catch(e){ console.error(e); } }
      if(o.say) say(d.who,Array.isArray(o.say)?o.say:[o.say],next); else next();
    },opts.length-1);
  };
  if(d.intro) say(d.who,d.intro,next); else next();
};

/* ---------- helpers ---------- */
function s2give(id,n){ addItem(id,n||1); coin(); }
function s2npcNear(name){ return null; }
function s2pos(wx,wy){ g.px=(wx+0.5)*TS; g.py=(wy+0.95)*TS; g.camX=g.px; g.camY=g.py-10; }
function s2absTile(lx,ly){ return [KX+lx,KY+ly]; }

/* ---------- boot, update, objective, journal ---------- */
function s2boot(dt){
  const st=g.story;
  if(!st||st.s2&&st.s2.ch) return;
  if(g.scene!=='world'||g.mode!=='play') { S2.bootT=0; return; }
  const red=st.isRed&&st.ch3Met, crown=st.dinnerDone&&st.banished;
  if(!red&&!crown) return;
  S2.bootT+=dt; if(S2.bootT<3) return;
  const q=s2(); q.route=red?'red':'crown';
  S2.begin(red?'c5r':'c5c');
}
function s2update(dt){
  if(g.mode==='title'||!g.story) return;
  s2boot(dt);
  if(!s2on()) return;
  s2wardUpdate(dt); s2zones(dt); s2deadlines(dt);
  const c=S2.ch[s2cur()]; if(c&&c.tick&&g.mode!=='cut') c.tick(dt);
}
{
  const _su=storyUpdate;
  storyUpdate=function(dt){ _su(dt); s2update(dt); };
  const _so=storyObjective;
  storyObjective=function(){
    if(s2on()){
      const c=S2.ch[s2cur()];
      if(c&&c.obj){ const o=c.obj(s2step()); if(o) return '<b>'+s2lab(s2cur())+':</b> '+o+s2deadlineText(); }
    } else if(g.story&&g.story.s2&&g.story.s2.ch==='end'){
      return 'The door is open. The story goes on, in the world you made. (Thank you for playing.)';
    }
    return _so();
  };
  const _je=journalExtra;
  journalExtra=function(sec,line){
    _je(sec,line);
    const q=g.story&&g.story.s2; if(!q||!q.ch) return;
    sec('The Long Road');
    const done=Object.keys(S2.ch).filter(id=>q.done[id]).sort((a,b)=>s2num(a)-s2num(b));
    for(const id of done){ const c=S2.ch[id]; line(s2lab(id)+', '+c.title+': '+(c.recap||'Done.'),'jdim'); }
    const c=S2.ch[q.ch];
    if(c){ line((s2lab(q.ch)==='Quiet hour'?'Quiet hour':s2lab(q.ch).replace(/^Ch /,'Chapter '))+': '+c.title); if(c.journal) c.journal(line); }
    line('The ward: ['+s2wardMeter()+']  '+['Quiet.','A first tremor.','Cracks are opening.','Armies are moving.','It is failing.','It is about to break.','It is broken.'][s2ward()]);
    s2ledgerLines(line);
  };
  /* scene-aware save: if you leave the game inside a story scene, you wake up at its door */
  const _snap=snapshot;
  snapshot=function(){ const s=_snap(); if(g.scene==='sx'&&g.saved){ s.x=g.saved.x; s.y=g.saved.y; s.dir=g.saved.dir||g.dir; } return s; };
}

/* ---------- debug hooks used by the test harness ---------- */
S2.dbg={
  jump:function(id,route){ const q=s2(); q.route=route||q.route||(id.slice(-1)==='c'?'crown':'red'); S2.begin(id,true); },
  led:s2led, set:s2set
};
