'use strict';
/* ===== BREATH CHAPTERS (v1.19) =====
   Short, quiet chapters between the big ones. Ten minutes, a fire, one person, one question.
   Their only job is to make the next big chapter hurt more. */
/* where the quiet-hour campfire is, in words plus a live compass bearing from the player */
function campWhere(){
  let txt='in the <b>Old Watchtower Hills</b>, far west of Kingsbill, beside the old watchtower';
  try{
    const d=S2.props.get('breath_fire');
    if(d&&g.scene==='world'){
      s2xy(d);
      const dx=d.wx+0.5-g.px/TS, dy=d.wy+0.5-g.py/TS, dist=Math.hypot(dx,dy);
      if(dist<8) return txt+' (right here, look for the glowing <b>!</b>)';
      const names=['east','south-east','south','south-west','west','north-west','north','north-east'];
      const dir=names[(Math.round(Math.atan2(dy,dx)/(Math.PI/4))+8)%8];
      txt+=' (about '+(Math.round(dist/5)*5)+' waddles <b>'+dir+'</b> of you)';
    }
  }catch(e){}
  return txt;
}
const BREATH_AFTER={c7r:'b7',c7c:'b7',c9r:'b9',c9c:'b9',c11:'b11',c13r:'b13',c13c:'b13',c13k:'b13',c15r:'b15',c15c:'b15',c15k:'b15',c17:'b17',c19:'b19'};
const BREATH={
 b7:{title:'Bread',sub:'A meal is a small peace.',who:'Captain Halbeak',
  intro:['The camp is quiet in the way a camp is quiet after something has not gone wrong.','Halbeak has set a pot over the fire. He is not a cook. He is stirring it as though it were a map.'],
  scene:[['Captain Halbeak',['"Sit. Eat. It is mostly barley. I am told it improves with company."','"I had a brother. He was better at this. He would sing while he cooked, always flat. After he died I stopped eating hot food for two years. It seemed rude."']]],
  q:'"Do you ever wonder if you are the kind of person who would have done what I did? Followed the order?"',
  opts:[['"I think everyone would."','tender','steady','"Yes. That is the kind answer, and the one I most want to believe."'],['"No. I would have refused."','proud','candid','"Perhaps. Many say so. I envy the certainty. I do not distrust it."'],['"I do not know. I hope I would ask."','candid','steady','"Ask. Yes. That is all I ever wanted to have done. Ask, and then, perhaps, still obey. But ask."']],
  tail:['He ladles you a second bowl you did not ask for.','"Whatever comes next," he says, "I would like it known that the barley was good."']},
 b9:{title:'Night Watch',sub:'Some things are only said at three in the morning.',who:'Warden Ruddock',
  intro:['The wall is quiet. Ruddock has asked you to take the second half of the night watch with him. He does not say why.','You sit on the parapet with a lantern between you, and the whole sleeping town below.'],
  scene:[['Warden Ruddock',['"I keep a list. Every one I have ever lost on this wall. It is eleven names. I say them, some nights. Not aloud. Only with my mouth."','"Do not tell me it was not my fault. I know it was not. That is not what the list is for."']]],
  q:'"Does it get lighter? You have lost people. I can see it. Does it get lighter?"',
  opts:[['"No. You get stronger."','steady','candid','"Yes. That is the true thing. I wish someone had told me at twenty."'],['"Yes. Eventually."','gentle','guarded','"Hm. I would like that to be true. I will carry it as a rumour."'],['Say nothing. Sit with him.','tender','steady','He nods, slowly. Neither of you speaks for a very long time. It is the best conversation you have had all year.']],
  tail:['The sky goes grey at the edges. He stands, and stretches, and says "Thank you for the second half."','It is the only time he has ever thanked anyone for anything.']},
 b11:{title:'The Boot',sub:'Poppy is mending something, and is not looking at you.',who:'Little Poppy',
  intro:['You find Poppy at the edge of the camp with a boot between her knees and a bone needle in her teeth.','It is not her boot. It is too big. She is stitching the heel very carefully, one stitch at a time.'],
  scene:[['Little Poppy',['"It is Papa\'s. He left it. He left a lot of things. Mama says that is what happens when a person leaves in a hurry, but she says it too fast."','"I am going to finish this and put it back where it was. I do not think anyone has noticed I took it."']]],
  q:'"If you knew a thing, a bad thing, and the person who did it was kind to you. What would you do?"',
  opts:[['"Tell someone. Even if it hurts."','candid','steady','"Okay." She nods, as if putting something away carefully. "I thought you would say that. I wanted you to."'],['"It depends on the thing."','guarded','candid','"Everything depends on the thing." She sounds ten years older. "That is a very grown-up answer."'],['"Tell me. Whatever it is."','tender','gentle','She does not tell you. She puts the boot down, and her small hand into yours, and holds it for a very long moment. That is the telling.']],
  tail:['She finishes the heel. She bites the thread. She looks at it for a long time.','"Do not tell anyone I was crying. I was only squinting."']},
 b13:{title:'Tea',sub:'A kettle, a quiet hour, and the question underneath.',who:'Hermit Mallow',
  intro:['Mallow does not ask you to sit. He simply puts a second cup down, as if you were already there.','The kettle ticks. It is a very old kettle. It has seen more arguments than most councils.'],
  scene:[['Hermit Mallow',['"I am going to tell you something I have told no one. When the war began, I was a boy alone in a hollow, and I saw the smoke of it from the hill for seven nights. I had a stick I called a bow. I did not go. I told myself for a hundred years it was courage."','"It was not. I could not decide which side was mine. So I did nothing, and called it peace."']]],
  q:'"Which was it, do you think? Peace or cowardice? I would like another pair of eyes."',
  opts:[['"Both. They are not opposites."','candid','steady','"Ah." He smiles, slowly. "That is the first answer in a hundred years that did not make me flinch."'],['"Peace. You were right not to."','gentle','tender','"Kind of you." He turns his cup. "I will think you said that out of kindness, and be grateful for it."'],['"Cowardice. And it still helped."','candid','proud','He laughs, once, a very dry sound. "Yes. That is the true shape of it. The worst things are often useful."']],
  tail:['He pours the last of the tea into your cup, not his.','"Whatever you choose next. Choose it with your feet. Words will betray you. Feet always know."']},
 b15:{title:'The Letter',sub:'The post comes at dusk, and one of them is for you.',who:'Little Poppy',
  intro:['A messenger-duck comes through at dusk, and hands out the post as if she were dealing cards.','There is one for you. It is not in a hand you know. It says only: "Thank you for being the kind of person I could write to."'],
  scene:[['Little Poppy',['"Who is it from?" She is looking over your shoulder, not pretending not to.','"Mama writes to Papa every week. He never writes back. She does not stop. I asked her why. She said: because the letter is for the writing, not the answering."']]],
  q:'"Do you write to anyone? Anyone who will not write back?"',
  opts:[['"Yes. More than I should."','tender','candid','"Me too." She says it very softly. "Do not tell Mama. She would want to read them."'],['"No. I should."','steady','gentle','"Then start tonight. I will lend you a quill. It is mine, but I will let you."'],['"No. There is no one."','guarded','proud','"There is." She sounds very sure. "You just have not thought of them yet. It is usually the one you are avoiding."']],
  tail:['She tucks the letter into your pack, where you can find it later.','She also tucks in a small, smudged drawing of a duck. It might be you. It might be a potato.']},
 b17:{title:'Two Fires',sub:'The night before the Tree. Everyone is awake.',who:'Captain Halbeak',
  intro:['The camp has two fires tonight. Nobody arranged it. The soldiers sit at one, and the villagers at the other, and the space between them is exactly as wide as a conversation.','Halbeak and Ruddock are standing in that space, not speaking.'],
  scene:[['Captain Halbeak',['"I have decided something," he says. "I am not going to be at the front tomorrow. I am going to be at the back. With the ones who cannot run."','Ruddock says, without turning: "That is the bravest and the stupidest thing I have heard this week." Halbeak says: "I know."']]],
  q:'"Would you stand at the back? With me? I will not ask twice."',
  opts:[['"Yes."','steady','tender','Halbeak nods once, and looks at the dark, and says nothing, and it is the best answer he could have given.'],['"I will be at the front."','proud','candid','"Then one of us will be right." He does not say which. "Go well, detective."'],['"I will be wherever I am needed."','gentle','steady','"A diplomat\'s answer." He smiles. "But I will take it. It is the one I would have given."']],
  tail:['Ruddock puts a hand on your shoulder, briefly, and takes it away again, and goes to see about the fire.','You hear him humming. It is flat. It is, you think, his brother\'s song.']},
 b19:{title:'The Last Quiet',sub:'Tomorrow is the door. Tonight is only tonight.',who:'Hermit Mallow',
  intro:['Mallow is sitting at the foot of the Old Tree with his back against it, as one sits against an old friend.','He pats the ground beside him. He does not say anything. The roots are warm.'],
  scene:[['Hermit Mallow',['"A hundred years I have been walking toward this tree. Now it is here, I find I do not want to arrive."','"I think that is what hope is, in the end. Not wanting to arrive, and going anyway."']]],
  q:'"What are you afraid of? Not about them. About you."',
  opts:[['"That I chose wrong."','candid','guarded','"Yes. So am I. It is not a thing that goes away. It only becomes familiar."'],['"That I will not be enough."','tender','gentle','"You are enough for this. You are not enough for everything. Nobody is. Rest in the difference."'],['"I am not afraid."','proud','steady','"Good. Be afraid a little anyway. It keeps the hands honest."']],
  tail:['The fire has burned down to a single orange eye.','"Go to bed, little detective," he says. "I will keep watch. I have had practice."']}
};
for(const id in BREATH){ const b=BREATH[id];
  S2.ch[id]={route:'both',theme:'both',numLabel:'A QUIET HOUR',title:b.title,sub:b.sub,intro:b.intro,recap:'A quiet hour, between two loud ones.',
    start(){ s2set(0); },
    obj(s){ return ['Go to the <b>campfire</b> '+campWhere()+', and spend a quiet hour with <b>'+b.who.replace(/^(Captain|Warden|Hermit|Little) /,'')+'</b>.'][s]||''; }
  };
}
S2.prop({id:'breath_fire',k:[-76,-26],glyph:'candle',col:'#ff9d2e',when:()=>/^b\d+$/.test(s2cur()),mark:'!',use(){
  const id=s2cur(), b=BREATH[id]; if(!b) return;
  seq(b.scene,()=>{
    choose(b.who,b.q,b.opts.map(o=>o[0]),k=>{
      const o=b.opts[k]; const h=S4st().h; h[o[1]]++; if(o[2]) h[o[2]]++;
      S4.setcx(id,String(k),null);
      say(b.who,[o[3]].concat(b.tail),()=>{ coin(); S2.finish(id,'A quiet hour, kept.'); });
    },b.opts.length-1);
  });
}});
/* wrap the flow: breath after the big chapter, then onward */
{
  const _sn=s2next;
  s2next=function(id){
    const q=s2();
    if(/^b\d+$/.test(id)) return q.bnext||null;
    const nx=_sn(id);
    const b=BREATH_AFTER[id];
    if(b&&!q.done[b]&&nx){ q.bnext=nx; return b; }
    return nx;
  };
}
/* what the quiet hour changes in the loud one that follows */
rc(['Captain Halbeak','Warden Ruddock','Elder Cinder'],'rb7',()=>S4.cx('b7')!==undefined,['(Halbeak, not quite looking at you:) "I have been meaning to say. The barley was not good. I wanted it to be."']);
rc(['Warden Ruddock','Captain Halbeak'],'rb9',()=>S4.cx('b9')!==undefined,['(Ruddock nods at you, once, like a man acknowledging a gift.) "There are twelve names, now. I added one. I won\'t say whose."']);
rc(['Little Poppy'],'rb11',()=>S4.cx('b11')!==undefined,['(She is holding the boot, mended. She puts it down as you approach, as if it were hot.) "I put it back. Nobody noticed. That is what I wanted. Mostly."']);
rc(['Hermit Mallow','Archivist Sorrel'],'rb13',()=>S4.cx('b13')!==undefined,['"I have thought about what you said, by the fire. I have not decided whether to be pleased or annoyed. I suspect both."']);
rc(['Little Poppy','Hermit Mallow'],'rb15',()=>S4.cx('b15')!==undefined,['(Poppy waves a scrap of paper at you.) "I wrote to Papa. I did not send it. It was enough to write it."']);
rc(['Captain Halbeak','Warden Ruddock'],'rb17',()=>S4.cx('b17')!==undefined,['(He is at the back of the line, as he said. He gives you a small, rueful nod.) "It is very draughty back here. I recommend it."']);
rc(['Hermit Mallow','Bree'],'rb19',()=>S4.cx('b19')!==undefined,['"I did not sleep. I never do, before something. But I am glad of the hour. It will be the first thing I remember."']);
