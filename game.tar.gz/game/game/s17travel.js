'use strict';
/* ===== PEOPLE WHO ASK FOR YOU ARE SOMEWHERE ELSE =====
   The road requests (s11story.js) and the crossroads moments (s4depth.js) used to put their person on the tile next to
   you the moment they appeared, so there was nothing to travel to. They now stand at a real place, a good walk away,
   and the game says which way and how far. farSpot() picks that place:
   - between minD and maxD tiles from where you stand,
   - reachable on foot (a flood-fill over walkable tiles, so never on an island or inside a wall),
   - preferably on a road or path, so it feels like somewhere people would wait. */
(function(){
const DIRS=['east','south-east','south','south-west','west','north-west','north','north-east'];
const free=(x,y)=>{ try{ return !SOLID.has(tileAt(x,y)); }catch(e){ return false; } };
function bearing(x,y){
  const dx=x+0.5-g.px/TS, dy=y+0.5-g.py/TS, dist=Math.hypot(dx,dy);
  return {dist:Math.round(dist),dir:DIRS[(Math.round(Math.atan2(dy,dx)/(Math.PI/4))+8)%8]};
}
function find(minD,maxD,avoid){
  try{
    const p=s2tile(), lim=maxD+6, seen=new Map(), q=[[p.x,p.y]]; seen.set(p.x+','+p.y,1);
    const cand=[];
    for(let h=0;h<q.length&&q.length<16000;h++){
      const [x,y]=q[h]; const d=Math.hypot(x-p.x,y-p.y);
      if(d>=minD&&d<=maxD){
        let ok=true; if(avoid) for(const a of avoid){ if(Math.hypot(a[0]-x,a[1]-y)<12){ ok=false; break; } }
        if(ok) cand.push([x,y,tileAt(x,y)===T.PATH?3:1]);
      }
      for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){
        const nx=x+dx, ny=y+dy, k=nx+','+ny;
        if(seen.has(k)||Math.abs(nx-p.x)>lim||Math.abs(ny-p.y)>lim||!free(nx,ny)) continue;
        seen.set(k,1); q.push([nx,ny]);
      }
    }
    if(!cand.length) return null;
    let tot=0; for(const c of cand) tot+=c[2];
    let r=Math.random()*tot; let pick=cand[cand.length-1];
    for(const c of cand){ r-=c[2]; if(r<=0){ pick=c; break; } }
    const b=bearing(pick[0],pick[1]);
    return {x:pick[0],y:pick[1],dist:b.dist,dir:b.dir};
  }catch(e){ console.error('farSpot',e); return null; }
}
/* if the surroundings are cramped (a walled wood, say), widen the search before giving up */
window.farSpot=function(minD,maxD,avoid){ return find(minD,maxD,avoid)||find(Math.max(10,minD*0.5),maxD+24,avoid)||find(6,maxD+24,null); };
window.farBearing=bearing;
/* the journal keeps the bearing of a crossroads person, as it already does for road requests */
{
  const _je=journalExtra;
  journalExtra=function(sec,line){
    _je(sec,line);
    try{
      if(typeof CXS!=='undefined'&&CXS.active&&CXS.at){
        const b=bearing(CXS.at[0],CXS.at[1]); sec('Someone Is Waiting');
        line(CXS.active.who[0]+(b.dist<5?' (right here)':' ('+b.dir+', about '+b.dist+' waddles)'));
      }
    }catch(e){}
  };
}
})();
