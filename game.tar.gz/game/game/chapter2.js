'use strict';
/* ===== CHAPTER 2: THE RED DUCKS =====
   The castle gate -> a faint vision -> the cold campfires -> the hermit's tale -> a book hidden in the library
   -> the cipher -> the Hollow Wood and the hidden town of Emberwick -> rejection -> the hermit's trust (the lost Edict pages).
   Everything for the chapter lives in this file; the older files are only lightly touched. */

/* ---------- new tiles ---------- */
const KCAMP=63, KPAGE=64;
SOLID.add(KCAMP); INTERACTIVE.add(KCAMP); INTERACTIVE.add(KPAGE);
MAPCOL[KCAMP]='#6b6f78'; MAPCOL[KPAGE]='#5b9a4e';

/* ---------- geography (all local to the kingdom origin KX,KY) ---------- */
/* the cold campfires: from just outside the east gate, up the lake road to the hermit's hollow */
const CAMPS=[[65,2],[66,-3],[64,-9],[64,-16],[64,-22],[64,-40],[66,-53],[70,-54]];   /* the first fire is just below the East Gate (the first cold-fire stone says so); none are inside the walls */
/* the three hidden pages of the Red Edict: with the dead, with the watchers, with the swans */
const PAGES=[[-71,30],[-79,-30],[79,-24]];
/* the Hollow Wood: 7x7 glades of 14x14 tiles, north-east of the kingdom; Emberwick is the middle glade */
const WN=7, WC=14, WSZ=WN*WC, WCX=KX+170, WCY=KY-175, WX0=WCX-WSZ/2, WY0=WCY-WSZ/2, WM=22;   /* WM: width of the dark forest ring around the glades */

const wood={epoch:0,epochT:0,route:null,idx:0,cell:null,cellT:0,still:0,lastX:0,lastY:0,cueOn:false,cueVec:null,pulse:0,arrived:false,hintedNo:false,hintedYes:false};

function inWood(tx,ty){ return tx>=WX0-WM&&tx<WX0+WSZ+WM&&ty>=WY0-WM&&ty<WY0+WSZ+WM; }
function woodRim(x,y){ return Math.max(0,WX0-x,x-(WX0+WSZ-1),WY0-y,y-(WY0+WSZ-1)); }   /* tiles outside the glades, 0 inside */

function ch2Tile(x,y){
  if(inWood(x,y)) return woodTile(x,y);
  const s=g.story;
  if(!s) return null;
  const lx=x-KX, ly=y-KY;
  if(lx<-100||lx>110||ly<-90||ly>60) return null;
  if(s.visionSeen){
    for(let i=0;i<CAMPS.length;i++) if(CAMPS[i][0]===lx&&CAMPS[i][1]===ly) return KCAMP;
    if(lx===63&&ly>=-52&&ly<=-2) return ly===-27?KBRIDGE:T.PATH;
    if(ly===-52&&lx>=63&&lx<=71) return T.PATH;
    if(lx===71&&ly>=-56&&ly<=-52) return T.PATH;
  }
  if(s.pagesQuest){
    for(let i=0;i<PAGES.length;i++) if(PAGES[i][0]===lx&&PAGES[i][1]===ly&&!(s.pages&&s.pages[i])) return KPAGE;
  }
  return null;
}
function ch2BlocksTown(rx,ry){
  const cx=rx*REG, cy=ry*REG;
  return Math.abs(cx-WCX)<WSZ/2+60&&Math.abs(cy-WCY)<WSZ/2+60;
}
function ch2Dark(x,y){ return inWood(x,y)?0.88-0.5*woodRim(x,y)/WM:0; }
function ch2Area(tx,ty){
  if(!inWood(tx,ty)) return null;
  const gx=tx-WX0, gy=ty-WY0;
  if(gx>=3*WC&&gx<4*WC&&gy>=3*WC&&gy<4*WC&&wood.arrived) return 'Emberwick';
  return 'The Hollow Wood';
}

/* ---------- the Hollow Wood ---------- */
function woodTile(x,y){
  const gx=x-WX0, gy=y-WY0, ep=wood.epoch;
  if(gx<0||gy<0||gx>=WSZ||gy>=WSZ){
    /* the way in: a short path south of the first glade */
    if(gy>=WSZ&&gy<WSZ+WM&&gx>=5&&gx<=8){
      if(gy===WSZ+1&&(gx===5||gx===8)) return T.MUSH;
      if(gy<WSZ+9) return (gx===6||gx===7)?T.PATH:T.GRASS;
      return hash(x,y,7003)<0.1?T.MUSH:T.GRASS;
    }
    const d=woodRim(x,y), p=0.88-0.5*(d-1)/(WM-1);
    if(hash(x,y,7000)<p) return hash(x,y,7001)<0.1?T.ROCK:T.TREE;
    return hash(x,y,7002)<0.25?T.MUSH:T.GRASS;
  }
  const i=Math.floor(gx/WC), j=Math.floor(gy/WC), u=gx%WC, v=gy%WC;
  const wallU=(u===0||u===WC-1), wallV=(v===0||v===WC-1);
  if(wallU||wallV){
    const gU=(u>=5&&u<=8), gV=(v>=5&&v<=8);
    let open=false;
    if(u===0&&!wallV&&gV&&i>0) open=true;
    if(u===WC-1&&!wallV&&gV&&i<WN-1) open=true;
    if(v===0&&!wallU&&gU&&j>0) open=true;
    if(v===WC-1&&!wallU&&gU&&(j<WN-1||i===0)) open=true;
    if(open) return hash(x,y,7010)<0.12?T.MUSH:T.GRASS;
    const h=hash(x,y,7011);
    return h<0.78?T.TREE:(h<0.9?T.ROCK:T.STUMP);
  }
  if(i===3&&j===3) return villageTile(x,y,u,v);
  const cross=(u>=5&&u<=8)||(v>=5&&v<=8);
  if(!cross){
    const h=hash(x,y,7100+ep*13);
    if(h<0.42) return hash(x,y,7101+ep)<0.12?T.ROCK:T.TREE;
    if(h<0.48) return T.MUSH;
    return T.GRASS;
  }
  const h2=hash(x,y,7200+ep*7);
  if(h2<0.05) return T.MUSH;
  if(h2<0.10) return T.FLOWER;
  return T.GRASS;
}

/* ---------- Emberwick: four round houses and a fire in the square ---------- */
const RHOUSES=[];
function rvList(){
  if(RHOUSES.length) return RHOUSES;
  const cx0=WX0+3*WC, cy0=WY0+3*WC;
  const defs=[[1,1,'#9b2d20','#f0cfc0'],[9,1,'#b5483a','#e8d9b5'],[1,8,'#c0583a','#d9e2c9'],[9,8,'#8a2a2a','#f0cfc0']];
  for(const d of defs) RHOUSES.push({x:cx0+d[0]-KX,y:cy0+d[1]-KY,w:4,h:4,type:'rhouse',name:'Emberwick house',roof:d[2],wall:d[3]});
  return RHOUSES;
}
function ch2Building(lx,ly){
  if(lx<150) return null;
  for(const b of rvList()) if(lx>=b.x&&lx<b.x+b.w&&ly>=b.y&&ly<b.y+b.h) return b;
  return null;
}
function villageTile(x,y,u,v){
  const b=ch2Building(x-KX,y-KY);
  if(b) return kBuildTile(b,x-KX,y-KY);
  if(u===6&&v===6) return T.FIRE;
  if((u===5||u===8)&&(v===5||v===8)) return T.LAMP;
  if(u===6||u===7||v===6||v===7) return T.PATH;
  return hash(x,y,7300)<0.14?T.FLOWER:T.GRASS;
}
let vNpcs=null;
function villageNpcs(){
  if(vNpcs) return vNpcs;
  const cx0=WX0+3*WC, cy0=WY0+3*WC;
  const V=(name,u,v,pal,head,neck,lines,dir)=>K(name,cx0+u-KX,cy0+v-KY,pal,head,neck,lines,{still:true,dir:dir||'down'});
  vNpcs=[
    V('Elder Cinder',7,7,RED_PAL[0],'hood','scarf',[['You should not be here, child. Not because we are cruel. Because we remember.']],'left'),
    V('Warden Ruddock',6,10,RED_PAL[1],'helm',null,[['Nobody passes the Wood. Nobody.']],'up'),
    V('Little Poppy',8,7,RED_PAL[1],'bow',null,[['A yellow one! A real yellow one!']],'left'),
    V('Baker Ember',4,6,RED_PAL[0],'cap','bowtie',[['The bread here is red-crusted. It is the beetroot. Do not ask.']],'right')
  ];
  return vNpcs;
}

/* ---------- chapter state ---------- */
function seq(list,done){
  let i=0;
  const next=()=>{ if(i>=list.length){ if(done) done(); return; } const it=list[i++]; say(it[0],it[1],next); };
  next();
}
function hermitObj(){ return kNpcList().find(n=>n.name==='Hermit Mallow'); }
/* Mallow stops following and goes back to his own cottage (he does not stay where he last stood, and he is not at the king's gate) */
function hermitGoHome(){ const st=g.story; st.hermitFollow=0; const h=hermitObj(); if(h){ h.x=h.hx; h.y=h.hy; h.moving=false; h.talking=false; h.dir='down'; } }
function pagesFound(){ const p=g.story.pages; return p?Object.keys(p).length:0; }

/* the dizzy spell at the castle gate that sets the whole chapter going */
function startFaint(){
  const st=g.story;
  st.faintStarted=1; st.visionSeen=1; tileCache.clear();
  say('',[
    'The chanting behind the bars rises and falls like a tide. Your knees feel strange. The cobblestones tilt.',
    'You feel faint. The world goes soft at the edges, and the smell of woodsmoke finds you from somewhere that is not here...'
  ],()=>startCutscene(VISION,visionEnd,{hint:'Press X again to skip the vision'}));
}
const VISION=[
  {k:'anim',scene:'hermitHome',dur:10,cap:'A vision: a cottage in a quiet hollow'},
  {k:'anim',scene:'reunion',dur:12,cap:'...and a joyful reunion'}
];
function visionEnd(){
  fade(1.6);
  say('',[
    'You come to on the cold stones, heart pounding. Guard Teal is fanning you with his helmet.',
    'The vision was so clear. A little cottage in flowers. A red duck, laughing, lost in a crowd of his own kind. And along the road to his door, small campfires, every one of them burned out.',
    'He is the hermit in the hollow east of the city. You have to follow the extinguished campfires to find him.'
  ]);
}

/* nearest unvisited cold fire, as an arrow and a distance */
function nextCamp(){
  const st=g.story; st.camps=st.camps||{};
  for(let i=0;i<CAMPS.length;i++){
    if(st.camps[i]) continue;
    const dx=(KX+CAMPS[i][0]+0.5)*TS-g.px, dy=(KY+CAMPS[i][1]+0.5)*TS-g.py;
    const a=Math.atan2(dy,dx), k=((Math.round(a/(Math.PI/4))%8)+8)%8;
    return ARROWS[k]+' '+Math.round(Math.hypot(dx,dy)/TS);
  }
  return null;
}
function campIndex(tx,ty){
  const lx=tx-KX, ly=ty-KY;
  for(let i=0;i<CAMPS.length;i++) if(CAMPS[i][0]===lx&&CAMPS[i][1]===ly) return i;
  return -1;
}
function campInteract(tx,ty){
  const i=campIndex(tx,ty), st=g.story; st.camps=st.camps||{};
  const first=!st.camps[i]; st.camps[i]=1;
  let dir='';
  if(i<CAMPS.length-1){
    const a=CAMPS[i], b=CAMPS[i+1], dx=b[0]-a[0], dy=b[1]-a[1];
    dir=Math.abs(dx)>=Math.abs(dy)?(dx>0?'east':'west'):(dy>0?'south':'north');
  }
  if(i===CAMPS.length-1){
    say('',['The last of the cold fires. A thin thread of chimney smoke rises just ahead, from a cottage in a garden of flowers.','Someone lives there. Someone has been waiting a very long time.']);
  } else {
    say('',[first?'The ashes are cold, the stones set back carefully in a ring. A single red feather lies on the embers, pointing '+dir+'.':'Cold ashes, stones in a tidy ring. The red feather still points '+dir+'.']);
    if(first) toast('Cold fires found: '+Object.keys(st.camps).length+' / '+CAMPS.length,2400);
  }
}

/* ---------- the hermit ---------- */
const HERMIT_TALE=[
  {k:'teller',bg:'hollow',who:'Hermit Mallow',pages:['I was a duckling once. Red as a berry, and proud of it.','Mallardia was home. My mother kept bees on the south hill, and I chased them, and they never once stung me.']},
  {k:'anim',scene:'kidJoy',dur:11,cap:'Mallardia, before the Edict'},
  {k:'teller',bg:'hollow',who:'Hermit Mallow',pages:['I was happy. I did not know that red was a thing anyone could mind.','Then one morning the bells rang, and the whole city went quiet.']},
  {k:'anim',scene:'castOut',dur:12,cap:'The king casts them out'},
  {k:'teller',bg:'hollow',who:'Hermit Mallow',pages:['King Eider himself stood on the balcony and read it. He did not look at us.','They gave us what we could carry. We walked until the road ended. And then we kept walking.']}
];
function hermitIntro(n,done){
  const st=g.story;
  st.hermitTold=1; st.libHint=1; if(!g.inv.decoder) addItem('decoder');
  seq([
    ['Hermit Mallow',['You followed the fires. Nobody has followed the fires since I did, a hundred years ago.','They are ours. On the march north we put each campfire out at dawn, so the king\'s soldiers could not follow the smoke. Every spring I walk back and set the stones straight.','You have the look of someone who has been shown things. Sit. Let me show you one of mine.']]
  ],()=>{
    startCutscene(HERMIT_TALE,()=>{
      fade(1.2);
      seq([
        ['Hermit Mallow',['So. That is how it was. And then I was a duckling with a bundle on a long, cold road.','Most of us were never soldiers.','We were bakers and beekeepers and singers. When Gordamom raised his banner, most of us only wanted to keep walking. The kingdom remembers the army. Nobody remembers the bakers.']],
        ['Hermit Mallow',['Listen, because I will say this once. There is a book about my people. The Crown burned every record of us, but one clerk could not bear it.','He hid the truth in a book in the Royal Library of Kingsbill, written in a cipher. The librarians have forgotten it exists.','The Royal Library is open to anyone who cares to walk in. Nobody ever does.']],
        ['Hermit Mallow',['Inside, go to the north wall. The fourth shelf from the west corner. A dull grey spine: "Pondweed, Volume Nine". Nobody has ever pulled Pondweed. Pull it.']],
        ['Hermit Mallow',['And take this. My father was a scribe. Two brass rings, A to Z on one, Z to A on the other. Turn the scribbles back into words.','Received: Cipher Decoder.','Go. Learn what the Crown could not burn. Then come back and tell me whether an old duck should hope.']]
      ],done);
    },{hint:'Press X again to skip'});
  });
}

function hermitTalk(n){
  const st=g.story;
  if(!st.visionSeen) return false;
  n.dir=OPP[g.dir]; n.moving=false; n.talking=true;
  st.met=st.met||{}; st.met[n.name]=1;
  const done=()=>{ n.talking=false; n.t=1; };
  const H='Hermit Mallow', P='Detective Duck';
  if(!st.hermitTold){ hermitIntro(n,done); return true; }
  if(st.ch2Done){
    say(H,[pick(['Lead on, little detective. I am right behind you.','Mind the Wood. It does not like a crowd. Then again, neither do I.','Hm-hm-hmm. Sorry. The old tune. It will not leave my head now.'])],done);
    return true;
  }
  if(st.pagesQuest){
    const n3=pagesFound();
    if(n3>=3){ hermitFinale(n,done); return true; }
    say(H,['The pages, little detective. One in the ash beside the red banner. One in the ruined tower in the west hills. One on the island in the lake.','You have '+n3+' of 3. Bring me all three and I will follow you to the end of the world.'],done);
    return true;
  }
  if(st.rejected){
    choose(H,'You look like a duck who has been somewhere.',['Tell him about Emberwick','Not yet'],k=>{
      if(k===0) hermitSuspicion(n,done); else done();
    },1);
    return true;
  }
  if(st.bookRead){
    say(H,['You have read it? Then go and see for yourself. The red ducks of the north-east, if there are any. Come back and tell me what you find.'],done);
    return true;
  }
  if(st.bookFound){
    say(H,['You found it! Now use the decoder. Open your pack, pick the book, and turn the rings.'],done);
    return true;
  }
  say(H,['The library, little detective. North wall, fourth shelf from the west corner. "Pondweed, Volume Nine".'],done);
  return true;
}
function hermitSuspicion(n,done){
  const st=g.story, H='Hermit Mallow', P='Detective Duck';
  st.toldHermit=1; st.pagesQuest=1; tileCache.clear();
  seq([
    [P,['They are real, Mallow. A whole village, hidden in a forest that moves. Emberwick. Every single one of them red.','They would not listen to me. But they might listen to you. Come with me.']],
    [H,['...Emberwick.','My mother used to sing about a place with a hearth that never went out. I thought it was a lullaby. I thought it was only a song.']],
    [H,['But you ask an old red duck to walk into a hidden wood on the word of a yellow-feathered stranger who walked in off the road?','The Crown has laid traps for us before. A kind face, a promise, a road. And at the end of it, a net.','I want to believe you. That is exactly why I cannot.']],
    [H,['Prove you are no friend of the Crown. The Edict was cut into three pages and hidden by those who were ashamed of it. Whoever holds all three holds the truth.','One lies with the dead, in the ash of the Siege Field, near the red banner.','One lies with the watchers, in the ruined tower in the western hills. One lies with the swans, on the island in the lake, where a duck who cannot swim would never go.','Bring me the pages. Then I will follow you anywhere.']]
  ],done);
}
function hermitFinale(n,done){
  const st=g.story, H='Hermit Mallow';
  seq([
    ['',['Hermit Mallow takes the three pages and lays them side by side on his knee. His wing is not quite steady.']],
    [H,['"It was not the red ducks I feared." In his own hand. And he still read the Edict from the balcony. And he still did not look at us.','A hundred years I have carried that morning. And the one who ordered it was afraid of something else the whole time.']],
    [H,['I do not know what that something is. I think you might be the only one who can find out.','You did not have to bring me these. You did. That is enough.','All right, little detective. Emberwick. Lead on. I will follow.']],
    ['',['Hermit Mallow falls in step beside you, his lantern swinging, humming a tune the old ducks hum when they think no one is listening.','It is not a dark tune at all. It is a lullaby.','- End of Chapter 2 -']]
  ],()=>{
    st.ch2Done=1; st.hermitFollow=1;
    toast('Chapter 2 complete. The hermit follows you.',5200);
    done();
  });
}

/* the hermit tags along once he trusts you */
function followUpdate(dt){
  const st=g.story;
  if(!st.hermitFollow||g.scene!=='world'||g.mode==='title') return;
  const n=hermitObj(); if(!n) return;
  n.still=true;
  const dx=g.px-n.x, dy=g.py-n.y, d=Math.hypot(dx,dy);
  if(n.talking){ n.moving=false; return; }
  if(d>TS*10){ n.x=g.px-26; n.y=g.py; n.moving=false; return; }
  if(d>TS*2.4){
    const sp=112*dt, nx=n.x+dx/d*sp, ny=n.y+dy/d*sp;
    n.moving=true; n.phase+=dt*10;
    n.dir=Math.abs(dx)>Math.abs(dy)?(dx>0?'right':'left'):(dy>0?'down':'up');
    if(!npcBlocked(nx,ny,n)){ n.x=nx; n.y=ny; }
    else if(!npcBlocked(nx,n.y,n)) n.x=nx;
    else if(!npcBlocked(n.x,ny,n)) n.y=ny;
  } else n.moving=false;
}

/* ---------- the book, the cipher, the pages ---------- */
const BOOK=[
  'THE RED CLANS OF THE NORTH. Of the ducks cast out by the Edict, most did not follow Gordamom. They wanted no war. They wanted a roof.',
  'They walked north and east, where the hills fold into one another, and built a small town. They named it Emberwick. No feather in it is any colour but red.',
  'None have been seen in years. Those who went looking never found it. The forest around Emberwick moves, so that it is never in the same place twice.',
  'THE TRICK OF THE HOLLOW WOOD. The wood moves because it is afraid. It does not move for one who is still.',
  'In each glade, stand quiet and count to three. A red feather will fall, and it falls toward the true way. Follow it, glade by glade. Never turn back.',
  'In the margin, in a different ink: the Edict was cut into three pages and hidden, so that no one could ever read it whole. Whoever holds all three will know who truly wrote it.'
];
function atbash(s){
  return s.replace(/[a-z]/gi,ch=>{ const b=ch<='Z'?65:97; return String.fromCharCode(b+25-(ch.charCodeAt(0)-b)); });
}
function useBook(decodedAlready){
  const st=g.story;
  if(!decodedAlready){
    if(!g.inv.decoder){ say('',['Loops, spirals and tiny stars. You need some way to turn them back into words.']); return; }
    delInv('redbook'); addItem('redbookd'); st.bookRead=1; coin();
    const pages=['Scribbles. "'+atbash(BOOK[0].slice(0,34))+'..." Nonsense. You hold the Cipher Decoder over the page. A is Z. B is Y. C is X. The rings click, letter by letter.','Words rise out of the scribbles, one by one, like fish.'].concat(BOOK).concat(['Emberwick. A town of red ducks, hidden north-east of the kingdom, in a forest that moves. And a trick to get through it. It is all in your journal now (J).']);
    say('',pages);
    return;
  }
  say('',['You turn to the decoded pages once more.'].concat(BOOK));
}
const PAGE_TEXT=[
  'THE RED EDICT, the first page. By order of the Crown of Mallardia: every duck hatched in red plumage shall be sent beyond the northern hills, for the safety of the realm.',
  'THE RED EDICT, the second page. Those sent away may not return while the Crown\'s mark is upon them. This law may be undone by the Crown alone, and by none who follow after.',
  'THE RED EDICT, the third page. Sealed: EIDER, King. And in the margin, in a shakier hand: "It was not the red ducks I feared."'
];
const PAGE_WHERE=[
  'Something pale in the ash between two graves: a page folded very small and tied with red thread. It was left here on purpose.',
  'Under a fallen stone in the ruined tower, wrapped in oilcloth, a page tied with red thread. Whoever hid it knew the wind would never find it.',
  'On the little island, wedged under a flat stone, wrapped in oilcloth and tied with red thread: a page. You get your feathers wet. It is worth it.'
];
function pageInteract(tx,ty){
  const lx=tx-KX, ly=ty-KY, st=g.story; st.pages=st.pages||{};
  let idx=-1; for(let i=0;i<PAGES.length;i++) if(PAGES[i][0]===lx&&PAGES[i][1]===ly) idx=i;
  if(idx<0||st.pages[idx]) return;
  st.pages[idx]=1; addItem('edictpage'); coin(); tileCache.clear();
  const n=pagesFound();
  say('',[PAGE_WHERE[idx],PAGE_TEXT[idx],'Edict pages: '+n+' / 3.'+(n>=3?' That is all three. Take them to Hermit Mallow.':'')]);
}
function readPages(){
  const st=g.story, got=[];
  for(let i=0;i<3;i++) if(st.pages&&st.pages[i]) got.push(PAGE_TEXT[i]);
  if(!got.length){ say('',['You have no pages yet.']); return; }
  say('',got);
}

/* ===== CUTSCENE ART: the vision, the hermit's memories, the recollection ===== */
const REDDUCK={body:'#c0392b',wing:'#962d22',bill:'#ff9d2e'};
const TELLERBG={};

function coldFire(c,x,y,s,t){
  ell(c,x,y+1,9*s,3*s,'rgba(0,0,0,0.3)');
  for(let i=0;i<8;i++){ const a=i*0.785; ell(c,x+Math.cos(a)*7*s,y+Math.sin(a)*2.6*s,2.4*s,1.8*s,'#6b6f78'); }
  ell(c,x,y,5.5*s,2*s,'#2a2624'); rect(c,x-4*s,y-2*s,8*s,1.6*s,'#1c1816'); rect(c,x-3*s,y-3.4*s,6*s,1.4*s,'#26201c');
  for(let i=0;i<3;i++){ const tt=(t*0.25+i*0.33)%1; ell(c,x+Math.sin(t+i*2)*1.5*s,y-4*s-tt*16*s,(1.6+tt*2)*s,(1+tt)*s,'rgba(170,170,180,'+(0.35*(1-tt)).toFixed(2)+')'); }
  c.fillStyle='#c0392b'; c.beginPath(); c.moveTo(x-2*s,y-1.5*s); c.quadraticCurveTo(x,y-5*s,x+3*s,y-3*s); c.quadraticCurveTo(x+1*s,y-1*s,x-2*s,y-1.5*s); c.fill();
}
function heart(c,x,y,s,col){
  c.fillStyle=col; c.beginPath(); c.moveTo(x,y+3*s); c.bezierCurveTo(x-6*s,y-1*s,x-3*s,y-5*s,x,y-2*s); c.bezierCurveTo(x+3*s,y-5*s,x+6*s,y-1*s,x,y+3*s); c.fill();
}
function vignette(c,a){
  const gr=c.createRadialGradient(LW/2,LH/2,LH*0.35,LW/2,LH/2,LW*0.7); gr.addColorStop(0,'rgba(10,0,30,0)'); gr.addColorStop(1,'rgba(10,0,30,'+a+')');
  c.fillStyle=gr; c.fillRect(0,0,LW,LH);
}

/* the vision, part one: the hermit's cottage, the road of cold fires */
SCENES.hermitHome=function(c,t){
  c.save(); const z=1+0.07*Math.min(1,t/10); c.translate(LW/2,LH/2+10); c.scale(z,z); c.translate(-LW/2,-LH/2-10);
  sky(c,'#3b2a6b','#f0a56b',24);
  circ(c,236,100,28,'rgba(255,200,140,0.22)'); circ(c,236,100,17,'#ffd9a0');
  c.fillStyle='#4a3a78'; c.beginPath(); c.moveTo(-10,120); for(let x=-10;x<=LW+10;x+=16) c.lineTo(x,108+Math.sin(x*0.03)*10); c.lineTo(LW+10,LH); c.lineTo(-10,LH); c.fill();
  const pines=(y,col,sz,off)=>{ c.fillStyle=col; for(let i=-1;i<12;i++){ const x=i*32+off; c.beginPath(); c.moveTo(x,y); c.lineTo(x+14,y-sz); c.lineTo(x+28,y); c.fill(); } };
  pines(132,'#2c2457',44,6); pines(142,'#231c47',54,-8);
  c.fillStyle='#3f6f45'; c.fillRect(-10,140,LW+20,50); c.fillStyle='#4a8350'; c.fillRect(-10,150,LW+20,40);
  /* the cottage */
  c.fillStyle='#e8d9b5'; c.fillRect(190,98,58,42); c.fillStyle='rgba(0,0,0,0.1)'; c.fillRect(190,110,58,1); c.fillRect(190,122,58,1);
  c.fillStyle='#4c8c4a'; c.beginPath(); c.moveTo(184,100); c.lineTo(219,72); c.lineTo(254,100); c.closePath(); c.fill();
  c.fillStyle='rgba(255,255,255,0.12)'; c.beginPath(); c.moveTo(219,72); c.lineTo(254,100); c.lineTo(240,100); c.closePath(); c.fill();
  rect(c,234,76,8,18,'#8a6a4a');
  const fl=0.75+0.25*Math.sin(t*7);
  rect(c,196,108,13,12,'#5a3d2b'); rect(c,198,110,9,8,'rgba(255,217,138,'+fl.toFixed(2)+')'); rect(c,201,110,2,8,'#5a3d2b');
  rect(c,222,116,13,24,'#5c3d7a'); circ(c,232,128,1.4,'#ffd166');
  for(let i=0;i<5;i++){ const tt=(t*0.3+i*0.2)%1; ell(c,238+Math.sin(tt*5+i)*5,70-tt*34,3+tt*5,2+tt*3,'rgba(210,205,215,'+(0.5*(1-tt)).toFixed(2)+')'); }
  /* garden */
  rect(c,170,142,92,2,'#8a6a4a'); for(let x=172;x<262;x+=10) rect(c,x,136,2,8,'#8a6a4a');
  const fc=['#e86a92','#f6d55c','#c792ea','#ffffff','#8ecae6'];
  for(let i=0;i<22;i++){ const x=172+i*4, y=146+((i*7)%6); rect(c,x+1,y,1,5,'#2f6b34'); circ(c,x+1.5,y,2,fc[i%5]); }
  /* the road of cold fires, leading in from the left */
  coldFire(c,34,168,1.2,t); coldFire(c,82,160,1.0,t+1); coldFire(c,124,154,0.85,t+2);
  c.strokeStyle='rgba(230,200,150,0.35)'; c.lineWidth=5; c.beginPath(); c.moveTo(-10,176); c.quadraticCurveTo(80,160,150,152); c.quadraticCurveTo(190,148,226,142); c.stroke();
  /* the hermit tends his flowers */
  const hx=156, hy=158;
  drawDuck(c,hx,hy,'right',t*2,false,REDDUCK,{scale:2.3});
  rect(c,hx+18,hy-26,10,7,'#7d8896'); rect(c,hx+27,hy-30,8,2,'#7d8896');
  for(let i=0;i<6;i++){ const tt=(t*1.4+i*0.17)%1; c.fillStyle='rgba(150,210,255,'+(1-tt).toFixed(2)+')'; c.fillRect(hx+36+tt*8,hy-29+tt*22,1.5,2); }
  /* fireflies */
  for(let i=0;i<16;i++){ const fx=(i*61+t*6*(1+(i%3)*0.2))%LW, fy=90+((i*37)%60)+Math.sin(t*1.3+i)*6, a=0.4+0.6*Math.abs(Math.sin(t*2+i));
    circ(c,fx,fy,3,'rgba(255,240,150,'+(0.18*a).toFixed(2)+')'); c.fillStyle='rgba(255,250,200,'+a.toFixed(2)+')'; c.fillRect(fx,fy,1.4,1.4); }
  c.restore();
  vignette(c,0.55);
  c.fillStyle='rgba(255,240,220,'+(Math.max(0,1-t/1.5)*0.9).toFixed(2)+')'; c.fillRect(0,0,LW,LH);
};

/* the vision, part two (and the memory you call back later): the hermit and his own people */
SCENES.reunion=function(c,t){
  const p=Math.min(1,t/5);
  sky(c,'#ffb88a','#ffeec8',22);
  circ(c,262,44,26,'rgba(255,230,160,0.35)'); circ(c,262,44,15,'#fff3b0');
  c.fillStyle='#8fb870'; c.beginPath(); c.moveTo(0,112); for(let x=0;x<=LW;x+=12) c.lineTo(x,104+Math.sin(x*0.035)*9); c.lineTo(LW,LH); c.lineTo(0,LH); c.fill();
  c.fillStyle='#79b862'; c.fillRect(0,128,LW,52);
  /* round houses with ember-red roofs */
  const house=(x,y,s,roof)=>{ rect(c,x-12*s,y-14*s,24*s,14*s,'#f0e0c0'); c.fillStyle=roof; c.beginPath(); c.moveTo(x-16*s,y-13*s); c.lineTo(x,y-30*s); c.lineTo(x+16*s,y-13*s); c.fill(); rect(c,x-3*s,y-9*s,6*s,9*s,'#5c3d7a'); };
  house(40,124,1.2,'#b5483a'); house(92,118,0.9,'#9b2d20'); house(238,120,1.0,'#c0583a'); house(288,126,1.3,'#8a2a2a');
  /* bunting between poles */
  rect(c,24,70,2,56,'#6b4a2f'); rect(c,296,70,2,56,'#6b4a2f');
  c.strokeStyle='#6b4a2f'; c.lineWidth=1; c.beginPath(); c.moveTo(25,72); c.quadraticCurveTo(160,102,297,72); c.stroke();
  for(let i=0;i<16;i++){ const k=(i+0.5)/16, x=25+k*272, y=72+Math.sin(k*Math.PI)*21+0.5; c.fillStyle=i%2?'#e0b84a':'#c0392b'; c.beginPath(); c.moveTo(x-4,y); c.lineTo(x+4,y); c.lineTo(x,y+8+Math.sin(t*4+i)); c.fill(); }
  /* the hermit, hood down, in the middle */
  const hx=160, hy=150, jump=-Math.abs(Math.sin(t*5))*(p>=1?3:0.5);
  const ring=12, reds=['#c0392b','#d9503f','#a83a2d','#e04a3a','#b5352b','#d9503f'];
  /* ducks run in from both sides, then crowd around him */
  for(let i=0;i<ring;i++){
    const ang=i*(Math.PI*2/ring)+0.3, rr=30+(i%3)*9, tx=hx+Math.cos(ang)*rr*1.25, ty=hy+Math.sin(ang)*rr*0.32+3;
    const from=(i%2===0)?-30:LW+30, delay=i*0.12, q=Math.max(0,Math.min(1,(t-delay)/4.2)), e=q*q*(3-2*q);
    const x=from+(tx-from)*e, bob=-Math.abs(Math.sin(t*(q<1?9:6)+i))*(q<1?2.5:3.2);
    mini(c,x,ty,reds[i%6],x<tx?'right':(x>tx?'left':'down'),1.9-(i%3)*0.15,bob);
    if(q>=1&&i%2===0){ const hh=(t*0.6+i*0.2)%1; heart(c,x,ty-24-hh*26,0.55,'rgba(255,90,120,'+(1-hh).toFixed(2)+')'); }
  }
  drawDuck(c,hx,hy+jump*0.5,'down',t*8,false,REDDUCK,{scale:2.7});
  if(p>=1){ for(let i=0;i<5;i++){ const hh=(t*0.5+i*0.2)%1; heart(c,hx-24+i*12,hy-72-hh*30,0.9,'rgba(255,90,120,'+(1-hh).toFixed(2)+')'); } }
  /* falling feathers and confetti */
  for(let i=0;i<34;i++){ const fx=(i*47+Math.sin(t*0.8+i)*14)%LW, fy=(t*26+i*31)%190-10; c.save(); c.translate(fx,fy); c.rotate(Math.sin(t*2+i)*0.9); c.fillStyle=i%3?'#c0392b':(i%3===1?'#f6d55c':'#ff9d2e'); c.fillRect(-2,-1,5,2); c.restore(); }
  vignette(c,0.22);
  if(t<1.2){ c.fillStyle='rgba(255,240,220,'+(1-t/1.2).toFixed(2)+')'; c.fillRect(0,0,LW,LH); }
};

/* the hermit's memory, part one: a happy childhood in Mallardia */
SCENES.kidJoy=function(c,t){
  sky(c,'#79c4ff','#e8f6ff',20);
  circ(c,44,34,22,'rgba(255,243,176,0.3)'); circ(c,44,34,13,'#fff3b0');
  for(let i=0;i<3;i++){ const x=((t*7+i*130)%420)-60; ell(c,x,28+i*16,24,6,'rgba(255,255,255,0.9)'); ell(c,x+12,24+i*16,15,5,'rgba(255,255,255,0.9)'); }
  c.fillStyle='#6fae5a'; c.beginPath(); c.moveTo(0,118); for(let x=0;x<=LW;x+=10) c.lineTo(x,110+Math.sin(x*0.04)*9); c.lineTo(LW,LH); c.lineTo(0,LH); c.fill();
  castle(c,266,126,0.62,'#d8d2c0','#3a5f9c',t,'#e0b84a');
  c.fillStyle='#8fc46e'; c.fillRect(0,138,LW,42);
  /* beehives on the south hill */
  for(let i=0;i<3;i++){ const x=70+i*30, y=132; rect(c,x-8,y-12,16,12,'#e8c070'); rect(c,x-9,y-15,18,4,'#c9a050'); rect(c,x-2,y-7,4,4,'#3b2a18');
    for(let k=0;k<3;k++){ const a=t*3+i*2+k*2.1; c.fillStyle='#2a2018'; c.fillRect(x+Math.cos(a)*14,y-20+Math.sin(a*1.3)*8,1.5,1.5); } }
  /* flowers */
  const fc=['#e86a92','#f6d55c','#c792ea','#ffffff'];
  for(let i=0;i<40;i++){ const x=(i*29)%LW, y=146+((i*13)%30); rect(c,x,y,1,4,'#2f6b34'); circ(c,x+0.5,y,2,fc[i%4]); }
  /* mother and the little one chasing butterflies */
  mini(c,92,152,'#c0392b','right',3,Math.sin(t*2)*0.5);
  heart(c,98,114+Math.sin(t*3)*2,0.9,'#ff5a7a');
  const kx=150+Math.sin(t*0.9)*70, kdir=Math.cos(t*0.9)>0?'right':'left';
  mini(c,kx,158,'#e04a3a',kdir,1.7,-Math.abs(Math.sin(t*8))*2.2);
  const bx=kx+(kdir==='right'?26:-26)+Math.sin(t*5)*6, by=134+Math.sin(t*4)*10;
  c.fillStyle='#8ecae6'; c.beginPath(); c.ellipse(bx-3,by,3,2+Math.sin(t*20),0,0,6.28); c.ellipse(bx+3,by,3,2+Math.sin(t*20),0,0,6.28); c.fill();
  /* friends from every kind of feather */
  const fr=['#f4f4ee','#8d7352','#87b4d8','#e9b7c8'];
  for(let i=0;i<4;i++){ const x=198+i*26+Math.sin(t*1.6+i)*6; mini(c,x,160+(i%2)*6,fr[i],i%2?'left':'right',1.6,-Math.abs(Math.sin(t*7+i*2))*2); }
  for(let i=0;i<10;i++){ const tt=(t*0.5+i*0.1)%1; heart(c,60+((i*31)%200)+Math.sin(tt*6+i)*6,150-tt*70,0.5,'rgba(255,100,130,'+(0.8*(1-tt)).toFixed(2)+')'); }
  if(t<1){ c.fillStyle='rgba(255,255,255,'+(1-t).toFixed(2)+')'; c.fillRect(0,0,LW,LH); }
};

/* the hermit's memory, part two: the king reads the Edict and the red ducks are sent away */
SCENES.castOut=function(c,t){
  const p=Math.min(1,Math.max(0,(t-1.5)/9));
  sky(c,'#7d8794','#b8bfc7',20);
  /* rain gathers */
  c.strokeStyle='rgba(200,215,235,'+(0.12+0.3*p).toFixed(2)+')'; c.lineWidth=1;
  for(let i=0;i<70;i++){ const x=(i*43+t*18)%LW, y=((i*29)+t*160)%LH; c.beginPath(); c.moveTo(x,y); c.lineTo(x-2,y+6); c.stroke(); }
  castle(c,232,138,1.15,'#c4beac','#34507e',t,'#a8892f');
  c.fillStyle='#8a8478'; c.fillRect(0,140,LW,40);
  for(let x=0;x<LW;x+=20) for(let y=140;y<LH;y+=10){ c.fillStyle=((x/20+y/10)&1)?'#7c766b':'#847e72'; c.fillRect(x,y,20,10); }
  /* the balcony and the king */
  rect(c,204,78,56,5,'#6b6458'); for(let i=0;i<7;i++) rect(c,206+i*8,70,2,9,'#6b6458'); rect(c,204,70,56,2,'#6b6458');
  drawDuck(c,232,78,'down',0,false,{body:'#f4f4ee',wing:'#d4d8cf',bill:'#ff9d2e'},{scale:1.7,head:'royal'});
  rect(c,224,58,16,12,'#f6e19a'); rect(c,226,61,12,1,'#8a1a1a'); rect(c,226,64,12,1,'#8a1a1a'); rect(c,226,67,8,1,'#8a1a1a');
  /* guards with spears */
  for(let i=0;i<4;i++){ const x=140+i*14; mini(c,x,150,'#9aa4ad','left',1.9,0); rect(c,x-9,112,1.6,40,'#6b4a2f'); c.fillStyle='#c3ccd6'; c.beginPath(); c.moveTo(x-10,112); c.lineTo(x-8,104); c.lineTo(x-6,112); c.fill(); }
  /* the crowd that does not look */
  const cols=['#f4f4ee','#8d7352','#87b4d8','#e9b7c8','#9aa4ad'];
  for(let i=0;i<7;i++) mini(c,176+i*12+(i%2)*3,164+(i%3)*4,cols[i%5],'up',1.7,0);
  /* the red ducks walk away to the left, a small one last, looking back */
  for(let i=0;i<9;i++){
    const x=128-p*170-i*15, y=160+(i%3)*5, bob=-Math.abs(Math.sin(t*5+i))*1.2;
    mini(c,x,y,i%2?'#c0392b':'#d9503f','left',1.7,bob); rect(c,x-4,y-12+bob,5,6,'#a8793f');
  }
  const kx=128-p*170-9*15-8, ky=164, look=Math.sin(t*1.5)>0.4;
  mini(c,kx,ky,'#e04a3a',look?'right':'left',1.4,-Math.abs(Math.sin(t*6))*1.4); rect(c,kx-2,ky-9,5,5,'#a8793f');
  c.fillStyle='rgba(8,10,24,'+(0.05+0.4*p).toFixed(2)+')'; c.fillRect(0,0,LW,LH);
  vignette(c,0.3);
};

/* the hermit's cottage at night, where he tells his story (kept above the text box) */
TELLERBG.hollow=function(c,t,b){
  const g1=c.createLinearGradient(0,0,0,LH); g1.addColorStop(0,'#080d22'); g1.addColorStop(0.5,'#15233a'); g1.addColorStop(1,'#12301f'); c.fillStyle=g1; c.fillRect(0,0,LW,LH);
  for(const s of cut.stars){ const a=0.4+0.6*Math.abs(Math.sin(t*1.5+s[2])); c.fillStyle='rgba(255,255,230,'+a.toFixed(2)+')'; c.fillRect(s[0],s[1]*0.8,1,1); }
  circ(c,278,24,10,'#f4efd0'); circ(c,273,20,8.5,'#080d22');
  for(let i=0;i<9;i++){ const x=i*38+((i*17)%13), h=34+((i*29)%20); c.fillStyle='#0a1a12'; c.beginPath(); c.moveTo(x,86); c.lineTo(x+11,86-h); c.lineTo(x+22,86); c.fill(); }
  c.fillStyle='#14341f'; c.fillRect(0,84,LW,96);
  /* cottage */
  rect(c,6,52,66,36,'#c9b99a'); c.fillStyle='#365f35'; c.beginPath(); c.moveTo(0,54); c.lineTo(39,28); c.lineTo(78,54); c.fill();
  const fl=0.8+0.2*Math.sin(t*7); rect(c,14,62,15,13,'#5a3d2b'); rect(c,16,64,11,9,'rgba(255,217,138,'+fl.toFixed(2)+')'); rect(c,21,64,2,9,'#5a3d2b'); rect(c,48,66,13,22,'#4a2f66');
  const fc=['#e86a92','#f6d55c','#c792ea','#ffffff']; for(let i=0;i<13;i++){ const x=4+i*5.5; rect(c,x,92,1,4,'#2f6b34'); circ(c,x+0.5,92,1.8,fc[i%4]); }
  /* small fire */
  const f2=0.85+0.15*Math.sin(t*9);
  const gr=c.createRadialGradient(168,108,2,168,108,80*f2); gr.addColorStop(0,'rgba(255,170,70,0.5)'); gr.addColorStop(1,'rgba(255,120,40,0)'); c.fillStyle=gr; c.fillRect(0,20,LW,120);
  for(let i=0;i<8;i++){ const a=i*0.785; ell(c,168+Math.cos(a)*10,114+Math.sin(a)*3.5,4,2.6,'#5d6068'); }
  rect(c,159,110,18,3,'#4a3018'); rect(c,161,107,14,3,'#5a3d22');
  const q1=Math.sin(t*10)*2, q2=Math.sin(t*14+1)*1.6;
  c.fillStyle='#ff7a2a'; c.beginPath(); c.moveTo(159,110); c.quadraticCurveTo(162+q2,94,168,82+q1); c.quadraticCurveTo(175,96,177,110); c.fill();
  c.fillStyle='#ffd166'; c.beginPath(); c.moveTo(163,110); c.quadraticCurveTo(165,98,168,91+q2); c.quadraticCurveTo(171,99,173,110); c.fill();
  /* the hermit, telling it; the little detective, listening */
  const talking=cut.typed<b.pages[cut.page].length;
  drawDuck(c,112,120,'right',talking?t*13:0,talking,REDDUCK,{scale:1.9});
  drawDuck(c,226,120,'left',0,false,{body:'#ffd84a',wing:'#f0b921',bill:'#ff8a1f'},{scale:1.6});
  for(let i=0;i<6;i++){ const tt=(t*0.5+i*0.17)%1; c.fillStyle='rgba(255,200,100,'+(1-tt).toFixed(2)+')'; c.fillRect(164+i*3+Math.sin(tt*7+i)*4,92-tt*40,1,1); }
};

/* alone at the edge of the Hollow Wood, after the door is closed on you */
TELLERBG.woods=function(c,t,b){
  const g1=c.createLinearGradient(0,0,0,LH); g1.addColorStop(0,'#05030f'); g1.addColorStop(0.5,'#1a1233'); g1.addColorStop(1,'#0e1a14'); c.fillStyle=g1; c.fillRect(0,0,LW,LH);
  for(const s of cut.stars){ const a=0.3+0.5*Math.abs(Math.sin(t*1.2+s[2])); c.fillStyle='rgba(220,230,255,'+a.toFixed(2)+')'; c.fillRect(s[0],s[1]*0.8,1,1); }
  const layer=(y,col,sz,off)=>{ c.fillStyle=col; for(let i=-1;i<14;i++){ const x=i*28+off+Math.sin(t*0.5+i)*1.5; c.beginPath(); c.moveTo(x,y); c.lineTo(x+14,y-sz-((i*13)%17)); c.lineTo(x+28,y); c.fill(); } };
  layer(84,'#0a1220',44,0); layer(98,'#070d17',56,-9); layer(116,'#04080f',66,5);
  c.fillStyle='#04080f'; c.fillRect(0,116,LW,64);
  for(let i=0;i<18;i++){ const fx=(i*53+t*5)%LW, fy=40+((i*37)%70)+Math.sin(t*1.1+i)*7, a=0.3+0.7*Math.abs(Math.sin(t*1.7+i)); circ(c,fx,fy,3,'rgba(255,240,150,'+(0.15*a).toFixed(2)+')'); c.fillStyle='rgba(255,250,200,'+a.toFixed(2)+')'; c.fillRect(fx,fy,1.4,1.4); }
  drawDuck(c,110,118,'right',0,false,{body:'#ffd84a',wing:'#f0b921',bill:'#ff8a1f'},{scale:1.8});
  const ft=(t*0.3)%1; c.save(); c.translate(170+Math.sin(ft*8)*10,24+ft*80); c.rotate(Math.sin(ft*7)); c.fillStyle='#c0392b'; c.beginPath(); c.ellipse(0,0,6,2,0,0,6.28); c.fill(); c.restore();
};

/* ===== THE HOLLOW WOOD: the shifting forest ===== */
function woodNewRoute(){
  const mv=['E','E','E','N','N','N'];
  for(let i=mv.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); const t=mv[i]; mv[i]=mv[j]; mv[j]=t; }
  let ci=0, cj=WN-1; const r=[[ci,cj]];
  for(const m of mv){ if(m==='E') ci++; else cj--; r.push([ci,cj]); }
  wood.route=r; wood.moves=mv; wood.idx=0;
}
function woodShift(){
  wood.epoch++; tileCache.clear(); wood.pulse=0.55;
  unstick();
}
function woodNextDir(){
  const r=wood.route; if(!r||wood.idx>=r.length-1) return null;
  const a=r[wood.idx], b=r[wood.idx+1];
  return b[0]>a[0]?'east':'north';
}
function woodLost(){
  fade(0.9); wood.epoch++; tileCache.clear();
  woodNewRoute(); wood.cell=null; wood.cellT=0; wood.cueOn=false; wood.still=0;
  g.px=(WX0+6.5)*TS; g.py=(WY0+WSZ+3.5)*TS; g.dir='up'; g.camX=g.px; g.camY=g.py-10;
  toast(pick(['The trees shift, and shift again. You are back at the edge of the wood.','Branches close behind you. When you look up, the way you came is gone.','The wood sighs. Somehow you are facing the entrance again.']),3800);
}
function woodTrack(tx,ty){
  const gx=tx-WX0, gy=ty-WY0;
  if(gx<0||gy<0||gx>=WSZ||gy>=WSZ){ if(wood.cell){ wood.cell=null; wood.idx=0; wood.cellT=0; } return; }
  const u=gx%WC, v=gy%WC;
  if(u<1||u>WC-2||v<1||v>WC-2) return;
  const i=Math.floor(gx/WC), j=Math.floor(gy/WC), key=i+','+j;
  if(key===wood.cell) return;
  wood.cell=key; wood.cellT=0; wood.still=0; wood.cueOn=false; wood.hintedYes=false;
  const r=wood.route; let k=-1;
  for(let n=0;n<=Math.min(wood.idx+1,r.length-1);n++) if(r[n][0]===i&&r[n][1]===j) k=n;
  if(k<0){ woodLost(); return; }
  wood.idx=k;
  if(k===r.length-1) villageArrive();
}
function woodUpdate(dt){
  if(g.scene!=='world') return;
  const tx=Math.floor(g.px/TS), ty=Math.floor((g.py-2)/TS);
  if(!inWood(tx,ty)){ if(wood.route){ wood.cell=null; wood.idx=0; wood.still=0; wood.cueOn=false; wood.arrived=false; } return; }
  if(g.mode!=='play') return;
  if(!wood.route) woodNewRoute();
  const st=g.story;
  if(!st.woodSeen){ st.woodSeen=1; toast('The trees lean in. The air smells of pine and old woodsmoke.',4200); }
  const inGrid=tx>=WX0&&tx<WX0+WSZ&&ty>=WY0&&ty<WY0+WSZ;
  const moved=Math.hypot(g.px-wood.lastX,g.py-wood.lastY); wood.lastX=g.px; wood.lastY=g.py;
  if(moved<0.3){ wood.still+=dt; } else { wood.still=0; wood.cueOn=false; }
  /* the wood moves because it is afraid, and it does not move for one who is still (the Red Book): it holds its breath while you stand quiet */
  if(inGrid){ if(wood.still>=1.2) wood.epochT=0; else { wood.epochT+=dt; if(wood.epochT>=7){ wood.epochT=0; woodShift(); } } }
  woodTrack(tx,ty);
  if(inGrid) wood.cellT+=dt;
  if(st.bookRead&&wood.cell&&wood.still>=3&&!wood.cueOn){
    const d=woodNextDir();
    if(d){ wood.cueOn=true; wood.cueVec=d==='east'?[1,0]:[0,-1]; toast('A red feather falls, and drifts '+d+'.',3600); }
  }
  if(st.bookRead&&wood.cell&&wood.cellT>35&&!wood.hintedYes&&!wood.cueOn){ wood.hintedYes=true; toast('(The book said: stand quiet in each glade and count to three.)',4200); }
  if(!st.bookRead&&wood.cellT>40&&!wood.hintedNo){ wood.hintedNo=true; toast('The wood keeps moving. You have no idea which way is right. Someone must know the trick.',4600); }
}

/* the village: a closed door */
function ejectPlayer(){
  fade(1.4); wood.epoch++; tileCache.clear();
  woodNewRoute(); wood.cell=null; wood.cellT=0; wood.arrived=false; wood.cueOn=false; wood.still=0;
  g.px=(WX0+6.5)*TS; g.py=(WY0+WSZ+3.5)*TS; g.dir='up'; g.camX=g.px; g.camY=g.py-10;
}
function villageArrive(){
  if(wood.arrived) return; wood.arrived=true;
  const st=g.story;
  if(st.rejected) villageAgain(); else villageFirst();
}
function villageFirst(){
  const st=g.story;
  seq([
    ['',['The last tree bends aside, almost politely. Beyond it, in a ring of lanterns, a hidden village: round little houses with ember-red roofs, a fire crackling in the square.','Every single duck in it is red. Emberwick is real. You found them.']],
    ['Little Poppy',['Mama! A yellow one! A real live yellow one!']],
    ['Warden Ruddock',['HALT! Nobody passes the Wood. Nobody. How did a yellow-feather find the way?']],
    ['Elder Cinder',['Quiet, Ruddock. Child... you are not one of us. Your feathers are the colour of the ones who wear the crown.','We were sent away for the shade of our plumage. Do you know what that teaches a village? It teaches it to close its doors.','Whatever brought you, it is not welcome here. Take him out.']],
    ['',['Strong wings lift you, gently but firmly. The crowd parts; a hundred eyes follow you; somewhere a door slams.','The trees swirl... and you are standing at the edge of the Wood, alone.']]
  ],()=>{
    ejectPlayer();
    st.rejected=1;
    startCutscene(RECALL,()=>{
      fade(1.2);
      say('',['The hermit. His face in the vision, buried in the arms of his own kind. That is the homecoming the Wood is hiding.','They will not open a door to a yellow duck. But they might open it to one of their own.','Go back to Hermit Mallow in the hollow east of Kingsbill. Tell him you found them, and have him follow you here.']);
    },{hint:'Press X again to skip'});
  });
}
function villageAgain(){
  seq([
    ['Warden Ruddock',['You again. The Wood let you through twice? Out. Elder Cinder said what she said.']],
    ['',['You are lifted out of the village as gently and firmly as before. The trees swirl, and you are standing at the edge of the Wood.']]
  ],()=>{ ejectPlayer(); say('',['Maybe they would listen to the hermit. Go and fetch him.']); });
}
const RECALL=[
  {k:'teller',bg:'woods',who:'Detective Duck',pages:['Not one of them would hear you out. Not one door opened.','And yet, as the Wood sighs shut behind you, you remember something.']},
  {k:'anim',scene:'reunion',dur:10,cap:'You remember the vision of the hermit...'},
  {k:'teller',bg:'woods',who:'Detective Duck',pages:['The hermit, laughing, wrapped in a crowd of red feathers. That is what the Wood is hiding. Not a secret. A homecoming that has not happened yet.','He has to see Emberwick. They have to see him.']}
];

/* ===== THE ROYAL LIBRARY (the hidden book) ===== */
const LIBW=13, LIBH=10;
const INTLAYOUT={
  library:['WWWWWWWWWWWWW','WBBBBBFBBBBBW','W...........W','WS.TT...TT.SW','WS.........SW','WS.TT...TT.SW','W...........W','WS....G....SW','W...........W','WWWWWWDWWWWWW'],
  temple:['WWWWWWWWWWWWW','WC.........CW','WC..AAAAA..CW','W.....N.....W','W.PPP...PPP.W','W.PPP...PPP.W','W.PPP...PPP.W','WL.........BW','W...........W','WWWWWWDWWWWWW']
};
const LIBINT={library:'BFSTG',temple:'ALBNPC'};
const LIBEXIT={library:[43,-24],temple:[-43,-24]};
function libLayout(){ return INTLAYOUT[g.libKind]||INTLAYOUT.library; }
function libCh(tx,ty){ if(tx<0||ty<0||tx>=LIBW||ty>=LIBH) return 'W'; return libLayout()[ty][tx]; }
function libSolid(tx,ty){ const ch=libCh(tx,ty); return ch!=='.'&&ch!=='D'; }
function enterInterior(kind){
  g.libKind=kind; g.saved={x:g.px,y:g.py,dir:g.dir};
  g.scene='lib'; g.px=6.5*TS; g.py=8.3*TS; g.dir='up'; fade(0.4); g.target=null; quack();
}
function enterLibrary(){
  enterInterior('library');
  toast('The Royal Library. Dust, candle smoke and a very loud silence.',3000);
}
function exitLibrary(){
  const e=LIBEXIT[g.libKind]||LIBEXIT.library;
  g.scene='world'; g.px=(KX+e[0]+0.5)*TS; g.py=(KY+e[1]+1.7)*TS; g.dir='down'; fade(0.4);
  g.camX=g.px; g.camY=g.py; blip();
}
function libUpdate(){ if(g.scene==='lib'&&g.mode==='play'&&g.py-2>=9*TS) exitLibrary(); }
function libFindTarget(){
  g.target=null; if(g.mode!=='play') return;
  const v=DIRV[g.dir], fx=g.px+v.x*14, fy=g.py-6+v.y*14;
  const tx=Math.floor(fx/TS), ty=Math.floor(fy/TS), ch=libCh(tx,ty);
  if((LIBINT[g.libKind]||LIBINT.library).indexOf(ch)>=0) g.target={k:'lib',ch:ch,tx:tx,ty:ty,x:(tx+0.5)*TS,y:ty*TS-2};
}
const SHELF_LINES=[
  'Rows of leather spines, gold-lettered and thoroughly unread. "A Short History of Long Walks."','"Sixty Uses for Pondweed." You read the first use. It is soup.',
  'Dusty. A note tucked in a gap reads: "Borrowed, will return, signed Daisy."','Bound atlases of the kingdom. All of them are the same map. Several are upside down.',
  'Poetry. Every poem rhymes "quack" with "back".','"The Complete Genealogy of Mallardian Pears." Volume nine hundred and four.',
  'A shelf of ledgers. Every entry says "inventory pending."','Cookbooks. One has a pressed leaf and a thumbprint of jam on page 3.'
];
function findBook(){
  const st=g.story; st.bookFound=1; addItem('redbook'); coin();
  say('',['You tug the dull grey spine. Something clicks deep inside the wall.','The whole shelf swings aside on a hidden hinge, breathing cold air that smells of cedar and secrets. In a small alcove: a single book, bound in faded red cloth.','You open it. Every page is covered in tight, looping scribbles and tiny stars. Not a word makes sense. It is a cipher.','Received: Cipher-Bound Book. The hermit\'s decoder should turn it into words. Open your pack (I) and examine the book.']);
}
function libInteract(tg){
  if(g.libKind==='temple'){ templeInteract(tg); return; }
  const st=g.story, ch=tg.ch, tx=tg.tx, ty=tg.ty;
  if(ch==='B'){
    if(tx===4&&ty===1){
      if(st.bookFound){ say('',['The shelf has swung back into place. A faint draught breathes from the gap behind "Pondweed, Vol. IX".']); return; }
      if(st.libHint){
        say('',['Between "Pondweed, Vol. VIII" and "Pondweed, Vol. X" sits a dull grey spine marked IX. It stands a hair prouder than its neighbours.'],()=>{
          choose('','Pull the book?',['Pull it','Leave it'],k=>{ if(k===0) findBook(); },1);
        });
        return;
      }
    }
    say('',[SHELF_LINES[(tx*3+ty)%SHELF_LINES.length]]); return;
  }
  if(ch==='S'){ say('',[SHELF_LINES[(tx*5+ty*2)%SHELF_LINES.length]]); return; }
  if(ch==='F'){ say('',['The fireplace is cold, but the ashes are still faintly warm. Someone sat here all night. Probably a cat.']); return; }
  if(ch==='T'){ say('',[pick(['A half-finished jigsaw of a pond. The pond is missing a corner.','A reading table scarred with initials. D.W. loves P.F. 3 summers ago.'])]); return; }
  if(ch==='G'){
    say('',[st.bookRead?'You spin the globe. In the north-east, where the hills fold, someone has scratched out a small name. Under the scratches, still faintly legible: EMBERWICK.':'You spin the globe. Mallardia is a tiny gold dot. North-east of it, the paint is rubbed thin, as if something was scratched out.']);
  }
}
function drawLibrary(c,W,H,kd,time){
  const vw=W/kd, vh=H/kd;
  const RW=LIBW*TS, RH=LIBH*TS;
  const fx=vw>=RW?(RW/2-vw/2):Math.max(0,Math.min(RW-vw,g.px-vw/2)), fy=vh>=RH?(RH/2-vh/2):Math.max(-30,Math.min(RH-vh+10,g.py-14-vh/2));
  const ox=Math.round(fx*kd)/kd, oy=Math.round(fy*kd)/kd;
  c.setTransform(kd,0,0,kd,-ox*kd,-oy*kd);
  const spine=['#7a2a2a','#2f6f4f','#3a62a8','#c9a24a','#6a3a7a','#2f7f8a','#8a5a2b','#a8432b'];
  for(let ty=0;ty<LIBH;ty++) for(let tx=0;tx<LIBW;tx++){
    const ch=libCh(tx,ty), px=tx*TS, py=ty*TS;
    if(ch==='W'){ rect(c,px,py,TS,TS,'#4a3626'); rect(c,px,py+TS-4,TS,4,'#2e2016'); rect(c,px+4,py+4,TS-8,2,'rgba(255,255,255,0.08)'); continue; }
    rect(c,px,py,TS,TS,((tx+ty)&1)?'#7a5a3a':'#6f5134'); rect(c,px,py+15,TS,1,'rgba(0,0,0,0.15)'); rect(c,px+((tx*7+ty*3)%24),py+4,1,TS-8,'rgba(0,0,0,0.12)');
    if(ch==='D') rect(c,px+2,py+4,TS-4,TS-4,'#2f5d3a');
  }
  /* rug */
  rect(c,3.2*TS,3.4*TS,6.6*TS,2.2*TS,'#7a2a3a'); c.strokeStyle='#d9b84a'; c.lineWidth=2; c.strokeRect(3.2*TS+5,3.4*TS+5,6.6*TS-10,2.2*TS-10);
  rect(c,3.2*TS+12,3.4*TS+12,6.6*TS-24,2.2*TS-24,'rgba(255,255,255,0.08)');
  /* shelves, fireplace, tables, globe */
  for(let ty=0;ty<LIBH;ty++) for(let tx=0;tx<LIBW;tx++){
    const ch=libCh(tx,ty), px=tx*TS, py=ty*TS;
    if(ch==='B'||ch==='S'){
      rect(c,px,py,TS,TS,'#5b4430'); rect(c,px+2,py+2,TS-4,TS-4,'#3b2b1e');
      for(let r=0;r<3;r++){ const y=py+3+r*9; rect(c,px+2,y+8,TS-4,1.5,'#8a6a45');
        for(let k=0,x=px+3;k<6&&x<px+TS-4;k++){ const w=3+((tx*5+ty*3+r*7+k*3)%3); rect(c,x,y+(k%3===0?1:0),w,8-(k%3===0?1:0),spine[(tx*3+ty+r*5+k)%spine.length]); x+=w+0.5; } }
      if(g.story.bookFound&&tx===4&&ty===1){ rect(c,px+3,py+3,TS-6,TS-6,'#120c08'); rect(c,px+8,py+12,16,10,'#7a2a2a'); }
    } else if(ch==='F'){
      rect(c,px,py,TS,TS,'#6a6e78'); rect(c,px+3,py+8,TS-6,TS-8,'#1d1a18'); rect(c,px,py+5,TS,4,'#8a8f98');
      const f=Math.sin(time*9)*1.5; c.fillStyle='rgba(255,140,50,0.18)'; c.fillRect(px+3,py+8,TS-6,TS-8);
      c.fillStyle='#ff9d2e'; c.beginPath(); c.moveTo(px+9,py+TS-2); c.quadraticCurveTo(px+11,py+14+f,px+16,py+11+f); c.quadraticCurveTo(px+21,py+16,px+23,py+TS-2); c.fill();
    } else if(ch==='T'){
      rect(c,px,py+6,TS,TS-6,'#8a6238'); rect(c,px,py+6,TS,5,'#b98a55'); rect(c,px,py+TS-4,TS,4,'#5b3f22');
      if(tx%2===0){ rect(c,px+6,py+2,14,6,'#e8d9b5'); rect(c,px+8,py+4,10,1,'#7a5a3a'); }
    } else if(ch==='G'){
      ell(c,px+16,py+28,10,4,'rgba(0,0,0,0.25)'); rect(c,px+14,py+16,4,10,'#5b3f22'); rect(c,px+9,py+25,14,3,'#5b3f22'); circ(c,px+16,py+11,10,'#3a7ca5'); circ(c,px+13,py+9,4,'#5aa05a'); circ(c,px+19,py+13,3,'#5aa05a');
    }
  }
  /* candle glow */
  const gl=c.createRadialGradient(6.5*TS,4.5*TS,10,6.5*TS,4.5*TS,6*TS); gl.addColorStop(0,'rgba(255,214,140,0.16)'); gl.addColorStop(1,'rgba(255,214,140,0)'); c.fillStyle=gl; c.fillRect(0,0,LIBW*TS,LIBH*TS);
  drawMe(c,time);
  if(g.target&&g.mode==='play') drawBubble(c,g.target.x,g.target.y,time,'Z');
  const a2=ambient(g.clock);
  if(a2[3]>0.1){ c.fillStyle='rgba(20,18,50,'+(a2[3]*0.18).toFixed(2)+')'; c.fillRect(ox,oy,vw,vh); }
  c.setTransform(1,0,0,1,0,0);
}

/* ===== tile art: cold campfire, hidden page ===== */
function drawColdCamp(c,px,py,time,x){
  ell(c,px+16,py+27,14,5,'rgba(0,0,0,0.25)');
  for(let i=0;i<8;i++){ const a=i*0.785; ell(c,px+16+Math.cos(a)*10.5,py+25+Math.sin(a)*4,4,3,'#6b6f78'); }
  ell(c,px+16,py+24,8,3.4,'#2a2624'); rect(c,px+9,py+21,14,3,'#1c1816'); rect(c,px+11,py+19,10,2,'#26201c');
  for(let i=0;i<3;i++){ const tt=(time*0.22+i*0.33+hash(x,0,4)*1)%1; ell(c,px+16+Math.sin(time*0.8+i*2)*2,py+16-tt*22,2.4+tt*3.2,1.8+tt*2,'rgba(175,175,188,'+(0.42*(1-tt)).toFixed(2)+')'); }
  c.fillStyle='#c0392b'; c.beginPath(); c.moveTo(px+11,py+22); c.quadraticCurveTo(px+14,py+14,px+22,py+18); c.quadraticCurveTo(px+16,py+22,px+11,py+22); c.fill();
}
function drawPageGlint(c,px,py,time,x,y){
  ell(c,px+16,py+22,8,3,'rgba(0,0,0,0.2)');
  rect(c,px+10,py+14,12,9,'#f4efe0'); rect(c,px+10,py+14,12,1,'#d8cfae'); rect(c,px+12,py+17,8,1,'#8a7a5a'); rect(c,px+12,py+19,6,1,'#8a7a5a'); rect(c,px+15,py+13,2,11,'#c0392b');
  const s=0.5+0.5*Math.sin(time*4+x*1.3+y);
  c.fillStyle='rgba(255,255,255,'+(0.35+0.5*s).toFixed(2)+')'; c.fillRect(px+15,py+7-s*2,2,6); c.fillRect(px+12,py+9-s*2,8,2);
}
function ch2Overlay(c,W,H,kd,camX,camY,time){
  if(!(wood.pulse>0||wood.cueOn)) return;
  const vw=W/kd, vh=H/kd, ox=Math.round((camX-vw/2)*kd)/kd, oy=Math.round((camY-vh/2)*kd)/kd;
  c.setTransform(kd,0,0,kd,-ox*kd,-oy*kd);
  if(wood.cueOn&&wood.cueVec&&g.scene==='world'){
    const vx=wood.cueVec[0], vy=wood.cueVec[1];
    for(let k=0;k<6;k++){
      const ph=((time*0.35+k/6)%1), dist=ph*TS*8, sw=Math.sin(ph*9+k)*6;
      const fx=g.px+vx*dist+(vy?sw:0), fy=g.py-14+vy*dist+(vx?sw:0), a=Math.sin(ph*Math.PI);
      circ(c,fx,fy,9,'rgba(255,60,60,'+(0.16*a).toFixed(2)+')');
      c.save(); c.translate(fx,fy); c.rotate(Math.sin(ph*8+k)*0.9+0.4); c.globalAlpha=a;
      c.fillStyle='#d9473a'; c.beginPath(); c.ellipse(0,0,6,2.2,0,0,6.2832); c.fill(); c.fillStyle='#ffb0a0'; c.fillRect(-5,-0.5,10,1);
      c.restore();
      lights.push({x:fx,y:fy,r:34,s:0.5*a,w:0.5});
    }
    const pr=Math.min(1,(wood.still-3)/1.5+1);
    circ(c,g.px,g.py-16,14+Math.sin(time*5)*2,'rgba(255,70,70,'+(0.09*pr).toFixed(2)+')');
  }
  if(wood.pulse>0){
    c.fillStyle='rgba(50,0,80,'+Math.min(0.5,wood.pulse*0.7).toFixed(2)+')'; c.fillRect(ox,oy,vw,vh);
    wood.pulse=Math.max(0,wood.pulse-frameDt);
  }
  c.setTransform(1,0,0,1,0,0);
}

/* ===== items ===== */
ITEMS.decoder={name:'Cipher Decoder',desc:'Two brass rings, A to Z on one and Z to A on the other. Turn them and scribbles become words.',use:'note',note:'You spin the rings. Every letter finds its partner on the other side: A with Z, B with Y, C with X.',nogift:true};
ITEMS.redbook={name:'Cipher-Bound Book',desc:'Faded red cloth. Every page is covered in loops and tiny stars. Examine it with the decoder in your pack.',use:'book',nogift:true};
ITEMS.redbookd={name:'The Red Book',desc:'The decoded record of the red clans of the north. Examine it to read it again. (Also in your journal.)',use:'book',nogift:true};
ITEMS.edictpage={name:'Edict Page',desc:'A torn page of the Red Edict, tied with red thread. Examine it to read what you have found.',use:'pages',nogift:true};

/* ===== THE TEMPLE OF FEATHERS (always open; service every day at 11 AM) ===== */
const SVC_START=11, SVC_END=12;
function serviceOn(){ return g.clock>=SVC_START&&g.clock<SVC_END; }
function enterTemple(){
  enterInterior('temple');
  if(serviceOn()) toast('The bells are ringing. The Service of the Feather is under way.',3400);
  else toast('The Temple of Feathers. Candles, quiet, and the smell of warm wax.',3000);
}
const FAITH=[
 'THE BOOK OF THE FIRST FEATHER  (Temple copy, well thumbed)',
 'The Pond-Above made the world in one long breath. The first thing the breath touched was water. The second was the Mother Mallard, who rose out of it and shook herself dry. Every drop that fell from her became a duck.',
 'The Three Gifts: the Feather, which keeps you warm. The Water, which carries you. The Flock, which finds you when you are lost. A duck who forgets any gift is only half a duck.',
 'Rites: the Dawn Preen (every morning, in your own time). The Service of the Feather (every day at eleven, when the sun stands on the temple\'s gold weathervane). The Long Float (at the end of life, on the evening tide, with a candle).',
 'The Eleven Bells: eleven, because the Mother Mallard laid eleven eggs and, being a mother, loved them exactly the same. The faithful say: "Eleven eggs, one nest."',
 'On Colours: it is written that every feather is a note in the Mother\'s song. In the oldest copies there is a whole chapter, "The Ember Feather", on the red-touched, who were called the Mother\'s first blessing, and given the seat nearest the altar.',
 'That chapter is missing from this copy. The stub is cut clean, with a very sharp knife, in the year of the Red Edict. In the margin, in a small shaky hand, someone has written: "Restore it. Restore it. Restore it."'
];
function readFaithBook(){
  g.story.faithRead=1;
  seq([['',FAITH.slice(0,3)],['',FAITH.slice(3,5)],['',FAITH.slice(5)]]);
}
function templeJournal(sec,line){
  const st=g.story;
  if(!(st.faithBook||st.services)) return;
  sec('The Temple of Feathers');
  line('The temple of Kingsbill is always open. The Service of the Feather is held every day at 11 AM.');
  if(st.services) line('You have attended '+st.services+' service'+(st.services>1?'s':'')+'.');
  if(st.faithBook){
    line('"The Book of the First Feather": the Pond-Above, the Mother Mallard, and the Three Gifts (Feather, Water, Flock).','jdim');
    line('A chapter on the red-touched, "The Ember Feather", was cut from the temple copy the year of the Red Edict.','jdim');
  }
}
let _lastClk=-1;
function templeUpdate(dt){
  if(g.mode!=='play'){ _lastClk=g.clock; return; }
  if(_lastClk>=0&&_lastClk<SVC_START&&g.clock>=SVC_START&&g.scene==='world'&&Math.abs(g.px/TS-KX)<120&&Math.abs(g.py/TS-KY)<120) toast('Far off, the temple bells ring eleven times. The service is beginning.',3200);
  _lastClk=g.clock;
}
function attendService(){
  const st=g.story;
  const t=SVC_END-g.clock;
  say('Sister Dove',['Come, sit. There is always room on the pew nearest the altar.'],()=>{
    fade(1.2); advanceClock(t);
    st.services=(st.services||0)+1;
    const first=!st.blessed;
    const hymn=pick([
      ['The congregation hums the Hymn of Still Water. You do not know the words. Nobody minds. A small duck beside you hums the harmony slightly off-key and looks very proud.'],
      ['Sister Dove reads from the Book of the First Feather. When she reaches the Eleven Bells, the whole flock says, softly: "Eleven eggs, one nest."'],
      ['The sermon is on forgiveness. Sister Dove says, "A flock that remembers every wrong has no room left for ducklings." Somewhere in the back, someone sniffles.']
    ]);
    seq([['',['You sit among the flock. Candles are lit, one for each duck, and the light moves on the gold of the altar.']],['',hymn],['Sister Dove',['Go gently. Preen kindly. Float well.']]],()=>{
      if(first){ st.blessed=1; addItem('blessfeather'); coin(); toast('Received: Blessing Feather',3000); }
      else toast('You leave the service feeling lighter. It is '+clockStr()+'.',2800);
    });
  });
}
function templeInteract(tg){
  const st=g.story, ch=tg.ch;
  if(ch==='N'){
    if(serviceOn()){
      choose('Sister Dove','The service is just beginning. Will you join us?',['Join the service','Not now'],k=>{ if(k===0) attendService(); },1);
    } else {
      const left=((SVC_START-g.clock)+24)%24;
      const lines=[
        ['Welcome, little detective. The Service of the Feather is held every day at eleven. Come then, and the benches fill up.'],
        ['The temple is never locked. A lock says, "you are not welcome". We would prefer to say the opposite to everyone.']
      ];
      if(g.clock>=SVC_END&&g.clock<SVC_END+0.5) lines.unshift(['You just missed it. Service ended at noon. Tomorrow, eleven. The bells are punctual. The ducks are not.']);
      say('Sister Dove',pick(lines).concat(left<2?['Not long now.']:[]));
    }
    return;
  }
  if(ch==='P'){
    if(serviceOn()){ choose('','The service is starting. Take a seat?',['Sit','Not now'],k=>{ if(k===0) attendService(); },1); }
    else say('',['The benches are worn smooth by many wings. A card on the pew says: "Daily Service of the Feather. 11 AM. All feathers welcome."']);
    return;
  }
  if(ch==='A'){ say('',['A gold feather the size of a duck, resting above a basin of still water. Beneath it is carved: "Feather. Water. Flock."']); return; }
  if(ch==='C'){ say('',[pick(['A tall candle, lit by someone patient. The wax has been dripping into the same shape for years.','A candle for a duck who is gone. A small paper boat lies at its foot.'])]); return; }
  if(ch==='L'){
    say('',['A lectern holds the great hymnal. Its pages are marked in three colours of ribbon. One ribbon is red, and has been kept very clean.']); return;
  }
  if(ch==='B'){
    if(st.faithBook){ say('',['The shelf of temple books: prayers, hymnals, a cookbook for feast days. Your copy of the Book of the First Feather is safe in your pack.']); return; }
    say('',['A low shelf of hymnals and feast-day recipes. One thick volume is worn dark at the corners: "The Book of the First Feather".'],()=>{
      choose('','Take it? (Sister Dove says it is for borrowing.)',['Take it','Leave it'],k=>{
        if(k===0){ st.faithBook=1; addItem('faithbook'); coin(); toast('Received: The Book of the First Feather',3000); }
      },1);
    });
  }
}
ITEMS.faithbook={name:'Book of the First Feather',desc:'The creed of the duck faith. Examine it to read. (Also in your journal.)',use:'faith',nogift:true};
ITEMS.blessfeather={name:'Blessing Feather',desc:'A white feather, blessed at the Service of the Feather. It is warm. Nobody can explain why.',use:'note',note:'You tuck it behind your ear. Eleven eggs, one nest.',nogift:true};
function miniDuck(c,x,y,col,hood){
  ell(c,x,y+8,7,2,'rgba(0,0,0,0.2)');
  ell(c,x,y+3,6,5,col); circ(c,x+2,y-3,4,col); rect(c,x+5,y-3,4,2,'#ee9a2a'); rect(c,x+3,y-5,1,1.5,'#222');
  if(hood){ c.fillStyle=hood; c.beginPath(); c.arc(x+1,y-3,4.6,Math.PI,0); c.fill(); }
}
function drawTemple(c,W,H,kd,time){
  const vw=W/kd, vh=H/kd, RW=LIBW*TS, RH=LIBH*TS;
  const fx=vw>=RW?(RW/2-vw/2):Math.max(0,Math.min(RW-vw,g.px-vw/2)), fy=vh>=RH?(RH/2-vh/2):Math.max(-30,Math.min(RH-vh+10,g.py-14-vh/2));
  const ox=Math.round(fx*kd)/kd, oy=Math.round(fy*kd)/kd;
  c.setTransform(kd,0,0,kd,-ox*kd,-oy*kd);
  const svc=serviceOn();
  for(let ty=0;ty<LIBH;ty++) for(let tx=0;tx<LIBW;tx++){
    const ch=libCh(tx,ty), px=tx*TS, py=ty*TS;
    if(ch==='W'){ rect(c,px,py,TS,TS,'#d9d2bf'); rect(c,px,py+TS-4,TS,4,'#a39a82'); rect(c,px+4,py+4,TS-8,2,'rgba(255,255,255,0.3)'); continue; }
    rect(c,px,py,TS,TS,((tx+ty)&1)?'#c9bfa4':'#bfb597'); rect(c,px,py+15,TS,1,'rgba(0,0,0,0.08)');
    if(ch==='D') rect(c,px+2,py+4,TS-4,TS-4,'#8a5a2b');
  }
  /* stained glass windows with light shafts */
  for(const wx of [2.5,6.5,10.5]){
    const px=wx*TS-12, py=4;
    rect(c,px-2,py-2,28,30,'#6a6454'); rect(c,px,py,24,26,'#2a3a6a');
    const cols=['#c0392b','#e0b84a','#3a7ca5','#5aa05a'];
    for(let i=0;i<4;i++) rect(c,px+(i%2)*12,py+Math.floor(i/2)*13,12,13,cols[(i+Math.floor(wx))%4]);
    rect(c,px+11,py,2,26,'#6a6454'); rect(c,px,py+12,24,2,'#6a6454');
    c.fillStyle='rgba(255,230,160,'+(svc?0.16:0.08)+')'; c.beginPath(); c.moveTo(px,py+26); c.lineTo(px+24,py+26); c.lineTo(px+24+34,py+9*TS-20); c.lineTo(px-34,py+9*TS-20); c.fill();
  }
  /* aisle rug */
  rect(c,5.3*TS,3*TS,2.4*TS,6.4*TS,'#7a2a3a'); rect(c,5.3*TS+4,3*TS,2,6.4*TS,'#d9b84a'); rect(c,7.7*TS-6,3*TS,2,6.4*TS,'#d9b84a');
  for(let ty=0;ty<LIBH;ty++) for(let tx=0;tx<LIBW;tx++){
    const ch=libCh(tx,ty), px=tx*TS, py=ty*TS;
    if(ch==='P'){ rect(c,px,py+8,TS,TS-8,'#8a6238'); rect(c,px,py+8,TS,4,'#b98a55'); rect(c,px,py+TS-3,TS,3,'#5b3f22'); if(tx%3===0&&svc) miniDuck(c,px+16,py+6,['#c9a46a','#e8e0c0','#8a9fb0','#d98a8a','#7ab07a'][(tx+ty)%5],null); }
    else if(ch==='A'){ rect(c,px,py+6,TS,TS-6,'#e8e0c0'); rect(c,px,py+6,TS,3,'#fff'); rect(c,px,py+TS-4,TS,4,'#a39a82');
      if(tx===6){ c.fillStyle='#e0b84a'; c.beginPath(); c.moveTo(px+8,py+2); c.quadraticCurveTo(px+16,py-26,px+26,py-6); c.quadraticCurveTo(px+18,py-4,px+8,py+2); c.fill(); rect(c,px+14,py-8,1.5,14,'#a37f1c'); circ(c,px+16,py-8,22,'rgba(255,230,140,'+(0.08+0.04*Math.sin(time*2)).toFixed(2)+')'); }
      if(tx===4||tx===8){ ell(c,px+16,py+14,9,3,'#3a7ca5'); } }
    else if(ch==='C'){ rect(c,px+12,py+10,8,18,'#f4efe0'); rect(c,px+10,py+26,12,3,'#8a6a2a'); const f=Math.sin(time*9+tx)*1; c.fillStyle='#ffb347'; c.beginPath(); c.ellipse(px+16,py+6,2.4,4+f,0,0,6.3); c.fill(); circ(c,px+16,py+6,15,'rgba(255,200,100,0.10)'); }
    else if(ch==='L'){ rect(c,px+13,py+14,6,14,'#5b3f22'); rect(c,px+7,py+8,18,8,'#8a6238'); rect(c,px+9,py+9,14,5,'#f4efe0'); rect(c,px+15,py+9,2,6,'#c0392b'); }
    else if(ch==='B'){ rect(c,px,py,TS,TS,'#5b4430'); rect(c,px+2,py+2,TS-4,TS-4,'#3b2b1e'); const sp=['#e0b84a','#3a7ca5','#f4efe0','#c0392b','#5aa05a'];
      for(let r=0;r<3;r++){ rect(c,px+2,py+3+r*9+8,TS-4,1.5,'#8a6a45'); for(let k=0,x=px+3;k<6;k++){ const w=3+((r*3+k)%3); rect(c,x,py+3+r*9,w,8,sp[(r*2+k)%5]); x+=w+0.5; } } }
    else if(ch==='N'){ miniDuck(c,px+16,py+12,'#f4efe0','#d9d2bf'); circ(c,px+16,py+20,12,'rgba(255,230,160,0.14)'); }
  }
  if(svc){ for(const [dx,dy,col] of [[2,4.8,'#c9a46a'],[3,5.3,'#8a9fb0'],[8.8,4.8,'#d98a8a'],[9.5,5.4,'#7ab07a'],[2.4,6.3,'#e8e0c0'],[9,6.4,'#c0392b']]) miniDuck(c,dx*TS+14,dy*TS-6+Math.sin(time*2+dx)*0.8,col,null); }
  const gl=c.createRadialGradient(6.5*TS,2.5*TS,10,6.5*TS,2.5*TS,6*TS); gl.addColorStop(0,'rgba(255,214,140,'+(svc?0.28:0.16)+')'); gl.addColorStop(1,'rgba(255,214,140,0)'); c.fillStyle=gl; c.fillRect(0,0,RW,RH);
  drawMe(c,time);
  if(g.target&&g.mode==='play') drawBubble(c,g.target.x,g.target.y,time,'Z');
  const a2=ambient(g.clock);
  if(a2[3]>0.1){ c.fillStyle='rgba(20,18,50,'+(a2[3]*0.16).toFixed(2)+')'; c.fillRect(ox,oy,vw,vh); }
  c.setTransform(1,0,0,1,0,0);
}

/* ===== SHOP ITEMS: every little thing now does a little thing ===== */
ITEMS.socks.use='equip'; ITEMS.socks.slot='feet'; ITEMS.socks.wear='socks'; ITEMS.socks.desc='Striped. Webbed feet in socks are surprisingly good in puddles. Wear them and water slows you down less.'; delete ITEMS.socks.note;
ITEMS.feather.use='equip'; ITEMS.feather.slot='charm'; ITEMS.feather.wear='sparkle'; ITEMS.feather.desc='Not a duck feather. You checked. Tuck it in and a shimmer of colours you cannot name follows you around.'; delete ITEMS.feather.note;
ITEMS.clover.desc='Four leaves. Probably. Rub it for luck: until midnight, every crumb you find, every job and every favor pays 1 more crumb. Used up.';
ITEMS.notebook.desc='Jot down where and when you are. Your last ten notes are kept in your Journal.';
ITEMS.novel.desc='"The Case of the Missing Pond." Read one chapter at a time. Six chapters, and a small prize for the ending.';
ITEMS.guide.desc='Pictures of ducks. Rude comments in the margins. Read it next to a duck and it tells you what they would love as a gift.';
ITEMS.cookbook.desc='Four hundred recipes. All of them are bread. Use it with a Crusty Bread in your pack and it becomes a Berry Muffin.';
ITEMS.specs.desc='Sold only to trusted customers. Look through them to spot a town you have not found yet, if one is within a few days of walking.';
ITEMS.daisy.desc='A cheerful little bunch tied with grass. Pluck the petals for a short, giddy skip in your step. Used up.';
ITEMS.bouquet.desc='Every colour at once. Hand it to a whole town at once: +2 reputation where you are standing. Used up.';
ITEMS.bulb.desc='Plant it where you stand. Wait two days. Flowers grow there for good. You are not good at waiting.';
ITEMS.ducky.desc='A smaller, squeakier, far less dignified relative. Explain your case to it and it squeaks. Somehow that helps.';
ITEMS.kite.desc='It flies if you run. Fly it for a good burst of speed. (Does not get used up.)';
ITEMS.marbles.desc='Little glass worlds in a drawstring bag. Roll them. Occasionally, something rolls out of a crack.';
ITEMS.top.desc='Wind it, pull it, watch it go. Hypnotic. Half an hour passes while you watch.';
ITEMS.pebble.desc='Smooth, round, and unreasonably shiny. Skip it. See how far you can get.';
ITEMS.key.desc='It is warm to the touch. It does not fit any lock, but it hums, and it hums louder in one direction.';
const DIRW=['east','south-east','south','south-west','west','north-west','north','north-east'];
function dirWord(dx,dy){ const a=Math.atan2(dy,dx); return DIRW[((Math.round(a/(Math.PI/4))%8)+8)%8]; }
const NOVEL=[
 'Chapter 1. It was a dark and stormy puddle. Detective Mallard stared at the empty space where the pond used to be.',
 'Chapter 2. "Somebody drained it," said the heron, suspiciously calm. "Somebody tall."',
 'Chapter 3. A single clue: a webbed footprint, six toes. Detective Mallard counted twice. Then a third time, to be sure.',
 'Chapter 4. The pond was not stolen. It had been moved. Eleven hundred buckets, one at a time, by a frog with a lot of free time.',
 'Chapter 5. "Why?" asked the Detective. "Because it was MY pond," said the frog, "and nobody asked me to the lily party."',
 'Chapter 6. The pond was returned. The frog was invited to every party after. The Detective went home, smelling of lilies and justice. THE END.'
];
const PEBBLE_LINES=['Plop. Straight to the bottom.','Skip... plop.','Skip, skip, plop.','Skip, skip, skip... plop!','Four skips! Somewhere a pond is impressed.','Five skips! The ducks nearby clap their wings.','Six! Seven! The pebble skips right across the far bank. Legendary.'];
function nearestNpc(r){
  let best=null,bd=r;
  for(const n of g.npcs){ const d=Math.hypot(n.x-g.px,n.y-g.py); if(d<bd){ bd=d; best=n; } }
  return best;
}
function itemEffect(id){
  const st=g.story;
  if(!st) return false;
  const T=(m,ms)=>{ closeInv(); toast(m,ms||3400); };
  const S=(l)=>{ closeInv(); say('',l); };
  switch(id){
  case 'clover':
    delInv('clover'); st.luckDay=g.day; T('You rub the clover. Lucky until midnight: +1 crumb on every crumb, job and favor.',3800); return true;
  case 'notebook':{
    const n=st.notes||(st.notes=[]);
    n.push('Day '+g.day+', '+clockStr()+': '+areaName()+'.'); if(n.length>10) n.shift();
    T('You jot it down: Day '+g.day+', '+clockStr()+', '+areaName()+'. (See your Journal.)',3600); return true; }
  case 'novel':{
    const c=st.novelCh||0;
    if(c>=NOVEL.length){ S(['You re-read your favourite bit, where the frog says "nobody asked me to the lily party". Still gets you.']); return true; }
    st.novelCh=c+1;
    if(st.novelCh===NOVEL.length){ g.crumbs+=5; coin(); S([NOVEL[c],'You close the book, satisfied. A bookmark falls out with 5 crumbs taped to it. Reader reward.']); }
    else S([NOVEL[c],'(Chapter '+st.novelCh+' of '+NOVEL.length+'.)']);
    return true; }
  case 'guide':{
    const n=nearestNpc(150);
    if(n){
      let f=null; try{ f=giftFav(n); }catch(e){}
      if(f&&ITEMS[f]) S(['You look up '+n.name+' in the Field Guide. The entry is scribbled over with margin notes.','"Adores a '+ITEMS[f].name+'. Do not tell them I said so."']);
      else S(['You look up '+n.name+'. The margin reads: "Hard to categorise. Respect."']);
    } else S(['You flip through the guide. "Mallard: common, but charming." Somebody has circled it twice.','Read it next to a duck and it will tell you what they would love as a gift.']);
    return true; }
  case 'cookbook':
    if(g.inv.crust){ delInv('crust'); addItem('muffin'); closeInv(); say('',['Page 212. You tear the crust, add a pinch of berries and a lot of hope.','Crusty Bread became a Berry Muffin.']); }
    else S(['Four hundred bread recipes, and every one starts the same way: "Take one crusty bread."','Bring a Crusty Bread and it can become a Berry Muffin.']);
    return true;
  case 'specs':{
    if(g.scene!=='world'){ T('Nothing to see but the inside of a wall.'); return true; }
    const prx=Math.floor((g.px/TS+24)/REG), pry=Math.floor((g.py/TS+24)/REG);
    let best=null,bd=1e9;
    for(let dy=-3;dy<=3;dy++) for(let dx=-3;dx<=3;dx++){
      const t=getTown(prx+dx,pry+dy);
      if(t&&!g.towns.has(t.key)){ const d=Math.hypot(t.cx*TS-g.px,t.cy*TS-g.py); if(d<bd){ bd=d; best=t; } }
    }
    if(best){ const dx=best.cx*TS-g.px, dy=best.cy*TS-g.py; T('Through the lenses: chimney smoke, '+(bd/TS>90?'far':'not so far')+' to the '+dirWord(dx,dy)+'. A town you have not found yet.',4400); }
    else T('You scan every horizon. Trees, hills, and one very smug frog. No new towns in sight.',3800);
    return true; }
  case 'daisy':
    delInv('daisy'); g.boost=Math.min(150,g.boost+12); T('He loves me. He loves me not. He loves me! Giddy, you skip for a while.',3400); return true;
  case 'bouquet':{
    const t=g.curTown?townByKey(g.curTown):null;
    if(t){ delInv('bouquet'); addRep(t,2); T('You pass the bouquet around. Everyone in '+t.name+' gets one flower and a smile.',3600); }
    else T('The flowers are lovely, but there is no town around to give them to.',3200);
    return true; }
  case 'bulb':{
    if(g.scene!=='world'){ T('You cannot plant a bulb indoors. The floor is very offended.'); return true; }
    const tx=Math.floor(g.px/TS), ty=Math.floor(g.py/TS);
    const wet=tileAt(tx,ty)===T_WATER();
    const L=st.tulips||(st.tulips=[]);
    if(wet||solidTile(tx,ty)){ T('Not here. Find some dry ground.'); return true; }
    if(L.some(p=>p.x===tx&&p.y===ty)){ T('There is already a tulip here. Give it some space.'); return true; }
    if(L.length>=16){ T('Your tulips have taken over the world. No more room.'); return true; }
    delInv('bulb'); L.push({x:tx,y:ty,d:g.day}); T('You plant the bulb and pat it flat. It will bloom in two days.',3200); return true; }
  case 'ducky':{
    const o=(typeof storyObjective==='function')?storyObjective():null;
    closeInv(); quack();
    if(o) say('',['You explain the whole case to the rubber duckie. Squeak, it says. Somehow, you realise:',o.replace(/<[^>]+>/g,'')]);
    else say('',['Squeak! It has no advice, but you feel better for saying it out loud.']);
    return true; }
  case 'kite':
    g.boost=Math.min(150,g.boost+20); T('You run, the kite lifts, and you fly across the grass! (+20s speed)',3000); return true;
  case 'marbles':{
    const r=rnd();
    if(r<0.18){ g.crumbs+=1; coin(); T('Click, click, click... one rolls into a crack, and a crumb rolls out. +1 crumb.',3200); }
    else T(pick(['Click, click. A tiny blue one wins.','You roll a perfect spiral. Nobody sees it.','One rolls under a bench. You pretend that was on purpose.']),2800);
    return true; }
  case 'top':{
    closeInv(); fade(0.9); advanceClock(0.5); quack();
    toast('You watch the top spin. And spin. Half an hour goes by. It is '+clockStr()+'.',3600); return true; }
  case 'pebble':{
    const s=1+Math.floor(Math.random()*7);
    st.skipBest=Math.max(st.skipBest||0,s);
    T(PEBBLE_LINES[s-1]+' (Best: '+st.skipBest+' skips.)',3400); return true; }
  case 'key':{
    let tx,ty,lbl;
    if(st.pagesQuest&&!st.ch2Done){
      let bd=1e9; for(let i=0;i<PAGES.length;i++){ if(st.pages&&st.pages[i]) continue; const d=Math.hypot(KX+PAGES[i][0]-g.px/TS,KY+PAGES[i][1]-g.py/TS); if(d<bd){ bd=d; tx=KX+PAGES[i][0]; ty=KY+PAGES[i][1]; } }
    }
    if(tx===undefined){ const th=(window.D10&&D10.treeKey)?D10.treeKey():null; if(th){ tx=th[0]; ty=th[1]; } else { tx=KX; ty=KY; } }
    const dx=tx-g.px/TS, dy=ty-g.py/TS, dist=Math.hypot(dx,dy);
    if(dist<4) T('The key hums right through your feathers. Whatever it wants is under your feet.',3800);
    else T('The key hums, warmest facing '+dirWord(dx,dy)+'. '+(dist<20?'The hum is strong.':dist<80?'A steady hum.':'A faint hum, far away.'),3800);
    return true; }
  }
  return false;
}
function T_WATER(){ return T.WATER; }
function itemJournal(sec,line){
  const st=g.story; if(!st) return;
  const has=(st.notes&&st.notes.length)||st.skipBest||(st.tulips&&st.tulips.length)||st.novelCh;
  if(!has) return;
  sec('Pocket Odds and Ends');
  if(st.notes&&st.notes.length){ line('Notebook:'); st.notes.slice().reverse().forEach(n=>line(n,'jdim')); }
  if(st.novelCh) line('Detective Novel: chapter '+Math.min(st.novelCh,NOVEL.length)+' of '+NOVEL.length+(st.novelCh>=NOVEL.length?' (finished).':'.'));
  if(st.skipBest) line('Best pebble skip: '+st.skipBest+'.');
  if(st.tulips&&st.tulips.length) line('Tulips planted: '+st.tulips.length+'.');
}
function luckBonus(){ return g.story&&g.story.luckDay===g.day?1:0; }
function drawItemEffects(c,time){
  /* tulips and worn extras, drawn in world space */
  if(g.scene==='world'&&g.story.tulips) for(const p of g.story.tulips){
    const age=g.day-p.d, x=(p.x+0.5)*TS, y=(p.y+0.9)*TS;
    if(Math.abs(x-g.px)>700||Math.abs(y-g.py)>520) continue;
    ell(c,x,y,7,2.5,'rgba(0,0,0,0.18)');
    if(age<1){ rect(c,x-1,y-6,2,6,'#4f9a4a'); ell(c,x-3,y-5,3,1.5,'#6fbf5a'); ell(c,x+3,y-6,3,1.5,'#6fbf5a'); }
    else if(age<2){ rect(c,x-1,y-12,2,12,'#4f9a4a'); ell(c,x-4,y-5,4,1.7,'#5fb04e'); ell(c,x+4,y-7,4,1.7,'#5fb04e'); circ(c,x,y-13,2.4,'#7fbf6a'); }
    else { const col=['#e04a5a','#f2c230','#d46ad0','#f08a3a','#ffffff'][((p.x*7+p.y*3)%5+5)%5];
      rect(c,x-1,y-12,2,12,'#4f9a4a'); ell(c,x-4,y-5,4,1.7,'#5fb04e'); ell(c,x+4,y-7,4,1.7,'#5fb04e');
      const sw=Math.sin(time*1.5+p.x)*0.6; c.fillStyle=col; c.beginPath(); c.moveTo(x-5+sw,y-18); c.lineTo(x-2,y-13); c.lineTo(x,y-19); c.lineTo(x+2,y-13); c.lineTo(x+5+sw,y-18); c.quadraticCurveTo(x+5,y-9,x,y-9); c.quadraticCurveTo(x-5,y-9,x-5+sw,y-18); c.fill(); }
  }
  if(g.worn.feet==='socks'){ const px=g.px, py=g.py; for(const sx of [-6,2]){ rect(c,px+sx,py-4,4,2,'#d94a4a'); rect(c,px+sx,py-2,4,2,'#f4efe0'); } }
  if(g.worn.charm==='sparkle'){
    for(let k=0;k<5;k++){ const a=time*1.7+k*1.26, r=16+4*Math.sin(time*2+k), x=g.px+Math.cos(a)*r, y=g.py-16+Math.sin(a)*r*0.7, h=(time*70+k*70)%360;
      c.fillStyle='hsla('+h+',90%,70%,0.85)'; c.fillRect(x-1,y-3,2,6); c.fillRect(x-3,y-1,6,2); }
  }
}

/* ===== objective, journal, markers ===== */
function ch2Objective(){
  const st=g.story;
  if(!st.visionSeen) return null;
  if(!st.hermitTold){
    const nx=nextCamp();
    return nx?'Follow the <b>cold campfires</b> to find the hermit.  Next fire: '+nx:'The fires end here. Find the hermit and <b>talk to him</b>, in his hollow east of Kingsbill.';
  }
  if(st.ch2Done) return 'Hermit Mallow walks beside you. Emberwick waits in the Hollow Wood, north-east of Mallardia. (The story continues...)';
  if(st.pagesQuest){
    const n=pagesFound();
    return n>=3?'You have all three pages. Take them to <b>Hermit Mallow</b>.':'Win the hermit\'s trust: find the three missing pages of the <b>Red Edict</b> ('+n+'/3). With the dead, with the watchers, with the swans.';
  }
  if(st.rejected) return 'Return to <b>Hermit Mallow</b> and tell him you found his people. Bring him with you.';
  if(st.bookRead) return 'The book speaks of <b>Emberwick</b>, a hidden town of red ducks north-east of the kingdom, in a forest that moves. Find it. Remember the trick.';
  if(st.bookFound) return 'Open your pack (<b>I</b>) and examine the book. The hermit\'s <b>decoder</b> will turn the scribbles into words.';
  return 'Find the hidden book in the <b>Royal Library</b> of Kingsbill (always open): north wall, fourth shelf from the west corner.';
}
function ch2Journal(sec,line){
  const st=g.story;
  if(!st.visionSeen) return;
  sec('Chapter 2: The Red Ducks');
  line('At the castle gate you were overcome by a vision: the hermit\'s cottage, and a joyful reunion with others of his kind.');
  if(st.hermitTold){
    line('Hermit Mallow was cast out as a child by King Eider\'s Red Edict. "Most of us were never soldiers."');
    line('He says the truth of the red ducks is hidden in a cipher book in the Royal Library: north wall, fourth shelf from the west corner, behind "Pondweed, Vol. IX". He gave you a Cipher Decoder.');
  } else line('Follow the cold campfires to find the hermit in his hollow. Fires found: '+(st.camps?Object.keys(st.camps).length:0)+' / '+CAMPS.length);
  if(st.bookRead){
    line('The Red Book, decoded:');
    BOOK.forEach(p=>line(p,'jdim'));
  } else if(st.bookFound) line('You found the Cipher-Bound Book. Use the decoder on it.');
  if(st.rejected) line('You found Emberwick and were turned away at once. The red ducks will not listen to a yellow-feather.');
  if(st.pagesQuest){
    line('The hermit suspects a trap. To earn his trust, find the three missing pages of the Red Edict ('+pagesFound()+'/3).');
    for(let i=0;i<3;i++) if(st.pages&&st.pages[i]) line(PAGE_TEXT[i],'jdim');
  }
  if(st.ch2Done) line('The hermit trusts you now, and follows. End of Chapter 2.');
}

/* ===== the per-frame driver ===== */
function ch2Update(dt){
  const st=g.story;
  if(g.scene==='world'&&g.mode==='play'&&st.castleSeen&&!st.faintStarted){ startFaint(); return; }
  followUpdate(dt);
  woodUpdate(dt);
  libUpdate();
  templeUpdate(dt);
}

/* ===== wrappers: hook the new chapter into the existing game without rewriting it ===== */
{
  const _kingdomTile=kingdomTile;
  kingdomTile=function(x,y){ const t=ch2Tile(x,y); if(t!==null) return t; return _kingdomTile(x,y); };
  const _blocks=kingdomBlocksTown;
  kingdomBlocksTown=function(rx,ry){ return _blocks(rx,ry)||ch2BlocksTown(rx,ry); };
  const _kBuilding=kBuilding;
  kBuilding=function(lx,ly){ return ch2Building(lx,ly)||_kBuilding(lx,ly); };
  const _kArea=kingdomArea;
  kingdomArea=function(tx,ty){ const a=ch2Area(tx,ty); return a||_kArea(tx,ty); };
  const _darkAt=darkAt;
  darkAt=function(x,y){ const w=ch2Dark(x,y); return w>0?w:_darkAt(x,y); };

  const _drawKTile=drawKTile;
  drawKTile=function(c,x,y,t,px,py,time,objs,night){
    if(t===KCAMP){ kGround(c,x,y,px,py); objs.push({y:py+TS,k:'fn',f:()=>drawColdCamp(c,px,py,time,x)}); return; }
    if(t===KPAGE){
      if(kZone(x-KX,y-KY)==="Gordamom's Siege Field") _drawKTile(c,x,y,KASH,px,py,time,objs,night); else kGround(c,x,y,px,py);
      drawPageGlint(c,px,py,time,x,y); return;
    }
    _drawKTile(c,x,y,t,px,py,time,objs,night);
  };
  const _drawWorld=drawWorld;
  drawWorld=function(c,W,H,kd,camX,camY,time){ _drawWorld(c,W,H,kd,camX,camY,time); ch2Overlay(c,W,H,kd,camX,camY,time); };
  const _drawInterior=drawInterior;
  drawInterior=function(c,W,H,kd,time){ if(g.scene==='lib'){ if(g.libKind==='temple') drawTemple(c,W,H,kd,time); else drawLibrary(c,W,H,kd,time); return; } _drawInterior(c,W,H,kd,time); };

  const _kInteract=kingdomInteract;
  kingdomInteract=function(t,tx,ty){
    if(t===KCAMP){ campInteract(tx,ty); return; }
    if(t===KPAGE){ pageInteract(tx,ty); return; }
    if(t===KHDOOR){
      const b=kBuilding(tx-KX,ty-KY);
      if(b&&b.type==='library'){ enterLibrary(); return; }
      if(b&&b.type==='temple'){ enterTemple(); return; }
      if(b&&b.type==='rhouse'){ say('',[pick(['The door is shut. A curtain twitches, then snaps closed.','Someone inside stops humming. Nobody answers.'])]); return; }
    }
    _kInteract(t,tx,ty);
  };
  const _solidTile=solidTile;
  solidTile=function(tx,ty){ if(g.scene==='lib') return libSolid(tx,ty); return _solidTile(tx,ty); };
  const _findTarget=findTarget;
  findTarget=function(){ if(g.scene==='lib'){ libFindTarget(); return; } _findTarget(); };
  const _areaName=areaName;
  areaName=function(){ if(g.scene==='lib') return g.libKind==='temple'?'Temple of Feathers':'Royal Library'; return _areaName(); };
  const _interact=interact;
  interact=function(){ const tg=g.target; if(tg&&tg.k==='lib'){ quack(); libInteract(tg); return; } _interact(); };
  const _snapshot=snapshot;
  snapshot=function(){ const s=_snapshot(); if(g.scene==='lib'&&g.saved){ s.x=g.saved.x; s.y=g.saved.y; s.dir=g.saved.dir||g.dir; } return s; };

  const _storyObjective=storyObjective;
  storyObjective=function(){
    const st=g.story;
    if(st.ghostHeard&&st.castleSeen){ const o=ch2Objective(); if(o) return o; }
    return _storyObjective();
  };
  const _journalExtra=journalExtra;
  journalExtra=function(sec,line){ _journalExtra(sec,line); ch2Journal(sec,line); templeJournal(sec,line); itemJournal(sec,line); };
  const _extraNpcs=extraNpcs;
  extraNpcs=function(list){
    _extraNpcs(list);
    if(g.scene!=='world') return;
    const px=g.px/TS, py=g.py/TS;
    if(Math.abs(px-WCX)<40&&Math.abs(py-WCY)<30) for(const n of villageNpcs()) list.push(n);
    if(g.story.hermitFollow){ const h=hermitObj(); if(h&&list.indexOf(h)<0) list.push(h); }
  };
  const _specialTalk=specialTalk;
  specialTalk=function(n){ if(n.name==='Hermit Mallow'&&hermitTalk(n)) return; _specialTalk(n); };
  const _specialMark=specialMark;
  specialMark=function(n){
    if(n.name==='Hermit Mallow'){
      const st=g.story;
      if(n.talking||st.ch2Done) return null;
      if(st.visionSeen&&(!st.hermitTold||(st.rejected&&!st.pagesQuest)||(st.pagesQuest&&pagesFound()>=3))) return {ch:'!',col:'#ffd166'};
      return null;
    }
    return _specialMark(n);
  };
  const _useItem=useItem;
  useItem=function(id){
    const it=ITEMS[id];
    if(it&&it.use==='faith'){ closeInv(); readFaithBook(); return; }
    if(itemEffect(id)) return;
    if(it&&it.use==='book'){ closeInv(); useBook(id==='redbookd'); return; }
    if(it&&it.use==='pages'){ closeInv(); readPages(); return; }
    _useItem(id);
  };
  const _drawIcon=drawIcon;
  drawIcon=function(c,id,s){
    if(id==='decoder'||id==='redbook'||id==='redbookd'||id==='edictpage'||id==='faithbook'||id==='blessfeather'){
      const u=s/16; c.save(); c.scale(u,u); c.clearRect(0,0,16,16);
      const R=(x,y,w,h,col)=>{ c.fillStyle=col; c.fillRect(x,y,w,h); };
      if(id==='decoder'){
        circ(c,8,8,7.2,'#8a6a2a'); circ(c,8,8,6,'#c9a24a'); circ(c,8,8,4.2,'#e8d9a0'); circ(c,8,8,2.4,'#8a6a2a'); circ(c,8,8,1,'#3b2a18');
        R(7.5,1,1,3,'#3b2a18'); R(7.5,12,1,3,'#3b2a18'); R(1,7.5,3,1,'#3b2a18'); R(12,7.5,3,1,'#3b2a18');
      } else if(id==='faithbook'){
        R(3,2,10,12,'#f4efe0'); R(3,2,2,12,'#c9a24a'); R(6,4,6,1,'#8a6a2a'); R(6,7,6,1,'#8a6a2a'); R(6,10,4,1,'#8a6a2a');
        c.fillStyle='#e0b84a'; c.beginPath(); c.moveTo(11,2); c.quadraticCurveTo(14,5,11,9); c.quadraticCurveTo(10,5,11,2); c.fill();
      } else if(id==='blessfeather'){
        c.fillStyle='#fffdf0'; c.beginPath(); c.moveTo(3,14); c.quadraticCurveTo(3,4,13,2); c.quadraticCurveTo(12,12,3,14); c.fill();
        R(4,12,1,1,'#c9a24a'); R(5,10,1,1,'#e8e0c0'); R(7,8,1,1,'#e8e0c0'); R(9,5,1,1,'#e8e0c0'); circ(c,12,3,1.2,'rgba(255,230,140,0.9)');
      } else if(id==='edictpage'){
        R(3,2,10,12,'#f4efe0'); R(3,2,10,1,'#d8cfae'); R(5,5,6,1,'#8a7a5a'); R(5,7,6,1,'#8a7a5a'); R(5,9,4,1,'#8a7a5a'); R(7,1,2,13,'#c0392b'); circ(c,8,12,1.4,'#8a1a1a');
      } else {
        R(3,2,10,12,id==='redbook'?'#7a2a2a':'#a8432b'); R(3,2,2,12,'#4a1414'); R(6,5,6,1,'#d8b878'); R(6,8,5,1,'#d8b878');
        if(id==='redbook'){ R(7,4,1,1,'#d8b878'); R(10,10,1,1,'#d8b878'); R(7,11,2,1,'#d8b878'); } else { R(6,11,5,1,'#d8b878'); circ(c,9,6.5,0.1,'#d8b878'); }
      }
      c.restore(); return;
    }
    _drawIcon(c,id,s);
  };
  /* the story engine's own per-frame hook */
  const _drawMe=drawMe;
  drawMe=function(c,time){ _drawMe(c,time); drawItemEffects(c,time); };
  const _storyUpdate=storyUpdate;
  storyUpdate=function(dt){ _storyUpdate(dt); ch2Update(dt); };
}
