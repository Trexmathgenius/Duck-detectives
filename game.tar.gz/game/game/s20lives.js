'use strict';
/* ===== v1.29: LIVING CHARACTERS =====
   Every person in the world now (1) exists once, (2) remembers you, and (3) grows as the story and you do.

   1. ONE OF EACH
      - A named character who is standing somewhere for the story (an S2 copy) is never also standing at home.
        This is checked across the whole world, not only on screen, so Halbeak is not at the Old Tree and the plaza at once.
      - Two copies of a name on screen are collapsed to one.
      - Townducks, shopkeepers, ducklings and carters used to be named from pools of 12-20, so every town had its own
        "Clementine". Names are now laid out on a 3x3 lattice of regions: no two people anywhere near each other share a
        first name, and townducks and keepers carry a family name as well. Ducklings never share a name with adults.
      - The two gate guards of Cinderhold have names of their own.
   2. MEMORY  (saved in g.story.lv)
      - Every character keeps: how many times you have talked, the day you met, when you last came by, the part of the
        story you were in last time, the colour of your feathers last time, and which things they have already told you.
      - Nobody introduces themselves twice. Nobody repeats the same speech after a reload.
      - Coming back after a long time is noticed. So is a change of feathers, a new reputation, and what you did.
   3. GROWTH
      - The world has a phase (before the castle, the sealed castle, after Emberwick, Acts II-VI, after the end).
        Each character has something to say for each, by route and by ending. Nobody falls back to their first-day lines.
      - After the end the Act VI people stay in the world and get on with their lives (King Eider if he lives, Cinder,
        Bree, Hob, Orla, Tam, Brand, Whistle). In the "stay" ending the sleepers sleep, and Mallow sits by the Tree.
      - Townducks have small lives of their own that move on day by day, and talk about what the story is doing.
      - Ducklings grow up a little, and remember you.
   Voices (the words) live in s20voices.js. This file is the machinery and must load first. Exposes window.LV. */
(function(){
const LV=window.LV=window.LV||{};
const safe=(f,d)=>{ try{ return f(); }catch(e){ console.warn('lives',e); return d; } };
const strHash=s=>{ let h=2166136261; s=String(s); for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619); } return h>>>0; };
const mod=(a,n)=>((a%n)+n)%n;
const cap1=s=>s?s.charAt(0).toUpperCase()+s.slice(1):s;
LV.strHash=strHash;

/* ======================================================================
   1. WHERE THE STORY IS
   ====================================================================== */
const PH=['p0','p1','p2','a2','a3','a4','a5','a6','end'];
const GROUP={p0:'early',p1:'early',p2:'early',a2:'war',a3:'war',a4:'crisis',a5:'crisis',a6:'after',end:'after'};
LV.PH=PH;
function q2(){ return g.story&&g.story.s2; }
LV.phase=function(){
  const st=g.story||{}, q=st.s2;
  if(q&&q.ch==='end') return 'end';
  if(q&&q.ch){
    const n=safe(()=>s2num(q.ch),5)||5;
    return n<=8?'a2':n<=12?'a3':n<=16?'a4':n<=20?'a5':'a6';
  }
  if(st.ch3Met||st.dinnerDone||st.isRed||st.banished||st.dinnerAt||st.reportAt) return 'p2';
  if(st.kfound||st.castleSeen||st.ghostHeard) return 'p1';
  return 'p0';
};
LV.pi=ph=>PH.indexOf(ph||LV.phase());
LV.ending=function(){ const q=q2(); return (q&&q.ending)||''; };
LV.after=function(){ return LV.phase()==='end'&&!!LV.ending(); };
LV.ctx=function(){
  const st=g.story||{}, ph=LV.phase(), q=q2()||{};
  const route=safe(()=>q.ch?s2route():(st.isRed?'red':st.banished||st.dinnerDone?'crown':''),'');
  const keeper=safe(()=>q.ch?(routeOf()==='k'||/^c1[345]k$/.test(q.ch)):false,false);
  const c={
    ph, pi:PH.indexOf(ph), grp:GROUP[ph], route, keeper, rk:keeper?'k':route,
    ending:q.ending||'', variant:q.endVariant||'', red:!!st.isRed, banished:!!st.banished,
    trait:safe(()=>S4.self(),null), nick:safe(()=>S4.nick(),null),
    crown:safe(()=>S6.get('crown'),0), hearth:safe(()=>S6.get('hearth'),0), mallowS:safe(()=>S6.get('mallow'),0), sleepers:safe(()=>S6.get('sleepers'),0),
    led:q.led||{}, fl:q.fl||{}, done:q.done||{}, path:q.path||{}, ch:q.ch||'',
    march:(q.fl||{}).march||'', eiderLives:safe(()=>eiderLives(),true),
    fame:Object.keys(q.done||{}).length, day:g.day, st
  };
  c.at=id=>safe(()=>s2at(id),false);
  c.did=id=>!!(c.done&&c.done[id]);
  c.cx=id=>safe(()=>S4.cx(id),undefined);
  c.k3=k=>safe(()=>k3(k),undefined);
  c.seen=k=>(c.path.seen||{})[k];
  c.friend=k=>!!((c.path.friend||{})[k]);
  return c;
};

/* ======================================================================
   2. MEMORY
   ====================================================================== */
function LM(){ const st=g.story||(g.story={}); if(!st.lv) st.lv={m:{},v:1}; if(!st.lv.m) st.lv.m={}; return st.lv; }
const nowH=()=>g.day*24+g.clock;
LV.mem=function(name){
  const m=LM().m;
  if(!m[name]){
    m[name]={n:0,met:0,last:0,ph:'',red:-1,nick:'',idx:{},seen:{}};
    /* a save from before 1.29: the kingdom already kept a list of the people you had met */
    const st=g.story||{};
    if(st.met&&st.met[name]){ m[name].n=1; m[name].met=1; m[name].last=nowH()-48; m[name].ph='p1'; }
  }
  return m[name];
};
LV.peek=name=>LM().m[name]||null;
LV.daysAway=m=>m&&m.last?Math.floor((nowH()-m.last)/24):0;
function remember(name,ctx){
  const m=LV.mem(name);
  if(!m.n) m.met=g.day;
  m.n++; m.last=nowH(); m.ph=ctx.ph; m.red=ctx.red?1:0; if(ctx.nick) m.nick=ctx.nick;
  const st=g.story; st.met=st.met||{}; st.met[name]=1;
}
LV.remember=remember;

/* ======================================================================
   3. VOICES (filled in by s20voices.js)
   ====================================================================== */
const VOICES=LV.VOICES=LV.VOICES||{};
LV.voice=function(name,def){ VOICES[name]=Object.assign(VOICES[name]||{},def); return VOICES[name]; };
LV.ROLE=LV.ROLE||{};   /* role -> phase -> convos : what anyone of that kind would say, if they have nothing of their own */
LV.TONE=LV.TONE||{};   /* tone -> {call, away, long, again, feathers, nick, meet} */

/* a value in a voice can be: an array of conversations, a function of ctx, or an object keyed by
   ending / route / 'k' (the keeper's road) / 'red' / 'yellow' / 'any' */
function resolve(v,ctx){
  for(let guard=0;guard<6&&v;guard++){
    if(typeof v==='function'){ v=safe(()=>v(ctx),null); continue; }
    if(Array.isArray(v)) return v.length?v:null;
    if(typeof v==='object'){
      const keys=[];
      if(ctx.ending) keys.push(ctx.ending);
      if(ctx.keeper) keys.push('k');
      if(ctx.route) keys.push(ctx.route);
      keys.push(ctx.red?'redfeather':'yellow','any');
      let nx=null; for(const k of keys){ if(v[k]!==undefined){ nx=v[k]; break; } }
      v=nx; continue;
    }
    return null;
  }
  return null;
}
LV.resolve=resolve;
/* fill {call} {Call} {days} {nick} {ending-word} in a line */
function fill(s,ctx,V,m){
  if(typeof s==='function') s=safe(()=>s(ctx,m),'')||'';
  s=String(s);
  if(s.indexOf('{')<0) return s;
  const call=callOf(V,ctx,m);
  return s.replace(/\{call\}/g,call).replace(/\{Call\}/g,cap1(call)).replace(/\{days\}/g,String(LV.daysAway(m)))
    .replace(/\{nick\}/g,ctx.nick||call).replace(/\{n\}/g,String(m?m.n:0));
}
LV.fill=fill;
function callOf(V,ctx,m){
  if(V&&V.call){ const c=typeof V.call==='function'?safe(()=>V.call(ctx,m),null):V.call; if(c) return c; }
  const T=LV.TONE[(V&&V.tone)||'folk']||LV.TONE.folk;
  if(T&&T.call) return safe(()=>T.call(ctx,m),'Detective')||'Detective';
  return 'Detective';
}
LV.callOf=callOf;
const pages=(convo,ctx,V,m)=>{
  if(typeof convo==='function') convo=safe(()=>convo(ctx,m),[])||[];
  if(typeof convo==='string') convo=[convo];
  return convo.map(s=>fill(s,ctx,V,m)).filter(s=>s&&s.length);
};
LV.pages=pages;

/* the pool for the current phase: own words first, then the group (war/crisis/after), then what anyone of the role would say */
function poolFor(V,ctx){
  const order=[ctx.ph,ctx.grp];
  if(ctx.ph==='p0') order.push('p1');
  for(const k of order){ if(V&&V[k]!==undefined){ const r=resolve(V[k],ctx); if(r) return {key:k,list:r}; } }
  if(V&&(ctx.ph==='p0'||ctx.ph==='p1')){ const l=V.lines||(V.intro?[V.intro]:null); if(l) return {key:'base',list:l}; }
  const R=LV.ROLE[(V&&V.role)||'folk']||LV.ROLE.folk;
  if(R){ for(const k of order){ if(R[k]!==undefined){ const r=resolve(R[k],ctx); if(r) return {key:'role:'+k,list:r}; } } }
  return {key:'none',list:[['...']]};
}
LV.poolFor=poolFor;

/* ---------- what a person says when you come up to them ---------- */
LV.compose=function(name,n,ctx){
  ctx=ctx||LV.ctx();
  const V=VOICES[name]||{}, m=LV.mem(name), T=LV.TONE[V.tone||'folk']||LV.TONE.folk||{};
  const out=[];
  const knows=m.n>0||(V.knows&&safe(()=>V.knows(ctx),false));
  const phaseNew=m.ph&&m.ph!==ctx.ph;
  if(!knows){
    /* a first meeting: early on, their own first words; later, they have heard of you */
    if(ctx.pi<=2&&V.intro) out.push(...pages(V.intro,ctx,V,m));
    else{
      const meet=V.meet!==undefined?resolve(V.meet,ctx):null;
      if(meet) out.push(...pages(meet[0],ctx,V,m));
      else if(T.meet) out.push(...pages(resolve(T.meet,ctx)[0],ctx,V,m).map(s=>s.replace(/\{who\}/g,V.who||name).replace(/\{name\}/g,name)));
      const p=poolFor(V,ctx); out.push(...pages(p.list[0],ctx,V,m));
      m.idx[p.key]=1;
    }
    return {pages:out,first:true};
  }
  const away=LV.daysAway(m);
  /* 1. hello, if it has been a while */
  if(away>=6&&T.long) out.push(fill(pickBy(resolve(T.long,ctx),name+m.n),ctx,V,m));
  else if(away>=2&&T.away) out.push(fill(pickBy(resolve(T.away,ctx),name+m.n),ctx,V,m));
  /* 2. at most ONE thing about you per visit, in this order: your feathers changed, something you did with them,
        the name people have for you, what they see in you, and what they have heard you did */
  let extra=false, recalled=false;
  if(m.red!==-1&&m.red!==(ctx.red?1:0)&&ctx.red){
    const f=V.feathers!==undefined?resolve(V.feathers,ctx):resolve(T.feathers,ctx);
    if(f){ out.push(...pages(f[0],ctx,V,m)); extra=true; }
  }
  if(!extra) for(const r of (V.recall||[])){
    if(m.seen[r.id]) continue;
    let ok=false; try{ ok=!!r.when(ctx,m); }catch(e){}
    if(!ok) continue;
    m.seen[r.id]=1; out.push(...pages(r.lines,ctx,V,m)); recalled=extra=true; break;
  }
  if(!extra&&ctx.nick&&m.nick!==ctx.nick&&m.n>=2&&!m.seen['nick:'+ctx.nick]){
    m.seen['nick:'+ctx.nick]=1;
    const told=(LM().nickTold=LM().nickTold||{});
    /* a new name goes round a few mouths, not every mouth */
    if((told[ctx.nick]||0)<3&&strHash(name+ctx.nick)%2===0){
      told[ctx.nick]=(told[ctx.nick]||0)+1;
      const f=V.nickLine!==undefined?resolve(V.nickLine,ctx):resolve(T.nick,ctx);
      if(f){ out.push(...pages(f[0],ctx,V,m)); extra=true; }
    }
  }
  if(!extra&&phaseNew&&m.n>=2&&!m.seen['who:'+ctx.ph]){
    const w=safe(()=>LV.whoLine&&LV.whoLine(V,ctx,name,m),null);
    m.seen['who:'+ctx.ph]=1;
    if(w){ out.push(...w.map(s=>fill(s,ctx,V,m))); extra=true; }
  }
  if(!extra&&m.n>=1&&LV.gossip){
    const gl=safe(()=>LV.gossip(V,ctx,name,m),null);
    if(gl){ out.push(...gl.map(s=>fill(s,ctx,V,m))); extra=true; }
  }
  /* 4. what they have to say now: a new part of the story always starts at the top of their list */
  const p=poolFor(V,ctx);
  let i=m.idx[p.key]||0;
  if(phaseNew&&!m.idx['_'+p.key]) i=0;
  m.idx['_'+p.key]=1;
  if(!recalled||phaseNew||out.length<2){
    const list=p.list, k=i%list.length;
    /* once they have told you everything they have for this part of the story, every other visit is about the day itself
       (the weather, the hour, what is going on), so nobody repeats themselves word for word on every visit */
    let small=null;
    if(i>=list.length&&(i-list.length)%2===0&&LV.small) small=safe(()=>LV.small(V,ctx,name,i,m),null);
    if(small&&small.length) out.push(...small.map(s=>fill(s,ctx,V,m)));
    else out.push(...pages(list[k],ctx,V,m));
    m.idx[p.key]=i+1;
  }
  return {pages:out.length?out:['...'],first:false};
};
function pickBy(arr,seed){ if(!arr||!arr.length) return ''; return arr[strHash(seed)%arr.length]; }
LV.pickBy=pickBy;

/* the talk itself */
LV.talk=function(n,doneIn){
  const ctx=LV.ctx(), name=n.name;
  if(!doneIn){ n.dir=OPP[g.dir]; n.moving=false; n.talking=true; }
  const done=doneIn||(()=>{ n.talking=false; n.t=1; });
  const r=LV.compose(name,n,ctx);
  remember(name,ctx);
  say(name,r.pages,done);
};

/* who the living layer speaks for */
LV.claims=function(n){
  if(!n||!n.name) return false;
  const V=VOICES[n.name]; if(!V) return false;
  if(n.special==='s2') return !!(n.s2&&n.s2.lv);
  if(n.kid||n.redKid||n.special==='traveler'||n.special==='stranger') return false;
  const ctx=LV.ctx();
  /* only the kingdom's own citizens: the village folk outside the Hollow Wood (chapter 2) keep their old parts */
  const citizen=n.special==='kingdom'&&safe(()=>kNpcList().indexOf(n)>=0,false);
  if(V.claim) return (citizen||n.special==='rguard'||n.special==='umber')&&!!safe(()=>V.claim(ctx,n),false);
  return citizen;
};

/* ======================================================================
   4. ROUTING THE TALK
   ====================================================================== */
{
  const _st=specialTalk;
  specialTalk=function(n){
    if(LV.claims(n)){
      /* the chapter always gets the first word: a person with a part to play in it still plays it */
      if(n.special!=='s2'&&safe(()=>s2chTalk(n),false)){ LV.touch(n.name); return; }
      LV.talk(n); return;
    }
    _st(n);
    if(n&&n.name&&VOICES[n.name]) LV.touch(n.name);
  };
}
/* a conversation the story ran still counts as having met: they will not introduce themselves later.
   The phase is left alone, so the next ordinary talk still opens with what is new. */
LV.touch=function(name){
  const ctx=LV.ctx(), m=LV.mem(name);
  if(!m.n) m.met=g.day;
  m.n++; m.last=nowH(); m.red=ctx.red?1:0;
  if(!m.ph) m.ph=ctx.ph;
  const st=g.story; st.met=st.met||{}; st.met[name]=1;
};

/* ======================================================================
   5. ONE OF EACH
   ====================================================================== */
let liveCache={t:0,names:new Map()};
function storyCopies(){
  const now=performance.now(), q=g.story&&g.story.s2;
  const key=q?(q.ch+'|'+q.step+'|'+(q.ending||'')+'|'+g.day+'|'+Math.floor(g.clock)):'';
  if(now-liveCache.t<300&&liveCache.key===key) return liveCache.names;
  const m=new Map();
  if(g.story&&g.story.s2) for(const d of (S2.npcs||[])){
    let on=false; try{ on=!d.when||!!d.when(); }catch(e){ on=false; }
    if(!on) continue;
    if(!m.has(d.name)) m.set(d.name,[]);
    m.get(d.name).push(d);
  }
  liveCache={t:now,names:m,key};
  return m;
}
LV.storyCopies=storyCopies;
function markOf(d){ try{ const v=typeof d.mark==='function'?d.mark():d.mark; return v!==undefined&&v!==null&&v!==false; }catch(e){ return false; } }
/* when several story copies of one person are live at once, the one with something to say is the real one */
function chosenCopy(arr){
  if(arr.length===1) return arr[0];
  const marked=arr.filter(markOf);
  const pool=marked.length?marked:arr;
  return pool[pool.length-1];
}
LV.chosenCopy=chosenCopy;
{
  const _en=extraNpcs;
  extraNpcs=function(list){
    _en(list);
    if(g.scene!=='world') return;
    try{
      const live=storyCopies();
      for(let i=list.length-1;i>=0;i--){
        const n=list[i]; if(!n||!n.name) continue;
        const arr=live.get(n.name); if(!arr) continue;
        if(n.special!=='s2'){ list.splice(i,1); continue; }        /* the story has them somewhere else */
        const keep=chosenCopy(arr); if(n.s2&&n.s2!==keep) list.splice(i,1);
      }
      /* anything still doubled on screen: keep the first */
      const seen=new Set();
      for(let i=0;i<list.length;i++){
        const n=list[i]; if(!n||!n.name) continue;
        if(seen.has(n.name)){ list.splice(i,1); i--; continue; }
        seen.add(n.name);
      }
    }catch(e){ console.warn('lives one-of-each',e); }
  };
}

/* ---------- unique names ---------- */
const STORY_WORDS=new Set();
function noteStoryNames(){
  const add=s=>String(s||'').split(/[\s,]+/).forEach(w=>{ if(w) STORY_WORDS.add(w.toLowerCase()); });
  safe(()=>kNpcList().forEach(n=>add(n.name)));
  safe(()=>(S2.npcs||[]).forEach(d=>add(d.name)));
  safe(()=>RED_ADULTS.forEach(a=>add(a[0])));
  safe(()=>RKIDS.forEach(k=>add(k.name)));
  safe(()=>TRV_NAMES.forEach(add));
  ['Gordamom','Eider','Mallow','Halbeak','Ruddock','Cinder','Poppy','Bree','Brand','Hob','Orla','Tam','Umber','Vesper','Alder','Teodor','Marta','Linnet','Tarn','Quill','Dobb','Lark','Sorrel','Yarrow','Marjoram','Teal','Gander'].forEach(add);
}
LV.STORY_WORDS=STORY_WORDS;
const FIRST=('Abernathy Acorn Adelaide Agatha Albie Alma Ambrose Amos Anise Annabel Apricot Archie Arlo Aster Augusta Auberon Avery Barley Bartholomew Basil Beatrix Belinda '+
 'Benedict Bertie Bessie Birdie Blossom Bonnie Bramble Brisket Bunting Buttercup Calico Camille Caraway Celeste Chester Chickpea Cicely Clarabel Clementine Clover Cobble Constance '+
 'Cornelius Cosmo Crispin Cuthbert Dabney Dahlia Dandelion Delphine Dewdrop Doris Dorothea Duncan Dumpling Edgar Edith Edmund Eloise Elspeth Emmeline Ernest Esme Eudora Eustace Evangeline '+
 'Fabian Fanny Felix Fenwick Ferdinand Flossie Florence Fox Frederick Gertie Gilbert Ginger Gladys Godfrey Goldie Gracie Gwendolyn Hamish Harriet Hazel Heathcliff Henrietta Herbert Hilda '+
 'Horace Humphrey Ida Imogen Inigo Iris Isadora Jasper Jemima Jonquil Josephine Juniper Kipper Lavender Lemuel Leopold Lettice Lillian Lionel Lottie Lucius Lulu Mabel Maisie Marigold '+
 'Matilda Maude Maximilian Meadow Mercy Merriweather Mildred Minnow Montague Mortimer Muriel Myrtle Nettle Nigel Noodle Norbert Nutmeg Octavia Odette Olive Ophelia Orville Oswald Pansy '+
 'Parsnip Patience Pemberton Penelope Percival Periwinkle Petunia Philippa Pickle Pippa Prudence Puddle Quentin Quincy Rhubarb Rosalind Rosemary Rufus Rupert Saffron Sage Samphire '+
 'Septimus Sherbet Sidney Silas Snowdrop Sorrel2 Sprig Sunny Sybil Tabitha Taffy Tarragon Thaddeus Theodora Thimble Tobias Toffee Trixie Truffle Tuppence Ulysses Ursula Valentine Verity '+
 'Violet Waddles Walter Wendolyn Wilfred Willa Willow Winifred Winston Wilbur Wren2 Yolanda Zebedee Zinnia Sir.Quackington Mr.Feathers Nugget Pebbles Gus Dot Daisy Edna Hortense Lulubelle '+
 'Barnum Biddy Bunny Cressida Dottie Elmer Ferris Fitz Gideon Hettie2 Ignatius Jolyon Kestrel Lupin Mistletoe Nell2 Ottoline Plover Quilliam Roscoe Salvatore Tilbury Umberto2 Vivian Wallis')
  .split(/\s+/).filter(Boolean).map(s=>s.replace('.',' ')).filter(s=>!/\d$/.test(s));
const SURN=('Reedwell Puddleby Mossfoot Brookbill Featherstone Dabbleton Pondsworth Rushmore Willowby Quackenbush Downey Marshwick Fennelby Ripple Bulrush Wadsworth Sedgely Mallowdale '+
 'Tumbleweed Crumbsworth Paddlefoot Lilypad Duckworth Waterhouse Driftwood Pebblebrook Splashley Webbington Hollowell Thistlewaite Cattail Muddleby Swansby Teasdale Plumley Gooseberry '+
 'Wigglesworth Nettlefield Brambleton Honeysett Larkspur Oakhurst Fernsby Mudlark Rainsford Drizzle Pondsley Cressfield Hazelwood Butterfield Puddlecombe Bellweather Dimbleby Quillon '+
 'Bunting Galloway Higgins Applegate Waddington Mossop Shallows Rookwood Tidewell Underhill Barleycorn Copperpot Kettleby Wickham Inkster Ashdown2 Beckett Fothergill Ploverton')
  .split(/\s+/).filter(Boolean).filter(s=>!/\d$/.test(s));
const KIDN=('Beanie Blip Bobbin Bumble Chirp Cobweb Conker Crumpet Dib Dodo Doodle Fable Fizz Flick Flip Freckle Gizmo Hiccup Inky Jot Juju Kipling Ladle Limpet Loopy Mungo Nutkin '+
 'Paddle2 Pepper Piccolo Plink Pogo Pompom Rolo Rumple Scooter Shrimp Skittle Snips Sock Spud Splish Sprocket Squidge Tadpole Teacup Thistledown2 Tickle Twinkle Wadge Whisk Widget Wink Yoyo Zippy '+
 'Acorn2 Bitsy Bo Bubbles Button Chip Cricket Dabble Dewey Dimple Dot2 Fidget Fuzz Gumdrop Hopper Jellybean Jinx Kiwi Lolly Marbles Midge Mittens Mochi Moss Muffin Nib Noodle2 '+
 'Nubbin Otto Peanut Pebble Pickles Plum Poppet Puff Quibble Rascal Scamp Skipper2 Smudge Snickers Sparrow Speck Sprout Squeak Taffy2 Tater Tiddle Tink Tiptoe Toot Twig Waffles Wiggle Wob Ziggy Zuzu')
  .split(/\s+/).filter(Boolean).filter(s=>!/\d$/.test(s));
const CARTN=('Ada Wheelwright,Amos Gatepost,Bertram Axle,Clara Muleton,Digby Furrow,Elsie Lanthorn,Ezra Milestone,Flora Hayward,Gideon Cartwright,Hattie Rutt,Ivo Hitchens,Jessamy Trundle,'+
 'Kit Spokes,Lettie Waggoner,Morris Turnpike,Nora Hillcrest,Obadiah Lane,Pearl Haybale,Ronan Fordham,Sadie Bridle,Thomas Tollgate,Una Crossways,Vernon Packhorse,Wynne Westerly,'+
 'Yardley Coach,Zelda Roadmender,Basil Overhill').split(',');
function seedOf(){ return strHash('lv'+(typeof SEED!=='undefined'?SEED:0)); }
function shuffled(arr,salt){
  const a=arr.slice(); let s=(seedOf()^strHash(salt))>>>0||1;
  for(let i=a.length-1;i>0;i--){ s=(Math.imul(s,1664525)+1013904223)>>>0; const j=s%(i+1); const t=a[i]; a[i]=a[j]; a[j]=t; }
  return a;
}
let poolsCache=null;
function pools(){
  const sd=seedOf();
  if(poolsCache&&poolsCache.sd===sd) return poolsCache;
  noteStoryNames();
  const ok=s=>!s.split(' ').some(w=>STORY_WORDS.has(w.toLowerCase()));
  const adultFirst=shuffled(FIRST.filter(ok),'adult');
  const kids=shuffled(KIDN.filter(ok).filter(k=>adultFirst.indexOf(k)<0),'kid');
  poolsCache={sd,first:adultFirst,sur:shuffled(SURN,'sur'),kids,cart:shuffled(CARTN,'cart')};
  return poolsCache;
}
LV.pools=pools;
const cellOf=(rx,ry)=>mod(rx,3)*3+mod(ry,3);
const SLOTS=21;   /* 9 townducks + up to 12 keepers per town */
/* a family name for a slot: two towns whose first names line up are a whole number of 3-region blocks apart, and the
   block (taken 6 across and 12 down) picks a different family name, so the full name is not repeated for a long way */
function surIdx(rx,ry,slot){
  const L=pools().sur.length, qx=Math.floor(rx/3), qy=Math.floor(ry/3);
  return mod(mod(qx,6)*12+mod(qy,12)+slot*29+(seedOf()%89),L);
}
function adultName(rx,ry,slot){
  const P=pools(), L=P.first.length;
  const c=cellOf(rx,ry);
  /* first names repeat only every third region in each direction; family names make even those differ */
  const first=P.first[(c*SLOTS+slot)%L];
  /* towns that share a first-name slot are a whole number of 3-region blocks apart: step the family name by that block */
  const sur=P.sur[surIdx(rx,ry,slot)];
  return first+' '+sur;
}
function renameTown(t){
  if(!t||t.isRed||t._lvNamed||!t.npcs) return t;
  t._lvNamed=true;
  t.npcs.forEach((n,i)=>{ if(n&&!n.special&&!n.red) n.name=adultName(t.rx,t.ry,i); });
  let k=0;
  for(const b of (t.buildings||[])) if(b&&b.keeper){ b.keeper.name=adultName(t.rx,t.ry,9+(k%12)); k++; }
  return t;
}
{
  const _gt=getTown;
  getTown=function(rx,ry){ const t=_gt(rx,ry); if(t&&!t._lvNamed) safe(()=>renameTown(t)); return t; };
}
/* ducklings: three per town on the same lattice, the kingdom's eight on their own */
LV.kidName=function(kidId,town,i){
  const P=pools(), L=P.kids.length;
  if(String(kidId).charAt(0)==='K'){ const j=parseInt(String(kidId).slice(1))||0; return P.kids[j%L]; }
  if(!town) return null;
  /* ducklings carry their town's family names too, so no two of them anywhere near each other share a whole name */
  const grp=mod(Math.floor(town.rx/3)+2*Math.floor(town.ry/3),3);
  return P.kids[(8+grp*27+cellOf(town.rx,town.ry)*3+(i||0))%L]+' '+P.sur[surIdx(town.rx,town.ry,40+(i||0))];
};
{
  const _tk=townKids;
  townKids=function(t){
    const list=_tk(t);
    if(list&&!list._lv){ list._lv=1; list.forEach((k,i)=>{ const nm=LV.kidName(k.kidId,t,i); if(nm) k.name=nm; }); }
    return list;
  };
  const _kk=kingdomKids;
  kingdomKids=function(){
    const list=_kk();
    if(list&&!list._lv){ list._lv=1; list.forEach(k=>{ const nm=LV.kidName(k.kidId,null,0); if(nm) k.name=nm; }); }
    return list;
  };
}
/* carters: the kingdom's two keep the old names; a town's carter is named for the town's place on the lattice and the day */
{
  const _tp=trvPlan;
  trvPlan=function(t){
    const p=_tp(t);
    if(p&&!p.perm&&!p._lvn&&t){ p._lvn=1; const P=pools(); p.name=P.cart[(cellOf(t.rx,t.ry)*3+g.day)%P.cart.length]; }
    return p;
  };
}
/* Cinderhold's two gate guards */
{
  const _cg=castleGuards;
  castleGuards=function(){
    const a=_cg();
    if(a&&!a._lv){ a._lv=1; if(a[0]) a[0].name='Cinderhold Guard Soot'; if(a[1]) a[1].name='Cinderhold Guard Flint'; }
    return a;
  };
}
/* a new or loaded world clears the name pools (the seed may differ) */
{
  const _rk=resetKingdom;
  resetKingdom=function(){ poolsCache=null; liveCache={t:0,names:new Map()}; return _rk(); };
}

/* ======================================================================
   6. TOWNDUCKS: a life of their own, a memory, and the news
   ====================================================================== */
LV.LIFE=LV.LIFE||[];      /* filled by s20voices.js: {about:[..], kin:[..], steps:[[..],[..],[..],[..]]} */
LV.NEWS=LV.NEWS||{};      /* phase -> (route-keyed) list of things townducks say about the story */
LV.TOWNTALK=LV.TOWNTALK||{};  /* away / long / feathers / nick lines for townducks */
function lifeOf(n){
  const L=LV.LIFE; if(!L.length) return null;
  const t=n.town; const h=strHash((t?t.key:'?')+':'+n.idx);
  return {tpl:L[h%L.length],h};
}
const KIN=['Pim','Bobble','Nan Wick','Tibbs','Aunt Moira','Ferdie','Lumpkin','Granny Sloe','Dabs','Uncle Horace','little Bea','Toby','Old Jem','Cousin Ottilie','Mops','Grandad Plum','Winnie','Squill'];
function lifeStage(m){
  const days=Math.max(0,g.day-(m.lvMet||g.day));
  return Math.min(3,Math.floor(days/3)+(m.fr>=6?1:0));
}
function lifeLines(n,m,stage){
  const L=lifeOf(n); if(!L) return null;
  const kin=KIN[(L.h>>>5)%KIN.length];
  const rep=s=>String(s).replace(/\{kin\}/g,kin).replace(/\{town\}/g,n.town?n.town.name:'town');
  const lines=(stage<0?L.tpl.about:L.tpl.steps[stage])||[];
  return lines.map(rep);
}
LV.lifeLines=lifeLines;
function newsLines(ctx,seed,spread){
  const v=resolve(LV.NEWS[ctx.ph]!==undefined?LV.NEWS[ctx.ph]:LV.NEWS[ctx.grp],ctx);
  if(!v||!v.length) return null;
  /* spread: neighbours in the same town start at different places in the news, so they do not all tell you the same thing */
  return v[(strHash(seed)+(spread||0))%v.length];
}
LV.newsLines=newsLines;
function townTone(){ return LV.TONE.folk||{}; }
{
  const _chat=chat;
  chat=function(n,done){
    try{
      const ctx=LV.ctx();
      /* Emberwick's people have voices of their own */
      if(n.red&&VOICES[n.name]){ redChat(n,done,ctx); return; }
      const t=n.town, m=npcMem(t,n.idx), p=PERSONAS[n.persona];
      if(!p){ _chat(n,done); return; }
      if(m.chat!==g.day){ m.chat=g.day; m.fr+=1; }
      if(!m.lvMet) m.lvMet=g.day;
      const out=[]; const T=LV.TOWNTALK;
      const late=ctx.pi>=5;   /* from Act IV the old small talk about dark trees is out of date */
      /* hello again */
      const away=m.lvLast?Math.floor((nowH()-m.lvLast)/24):0;
      if(m.talks>0&&away>=6&&T.long) out.push(pickBy(resolve(T.long,ctx),n.name+m.talks).replace(/\{days\}/g,away));
      else if(m.talks>0&&away>=2&&T.away) out.push(pickBy(resolve(T.away,ctx),n.name+m.talks).replace(/\{days\}/g,away));
      /* your feathers */
      if(ctx.red&&!m.lvRed&&m.talks>0&&T.feathers){ m.lvRed=1; out.push(...resolve(T.feathers,ctx)[strHash(n.name)%resolve(T.feathers,ctx).length]); }
      else if(ctx.red) m.lvRed=1;
      /* what to talk about: their persona first, then their own life and the news, in turn */
      const stage=lifeStage(m);
      let body=null;
      if(m.talks===0) body=late?(lifeLines(n,m,-1)||p[0]):p[0];
      else if(m.lvPh&&m.lvPh!==ctx.ph&&ctx.pi>=3) body=newsLines(ctx,(t?t.key:'')+ctx.ph,n.idx*5)||null;
      /* their life moves on whether you visit or not, but you hear it one step at a time */
      if(!body&&m.lvStage!==undefined&&stage>m.lvStage){
        m.lvStage++;
        const pre=m.lvStage===0||away<1?[]:[pickBy(['Oh! Since you were last by:','You missed something!','News! Well, my news.'],n.name+m.lvStage)];
        body=pre.concat(lifeLines(n,m,m.lvStage)||[]);
      }
      if(!body){
        const turn=m.talks%3;
        if(turn===1&&!late&&p.length>1) body=p[1+((Math.floor(m.talks/3))%(p.length-1))];
        else if(turn===2||(turn===1&&late)){ body=ctx.pi>=3?newsLines(ctx,(t?t.key:'')+ctx.ph,n.idx*5+Math.floor(m.talks/3)):null; if(!body) body=lifeLines(n,m,m.lvStage===undefined?-1:m.lvStage); }
        else { if(m.lvStage===undefined){ body=lifeLines(n,m,-1); m.lvStage=-1; } else body=lifeLines(n,m,m.lvStage); }
        if(!body) body=p[m.talks%p.length];
      }
      if(m.lvStage===undefined&&m.talks>0) m.lvStage=-1;
      m.talks++; m.lvLast=nowH(); m.lvPh=ctx.ph;
      out.push(...body.map(s=>typeof s==='function'?s(g,n):fmt(String(s),t)));
      if(m.fr>=2&&!m.hint){ m.hint=1; out.push('Between us? I would love '+ITEMS[giftFav(n)].name+' someday. Just saying.'); }
      if(m.fr>=4&&!m.rum){ m.rum=1; g.rumors.push(t.key+':'+n.idx); out.push(RUMORS[n.persona%RUMORS.length]); toast('Rumor added to your journal.',2400); }
      say(n.name,out,done);
    }catch(e){ console.warn('lives chat',e); _chat(n,done); }
  };
}
/* the greeting on a townduck's menu remembers you */
{
  const _menu=npcMenu;
  npcMenu=function(n,done){
    if(!n||!n.town){ _menu(n,done); return; }
    const _ch=choose;
    try{
      const ctx=LV.ctx(), m=npcMem(n.town,n.idx);
      let gr=null;
      if(n.red&&VOICES[n.name]) gr=redGreet(n,ctx);
      else if(m.talks>0){
        const away=m.lvLast?Math.floor((nowH()-m.lvLast)/24):0, T=LV.TOWNTALK;
        if(away>=6&&T.menuLong) gr=pickBy(resolve(T.menuLong,ctx),n.name+g.day).replace(/\{days\}/g,away);
        else if(m.fr>=8&&T.menuFriend) gr=pickBy(resolve(T.menuFriend,ctx),n.name+g.day);
        else if(townRank(n.town)===0&&T.menuKnown) gr=pickBy(resolve(T.menuKnown,ctx),n.name+g.day);   /* not "hello, stranger" to someone they have talked to */
      }
      if(gr){ choose=function(w,t,o,cb,c){ choose=_ch; return _ch(w,gr,o,cb,c); }; }
      _menu(n,done);
    }catch(e){ console.warn('lives menu',e); }
    finally{ choose=_ch; }
  };
}

/* ---------- Emberwick's people ---------- */
function redGreet(n,ctx){
  const V=VOICES[n.name], m=LV.mem(n.name);
  const T=LV.TONE[V.tone||'hearth']||{};
  const away=LV.daysAway(m);
  const G=V.greet||{}, gv=G[ctx.ph]!==undefined?G[ctx.ph]:G[ctx.grp];
  const gr=gv!==undefined?resolve(gv,ctx):null;
  if(m.n===0) return gr?fill(pickBy(gr,n.name+g.day),ctx,V,m):null;
  if(away>=6&&T.long) return fill(pickBy(resolve(T.long,ctx),n.name+m.n),ctx,V,m);
  return gr?fill(pickBy(gr,n.name+g.day+m.n),ctx,V,m):null;
}
function redChat(n,done,ctx){
  const t=n.town, tm=npcMem(t,n.idx);
  if(tm.chat!==g.day){ tm.chat=g.day; tm.fr+=1; }
  const r=LV.compose(n.name,n,ctx);
  tm.talks++;
  remember(n.name,ctx);
  const out=r.pages.slice();
  if(tm.fr>=4&&!tm.rum){ tm.rum=1; g.rumors.push(t.key+':'+n.idx); out.push(RUMORS[n.persona%RUMORS.length]); toast('Rumor added to your journal.',2400); }
  say(n.name,out,done);
}

/* ---------- shopkeepers remember regulars ---------- */
{
  const _ck=chatKeeper;
  chatKeeper=function(b,t){
    try{
      const ctx=LV.ctx(), key='keep:'+(t?t.key:'?')+':'+b.x+','+b.y;
      const m=LV.mem(key), away=LV.daysAway(m), T=LV.TOWNTALK;
      const out=[];
      if(m.n===0) out.push(pick(GREET[b.kind]||['Welcome.']));
      else if(away>=6&&T.keepLong) out.push(pickBy(resolve(T.keepLong,ctx),key+m.n).replace(/\{days\}/g,away));
      else out.push(pick(GREET[b.kind]||['Welcome back.']));
      const r=townRank(t);
      out.push(m.n>=6?(r>=3?'You are practically family now. I keep the good ones back for you.':'You are a regular now, whatever the notice board says.'):r>=4?'You are the best thing to happen to this town since the fountain.':r>=3?'You are practically family now.':r>=1?'Nice to see a regular face.':m.n>0?'Back again? Good. I like a face I have seen before.':'First time in here? Take your time.');
      if(ctx.pi>=3&&m.n%2===1){ const nw=newsLines(ctx,key+m.n); if(nw) out.push(...nw); }
      else out.push('Open '+fmtHour(HOURS[b.kind][0])+' to '+fmtHour(HOURS[b.kind][1])+', every day.');
      m.n++; m.last=nowH(); m.ph=ctx.ph;
      say(b.keeper.name,out);
    }catch(e){ console.warn('lives keeper',e); _ck(b,t); }
  };
}

/* the shop counter greets a returning customer as one */
{
  const _oc=openCounter;
  openCounter=function(){
    const _ch=choose;
    try{
      const b=g.shop&&g.shop.b, t=g.shop&&g.shop.town;
      if(b&&t&&b.keeper){
        const key='keep:'+t.key+':'+b.x+','+b.y, m=LV.mem(key), away=LV.daysAway(m), T=LV.TOWNTALK, ctx=LV.ctx();
        let gr=null;
        if(m.n>0&&away>=6&&T.keepLong) gr=pickBy(resolve(T.keepLong,ctx),key+g.day).replace(/\{days\}/g,away);
        else if(m.n>0&&townRank(t)===0&&T.menuKnown) gr=pickBy(resolve(T.menuKnown,ctx),key+g.day);
        if(m.n===0) m.met=g.day;
        m.n++; m.last=nowH(); m.ph=ctx.ph;
        if(gr) choose=function(w,txt,o,cb,c){ choose=_ch; return _ch(w,gr+' What can I do for you?',o,cb,c); };
      }
      _oc();
    }catch(e){ console.warn('lives counter',e); }
    finally{ choose=_ch; }
  };
}

/* ======================================================================
   7. DUCKLINGS: they remember you, and they grow
   ====================================================================== */
LV.KIDS=LV.KIDS||{};   /* {back:[..], grow:[[..]..], news:{phase:..}, feathers:[..]} filled by voices */
function kidMem(id){ return LV.mem('kid:'+id); }
function kidExtra(n,ctx,m){
  const K=LV.KIDS, out=[];
  const away=LV.daysAway(m);
  if(m.n>0&&away>=3&&K.back) out.push(...[pickBy(resolve(K.back,ctx),n.kidId+m.n)]);
  if(ctx.red&&m.red===0&&K.feathers) out.push(...pickBy(resolve(K.feathers,ctx),n.kidId));
  return out;
}
function kidBody(n,ctx,m,base){
  const K=LV.KIDS;
  const age=m.met?Math.floor((g.day-m.met)/12):0;   /* every twelve days or so they are a little bigger */
  const turn=m.n%3;
  if(m.n>0&&age>(m.age||0)&&K.grow){ m.age=age; const gl=K.grow[Math.min(K.grow.length-1,age-1)]; if(gl) return [pickBy(gl,n.kidId+age)].flat(); }
  if(turn===1&&ctx.pi>=3&&K.news){ const v=resolve(K.news[ctx.ph]!==undefined?K.news[ctx.ph]:K.news[GROUP[ctx.ph]],ctx); if(v&&v.length) return [].concat(pickBy(v,n.kidId+m.n)); }
  return base;
}
{
  const _ktn=kidTalkNormal;
  kidTalkNormal=function(n){
    try{
      const ctx=LV.ctx(), m=kidMem(n.kidId);
      const pre=kidExtra(n,ctx,m);
      const first=m.n===0;
      n.cycle=m.n;   /* their place in what they like to talk about is saved, so a reload does not start them over */
      const _s=say;
      /* let the old talk choose its line and do its reputation bookkeeping, and add to what is said */
      say=function(nm,pg,cb){
        say=_s;
        let body=pg;
        if(!first&&nm===n.name&&Array.isArray(pg)) body=kidBody(n,ctx,m,pg);
        return _s(nm,(nm===n.name?pre:[]).concat(body),cb);
      };
      const _c=choose;
      choose=function(w,t,o,cb,c){ choose=_c; say=_s; if(pre.length&&w===n.name){ return _s(n.name,pre,()=>_c(w,t,o,cb,c)); } return _c(w,t,o,cb,c); };
      try{ _ktn(n); } finally{ if(say!==_s) say=_s; if(choose!==_c) choose=_c; }
      if(!m.n) m.met=g.day;
      m.n++; m.last=nowH(); m.ph=ctx.ph; m.red=ctx.red?1:0;
    }catch(e){ console.warn('lives kid',e); _ktn(n); }
  };
  const _rkt=rKidTalk;
  rKidTalk=function(n){
    try{
      const st=g.story, a=(st.kidA||{})[n.name]||[];
      const V=VOICES[n.name]||VOICES['@redkid'];
      /* their first words are about a yellow stranger: not if you are red, and not from Poppy once the story has made you friends */
      if(a.length===0){
        const ctx0=LV.ctx(), late=n.name==='Little Poppy'&&ctx0.pi>=3;
        if(ctx0.red||late){
          const _s=say;
          say=function(nm,pg,cb){
            say=_s;
            if(nm===n.name&&Array.isArray(pg)&&String(pg[0]).indexOf('yellow one')>=0)
              pg=late?['It is you! You came to MY house! I have been saving questions. Not the big ones. The middle ones.']:['You are the red one who used to be yellow! Mama told me. Can I look? I am looking.','I have questions. Mama says no questions. I have them anyway.'];
            return _s(nm,pg,cb);
          };
          try{ _rkt(n); } finally{ if(say!==_s) say=_s; }
          return;
        }
      }
      const pop=n.name==='Little Poppy'&&LV.pi()>=3;   /* by Act II Poppy is your friend: no stranger's questions */
      if((a.length>=2||pop)&&V){
        const ctx=LV.ctx();
        n.dir=OPP[g.dir]; n.moving=false; n.talking=true;
        const done=()=>{ n.talking=false; n.t=1; };
        if(!VOICES[n.name]) VOICES[n.name]=Object.assign({},VOICES['@redkid']);
        const r=LV.compose(n.name,n,ctx); remember(n.name,ctx);
        say(n.name,r.pages,done); return;
      }
    }catch(e){ console.warn('lives redkid',e); }
    _rkt(n);
  };
}

/* ======================================================================
   8. AFTER THE END: the people of Act VI stay in the world
   ====================================================================== */
LV.RESIDENTS=LV.RESIDENTS||[];
LV.resident=function(d){
  const o=Object.assign({still:true,mark:false,lv:true,snap:3},d);
  o.talk=function(n,done){ LV.talk(n,done); };
  LV.RESIDENTS.push(o);
  return o;
};
LV.installResidents=function(){
  for(const d of LV.RESIDENTS){
    if(d._in) continue; d._in=1;
    /* borrow the colours and hats the story gave them */
    if(d.like){ const src=S2.npcs.find(x=>x.id===d.like); if(src){ if(d.pal===undefined) d.pal=src.pal; if(d.head===undefined) d.head=src.head; if(d.neck===undefined) d.neck=src.neck; } }
    S2.npc(d);
  }
};
/* where the plain kingdom copy of a person stands, when the ending moves them */
LV.homes=LV.homes||[];
{
  let lastKey='';
  const _su=storyUpdate;
  storyUpdate=function(dt){
    _su(dt);
    try{
      if(!g.story||g.mode==='title') return;
      let key='';
      for(const h of LV.homes){ let p=null; try{ p=h.where(); }catch(e){} key+=h.name+':'+(p?p.join(','):'home')+';'; }
      if(key===lastKey) return;
      lastKey=key;
      for(const h of LV.homes){
        const n=kNpcList().find(x=>x.name===h.name); if(!n) continue;
        if(!n._lvHome) n._lvHome=[n.hx,n.hy];
        let p=null; try{ p=h.where(); }catch(e){}
        if(p){ const sp=snapFree(Math.round(p[0]),Math.round(p[1]),3); n.x=(sp[0]+0.5)*TS; n.y=(sp[1]+0.95)*TS; n.hx=n.x; n.hy=n.y; }
        else if(h.always){ n.x=n._lvHome[0]; n.y=n._lvHome[1]; n.hx=n.x; n.hy=n.y; }
        n.moving=false;
      }
    }catch(e){ console.warn('lives homes',e); }
  };
}

/* ======================================================================
   9. THE JOURNAL: who remembers you
   ====================================================================== */
{
  const _je=journalExtra;
  journalExtra=function(sec,line){
    _je(sec,line);
    try{
      const m=LM().m, names=Object.keys(m).filter(k=>VOICES[k]&&m[k].n>0&&k.charAt(0)!=='@');
      if(!names.length) return;
      names.sort((a,b)=>m[b].n-m[a].n);
      sec('People Who Know You');
      const top=names.slice(0,8).map(k=>k+(m[k].n>=8?' (old friend)':m[k].n>=3?' (friend)':''));
      line(top.join(', ')+(names.length>8?', and '+(names.length-8)+' more.':'.'),'jdim');
    }catch(e){}
  };
}
})();
