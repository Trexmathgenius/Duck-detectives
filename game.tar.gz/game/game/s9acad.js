'use strict';
/* ===== THE TWELVE DAYS, AS PROBLEMS (v1.24) =====
   Each of the Academy's twelve lessons is still taught plainly (LESSONS in magic.js). Then Mistress Vesper conjures a problem into the room
   and the spell itself is how you solve it. No quizzes. Every problem has a way that works, a way that is taught from, and no way that is luck. */

function pracStartStd(n,after){
  const sc=SPELLS[n-1];
  const v={n:sc[0],master:V,std:true,pages:LESSONS[n-1],i:n-1};
  say(V,['"Now. I will not ask you what it means. I will give you something to do with it."','(The room changes. Whatever has been conjured, it is not on any map.)'],
    ()=>pracStart(v,{master:V},()=>after(true),()=>after(false)));
}
const FACE_HINT='You will need to face it, and then press C.';

/* 1. SPARK: ask for warmth, and wait. */
PRAC.Spark=(v,M)=>pracRoom(v,M,{name:'Lesson 1: the cold candle',rows:sxGrid(11,7,[[0,3,'D'],[5,2,'c']]),start:[1,3,'right'],teacher:[8,5],
  objs:{c:{name:'A cold candle',glyph:'candle',key:'lit',solid:true,desc:'A white candle in a brass dish. The wick has never been introduced to a flame.',
    use:(S)=>{ if(S.fl.lit){ say('',['It burns, quite pleased.']); return; } sxSay(S,'',['You blow on it. The wick is unimpressed.'],()=>sxSay(S,M,['"Do not blow on it. Do not quack at it. Ask, and then wait."'])); },
    cast:{Spark:(S,o,tx,ty)=>{
      if(S.fl.lit) return;
      if(S.wait>0){ S.wait=0; pracFx(S,(tx+0.5)*TS,(ty+0.5)*TS,'#8a8f98',8); sxSay(S,M,['"You asked twice. Magic is asking, and then being quiet. Begin again."']); return; }
      S.wait=3.6; S.wx=g.px; S.wy=g.py; pracFx(S,(tx+0.5)*TS,(ty+0.5)*TS,'#ffe94a',14); toast('Asked. Now be quiet. Do not move.',3000);
    }}}},
  task:S=>'"Light the candle. Not by blowing on it. Face it, cast Spark, and then be quiet enough to hear the answer."',
  intro:['"Here is a cold candle. It would like to be warm, and has no way of saying so.','Face it, and ask. Then be quiet. The second part is the lesson."'],
  tick:(S,dt)=>{
    if(!(S.wait>0)) return;
    if(Math.hypot(g.px-S.wx,g.py-S.wy)>6){ S.wait=0; sxSay(S,M,['(You moved. The spark, which had been thinking about it, stops thinking about it.)','"Quietly. You have to be quiet enough to hear the answer. Again."']); return; }
    S.wait-=dt;
    if(S.wait<=0){ S.fl.lit=1; pracFx(S,5.5*TS,2.5*TS,'#ffe94a',26); pracWin(S,['"There. You did not make it burn. You asked it, and kept still, and it remembered how.','That is all magic is: asking, and then being quiet enough to hear the answer."']); }
  }});

/* 2. KINDLE: a wand remembers fire. Point it at what is meant to burn. Never at what you love. */
PRAC.Kindle=(v,M)=>pracRoom(v,M,{name:'Lesson 2: the cracked wand',rows:sxGrid(13,7,[[0,3,'D'],[6,2,'h'],[8,2,'s'],[11,3,'f']]),start:[1,3,'right'],teacher:[3,5],
  objs:{
    h:{name:'A dead tangle of thorn',glyph:'thorns',solid:true,when:S=>!S.fl.burnt,desc:'Dry as paper. It has grown across the old hearth and has no further plans.',
      cast:{Kindle:(S,o,tx,ty)=>{ S.fl.burnt=1; S.fl.hearth=1; pracFx(S,(tx+0.5)*TS,(ty+0.5)*TS,'#ff9a2a',30);
        sxSay(S,'',['The tangle catches, and goes up in a clean orange line, and the old hearth is bare and ready.'],()=>pracWin(S,['"The wand does not make fire. It remembers fire. You pointed it at what was meant to burn.','Never at what you love. Hold that thought until you have a reason to need it."'])); }}},
    s:{name:'Posy\'s drawing',glyph:'scroll',solid:true,desc:'A child\'s drawing of a very large hat, pinned beside the hearth. It is, you are told, her best.',
      cast:{Kindle:(S,o,tx,ty)=>{ pracFx(S,(tx+0.5)*TS,(ty+0.5)*TS,'#ff9a2a',16); sxSay(S,M,['(The corner of the drawing browns. The Mistress closes her wing round the wand, without hurry.)','"No. Never at what you love. A wand remembers fire, and it does not know what a child drew with her whole afternoon. You do."','(The scorch fades. You are not sure she is permitted to do that.)']); }}},
    f:{name:'The old hearth',glyph:'fireplace',solid:true,desc:'A stone hearth, swept and cold. A tangle of dead thorn is all that is in it.'}},
  task:S=>'"The old hearth is choked with dead thorn. Burn the thorn. Not the drawing pinned beside it."',
  intro:['"There is a hearth in this room that has not been lit in a year, and a thicket of dead thorn in it.','The Ember Wand remembers fire. Point it at what is meant to burn."']});

/* 3. LUMEN: light is a promise that the dark is not empty. Light the three lamps. */
PRAC.Lumen=(v,M)=>{
  const lamp=(k,nm)=>({name:nm,glyph:'brazier',lit:S=>!!S.fl['l'+k],light:S=>!!S.fl['l'+k],lightR:80,solid:true,
    desc:'An iron lamp on a post. It is cold. Beyond the end of your wing it is hard to tell it is there.',
    cast:{Lumen:(S,o,tx,ty)=>{ if(S.fl['l'+k]) return; S.fl['l'+k]=1; pracFx(S,(tx+0.5)*TS,(ty+0.5)*TS,'#cfe4ff',20); toast('The lamp takes the light, and keeps it.',2600);
      if(S.fl.l1&&S.fl.l2&&S.fl.l3) setTimeout(()=>pracWin(S,['"A promise that the dark is not empty. You made it three times, and each one stayed lit when you walked away.','It lights a circle around you. It will not light through a wall. Do not ask it to."']),700); }}});
  return pracRoom(v,M,{name:'Lesson 3: the dark lamp-room',rows:sxGrid(15,7,[[0,3,'D'],[4,1,'1'],[8,1,'2'],[12,1,'3']]),start:[1,3,'right'],teacher:[2,5],dark:0.97,lightR:34,
    objs:{'1':lamp('1','The first lamp'),'2':lamp('2','The second lamp'),'3':lamp('3','The third lamp')},
    task:S=>'"There are three lamps in this room, and the room is dark. Cast Lumen so you can see, and then light all three."',
    intro:['"The lamp-room is dark. There are three lamps in it. I am not going to tell you where.','Hold the orb in the open wing, and say show. Then light them. Face each lamp and cast again."']});
};

/* 4. GUST: wind is a shy animal. Fog and smoke obey; stone does not. */
PRAC.Gust=(v,M)=>{
  const fog=k=>({name:'A bank of smoke',glyph:'fog',solid:true,when:S=>!S.fl[k],desc:'Thick grey smoke, filling the doorway.',
    cast:{Gust:(S,o,tx,ty)=>{ S.fl[k]=1; pracFx(S,(tx+0.5)*TS,(ty+0.5)*TS,'#d8f0ff',24); toast('The smoke leaves in a grey, polite line.',2800); }}});
  return pracRoom(v,M,{name:'Lesson 4: smoke and stone',rows:sxGrid(15,7,[[0,3,'D'],[14,3,'E'],[6,1,1,2,'#'],[6,4,1,3,'#'],[11,1,1,2,'#'],[11,4,1,3,'#'],[6,3,'f'],[11,3,'g'],[3,1,'b']]),start:[1,3,'right'],teacher:[3,5],
    objs:{f:fog('f1'),g:fog('f2'),
      b:{name:'A stone block',glyph:'boulder',solid:true,desc:'A block of grey stone, in front of a very small closet.',
        cast:{Gust:(S,o,tx,ty)=>{ pracFx(S,(tx+0.5)*TS,(ty+0.5)*TS,'#d8f0ff',10); sxSay(S,M,['(The wind goes round the stone, in the manner of a crowd round a lamppost.)','"Stone and iron do not obey wind. Do not be the duck who gusts a boulder."']); }}}},
    exits:{E:{fn:S=>{ if(!(S.fl.f1&&S.fl.f2)){ say('',['The way is still full of smoke.']); return; } pracWin(S,['"Wind is a shy animal. You asked, softly, and it went where you pointed. And you left the stone alone, which is the harder half."']); }}},
    task:S=>'"The doorways between you and the far door are full of smoke. Gust it away. The stone block in the corner is not a doorway."',
    intro:['"There is smoke in two of the doorways, and a block of stone beside the closet.','Face the thing you want gone, and say away. Softly."']});
};

/* 5. WARD: a door that only opens inward. Wards turn curses, not sticks. */
PRAC.Ward=(v,M)=>pracRoom(v,M,{name:'Lesson 5: the cursed doorway',rows:sxGrid(13,7,[[0,3,'D'],[12,3,'E'],[6,1,1,2,'#'],[6,4,1,3,'#'],[6,3,'k']]),start:[1,3,'right'],teacher:[2,5],
  objs:{k:{name:'A curse-mark',glyph:'curse',solid:true,when:S=>!S.fl.k,desc:'A violet mark, glowing on the lintel. It hums, which is rude.',
    cast:{Ward:(S,o,tx,ty)=>{ S.fl.k=1; pracFx(S,(tx+0.5)*TS,(ty+0.5)*TS,'#ff8a9a',26); toast('The mark dims, flickers, and turns back on itself.',3000); }}}},
  trig:[{id:'stick',tx:3,ty:3,fn:S=>{ toast('A stick flies out of the wall. You duck. (A ward turns curses. It does not turn sticks.)',4200); }}],
  exits:{E:{fn:S=>{ if(!S.fl.k){ say('',['The curse is still on the doorway.']); return; } pracWin(S,['"A ward is a door that only opens inward. It turned the curse, and it let you duck the stick yourself, which is fair.','Hold it to your heart. Breathe out. Think of home."']); }}},
  task:S=>'"There is a curse on the doorway. Face it, hold the ward to your heart, and cast. Mind the stick."',
  intro:['"A curse-mark on the lintel, and a stick somewhere in the wall that I would rather not discuss.','Ward the doorway. A ward turns curses. It does not turn sticks."']});

/* 6. MEND: match the thread to the cloth. Mend what is broken, not what is gone. */
PRAC.Mend=(v,M)=>{
  const spool=(k,nm,col)=>({name:nm,glyph:'crate',col:col,solid:true,desc:'A spool of thread on a shelf.',use:(S)=>{ S.fl.thread=k; toast('You take the '+k+' thread.',2400); }});
  return pracRoom(v,M,{name:'Lesson 6: the torn cloak',rows:sxGrid(13,7,[[0,3,'D'],[3,1,'r'],[5,1,'b'],[7,1,'n'],[11,2,'u']]),start:[1,3,'right'],teacher:[2,5],
    objs:{r:spool('red','A spool of red thread','#b5322a'),b:spool('blue','A spool of blue thread','#3a62a8'),n:spool('green','A spool of green thread','#2f6f4f'),
      u:{name:'A cup, in dust',glyph:'crate',col:'#d9d2bf',solid:true,desc:'What was a cup. It has been swept into a neat pile and is, in every important sense, gone.',
        cast:{Mend:(S,o,tx,ty)=>{ pracFx(S,(tx+0.5)*TS,(ty+0.5)*TS,'#5affa0',10); sxSay(S,M,['(The dust shivers, and does not become a cup.)','"Mend what is broken, not what is gone. Match the thread to the cloth. The cup is gone."']); }}}},
    npcs:[{name:'Maple',tx:8,ty:4,pal:PALS[4],dir:'left',talk:(S)=>{ say('Maple',['"My cloak, it tore on the gate. It is red. My mother made it, so please be careful."']); },
      cast:{Mend:(S,n)=>{
        if(!S.fl.thread){ sxSay(S,M,['"Mend with what? Thread first. Thread is on the shelf."']); return; }
        if(S.fl.thread!=='red'){ const c=S.fl.thread; S.fl.thread=''; pracFx(S,n.x,n.y-14,'#5affa0',12); sxSay(S,'Maple',['(The seam closes in '+c+'. It is very neat, and very wrong.)','"...It is a lovely seam. It is not my cloak."'],()=>sxSay(S,M,['"Match the thread to the cloth. Match the cloth to the person. Again."'])); return; }
        pracFx(S,n.x,n.y-14,'#5affa0',28);
        sxSay(S,'Maple',['(The red thread finds the red cloth, and the tear draws shut, slowly, like a held breath let go.)','"Oh. You can hardly tell. Mother will not know."'],()=>pracWin(S,['"Slowly. A mend done quickly is a tear, waiting.','You matched it to the cloth, and to the person. That is all Mend is."']));
      }}}],
    task:S=>'"Maple has torn her cloak. Choose the thread that matches, take it from the shelf, and cast Mend at her. The cup on the table is another matter."',
    intro:['"Maple has torn her cloak, and is being brave about it. There is thread on the shelf. There is also, in the corner, what used to be a cup.','Mend what is broken. Match the thread to the cloth."']});
};

/* 7. STONE: a stone that is asked breaks along its seams. */
PRAC.Stone=(v,M)=>pracRoom(v,M,{name:'Lesson 7: the boulder in the yard',rows:sxGrid(11,7,[[0,3,'D'],[10,3,'E'],[7,1,1,2,'#'],[7,4,1,3,'#'],[7,3,'b']]),start:[1,3,'right'],teacher:[3,5],
  objs:{b:{name:'The boulder',glyph:'boulder',solid:true,when:S=>!S.fl.split,desc:'A boulder the size of a small cart, filling the gate of the training yard.',
    use:(S)=>{ sxSay(S,'',['You strike it. The boulder does not mind. Your wing minds a great deal.'],()=>sxSay(S,M,['"A stone that is asked breaks along its own seams. A stone that is struck breaks your wing."'])); },
    cast:{Stone:(S,o,tx,ty)=>{ S.fl.split=1; pracFx(S,(tx+0.5)*TS,(ty+0.5)*TS,'#7affc8',30); pracFx(S,(tx+0.5)*TS,(ty+0.5)*TS-8,'#e8f4ff',18);
      sxSay(S,'',['A rune lights on the face of the stone. It splits along seams you could not see, into six neat pieces, like a loaf.'],()=>pracWin(S,['"The rune is a word the stone already knows. You pressed it to the face of the boulder, and asked.','Next time, ask before you reach for your wing."'])); }}}},
  task:S=>'"The yard gate is blocked by a boulder. Do not hit it. Press the rune to its face, and ask."',
  intro:['"A boulder, in the gate of the training yard. It has been there since before I was a student, and I was not a young student.','The rune is a word the stone already knows."']});

/* 8. SEEK: the beetle points to what you truly seek, if you know. */
PRAC.Seek=(v,M)=>{
  const POS={a:[3,1],b:[7,1],c:[11,1],d:[4,4],e:[10,4]};
  const crate=k=>({name:'A broom cupboard',glyph:'crate',solid:true,desc:'A tall cupboard. Every one in this hall is identical, and not by accident.',
    use:(S)=>{
      if(S.fl.real!==k){ say('',['You open it. A mop. A mouse, regarding you with calm. Nothing else.']); return; }
      if(!S.fl.asked){ sxSay(S,M,['(The cupboard is the right one. The Mistress does not let you open it.)','"That is a guess. Ask the beetle. It is a rather good beetle."']); return; }
      sxSay(S,'',['Inside, on a hook, a small brass key and a note: "The heart of the maze is whatever you came to find."'],()=>pracWin(S,['"The beetle remembers where light comes from. It pointed, and you followed, and you did not ask it two things at once.','It points to what you seek only if you know what you seek. Next time, know."']));
    }});
  const o={};  ['a','b','c','d','e'].forEach(k=>{ o[k]=crate(k); });
  return pracRoom(v,M,{name:'Lesson 8: the maze of brooms',rows:sxGrid(15,7,[[0,3,'D'],[3,1,'a'],[7,1,'b'],[11,1,'c'],[4,4,'d'],[10,4,'e']]),start:[1,3,'right'],teacher:[13,5],
    objs:o,
    seek:S=>{ const p=POS[S.fl.real]; return p?[p[0],p[1]]:null; },
    onSeek:S=>{ S.fl.asked=1; },
    init:S=>{ S.fl.real='abcde'[Math.floor(Math.random()*5)]; },
    task:S=>'"The thing you need is in one of five cupboards. Ask the beetle where, and then follow it. Do not open them all."',
    intro:['"Five cupboards, one thing in one of them. I have not told you which. I have not told the beetle either; it simply knows.','Cast the verse. Ask it where the heart of this place is, and follow."']});
};

/* 9. BIND: hold loosely, like a ribbon on a wrist. */
PRAC.Bind=(v,M)=>{
  const shut=(k)=>({name:'A banging shutter',glyph:'shutter',solid:true,desc:'A shutter, swinging and slamming in a wind that is not actually there. It has knocked six scrolls off the sill.',
    cast:{Bind:(S,o,tx,ty)=>{ if(S.fl['b'+k]) return; S.fl['b'+k]=1; pracFx(S,(tx+0.5)*TS,(ty+0.5)*TS,'#ff8ac8',20); toast('A pale ribbon of light loops the latch, loosely, and the banging stops.',3200);
      if(S.fl.bw&&S.fl.bx){ S.fl.shutter=1; setTimeout(()=>pracWin(S,['"To bind is to hold, not to hurt. Loosely, like a ribbon on a wrist. You tied two shutters and neither one is bruised.','A binding made in anger slips. A binding made in care stays until it is thanked."']),700); } }}});
  return pracRoom(v,M,{name:'Lesson 9: the banging shutters',rows:sxGrid(13,7,[[0,3,'D'],[4,1,'w'],[8,1,'x']]),start:[1,3,'right'],teacher:[2,5],
    objs:{w:shut('w'),x:shut('x')},
    npcs:[{name:'Posy',tx:6,ty:4,pal:PALS[2],dir:'up',talk:()=>say('Posy',['"I am only here to hold the ladder. The shutters were not my idea."']),
      cast:{Bind:(S,n)=>{ pracFx(S,n.x,n.y-14,'#ff8ac8',12); sxSay(S,'Posy',['(A ribbon of light wraps Posy, and Posy looks at it, and at you, with great dignity.)','"I was only holding the ladder."'],()=>sxSay(S,M,['"To bind is to hold, not to hurt. Bind the latch, Detective. Not the duck."'])); }}}],
    task:S=>'"Two shutters are banging in a wind that is not there, and knocking the scrolls off the sill. Bind each latch, loosely."',
    intro:['"Two shutters, banging, and a ladder, and a student holding it who would like it known that it was not his idea.','Bind the latches. Loosely."']});
};

/* 10. FROST: cold slows, stills, lets you cross water. */
PRAC.Frost=(v,M)=>pracRoom(v,M,{name:'Lesson 10: the stream and the door',rows:sxGrid(13,7,[[0,3,'D'],[12,3,'E'],[5,1,3,5,'~']]),start:[1,3,'right'],teacher:[2,5],
  objs:{'~':{name:'The stream',glyph:'none',solid:true,desc:'A cold, quick stream, three tiles wide, between you and the far door.',
    cast:{Frost:(S,o,tx,ty)=>{ sxSet(S,tx,ty,'i'); S.fl.ice=(S.fl.ice||0)+1; pracFx(S,(tx+0.5)*TS,(ty+0.5)*TS,'#cfeeff',24); toast('The water stills, and a skin of ice runs across it.',2800); }}}},
  exits:{E:{fn:S=>{ pracWin(S,['"Cold is the other half of warmth. It slows, it stills, it lets you cross water.','Never freeze what you cannot thaw. That ice will be water again when you leave, and I will have words with the stream if it is not."']); }}},
  task:S=>'"There is a stream between you and the door. Freeze a way across it. One tile at a time; face the water and cast."',
  intro:['"A stream, three tiles wide, and the far door. I have not provided a bridge.','Cold slows the water, and stills it. Freeze it, and cross. Know how you would bring it back."']});

/* 11. VEIL: a veil does not hide you; it makes you uninteresting. It fails the moment you look to check. */
PRAC.Veil=(v,M)=>pracRoom(v,M,{name:'Lesson 11: the patient guard',rows:sxGrid(15,9,[[0,4,'D'],[14,4,'E']]),start:[1,4,'right'],teacher:[2,7],
  objs:{},
  guards:[{name:'The Guard',path:[[7,1],[7,7]],speed:24,range:6,fov:80,pal:WARDEN_PAL,head:'helm',pause:0.9,scan:true,loop:false}],
  caughtLines:['"WHO\'S THERE?" says the Guard, and holds up a lantern.','"Hm," says the Guard, not unkindly. "Back you go. I am being patient at you."'],
  exits:{E:{fn:S=>{ pracWin(S,['"A veil does not make you vanish. It makes you uninteresting. You thought of nothing here to see, and there was not.','And you did not look back to check. That is where it fails, every time."']); }}},
  tick:(S,dt)=>{
    if(!(S.veil>0)){ S.lookT=0; S.lx=g.px; S.ly=g.py; return; }
    const moved=Math.hypot(g.px-(S.lx===undefined?g.px:S.lx),g.py-(S.ly===undefined?g.py:S.ly))>0.2; S.lx=g.px; S.ly=g.py;
    let look=false;
    for(const gd of S.guards){ const dx=gd.x-g.px, dy=gd.y-g.py; if(Math.hypot(dx,dy)>TS*7) continue; const d=g.dir;
      if((d==='left'&&dx<-6&&Math.abs(dx)>=Math.abs(dy))||(d==='right'&&dx>6&&Math.abs(dx)>=Math.abs(dy))||(d==='up'&&dy<-6&&Math.abs(dy)>Math.abs(dx))||(d==='down'&&dy>6&&Math.abs(dy)>Math.abs(dx))) look=true; }
    if(look&&!moved) S.lookT=(S.lookT||0)+dt; else S.lookT=0;
    if(S.lookT>0.7){ S.lookT=0; S.veil=0; toast('You looked to check. The veil fails.',3800); }
  },
  hint:'The Guard sees a long way, but the veil makes you uninteresting at a distance. Cast it, and do not stand still looking at him.',
  task:S=>'"Get past the Guard to the far door. Cast Veil, think there is nothing here to see, and do not stop to check whether it worked."',
  intro:['"The Guard is very patient. It is his one talent.','Get to the far door. Cast the veil, and think: nothing here to see. And do not look at him to check."']});

/* 12. HEARTHSONG: the whole song. Light, quiet and speed together, and only for as long as the song lasts. */
PRAC.Hearthsong=(v,M)=>{
  const def={name:'Lesson 12: the whole song',rows:sxGrid(21,7,[[0,3,'D'],[20,3,'E']]),start:[1,3,'right'],teacher:[2,5],dark:0.96,lightR:34,
    objs:{},
    guards:[{name:'The Warden',path:[[10,1],[10,5]],speed:26,range:6,fov:90,pal:WARDEN_PAL,head:'helm',pause:0.8,scan:true,loop:false}],
    caughtLines:['"WHO\'S THERE?" says the Warden, to the dark, and the dark answers: you.','"Again," says the Warden, kindly. "A song only works if it is sung."'],
    exits:{E:{fn:S=>{ S.timer=null; pracWin(S,['"Every spell is a verse. You sang the whole song: light to see by, quiet to pass, and speed to be done before it ended.','And you knew it would end. Remember the Great Saying: Keep. Kindle. Bank. A spell is only borrowed, and so is the dark."']); }}},
    task:S=>'"A long dark hall, and a Warden, and the far door. Sing the whole song, and cross before it ends."',
    intro:['"A long dark hall, with a Warden in it. I would like you at the far end.','Hearthsong gives you light, and quiet, and speed, all together. It does not give you very long. Sing it, and cross."']};
  return pracRoom(v,M,def);
};
PRAC.Hearthsong.onCast=(S)=>{
  sxTimer(S,30,'The song',()=>{ S.veil=0; S.lumen=0; S.speed=0;
    sxSay(S,V,['(The song runs out. The dark comes back in, and the Warden, who was very patient, turns round.)','"Again. A song has a beginning and an end. Plan for both."'],()=>{ g.px=1.5*TS; g.py=3.95*TS; S.trail=[]; }); });
};

/* =============================================================== the twelve, in the world */
const UT={
  Lumen(tg){
    const cols=SP_COL.Lumen; const A=ART();
    if(tg.k==='npc'){ const nm=vName(tg); vFlash(tg,cols,14); return 'The orb shows '+nm+'\'s face plainly, and '+nm+' is glad it was the orb and not a question.'; }
    if(tg.k!=='tile') return '';
    vFlash(tg,cols,16);
    if(tg.cat==='tree'&&tg.t===T.DARK){ if(!vKey('Lu',tg)) return 'The light has shown you what this dark tree has today.'; spCollect({tx:tg.tx,ty:tg.ty,t:tg.t},'The light shows you what the dark was hiding in'); return ''; }
    if(tg.cat==='crumbs'){ if(!vKey('Lc',tg)) return 'The light shows nothing more.'; const n=1+Math.floor(rnd()*2); g.crumbs+=n; coin(); return 'The light finds crumbs in the cracks. +'+n+'.'; }
    if(tg.cat==='water'){ fxGive('angler',1); return 'The orb\'s light goes down through the water and shows where the fish are keeping still. (Fishing is a little easier.)'; }
    return '';
  },
  Ward(tg){
    const cols=SP_COL.Ward, A=ART(); A.touched=A.touched||{};
    if(tg.k==='npc'){
      const nm=vName(tg); vFlash(tg,cols,16);
      if(!A.touched['Wd'+nm]){ A.touched['Wd'+nm]=1; S4.note('trust',1); g.crumbs+=3; coin(); return 'A small knot of warmth settles round '+nm+'. They look at it, and at you. "Nobody does that," they say, and press 3 crumbs into your wing.'; }
      return nm+' touches the place where the ward settled, and is glad of it.';
    }
    if(tg.k!=='tile') return '';
    vFlash(tg,cols,12);
    if(tg.cat==='light') return 'The flame leans towards the ward, and burns, unbothered, inside it.';
    if(tg.cat==='build') return 'The ward settles on the lintel like a held breath. This house will turn a curse for a while.';
    return '';
  },
  Seek(tg){
    const cols=SP_COL.Seek;
    if(tg.k==='npc'){ const nm=vName(tg); vFlash(tg,cols,10); return 'The beetle turns to '+nm+', and then, delicately, away. It is not that sort of beetle.'; }
    if(tg.k!=='tile') return '';
    vFlash(tg,cols,12);
    if(tg.cat==='rock'){ if(!vKey('Sk',tg)) return 'The beetle has already been under this one today.'; const n=3+Math.floor(rnd()*4); g.crumbs+=n; coin(); return 'The beetle scuttles under the rock and comes out with '+n+' crumbs, looking pleased.'; }
    if(tg.cat==='water'){ fxGive('angler',2); return 'The beetle walks to the edge and points at a place in the water. (Fishing is easier.)'; }
    if(tg.cat==='plant'||(tg.cat==='tree'&&tg.t!==T.DARK)){ if(!vKey('Sp',tg)) return 'The beetle has shown you the best of this one already.'; spCollect({tx:tg.tx,ty:tg.ty,t:tg.t},'The beetle finds the ripest part of'); return ''; }
    return '';
  },
  Bind(tg){
    const cols=SP_COL.Bind, A=ART(); A.touched=A.touched||{};
    if(tg.k==='npc'){
      const nm=vName(tg); vFlash(tg,cols,14);
      if(!A.touched['Bn'+nm]){ A.touched['Bn'+nm]=1; S4.note('kin',1); return 'A ribbon of light loops '+nm+'\'s wrist, loosely, and fades. "Oh," says '+nm+'. It is not a complaint.'; }
      return nm+' turns their wrist over, where the ribbon was.';
    }
    if(tg.k!=='tile') return '';
    vFlash(tg,cols,14);
    if(tg.cat==='plant'||(tg.cat==='tree'&&tg.t!==T.DARK)){ if(!vKey('Bd',tg)) return 'The ribbon has already gathered what this one had to give.'; spCollect({tx:tg.tx,ty:tg.ty,t:tg.t},'The ribbon gathers neatly from'); return ''; }
    return '';
  },
  Veil(tg){
    const cols=SP_COL.Veil;
    if(tg.k==='npc'){
      const nm=vName(tg); vFlash(tg,cols,10);
      if(!vKey('Vl',tg)) return nm+' has said what they will say today.';
      fxGive('haggle',1); return EAVES[hashS(nm+g.day)%EAVES.length].replace(/\{n\}/g,nm)+' (You will haggle a little better today.)';
    }
    if(tg.k==='tile'&&tg.cat==='water'){ vFlash(tg,cols,10); fxGive('angler',1); return 'You are a grey stone with opinions. The fish forget you are there. (Fishing is a little easier.)'; }
    return '';
  },
  Hearthsong(tg){
    const cols=SP_COL.Hearthsong, A=ART(); A.touched=A.touched||{};
    if(tg.k==='npc'){
      const nm=vName(tg); vFlash(tg,cols,20);
      if(!A.touched['Hs'+nm]){ A.touched['Hs'+nm]=1; S4.note('mercy',1); const n=3+Math.floor(rnd()*3); g.crumbs+=n; coin(); return nm+' hums the second line without meaning to, and presses '+n+' crumbs on you, as if paying for a seat.'; }
      return nm+' hums a line, absently, and does not notice they are doing it.';
    }
    if(tg.k!=='tile') return '';
    vFlash(tg,cols,22);
    if(tg.cat==='gone'){ const w=WD(); delete w.gone[tg.tx+','+tg.ty]; tileCache.delete(tkey(tg.tx,tg.ty)); return 'The song reaches the bare ground and something green remembers the next line.'; }
    if(tg.cat==='light'&&tg.t===T.FIRE){ const fid=FISHIDS.find(id=>g.inv['fish_'+id]&&id!=='oldboot'); if(fid){ delInv('fish_'+fid); addItem('roastfish'); return 'The fire sings back, takes your '+FISHBY[fid].n+', and hands over a golden Roast Fish.'; } return 'The fire sings back. A fish in your pack would be roasted.'; }
    if(tg.cat==='plant'||(tg.cat==='tree'&&tg.t!==T.DARK)){ if(!vKey('Hs',tg)) return 'The song has already lifted this one today.'; spCollect({tx:tg.tx,ty:tg.ty,t:tg.t},'The song lifts what is ripe on'); return ''; }
    return '';
  }
};
{
  const _sc=spellCast;
  spellCast=function(n){
    const had=SPF.windup;
    _sc(n);
    if(!UT[n]||!SPF.windup||SPF.windup===had||SPF.windup.n!==n) return;
    const w=SPF.windup, go=w.go;
    w.go=()=>{
      const t0=toast; let cap=''; toast=function(m){ cap=m; };
      try{ go(); } finally{ toast=t0; }
      let extra=''; try{ extra=UT[n](spScan('Mend',VRANGE))||''; }catch(e){ console.error(e); }
      const msg=[cap,extra].filter(Boolean).join(' '); if(msg) toast(msg,msg.length>110?5600:3800);
    };
  };
}
