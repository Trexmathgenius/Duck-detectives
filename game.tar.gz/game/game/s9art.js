'use strict';
/* ===== THE DEEP ART (v1.23) =====
   To the red ducks, the Art is not a trick. It is a way of living in a small cold place: you ask, you are quiet, you listen, you spend what you are given on someone else.
   Beyond the twelve Academy spells there are eight ARTV. Nobody can be given a verse. You are shown one when your life has already been shaped like it:
   the ledger and the hidden traits decide which are offered, and the story decides when.
   THE THREE HEARTH-LAWS:  1. Ask, then be quiet.  2. Harm nothing that cannot be mended.  3. Spend it for another. */

const ART=()=>{ const st=g.story; if(!st.art) st.art={taught:{},breach:0,mended:0,oath:'',readmit:0,seen:{},coerced:{},softened:{},last:0,hist:[],gate:{}}; return st.art; };
const artLed=k=>{ try{ return s2led(k); }catch(e){ return 0; } };
const artH=k=>{ try{ return S4st().h[k]||0; }catch(e){ return 0; } };
const artChap=()=>{ try{ if(s2().ending) return 99; return swChNum(); }catch(e){ return 0; } };
/* who may use the Art at all: reds, and those who learned before they were cast out. Everyone else must be taken back in. */
const artAccess=()=>{ const st=g.story; if(!st) return 'none'; if(st.isRed) return 'red'; return (magicDays()>0||ART().readmit)?'trained':'none'; };
const artWelcome=()=>!!(g.story.isRed||ART().readmit);

const LAWS=['Ask, then be quiet.','Harm nothing that cannot be mended.','Spend it for another.'];

/* ---------- the eight verses ---------- */
const ARTV=[
 {n:'Truthlight',gate:7,trait:'candid',led:'truth',master:'Archivist Sorrel',cd:8,hours:3,col:['#ffe27a','#fff3c4','#ffffff'],
  blurb:'Light that shows what is true, and is polite about it. Shows what wants to be seen; luck follows the honest.',
  hint:'"Come back when you have said a hard thing plainly, more than once, and meant it kindly."',
  qual:(s)=>artH('candid')>=(s?3:2)||artLed('truth')>=(s?4:3),
  icon:c=>{ c.beginPath(); c.moveTo(1.5,9); c.quadraticCurveTo(8,3,14.5,9); c.quadraticCurveTo(8,15,1.5,9); c.closePath(); c.lineWidth=1.4; c.stroke(); c.beginPath(); c.arc(8,9,2.2,0,6.283); c.fill(); c.lineWidth=1.2; for(const a of [-0.9,0,0.9]){ c.beginPath(); c.moveTo(8+Math.sin(a)*3,5.2-Math.cos(a)*1); c.lineTo(8+Math.sin(a)*5.4,2.2-Math.cos(a)*0.6); c.stroke(); } }},
 {n:'Softfall',gate:7,trait:'gentle',led:'mercy',master:'Mistress Vesper',cd:10,hours:3,col:['#ffb3d1','#ffe1ee','#ffffff'],
  blurb:'Petals that settle on a room until it breathes out. Cast near someone, it calms them; rooms soften to persuasion.',
  hint:'"Come back when you have been kind to someone who did not ask, and did not thank you."',
  qual:(s)=>artH('gentle')>=(s?3:2)||artLed('mercy')>=(s?4:3),
  icon:c=>{ c.beginPath(); c.moveTo(8,2); c.quadraticCurveTo(13.5,6,8,14); c.quadraticCurveTo(2.5,6,8,2); c.fill(); c.fillStyle='rgba(0,0,0,0.35)'; c.fillRect(7.6,5,0.9,7); }},
 {n:'Standfast',gate:9,trait:'steady',led:'trust',master:'Hearthwarden Pyre',cd:14,hours:4,col:['#ffd9a0','#ffb347','#fff3e0'],
  blurb:'A ring of runes for whoever needs to stand and cannot. Lengthens the time you have in a hard moment.',
  hint:'"Come back when somebody has leaned on you and you did not let them fall."',
  qual:(s)=>artH('steady')>=(s?3:2)||artLed('trust')>=(s?4:3),
  icon:c=>{ c.lineWidth=1.6; c.beginPath(); for(let i=0;i<6;i++){ const a=i*1.047-1.57; const x=8+Math.cos(a)*6.4, y=8+Math.sin(a)*6.4; if(i) c.lineTo(x,y); else c.moveTo(x,y); } c.closePath(); c.stroke(); c.beginPath(); c.arc(8,8,1.8,0,6.283); c.fill(); }},
 {n:'Lanternwalk',gate:9,trait:'tender',led:'kin',master:'Mistress Vesper',cd:12,hours:2,col:['#ffcf6e','#ffe9a8','#fff8dc'],
  blurb:'A small lantern goes ahead of you, toward what the story is waiting for. It does not know why. It only knows who.',
  hint:'"Come back when you have noticed the small one at the edge of the room, and done something about it."',
  qual:(s)=>artH('tender')>=(s?3:2)||artLed('kin')>=(s?4:3),
  icon:c=>{ c.lineWidth=1.4; c.beginPath(); c.moveTo(6,2.6); c.lineTo(10,2.6); c.stroke(); c.fillRect(5,4,6,1.6); c.fillRect(4.6,5.6,6.8,7.4); c.fillStyle='rgba(0,0,0,0.5)'; c.fillRect(6.2,6.8,3.6,4.6); c.fillStyle='#fff3c4'; c.fillRect(7,7.6,2,3); }},
 {n:'Quietcoat',gate:11,trait:'guarded',led:'lie',master:'Warden Ruddock',cd:16,hours:6,col:['#b9b3e8','#d9d4f5','#ffffff'],
  blurb:'A coat of grey that makes you uninteresting for a long time. It keeps you out of sight; it does not put words in your mouth.',
  hint:'"Come back when you have kept a door on the latch, and known exactly why."',
  qual:(s)=>artH('guarded')>=(s?3:2)||artLed('lie')>=(s?3:2),
  icon:c=>{ c.beginPath(); c.arc(8,8,6,0.5,5.8); c.arc(10.4,7,4.6,5.6,0.7,true); c.closePath(); c.fill(); }},
 {n:'Remembrance',gate:12,trait:'candid',led:'truth',master:'Archivist Sorrel',cd:20,hours:0,col:['#9fd0ff','#d6ebff','#ffffff'],
  blurb:'The Art remembers back to you what you have done, and said, and been. It will not remember for you what you have not.',
  hint:'"Come back when you have carried somebody\'s name for them."',
  qual:(s)=>artLed('truth')>=(s?3:2)&&(S4st().mem.length>=(s?3:2)),
  icon:c=>{ c.lineWidth=1.5; c.beginPath(); for(let a=0;a<9;a+=0.3){ const r=0.9+a*0.62; const x=8+Math.cos(a)*r, y=8+Math.sin(a)*r; if(a===0) c.moveTo(x,y); else c.lineTo(x,y); } c.stroke(); c.beginPath(); c.arc(8,8,1,0,6.283); c.fill(); }},
 {n:'Bloom',gate:13,trait:'tender',led:'kin',master:'Elder Cinder',cd:18,hours:3,col:['#9af0b0','#ffd1e8','#fff6c8'],
  blurb:'A field comes up all at once, and forgets it was ever winter. The wild is kinder to those the Hearth trusts.',
  hint:'"Come back when the Hearth itself has trusted you with something that mattered."',
  qual:(s)=>S6.get('hearth')>=(s?3:2)||(artLed('kin')>=(s?3:2)&&artLed('mercy')>=(s?3:2)),
  icon:c=>{ for(let i=0;i<5;i++){ const a=i*1.2566-1.57; c.beginPath(); c.arc(8+Math.cos(a)*3.6,8+Math.sin(a)*3.6,2.6,0,6.283); c.fill(); } c.fillStyle='rgba(0,0,0,0.45)'; c.beginPath(); c.arc(8,8,1.9,0,6.283); c.fill(); }},
 {n:'Banner',gate:10,trait:'proud',led:'pride',master:'Hearthwarden Pyre',cd:30,hours:0,col:['#ffd24a','#ff9a3a','#fff3c4'],danger:true,
  blurb:'A sigil of gold over your head. It is lovely on an empty hill. Cast at a person, it will make them do what you want, and that is not the Art.',
  hint:'"Come back when you have been right a great many times in a row. That is when I will teach you. Not before."',
  qual:(s)=>artH('proud')>=2||artLed('pride')>=3,
  icon:c=>{ c.fillRect(3.6,1.8,1.4,12.6); c.beginPath(); c.moveTo(5,2.4); c.lineTo(13.4,5); c.lineTo(5,8.6); c.closePath(); c.fill(); }}
];
const VBY={}; ARTV.forEach(v=>VBY[v.n]=v);
const verseKnown=()=>{ if(!g.story||!g.story.art||artAccess()==='none') return []; return ARTV.filter(v=>g.story.art.taught[v.n]).map(v=>v.n); };

/* ---------- they live on the spell bar like any other spell ---------- */
for(const v of ARTV){
  SPELLS.push([v.n,v.blurb]); SPCD[v.n]=v.cd; SP_COL[v.n]=v.col; SP_ICON[v.n]=v.icon;
  const n=v.n, d=document.createElement('div'); d.className='spb'; d.dataset.n=n; d.hidden=true;
  d.appendChild(spIconCanvas(n));
  const cd=document.createElement('div'); cd.className='spcd'; d.appendChild(cd);
  const lk=document.createElement('div'); lk.className='splk'; d.appendChild(lk);
  d.style.setProperty('--sc',SP_COL[n][0]);
  d.addEventListener('click',e=>{ e.stopPropagation(); if(g.mode!=='play') return; if(spGetSel()===n) spellCast(n); else { spSetSel(n); blip(); spSig=''; } });
  spBar.insertBefore(d,spBar.querySelector('.sphint')); spSlots[n]={d:d,cd:cd,lk:lk};
}

/* ---------- what casting does ---------- */
const verseNear=r=>(g.npcs||[]).filter(m=>Math.hypot(m.x-g.px,(m.y-12)-(g.py-12))<r);
const verseHours=v=>{ let h=v.hours; if(ART().breach>0) h*=0.5; if(verseNear(80).length) h*=1.5; return h; };
function verseSeen(r){
  const out=[];
  if(!g.story.s2) return out;
  for(const d of S2.props.values()){
    let on=true; try{ on=!d.when||d.when(); }catch(e){ on=false; }
    if(!on) continue;
    let m=d.mark; try{ if(typeof m==='function') m=m(); }catch(e){ m=null; }
    if(!m) continue;
    try{ s2xy(d); }catch(e){ continue; }
    const x=d.wx*TS+16, y=d.wy*TS+8, dist=Math.hypot(x-g.px,y-g.py);
    if(dist<=r) out.push({x,y,d,dist});
  }
  return out.sort((a,b)=>a.dist-b.dist);
}
function verseObjective(){
  if(!g.story.s2) return null;
  let best=null;
  for(const d of S2.props.values()){
    let on=true; try{ on=!d.when||d.when(); }catch(e){ on=false; }
    if(!on) continue;
    let m=d.mark; try{ if(typeof m==='function') m=m(); }catch(e){ m=null; }
    if(m!=='!') continue;
    try{ s2xy(d); }catch(e){ continue; }
    const x=d.wx*TS+16, y=d.wy*TS+8, dist=Math.hypot(x-g.px,y-g.py);
    if(!best||dist<best.dist) best={x,y,dist,d};
  }
  return best;
}
const SOFT_LINES={'Warden Ruddock':'Ruddock\'s shoulders come down a quarter of an inch. He does not say thank you. He says "hm", and sits.','Captain Halbeak':'Halbeak looks at the petals on his sleeve as if they were an order he had not expected to like.','Little Poppy':'Poppy catches a petal on her tongue and decides this is the best day of her life.','Hermit Mallow':'Mallow closes his eyes. "My mother used to do that with flour," he says, quietly, and does not elaborate.'};
const VERSEFX={
  Truthlight(v){
    const x=XS(), cols=v.col, px=g.px, py=g.py-12;
    x.truthUntil=xAbs()+verseHours(v); fxGive('luck',2);
    for(let i=0;i<4;i++) setTimeout(()=>spRing(px,py+12,cols[i%3],6,70+i*40,0.9+i*0.12,2.2),i*140);
    for(let i=0;i<30;i++){ const a=i/30*6.283; spP({k:'line',x:px,y:py,vx:Math.cos(a)*230,vy:Math.sin(a)*140,drag:1.2,life:0.75,r:2,col:cols[i%3]}); }
    for(let i=0;i<40;i++) spP({k:'dot',x:px+(Math.random()-0.5)*22,y:py+10,vx:(Math.random()-0.5)*20,vy:-55-Math.random()*70,drag:0.5,life:1.5,r:1.8+Math.random()*1.5,col:cols[i%3]});
    spLight(px,py,210,'#fff0b0',0.85);
    [660,880,1320].forEach((f,i)=>setTimeout(()=>tone('sine',f,f*1.01,0.5,0.05),i*110));
    const seen=verseSeen(300);
    seen.slice(0,6).forEach((s,i)=>setTimeout(()=>{ spRing(s.x,s.y,cols[0],3,30,0.9,2); spBurst(s.x,s.y-6,cols,14,50,{up:50,g:-20,life:1}); spP({k:'line',x:s.x,y:s.y-30,vx:0,vy:-90,drag:0.4,life:0.9,r:2,col:cols[1]}); },250+i*120));
    const near=seen[0];
    return seen.length?('The light goes out in a ring, and '+seen.length+(seen.length>1?' things':' thing')+' nearby '+(seen.length>1?'are':'is')+' glad to be seen.'+(near&&near.d.name?' Nearest: '+near.d.name+'.':'')):'The light goes out in a ring and finds nothing hiding. That is its own kind of answer.';
  },
  Softfall(v){
    const x=XS(), cols=v.col, px=g.px, py=g.py-12;
    x.softUntil=xAbs()+verseHours(v); g.boost=Math.min(150,(g.boost||0)+40);
    for(let i=0;i<80;i++){ const a=Math.random()*6.283, r=Math.random()*120; spP({k:'leaf',x:px+Math.cos(a)*r,y:py-90-Math.random()*40,vx:(Math.random()-0.5)*26,vy:14+Math.random()*24,ay:6,drag:0.2,life:2.6+Math.random()*1.4,r:1.6+Math.random()*1.6,col:['#ffb3d1','#ffe1ee','#fff6f0','#ffd9a0'][i%4],rot:Math.random()*6,vr:(Math.random()-0.5)*4}); }
    for(let i=0;i<5;i++) spP({k:'note',x:px+(Math.random()-0.5)*40,y:py-8,vx:(Math.random()-0.5)*14,vy:-26-Math.random()*20,drag:0.4,life:1.8,r:3,col:cols[i%3]});
    spRing(px,py+12,cols[0],8,90,1.2,3); spLight(px,py-20,190,'#ffd9ec',0.7);
    [523,659,784].forEach((f,i)=>setTimeout(()=>tone('sine',f,f,0.5,0.04),i*160));
    const near=verseNear(70).sort((a,b)=>Math.hypot(a.x-g.px,a.y-g.py)-Math.hypot(b.x-g.px,b.y-g.py))[0];
    if(!near) return 'The petals come down on nobody, and the street is a little softer for it.';
    const nm=near.name||'the duck';
    let out=SOFT_LINES[nm]||(nm+' lifts a face into the petals, and for a moment is not carrying anything.');
    if(!ART().softened[nm]){ ART().softened[nm]=1; S4.note('mercy',1); try{ s2led('mercy',1); }catch(e){} out+=' (A small mercy, noted.)'; }
    return out;
  },
  Standfast(v){
    const x=XS(), cols=v.col, px=g.px, py=g.py-4;
    x.standUntil=xAbs()+verseHours(v); g.story.luckDay=g.day;
    for(let i=0;i<3;i++) setTimeout(()=>spRing(px,py,cols[i%2],8,60+i*14,0.9,2.8),i*130);
    for(let i=0;i<12;i++){ const a=i/12*6.283; spP({k:'rune',x:px+Math.cos(a)*34,y:py+Math.sin(a)*15,vx:Math.cos(a)*6,vy:-32-Math.random()*14,drag:0.5,life:1.4,r:2.8,col:cols[i%3],rot:a,vr:1.2}); }
    spBurst(px,py-10,cols,26,70,{up:20,g:10,life:0.9}); spLight(px,py-14,170,'#ffcf8a',0.8);
    tone('triangle',140,260,0.7,0.07); setTimeout(()=>tone('sine',390,390,0.5,0.04),180);
    return 'A ring of runes settles round your feet and holds. For a while you will have longer than you think.';
  },
  Lanternwalk(v){
    const x=XS(), cols=v.col, px=g.px, py=g.py-18;
    x.lanternUntil=xAbs()+verseHours(v); VST.lx=px+14; VST.ly=py-14;
    spBurst(px+14,py-14,cols,30,80,{up:30,g:-14,life:0.9}); spRing(px+14,py-6,cols[0],4,40,0.8,2); spLight(px+14,py-14,140,'#ffd98a',0.8);
    [392,523,659].forEach((f,i)=>setTimeout(()=>tone('sine',f,f,0.4,0.05),i*120));
    const o=verseObjective();
    return o?'A small lantern lights, and drifts toward the thing the story is waiting on. It is not sure why. It is sure who.':'A small lantern lights at your shoulder. Nothing here is waiting for you, so it keeps you company.';
  },
  Quietcoat(v){
    const x=XS(), cols=v.col, px=g.px, py=g.py-10;
    const until=xAbs()+verseHours(v); x.veilUntil=Math.max(x.veilUntil||0,until); x.coatUntil=until;
    for(let i=0;i<46;i++){ const a=Math.random()*6.28, r=46+Math.random()*30; spP({k:'smoke',x:px+Math.cos(a)*r,y:py+Math.sin(a)*r*0.6,vx:-Math.cos(a)*r*1.6,vy:-Math.sin(a)*r*1.0,drag:1.4,life:0.9,r:6,col:'#b9b3e8'}); }
    spBurst(px,py-4,cols,28,50,{life:1}); spRing(px,py+10,cols[0],40,6,0.9,2);
    tone('sine',620,180,0.9,0.05);
    return 'The coat settles. You are wonderfully uninteresting for a long while, and not a word of it is a lie.';
  },
  Remembrance(v){
    const cols=v.col, px=g.px, py=g.py-12;
    for(let k=0;k<2;k++) for(let i=0;i<14;i++) spP({k:'rune',x:px+(k?24:-24)+(Math.random()-0.5)*8,y:py+14,vx:(Math.random()-0.5)*6,vy:-40-Math.random()*30,drag:0.5,life:1.8,r:2.2,col:cols[i%3],rot:i,vr:0.8});
    for(let i=0;i<12;i++) spP({k:'note',x:px+(Math.random()-0.5)*50,y:py,vx:(Math.random()-0.5)*14,vy:-24-Math.random()*20,drag:0.4,life:1.8,r:3,col:cols[i%3]});
    spRing(px,py+12,cols[0],6,80,1.3,2.5); spLight(px,py-14,170,'#cfe6ff',0.7);
    [440,554,659,880].forEach((f,i)=>setTimeout(()=>tone('sine',f,f,0.45,0.04),i*150));
    setTimeout(()=>verseRemember(),900);
    return '';
  },
  Bloom(v){
    const x=XS(), cols=v.col, px=g.px, py=g.py-6;
    x.bloomUntil=xAbs()+verseHours(v); fxGive('forage',3); fxGive('luck',1);
    const wild=(()=>{ try{ return typeof swStarted==='function'&&swStarted(); }catch(e){ return false; } })();
    for(let i=0;i<110;i++){ const a=Math.random()*6.283, r=10+Math.random()*(70+(wild?20:0)); spP({k:'leaf',x:px+Math.cos(a)*r*0.3,y:py+Math.sin(a)*r*0.15,vx:Math.cos(a)*r*1.1,vy:-50-Math.random()*60+Math.sin(a)*r*0.2,ay:80,drag:0.7,life:1.4+Math.random()*0.9,r:1.5+Math.random()*1.8,col:['#7fe09a','#ffd1e8','#fff6c8','#ff9ac0','#a8f0c0'][i%5],rot:Math.random()*6,vr:(Math.random()-0.5)*5}); }
    for(let i=0;i<50;i++) spP({k:'dot',x:px+(Math.random()-0.5)*120,y:py+(Math.random()-0.5)*40,vx:(Math.random()-0.5)*10,vy:-18-Math.random()*26,drag:0.5,life:1.8,r:1.4,col:'#fff6c8'});
    spRing(px,py+8,cols[0],8,110,1.3,3); setTimeout(()=>spRing(px,py+8,cols[1],8,140,1.4,2.5),180); spLight(px,py-10,200,'#c8ffd8',0.6);
    [330,415,523,659].forEach((f,i)=>setTimeout(()=>tone('triangle',f,f*1.02,0.5,0.045),i*110));
    return 'The ground forgets it was ever winter. For a while the wild looks on you kindly. (Foraging is easier.)';
  },
  Banner(v){
    const x=XS(), cols=v.col, px=g.px, py=g.py-40;
    for(let i=0;i<3;i++) setTimeout(()=>spRing(px,py,cols[i%3],10,90+i*34,1.0,3.2),i*140);
    for(let i=0;i<16;i++){ const a=i/16*6.283; spP({k:'line',x:px,y:py,vx:Math.cos(a)*260,vy:Math.sin(a)*160,drag:1.1,life:0.85,r:2,col:cols[i%3]}); }
    for(let i=0;i<5;i++){ const a=i*1.2566-1.57; spP({k:'rune',x:px+Math.cos(a)*22,y:py+Math.sin(a)*22,vx:0,vy:-4,drag:0.2,life:1.7,r:5.5,col:cols[0],rot:a,vr:0.3}); }
    spBurst(px,py,cols,36,120,{life:1}); spLight(px,py,230,'#ffe9a0',0.95);
    tone('sawtooth',110,220,0.9,0.07); setTimeout(()=>tone('triangle',330,330,0.6,0.05),240);
    const near=verseNear(110).sort((a,b)=>Math.hypot(a.x-g.px,a.y-g.py)-Math.hypot(b.x-g.px,b.y-g.py))[0];
    if(!near) return 'A sigil of gold stands over your head for a long breath. There is nobody to see it. That is, you suspect, what it was for.';
    const nm=near.name||'the duck';
    const A=ART(); A.breach++; A.coerced[nm]=1; A.hist.push('cast the Banner at '+nm);
    S4.note('pride',2); S4.shift('tender',-1); S4.shift('gentle',-1); try{ s2led('pride',1); }catch(e){}
    fxGive('haggle',3);
    sayWhenFree(nm,['(They go very still. Then they bow, a little, without having decided to.)','"Of course," says '+nm+'. "Whatever you like." The voice is polite and very far away.','(You did not ask. You did not wait. The petals of the first law have gone out of the air.)'],null,500);
    return 'The Art goes quiet in you, like a room after a door is shut. (Your verses will burn thin until you mend it.)';
  }
};
function verseRemember(){
  const S=ART();
  const opts=['What the road has said of you','What you have done','Who you are becoming','What you first said, at the start','Leave it'];
  choose('','Remembrance holds still. Which would you like back?',opts,k=>{
    if(k===0){ const lg=(S6st().log||[]).slice(-3); say('',lg.length?lg.map(e=>(e.who?e.who+': ':'')+e.t):['The road has not said anything about you yet. That is not the same as nothing.']); }
    else if(k===1){ const m=S4st().mem.slice(-4); say('',m.length?m.map(x=>'You '+x+'.'):['There is not enough behind you, yet, to remember.']); }
    else if(k===2){ const p=S4.portrait(); say('',p.lines); }
    else if(k===3){ const p=P1(), L=[];
      if(p.why!==undefined) L.push('You told the Elders you had come '+['because a stranger told you a tale in Puddlewick','because the king\'s castle was shut and something was wrong at its heart','because you are a detective, and follow mysteries','because a vision called you'][p.why]+'.');
      if(p.from!==undefined) L.push('Asked whose child you were, you said '+['Mallardia','that you woke in a quiet forest and do not know','south, past the river','that you would rather not say'][p.from]+'.');
      if(p.tell) L.push('You told Mallow that Emberwick had looked at you '+{fear:'like a flood they had been waiting for',plain:'flatly, at the gate',proud:'like you were nothing, and that it was their loss'}[p.tell]+'.');
      if(p.told) L.push('To the king, you gave '+{all:'the gate, the numbers, and the town',soft:'only that they were frightened, and bakers',little:'nothing, but that they exist'}[p.told]+'.');
      if(p.umber!==undefined) L.push('To a blind man in the Umbral Wood, you said '+['that the Elders would only trust you if you did it','that you wished to know what it was to be hunted, and then to be at home','that you were not sure, and came to see','that you came to spy for the king'][p.umber]+'.');
      say('',L.length?L:['Before the war, you had not said much. That, too, is a kind of beginning.']); }
  },opts.length-1);
}
function verseCast(n){
  if(g.mode!=='play'||g.scene!=='world') return;
  const v=VBY[n];
  if(spKnown().indexOf(n)<0){ toast('You have not learned '+n+' yet.',2200); return; }
  if(!spellReady(n)){ toast(n+' is still settling: ready in '+xIn(XS().cd[n]-xAbs())+'.',2200); return; }
  if(g.time<SPF.busy||SPF.windup) return;
  SPF.busy=g.time+0.7; spSetSel(n); setCd(n,v.cd);
  SPF.windup={n:n,t:0.32,max:0.32,go:()=>{ let msg=''; try{ msg=VERSEFX[n](v)||''; }catch(e){ console.error(e); } if(msg) toast(msg,msg.length>110?5600:3800); }};
}
{
  const _sc=spellCast;
  spellCast=function(n){ if(VBY[n]) return verseCast(n); return _sc(n); };
}

/* ---------- the verses that stay with you: auras, and the lantern ---------- */
const VST={lx:0,ly:0,t:0,sp:0};
function verseUpdate(dt){
  if(!g.story||g.scene!=='world'||g.mode==='title') return;
  const x=XS(), now=xAbs();
  VST.t+=dt;
  if(x.lanternUntil>now){
    const o=verseObjective();
    let tx=g.px+14, ty=g.py-34;
    if(o){ const dx=o.x-g.px, dy=o.y-g.py, d=Math.hypot(dx,dy)||1, r=Math.min(64,d*0.5); tx=g.px+dx/d*r; ty=g.py-20+dy/d*r*0.7-8; }
    if(!VST.lx) { VST.lx=g.px; VST.ly=g.py-20; }
    const k=Math.min(1,dt*3.2); VST.lx+=(tx-VST.lx)*k; VST.ly+=(ty-VST.ly)*k+Math.sin(VST.t*3)*0.2;
    if(Math.random()<0.5) spP({k:'dot',x:VST.lx+(Math.random()-0.5)*4,y:VST.ly+4,vx:(Math.random()-0.5)*10,vy:10+Math.random()*10,drag:1,life:0.6,r:1.4,col:'#ffe9a8'});
  } else if(VST.lx){ spBurst(VST.lx,VST.ly,['#ffcf6e','#ffe9a8'],14,50,{life:0.6}); VST.lx=0; }
  if(x.softUntil>now&&Math.random()<dt*5) spP({k:'leaf',x:g.px+(Math.random()-0.5)*90,y:g.py-70,vx:(Math.random()-0.5)*12,vy:14+Math.random()*14,ay:4,drag:0.2,life:2.4,r:1.5,col:['#ffb3d1','#ffe1ee'][(Math.random()*2)|0],rot:Math.random()*6,vr:(Math.random()-0.5)*3});
  if(x.coatUntil>now&&Math.random()<dt*3) spP({k:'smoke',x:g.px+(Math.random()-0.5)*22,y:g.py-2,vx:(Math.random()-0.5)*8,vy:-6-Math.random()*6,drag:0.8,life:1.2,r:4,col:'#b9b3e8'});
}
function verseDraw(c,kd){
  if(g.scene!=='world'||!g.story) return;
  const x=XS(), now=xAbs();
  const stand=x.standUntil>now, truth=x.truthUntil>now, lamp=x.lanternUntil>now&&VST.lx;
  if(!stand&&!truth&&!lamp) return;
  const t=VST.t;
  c.save(); c.setTransform(kd,0,0,kd,-view.ox*kd,-view.oy*kd); c.globalCompositeOperation='lighter';
  if(stand){
    c.globalAlpha=0.28+0.1*Math.sin(t*2); c.strokeStyle='#ffcf8a'; c.lineWidth=1.3; c.beginPath(); c.ellipse(g.px,g.py-3,21,8,0,0,6.283); c.stroke();
    for(let i=0;i<6;i++){ const a=t*0.8+i*1.047, rx=g.px+Math.cos(a)*21, ry=g.py-3+Math.sin(a)*8; c.globalAlpha=0.7; c.strokeStyle='#ffe0b0'; c.save(); c.translate(rx,ry); c.rotate(a); c.beginPath(); c.moveTo(0,-3); c.lineTo(2,0); c.lineTo(0,3); c.lineTo(-2,0); c.closePath(); c.stroke(); c.restore(); }
  }
  if(truth){
    c.globalAlpha=0.5+0.15*Math.sin(t*2.4); c.strokeStyle='#ffe27a'; c.lineWidth=1.2; c.beginPath(); c.ellipse(g.px,g.py-35,9,3,0,0,6.283); c.stroke();
    for(let i=0;i<2;i++){ const a=t*1.6+i*3.14; c.globalAlpha=0.7; c.fillStyle='#fff3c4'; c.beginPath(); c.arc(g.px+Math.cos(a)*9,g.py-35+Math.sin(a)*3,1.3,0,6.283); c.fill(); }
  }
  if(lamp){
    const lx=VST.lx, ly=VST.ly+Math.sin(t*3)*1.5;
    const gr=c.createRadialGradient(lx,ly,0,lx,ly,34); gr.addColorStop(0,'rgba(255,225,150,0.65)'); gr.addColorStop(1,'rgba(255,200,100,0)');
    c.globalAlpha=1; c.fillStyle=gr; c.beginPath(); c.arc(lx,ly,34,0,6.283); c.fill();
    c.globalCompositeOperation='source-over'; c.globalAlpha=1;
    c.fillStyle='#4a3420'; c.fillRect(lx-3,ly-6,6,1.6); c.fillRect(lx-3.4,ly-4.4,6.8,7.6);
    c.fillStyle='#ffe9a8'; c.fillRect(lx-2.2,ly-3.2,4.4,5.4); c.fillStyle='#fff8dc'; c.fillRect(lx-1,ly-2,2,3);
  }
  c.restore();
}
{
  const _upd=update;
  update=function(dt){ _upd(dt); try{ verseUpdate(dt); }catch(e){ console.error(e); } };
  const _dp=drawParts;
  drawParts=function(c,kind,kd){ _dp(c,kind,kd); try{ verseDraw(c,kd); }catch(e){ console.error(e); } };
}
