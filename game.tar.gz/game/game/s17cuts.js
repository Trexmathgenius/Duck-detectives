'use strict';
/* ===== STORY CUTSCENES FOR CHAPTERS 5 TO 24 =====
   Chapters 1-4 tell their big moments as animated cutscenes (the vision, the hermit's tale, the Elders' history).
   From chapter 5 on the game used to show only a title card. This file gives every main chapter an opening cutscene
   that plays straight after its title card, and the turning points a short closing one.

   - SCENES.s17*       : animated backdrops (options come from the current beat's `opt`)
   - TELLERBG.s17      : lets a talking beat use any of those backdrops behind the text box
   - OPEN[chapterId]   : beats played after the chapter card (same beat format as startCutscene)
   - CLOSE[chapterId]  : beats played when a chapter finishes, before the next chapter begins
   Each cutscene plays once per save (s2().cuts), and X skips it like every other cutscene. */
(function(){

/* ---------- small helpers ---------- */
const ez=x=>{ x=Math.max(0,Math.min(1,x)); return x*x*(3-2*x); };
const rn=i=>{ const s=Math.sin(i*127.1+311.7)*43758.5453; return s-Math.floor(s); };
const opt=()=>{ const b=cut.beats[cut.i]; return (b&&b.opt)||{}; };
const YEL={body:'#ffd84a',wing:'#f0b921',bill:'#ff8a1f'};
const BLUE={body:'#4a6fb5',wing:'#37558c',bill:'#e6c441'};
const GREY={body:'#8a8f99',wing:'#6a6f78',bill:'#d9a066'};
const WHITE={body:'#f4f4ee',wing:'#d4d8cf',bill:'#ff9d2e'};
const REDS=['#c0392b','#d9503f','#a83a2d','#e04a3a','#b5352b','#d9503f'];
const BLUES=['#4a6fb5','#5a82c9','#3f5f9f','#6a8fd0'];
function meDuck(){ try{ return (g.story&&g.story.isRed)?REDDUCK:YEL; }catch(e){ return YEL; } }
function vg(c,a){
  const gr=c.createRadialGradient(LW/2,LH/2,LH*0.35,LW/2,LH/2,LW*0.7);
  gr.addColorStop(0,'rgba(0,0,0,0)'); gr.addColorStop(1,'rgba(4,2,14,'+a+')'); c.fillStyle=gr; c.fillRect(0,0,LW,LH);
}
function ridge(c,y,col,amp,fr,ph){
  c.fillStyle=col; c.beginPath(); c.moveTo(0,LH);
  for(let x=0;x<=LW;x+=8) c.lineTo(x,y+Math.sin(x*fr+(ph||0))*amp);
  c.lineTo(LW,LH); c.closePath(); c.fill();
}
function pineRow(c,y,col,sz,off,gap){
  c.fillStyle=col;
  for(let x=-gap+off;x<LW+gap;x+=gap){ c.beginPath(); c.moveTo(x,y); c.lineTo(x+gap*0.5,y-sz); c.lineTo(x+gap,y); c.fill(); }
}
function twinkle(c,t,n,ymax,a){
  for(let i=0;i<n;i++){ const s=cut.stars[i%cut.stars.length]; const al=(a||1)*(0.35+0.65*Math.abs(Math.sin(t*1.5+s[2]))); c.fillStyle='rgba(255,255,230,'+al.toFixed(2)+')'; c.fillRect(s[0],Math.min(ymax,s[1]),1,1); }
}
function moon(c,x,y,r,bg){ circ(c,x,y,r*1.8,'rgba(244,239,208,0.10)'); circ(c,x,y,r,'#f4efd0'); circ(c,x+r*0.45,y-r*0.3,r*0.85,bg); }
function lamp(c,x,y,lit,t,s){
  s=s||1; rect(c,x-0.8*s,y-14*s,1.6*s,14*s,'#4a3a2a');
  if(lit){ const f=0.8+0.2*Math.sin(t*7+x); circ(c,x,y-16*s,7*s,'rgba(255,200,110,'+(0.18*f).toFixed(2)+')'); circ(c,x,y-16*s,2.6*s,'rgba(255,225,150,'+f.toFixed(2)+')'); }
  else circ(c,x,y-16*s,2.4*s,'#3a3a44');
}
function house(c,x,y,s,wall,roof,lit,t){
  rect(c,x-12*s,y-14*s,24*s,14*s,wall); c.fillStyle=roof; c.beginPath(); c.moveTo(x-16*s,y-13*s); c.lineTo(x,y-30*s); c.lineTo(x+16*s,y-13*s); c.fill();
  rect(c,x-3*s,y-9*s,6*s,9*s,'#3b2a2a');
  if(lit){ const f=0.75+0.25*Math.sin((t||0)*6+x); rect(c,x+5*s,y-11*s,5*s,5*s,'rgba(255,214,130,'+f.toFixed(2)+')'); rect(c,x-10*s,y-11*s,5*s,5*s,'rgba(255,214,130,'+f.toFixed(2)+')'); }
  else { rect(c,x+5*s,y-11*s,5*s,5*s,'#2a2630'); rect(c,x-10*s,y-11*s,5*s,5*s,'#2a2630'); }
}
function bobDuck(c,x,y,dir,t,pal,sc,o){ drawDuck(c,x,y,dir,t*6,true,pal,Object.assign({scale:sc||1.6},o||{})); }
function staticDuck(c,x,y,dir,pal,sc,o){ drawDuck(c,x,y,dir,0,false,pal,Object.assign({scale:sc||1.6},o||{})); }
function flare(c,x,y,s,t,col){
  const f=0.85+0.15*Math.sin(t*9+x), cc=col||['#ff7a2a','#ffd166','#fff3c4'];
  c.fillStyle=cc[0]; c.beginPath(); c.moveTo(x-5*s,y); c.quadraticCurveTo(x-6*s,y-10*s*f,x+Math.sin(t*11+x)*2*s,y-20*s*f); c.quadraticCurveTo(x+7*s,y-10*s*f,x+5*s,y); c.fill();
  c.fillStyle=cc[1]; c.beginPath(); c.moveTo(x-3*s,y); c.quadraticCurveTo(x-3.5*s,y-7*s*f,x,y-13*s*f); c.quadraticCurveTo(x+4*s,y-7*s*f,x+3*s,y); c.fill();
  c.fillStyle=cc[2]; c.beginPath(); c.moveTo(x-1.5*s,y); c.quadraticCurveTo(x-1.5*s,y-4*s,x,y-7*s*f); c.quadraticCurveTo(x+2*s,y-4*s,x+1.5*s,y); c.fill();
}
function glow(c,x,y,r,col){
  const gr=c.createRadialGradient(x,y,1,x,y,r); gr.addColorStop(0,col); gr.addColorStop(1,col.replace(/[\d.]+\)$/,'0)')); c.fillStyle=gr; c.fillRect(x-r,y-r,r*2,r*2);
}
function crowd(c,x0,x1,y,n,cols,dir,sc,t,jit){
  for(let i=0;i<n;i++){ const x=x0+(x1-x0)*(n<2?0.5:i/(n-1))+(rn(i+jit)-0.5)*6, yy=y+(i%3)*4+rn(i*3+jit)*3; mini(c,x,yy,cols[i%cols.length],dir==='mix'?(x<LW/2?'right':'left'):dir,sc,Math.abs(Math.sin(t*2+i))*-0.4); }
}

/* ---------- THE ROAD: travellers, shutters, meetings ---------- */
SCENES.s17road=function(c,t){
  const o=opt(), sk=o.sky||'day';
  const P={dawn:['#3a2a5a','#f4b07a'],day:['#6fb0e8','#f7e0a0'],dusk:['#3b2a6b','#f0a56b'],night:['#070b1e','#1c2350']}[sk];
  sky(c,P[0],P[1],22);
  if(sk==='night'){ twinkle(c,t,50,90); moon(c,264,34,10,P[0]); }
  else if(sk==='dawn'||sk==='dusk'){ circ(c,240,104,26,'rgba(255,214,150,0.25)'); circ(c,240,104,14,'#ffe2a0'); }
  else { circ(c,60,30,12,'#fff6c0'); circ(c,60,30,20,'rgba(255,246,190,0.25)'); for(let i=0;i<3;i++){ const x=((t*5+i*130)%420)-50; ell(c,x,30+i*14,24,6,'rgba(255,255,255,0.85)'); } }
  const dk=sk==='night'?0.55:sk==='day'?1:0.8;
  const sh=(h)=>{ const k=parseInt(h.slice(1),16); return 'rgb('+(((k>>16)&255)*dk|0)+','+(((k>>8)&255)*dk|0)+','+((k&255)*dk|0)+')'; };
  ridge(c,112,sh('#6d7fae'),6,0.025,1); ridge(c,124,sh('#4d7a5a'),7,0.035,3);
  if(o.castle){ castle(c,262,124,0.5,sk==='night'?'#4a4f6a':'#d8d2c0','#3a5f9c',t,'#e0b84a'); }
  ridge(c,136,sh('#4f8a50'),5,0.05,0);
  /* the road, curving toward the horizon */
  c.fillStyle=sh('#b09a6a'); c.beginPath(); c.moveTo(-10,LH); c.lineTo(-10,152); c.quadraticCurveTo(120,140,240,126); c.lineTo(250,126); c.quadraticCurveTo(140,150,60,LH); c.fill();
  /* farms with shutters (optional) */
  if(o.farms){
    for(let i=0;i<2;i++){
      const x=i?282:44, y=i?140:150, s=i?0.8:1.1; house(c,x,y,s,'#e6d6b0','#8a4a3a',true,t);
      const cl=ez((t-1-i*1.3)/1.2); rect(c,x+5*s,y-11*s,5*s*(1-cl),5*s,'#2a2118'); rect(c,x-10*s,y-11*s,5*s*(1-cl),5*s,'#2a2118'); rect(c,x+5*s,y-11*s,5*s*cl,5*s,'#4a2e1e'); rect(c,x-10*s,y-11*s,5*s*cl,5*s,'#4a2e1e');
    }
  }
  /* lantern posts */
  if(o.lanterns){ for(let i=0;i<6;i++){ const k=i/5, x=20+k*215, y=162-k*30; lamp(c,x+(i%2?10:-10),y,true,t,0.6+0.5*(1-k)); } }
  /* walkers */
  const party=o.party||['me'];
  if(o.meet){
    const p=ez(t/(o.dur||10));
    for(let i=0;i<4;i++){ const x=-20+(120-i*18)*p-(1-p)*i*8; bobDuck(c,x,150-i*2,'right',t+i,i%2?REDDUCK:REDDUCK,1.3); }
    for(let i=0;i<4;i++){ const x=LW+20-(120-i*18)*p+(1-p)*i*8; bobDuck(c,x,150-i*2,'left',t+i,BLUE,1.3); }
    glow(c,160,120,50,'rgba(255,214,150,0.25)');
  } else {
    const pal={me:meDuck(),mallow:REDDUCK,poppy:{body:'#e0603f',wing:'#b24a30',bill:'#e6c441'},ruddock:{body:'#a82a2a',wing:'#7f1f1f',bill:'#d9902a'},halbeak:BLUE,cinder:{body:'#b5322a',wing:'#8a2620',bill:'#ff9d2e'}};
    const hd={ruddock:'helm',halbeak:'helm',mallow:'hood',cinder:'wizard',poppy:'bow'};
    const sz={poppy:1.25,me:1.7,mallow:1.75,ruddock:1.8,halbeak:1.8,cinder:1.75};
    party.forEach((k,i)=>{
      const x=o.stand?(150+i*28-(party.length-1)*14):(40+t*(o.pace||13)+i*(-26)+(k==='ruddock'?-8:0));
      const y=148+((i*5)%9)-(x/LW)*8;
      if(o.stand) staticDuck(c,x,y,'right',pal[k],sz[k]||1.6,{head:hd[k]}); else bobDuck(c,x,y,'right',t+i,pal[k],sz[k]||1.6,{head:hd[k]});
      if(k==='poppy'||k==='me'){ if(o.lantern) { circ(c,x+10,y-18+Math.sin(t*3+i),9,'rgba(255,214,130,0.25)'); rect(c,x+8,y-20,4,6,'#f2b84b'); rect(c,x+9,y-19,2,4,'#fff1b0'); } }
    });
  }
  /* falling leaves / ash / petals */
  if(o.fall){ for(let i=0;i<30;i++){ const fx=(i*37+Math.sin(t+i)*10+t*10)%LW, fy=(t*14+i*23)%LH; c.fillStyle=o.fall; c.fillRect(fx,fy,1.6,1.6); } }
  vg(c,0.4);
};

/* ---------- EMBERWICK, the red town ---------- */
SCENES.s17town=function(c,t){
  const o=opt(), mode=o.hearth||'warm', dawn=!!o.dawn;
  sky(c,dawn?'#2a1a3a':'#070b1e',dawn?'#f0a56b':'#1a1f40',22);
  if(!dawn){ twinkle(c,t,55,80); moon(c,40,28,9,'#0a0f26'); }
  else { circ(c,250,112,24,'rgba(255,214,150,0.28)'); circ(c,250,112,12,'#ffe2a0'); }
  pineRow(c,112,dawn?'#2a2050':'#0c1a24',36,0,28); pineRow(c,120,dawn?'#1e1840':'#0a1520',44,-10,34);
  ridge(c,124,dawn?'#2b3a3a':'#0f2a22',3,0.05,2);
  /* palisade */
  for(let x=0;x<LW;x+=7){ const h=16+rn(x)*5; rect(c,x,126-h,5,h,dawn?'#4a3428':'#2e2018'); c.fillStyle=dawn?'#5a4030':'#3a281c'; c.beginPath(); c.moveTo(x,126-h); c.lineTo(x+2.5,126-h-5); c.lineTo(x+5,126-h); c.fill(); }
  const lanternsLit=o.lanterns!==false;
  house(c,36,142,1.3,dawn?'#9a7a68':'#6a4a48','#7a2a24',lanternsLit,t); house(c,92,138,1.0,dawn?'#9a7a68':'#6a4a48','#932d22',lanternsLit,t);
  house(c,232,138,1.0,dawn?'#9a7a68':'#6a4a48','#a0382a',lanternsLit,t); house(c,284,144,1.35,dawn?'#9a7a68':'#6a4a48','#7a2a24',lanternsLit,t);
  c.fillStyle=dawn?'#5a5048':'#1a2a22'; c.fillRect(0,144,LW,LH-144);
  for(let x=0;x<LW;x+=18) for(let y=146;y<LH;y+=9){ c.fillStyle=((x/18+y/9)&1)?'rgba(255,255,255,0.03)':'rgba(0,0,0,0.05)'; c.fillRect(x,y,18,9); }
  /* strings of lanterns */
  c.strokeStyle='#3a2a1a'; c.lineWidth=1; c.beginPath(); c.moveTo(0,70); c.quadraticCurveTo(80,92,160,76); c.quadraticCurveTo(240,60,LW,82); c.stroke();
  for(let i=0;i<14;i++){ const k=i/13, x=k*LW, y=70+Math.sin(k*Math.PI*1.5)*14+((i%2)?4:0)+6;
    if(lanternsLit){ const f=0.75+0.25*Math.sin(t*5+i); circ(c,x,y,6,'rgba(255,190,90,'+(0.2*f).toFixed(2)+')'); rect(c,x-1.6,y-2,3.2,4.5,'rgba(255,205,110,'+f.toFixed(2)+')'); } else rect(c,x-1.6,y-2,3.2,4.5,'#34303a'); }
  /* the Great Hearth */
  const hx=160, hy=150;
  const col={warm:['#ff7a2a','#ffd166','#fff3c4'],dim:['#8a3a1a','#c26a2a','#e8a860'],bruise:['#4a2a6a','#7a4a9a','#b08ad0'],blue:['#2a6ad0','#6ab4ff','#d8f0ff'],bright:['#ff9d2e','#ffe08a','#ffffff']}[mode];
  const sz={warm:1.2,dim:0.55,bruise:1.0,blue:1.7,bright:1.8}[mode];
  glow(c,hx,hy-8,mode==='blue'?110:70,mode==='blue'?'rgba(120,180,255,0.4)':mode==='bruise'?'rgba(150,90,200,0.3)':mode==='dim'?'rgba(255,140,60,0.15)':'rgba(255,170,70,0.4)');
  for(let i=0;i<10;i++){ const a=i*0.628; ell(c,hx+Math.cos(a)*17,hy+Math.sin(a)*5,5,3.5,'#5d6068'); }
  rect(c,hx-12,hy-4,24,5,'#4a3018'); flare(c,hx,hy-3,sz,t,col);
  /* the town, watching one flame */
  const lc=o.crowd===undefined?12:o.crowd;
  for(let i=0;i<lc;i++){ const a=Math.PI*(0.1+0.8*(i/(Math.max(1,lc-1)))), rr=34+(i%3)*10, x=hx+Math.cos(a+Math.PI)*rr*1.7, y=hy+14+Math.sin(a)*rr*0.35+(i%2)*3;
    mini(c,x,y,REDS[i%6],x<hx?'right':'left',1.5,Math.abs(Math.sin(t*1.6+i))*-0.3); }
  /* five fires on the palisade */
  if(o.fire){ for(let i=0;i<5;i++){ const x=30+i*65, k=ez((t-i*0.8)/1.5); if(k<=0) continue; glow(c,x,112,40,'rgba(255,120,40,'+(0.35*k).toFixed(2)+')'); flare(c,x,126,1.3*k,t+i); for(let j=0;j<4;j++){ const tt=(t*0.4+j*0.25+i*0.1)%1; ell(c,x+Math.sin(t+j+i)*5,100-tt*40,3+tt*5,2+tt*3,'rgba(40,36,40,'+(0.4*(1-tt)).toFixed(2)+')'); } } }
  /* a door in the ground, south of the wall */
  if(o.hatch){ const p=0.7+0.3*Math.sin(t*3); rect(c,52,166,24,9,'#2a2018'); rect(c,54,168,20,5,'#4a3828'); glow(c,64,168,26,'rgba(255,214,140,'+(0.35*p).toFixed(2)+')'); rect(c,62,166,4,2,'rgba(255,230,160,'+p.toFixed(2)+')'); }
  vg(c,0.5);
};

/* ---------- QUACKENHOLD AND THE CROWN ---------- */
SCENES.s17castle=function(c,t){
  const o=opt(), tm=o.time||'night';
  const P={day:['#5f9bdc','#f7d083'],dusk:['#3b2a6b','#f0a56b'],night:['#070b1e','#1a1f40']}[tm];
  sky(c,P[0],P[1],22);
  if(tm==='night'){ twinkle(c,t,60,90); moon(c,52,30,9,P[0]); } else if(tm==='dusk'){ circ(c,60,110,22,'rgba(255,214,150,0.3)'); circ(c,60,110,12,'#ffe2a0'); } else { for(let i=0;i<3;i++){ const x=((t*6+i*120)%420)-50; ell(c,x,28+i*14,26,7,'rgba(255,255,255,0.85)'); } }
  ridge(c,118,tm==='night'?'#1c2a3a':'#6a8a6a',6,0.03,0); ridge(c,134,tm==='night'?'#142418':'#4f8a50',5,0.045,2);
  const base=140, s=1.2, wall=tm==='night'?'#565c78':'#d8d2c0';
  castle(c,160,base,s,wall,'#3a5f9c',t,'#e0b84a');
  /* windows */
  const W=[[-28,-30],[-14,-30],[0,-30],[14,-30],[28,-30],[-24,-16],[-8,-16],[8,-16],[24,-16],[0,-62],[-6,-76],[6,-76],[-42,-52],[-42,-34],[42,-52],[42,-34]];
  W.forEach((w,i)=>{ const x=160+w[0]*s, y=base+w[1]*s;
    if(o.windows==='dark'){ rect(c,x-2,y-3,4,6,'#1c1e2c'); }
    else { const f=0.8+0.2*Math.sin(t*3+i); rect(c,x-2,y-3,4,6,'rgba(255,214,120,'+f.toFixed(2)+')');
      if(o.silent) { rect(c,x-1.2,y,2.4,3,'rgba(30,24,40,0.85)'); circ(c,x,y-0.5,1.2,'rgba(30,24,40,0.85)'); } } });
  if(o.crystal){ const p=0.6+0.4*Math.sin(t*2.4); glow(c,160,base-128*s+20,50,'rgba(120,170,255,'+(0.45*p).toFixed(2)+')'); circ(c,160,base-125*s+20,3,'#cfe6ff'); }
  c.fillStyle='#4f8a50'; c.fillRect(0,base,LW,LH-base);
  c.fillStyle='#8a8478'; c.beginPath(); c.moveTo(150,LH); c.lineTo(168,LH); c.lineTo(164,base); c.lineTo(156,base); c.fill();
  /* the march out of the gate */
  if(o.march){
    for(let i=0;i<14;i++){ const p=((t*0.09+i*0.075)%1), x=150+p*190, y=base+4+p*28+(i%3)*3;
      mini(c,x,y,BLUES[i%4],'right',0.8+p*1.1,-Math.abs(Math.sin(t*7+i))*1.4); rect(c,x+1,y-24*(0.8+p*1.1)/1.5,1.2,16*(0.8+p*1.1)/1.5,'#6b4a2f'); }
    rect(c,236,base-60,1.5,60,'#6b4a2f'); c.fillStyle='#3a5f9c'; c.beginPath(); c.moveTo(237,base-60); c.lineTo(255+Math.sin(t*4)*2,base-54); c.lineTo(237,base-46); c.fill();
  }
  /* the night watch / guards at the gate */
  const gn=o.guards===undefined?2:o.guards;
  for(let i=0;i<gn;i++) staticDuck(c,i?176:144,base+16,'down',BLUE,1.1,{head:'helm'});
  vg(c,0.45);
  if(o.door){ const p=0.6+0.4*Math.sin(t*3); glow(c,160,base+8,30,'rgba(255,214,140,'+(0.4*p).toFixed(2)+')'); }
};

/* ---------- ROOMS: the black door, the dinner table, the court, the barracks ---------- */
SCENES.s17hall=function(c,t){
  const o=opt(), mode=o.mode||'throne';
  if(mode==='throne'||mode==='dinner'){
    c.fillStyle='#0b0a14'; c.fillRect(0,0,LW,LH);
    /* floor in perspective */
    c.fillStyle='#17142a'; c.beginPath(); c.moveTo(0,LH); c.lineTo(110,98); c.lineTo(210,98); c.lineTo(LW,LH); c.fill();
    c.strokeStyle='rgba(120,110,170,0.2)'; c.lineWidth=1; for(let i=-6;i<=6;i++){ c.beginPath(); c.moveTo(160+i*10,98); c.lineTo(160+i*52,LH); c.stroke(); }
    for(let j=0;j<6;j++){ const y=98+Math.pow(j/6,1.7)*82; c.beginPath(); c.moveTo(110-(y-98)*1.33,y); c.lineTo(210+(y-98)*1.33,y); c.stroke(); }
    /* columns and candles */
    for(let i=0;i<5;i++){ const k=i/4, y=98+k*70, w=3+k*7, x1=110-(y-98)*1.0-w, x2=210+(y-98)*1.0;
      rect(c,x1-w,28-k*18,w*1.6,y-28+k*18,'#242038'); rect(c,x2,28-k*18,w*1.6,y-28+k*18,'#242038');
      const f=0.75+0.25*Math.sin(t*6+i*2); glow(c,x1+w*1.5+2,y-14-k*4,16+k*14,'rgba(255,190,100,'+(0.22*f).toFixed(2)+')'); flare(c,x1+w*1.5+2,y-10-k*3,0.28+k*0.35,t+i); flare(c,x2-2,y-10-k*3,0.28+k*0.35,t+i+1); }
  }
  if(mode==='throne'){
    rect(c,128,38,64,62,'#05040a'); rect(c,128,36,64,3,'#3a3350'); rect(c,126,36,2,64,'#3a3350'); rect(c,192,36,2,64,'#3a3350');
    c.fillStyle='#0d0b16'; c.fillRect(131,41,58,59);
    const p=0.6+0.4*Math.sin(t*1.7);
    rect(c,159,41,2,59,'rgba(255,225,150,'+(0.5*p).toFixed(2)+')'); rect(c,131,98,58,2,'rgba(255,225,150,'+(0.6*p).toFixed(2)+')');
    glow(c,160,100,60,'rgba(255,214,140,'+(0.2*p).toFixed(2)+')');
    const wk=ez((t-1)/6); bobDuck(c,160+Math.sin(wk*0.5)*0,LH-14-wk*54,'up',t,meDuck(),1.8-wk*0.9);
  }
  if(mode==='dinner'){
    rect(c,100,100,120,6,'#2a1e18'); rect(c,100,106,120,14,'#3a2a22'); for(let i=0;i<5;i++) rect(c,108+i*24,106,3,26,'#2a1e18');
    for(const x of [128,192]){ ell(c,x,102,7,2,'#d8d0c0'); rect(c,x-2,94,4,6,'#e8e0d0'); }
    for(const x of [145,175]){ rect(c,x-1,92,2,9,'#e8dfc0'); flare(c,x,92,0.45,t); glow(c,x,88,22,'rgba(255,190,100,0.25)'); }
    /* the voice in the dark at the far end of the table */
    const bl=Math.sin(t*0.9)>0.9;
    c.fillStyle='rgba(8,6,16,0.97)'; c.beginPath(); c.moveTo(150,84); c.lineTo(170,84); c.lineTo(176,106); c.lineTo(144,106); c.fill(); c.beginPath(); c.arc(160,76,9,0,6.3); c.fill();
    if(!bl){ circ(c,157,75,0.9,'rgba(255,214,140,0.9)'); circ(c,163,75,0.9,'rgba(255,214,140,0.9)'); }
    staticDuck(c,160,LH-12,'up',meDuck(),1.9);
  }
  if(mode==='court'){
    c.fillStyle='#2a1c34'; c.fillRect(0,0,LW,LH); c.fillStyle='#3a2848'; c.fillRect(0,0,LW,90);
    for(let i=0;i<6;i++){ rect(c,i*56+6,12,22,70,'#2e2040'); rect(c,i*56+10,16,14,60,'#3a2850'); }
    c.fillStyle='#6a4a30'; c.fillRect(0,104,LW,10); c.fillStyle='#4a3020'; c.fillRect(0,114,LW,60);
    c.fillStyle='#2c1c14'; c.fillRect(0,128,LW,52);
    /* the war chest, open */
    rect(c,138,92,44,14,'#8a6a2a'); rect(c,138,88,44,5,'#a8842f'); const sp=0.7+0.3*Math.sin(t*4);
    for(let i=0;i<9;i++) circ(c,142+i*4.4,91+Math.sin(i)*1,2.2,'rgba(255,214,80,'+(0.6+0.4*sp).toFixed(2)+')');
    glow(c,160,88,30,'rgba(255,214,90,0.3)');
    const lc=['#6a3aa0','#a03a5a','#3a7a8a','#b08a2a','#4a5aa8','#8a4a2a'];
    for(let i=0;i<6;i++){ const x=40+i*48, lean=Math.sin(t*0.8+i)*2; mini(c,x,126+(i%2)*6,lc[i],i<3?'right':'left',2,0); if(i%2===0) rect(c,x+lean,98,12,3,'#f6e19a'); }
    mini(c,160,116,'#2a2438','down',2.1,0,'#e0b84a');
  }
  if(mode==='barracks'){
    c.fillStyle='#241c18'; c.fillRect(0,0,LW,LH); c.fillStyle='#3a2c24'; c.fillRect(0,0,LW,96);
    for(let x=0;x<LW;x+=22) rect(c,x,0,1,96,'rgba(0,0,0,0.25)');
    c.fillStyle='#2a1e18'; c.fillRect(0,126,LW,54);
    rect(c,236,48,40,50,'#1a1410'); rect(c,240,52,32,42,'#4a6fb5'); c.fillStyle='#e0b84a'; c.fillRect(244,56,24,2);
    rect(c,60,60,36,34,'#2a2018'); rect(c,64,64,28,26,'#8a8f99');
    rect(c,100,108,120,8,'#4a3424'); rect(c,106,116,6,22,'#3a281c'); rect(c,208,116,6,22,'#3a281c');
    /* the lamp and the folded page with its seal */
    const f=0.75+0.25*Math.sin(t*6); rect(c,126,96,6,12,'#6a5a3a'); flare(c,129,96,0.5,t); glow(c,129,92,60,'rgba(255,190,100,'+(0.3*f).toFixed(2)+')');
    c.save(); c.translate(168,106); c.rotate(-0.06); rect(c,-16,-4,32,6,'#e8e0c8'); rect(c,-14,-3,22,1,'#9a8a6a'); rect(c,-14,-1,18,1,'#9a8a6a'); c.restore();
    const sp=0.6+0.4*Math.sin(t*2.4); glow(c,176,104,12,'rgba(220,60,50,'+(0.6*sp).toFixed(2)+')'); circ(c,176,104,3.2,'#c0392b');
    staticDuck(c,150,150,'right',BLUE,2.2,{head:'helm'}); staticDuck(c,236,150,'left',meDuck(),1.9);
  }
  vg(c,0.55);
};

/* ---------- THE LETTER (chapter 5, Crown route) ---------- */
SCENES.s17letter=function(c,t){
  sky(c,'#d8a070','#f6d8a8',16);
  c.fillStyle='#a8784a'; c.fillRect(0,100,LW,80);
  /* the window's morning */
  rect(c,214,20,70,58,'#5a3a22'); rect(c,218,24,62,50,'#9fd0f0'); rect(c,248,24,2,50,'#5a3a22'); rect(c,218,48,62,2,'#5a3a22'); circ(c,262,40,9,'#fff6c0');
  glow(c,250,70,90,'rgba(255,240,190,0.3)');
  /* bed and pillow */
  rect(c,0,108,LW,72,'#d8c8b0'); rect(c,0,108,LW,6,'#bfae92');
  ell(c,150,134,86,28,'#f4eee0'); ell(c,150,134,86,28,'rgba(0,0,0,0.04)'); ell(c,150,128,80,22,'#fffaf0');
  /* the letter, floating a little as the light moves */
  const b=Math.sin(t*1.2)*1.2;
  c.save(); c.translate(150,128+b); c.rotate(-0.08); rect(c,-34,-20,68,40,'#f6efe0'); rect(c,-34,-20,68,2,'#e3d9c3');
  for(let i=0;i<4;i++) rect(c,-24,-10+i*7,36,1,'#a89878');
  const sp=0.75+0.25*Math.sin(t*2); glow(c,18,8,22,'rgba(70,110,220,'+(0.5*sp).toFixed(2)+')'); circ(c,18,8,7,'#2d5cc4'); circ(c,18,8,4.6,'#4a7ae0'); rect(c,15,5.5,6,1.4,'#cfe0ff'); rect(c,17.3,4,1.4,8,'#cfe0ff');
  c.restore();
  /* the sleeper's hand */
  rect(c,200,140,48,10,'#e8d8c0'); circ(c,244,146,7,'#ffd84a');
  for(let i=0;i<12;i++){ const tt=(t*0.15+i*0.083)%1; c.fillStyle='rgba(255,255,230,'+(0.5*(1-tt)).toFixed(2)+')'; c.fillRect(220+Math.sin(tt*6+i)*40,80+tt*70,1.4,1.4); }
  vg(c,0.25);
};

/* ---------- THE TENT ON THE WATCHTOWER HILLS: the summit (chapter 12) ---------- */
SCENES.s17tent=function(c,t){
  const o=opt(), part=o.mode==='part';
  sky(c,'#8a93a8','#d6d8d0',20);
  for(let i=0;i<3;i++){ const x=((t*4+i*140)%440)-60; ell(c,x,26+i*14,30,7,'rgba(255,255,255,0.5)'); }
  ridge(c,108,'#6f7f8a',8,0.03,1); ridge(c,126,'#5f7f5a',6,0.04,4); ridge(c,146,'#6a8a5a',4,0.05,0);
  c.fillStyle='#b0a07a'; c.beginPath(); c.moveTo(138,LH); c.lineTo(182,LH); c.lineTo(166,120); c.lineTo(154,120); c.fill();
  /* the tent */
  c.fillStyle='#e8e0cc'; c.beginPath(); c.moveTo(118,134); c.lineTo(160,88); c.lineTo(202,134); c.closePath(); c.fill();
  c.fillStyle='rgba(0,0,0,0.12)'; c.beginPath(); c.moveTo(160,88); c.lineTo(202,134); c.lineTo(160,134); c.closePath(); c.fill();
  c.fillStyle='#2a2018'; c.beginPath(); c.moveTo(150,134); c.lineTo(160,108); c.lineTo(170,134); c.closePath(); c.fill();
  rect(c,159,76,1.5,14,'#6b4a2f'); c.fillStyle='#e0b84a'; c.beginPath(); c.moveTo(160,76); c.lineTo(172+Math.sin(t*4)*2,80); c.lineTo(160,84); c.fill();
  const p=part?ez((t-1.5)/8):0;
  /* the Hollow on the left, the Crown on the right */
  const g1=part?-p*120:0, g2=part?p*120:0;
  for(let i=0;i<6;i++){ const x=34+i*14+g1, y=146+(i%3)*5; mini(c,x,y,REDS[i%6],part?'left':'right',1.7,-Math.abs(Math.sin(t*(part?6:0.5)+i))*(part?1.2:0.2)); }
  for(let i=0;i<6;i++){ const x=286-i*14+g2, y=146+(i%3)*5; mini(c,x,y,BLUES[i%4],part?'right':'left',1.7,-Math.abs(Math.sin(t*(part?6:0.5)+i))*(part?1.2:0.2)); }
  rect(c,22+g1,86,1.5,60,'#6b4a2f'); c.fillStyle='#c0392b'; c.beginPath(); c.moveTo(23.5+g1,86); c.lineTo(42+g1+Math.sin(t*4)*2,92); c.lineTo(23.5+g1,100); c.fill();
  rect(c,298+g2,86,1.5,60,'#6b4a2f'); c.fillStyle='#3a5f9c'; c.beginPath(); c.moveTo(298+g2,86); c.lineTo(280+g2+Math.sin(t*4)*2,92); c.lineTo(298+g2,100); c.fill();
  /* you in the middle of the road */
  if(!part) staticDuck(c,160,164,'up',meDuck(),1.7);
  if(part&&p>0.6){ c.fillStyle='rgba(20,22,40,'+((p-0.6)*0.9).toFixed(2)+')'; c.fillRect(0,0,LW,LH); }
  vg(c,0.4);
};

/* ---------- THE HILLS: watchtower and watch-fires ---------- */
SCENES.s17hills=function(c,t){
  const o=opt(), dusk=o.time!=='night';
  sky(c,dusk?'#2a2060':'#070b1e',dusk?'#e8905a':'#1a1f40',22);
  if(!dusk) twinkle(c,t,50,80); else { circ(c,70,118,24,'rgba(255,200,130,0.3)'); circ(c,70,118,12,'#ffd9a0'); }
  ridge(c,100,'#2a2a52',10,0.025,1); ridge(c,120,'#1e2a3a',8,0.035,3); ridge(c,142,'#142418',6,0.045,0);
  if(o.tower){
    c.fillStyle='#4a4650'; c.fillRect(226,62,30,86); for(let i=0;i<4;i++) c.fillRect(224+i*9,56,6,8); c.fillStyle='#37343e'; c.fillRect(234,76,12,16); rect(c,232,112,16,36,'#2c2a34');
    rect(c,238,78,4,10,'rgba(20,16,10,0.9)');
    const k=ez(t/4); flare(c,206,150,1.0*k,t); glow(c,206,140,60,'rgba(255,170,70,'+(0.35*k).toFixed(2)+')');
    staticDuck(c,190,154,'right',REDDUCK,1.6,{head:'hood'});
    bobDuck(c,60+ez(t/9)*92,160,'right',t,meDuck(),1.5);
  }
  if(o.fires){
    const n=o.fires;
    for(let i=0;i<n;i++){ const x=30+i*(LW-60)/(n-1), y=138-Math.sin(i*1.3)*8, lit=t>1.2+i*1.1, k=lit?ez((t-1.2-i*1.1)/0.8):0;
      rect(c,x-6,y,12,3,'#3a281c'); rect(c,x-1,y-6,2,6,'#3a281c');
      if(k>0){ glow(c,x,y-8,60*k+10,'rgba(255,160,60,'+(0.45*k).toFixed(2)+')'); flare(c,x,y,1.0*k,t+i); }
      mini(c,x+14,y+14,BLUES[i%4],'left',1.1,0); }
    const cx=30+ez(t/9)*30; staticDuck(c,cx,172,'right',meDuck(),1.4); circ(c,cx+9,160,6,'rgba(255,214,130,0.25)'); rect(c,cx+7,157,4,5,'#e0b84a');
  }
  vg(c,0.4);
};

/* ---------- THE HERMIT'S TABLE ---------- */
SCENES.s17table=function(c,t){
  const o=opt();
  c.fillStyle='#2c2018'; c.fillRect(0,0,LW,LH); c.fillStyle='#3a2a1e'; c.fillRect(0,0,LW,104);
  for(let x=0;x<LW;x+=18) rect(c,x,0,1,104,'rgba(0,0,0,0.25)');
  c.fillStyle='#241a14'; c.fillRect(0,112,LW,68);
  /* window with weather outside */
  rect(c,206,26,66,50,'#1a120c'); rect(c,210,30,58,42,o.dawn?'#f0b080':'#0e1430'); if(!o.dawn){ twinkle(c,t,18,40); } rect(c,238,30,2,42,'#1a120c'); rect(c,210,50,58,2,'#1a120c');
  /* hearth */
  rect(c,24,56,48,56,'#4a4048'); rect(c,32,70,32,42,'#12090a'); flare(c,48,112,1.2,t); glow(c,48,100,80,'rgba(255,170,70,0.3)');
  rect(c,38,64,20,2,'#8a8f98'); rect(c,44,60,8,4,'#6a6f78');
  /* the kettle */
  rect(c,38,92,20,2,'#2a2a2a'); ell(c,48,88,8,6,'#7d8896'); rect(c,54,84,8,2,'#7d8896');
  for(let i=0;i<4;i++){ const tt=(t*0.5+i*0.25)%1; ell(c,50+Math.sin(tt*5+i)*3,82-tt*26,2+tt*3,2+tt*2,'rgba(230,230,235,'+(0.5*(1-tt)).toFixed(2)+')'); }
  /* table and chairs */
  rect(c,96,120,128,8,'#6a4a30'); rect(c,96,128,128,3,'#4a3020'); rect(c,104,131,5,26,'#4a3020'); rect(c,211,131,5,26,'#4a3020');
  rect(c,76,118,12,40,'#5a3d24'); rect(c,76,134,18,5,'#6a4a30'); rect(c,232,118,12,40,'#5a3d24'); rect(c,226,134,18,5,'#6a4a30');
  const third=o.third!==false; if(third){ rect(c,148,140,24,4,'#5a3d24'); rect(c,150,144,3,14,'#4a3020'); rect(c,167,144,3,14,'#4a3020'); rect(c,148,126,24,3,'#7a5d44'); }
  const cups=o.cups||0;
  for(let i=0;i<cups;i++){ const x=128+i*32; rect(c,x-4,112,8,8,'#e8e0d0'); rect(c,x+4,114,3,4,'#e8e0d0'); for(let j=0;j<2;j++){ const tt=(t*0.6+j*0.5+i*0.2)%1; c.fillStyle='rgba(235,235,240,'+(0.5*(1-tt)).toFixed(2)+')'; c.fillRect(x-1+Math.sin(tt*6+i)*2,108-tt*16,1.6,3); } }
  if(o.book){ c.save(); c.translate(160,119); rect(c,-20,-3,20,4,'#e8e0c8'); rect(c,0,-3,20,4,'#f0e8d4'); rect(c,-20,-4,40,1,'#8a2a2a'); for(let i=0;i<3;i++){ rect(c,-17,-2.5+i*0.8,14,0.4,'#9a8a6a'); rect(c,3,-2.5+i*0.8,14,0.4,'#9a8a6a'); } c.strokeStyle='#f6f1e6'; c.lineWidth=1; c.beginPath(); c.moveTo(14,-3); c.lineTo(24,-18+Math.sin(t*2)); c.stroke(); c.restore(); }
  if(o.items){ const its=[['#e0b84a',128],['#8f7ac9',160],['#8a8f98',190]]; its.forEach((it,i)=>{ const k=ez((t-1-i*1.2)/0.8); if(k>0){ circ(c,it[1],118-k*0+0,3*k,it[0]); } }); }
  staticDuck(c,76,150,'right',{body:'#b5322a',wing:'#8a2620',bill:'#ff9d2e'},2.0,{head:'hood'});
  if(o.guests){ const k=ez(t/8); bobDuck(c,330-k*100,168,'left',t,BLUE,1.7,{head:'helm'}); bobDuck(c,356-k*100,168,'left',t+1,REDDUCK,1.7); }
  staticDuck(c,246,152,'left',meDuck(),1.9);
  vg(c,0.5);
};

/* ---------- THE BURNT WOOD ---------- */
function oldTree(c,x,y,s,t,leafy){
  rect(c,x-9*s,y-60*s,18*s,60*s,'#1c1a1e'); rect(c,x-14*s,y-8*s,28*s,8*s,'#1c1a1e'); rect(c,x-20*s,y-2*s,40*s,4*s,'#1c1a1e');
  c.strokeStyle='#1c1a1e'; c.lineWidth=3*s;
  for(let i=0;i<5;i++){ const a=-Math.PI/2+(i-2)*0.55, L=(34+(i%2)*10)*s; c.beginPath(); c.moveTo(x,y-56*s); c.lineTo(x+Math.cos(a)*L,y-56*s+Math.sin(a)*L); c.stroke(); }
  c.fillStyle='#000'; c.beginPath(); c.ellipse(x,y-22*s,5*s,9*s,0,0,6.3); c.fill();
  const p=0.6+0.4*Math.sin(t*2); glow(c,x,y-22*s,24*s,'rgba(255,214,150,'+(0.22*p).toFixed(2)+')');
  if(leafy){ for(let i=0;i<9;i++){ const a=-Math.PI/2+(i-4)*0.35, L=(30+(i%3)*8)*s; circ(c,x+Math.cos(a)*L,y-56*s+Math.sin(a)*L,3*s,'#4f9a4a'); } }
}
SCENES.s17wood=function(c,t){
  const o=opt(), mode=o.mode||'trees';
  c.save();
  if(mode==='break'){ const k=Math.min(1,t/3); c.translate((Math.random()-0.5)*5*k,(Math.random()-0.5)*5*k); }
  if(mode==='shrine'){
    sky(c,'#14243a','#2e4a3a',20); twinkle(c,t,40,70); pineRow(c,110,'#0e2418',46,0,26); pineRow(c,124,'#0a1c12',56,-9,32);
    c.fillStyle='#17331f'; c.fillRect(0,128,LW,52);
    rect(c,128,94,64,40,'#6f757c'); rect(c,124,90,72,6,'#5d636a'); rect(c,142,104,36,30,'#14181c');
    const f=0.7+0.3*Math.sin(t*5); glow(c,160,114,50,'rgba(255,190,100,'+(0.4*f).toFixed(2)+')'); rect(c,156,108,8,12,'#f2b84b'); rect(c,158,110,4,8,'#fff1b0'); rect(c,157,105,6,3,'#4a4a4a');
    for(let i=0;i<16;i++){ const fx=(i*61+t*6*(1+(i%3)*0.2))%LW, fy=100+((i*37)%50)+Math.sin(t*1.3+i)*6, a=0.4+0.6*Math.abs(Math.sin(t*2+i)); circ(c,fx,fy,3,'rgba(255,240,150,'+(0.18*a).toFixed(2)+')'); c.fillStyle='rgba(255,250,200,'+a.toFixed(2)+')'; c.fillRect(fx,fy,1.4,1.4); }
    const k=ez(t/6); bobDuck(c,-10+k*140,152,'right',t,meDuck(),1.8);
    c.restore(); vg(c,0.5); return;
  }
  sky(c,'#35353d','#6c6872',20);
  for(let i=0;i<30;i++){ const x=(i*43+t*3)%LW, y=(i*29)%100; c.fillStyle='rgba(200,196,205,0.25)'; c.fillRect(x,y,1.5,1.5); }
  ridge(c,100,'#4a4750',6,0.03,1);
  c.fillStyle='#55525a'; c.fillRect(0,126,LW,54); ridge(c,124,'#4a474f',3,0.07,0);
  const trees=(y,col,h,gap,off,w)=>{ for(let x=-gap+off;x<LW+gap;x+=gap){ const hh=h+rn(x+y)*h*0.5; rect(c,x,y-hh,w,hh,col); c.strokeStyle=col; c.lineWidth=Math.max(1,w*0.4); c.beginPath(); c.moveTo(x+w/2,y-hh*0.7); c.lineTo(x+w/2-8,y-hh*0.95); c.moveTo(x+w/2,y-hh*0.55); c.lineTo(x+w/2+9,y-hh*0.8); c.stroke(); } };
  trees(112,'#2a282e',40,22,3,3); trees(128,'#1c1a20',56,30,-6,5);
  const hum=['clearing','break','wake','name','tree'].includes(mode);
  const tx=160, ty=146;
  if(mode==='edge'){
    /* the line at the gate */
    const red=o.line==='red', n=7;
    for(let i=0;i<n;i++){ const x=70+i*30, y=152+(i%2)*3; if(red){ mini(c,x,y,REDS[i%6],'down',1.9,0); } else { mini(c,x,y,BLUES[i%4],'down',1.9,0); } rect(c,x+5,y-36,1.6,36,'#6b4a2f'); c.fillStyle='#c3ccd6'; c.beginPath(); c.moveTo(x+4,y-36); c.lineTo(x+5.8,y-43); c.lineTo(x+7.6,y-36); c.fill(); }
    if(red){ rect(c,158,104,2,44,'#6b4a2f'); flare(c,159,106,0.9,t); glow(c,159,98,50,'rgba(255,160,60,0.35)'); staticDuck(c,160,168,'down',{body:'#a82a2a',wing:'#7f1f1f',bill:'#d9902a'},2.3,{head:'helm'}); }
    else { staticDuck(c,160,166,'down',BLUE,2.3,{head:'helm'}); rect(c,176,118,1.8,48,'#6b4a2f'); c.fillStyle='#3a5f9c'; c.beginPath(); c.moveTo(177,118); c.lineTo(196+Math.sin(t*4)*2,124); c.lineTo(177,132); c.fill(); }
    if(o.player) staticDuck(c,52,170,'right',meDuck(),1.6);
  } else {
    oldTree(c,tx,ty,mode==='tree'?1.1:1.0,t,false);
    if(hum){ for(let i=0;i<4;i++){ const k=((t*(mode==='break'?0.9:0.35)+i*0.25)%1); c.strokeStyle='rgba(200,190,230,'+(0.4*(1-k)).toFixed(2)+')'; c.lineWidth=1; c.beginPath(); c.ellipse(tx,ty-20,10+k*180,4+k*54,0,0,6.3); c.stroke(); } }
    if(mode==='tree'){ staticDuck(c,tx-48,170,'right',meDuck(),1.6); }
    if(mode==='clearing'||mode==='break'||mode==='wake'){
      const n=o.sleepers||24, awake=mode==='wake';
      for(let i=0;i<n;i++){ const a=(i/n)*Math.PI*2, rx=118, ry=26, x=tx+Math.cos(a)*(rx*(0.55+0.45*rn(i))), y=ty+8+Math.sin(a)*ry*(0.6+0.4*rn(i+9));
        if(Math.sin(a)<-0.3&&Math.abs(Math.cos(a))<0.25) continue;
        const k=awake?ez((t-0.8-rn(i+3)*7)/1.4):0, br=0.6+0.4*Math.sin(t*(mode==='break'?5:1.3)+(awake?i:0));
        const col=REDS[i%6];
        if(k>0.02){ ell(c,x,y+1,5,1.6,'rgba(0,0,0,0.3)'); ell(c,x,y-3-k*5,4,3.5+k*4,col); circ(c,x+2,y-8-k*6,2.4,col); rect(c,x+3.6,y-8.4-k*6,2.4,1,'#ff9d2e'); }
        else { ell(c,x,y,6,2.8,col); circ(c,x+4,y-1.6,2,col); }
        const lc=awake?'rgba(255,225,150,':'rgba(170,200,255,'; circ(c,x-1,y-2,4+br*2,lc+(0.25*br+0.1).toFixed(2)+')'); circ(c,x-1,y-2,1.3,lc+'0.95)');
      }
    }
    if(mode==='break'){
      for(let i=0;i<60;i++){ const x=(i*37)%LW, y=LH-((t*34+i*17)%LH); c.fillStyle='rgba(190,186,196,'+(0.15+0.4*rn(i)).toFixed(2)+')'; c.fillRect(x,y,1.8,1.8); }
      const fl=Math.max(0,1-t/1.2); if(fl>0){ c.fillStyle='rgba(200,220,255,'+(fl*0.7).toFixed(2)+')'; c.fillRect(0,0,LW,LH); }
    }
    if(mode==='name'){
      /* the old king on a litter, the hermit beside him, and everyone who walked here */
      rect(c,124,138,48,5,'#6a4a30'); rect(c,128,143,3,10,'#4a3020'); rect(c,165,143,3,10,'#4a3020');
      ell(c,146,134,17,5,'#f4f4ee'); circ(c,160,131,5,'#f4f4ee'); rect(c,164,131,5,1.8,'#ff9d2e'); circ(c,159,130,0.9,'#222');
      staticDuck(c,112,152,'right',{body:'#b5322a',wing:'#8a2620',bill:'#ff9d2e'},1.9,{head:'hood'});
      const cols=[REDS,BLUES,['#8a8f99','#a0a5af','#7a7f88']];
      for(let i=0;i<15;i++){ const a=Math.PI*(0.12+0.76*(i/14)), x=tx+Math.cos(a+Math.PI)*104*1.15, y=150+Math.sin(a)*34; const grp=cols[i%3]; mini(c,x,y,grp[i%grp.length],'right',1.5,0); }
      for(let i=0;i<4;i++){ const x=tx+104+i*8, y=156+(i%2)*6; mini(c,x,y,cols[i%3][0],'left',1.5,0); }
    }
    if(mode==='trees'||mode==='tree'){ for(let i=0;i<5;i++){ const a=t*0.4+i*1.3, bx=40+((a*40)%240), by=22+i*9+Math.sin(a*2)*3; c.strokeStyle='#15131a'; c.lineWidth=1; c.beginPath(); c.moveTo(bx-3,by+Math.sin(t*10+i)); c.lineTo(bx,by); c.lineTo(bx+3,by+Math.sin(t*10+i)); c.stroke(); } }
    if(mode==='trees'){ const k=ez(t/8); bobDuck(c,-10+k*150,168,'right',t,meDuck(),1.7); }
  }
  c.restore();
  vg(c,0.5);
};

/* ---------- THE ASH ROAD (chapter 16.5) ---------- */
SCENES.s17ash=function(c,t){
  sky(c,'#4a4854','#9a96a0',20);
  for(let i=0;i<40;i++){ const x=(i*43+t*8)%LW, y=(t*10+i*31)%LH; c.fillStyle='rgba(210,206,216,0.35)'; c.fillRect(x,y,1.6,1.6); }
  ridge(c,92,'#6a6874',9,0.03,0); ridge(c,112,'#5a5862',7,0.04,2); ridge(c,132,'#4a4850',5,0.06,1);
  /* the beacon on the ridge */
  rect(c,252,74,10,30,'#3a3840'); rect(c,248,70,18,5,'#2a2830'); const k=ez((t-3)/3); if(k>0){ glow(c,257,66,50,'rgba(255,170,70,'+(0.45*k).toFixed(2)+')'); flare(c,257,70,0.9*k,t); }
  /* standing stones */
  for(let i=0;i<5;i++){ const x=40+i*22, h=18+rn(i)*10; c.fillStyle='#2e2c34'; c.beginPath(); c.moveTo(x,128); c.lineTo(x+1,128-h); c.lineTo(x+7,128-h+3); c.lineTo(x+8,128); c.fill(); }
  c.fillStyle='#3e3c44'; c.beginPath(); c.moveTo(-10,LH); c.lineTo(-10,160); c.quadraticCurveTo(100,150,200,126); c.lineTo(214,126); c.quadraticCurveTo(130,160,80,LH); c.fill();
  /* the walkers: a single tall duck and a very small hermit-shaped one behind */
  const p=ez(t/(o2()||10)); bobDuck(c,-10+p*190,156-p*14,'right',t,meDuck(),1.7-p*0.5);
  vg(c,0.5);
  function o2(){ return opt().dur||10; }
};

/* ---------- GREEN (chapter 23) ---------- */
SCENES.s17grow=function(c,t){
  sky(c,'#7a7a88','#d8d4cc',20);
  for(let i=0;i<3;i++){ const x=((t*3+i*150)%440)-60; ell(c,x,24+i*14,32,7,'rgba(255,255,255,0.35)'); }
  ridge(c,100,'#6a6874',8,0.03,1); ridge(c,118,'#5a6a5a',6,0.04,3);
  oldTree(c,160,128,0.8,t,true);
  c.fillStyle='#6e6a70'; c.fillRect(0,128,LW,52);
  const patches=[[58,152],[160,166],[262,152]];
  patches.forEach((p,i)=>{
    ell(c,p[0],p[1],26,6,'#4a3a2c');
    const k=ez((t-2-i*2.5)/4);
    if(k>0){ for(let j=0;j<5;j++){ const x=p[0]-14+j*7, h=(4+rn(i*5+j)*7)*k; rect(c,x,p[1]-h,1.4,h,'#4a9a48'); if(k>0.7){ circ(c,x+0.7,p[1]-h,2.4*Math.min(1,(k-0.7)*3.3),['#ff9d2e','#ffd166','#ff7a2a'][j%3]); glow(c,x,p[1]-h,10,'rgba(255,170,70,0.25)'); } } }
  });
  /* Poppy and her trowel */
  const px=70+Math.sin(t*0.5)*4; staticDuck(c,px,166,'right',{body:'#e0603f',wing:'#b24a30',bill:'#e6c441'},1.5,{head:'bow'}); rect(c,px+12,160,1.6,8,'#8a6a4a'); rect(c,px+11,167,4,2,'#9aa0a8');
  vg(c,0.3);
};

/* ---------- THE FIRST LANTERN OF THE LANTERN ROAD (chapter 24) ---------- */
SCENES.s17lanterns=function(c,t){
  sky(c,'#2a2060','#f0a56b',22);
  circ(c,260,110,22,'rgba(255,200,130,0.3)'); circ(c,260,110,11,'#ffd9a0');
  ridge(c,104,'#2a2a52',9,0.03,1); ridge(c,124,'#1e2a3a',7,0.04,3);
  oldTree(c,92,136,0.95,t,true);
  c.fillStyle='#1a2a22'; c.fillRect(0,136,LW,44);
  c.fillStyle='#4a4030'; c.beginPath(); c.moveTo(124,LH); c.lineTo(170,LH); c.quadraticCurveTo(200,150,300,128); c.lineTo(310,128); c.quadraticCurveTo(212,160,170,LH); c.fill();
  /* lanterns light one by one, outward from the Tree */
  for(let i=0;i<8;i++){ const k=i/7, x=122+k*180, y=170-k*38; const lit=ez((t-2.5-i*0.9)/0.6); rect(c,x,y-12,1.4,12,'#3a2a1a'); if(lit>0){ glow(c,x,y-14,22*lit+4,'rgba(255,200,110,'+(0.5*lit).toFixed(2)+')'); circ(c,x,y-14,2.2,'rgba(255,235,170,'+lit.toFixed(2)+')'); } else circ(c,x,y-14,2,'#3a3a44'); }
  /* everyone, standing near each other */
  const cols=[REDS,BLUES,['#8a8f99','#a0a5af','#7a7f88']];
  for(let i=0;i<18;i++){ const x=118+((i%9)*17)+(i>8?8:0)+(rn(i)*4), y=150+(i>8?10:0), grp=cols[i%3]; mini(c,x,y,grp[i%grp.length],'right',1.45,Math.abs(Math.sin(t*1.3+i))*-0.3); }
  const lx=108; staticDuck(c,lx,160,'right',{body:'#e0603f',wing:'#b24a30',bill:'#e6c441'},1.4,{head:'bow'});
  const k0=ez((t-0.8)/1.2); glow(c,lx+9,148,16+k0*20,'rgba(255,200,110,'+(0.5*k0).toFixed(2)+')'); rect(c,lx+7,146,4,6,'#f2b84b'); rect(c,lx+8,147,2,4,'rgba(255,241,176,'+(0.4+0.6*k0).toFixed(2)+')');
  for(let i=0;i<14;i++){ const tt=(t*0.12+i*0.07)%1; c.fillStyle='rgba(255,230,160,'+(0.6*(1-tt)).toFixed(2)+')'; c.fillRect(100+i*14+Math.sin(tt*6+i)*6,150-tt*110,1.4,1.4); }
  vg(c,0.35);
};

/* ---------- THE NIGHT ON THE WALL: the dream of the siege (chapter 11) ---------- */
SCENES.s17siege=function(c,t){
  sky(c,'#0a0e2a','#2a2a58',22); twinkle(c,t,60,90);
  moon(c,268,30,10,'#0a0e2a');
  ridge(c,120,'#161a3a',6,0.03,1);
  /* the wall and its battlement, and the old king on it */
  c.fillStyle='#4a4e6a'; c.fillRect(0,76,206,104); for(let i=0;i<9;i++) c.fillRect(i*24,66,14,12);
  c.fillStyle='rgba(0,0,0,0.25)'; for(let y=88;y<LH;y+=12) c.fillRect(0,y,206,1);
  c.fillStyle='#2a2c44'; c.fillRect(70,120,52,60); c.beginPath(); c.arc(96,120,26,Math.PI,0); c.fill();
  for(let i=0;i<9;i++){ const x=8+i*22, a=0.5+0.5*Math.sin(t*1.5+i); c.fillStyle='rgba(30,30,50,'+(0.6+0.3*a).toFixed(2)+')'; c.beginPath(); c.moveTo(x,62); c.lineTo(x+1,52); c.lineTo(x+2,62); c.fill(); }
  staticDuck(c,132,66,'down',WHITE,1.7,{head:'royal'});
  /* the ground below: a very tired red duck, sitting, with his army sitting behind him */
  c.fillStyle='#232a3a'; c.fillRect(0,140,LW,40); c.fillStyle='#1c2230'; c.fillRect(206,100,114,80);
  for(let i=0;i<18;i++){ const x=214+(i%6)*16+(Math.floor(i/6)%2)*6, y=124+Math.floor(i/6)*14; mini(c,x,y,REDS[i%6],'left',1.3,0); }
  staticDuck(c,196,160,'left',{body:'#8a2a2a',wing:'#5a1a1a',bill:'#c9a24a'},2.2,{head:'helm'});
  /* the two words, as two birds of light */
  const w=ez((t-3)/5);
  if(t>3){
    const a1=t*1.4, a2=t*1.4+Math.PI;
    const x1=150+Math.cos(a1)*(60*(1-w)+8*w), y1=96+Math.sin(a1*1.3)*(26*(1-w))-w*10;
    const x2=150+Math.cos(a2)*(60*(1-w)+8*w), y2=96+Math.sin(a2*1.3)*(26*(1-w))-w*10;
    glow(c,x1,y1,26,'rgba(235,240,255,'+(0.5).toFixed(2)+')'); circ(c,x1,y1,3,'#f4f6ff');
    glow(c,x2,y2,26,'rgba(255,190,100,0.5)'); circ(c,x2,y2,3,'#ffd9a0');
    if(w>=1){ glow(c,150,86,60,'rgba(255,230,180,0.25)'); }
  }
  c.fillStyle='rgba(120,140,200,0.05)'; c.fillRect(0,0,LW,LH);
  vg(c,0.6);
};

/* ---------- THE HEARTH VAULT (chapter 9, Crown route) ---------- */
SCENES.s17vault=function(c,t){
  c.fillStyle='#2a0e0c'; c.fillRect(0,0,LW,LH);
  for(let r=0;r<10;r++) for(let x=-(r%2)*12;x<LW;x+=24){ c.fillStyle=((x/24+r)&1)?'#4a1a14':'#3c1410'; c.fillRect(x,r*10,22,8); }
  c.fillStyle='#1a0808'; c.beginPath(); c.arc(160,116,100,Math.PI,0); c.lineTo(260,LH); c.lineTo(60,LH); c.fill();
  c.fillStyle='#2a1410'; c.fillRect(0,128,LW,52);
  const p=0.75+0.25*Math.sin(t*3);
  glow(c,160,100,90,'rgba(255,150,50,'+(0.4*p).toFixed(2)+')');
  rect(c,138,122,44,10,'#2a2a30'); for(let i=0;i<8;i++) circ(c,144+i*5,122,2.4,'rgba(255,120,40,'+(0.6+0.4*Math.sin(t*5+i)).toFixed(2)+')');
  c.fillStyle='rgba(255,157,46,0.92)'; c.beginPath(); c.moveTo(148,122); c.lineTo(152,50); c.lineTo(160,40); c.lineTo(168,50); c.lineTo(172,122); c.closePath(); c.fill();
  c.fillStyle='rgba(255,230,170,0.5)'; c.fillRect(156,52,3,68);
  /* the blue twin, far away, leaning toward it */
  const k=ez((t-4)/3)*(0.5+0.5*Math.sin(t*1.5)*0.3);
  if(t>4){ c.save(); c.globalAlpha=0.35*Math.min(1,(t-4)/3); c.fillStyle='#8ab4ff'; c.beginPath(); c.moveTo(220,70); c.lineTo(224,20); c.lineTo(230,12); c.lineTo(236,20); c.lineTo(240,70); c.closePath(); c.fill(); c.restore(); glow(c,230,40,50,'rgba(120,170,255,'+(0.2*Math.min(1,(t-4)/3)).toFixed(2)+')'); }
  for(const x of [48,100,220,272]){ rect(c,x-1,70,2,10,'#4a3a2a'); flare(c,x,70,0.5,t+x); glow(c,x,64,22,'rgba(255,170,70,0.25)'); }
  staticDuck(c,92,152,'right',{body:'#b5322a',wing:'#8a2620',bill:'#ff9d2e'},1.7,{head:'wizard'});
  staticDuck(c,232,156,'left',meDuck(),1.9);
  vg(c,0.5);
};

/* ---------- THE HALL OF NAMES (chapter 16.5) ---------- */
SCENES.s17names=function(c,t){
  sky(c,'#1a2036','#4a5470',20); twinkle(c,t,40,70);
  ridge(c,112,'#2a3248',6,0.03,1);
  c.fillStyle='#8a94a8'; c.fillRect(0,128,LW,52); c.fillStyle='#a0aabc'; c.fillRect(0,128,LW,3);
  /* a ring of tumbled houses */
  for(let i=0;i<7;i++){ const x=10+i*50, h=18+rn(i)*22, w=26+rn(i+4)*10; c.fillStyle='#4a3a38'; c.fillRect(x,128-h,w,h); c.fillStyle='#2a2428'; c.fillRect(x+4,128-h*0.7,6,h*0.5); c.fillStyle='#8a94a8'; c.beginPath(); c.moveTo(x-1,128-h); c.lineTo(x+w*0.3,128-h-4); c.lineTo(x+w*0.55,128-h+3); c.lineTo(x+w+1,128-h-2); c.lineTo(x+w+1,128-h+6); c.lineTo(x-1,128-h+6); c.fill(); }
  /* the rows of bricks, one name each */
  for(let r=0;r<4;r++) for(let i=0;i<26;i++){ const x=18+i*11.5+(r%2)*5, y=134+r*10, last=(r===3&&i>13); if(last&&i>20) continue; rect(c,x,y,10,6,last?'#2e3444':'#5a4640'); if(!last) rect(c,x+2,y+2.5,6,0.8,'rgba(255,230,200,0.5)'); }
  const k=ez((t-1)/4); const f=0.7+0.3*Math.sin(t*5);
  glow(c,160,126,70,'rgba(255,200,120,'+(0.2*k*f).toFixed(2)+')');
  for(let i=0;i<80;i++){ const x=(i*37+Math.sin(t*0.6+i)*8)%LW, y=(t*18+i*23)%LH; c.fillStyle='rgba(255,255,255,0.7)'; c.fillRect(x,y,1.3,1.3); }
  const wx=-10+ez(t/7)*100; bobDuck(c,wx,170,'right',t,meDuck(),1.6); circ(c,wx+10,158,10,'rgba(255,200,120,0.25)');
  vg(c,0.45);
};

/* ---------- A CHILD'S ROOM IN EMBERWICK, at dawn (chapter 7, Red route) ---------- */
SCENES.s17room=function(c,t){
  c.fillStyle='#3a2420'; c.fillRect(0,0,LW,LH); c.fillStyle='#4a2e28'; c.fillRect(0,0,LW,108);
  for(let x=0;x<LW;x+=16) rect(c,x,0,1,108,'rgba(0,0,0,0.2)');
  c.fillStyle='#2a1a16'; c.fillRect(0,116,LW,64);
  /* shutter window onto the dawn town */
  rect(c,206,22,72,56,'#1a100c'); rect(c,210,26,64,48,'#f0b080'); c.fillStyle='#c85a3a'; for(let i=0;i<4;i++){ const x=212+i*16; c.beginPath(); c.moveTo(x,66); c.lineTo(x+7,52); c.lineTo(x+14,66); c.fill(); }
  rect(c,240,26,2,48,'#1a100c'); rect(c,210,48,64,2,'#1a100c'); glow(c,244,80,80,'rgba(255,200,140,0.3)');
  /* the small bed, blanket folded as if someone were coming back */
  rect(c,30,102,74,30,'#6a4a38'); rect(c,34,92,66,14,'#7a5a46'); rect(c,34,96,66,10,'#c8b898'); rect(c,34,104,66,12,'#a8503a'); rect(c,36,108,62,2,'#d8785a');
  /* the table with the music box */
  rect(c,140,124,76,5,'#6a4a30'); rect(c,146,129,4,24,'#4a3020'); rect(c,206,129,4,24,'#4a3020');
  const p=0.6+0.4*Math.sin(t*3); rect(c,164,112,24,12,'#a8281c'); rect(c,164,110,24,3,'#c0392b'); circ(c,176,111,2.4,'#ffd166'); glow(c,176,112,34,'rgba(255,200,120,'+(0.25*p).toFixed(2)+')');
  for(let i=0;i<6;i++){ const tt=(t*0.35+i*0.17)%1; c.fillStyle='rgba(255,230,160,'+(0.7*(1-tt)).toFixed(2)+')'; c.fillRect(170+Math.sin(tt*7+i)*8,104-tt*50,1.6,2.4); c.fillRect(172+Math.cos(tt*6+i)*10,100-tt*40,1.2,1.2); }
  staticDuck(c,108,150,'right',REDDUCK,2.0,{head:'hood'});
  staticDuck(c,236,152,'left',meDuck(),1.8); staticDuck(c,266,158,'left',{body:'#e0603f',wing:'#b24a30',bill:'#e6c441'},1.2,{head:'bow'});
  vg(c,0.45);
};

/* any scene can sit behind a talking beat (shifted up so the figures clear the text box) */
let _pg={b:null,page:-1,t0:0};
TELLERBG.s17=function(c,t,b){
  c.fillStyle='#000'; c.fillRect(0,0,LW,LH);
  if(_pg.b!==b||_pg.page!==cut.page){ _pg.b=b; _pg.page=cut.page; _pg.t0=t; }
  const pt=Math.max(0,t-_pg.t0);
  c.save(); c.translate(0,-38);
  let ref=b.shots&&b.shots[Math.min(cut.page,b.shots.length-1)];
  if(ref){
    const name=Array.isArray(ref)?ref[0]:ref, o=Array.isArray(ref)?(ref[1]||{}):{};
    try{
      if(window.S17SHOTS&&S17SHOTS[name]) S17SHOTS[name](c,pt,o);
      else if(SCENES['s17'+name]){ const keep=b.opt; b.opt=o; try{ SCENES['s17'+name](c,pt,cut); } finally{ b.opt=keep; } }
    }catch(e){ if(!_pg.err){ _pg.err=1; console.error('shot',name,e); } }
  } else { const f=SCENES[b.sc]; if(f) f(c,t,cut); }
  c.restore();
};

/* ---------- beat builders ---------- */
const A=(scene,cap,opt,dur)=>({k:'anim',scene:'s17'+scene,dur:dur||9,cap:cap,opt:opt||{}});
const T=(who,sc,opt,pages)=>({k:'teller',bg:'s17',sc:'s17'+sc,opt:opt||{},who:who,pages:pages});

/* ---------- THE OPENINGS ---------- */
const OPEN={
  c5c:()=>[A('hall','A long cold hall. A table laid for two.',{mode:'dinner'},9),
           T('Narrator','letter',{},['You wake at the inn in Kingsbill. Three hundred crumbs in the purse. A headache the size of a castle.','On the pillow, a letter. The wax of the seal is blue, and still faintly warm.'])],
  c5r:()=>[A('town','Emberwick. The Potion does not wash off.',{hearth:'dim'},9),
           T('Warden Ruddock','town',{hearth:'dim',crowd:8},['Three proofs. I will set them. I will not be kind about it.','A town that has been afraid this long has learned to be careful. Earn it, and the whole town will hold the door for you.'])],
  c6c:()=>[A('castle','Quackenhold, past midnight. Every window lit.',{time:'night',silent:true,guards:0},10),
           T('Narrator','castle',{time:'night',silent:true,guards:0,door:true},['The servants\' door stands an inch ajar, as if someone had been told to leave it that way.','Inside, a hundred years of silence is waiting to be disturbed. Mind where you put your feet.'])],
  c6r:()=>[A('town','The Hearth dims at dusk. The whole town watches it.',{hearth:'dim',dawn:false,crowd:16},9),
           T('Elder Cinder','town',{hearth:'dim',crowd:16},['We did not tell them. They knew anyway. A hundred ducks in a hundred doorways, watching one flame.','The First Hearth was lit from a lantern, and the lantern is in the shrine in the Hollow Wood. Nobody has dared go and look.']),
           A('wood','The shrine in the Hollow Wood',{mode:'shrine'},9)],
  c7c:()=>[A('castle','Kingsbill smells of polish and sharpened steel.',{time:'day',march:true,guards:2},10),
           T('Herald','castle',{time:'day',march:true,guards:2},['By order of the Crown! By order of the Crown!','(The Herald is hoarse. He has said it forty times since sunrise, and every time it sounds a little less like a man who believes it.)']),
           A('hall','Behind the black door, a hand signs every page.',{mode:'throne'},9)],
  c7r:()=>[A('town','At dawn the lantern still leans north-west.',{hearth:'warm',dawn:true,crowd:3},9),
           T('Hermit Mallow','town',{hearth:'warm',dawn:true,crowd:3},['A hundred years, I have come back every spring to put the stones in their ring. I never once went through the gate.','Walk in with me. If my knees stop, hold the lantern.'])],
  c8c:()=>[A('hills','A small fire, made from nothing, beside the tower.',{tower:true},10),
           T('Hermit Mallow','hills',{tower:true},['You are real. Forgive me. I have been seeing the faces of the kingdom\'s friends in the smoke for a week.','Sit. I am out of practice at being asked for anything.'])],
  c8r:()=>[A('town','Every lantern went out in the night. Nobody touched them.',{hearth:'bruise',lanterns:false,crowd:14,dawn:true},9),
           T('Narrator','town',{hearth:'bruise',lanterns:false,crowd:14,dawn:true},['By morning, the town is saying out loud what it whispered all week: the Wood is dying, the Hearth is dying, somebody must do something.','Somewhere in the crowd, someone is not afraid. Someone is very well organised.'])],
  c9r:()=>[A('road','At every farm a shutter closes.',{sky:'dusk',farms:true,party:['me'],lantern:true,pace:10},11),
           T('Elder Cinder','town',{hearth:'warm',crowd:10},['Carry this to the king. If he will not read it, read it to him.','Keep the lantern lit. It is the only thing we own that is both ours and his.'])],
  c9c:()=>[A('town','Cast out in red runes, and glad of a wooden disc.',{hearth:'warm',hatch:true,crowd:0,lanterns:true},10),
           T('Narrator','town',{hearth:'warm',hatch:true,crowd:0},['At midnight, by the south wall, there is a door in the ground that is not on any map.','It opens on a stair that smells of ash and warm bread.'])],
  c10:()=>[A('hall','The black door has waited a hundred years for a knock.',{mode:'throne'},10),
           T('A Voice Behind the Door','hall',{mode:'throne'},['You came back. I hoped you would. I was afraid you would.','Come in. Mind the third step. It remembers.'])],
  c11:()=>[A('wood','The quietest place in the world hums.',{mode:'trees'},11),
           T('Narrator','wood',{mode:'tree'},['In the hollow of the Old Tree, something is humming a lullaby. It is very slightly flat.','The tree has been waiting to be asked what it remembers. It has not been asked in a hundred years.'])],
  c12:()=>[A('tent','A tent on the hills, halfway between town and castle.',{mode:'gather'},10),
           T('Captain Halbeak','tent',{mode:'gather'},['The Crown will hear you. I will not pretend that it will be moved.']),
           T('Elder Cinder','tent',{mode:'gather'},['The Hollow will hear you too. We have heard a great many things in a hundred years, and been moved by very few of them.'])],
  c13r:()=>[A('town','Emberwick fills with the sound of sharpening.',{hearth:'warm',crowd:18},9),
            T('Warden Ruddock','town',{hearth:'warm',crowd:18},['A wall.']),
            T('A Hand in Grey','town',{hearth:'warm',crowd:18},['A rite.']),
            T('Elder Cinder','town',{hearth:'warm',crowd:18},['Peace. If somebody will tell me what it costs, and who pays.'])],
  c13c:()=>[A('hall','The war chest is open. Nobody remembers signing for it.',{mode:'court'},10),
            T('A Lord of the Court','hall',{mode:'court'},['Inevitable.','Inevitable. Quite inevitable. (Nobody at the table will say who said it first.)'])],
  c14r:()=>[A('town','Five fires on the palisade, an hour before dawn.',{hearth:'warm',fire:true,dawn:true,crowd:0},10),
            T('Warden Ruddock','town',{hearth:'warm',fire:true,dawn:true,crowd:0},['They are afraid, and it has made them organised. We will have to be organised back.','Buckets. Everyone. Now.'])],
  c14c:()=>[A('hall','He has carried it for six days.',{mode:'barracks'},10),
            T('Captain Halbeak','hall',{mode:'barracks'},['I swore an oath to the Crown. This is the Crown\'s hand. I cannot burn it, and I cannot obey it.','I would rather you told me what to do. I am aware of how that sounds.'])],
  c15r:()=>[A('road','The Lantern Road leaves by the west gate.',{sky:'dawn',party:['me','poppy','ruddock'],lantern:true,lanterns:true,pace:12},11),
            T('Little Poppy','road',{sky:'dawn',party:['me','poppy','ruddock'],stand:true,lantern:true},['I packed eleven sandwiches. Ruddock says that is too many.','Ruddock is not the one carrying them.'])],
  c15c:()=>[A('hills','Five watch-fires on the western hills, long dark.',{fires:5,time:'night'},11),
            T('Narrator','hills',{fires:5,time:'night'},['The coal in the iron cup does not burn. It does not go out. It lights whatever you ask it to, and it leans, always, toward the Burnt Wood.'])],
  c16r:()=>[A('wood','A line of blue at the edge of the ash.',{mode:'edge',line:'crown',player:true},9),
            T('Captain Halbeak','wood',{mode:'edge',line:'crown',player:true},['I did not march into your Hollow. I marched to the one place both of us must pass.','It is the most sensible thing I have done all week. I am very much afraid it is going to get someone killed.'])],
  c16c:()=>[A('wood','A line of red at the edge of the ash.',{mode:'edge',line:'red',player:true},9),
            T('Warden Ruddock','wood',{mode:'edge',line:'red',player:true},['I have made a decision.','I would very much like someone to talk me out of it.'])],
  c13k:()=>[A('table','A kettle on the fire. Two chairs, and a third.',{third:true},9),
            T('Hermit Mallow','table',{third:true},['Sit. The kettle is on. Nobody at this table is asked to choose a side.','The third chair has never been sat in. Leave it. Somebody will come.'])],
  c14k:()=>[A('table','The book of days, open, with a quill in the fold.',{book:true,items:true},10),
            T('Hermit Mallow','table',{book:true,items:true},['Everyone has a back page, where they put down what they could not say aloud.','Bring me three small lost things from the Ash Road, and I will read you yours.'])],
  c15k:()=>[A('table','Three cups, steaming.',{cups:3,third:true,guests:true},10),
            T('Narrator','table',{cups:3,third:true},['The envoys walk in step this time, and neither looks sideways.','The third cup steams with no one to drink it, and nobody asks.'])],
  c16x:()=>[A('ash','North of the Burnt Wood the land turns grey and keeps going.',{dur:12},12),
            T('Hermit Mallow','ash',{dur:12},['I walked it once, after. It took nine days. I would have taken ninety, if the road had been longer.','It is the road a person walks when they are not yet ready to arrive.'])],
  c17:()=>[A('wood','The trees are charcoal, upright, and every one of them hums.',{mode:'trees'},11),
           T('The Wood','wood',{mode:'trees'},['You have come a long way to be asked one thing.','Be patient. It will not be hard to hear.'])],
  c18:()=>[A('wood','Three hundred sleepers, each curled round a small light.',{mode:'clearing',sleepers:44},11),
           T('Narrator','wood',{mode:'clearing',sleepers:44},['They are not dead. Their breathing is slow, and in time, and every one of them is humming.','You can hear what they are humming if you stand still long enough.'])],
  c19:()=>[A('wood','A note drops a whole tone through every tree at once.',{mode:'break',sleepers:44},10),
           A('town','In a town in a wood, a Hearth flares blue.',{hearth:'blue',crowd:18},8),
           A('castle','In a far castle, a white-haired duck puts down his pen.',{time:'night',crystal:true,windows:'lit',guards:0},9)],
  c20:()=>[A('wood','Opposite roads, and they arrived at the same time.',{mode:'name'},10),
           T('The Old Tree','wood',{mode:'name'},['I have kept the question a hundred years. I will ask it once, and I will wait.','Is it safe now?'])],
  c21:()=>[A('wood','Like lamps being lit down a long street.',{mode:'wake',sleepers:44},13),
           T('Hob','wood',{mode:'wake',sleepers:44},['Is it morning? My hands have forgotten what they were doing.','It has been morning for a very long time, friend. Sit. There is no hurry now.'])],
  c22:()=>[A('road','A season, and then another.',{sky:'dawn',meet:true,lanterns:true,dur:11},11),
           T('Captain Halbeak','road',{sky:'dawn',party:['halbeak'],stand:true},['Mine is blue.']),
           T('Elder Cinder','road',{sky:'dawn',party:['cinder'],stand:true},['Mine is red. They cross at the Tree.','Neither of us will say which line is whose.'])],
  c23:()=>[A('grow','Three bare patches, and one very small gardener.',{},13),
           T('Little Poppy','grow',{},['Mallow says it takes a long time for good reasons.','I think he means I am not allowed to dig it up to check.'])],
  c24:()=>[A('lanterns','They light the first lantern at dusk.',{},14),
           T('Narrator','lanterns',{},['Some of them are not speaking to each other. They are standing near each other.','That, as it turns out, is how the other thing begins.'])]
};

/* ---------- THE ENDINGS (turning points only) ---------- */
const CLOSE={
  c8r:()=>[A('road','The Elders\' letter, and the Keeper\'s Lantern, go south.',{sky:'dusk',party:['me'],lantern:true,pace:10},10)],
  c12:()=>[A('tent','The summit fails. Both sides walk away.',{mode:'part'},12),
           T('Narrator','tent',{mode:'part'},['Nobody shouts. That is the worst of it.','By morning, both towns are sharpening.'])],
  c16r:()=>[A('wood','The line parts. The Wood is waiting.',{mode:'trees'},9)],
  c16c:()=>[A('wood','The line parts. The Wood is waiting.',{mode:'trees'},9)]
};

/* ---------- hook into the chapter flow ---------- */
function seenKey(k){ try{ const q=s2(); q.cuts=q.cuts||{}; if(q.cuts[k]) return true; q.cuts[k]=1; return false; }catch(e){ return true; } }
function chapId(c){ return Object.keys(S2.ch).find(k=>S2.ch[k]===c)||''; }

/* the chapter card (same title beat as s2core.js), followed by this chapter's opening cutscene */
S2.card=function(c,done){
  const id=chapId(c), num=c.numLabel||s2num(id||'c0');
  const pages=(c.intro&&c.intro.length)?c.intro:[c.sub||''];
  const beats=[{k:'teller',bg:'s2card',who:c.who||'Narrator',title:c.title,num:num,act:ACTS[num]||'',sub:c.sub||'',rt:c.theme||(c.route==='red'?'red':c.route==='crown'?'crown':'both'),pages:pages}];
  const mk=OPEN[id];
  if(mk && !seenKey('o_'+id)){ try{ mk().forEach(b=>beats.push(b)); }catch(e){ console.error('s17 opening',id,e); } }
  startCutscene(beats,done,{hint:'Press X again to skip'});
};
{
  const _fin=S2.finish;
  S2.finish=function(id,msg){
    const mk=CLOSE[id];
    if(mk && !seenKey('c_'+id)){
      let beats=null; try{ beats=mk(); }catch(e){ console.error('s17 ending',id,e); }
      if(beats){ const args=arguments, self=this; startCutscene(beats,()=>_fin.apply(self,args),{hint:'Press X again to skip'}); return; }
    }
    return _fin.apply(this,arguments);
  };
}


/* ---------- cutSeq: play an existing seq([...]) list as a cutscene, keeping every word ----------
   spec : [scene,opt] used for every entry, or an array of [scene,opt] (one per entry; the last repeats); null = plain dialogue
   list : the same [[who,[pages...]], ...] you would give seq()
   cb   : runs when it finishes or is skipped, exactly like seq()'s callback
   Long pages are split at sentence ends so nothing is lost to the 4-line text box. */
let _mc=null;
function measure(){ if(!_mc){ _mc=document.createElement('canvas').getContext('2d'); _mc.font='600 8px ui-monospace,"Courier New",monospace'; } return _mc; }
function splitPage(p){
  const c=measure(), max=LW-40;
  if(wrapText(c,p,max).length<=4) return [p];
  const parts=p.match(/[^.!?…]+[.!?…]+["')\]]*\s*|[^.!?…]+$/g)||[p], out=[]; let cur='';
  for(const s of parts){ const t=cur?cur+s:s; if(cur&&wrapText(c,t.trim(),max).length>4){ out.push(cur.trim()); cur=s; } else cur=t; }
  if(cur.trim()) out.push(cur.trim());
  /* a single sentence that is still too long: break at the last space that fits */
  const fin=[]; for(const o of out){ let r=o; while(wrapText(c,r,max).length>4){ let k=r.lastIndexOf(' ',Math.floor(r.length*0.7)); if(k<1) break; fin.push(r.slice(0,k)); r=r.slice(k+1); } fin.push(r); }
  return fin;
}
window.cutSeq=function(spec,list,cb){
  if(!spec||(typeof g!=='undefined'&&g.mode==='cut')){ return seq(list,cb); }
  try{
    const story=spec.story||null;
    const specs=story?null:((Array.isArray(spec)&&Array.isArray(spec[0]))?spec:[spec]);
    const beats=[];
    list.forEach((it,i)=>{
      let pages=(Array.isArray(it[1])?it[1]:[it[1]]).map(p=>typeof p==='function'?p(g):p);
      if(story){
        const sh=story[Math.min(i,story.length-1)]||[], outP=[], outS=[];
        pages.forEach((p,pi)=>{
          const ref=sh.length?sh[Math.min(pi,sh.length-1)]:null;
          splitPage(String(p)).forEach((chunk,j)=>{ outP.push(chunk); outS.push(ref&&ref.seq?ref.seq[Math.min(j,ref.seq.length-1)]:ref); });
        });
        beats.push({k:'teller',bg:'s17',sc:'s17wood',opt:{},who:it[0]||'Narrator',pages:outP,shots:outS});
      } else {
        const sp=specs[Math.min(i,specs.length-1)];
        pages=pages.reduce((a,p)=>a.concat(splitPage(String(p))),[]);
        beats.push({k:'teller',bg:'s17',sc:'s17'+sp[0],opt:sp[1]||{},who:it[0]||'Narrator',pages:pages});
      }
    });
    startCutscene(beats,cb,{hint:'Press X again to skip'});
  }catch(e){ console.error('cutSeq failed, falling back to dialogue',e); seq(list,cb); }
};

window.S17={OPEN:OPEN,CLOSE:CLOSE};
})();
