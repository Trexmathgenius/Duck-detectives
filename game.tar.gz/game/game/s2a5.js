'use strict';
/* ===== ACT V: UNTIL IT IS SAFE ===== chapters 17 to 20 and the endings ===== */

SXG.oldtree=(c,x,y,t,o)=>PGLYPH.oldtree(c,x-2,y+8,null,t);
const GHOST={body:'#9a8ac8',wing:'#7a6aa8',bill:'#c9b0e0'};
const MALLOW_F={name:'Hermit Mallow',pal:RED_PALS[0],head:'hood',seen:false};
function epiCard(label,title,sub,pages,theme,cb){ startCutscene([{k:'teller',bg:'s2card',who:'',title:title,num:label,act:'',sub:sub,rt:theme||'both',pages:pages}],cb,{hint:'Press X again to skip'}); }
function grudge(){ return s2fl('grudge')||'held'; }

/* =========================================================
   CHAPTER 17: THE BURNT WOOD
   ========================================================= */
S2.ch.c17={route:'both',title:'The Burnt Wood',sub:'It does not ask who you are. It shows you.',
  intro:['The Burnt Wood is a silence the shape of a forest. The trees are charcoal, upright, and they hum, all of them, four slow notes.','Nobody goes in. Birds go round. Those who have walked in on a dare describe the same thing: the wood shows you something you did, and asks if you meant it.'],
  recap:'The Burnt Wood showed you your own deeds, and asked if you meant them. You answered.',
  start(){ s2set(0); },
  obj(s){ return ['Go into the <b>Burnt Wood</b>: follow the ash path north-west of Kingsbill, past the old Gate, then east to the Ash Maze'+hostWhere(57,-1057)+'.','The Ash Maze: three memory stones, each in its own chamber. Look at what the Wood shows you. The fog in the gaps answers to a light.'][s]; }
};
S2.prop({id:'bwentry',wx:54,wy:-1059,snap:2,glyph:'stone',col:'#2a2624',when:()=>s2at('c17',0,0),mark:'!',use(){ say('',['A ring of charred stumps, and a path of grey ash between them. A hundred years of silence stands behind it, with its hands folded.','(The Ash Maze begins just east of here.)']); }});
function lightFog(o){ o.use=((u)=>(S,ob)=>{
  const alts=[{t:'Hold up the '+(g.inv.keeperlantern?'Keeper\'s Lantern':'Coal of the First Hearth')+' and walk into it',cond:()=>!!g.inv.keeperlantern||!!g.inv.hearthcoal,fn:(S2_,ob2)=>{ S2_.fl[ob2.key]=1; coin(); sxSay(S2_,'',['The light goes in first. The fog does not part so much as remember what it is for, and falls back to the edges of the room.']); }}];
  sxNeed(S,ob,{Gust:'blow it back, gently',Emberlight:'burn it back with a Keeper\'s flame'},(S2_,ob2)=>{ S2_.fl[ob2.key]=1; coin(); sxSay(S2_,'',['The fog unrolls, grumbling, and the gap is open.']); },alts,'The fog is thick. Something with a light of its own might walk through.');
})(); o.cast={Gust:(S,ob)=>{ S.fl[ob.key]=1; coin(); sxSay(S,'',['The fog unrolls, and the gap is open.']); },Emberlight:(S,ob)=>{ S.fl[ob.key]=1; coin(); sxSay(S,'',['The Emberlight goes in, small and steady. The fog does not argue with it. It goes grey, and then thin, and then, with a sigh, it is only the memory of a cloud.']); }}; return o; }
function memStone(S,i){
  if(S.fl['m'+i]){ say('',['The stone is dark. It has said what it had to say.']); return; }
  const L=s2().led, has=(k,n)=>(L[k]||0)>=n;
  const mem=[
    {t:'The first stone shows a duck on a bridge, saying something. Its voice is yours.',
      lines:has('lie',1)?['You said a thing that was not true, because it was easier. You watch it travel from your mouth into the world and become somebody else\'s decision.']:has('truth',3)?['You said a hard thing, plainly, when it would have been simpler to say a soft one. It travelled, and someone you did not know was changed by it.']:['You said a plain thing, once, to someone who needed it. You did not know it mattered. It did.'],
      ask:'The Wood asks: did you mean it?',opts:[['Yes. I meant it.',()=>s2led('truth',1)],['I meant well, and I was wrong.',()=>{ s2led('mercy',1); }],['I do not want to look at it.',()=>s2led('pride',1)]]},
    {t:'The second stone shows a doorway, and someone behind it who did not open.',
      lines:has('mercy',3)?['You were kind, again and again, in small ways. You see a chair mended, a shutter bound, a stranger spared, and none of them know it was you.']:has('pride',2)?['You were proud when you should have been gentle. You see the face of the one you refused. It does not look angry. It looks tired.']:['You did some good, and some harm, in the usual proportions. The stone does not judge. It only holds them side by side.'],
      ask:'The Wood asks: who did you do it for?',opts:[['For them.',()=>s2led('mercy',1)],['For myself, and I am sorry.',()=>s2led('truth',1)],['I would rather not say.',()=>{}]]},
    {t:'The third stone shows a small hand, and a larger one, held for a long moment, and let go.',
      lines:has('trust',2)||has('kin',2)?['Someone trusted you, and you kept it. You see the hand close around a thing you gave, and the face of the one who held it. It is the most private thing the Wood has shown you, and it does not feel like being looked at. It feels like being thanked.']:['Someone trusted you a little, and you were not quite sure what to do with it. You see them waiting. It is a long wait.'],
      ask:'The Wood asks: will you go on?',opts:[['Yes.',()=>s2led('trust',1)],['I am afraid, but yes.',()=>{ s2led('trust',1); s2led('truth',1); }],['I do not know.',()=>{}]]}][i];
  seq([['The Burnt Wood',[mem.t].concat(mem.lines)]],()=>{
    choose('The Burnt Wood',mem.ask,mem.opts.map(o=>o[0]),k=>{
      mem.opts[k][1](); S.fl['m'+i]=1; S.fl.mc=(S.fl.mc||0)+1; coin();
      say('',[['The stone takes the answer, and goes quiet. Somewhere deep in the wood, a note drops by half a step.','The stone takes the answer, and holds it, as one holds a bird. It goes quiet.','The stone takes the silence as an answer, too. It goes quiet, a little sadly.'][k]],()=>{
        toast('Memory '+S.fl.mc+' of 3.',2200);
        if(S.fl.mc>=3&&!S.fl.open){ S.fl.open=1; sxSay(S,'Hermit Mallow',['The wood has gone still. It listened to all of it, and it has not decided anything. Which is, I think, what it was waiting for.','The way to the Tree is open, little detective. Let us not make it wait.']); }
      });
    },2);
  });
}
sxDef('bw1',{name:'The Ash Maze',theme:'ash',dark:0.62,lightR:90,fx:'dream',start:[1,6,'right'],follow:MALLOW_F,seek:S=>S.fl.mc>=3?[28,6]:(S.fl.m0?(S.fl.m1?[25,3]:[15,10]):[5,2]),
  hint:'The wisps are not malicious. They are only certain. Trees block their sight. Shadows halve it.',
  caughtLines:['A pale wisp turns, and seems to know you. It does not hurt you. It only returns you to where you came in, as the Wood returns everything.'],
  rows:sxGrid(30,13,[[0,6,'D'],[29,6,'E'],[10,1,1,5,'#'],[10,7,1,5,'#'],[10,6,'F'],[20,1,1,5,'#'],[20,7,1,5,'#'],[20,6,'G'],[5,2,'a'],[15,10,'b'],[25,3,'c'],[4,5,'T'],[7,8,'T'],[13,3,'T'],[16,8,'T'],[23,8,'T'],[26,6,'T'],[2,8,5,3,','],[12,1,4,3,','],[22,9,5,3,',']]),
  exits:{D:{to:'world',wx:KX-46,wy:KY-53},E:{fn:S=>{ if(!S.fl.open){ say('',['Not yet. The Wood has three things to show you.']); return; } sxLeave(KX-66,KY-60); S2.finish('c17'); }}},
  objs:{
    T:{name:'Charred tree',glyph:'charred',block:true,glow:true,desc:'A tree burnt to its bones. It hums.'},
    F:lightFog({key:'f1',name:'Fog',glyph:'fog',solid:true,desc:'A bank of grey fog. It hums. It stands in the gap in the wall like a held thought.',when:S=>!S.fl.f1}),
    G:lightFog({key:'f2',name:'Fog',glyph:'fog',solid:true,desc:'A bank of grey fog. It hums. It stands in the gap in the wall like a held thought.',when:S=>!S.fl.f2}),
    a:{name:'Memory stone',glyph:'rock',col:'#6a5a8a',use:(S)=>memStone(S,0)},
    b:{name:'Memory stone',glyph:'rock',col:'#6a5a8a',use:(S)=>memStone(S,1)},
    c:{name:'Memory stone',glyph:'rock',col:'#6a5a8a',use:(S)=>memStone(S,2)}
  },
  guards:[{name:'Wisp',path:[[2,1],[8,1],[8,11],[2,11]],speed:28,range:5,fov:64,pal:GHOST,head:null},
          {name:'Wisp',path:[[12,1],[18,1],[18,11],[12,11]],speed:28,range:5,fov:64,pal:GHOST,head:null},
          {name:'Wisp',path:[[22,1],[27,1],[27,11],[22,11]],speed:30,range:5,fov:64,pal:GHOST,head:null}],
  onEnter(S){ if(!S.fl.hint){ S.fl.hint=1; sxSay(S,'Hermit Mallow',['It is so quiet. I thought it would be loud.','There is a stone in each chamber. I think we are supposed to look at them. I think we are supposed to be looked at.']); } }
});

/* =========================================================
   CHAPTER 18: THE THREE HUNDRED
   ========================================================= */
S2.ch.c18={route:'both',title:'The Three Hundred',sub:'They have been dreaming for a hundred years. Ask them what they dreamt.',
  intro:['The clearing at the centre of the Burnt Wood is round and still. The Old Tree stands in the middle, and in a ring around it, on the ash, three hundred ducks sleep, each curled round a small light.','They are not dead. Their breathing is slow, and in time, and every one of them is humming.'],
  recap:'You heard the sleepers, found Bree, and spoke to Gordamom. What you said decided whether the grudge could be put down.',
  start(){ s2set(0); },
  obj(s){ return ['Enter the <b>Hall of Sleepers</b> at the foot of the Old Tree, in the heart of the Burnt Wood.','Listen to the sleepers. Hear at least <b>five</b> of them, find <b>Bree</b>, then speak with <b>Gordamom</b>.'][s]; }
};
S2.prop({id:'sleepers',k:[-66,-63],glyph:'oldtree',when:()=>s2at('c18',0,1),mark:'!',use(){ say('',['The hollow in the Old Tree is humming. You step through it, as through a door, and into the room where the three hundred are sleeping.'],()=>{ s2set(1); sxEnter('sl1'); }); }});
const SLEEP=[
  {k:'s1',nm:'Sleeper: Tam, a soldier',g:'crown',txt:['"I held the line at the Reeds. I would do it again. Tell the king I will not forgive him. Tell him, if he is there, that I am not angry. I am only certain."']},
  {k:'s2',nm:'Sleeper: Orla, a mother',g:'ember',txt:['"I lost Alder at the Rise. I stood there until the others dragged me back. The Elders were not at the Rise. The Elders were at the front of the march, being careful."','"Do not tell me they had reasons. Everyone has reasons."']},
  {k:'s3',nm:'Sleeper: Hob, a cook',g:'none',txt:['"I fed them all, the whole way. Nobody thanked us. I do not say it for thanks. I say it so someone knows we ate."']},
  {k:'s4',nm:'Sleeper: Rook, a scout',g:'truth',txt:['"I saw the wall that night, and the king on it. He was crying. I never told anyone. Who would believe it, that he was crying?"']},
  {k:'s5',nm:'Sleeper: Corvin, a priest',g:'ember',txt:['"We prayed at the Hearth, and the temple prayed against us. It was not the war that undid me. It was that both of us were praying."']},
  {k:'s6',nm:'Sleeper: Ibb, a child',g:'none',txt:['"Is it morning? ... Is it morning yet? ... I am not tired. I am only sitting."']},
  {k:'s7',nm:'Sleeper: Marl, a smith',g:'crown',txt:['"I forged the spears I did not mean to use. I made them well. That is the worst of it. I made them well."']},
  {k:'s8',nm:'Sleeper: Dessa, a healer',g:'truth',txt:['"I would have healed them all. Both sides. I carried the bandages up the hill. They would not let me past the line. Nobody let anyone past any line."']}
];
function heardCount(S){ return SLEEP.filter(x=>S.fl[x.k]).length; }
function sleeperObj(x,i){ return {name:x.nm,glyph:'sleeper',key:x.k,col:['#5a4a3a','#6a4a4a','#4a5a4a','#5a5a6a','#6a5a3a','#4a4a5a','#5a3a3a','#4a5a5a'][i%8],use:(S)=>{
  if(S.fl[x.k]){ say(x.nm,['(The dream has said what it had to say.)']); return; }
  S.fl[x.k]=1; coin(); if(x.g==='crown') s2fl('gCrown',(s2fl('gCrown')||0)+1); if(x.g==='ember') s2fl('gEmber',(s2fl('gEmber')||0)+1);
  say(x.nm,['(You lay a wing near the small light. The sleeper does not wake. But a voice, thin and very close, is saying:)'].concat(x.txt),()=>{ toast('Heard: '+heardCount(S)+' of 8.',2200); });
}}; }
sxDef('sl1',{name:'The Hall of Sleepers',theme:'dream',fx:'dream',dark:0.58,lightR:100,start:[1,7,'right'],follow:MALLOW_F,
  rows:sxGrid(26,15,[[0,7,'D'],[25,7,'E'],[13,2,'X'],[6,3,'1'],[10,3,'2'],[16,3,'3'],[20,3,'4'],[6,11,'5'],[10,11,'6'],[16,11,'7'],[20,11,'8'],[13,12,'B'],[13,6,'.']]),
  exits:{D:{to:'world',wx:KX-66,wy:KY-61},E:{fn:S=>{ if(!S.fl.done){ say('',['You cannot go yet. There is a conversation you have not had.']); return; } sxLeave(KX-66,KY-61); S2.finish('c18'); }}},
  objs:Object.assign({
    X:{name:'The Old Tree',glyph:'oldtree',solid:true,desc:'The Old Tree, from underneath. The hollow in its trunk is open, and the hum comes out of it like warmth.'},
    B:{name:'Bree',glyph:'sleeper',key:'bree',col:'#8a4a4a',use:(S)=>{
      if(S.fl.bree){ say('Bree',['(She sleeps, and hums, and her hand is open.)']); return; }
      S.fl.bree=1; coin(); s2fl('breeMet',1);
      seq([['',['A woman, curled in the ash, with a small light cupped in both wings. She is hooded. She is humming four slow notes. Mallow has stopped walking behind you.']],
        [H3,['Mama.','I have come home. I came home a hundred years late. I did what you said. I lit the hearth. I ate something. I did not follow.','I am so sorry I did not follow.']],
        ['Bree',['(Her wings do not move. Her breath catches, once, in the humming, and the second verse of the lullaby comes out of her sleep, very quietly, like something she has been saving.)','"...is it you? ...is it my boy? ...I did not stop. I did not stop."']],
        [H3,['(He kneels. He puts his forehead against her wing. For a long time nothing is said, and everyone is very careful not to say it.)']]],()=>{ s2led('trust',1); s2led('kin',1); hudCache.obj=null; toast('Bree is not awake. But she heard.',3600); });
    }}
  },Object.fromEntries(SLEEP.map((x,i)=>[String(i+1),sleeperObj(x,i)]))),
  npcs:[{name:'Gordamom',tx:13,ty:5,pal:{body:'#7a2a2a',wing:'#5a1a1a',bill:'#c9a24a'},head:'helm',still:true,talk:(S,n)=>{
    if(S.fl.done){ say('Gordamom',['Go well, small one. Be the one who says.'],null); return; }
    if(heardCount(S)<5||!S.fl.bree){ say('Gordamom',['(He is half a duck and half a trunk, with his eyes closed.)','"Not yet. Listen first. Listen to all of them, or as many as you can bear. Then ask me what you came to ask."','('+heardCount(S)+' of 8 heard. At least five, and Bree.)'],null); return; }
    const g1=s2fl('gCrown')||0, g2=s2fl('gEmber')||0;
    S2.persuade({who:'Gordamom',intro:['The eyes of the tall trunk open. They are amber, and tired, and entirely awake.','"You listened. All of you, I see. The two of you. Most do not. Ask what you came to ask, small one. And ask it knowing I have had a hundred years to prepare an answer."'],
      rounds:[{q:'He waits. "A hundred years, and what did anyone do?"',opts:[
          {t:'"Nothing. We were afraid. Both sides."',p:2,req:()=>(s2led('truth')>=1),led:{truth:1},say:['The eyes close, and open. "That is the first honest sentence I have heard in a century."']},
          {t:'"We kept the Hearth lit. We kept the king\'s ward."',p:1,say:['"Lit. Held. Yes. And nobody asked."']},
          {t:'"You started it."',p:0,led:{pride:1},say:['"Did I," says Gordamom, very softly. "Did I."']}]},
        {q:'"Whom do I forgive?"',opts:[
          {t:'"Both of them, for being afraid. It is not forgiveness to hold a grudge for a century."',p:2,req:()=>(s2led('mercy')>=2),led:{mercy:1},say:['A long, long breath. "...You may be right. I am so tired of being right."']},
          {t:'"You do not have to forgive. But do not ask the children to carry it."',p:1,say:['"No. No, I would never. ...That is a fair thing to say."']},
          {t:'"They owe you."',p:0,led:{pride:1},say:['"They do. And what would that buy me?"']}]},
        {q:'"What did they say, the others?"',opts:[
          {t:'"They were more tired than angry. All of them. Even Tam."',p:2,req:()=>heardCount(S)>=6,say:['"Tam," says Gordamom, and something goes out of his shoulders. "Tam never did know how to put a thing down."']},
          {t:'"Some are angry at the Crown. Some at Emberwick."',p:1,say:['"Yes. I know. I have been listening for a hundred years."']},
          {t:'Say nothing, and let him hear the lullaby.',p:2,req:()=>!!s2fl('breeMet'),say:['The humming rises, and falls, and the second verse comes through the ring of sleepers, from Bree, from all of them. Gordamom closes his eyes again. He is smiling.']}]}],
      need:4,
      win:(sc)=>{ s2fl('grudge',sc>=5?'forgiven':'softened'); S.fl.done=1; coin(); say('Gordamom',[sc>=5?'Then it is put down. Not forgotten. Put down. That is a different thing, and a better one.':'Then it is eased. Not ended. Eased. That will have to be enough, for now.','When you come to say the words, small one, I will be listening. I do not know what you will say. I find I am no longer afraid of it.'],()=>{ toast('The grudge is '+grudge()+'.',3600); hudCache.obj=null; }); },
      lose:(sc)=>{ s2fl('grudge','held'); S.fl.done=1; say('Gordamom',['I hear you. I do not agree. But I hear you. That is more than I had.','Go. When you come to say the words, I will listen. I cannot promise what I will do.'],()=>{ toast('The grudge is held. The Wood will remember.',3600); hudCache.obj=null; }); }});
  }}],
  onEnter(S){ if(!S.fl.hint){ S.fl.hint=1; sxSay(S,'',['A round hall, and the sleepers around it in a ring, each with a small light. The Old Tree rises in the middle, hollow and warm. The humming is very soft, and very close, and has the shape of a lullaby.']); } }
});

/* =========================================================
   CHAPTER 19: THE WARD BREAKS
   ========================================================= */
S2.ch.c19={route:'both',title:'The Ward Breaks',sub:'Four notes, four anchors, and a clock with no hands.',
  intro:['The ground shakes. Not an earthquake: a note, dropping a whole tone, through every tree in the Burnt Wood at once. The ash rises off the ground in a long grey exhalation.','Far away, in a castle, a white-haired duck puts down his pen. In a town in a wood, a Hearth flares blue. And here, under the Old Tree, the sleepers are beginning to move.'],
  recap:'The ward broke. You held what you could of it.',
  start(){ s2set(0); sxEnter('wardsc'); },
  obj(s){ return ['Here at the Old Tree: steady the four anchors before the ward breaks. Stand still beside each one, and do not let a wisp see you.'][s]||''; }
};
const VERSES=['the first note: shelter','the second note: bread','the third note: a door','the fourth note: stay, and then, go'];
function steady(S,k){
  S.fl['a'+k]=1; coin(); const n=['a1','a2','a3','a4'].filter(x=>S.fl[x]).length;
  toast('The anchor steadies: '+VERSES[k-1]+'. ('+n+'/4)',3400);
  if(n>=4&&!S.fl.over){ S.fl.over=1; S.timer=null; wardEnd(S,true); }
}
function wardEnd(S,ok){
  s2fl('wardState',ok?'gentle':'violent'); S.hold=null;
  cutSeq({story:[ok?['wardOpen','sleepersBreathe']:['wardShatter','farKingFalls'],[ok?'wardOpen':'wardShatter'],['litterArrives']]},[['',ok?['The fourth note holds. The ward does not hold, it was never going to hold, but it lets go slowly, the way a hand opens when someone is ready to be taken by it.','Across the ring, three hundred sleepers draw a long breath, in time.']:['The clock runs out. The ward does not let go. It breaks, the way glass breaks, in every direction at once, with a sound like the world being told the thing it never wanted to hear.','The ring of sleepers jerks, together, and the humming stops. Somewhere very far away, a king falls.']],
    [H3,ok?['Something has changed. It is not over. But it has changed, and it did not have to change like this. Thank you, little detective.']:['Little detective. Little detective. They are waking. They are waking all at once, and nobody is ready, and nobody was ever going to be.']],
    ['',['At the edge of the clearing, a litter, carried by four ducks in blue and red together. On it, white as ash, a king with a bent crown, who has come the whole way on the last of the ward.']]],()=>{ sxLeave(KX-66,KY-61); S2.finish('c19'); });
}
sxDef('wardsc',{name:'The Ring',theme:'dream',fx:'dream',dark:0.5,lightR:100,start:[11,7,'up'],follow:MALLOW_F,
  hint:'Stand still beside an anchor. Wisps cannot touch you, but they will wake what they see.',
  caughtLines:['A wisp turns, and its light falls on you. The anchor you were holding flickers and goes out.'],
  rows:sxGrid(24,13,[[10,12,3,1,'.'],[11,6,'X'],[3,2,'1'],[20,2,'2'],[3,10,'3'],[20,10,'4'],[6,5,'T'],[16,7,'T'],[9,3,'T'],[14,9,'T']]),
  exits:{},
  objs:{
    X:{name:'The Old Tree',glyph:'oldtree',solid:true,light:true,lightR:110,desc:'The tree is shaking.'},
    T:{name:'Charred tree',glyph:'charred',block:true,glow:true},
    1:{name:'First anchor',glyph:'crystal',col:'#c9a6ff',lit:S=>!S.fl.a1,light:S=>!!S.fl.a1,lightR:90,solid:true,use:(S)=>anchorUse(S,1)},
    2:{name:'Second anchor',glyph:'crystal',col:'#c9a6ff',lit:S=>!S.fl.a2,light:S=>!!S.fl.a2,lightR:90,solid:true,use:(S)=>anchorUse(S,2)},
    3:{name:'Third anchor',glyph:'crystal',col:'#c9a6ff',lit:S=>!S.fl.a3,light:S=>!!S.fl.a3,lightR:90,solid:true,use:(S)=>anchorUse(S,3)},
    4:{name:'Fourth anchor',glyph:'crystal',col:'#c9a6ff',lit:S=>!S.fl.a4,light:S=>!!S.fl.a4,lightR:90,solid:true,use:(S)=>anchorUse(S,4)}
  },
  guards:[{name:'Wisp',path:[[2,1],[21,1],[21,11],[2,11]],speed:32,range:5,fov:64,pal:GHOST,head:null},
          {name:'Wisp',path:[[5,4],[18,4],[18,8],[5,8]],speed:28,range:5,fov:64,pal:GHOST,head:null},
          {name:'Wisp',path:[[11,2],[11,10]],speed:30,range:5,fov:64,pal:GHOST,head:null,pause:0.6,scan:true}],
  onEnter(S){ S.fl.over=0; for(const k of ['a1','a2','a3','a4']) delete S.fl[k]; S.hold=null; sxTimer(S,210,'The Ward',(S_)=>{ if(!S_.fl.over){ S_.fl.over=1; wardEnd(S_,false); } }); sxSay(S,'Hermit Mallow',['Four anchors, one at each corner. The old ones set them with a verse each. Stand beside one, quiet, and think the verse. I will watch your back.','Do not be seen while you hold. The wisps are not cruel, but they wake whatever they look at.']); },
  onReset(S){ S.hold=null; },
  tick(S,dt){
    const h=S.hold; if(!h||S.fl.over) return;
    if(g.mode!=='play') return;
    if(g.moving){ S.hold=null; toast('You let go. The anchor flickers.',1800); return; }
    h.t+=dt; const need=(sxCan('Hearthsong')||sxCan('Emberlight')||g.inv.hearthcoal||g.inv.keeperlantern)?2.6:4;
    if(h.t>=need){ S.hold=null; steady(S,h.k); }
  }
});
function anchorUse(S,k){
  if(S.fl['a'+k]){ say('',['The anchor is steady. It hums '+VERSES[k-1]+'.']); return; }
  S.hold={k:k,t:0}; toast('Hold still... think '+VERSES[k-1]+'.',2600);
}

/* =========================================================
   CHAPTER 20: THE NAME
   ========================================================= */
S2.ch.c20={route:'both',title:'The Name',sub:'Whose child are you?',
  intro:['The Old Tree has stopped shaking. In the hollow, in the clearing, around the ring, nobody is speaking.','On a litter at the foot of the Tree, an old king lies with his eyes open. Beside him, a hermit with a grey face. Behind them, a half-circle of people, red and blue and grey, who walked here on opposite roads and have not noticed that they arrived at the same time.'],
  recap:'The Old Tree asked whether it was safe. You answered.',
  start(){ s2set(0); sxEnter('tree20'); },
  obj(s){ return ['Speak with <b>King Eider</b>, and the others, in the clearing. Then ask the <b>Old Tree</b>.'][s]||''; }
};
function lineup(S){ return S.npcs; }
sxDef('tree20',{name:'The Old Tree',theme:'dream',fx:'dream',dark:0.4,lightR:130,start:[10,9,'up'],
  rows:sxGrid(22,12,[[11,2,'X'],[10,6,'.']]),
  exits:{},
  objs:{X:{name:'The Old Tree',glyph:'oldtree',solid:true,light:true,lightR:150,use:(S)=>{
    if(!S.fl.eider){ say('',['The tree is humming. It is waiting for you to have spoken to the king.']); return; }
    revealScene(S);
  }}},
  npcs:[
    {name:'King Eider',tx:10,ty:6,pal:{body:'#e0ddd0',wing:'#b0ab9a',bill:'#c9b27a'},head:'royal',still:true,talk:(S,n)=>{
      if(!S.fl.eider){ S.fl.eider=1;
        seq([['King Eider',s2fl('wardState')==='gentle'?['I am not dead. I had been so sure I would be. It let go like a hand opening. I am only very, very tired.','You steadied it. I felt every anchor. Thank you.']:['I am not dead. I wish I could say I was surprised. The ward broke the way a great many things break: all at once, and in the wrong order.','I felt it let go. Do not trouble yourself about that.']],
          ['King Eider',['A hundred years ago, on a wall, I spoke a word. Gordamom spoke one too. We did not plan it. We each said the thing we most needed to be true. His opened. Mine closed.','I have never known what his was. I have never had the courage to ask.']],
          ['King Eider',['Ask the Tree. It remembers. Ask it, and listen all the way to the end.']]],()=>{ hudCache.obj=null; });
      } else say('King Eider',['Ask the Tree. I will not interrupt.'],null); }},
    {name:'Elder Cinder',tx:4,ty:8,pal:RED_PALS[2],head:'wizard',still:true,talk:(S,n)=>say('Elder Cinder',['I walked here with Halbeak, in a silence so complete I could hear him thinking. He thinks very loudly, for a man who says so little.','Whatever you say, Detective, say it kindly. We have not had kindness in a long while. We would very much like to learn it.'],null)},
    {name:'Captain Halbeak',tx:17,ty:8,pal:BLUE_PAL,head:'helm',still:true,talk:(S,n)=>say('Captain Halbeak',['I stand by whatever the king decides. And I stand beside whatever you say. I have found I can do both.'],null)},
    {name:'Warden Ruddock',tx:5,ty:3,pal:WARDEN_PAL,head:'helm',still:true,talk:(S,n)=>say('Warden Ruddock',['I voted no. I thought I would feel vindicated. I feel like a man who has been carrying a very heavy thing, and has been told he may put it down.'],null)},
    {name:'Little Poppy',tx:18,ty:3,pal:RED_PALS[3],head:null,scale:0.7,still:true,talk:(S,n)=>say('Little Poppy',['Everyone is being so quiet. Is it a good quiet or a bad quiet? I cannot tell. Mama says sometimes you cannot.'],null)}
  ],
  follow:MALLOW_F,
  onEnter(S){ if(!S.fl.hint){ S.fl.hint=1; sxSay(S,'',['The clearing is silent. The ring of the three hundred is stirring, as a field stirs before rain. The Old Tree is waiting.']); } }
});
function revealScene(S){
  const ans=['nobody\'s child','Gordamom\'s, I think','not sure at all','Mallardia\'s'][s2fl('childAns')]||'not sure';
  cutSeq({story:[['treeHollow'],['wordsOnWall',{seq:['sleepersToTrees','wordFlies']},'hatch'],['threeRoads','treeHollow'],['eiderChains']]},[['The Old Tree',['The hollow opens. It is a voice you know, very close, warm, and very tired. It is Gordamom, and it is also the humming of three hundred ducks.','"Small one. In the dream, I asked you whose child you were. You said: '+ans+'. I let you say it. I did not tell you why I asked."']],
    ['Gordamom',['"On the last night, on the wall, Eider spoke a word. I spoke one too. His was a door closing. Mine was a door opening. His word was \"stay\". Mine was \"shelter\"."','"My word did not go to the three hundred, small one. The three hundred were wood by then. It went out, over the river, to the south, to a place the Edict could not reach, because the Edict only covers the red feather."','"It lay there a hundred years, in the shape of a promise, until it hatched. You woke in a forest, with no past. You were not a yellow duck who found a mystery. You were a mystery that found its own yellow feathers."']],
    ['Gordamom',['"You are my second word. A duck who belongs to no side, because both sides were already in you. A duck the Edict does not apply to. A duck who could walk, unchallenged, into the red town and the king\'s castle and the middle of the Burnt Wood. You were sent to ask one question."','"Is it safe?"']],
    ['King Eider',['(He has been listening, with his eyes shut. They are open now.)','"Shelter. His word was shelter. I have been trying to cage a promise for a hundred years. No wonder the wood would not stay quiet."']]],()=>{ S.fl.revealed=1; finalChoice(S); });
}
function finalChoice(S){
  const keeper=!!s2().keeper;
  const opts=['"It is safe now." Wake them all, at once.','"It will be safe." Rewrite the ward as a door, and keep it.'].concat(keeper?['"It will be tended." Stay, and keep the table.']:[]).concat(['"Let it stay." Leave it as it is.']);
  choose('The Old Tree','The Tree waits. All of them wait. "Is it safe?"',opts,k=>{
    if(k===0) endWake(S);
    else if(k===1) endDoor(S);
    else if(keeper&&k===2) endKeep(S);
    else endStay(S);
  },opts.length-1);
}
function endWake(S){
  const red=s2red(), gr=grudge();
  cutSeq({story:[['youAtTree','humStops'],red?['eiderLetGo']:['eiderCrown'],gr==='forgiven'?[{seq:['wakeLamps','tamHalbeak']},'breeMallow']:gr==='softened'?['orlaCinder','breeMallow']:['waveBreaks','breeMallow'],['poppyWing','morningSong']]},[['',['You say it: "It is safe now."','The word goes into the Tree like a stone into a well. The humming stops. For a moment, the whole clearing is quiet in a way it has not been in a hundred years: the quiet before a breath.']],
    ['',red?['King Eider\'s hand opens on the litter. He has held the door a hundred years, and when it lets go, so does he. He is smiling. Cinder, who has not wept in public in forty years, kneels beside him, and takes his wing, and does not say anything.','"Tell Gordamom," he says, very quietly, "that I never was angry either." He closes his eyes. He does not open them.']:['King Eider sits up on the litter. For the first time in a hundred years, he is breathing without effort. He takes the bent crown off the ground, and looks at it, and sets it in Halbeak\'s hands.','"I was king of a wall. Let someone be king of a door." The Crown passes, that afternoon, not to a captain, but to a council of the Hollow and the Court, seated in the same chairs.']],
    ['',gr==='forgiven'?['The three hundred wake, one by one, like lamps being lit down a long street. Tam sits up, and sees Halbeak, and does not move. Halbeak takes off his helmet. After a long moment, Tam laughs, once, helplessly, and holds out a wing.','Bree opens her eyes, and looks, for a long time, at Mallow. "I did not stop," she says. "I know," says Mallow. "I know. I came."']:gr==='softened'?['The three hundred wake slowly, and not all of them gladly. Some weep. Some turn away. Orla walks the ring until she finds Cinder, and says nothing, and stands there, and Cinder lets her.','Bree opens her eyes, and looks at Mallow. "I did not stop," she says. He says, "I know." It takes the Hollow and the kingdom a generation to learn to share a road. It does.']:['The three hundred wake in a wave, and the wave breaks. Tam is on his feet, and Marl, and Orla, and for an hour the Burnt Wood is a field of shouting. Halbeak\'s line holds, and Ruddock\'s holds beside it, and nobody who was not already in the ring is killed.','At the end of it, the sleepers sit down in the ash, and stay, as if they had been told to. Bree finds Mallow. "I did not stop," she says. He says, "I know."']],
    ['',['Poppy takes your wing, and holds it. "Was that the right word?" she says.','Nobody answers. The Tree is humming a different tune. It is not a lullaby. It is a song for the morning.']]],()=>epilogue('wake'));
}
function endDoor(S){
  const t=s2led('trust'), side=s2led('crown')+s2led('ember'), gr=grudge();
  if(t<4||side<1||gr==='held'){
    const why=gr==='held'?'The Wood still holds its grudge, and will not open a door to someone who has not put it down.':t<4?'Both sides know you, but neither of them trusts you all the way yet. A door needs both hinges.':'Neither the Crown nor the Hollow has vouched for you. A door must be held from both sides.';
    seq([['The Old Tree',['"Rewrite the ward as a door." The voice is gentle. "I would like that very much. But a door must be held from both sides, and the Tree is not yet sure you can be trusted by both."','"'+why+'"','"Choose again. There is time. There is, I think, just enough time."']]],()=>finalChoice(S));
    return;
  }
  cutSeq({story:[['youAtTree','fifthNote'],['fifthNote','keeperBetween'],['eiderRests'],['doorOpens']]},[['',['You say it: "It will be safe."','The Tree is silent, and then, very slowly, the humming changes. The four notes become five. The fifth is a step higher than the rest, and it does not resolve. It leans, like a door ajar.']],
    ['Gordamom',['You are not saying it is safe. You are saying it will be. That is a harder word, small one. It means someone has to keep it.','You will be the Keeper-between. You will not rule either side. You will hold the door, and tell both sides, truthfully, how far open it is.']],
    ['King Eider',['(Eider is sitting up. He is not dying. He is, for the first time in a hundred years, not carrying the whole of it.)','"I will go home. I will rest. I will come back, in a year, and I will be of use. I find that I should like that very much."']],
    ['',['The Old Tree opens. Not a hollow: a door, of old grey wood, with a latch. It stands a hand-width ajar, in the middle of the Burnt Wood. Through the gap, you can hear a lullaby, and a very distant bell.','You are the one who will say how far it opens. It will open further every day it is not abused.']]],()=>{ s2().doorAt=s2now(); epilogue('door'); });
}
function endKeep(S){
  const t=s2led('trust'), tbl=(s2().k3||{}).tbl, gr=grudge();
  if(tbl!=='agreed'||t<3||gr==='held'){
    const why=gr==='held'?'The Wood still holds its grudge. A table cannot be laid in front of it.':tbl!=='agreed'?'The table in the hermit\'s house did not hold. A Keeper keeps what held.':'Mallow has not yet seen enough of you to let you sit in the third chair.';
    seq([['The Old Tree',['"Tended." The voice is warm. "I would like that. But a Keeper must have a table that held, and the road you have walked is not yet the right shape."','"'+why+'"','"Choose again. There is time."']]],()=>finalChoice(S));
    return;
  }
  cutSeq({story:[['youAtTree','cupDown'],['ringOfChairs'],['mallowArrives'],['ringOfChairs']]},[['',['You say it: "It will be tended."','The humming stops. The silence is a different kind. It is the quiet of a room in which someone has just set down a cup.']],
    ['Gordamom',['Tended. Not safe. Not opened. Tended. A word that asks for a person, and a person that asks for a day, and a day, and a day.','I have never heard a word so patient. I think I will sleep, small one. Properly. For the first time since the wall.']],
    ['Hermit Mallow',['(He is standing at the edge of the clearing, with a kettle in one wing and a loaf of bread in the other, as if he has just arrived at a party.)','I do not need to be told what to do with a table. I only needed someone to tell me it was allowed.']],
    ['',['The Old Tree does not open. It does not stay shut. It stands in the clearing with a ring of chairs round it, and a kettle, and an open book on the roots, and each morning someone sits in a chair and listens.','You are not the Keeper. You are the first guest.']]],()=>epilogue('keeper'));
}
function endStay(S){
  cutSeq({story:[['youAtTree','lightDims'],['lightDims'],['wardTakesEider'],[{seq:['birdsRows','mallowStays']}]]},[['',['You say it: "Let it stay."','The Tree is quiet for a long time. Then, very softly, the humming resumes, and settles, and the light in the clearing dims by a shade.']],
    ['Gordamom',['"Yes. It is easier. Everyone is safe, so long as no one asks."','"I will not argue. I have argued for a hundred years. I am so very tired of arguing."']],
    ['King Eider',['(He does not say anything. He closes his eyes. The ward takes him, gently, again, the way a hand takes a hand it has held a long time.)']],
    ['',['The sleepers are sleeping. The ward is held. The kingdom is quiet, and the Hollow is quiet, and every night, at the edge of the woods, the birds sit in rows and look the same way. Mallow sits down at the foot of the Tree, beside his mother, and stays.']]],()=>epilogue('stay'));
}
function epilogue(kind){
  const q=s2();
  const pages={wake:['The Burnt Wood is green by spring. It takes, as these things do, a long time.','The Hollow and the kingdom open a road between them, by the old route, and call it, because nobody can agree on anything else, the Lantern Road.','Poppy grows up to be the Keeper of the First Hearth. Mallow lives in his mother\'s house, with the hearth lit. Nobody ever finds out how long the lullaby was, because nobody ever finishes it. It simply stops being sung in the dark.'],
    door:['The door is opened a hand-width, and then two, and then, over the winter, a pace. Red ducks cross to the kingdom, in ones and twos, and are looked at, and are not turned back.','The sleepers sit up within the week, and are fully themselves by the first frost, with a bell. Every one of them is told, by someone, what has happened, in the right order.','You keep the door. You are neither red nor blue. You are the one who says. It is, you find, a very quiet kind of power.'],
    keeper:['The Old Tree has a ring of chairs. Nobody has ever agreed on who put them there.','The sleepers sit up within the week and come back to themselves over a season, each with a cup of something warm and a person who stayed. Nobody tells anyone what to feel.','The Keeper\'s Table is a place. It is a habit. It is a kettle. Whoever comes is made welcome; whoever stays is given a chair.'],
    stay:['The kingdom is quiet. The Hollow is quiet. The ward holds. In a hundred years, someone will come to ask again.','You walk away, down the road, and nobody follows. Behind you, a long way off, the Tree is humming a lullaby. It is the first verse. There was never a second.']}[kind];
  const t={wake:['Epilogue','It is safe now.'],door:['Epilogue','It will be safe.'],keeper:['Epilogue','It will be tended.'],stay:['Epilogue','Let it stay.']}[kind];
  q.ending=kind; q.done.c20=1;
  epiCard('EPILOGUE',t[1],'Whose child are you?',pages,'both',()=>{
    hudCache.obj=null; sxLeave(KX-66,KY-61);
    if(kind==='stay'){ q.ch='end'; toast('The story ends here. The Wood is quiet.',5200); }
    else { q.ch='end'; if(S2.ch.c21) S2.begin('c21'); else toast('The story is told. The world goes on.',5200); }
  });
}
/* the afterlife: what the world looks like once the story is over */
S2.prop({id:'afterdoor',k:[-66,-60],glyph:'star',col:'#ffe9a8',when:()=>{ const q=s2(); return q.ch==='end'&&q.ending; },mark:'!',use(){
  const q=s2(), days=Math.floor((s2now()-(q.doorAt||s2now()))/24);
  if(q.ending==='door'){
    const line=days<1?'The door stands a hand-width ajar. Through the gap you can hear the lullaby, and, far off, a bell.':days<4?'The door is open two hands. A small red duck has come through, and been looked at, and been given a pear.':days<8?'The door is open a pace. Halbeak and Ruddock are standing on opposite sides of it, arguing, quite happily, about who will hold it for the next hour.':'The door is open wide. The Burnt Wood is green at the edges. You can see, through it, a road, and on it, ducks of every colour, walking both ways.';
    say('The Door',['It has been '+days+' day'+(days===1?'':'s')+' since you said it.',line]);
  } else if(q.ending==='wake') say('',['The Burnt Wood is green at the edges. A very old duck is teaching a very small duck a song.']);
  else say('',['The Old Tree is humming. Nobody has asked it anything today.']);
}});
{
  const _so=storyObjective;
  storyObjective=function(){
    const q=g.story&&g.story.s2;
    if(q&&q.ch==='end'){ return ({keeper:'The Table is laid. The Tree has a ring of chairs. (Thank you for playing.)',wake:'The Burnt Wood is waking, and the road is open. The story goes on, in the world you made.',door:'The door is open a little further every day. Visit it in the Burnt Wood. (Thank you for playing.)',stay:'It is quiet. The Tree is humming. (Thank you for playing.)'})[q.ending]||_so(); }
    return _so();
  };
  const _je=journalExtra;
  journalExtra=function(sec,line){
    _je(sec,line);
    const q=g.story&&g.story.s2; if(!q||q.ch!=='end') return;
    sec('The End');
    line(({keeper:'You said "It will be tended." The table held, and a ring of chairs was set.',wake:'You said "It is safe now." The sleepers woke, and a road was made.',door:'You said "It will be safe." You keep the door between the Hollow and the kingdom.',stay:'You said "Let it stay." The Wood is quiet.'})[q.ending],'jdim');
    if(q.fl.grudge) line('The grudge was: '+q.fl.grudge+'.','jdim');
  };
}
