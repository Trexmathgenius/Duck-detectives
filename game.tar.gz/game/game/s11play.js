'use strict';
/* ===== v1.26: GOALS, VARIETY, A LIVING LINK TO THE MYSTERY, AND EASIER HANDS =====
   Everything here wraps older code; nothing old was removed. Exposes window.D10.*
   1. Seeded fate: foraging, digging and fishing are pinned to the place (plant, tile, cast) so a seed gives the same luck.
   2. Aims (long goals with perks) and Daily Commissions (three small jobs a day, seeded) so there is always a reason to play.
   3. Job twists (Rush / Meticulous / Festival) and a streak bonus; fishing hotspots, biome fish and reel styles.
   4. The sandbox feeds the mystery: ranked townsfolk share rumours of unstudied Dark Trees, and the Hollowhum Draught
      lets you feel the way to one.
   5. Controls: Space/Enter/Backspace, optional WASD, a Controls page (?), on-screen buttons, click to advance, tap-to-reel.
   6. A top bar that hides while you walk, and a rod that re-strings itself in any town. */
(function(){
'use strict';
const D10=window.D10=window.D10||{};
const ST=D10.settings||(D10.settings={seen:{}});
const safe=(f,d)=>{ try{ return f(); }catch(e){ return d; } };
const stageEl=document.getElementById('stage');
const $q=id=>document.getElementById(id);

/* ---------- state ---------- */
const X=()=>{ const s=g.story||(g.story={}); const x=s.x11||(s.x11={}); if(!x.st) x.st={}; if(!x.aims) x.aims={}; if(!x.casts) x.casts={}; if(!x.rum) x.rum={}; if(!x.streak) x.streak=0; return x; };
const hstr=s=>{ let h=2166136261; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619); } return h|0; };

/* ================= 1. seeded places ================= */
{
  const _wf=wlForage;
  wlForage=function(tg){
    const w=WD(), before=(w.stats&&w.stats.forage)||0;
    const r=withRng(rndKey(tg.tx,tg.ty,77),()=>_wf.call(this,tg));
    if(((w.stats&&w.stats.forage)||0)>before){ const st=X().st, cat=WL_TILECAT[tg.t]; if(cat) st['c_'+cat]=(st['c_'+cat]||0)+1; if(WL_NIGHT()) st.fNight=(st.fNight||0)+1; }
    return r;
  };
  const _wd=wlDigAt;
  wlDigAt=function(x,y,k){
    const w=WD(), key=x+','+y, was=w.dug[key]===g.day;
    const r=withRng(rndKey(x,y,g.day,78),()=>_wd.call(this,x,y,k));
    if(!was&&w.dug[key]===g.day){ const s=X().st; s.dig=(s.dig||0)+1; }
    return r;
  };
}

/* ================= 2. fishing: places, biomes, reel styles ================= */
const REEL=[['steady',1,1,0.4,1,''],['thrasher',1.35,1.05,0.2,1.4,'A thrasher! It fights hard.'],['diver',1.15,0.85,0.2,1.4,'Something big, and deep.'],['drifter',0.8,1.25,0.2,0.9,'A lazy drifter.']];
function reelFor(tx,ty,n){ const r=((hash(tx,ty,n*13+6601)*1e6)%1e6)/1e6; let a=0; for(const v of REEL){ a+=v[3]; if(r<a) return v; } return REEL[0]; }
{
  const _sf=startFishing;
  startFishing=function(){
    try{
      const v=DIRV[g.dir], tx=Math.floor((g.px+v.x*14)/TS), ty=Math.floor((g.py-6+v.y*14)/TS);
      const x=X(), key=tx+','+ty, n=(x.casts[key]||0);
      const wp=wlTile(), b=safe(()=>wlBiomeAt(wp.x,wp.y),null)||safe(()=>wlBiomeAt(tx,ty),null);
      const rv=reelFor(tx,ty,n);
      Object.assign(FISH_CTX,{tx:tx,ty:ty,n:n,bio:b?b.id:null,hot:hash(tx,ty,5511)<0.14,rare:rv[4]*(safe(()=>D10.carry('tacklebox'),false)?1.2:1),reel:rv});
      if((XS().rodWear||0)<rodMax()){ x.casts[key]=n+1; const keys=Object.keys(x.casts); if(keys.length>400) delete x.casts[keys[0]]; }
      if(FISH_CTX.hot) toast('The water ripples here. Rare fish like this spot.',2600);
    }catch(e){ console.warn('fish ctx',e); }
    return _sf();
  };
  const _fr=fishResult;
  fishResult=function(S){
    const t0=Object.values(XC().fish).reduce((a,b)=>a+b,0);
    const r=withRng(rndKey(FISH_CTX.tx,FISH_CTX.ty,FISH_CTX.n,79),()=>_fr(S));
    if(Object.values(XC().fish).reduce((a,b)=>a+b,0)>t0&&(g.clock>=20||g.clock<5)){ const st=X().st; st.fishNight=(st.fishNight||0)+1; }
    return r;
  };
  const _fi=MG.fish.init;
  MG.fish.init=function(s){
    _fi.call(this,s);
    const rv=FISH_CTX.reel||REEL[0];
    s.spd*=rv[1]; s.band*=rv[2]*(safe(()=>D10.carry('tacklebox'),false)?1.12:1); s.vnote=rv[5]; s.lift=false;
  };
  const _fp=MG.fish.press;
  MG.fish.press=function(s,k){ const was=s.ph; _fp.call(this,s,k); if(was==='bite'&&s.ph==='reel'&&s.vnote) s.msg=s.vnote; };
  /* any town re-strings a worn line for free */
  let lastTown=null;
  setInterval(()=>{
    if(g.mode!=='play'||g.scene!=='world') return;
    const tk=g.curTown||null;
    if(tk&&tk!==lastTown){ const w=XS().rodWear||0; if(w>=10){ XS().rodWear=0; toast('A townduck re-strings your fishing line, free of charge.',2800); } }
    lastTown=tk;
  },1000);
  const _oc=openCounter;
  openCounter=function(){ const w=XS().rodWear||0; if(w>=10){ XS().rodWear=0; toast('The shopkeeper re-strings your line for free.',2400); } return _oc.apply(this,arguments); };
}

/* ================= 3. jobs: twists and streaks ================= */
const TWISTS=[
  {id:'steady',w:0.5,name:'',say:''},
  {id:'rush',w:0.2,name:'Rush',say:'Rush job: everything is faster. +40% bonus pay.',f:0.4},
  {id:'careful',w:0.15,name:'Meticulous',say:'Meticulous client: score 8 or more for +80% bonus pay.',f:0.8},
  {id:'festival',w:0.15,name:'Busy day',say:'Busy day in town: +30% bonus pay.',f:0.3}
];
function twistFor(title){
  const r=((hash(g.day,hstr(title+(g.curTown||'')),6611)*1e6)%1e6)/1e6; let a=0;
  for(const t of TWISTS){ a+=t.w; if(r<a) return t; } return TWISTS[0];
}
const isJob=t=>{ if(!t||t==='Go Fishing') return false; if(MG_BY_TITLE[t]) return true; return safe(()=>ODD_JOBS.indexOf(t)>=0,false); };
{
  const _sm=startMini;
  startMini=function(o){
    if(!o||!o.onDone||!isJob(o.title)) return _sm(o);
    const tw=twistFor(o.title), od=o.onDone;
    o.twist=tw.id;
    o.onDone=function(S){
      od(S);
      const x=X();
      const kind=safe(()=>ODD_JOBS.indexOf(o.title)>=0,false)?'odd':(safe(()=>Object.values(JOBS).some(j=>j[0]===o.title),false)||(D10.altTitles&&D10.altTitles.has(o.title)))?'shifts':'events';
      if(S>=6){ x.st.jobs=(x.st.jobs||0)+1; x.st[kind]=(x.st[kind]||0)+1; x.streak++; } else x.streak=0;
      if(S>=9) x.st.top=(x.st.top||0)+1;
      let bonus=0; const parts=[];
      if(tw.f&&S>=3&&(tw.id!=='careful'||S>=8)){ const b=Math.round((2+S*0.7)*tw.f); bonus+=b; parts.push(tw.name+' +'+b); }
      if(x.streak>=2){ const b=Math.min(5,x.streak-1); bonus+=b; parts.push('streak x'+x.streak+' +'+b); }
      if(bonus>0){ g.crumbs+=bonus; coin(); setTimeout(()=>toast('Bonus: '+parts.join(', ')+' crumbs.',2800),700); }
    };
    const r=_sm(o);
    if(tw.say){ safe(()=>{ if(el.miSay&&g.mode==='mini') el.miSay.textContent=tw.say; const ms=$q('mgSay'); if(ms&&g.mode==='mg') ms.textContent=tw.say; }); setTimeout(()=>toast(tw.say,3200),300); }
    return r;
  };
  const _mr=miniRound;
  miniRound=function(){ _mr(); const m=g.mini; if(m&&m.o&&m.o.twist==='rush'){ m.spd*=1.25; m.zw*=0.85; } };
  const _mu=mgUpdate;
  mgUpdate=function(dt){ if(mgs&&mgs.o&&mgs.o.twist==='rush') dt*=1.25; return _mu(dt); };
}

/* ================= 4. stats, aims and commissions ================= */
const fishTotal=()=>safe(()=>Object.values(XC().fish).reduce((a,b)=>a+b,0),0);
function stats(){
  const x=X(), st=x.st, w=safe(()=>WD(),{stats:{},seen:{}}), c=safe(()=>XC().fish,{})||{};
  let rank=0; for(const k in g.rep) rank=Math.max(rank,rankOf(g.rep[k]||0));
  const sum=f=>Object.keys(c).reduce((a,k)=>a+(f(k)?(c[k]||0):0),0);
  const made=safe(()=>BS().made,{});
  const tier1=Object.keys(made).reduce((a,k)=>{ const r=BR_RECIPES.find(q=>q.id===k); return a+((r&&r.tier>=1)?made[k]:0); },0);
  const o={
    fish:sum(()=>true), rareFish:sum(k=>FISHBY[k]&&FISHBY[k].rare), bioFish:sum(k=>FISHBY[k]&&FISHBY[k].bio), fishNight:st.fishNight||0,
    species:Object.keys(c).filter(k=>!(FISHBY[k]&&FISHBY[k].junk)).length,
    forage:(w.stats&&w.stats.forage)||0, fNight:st.fNight||0, kinds:Object.keys(w.seen||{}).length,
    dig:st.dig||0, jobs:st.jobs||0, shifts:st.shifts||0, odd:st.odd||0, events:st.events||0, top:st.top||0,
    brew:safe(()=>Object.values(made).reduce((a,b)=>a+b,0),0), brewT1:tier1,
    sold:safe(()=>XS().fishSold||0,0), clues:g.clues||0, towns:g.towns?g.towns.size:0, explored:g.explored||0, rank:rank
  };
  for(const k of ['flower','bush','mush','tree','rock','stump']) o['c_'+k]=st['c_'+k]||0;
  return o;
}
const AIMS=[
 {id:'angler',name:'Angler',stat:'fish',unit:'fish landed',tiers:[5,25,75],pay:[15,40,100],perk:'The fishing line lasts 10 more casts per star.'},
 {id:'species',name:'Ichthyologist',stat:'species',unit:'kinds of fish',tiers:[4,9,16],pay:[20,45,90],perk:'Each biome has its own fish. Travel to find them all.'},
 {id:'seller',name:'Fishmonger\'s Friend',stat:'sold',unit:'fish sold',tiers:[10,50,150],pay:[15,40,90]},
 {id:'gatherer',name:'Gatherer',stat:'forage',unit:'plants gathered',tiers:[20,100,300],pay:[15,45,110]},
 {id:'digger',name:'Digger',stat:'dig',unit:'holes dug',tiers:[5,25,60],pay:[15,40,90]},
 {id:'jobber',name:'Hard Worker',stat:'jobs',unit:'jobs and events scored 6+',tiers:[8,40,120],pay:[15,45,120],perk:'Every job pays 5% more per star.'},
 {id:'brewer',name:'Brewmaster',stat:'brew',unit:'potions brewed',tiers:[1,8,30],pay:[20,50,120]},
 {id:'wanderer',name:'Wanderer',stat:'towns',unit:'towns found',tiers:[2,6,14],pay:[15,40,100]},
 {id:'liked',name:'Well Liked',stat:'rank',unit:'best town rank (1 Newcomer … 5 Town Legend)',tiers:[1,3,5],pay:[10,40,150],perk:'Towns that know you ask you for more, and trust you with more.'},
 {id:'sleuth',name:'Dark-Tree Sleuth',stat:'clues',unit:'Dark Trees studied',tiers:[3,8,12],pay:[20,50,100],perk:'Part of the mystery. Brew a Hollowhum Draught, or ask a well-liked townduck, to find the next one.'}
];
D10.aimTier=id=>safe(()=>X().aims[id]||0,0);
{
  const _pm=payMul;
  payMul=function(t){ return _pm(t)+0.05*D10.aimTier('jobber'); };
}
const mult=()=>1+0.08*safe(()=>D10.nestLevel('study'),0);
const hasRod=()=>!!g.inv.fishrod, hasBook=()=>!!g.inv.recipebook, hasShovel=()=>!!g.inv.shovel;
const easy=new Set(['forage','jobs','explored','c_flower','c_bush','c_mush','shifts','odd']);
const CAT_T={flower:['Pick {n} flowers','The window boxes are bare. Flowers, please.','A wedding is coming, and I am short on petals.'],
  bush:['Gather berries from {n} bushes','The pie needs berries. The pie always needs berries.','My jam jars are lined up and empty.'],
  mush:['Gather {n} mushrooms','Soup night is tomorrow. I need caps.','Somebody told me mushrooms cure everything.'],
  tree:['Chop down {n} trees (axe)','The woodpile is a sad little heap.','The stove is hungry.'],
  rock:['Break up {n} rocks (pickaxe)','I am building a wall, one sulky stone at a time.','The path needs gravel.'],
  stump:['Chop up {n} stumps (axe)','Old stumps make good kindling, and I have none.','The shed roof needs shingles. Do not ask.']};
const POOL=[
 {id:'fish',k:'fish',t:n=>'Land '+n+' fish',lo:2,hi:5,per:5,need:hasRod,lines:['The pond has been quiet for my pie. Fish would help.','Supper is thin tonight. Bring something with fins.','My cat has opinions about fish. Help me meet them.']},
 {id:'rare',k:'rareFish',t:n=>'Land '+n+' rare fish',lo:1,hi:2,per:16,need:hasRod,lines:['A guest is coming who only eats the good fish.','I have a bet with the baker. Rare fish only.']},
 {id:'bio',k:'bioFish',t:n=>'Land '+n+' fish that live only in one biome',lo:1,hi:1,per:22,need:hasRod,lines:['They say each biome hides its own fish. I would like to see one.','The cartographer swears the tundra has a fish no other water has.']},
 {id:'fnight',k:'fishNight',t:n=>'Land '+n+' fish after dark',lo:2,hi:3,per:9,need:hasRod,lines:['The best bite is after the moon is up. So I hear.','I want a night fish. Do not ask why.']},
 {id:'forage',k:'forage',t:n=>'Gather '+n+' plants',lo:6,hi:12,per:2,lines:['The brewery is out of everything.','I am stocking the shelf for winter.','Anything green, anything fresh.']},
 {id:'fn',k:'fNight',t:n=>'Gather '+n+' plants after dark',lo:4,hi:7,per:3,lines:['Some things only open at night. I want those.','Night flowers sell for double. Do not tell the day shift.']},
 {id:'kinds',k:'kinds',t:n=>'Find '+n+(n>1?' plant kinds':' plant kind')+' you have never logged',lo:1,hi:3,per:9,lines:['I am writing a field book and I need a new face in it.','Surprise me. Something I cannot name.']},
 {id:'dig',k:'dig',t:n=>'Dig '+n+' holes with your shovel',lo:2,hi:4,per:6,need:hasShovel,lines:['I lost something in the garden. Everywhere in the garden.','Treasure maps are for people with patience. Dig for me.']},
 {id:'jobs',k:'jobs',t:n=>'Score 6 or better on '+n+' jobs or events',lo:2,hi:3,per:7,lines:['Show this town what a hard worker looks like.','I told everyone you were reliable. Prove me right.']},
 {id:'shifts',k:'shifts',t:n=>'Work '+n+(n>1?' shop shifts':' shop shift')+' (6 or better)',lo:1,hi:2,per:9,lines:['The shops are short-handed this week.','A shopkeeper told me you can knead a straight line.']},
 {id:'odd',k:'odd',t:n=>'Do '+n+' odd job'+(n>1?'s':'')+' at the notice board (6 or better)',lo:1,hi:2,per:8,lines:['The notice board is crowded and nobody wants the chores.','The plaza is a mess, and I am the mayor.']},
 {id:'top',k:'top',t:n=>'Score a 9 or better on any job',lo:1,hi:1,per:16,lines:['I want to see perfect work, once, so I know it exists.','Somebody here is a perfectionist. Be them.']},
 {id:'brew',k:'brew',t:n=>'Brew '+n+' potion',lo:1,hi:1,per:26,need:hasBook,lines:['The apothecary is out. A bottle of anything would do.','Whatever is in your satchel, make it into something drinkable.']},
 {id:'brew1',k:'brewT1',t:n=>'Brew a Fine potion (Choice ingredients)',lo:1,hi:1,per:46,need:hasBook,lines:['I will pay properly for a bottle that is properly made.','Fine brews only. The cheap ones taste of the cork.']},
 {id:'sold',k:'sold',t:n=>'Sell '+n+' fish to a market or cafe',lo:3,hi:6,per:4,need:hasRod,lines:['The fishmonger is fishing for fish. Sell to them.','Put a fish on a counter somewhere. Any counter.']},
 {id:'explore',k:'explored',t:n=>'Explore '+n+' new tiles',lo:150,hi:300,per:0.07,lines:['I have a map with a blank corner and it bothers me.','Walk somewhere you have not been and tell me what is there.']},
 {id:'clue',k:'clues',t:n=>'Study a Dark Tree',lo:1,hi:1,per:20,need:()=>(g.clues||0)<12,lines:['Those black trees give me the shivers. Someone should look closely.','Something is wrong with those trees. You would know how to look.']}
];
for(const cat of ['flower','bush','mush','tree','rock','stump']){
  POOL.push({id:'c_'+cat,k:'c_'+cat,t:n=>CAT_T[cat][0].replace('{n}',n),lo:3,hi:6,per:3,lines:CAT_T[cat].slice(1),
    need:cat==='rock'?(()=>!!g.inv.pickaxe):(cat==='tree'||cat==='stump')?(()=>!!g.inv.axe):null});
}
const BIG=[
 {id:'fish',k:'fish',t:n=>'Land '+n+' fish',lo:8,hi:12,need:hasRod},
 {id:'forage',k:'forage',t:n=>'Gather '+n+' plants',lo:40,hi:60},
 {id:'jobs',k:'jobs',t:n=>'Score 6 or better on '+n+' jobs or events',lo:8,hi:12},
 {id:'brew',k:'brew',t:n=>'Brew '+n+' potions',lo:2,hi:3,need:hasBook},
 {id:'clues',k:'clues',t:n=>'Study '+n+' Dark Trees',lo:2,hi:3,need:()=>(g.clues||0)<=9},
 {id:'explored',k:'explored',t:n=>'Explore '+n+' new tiles',lo:600,hi:900},
 {id:'sold',k:'sold',t:n=>'Sell '+n+' fish',lo:10,hi:15,need:hasRod},
 {id:'dig',k:'dig',t:n=>'Dig '+n+' holes',lo:6,hi:10,need:hasShovel},
 {id:'rare',k:'rareFish',t:n=>'Land '+n+' rare fish',lo:3,hi:4,need:hasRod},
 {id:'top',k:'top',t:n=>'Score 9 or better '+n+' times',lo:3,hi:4}
];
const clientName=(salt)=>{ const L=safe(()=>NPC_NAMES,['Pip']); return L[Math.floor(hash(g.day,salt,6655)*L.length)]; };
function makeCommissions(){
  const x=X(), prev=new Set((x.comm&&x.comm.kinds)||[]);
  const pool=POOL.filter(p=>!p.need||safe(p.need,false));
  const order=pool.map((p,i)=>[hash(g.day,i,6633)+(prev.has(p.id)?2:0),p]).sort((a,b)=>a[0]-b[0]).map(a=>a[1]);
  let pick=order.slice(0,4);
  if(!pick.some(p=>easy.has(p.id))){ const e=order.find(p=>easy.has(p.id)); if(e) pick[3]=e; }
  const list=pick.map((p,i)=>{
    const n=p.lo+Math.floor(hash(g.day,i+9,6644)*(p.hi-p.lo+1));
    return {id:p.id,k:p.k,n:n,txt:p.t(n),pay:Math.max(8,Math.round(n*p.per)),who:clientName(i),line:p.lines[Math.floor(hash(g.day,i+3,6666)*p.lines.length)],done:0};
  });
  x.comm={day:g.day,base:stats(),list:list,bonus:0,kinds:list.map(c=>c.id)};
}
function makeBig(){
  const x=X(), wk=Math.floor((g.day-1)/7), pool=BIG.filter(p=>!p.need||safe(p.need,false));
  const order=pool.map((p,i)=>[hash(wk,i,7733),p]).sort((a,b)=>a[0]-b[0]).map(a=>a[1]).slice(0,3);
  const rec=BR_RECIPES.filter(r=>r.tier===1), r=rec[Math.floor(hash(wk,5,7744)*rec.length)];
  const list=order.map((p,i)=>{ const n=p.lo+Math.floor(hash(wk,i+9,7755)*(p.hi-p.lo+1)); return {id:p.id,k:p.k,n:n,txt:p.t(n)}; });
  x.big={week:wk,base:stats(),list:list,paid:0,pay:90+10*Math.min(3,safe(()=>x.aims.liked,0)),potion:r?r.id:null,who:clientName(40)};
}
function prog(base,c){ return Math.max(0,(stats()[c.k]||0)-((base&&base[c.k])||0)); }
const commProgress=c=>prog(X().comm.base,c);
let announced=-1;
function tick(){
  if(g.mode!=='play'||!g.story) return;
  const x=X(), st=stats(), msgs=[], m=mult();
  /* aims */
  for(const a of AIMS){
    let n=x.aims[a.id]||0;
    while(n<a.tiers.length&&st[a.stat]>=a.tiers[n]){ const p=Math.round(a.pay[n]*m); g.crumbs+=p; msgs.push(a.name+' '+'★'.repeat(n+1)+' (+'+p+' crumbs)'); n++; }
    x.aims[a.id]=n;
  }
  /* daily commissions: four on offer, any three earn a bonus */
  if(!x.comm||x.comm.day!==g.day) makeCommissions();
  if(announced!==g.day){ announced=g.day; msgs.push('New commissions are on offer (K)'); }
  let n=0;
  for(const c of x.comm.list){
    if(!c.done&&commProgress(c)>=c.n){ c.done=1; const p=Math.round(c.pay*m); g.crumbs+=p; msgs.push(c.who+': '+c.txt+' done (+'+p+' crumbs)'); }
    if(c.done) n++;
  }
  if(n>=3&&!x.comm.bonus){ x.comm.bonus=1; const p=Math.round(20*m); g.crumbs+=p; msgs.push('Three commissions done: +'+p+' crumbs'); }
  /* the big order: once a week, over many days */
  if(!x.big||x.big.week!==Math.floor((g.day-1)/7)) makeBig();
  if(!x.big.paid&&x.big.list.every(c=>prog(x.big.base,c)>=c.n)){
    x.big.paid=1; const p=Math.round(x.big.pay*m); g.crumbs+=p;
    let extra=''; if(x.big.potion&&ITEMS['p_'+x.big.potion]){ addItem('p_'+x.big.potion); extra=' and a bottle of '+ITEMS['p_'+x.big.potion].name; }
    msgs.push('Big order complete! '+x.big.who+' pays '+p+' crumbs'+extra);
  }
  if(msgs.length){ coin(); let i=0; const next=()=>{ if(i<msgs.length){ toast(msgs[i++],2600); if(i<msgs.length) setTimeout(next,2700); } }; next(); }
}
setInterval(()=>safe(tick),1800);

/* ---------- panels ---------- */
function makePanel(id,title,sub,closeLabel){
  const pan=document.createElement('div'); pan.className='panel xpanel'; pan.id=id; pan.hidden=true;
  pan.innerHTML='<div class="ph"><div><h2></h2><div class="say"></div></div><button class="hb" type="button">'+closeLabel+'</button></div><div class="xbody"></div><div class="pf"><span></span><span>Up/Down scroll &middot; X close</span></div>';
  pan.querySelector('h2').textContent=title; pan.querySelector('.say').textContent=sub;
  stageEl.appendChild(pan);
  return {pan:pan,body:pan.querySelector('.xbody'),say:pan.querySelector('.say'),foot:pan.querySelector('.pf span'),btn:pan.querySelector('.ph button')};
}
const row=(cls,html)=>{ const d=document.createElement('div'); d.className='axrow '+(cls||''); d.innerHTML=html; return d; };
const esc=s=>String(s).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
const AP=makePanel('aimspan','Aims & Commissions','Commissions change every morning. Aims are for the long run.','Close (K)');
function renderAims(){
  const x=X(); if(!x.comm||x.comm.day!==g.day) makeCommissions(); if(!x.big||x.big.week!==Math.floor((g.day-1)/7)) makeBig();
  const st=stats(), b=AP.body, m=mult(); b.innerHTML='';
  const h=document.createElement('h3'); h.textContent='Today\'s commissions'; b.appendChild(h);
  let done=0;
  for(const c of x.comm.list){
    const p=Math.min(c.n,commProgress(c)); if(c.done) done++;
    b.appendChild(row(c.done?'ok':'', '<span class="gdbox">'+(c.done?'✓':'○')+'</span><div><b>'+esc(c.txt)+'</b><div class="ds">'+p+' / '+c.n+' &middot; pays '+Math.round(c.pay*m)+' crumbs</div><div class="ds axquote">'+esc(c.who)+': “'+esc(c.line)+'”</div></div>'));
  }
  b.appendChild(row('', '<span class="gdbox"></span><div class="ds">Do any three of the four for a bonus of '+Math.round(20*m)+' crumbs'+(x.comm.bonus?' (earned)':'')+'. Nothing is lost if you skip one.</div>'));
  const hb=document.createElement('h3'); hb.textContent='This week\'s big order'; b.appendChild(hb);
  for(const c of x.big.list){
    const p=Math.min(c.n,prog(x.big.base,c)), ok=p>=c.n;
    b.appendChild(row(ok?'ok':'', '<span class="gdbox">'+(ok?'✓':'○')+'</span><div><b>'+esc(c.txt)+'</b><div class="ds">'+p+' / '+c.n+'</div></div>'));
  }
  b.appendChild(row(x.big.paid?'ok':'', '<span class="gdbox"></span><div class="ds">'+(x.big.paid?'Paid. A new order arrives next week.':esc(x.big.who)+' pays '+Math.round(x.big.pay*m)+' crumbs'+(x.big.potion&&ITEMS['p_'+x.big.potion]?' and a bottle of '+esc(ITEMS['p_'+x.big.potion].name):'')+' when all three are done. You have all week.')+'</div>'));
  const h2=document.createElement('h3'); h2.textContent='Aims'; b.appendChild(h2);
  for(const a of AIMS){
    const n=x.aims[a.id]||0, nxt=a.tiers[n], cur=st[a.stat]||0;
    const stars='★'.repeat(n)+'☆'.repeat(a.tiers.length-n);
    const info=nxt!==undefined?(Math.min(cur,nxt)+' / '+nxt+' '+a.unit+' &middot; next star pays '+Math.round(a.pay[n]*m)+' crumbs'):'Complete. '+cur+' '+a.unit+'.';
    const pct=nxt!==undefined?Math.min(100,Math.round(cur/nxt*100)):100;
    b.appendChild(row(n===a.tiers.length?'ok':'', '<span class="gdbox axstar">'+stars+'</span><div><b>'+esc(a.name)+'</b><div class="ds">'+info+'</div><div class="axbar"><i style="width:'+pct+'%"></i></div>'+(a.perk?'<div class="ds axperk">'+esc(a.perk)+'</div>':'')+'</div>'));
  }
  AP.say.textContent=done+' of '+x.comm.list.length+' commissions done today'+(m>1?'  (Study Nook +'+Math.round((m-1)*100)+'%)':'');
}
D10.openAims=function(){ if(g.mode!=='play') return; g.mode='aims'; AP.pan.hidden=false; renderAims(); AP.body.scrollTop=0; blip(); };
function closeAims(){ if(g.mode!=='aims') return; g.mode='play'; AP.pan.hidden=true; blip(); }
PANEL_CLOSE.aims=()=>closeAims();
AP.btn.addEventListener('click',closeAims);

const HP=makePanel('helppan','Controls','Everything you can press, in one place.','Close (?)');
function renderHelp(){
  const w=ST.keys==='wasd', mv=w?'W A S D or arrows':'Arrow keys', dig=w?'F':'D';
  const sec=(t,items)=>{ const h=document.createElement('h3'); h.textContent=t; HP.body.appendChild(h); items.forEach(i=>HP.body.appendChild(row('', '<span class="gdkey">'+esc(i[0])+'</span><div>'+esc(i[1])+'</div>'))); };
  HP.body.innerHTML='';
  sec('Always',[[mv,'Walk. Hold for a steady pace.'],['Z, Space or Enter','Interact, talk, confirm, gather, cast, use the held item.'],['X, Esc or Backspace','Back, close, cancel. Esc also opens the pause menu.'],['1 – 0','Hold the item in that hotbar slot. Z then uses it.']]);
  sec('Menus',[['I','Pack'],['J','Journal'],['M','Map (H sets home, + and - zoom)'],['G','Field Guide: what to try next'],['K','Aims and daily commissions'],['L','Collection Log'],['B','Brewer\'s recipe book (needs the book)'],['N','Your Nest (beside home)'],['Y','Who You Are Becoming'],['T','Waymarks: lit places you have walked to'],...(w?[]:[['S','Show the world seed (copied to the clipboard)']]),['Esc or P','Pause, settings, save and quit'],['?  or  F1','This page']]);
  sec('In the world',[[dig,'Dig with a shovel (face open ground)'],['Q and E','Choose a spell'],['C','Cast the chosen spell'],['Tab','Show every spell']]);
  sec('Fishing',[['Z','Hold a rod, face water and press Z to cast. Press Z when the bobber dips.'],['Hold Z','Lift the hook; let go to sink it. Keep it on the fish. (Settings can make this a tap.)']]);
  sec('No keyboard?',[['Buttons','Settings > On-screen buttons shows a pad. You can also click the top bar, dialogue, choices and mini-games.']]);
  HP.say.textContent='Change movement keys, the reel, and the top bar in the pause menu: Settings.';
}
D10.openHelp=function(){ if(g.mode!=='play') return; g.mode='help'; HP.pan.hidden=false; renderHelp(); HP.body.scrollTop=0; blip(); };
function closeHelp(){ if(g.mode!=='help') return; g.mode='play'; HP.pan.hidden=true; blip(); }
PANEL_CLOSE.help=()=>closeHelp();
HP.btn.addEventListener('click',closeHelp);
{
  const _p=press;
  press=function(k){
    if(g.mode==='aims'){ if(k==='x'||k==='aims') closeAims(); else if(k==='down') AP.body.scrollTop+=60; else if(k==='up') AP.body.scrollTop-=60; return; }
    if(g.mode==='help'){ if(k==='x'||k==='help') closeHelp(); else if(k==='down') HP.body.scrollTop+=60; else if(k==='up') HP.body.scrollTop-=60; return; }
    if(g.mode==='play'&&k==='aims'){ D10.openAims(); return; }
    if(g.mode==='play'&&k==='help'){ D10.openHelp(); return; }
    _p(k);
  };
}
/* More-menu buttons */
{
  const btns=document.querySelector('.hud .btns');
  if(btns){
    const mk=(id,txt,fn)=>{ const b=document.createElement('button'); b.className='hb'; b.type='button'; b.id=id; b.textContent=txt; b.addEventListener('click',e=>{ e.currentTarget.blur(); fn(); }); btns.appendChild(b); };
    mk('bAims','Aims (K)',()=>D10.openAims());
    mk('bHelp','Controls (?)',()=>D10.openHelp());
  }
}
safe(()=>{ D10.tips.push({id:'t_aims',when:()=>g.day>=2&&!!g.flags.shop,title:'Aims & commissions',text:'Press K for three small commissions each morning and long-term aims. They pay crumbs, and some give perks.'}); });

/* ================= 5. the mystery in the sandbox ================= */
function darkNearest(R){
  const px=Math.floor(g.px/TS), py=Math.floor((g.py-2)/TS); let best=null;
  for(let dy=-R;dy<=R;dy++) for(let dx=-R;dx<=R;dx++){
    const d=Math.hypot(dx,dy); if(best&&d>=best.d) continue; if(d>R) continue;
    const x=px+dx, y=py+dy;
    if(tileAt(x,y)===T.DARK&&!g.inspected.has(x+','+y)) best={d:d,dx:dx,dy:dy};
  }
  return best;
}
D10.darkNearest=darkNearest;
{
  const _ck=chatKeeper;
  chatKeeper=function(b,t){
    let extra=null;
    safe(()=>{
      const rk=townRank(t), x=X();
      if(rk<1||x.rum[t.key]===g.day||g.scene!=='world'&&g.scene!==undefined&&!g.curTown) return;
      const n=darkNearest(70); x.rum[t.key]=g.day;
      if(!n){ extra=['They say the odd trees near here have all been looked at, by somebody. Perhaps you.']; return; }
      const dir=wlDir(n.dx,n.dy);
      extra=[rk>=3?'Between us: some trees '+dir+' of here, about '+Math.round(n.d)+' waddles off, have gone black and quiet. Nobody will walk near them. You might.'
                  :'People say the trees to the '+dir+' have gone strange. I would not know. You look like someone who asks.'];
    });
    if(!extra) return _ck(b,t);
    const prev=say;
    say=function(n,p,e){ say=prev; return prev(n,(p||[]).concat(extra),e); };
    try{ _ck(b,t); } finally{ say=prev; }
  };
}
const humEl=document.createElement('div'); humEl.id='humArrow'; humEl.hidden=true; stageEl.appendChild(humEl);
let humNear=null, humAt=0;
setInterval(()=>safe(()=>{
  const on=g.story&&g.story.x11&&g.story.x11.humUntil>fxNow()&&g.scene==='world'&&(g.mode==='play');
  if(!on){ humEl.hidden=true; return; }
  const now=performance.now();
  if(now-humAt>2500){ humAt=now; humNear=darkNearest(60); }
  humEl.hidden=false;
  const n=humNear;
  humEl.textContent=n?'Hum '+wlArrow(n.dx,n.dy)+'  '+wlDir(n.dx,n.dy)+', about '+Math.max(1,Math.round(n.d))+' waddles':'The hum is faint. No unstudied tree within 60 waddles.';
}),400);

/* ================= 6. hands: keys, buttons, mouse ================= */
const INPUTISH=/^(INPUT|TEXTAREA|SELECT|BUTTON|A)$/;
D10.applyKeys=function(){
  const w=ST.keys==='wasd';
  for(const k of ['w','W','a','A','f','F']) delete KEYMAP[k];
  if(w){ KEYMAP.w=KEYMAP.W='up'; KEYMAP.a=KEYMAP.A='left'; KEYMAP.s=KEYMAP.S='down'; KEYMAP.d=KEYMAP.D='right'; KEYMAP.f=KEYMAP.F='d'; }
  else { KEYMAP.s=KEYMAP.S='s'; KEYMAP.d=KEYMAP.D='d'; }
  for(const k of ['up','down','left','right','d','s']) keys[k]=false;
  { const sb=$q('bSeed'); if(sb) sb.textContent=w?'Seed':'Seed (S)'; }   /* in WASD mode S walks down, so the button must not claim it */
  fixTip();
};
KEYMAP.k='aims'; KEYMAP.K='aims'; KEYMAP['?']='help'; KEYMAP.F1='help';
function fixTip(){
  const t=$q('keysTip'); if(!t) return;
  let s=t.textContent;
  if(ST.keys==='wasd'&&!/WASD/.test(s)) s=s.replace(/^Arrows/,'WASD / arrows');
  if(ST.keys!=='wasd') s=s.replace(/^WASD \/ arrows/,'Arrows');
  s=s.replace(/[DF] dig/,ST.keys==='wasd'?'F dig':'D dig');
  if(!/K aims/.test(s)) s+=' · K aims · ? help';
  if(s!==t.textContent) t.textContent=s;
}
setInterval(()=>safe(fixTip),2000);
D10.applyKeys();
window.addEventListener('keydown',e=>{
  if(e.target&&INPUTISH.test(e.target.tagName)) return;
  if(e.ctrlKey||e.metaKey||e.altKey) return;
  let k=null;
  if(e.key===' '||e.key==='Enter') k='z'; else if(e.key==='Backspace') k='x';
  if(!k) return;
  e.preventDefault();
  if(!e.repeat) press(k);
  keys[k]=true;
});
window.addEventListener('keyup',e=>{ if(e.key===' '||e.key==='Enter') keys.z=false; else if(e.key==='Backspace') keys.x=false; });

/* on-screen pad */
const pad=document.createElement('div'); pad.id='xpad'; pad.hidden=true;
pad.innerHTML='<div class="xdp"><button data-k="up" type="button">▲</button><button data-k="left" type="button">◀</button><button data-k="right" type="button">▶</button><button data-k="down" type="button">▼</button></div><div class="xab"><button data-k="x" type="button">X</button><button data-k="z" type="button">Z</button></div>';
stageEl.appendChild(pad);
const DIRS=['up','down','left','right'];
pad.querySelectorAll('button').forEach(b=>{
  const k=b.dataset.k;
  b.addEventListener('contextmenu',e=>e.preventDefault());
  b.addEventListener('pointerdown',e=>{ e.preventDefault(); try{ b.setPointerCapture(e.pointerId); }catch(_){} b.classList.add('on'); if(DIRS.includes(k)) g.faceKey=k; press(k); keys[k]=true; if(AC&&AC.state==='suspended') AC.resume(); });
  const up=()=>{ b.classList.remove('on'); keys[k]=false; };
  b.addEventListener('pointerup',up); b.addEventListener('pointercancel',up); b.addEventListener('lostpointercapture',up);
});
D10.padOn=()=>ST.pad===null||ST.pad===undefined?safe(()=>window.matchMedia('(pointer:coarse)').matches,false):!!ST.pad;
D10.applyPad=()=>{ pad.hidden=!D10.padOn(); };
D10.applyPad();

/* clicking works too */
{
  const dlg=$q('dialog'); if(dlg) dlg.addEventListener('click',e=>{ if(g.mode==='dialog'&&!e.target.closest('.choices')) press('z'); });
  const mini=$q('mini'); if(mini) mini.addEventListener('pointerdown',e=>{ if(g.mode==='mini'&&!e.target.closest('button')) press('z'); });
  const mg=$q('mg'); if(mg) mg.addEventListener('pointerdown',e=>{ if(g.mode==='mg'&&!e.target.closest('button')){ keys.z=true; press('z'); } });
  window.addEventListener('pointerup',()=>{ if(g.mode==='mg') keys.z=false; });
}

/* ================= 7. a top bar that gets out of the way ================= */
{
  const hud=$q('hud'); let lastAct=performance.now(), lastCrumbs=-1;
  const wake=()=>{ lastAct=performance.now(); };
  stageEl.addEventListener('pointermove',e=>{ const r=stageEl.getBoundingClientRect(); if(e.clientY-r.top<110) wake(); });
  stageEl.addEventListener('pointerdown',wake);
  window.addEventListener('keydown',e=>{ const k=KEYMAP[e.key]; if(!k||DIRS.includes(k)) return; wake(); });
  setInterval(()=>safe(()=>{
    if(!hud) return;
    if(g.crumbs!==lastCrumbs){ if(lastCrumbs>=0) wake(); lastCrumbs=g.crumbs; }
    const more=document.querySelector('.moremenu');
    const hide=ST.hud!=='always'&&g.mode==='play'&&performance.now()-lastAct>3500&&!(more&&!more.hidden);
    hud.classList.toggle('autohide',hide);
    if(g.mode!=='play') wake();
  }),300);
}
})();
