'use strict';
/* ===== BEFORE THE STORY (v1.22) =====
   Chapters 1 to 4 were the game's strongest writing and the least connected to the rest.
   This layer (a) records the few answers that reveal who you are before the war starts,
   (b) gives the hermit scene and the king's dinner a real choice, since the Crown road begins with an informer's act that had no weight,
   (c) pays it all back in the opening of Chapter 5, in recalls, and in the epilogue. Nothing here changes any ending gate. */

const P1=()=>{ const st=g.story; return st.s1||(st.s1={}); };

/* ---- seed the hidden character from what you say to the Elders ---- */
{
  const _choose=choose;
  choose=function(who,text,opts,cb,cancel){
    let cb2=cb;
    try{
      const T=String(text||'');
      let f=null;
      if(T.indexOf('Why have you sought out the red ducks?')===0) f=k=>{ P1().why=k; S4.note(['trust','kin','pride','truth'][k],1); };
      else if(T.indexOf('And where do you come from?')===0) f=k=>{ P1().from=k; if(k===3){ S4.note('lie',1); } else S4.note('truth',1); };
      else if(T==='Explain.') f=k=>{ P1().explain=k; S4.note(['mercy','truth','lie'][k],1); };
      else if(T==='Why do you want to become red?') f=k=>{ P1().umber=k; S4.note(['trust','kin','truth','lie'][k],1); };
      else if(T==='What will you do?'&&who==='Elder Cinder') f=k=>{ P1().fork=['red','crown','time'][k]; S4.note(['kin','trust','lie'][k],1); };
      if(f) cb2=function(k){ try{ f(k); }catch(e){ console.error(e); } return cb(k); };
    }catch(e){ console.error(e); }
    return _choose(who,text,opts,cb2,cancel);
  };
}

/* ---- the hermit asks how Emberwick received you ---- */
{
  const _hs=hermitSuspicion;
  hermitSuspicion=function(n,done){
    const H='Hermit Mallow';
    if(P1().tell) return _hs(n,done);
    say(H,['Emberwick. You say it as if it were a real place.','Before the rest: how did they look at you? Not what they said. How they looked.'],()=>{
      choose(H,'How did they look at you?',[
        'Afraid. The way you would look at a flood. I think they have been waiting a hundred years for one.',
        'They turned me away at the gate. Flatly. I am telling you because you would find out.',
        'Like I was nothing. Their loss. They will listen to you, and then they will wish they had listened to me.'
      ],k=>{
        P1().tell=['fear','plain','proud'][k];
        S4.note(['kin','truth','pride'][k],1);
        const r=[
          ['Afraid.','(He closes his eyes, briefly.)','Yes. Fear is the one thing both sides of a wall always have in common. Thank you for seeing it first. Most would have seen the wall.'],
          ['Thank you for not dressing it.','A hundred years of people dressing things for me. You would not believe the quantity of ribbon.'],
          ['Hm.','(He smiles, a little, the way you smile at a child who has said something true and unkind.)','The Crown says things like that too, little detective. I only mention it.']
        ][k];
        say(H,r,()=>_hs(n,done));
      },1);
    });
  };
}

/* ---- the king's dinner: the Crown road begins with an informer's act. It should cost something to choose it. ---- */
kingDinner=function(G,done){
  const st=g.story;
  const end=()=>{
    st.dinnerDone=1; st.banished=1; tileCache.clear(); fade(1.6); advanceClock(3);
    done();
  };
  const purse=()=>{
    say('',['At the end of the evening a servant slides a heavy purse across the table. "The reward on the notices," says the voice from the dark. "Three hundred crumbs, as promised. Information is the one thing this kingdom still buys without question."'],()=>{
      choose('','The purse sits between you and the dark.',['Take it','Leave it on the table'],k=>{
        P1().purse=k===0?'took':'left';
        if(k===0){ g.crumbs+=300; coin(); st.kingReward=300; }
        else { S4.note('pride',1); st.kingReward=0; }
        const tail=k===0?[]:['The servant looks toward the dark. "As you like," says the voice. The purse stays where it is.'];
        seq((tail.length?[['',tail]]:[]).concat([['',['- To be continued -']]]),end);
      },0);
    });
  };
  seq([
    [G,['You are on time. Good. The king dislikes the other kind.','Follow me. Do not speak until you are spoken to.']],
    ['',['The gate opens just wide enough for one duck. The hall beyond is cold, blue-lit and very long. A single table is laid for two. Behind the far chair, a window shows nothing but dark.','At the head of the table: an empty chair, and a place set before it with great care, as if for a guest who has not been invited in a hundred years.']],
    ['',['Footsteps. Slow ones. A candle flickers, and a shape stands up from the dark at the far end of the hall.','"Detective Duck," says a voice you have heard, in your dreams, at the castle gate. "Please. Sit. We have so much to discuss."']]
  ],()=>{
    choose('','"Tell me about the red ducks. Where do they live? How many are there? What do they want?"',[
      'Everything: where the town is, its gate, its numbers.',
      'That they are frightened, and mostly bakers. Nothing that would help a march.',
      'That they exist. Nothing else. You will not get a map from me.'
    ],k=>{
      P1().told=['all','soft','little'][k];
      S4.note(['truth','mercy','lie'][k],1);
      const r=[
        ['"Good. That is exactly what I needed," says the voice. A pen scratches in the dark for a long time.','You find you are looking at your own wings.'],
        ['A pause. "Frightened. Bakers." The voice tries the words like a coin from a country it has not visited.','"I had not thought to ask what they were. Only what they were for."'],
        ['"Hm. That is not a map." Another pause, and then, to your surprise, something like approval.','"Few say no to me at this table. I shall remember the exception."']
      ][k];
      seq([['',r]],purse);
    },2);
  });
};

/* ---- Chapter 5 opens knowing who you were at the door ---- */
OPEN[5]={
  r:{open:'The Elders asked you who you were, and you answered what you could. It is a strange feeling, to be known by a town that has not decided to like you.',
     veiled:'The Elders asked who you were, and you left a door on the latch. Ruddock noticed. He wrote it down, and under it, in a smaller hand: for now.',
     torn:'You asked for time, and they gave it, and you used all of it. The potion did not make the choice simpler. It made it yours.'},
  c:{all:'You told the king where the gate is. Nobody has said so. The Hollow has begun to oil its hinges anyway.',
     soft:'You told the king they were bakers. It is the truest thing you have said to him, and he has not mentioned it once.',
     little:'You gave the king a shrug and kept the rest. It is a thin protection, and the only one you had.'}
};
{
  const _begin=S2.begin;
  S2.begin=function(id,skip){
    try{
      if(id==='c5r'){ const p=P1(); S4.setcx('t4', p.fork==='time'?'torn':(p.from===3||p.explain===2)?'veiled':'open'); }
      else if(id==='c5c'){ const p=P1(); S4.setcx('t4', p.told||'little'); }
    }catch(e){ console.error(e); }
    return _begin(id,skip);
  };
}

/* ---- the early answers come back as things people say ---- */
rc(['Hermit Mallow'],'rc_s1fear',()=>P1().tell==='fear',['"At the start you told me they looked at you the way you look at a flood. I have thought about that more than you would believe. It made them people to me before I had met one."']);
rc(['Hermit Mallow'],'rc_s1plain',()=>P1().tell==='plain',['"You did not dress it, the gate. I think I trusted the rest of it because you did not."']);
rc(['Hermit Mallow'],'rc_s1proud',()=>P1().tell==='proud',['"You said it was their loss, once. I have turned that over. Some losses are not theirs. A town can be wrong and still be a town."']);
rc(['Hermit Mallow'],'rc_s1soft',()=>P1().told==='soft',['"You told the king we were bakers. He told his Chancellor. The Chancellor laughed, I am told, and then stopped. I should like to have seen that."']);
rc(['Elder Cinder','Warden Ruddock'],'rc_s1all',()=>P1().told==='all',['(Not looking up.) "The king\'s men know where our gate is. A season ago, they did not. I am not asking who. I am telling you that I know how to count."']);
rc(['Captain Halbeak'],'rc_s1all2',()=>P1().told==='all',['"The king had a map of Emberwick on his table when I was called in. It was a good map. I thought you should know I noticed."']);
rc(['Captain Halbeak'],'rc_s1little',()=>P1().told==='little',['"The king says he asked you for a map and got a shrug. He told me it was the first time in forty years anyone refused him. I could not tell if he was angry."']);
rc(['Warden Ruddock'],'rc_s1veil',()=>P1().from===3,['"You said you would rather not say where you were from. I have held that against you. I would like to say I have also stopped."']);

/* ---- the epilogue remembers the road you started on ---- */
{
  const _ec=epiCard;
  epiCard=function(label,title,sub,pages,theme,cb){
    try{
      if(label==='EPILOGUE'&&Array.isArray(pages)){
        const q=s2(), p=P1(), e=q.ending;
        const camp={
          wake:'In spring, Mallow walks the road of cold campfires, as he has every year, setting the stones straight. This year he lights them, one by one, and does not put them out at dawn.',
          door:'In spring, Mallow walks the road of cold campfires and lights every one. Soldiers from both sides watch the smoke go up. Nobody follows it with a sword.',
          keeper:'In spring, Mallow walks the road of cold campfires, setting the stones straight. He leaves a kettle at each. "Someone will come by," he says. "Someone always does."',
          stay:'In spring, Mallow walks the road of cold campfires and sets the stones straight. He leaves them cold. "Not yet," he says. "But straight."'
        }[e];
        if(camp) pages=pages.concat([camp]);
        const fr=[
          'The Warden asked, once, whose child you were. You said Mallardia. Somewhere between Kingsbill and the Burnt Wood you stopped being sure that was the whole of the answer, and found you did not need it to be.',
          'You told the Warden you did not know where you were from. On the road from Kingsbill to the Burnt Wood you stopped needing to.',
          'South of the river, you said. Nobody in Emberwick has gone to look. Poppy has a plan, and a rope, and a list.',
          'You would rather not say, you told the Warden. Ruddock keeps a page in his ledger for it. He says it is the only entry he has ever been glad to leave blank.'
        ][p.from];
        if(fr) pages=pages.concat([fr]);
        if(p.told==='all') pages=pages.concat(['You think, some nights, about the evening you told the king where the gate was. Nobody has made you say it. That is its own sentence.']);
        if(p.purse==='took') pages=pages.concat(['You still have some of the king\'s three hundred crumbs. You have never spent them on anything that did not feel like an apology.']);
        else if(p.purse==='left') pages=pages.concat(['The king\'s purse sat on the table at Quackenhold for a month. The servants dusted around it. In the end someone moved it, and nobody will say who.']);
        if(p.told==='soft') pages=pages.concat(['The king asked once what the red ducks were, and you said bakers. In the end he sent a cart of flour. He did not sign it.']);
      }
    }catch(e){ console.error(e); }
    return _ec(label,title,sub,pages,theme,cb);
  };
}
