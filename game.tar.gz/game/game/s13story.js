'use strict';
/* ===== s13story: hints that point at where things really are, and quiet hours held where they happen =====
   - every objective line at the bottom of the screen now says where to go as a live compass bearing and distance from
     YOU, instead of "north-west of Kingsbill" (a place you may never have seen).
   - lists of people ("ask Ashby, Wren, Jay...") say where each of them is standing right now.
   - the quiet-hour campfire moves to where its scene is set (Emberwick's Hearth, the south-gate wall, the Training Yard
     camp, the watchtower, the Old Tree...) for the route you are on, and the person you sit with is standing there. */

/* ---------- where is it, from where I stand ---------- */
function whBear(tx,ty){
  const dx=tx+0.5-g.px/TS, dy=ty+0.5-g.py/TS, dist=Math.hypot(dx,dy);
  const names=['east','south-east','south','south-west','west','north-west','north','north-east'];
  return {dist:dist,dir:names[(Math.round(Math.atan2(dy,dx)/(Math.PI/4))+8)%8]};
}
function wh(tx,ty){
  if(g.scene!=='world'||tx===undefined||tx===null) return '';
  const b=whBear(tx,ty);
  if(b.dist<7) return ' (right here)';
  const n=b.dist<30?Math.round(b.dist/2)*2:Math.round(b.dist/5)*5;
  return ' (about '+n+' tiles <b>'+b.dir+'</b> of you)';
}
function whP(p){ return p?wh(p[0],p[1]):''; }
/* the same, as a plain phrase for mid-sentence use */
function whT(p){ if(!p||g.scene!=='world') return ''; const b=whBear(p[0],p[1]); if(b.dist<7) return 'right here'; const n=b.dist<30?Math.round(b.dist/2)*2:Math.round(b.dist/5)*5; return 'about '+n+' tiles <b>'+b.dir+'</b> of you'; }
const mt=(t,re)=>(t.match(re)||[''])[0];
/* live position of a named person: story people, Emberwick's townsfolk, or the kingdom's */
function npcSpot(name){
  try{
    for(const d of S2.npcs){ if(d.name!==name) continue; let on=true; try{ on=!d.when||d.when(); }catch(e){ on=false; } if(!on) continue; s2xy(d); return [d.wx,d.wy]; }
    if(name==='Hermit Mallow'&&g.story&&g.story.redOpen&&!g.story.hermitAway&&typeof hermitObj==='function'){ const h=hermitObj(); if(h) return [h.x/TS-0.5,h.y/TS-0.5]; }
    const t=getRed(); if(t){ const n=t.npcs.find(q=>q.name===name); if(n) return [n.x/TS-0.5,n.y/TS-0.5]; }
    const k=(typeof kNpcList==='function'?kNpcList():[]).find(q=>q.name===name); if(k) return [k.x/TS-0.5,k.y/TS-0.5];
  }catch(e){}
  return null;
}
function whN(name,fallback){ const p=npcSpot(name)||fallback; return whP(p); }
/* "Name (about 12 tiles north-east of you)" for each name */
function nameWhere(names,fb){ return names.map(n=>'<b>'+n+'</b>'+whN(n,fb&&fb[n])).join(', '); }
function nearestProp(ids){
  let best=null, bd=1e9;
  for(const id of ids){ const d=S2.props.get(id); if(!d) continue; let on=true; try{ on=!d.when||d.when(); }catch(e){ on=false; } if(!on) continue; s2xy(d); const dd=Math.hypot(d.wx-g.px/TS,d.wy-g.py/TS); if(dd<bd){ bd=dd; best=[d.wx,d.wy]; } }
  return best;
}
/* fixed places (tile coordinates) */
const PL={
  sgate:()=>[RX0+36,RY0+53], hearth:()=>[RX0+36,RY0+31], bell:()=>[RX0+30,RY0+27], wall:()=>[RX0+28,RY0+27],
  cellar:()=>[RX0+58,RY0+38], wgate:()=>[RX0+3,RY0+28],
  archive:()=>{ try{ const b=getRed().buildings.find(q=>/Archive/i.test(q.name)); if(b) return [b.doorX!==undefined?b.doorX:b.x+b.w/2,b.doorY!==undefined?b.doorY:b.y+b.h]; }catch(e){} return [RX0+8,RY0+48]; },
  plaza:()=>[KX,KY+18], castle:()=>[KX,KY+20], yard:()=>[KX+29,KY+29], tower:()=>[KX-76,KY-26], tree:()=>[KX-66,KY-61],
  bwedge:()=>[KX-47,KY-55], servant:()=>[KX+11,KY+10], grate:()=>[KX-18,KY+13], hollow:()=>[RX0+36,RY0+RH+3],
  gate:()=>[28,-1057], maze:()=>[57,-1057]
};
function obj_fix(id,fn){
  const c=S2.ch[id]; if(!c||!c.obj) return;
  const o=c.obj;
  c.obj=function(s){ let t=''; try{ t=o.call(c,s); }catch(e){ t=''; } if(!t) return t; try{ const r=fn(s,t); return r===undefined?t:r; }catch(e){ console.error(e); return t; } };
}
const _strip=(t,re)=>t.replace(re,'');

/* ---------- chapter hints ---------- */
/* Chapter 5 red: Standing */
obj_fix('c5r',(s,t)=>[
  'Report to <b>Warden Ruddock</b> at the south gate of Emberwick'+whP(PL.sgate())+'. He will set you three proofs.',
  'Proof one: ring the <b>Dawn Bell</b>, in the square'+whP(PL.bell())+', at first light (it is only rung at dawn; the bell will let you wait).',
  'Report to <b>Warden Ruddock</b> again, at the south gate'+whN('Warden Ruddock',PL.sgate())+'. He has the second proof.',
  t,
  'Proof three: hear the town\'s grievances. Talk to '+nameWhere(['Old Garnet','Widow Ash','Gossip Marrow'])+' '+mt(t,/\(\d+\/\d+ heard\)/)+'.',
  'Return to <b>Warden Ruddock</b> at the south gate'+whN('Warden Ruddock',PL.sgate())+'. The three proofs are done.'][s]);
/* Chapter 7 red: the key, and who has it */
obj_fix('c7r',(s,t)=>{
  if(s===1&&s2fl('letterRead')){ s2set(2); s=2; }
  const house=whP([257,-1141]);
  if(s===0) return s2fl('key')?'You have Bree\'s key. Open the red-knockered door of <b>Bree\'s cottage</b>, just outside Emberwick\'s south gate'+house+'.'
    :'Mallow has waited a century to go home. Find <b>Little Poppy</b>, who has the key: she is playing just outside <b>Bree\'s cottage</b>, a little way outside Emberwick\'s south gate'+whN('Little Poppy',[260,-1141])+'. Talk to her, then open the cottage door.';
  if(s===1){ const f=(typeof SX!=='undefined'&&SX.S&&SX.S.id==='bree')?SX.S.fl:{};
    return 'Inside <b>Bree\'s cottage</b>: look around. Mallow\'s mother hid something in this house. When you find it, read the letter. That is all he needs.'+(f.hearth?' (The hearth is lit; the rest is up to you.)':''); }
  if(s===2) return 'The Elders have sent for you at the <b>Great Hearth</b>'+whP(PL.hearth())+'. Take the letter.';
  return t;
});
/* Chapter 8 red */
obj_fix('c8r',(s,t)=>{
  if(s===0) return 'Find who is behind the lantern-snuffing. Ask: '+nameWhere(['Night-watch Ashby','Acolyte Wren','Courier Jay','Gossip Marrow','Scout Fennel'])+' '+mt(t,/\(\d+\/\d+ notes\)/)+'. When you have enough, talk to <b>Hermit Mallow</b>'+whN('Hermit Mallow',PL.hearth())+' to open the case board.';
  if(s===1) return 'The Hands meet at midnight (the door only opens after 10 pm; come back at night). The <b>root cellar</b>, by the east wall of Emberwick'+whP(PL.cellar())+'. Stop the Closing Rite.';
  if(s===2) return 'Return to the <b>Great Hearth</b>'+whP(PL.hearth())+'. The Elders are waiting.';
  if(s===3) return 'Cinder has set you a task: take the lantern and her letter to <b>Castle Quackenhold</b>, the king\'s castle'+whP(PL.castle())+'.';
  return t;
});
/* Chapter 5 crown */
obj_fix('c5c',(s,t)=>{
  if(s===0) return t.replace(/Ask around the kingdom: [^(]*/,'Ask around the kingdom: '+nameWhere(['Farmer Oats','Millie the Miller','Old Rue','Warden Thistle','Pip Ember','Archivist Penna'])+' ');
  if(s===1) return 'Take your answer to <b>Captain Halbeak</b>, at the Castle Plaza'+whN('Captain Halbeak',PL.plaza())+'.';
  return t;
});
obj_fix('c6c',(s,t)=>s===0?'After dark, go to the <b>servants\' door</b>, on the east side of the castle'+whP(PL.servant())+'. Get inside.':t);
/* Chapter 7 crown */
obj_fix('c7c',(s,t)=>{
  const yard='the Training Yard'+whP(PL.yard());
  if(s===0) return 'The Captain means to march at noon. Find what will stop him: the <b>Royal Seal</b> from <b>Pip Ember</b>'+whN('Pip Ember')+' ('+(g.inv.royalseal?'got it':'not yet')+'), and <b>Warden Thistle</b>\'s word at the Siege Field'+whN('Warden Thistle')+' ('+(s2fl('thistleOk')?'heard':'not yet')+'). You already hold <b>Eider\'s Draft</b>. Then speak to <b>Captain Halbeak</b> at '+yard+'.';
  if(s===1) return 'Speak to <b>Captain Halbeak</b> at '+yard+'.';
  if(s===4) return 'Your order has gone out. Walk west to the old watchtower in the west hills'+whP(PL.tower())+'. A <b>red feather</b> has been asking for you.';
  return t;
});
/* Chapter 8 crown */
obj_fix('c8c',(s,t)=>s===0?'Climb to the old watchtower in the west hills'+whP(PL.tower())+'. A red hermit is waiting.':(s===1||s===2)?t.replace(/\.$/,'')+whP(PL.tower())+'.':t);
/* Chapter 9 */
obj_fix('c9r',(s,t)=>s===0?'Travel to <b>Castle Quackenhold</b>'+whP(PL.castle())+' with Cinder\'s letter and the Keeper\'s Lantern.':s===1?'The gate is shut to red feathers. Find another way in: the <b>moat grate</b>, west of the castle plaza, breathes cold air'+whP(PL.grate())+'.':t);
obj_fix('c9c',(s,t)=>s===0?'At midnight, bring the <b>Hollow Token</b> to the <b>Hollow Door</b>: a stone door in the south wall of Emberwick, by the sealed gate'+whP(PL.hollow())+'. Mallow will be waiting for you there.':t);
obj_fix('c10',(s,t)=>s===0?t.replace(/\.$/,'')+whP(PL.castle())+'.':t);
obj_fix('c11',(s,t)=>s===0?'Travel to the <b>Old Tree</b>, in the heart of the Burnt Wood'+whP(PL.tree())+'. Be still, and look.':t);
obj_fix('c12',(s,t)=>s===0?'Go to the <b>parley tent</b> on the old watchtower hills'+whP(PL.tower())+'.':'The parley has fallen apart. Choose where you stand.');
/* Chapter 13 red: Emberwick */
obj_fix('c13r',(s,t)=>{
  if(s===0) return 'Read the <b>Wall of Lost</b>, in Emberwick\'s square'+whP(PL.wall())+', and ask <b>Archivist Sorrel</b> in the Ashen Archive, the south-west corner of town'+whN('Archivist Sorrel',PL.archive())+' '+(t.match(/\(\d+\/\d+ notes\)/)||[''])[0]+'. Open your Case Board (bag) and link them.';
  if(s===1) return 'Argue the council round. Speak to '+nameWhere(['Archivist Sorrel','Hearthwarden Pyre','Warden Ruddock'])+' '+mt(t,/\(\d+\/\d+ persuaded[^)]*\)/)+'. Then <b>Elder Cinder</b>'+whN('Elder Cinder')+'.';
  if(s===2) return 'Tell <b>Elder Cinder</b> what the Elders decided'+whN('Elder Cinder',PL.hearth())+'.';
  return t;
});
obj_fix('c14r',(s,t)=>{
  if(s===0) return 'The Hands have struck. Listen to Warden Ruddock.';
  if(s===1){ const f=nearestProp(['fire0','fire1','fire2','fire3','fire4']); return t+(f?' The nearest fire is '+whT(f)+'.':''); }
  if(s===2) return 'Find <b>Warden Ruddock</b> at the south gate'+whN('Warden Ruddock',PL.sgate())+'.';
  if(s===3) return 'Speak with <b>Elder Cinder</b> at the Hearth'+whN('Elder Cinder',PL.hearth())+'.';
  return t;
});
obj_fix('c15r',(s,t)=>s===0?'Take Poppy west by the <b>Lantern Road</b>: out of the <b>west gate</b> of Emberwick and keep walking west'+whP(PL.wgate())+'.':t);
/* Chapter 13 crown */
obj_fix('c13c',(s,t)=>{
  if(s===0) return t.replace(/Ask the Court: [^(]*in the Castle Plaza/,'Ask the Court, in the Castle Plaza'+whP(PL.plaza())+': '+nameWhere(['Chancellor Gander','Lord Plume','Lady Teal','Treasurer Mink'])+' ');
  if(s===1) return 'Persuade the Court to stand down. Speak to '+nameWhere(['Chancellor Gander','Lady Teal','Lord Plume'])+' '+mt(t,/\(\d+\/\d+;[^)]*\)/)+'.';
  if(s===2) return 'Report to <b>Captain Halbeak</b>, who is waiting on the south wall'+whN('Captain Halbeak')+'.';
  return t;
});
obj_fix('c14c',(s,t)=>s===0?'Break into the <b>barracks office</b> at the Training Yard'+whP(PL.yard())+' and replace the march order with a recall. Halbeak will leave the door on the latch.':s===1?'Speak to <b>Captain Halbeak</b> at the south wall'+whN('Captain Halbeak')+'.':t);
obj_fix('c15c',(s,t)=>{
  if(/watch-fires/.test(t)){ const f=nearestProp(['wf0','wf1','wf2','wf3','wf4']); return t.replace(/\.$/,'')+(f?'. The nearest unlit one is '+whT(f):'')+'.'; }
  if(s===2) return 'Report to <b>Hermit Mallow</b> at the watchtower'+whN('Hermit Mallow',PL.tower())+'.';
  return t;
});
/* Chapters 16-24 */
const GATEHINT=(nm,line)=>'Go to the <b>'+nm+'</b>: take the ash path that leaves the western road at the old moat bridge and runs north along the moat'+whP(PL.gate())+'. '+line;
obj_fix('c16r',(s,t)=>s===0?GATEHINT('Gate of Ash','Get past the Crown\'s line: argue, or sneak.'):t);
obj_fix('c16c',(s,t)=>s===0?GATEHINT('Gate of Gold','Get past the Hollow\'s line: argue, or sneak.'):t);
obj_fix('c17',(s,t)=>s===0?'Go into the <b>Burnt Wood</b>: past the old Gate, follow the ash path east to the <b>Ash Maze</b>'+whP(PL.maze())+'.':t);
obj_fix('c18',(s,t)=>s===0?'Enter the <b>Hall of Sleepers</b> at the foot of the Old Tree, in the heart of the Burnt Wood'+whP(PL.tree())+'.':t);
obj_fix('c20',(s,t)=>s===0?t.replace(/\.$/,'')+whP(PL.tree())+'.':t);
obj_fix('c13k',(s,t)=>s===0?'Go to <b>Mallow\'s house</b> at the edge of the Burnt Wood and sit down'+whN('Hermit Mallow')+'.':(s===1||s===2)?t.replace(/\.$/,'')+whN('Hermit Mallow')+'.':t);
obj_fix('c14k',(s,t)=>{
  if(s===0){ const f=nearestProp(['lost_d1','lost_d2','lost_d3']); return t+(f?' The nearest one is '+whT(f)+'.':''); }
  if(s===1) return 'Return to <b>Mallow</b>'+whN('Hermit Mallow')+'. He will read you the page he has written about you.';
  return t;
});
obj_fix('c15k',(s,t)=>t.replace(/\.$/,'')+whN('Hermit Mallow')+'.');
obj_fix('c16x',(s,t)=>{
  const sw=(typeof SW_WP!=='undefined')?SW_WP:null;
  if(s===0&&sw&&sw.mile) return t.replace(/\.$/,'')+whP([sw.mile.x,sw.mile.y])+'.';
  if(s===1) return 'Climb Weeping Ridge and speak to the <b>Cairn-Keeper</b>'+whN('Cairn-Keeper Wrenna')+'. Carry the lantern in your hand.';
  if(s===2){ const f=nearestProp(['reed_0','reed_1','reed_2']); return t.replace(/Ferrier Pim/,'Ferrier Pim'+whN('Ferrier Pim'))+(f?' The nearest reeds are '+whT(f)+'.':''); }
  if(s===3){ const f=nearestProp(['seal_stones']); return t.replace(/\.$/,'')+whP(f)+'.'; }
  if(s===4){ const f=nearestProp(['hall_names']); return t.replace(/\.$/,'')+whP(f)+'.'; }
  if(s===5) return 'Return to the north rim of the Burnt Wood. <b>Mallow</b> is waiting'+whN('Hermit Mallow')+'.';
  return t;
});
obj_fix('c21',(s,t)=>s===0?'Sit with the waking: '+nameWhere(['Hob, a cook','Orla, a mother','Tam, a soldier'])+', in the clearing by the Old Tree '+mt(t,/\(\d+\/\d+\)/)+'.':s===1?t.replace(/\.$/,'')+whP(PL.tree())+'.':t);
obj_fix('c22',(s,t)=>s===0?'Hear '+nameWhere(['Captain Halbeak','Elder Cinder'])+' about the road. '+mt(t,/\(\d+\/\d+\)/):s===1?t.replace(/\.$/,'')+whP(nearestProp(['council']))+'.':t);
obj_fix('c23',(s,t)=>{
  if(s===0){ const f=nearestProp(['plot_0','plot_1','plot_2']); return t+(f?' The nearest bare patch is '+whT(f)+'.':''); }
  if(s===1) return 'Wait for the plots to bloom (about half a day), and tell <b>Poppy</b>'+whN('Little Poppy')+'.';
  if(s===2) return 'Speak with <b>Mallow</b>'+whN('Hermit Mallow')+' about the house, and <b>Poppy</b>'+whN('Little Poppy')+' about the Keeper\'s work.';
  return t;
});
obj_fix('c24',(s,t)=>s===0?'Say goodbye to the people who matter. Speak with at least four of them, around the Old Tree'+whP(PL.tree())+' '+mt(t,/\(\d+\/\d+\)/)+'.':s===1?t.replace(/\.$/,'')+whP(nearestProp(['first_lantern']))+'.':t);
obj_fix('b18',(s,t)=>'Meet the people at the <b>edge of the Burnt Wood</b>'+whP(PL.bwedge())+'. They have come unasked.');

/* ---------- the quiet hours, held where they happen ---------- */
function routeOf(){ const q=s2(); if(q.done&&(q.done.c13k||q.done.c14k||q.done.c15k)) return 'k'; return s2red()?'red':'crown'; }
const FSPOT={
  hearth:{p:()=>[RX0+38,RY0+29],place:'beside the <b>Great Hearth</b>, in the middle of Emberwick'},
  wall:{p:()=>[RX0+35,RY0+52],place:'by the palisade just inside Emberwick\'s <b>south gate</b>'},
  sgcamp:{p:()=>[RX0+38,RY0+58],place:'in the camp just outside Emberwick\'s <b>south gate</b>'},
  yard:{p:()=>[KX+26,KY+31],place:'in the camp at the <b>Training Yard</b>'},
  tower:{p:()=>[KX-76,KY-26],place:'by the <b>old watchtower</b>, in the west hills'},
  tree:{p:()=>[KX-64,KY-59],place:'at the foot of the <b>Old Tree</b>, in the Burnt Wood'},
  house:{p:()=>[KX-44,KY-51],place:'at <b>Mallow\'s house</b>, on the edge of the Burnt Wood'},
  edge:{p:()=>[KX-48,KY-55],place:'at the <b>edge of the Burnt Wood</b>'}
};
function fireSpotKey(id){
  const r=routeOf();
  const bySide=(red,crown)=>r==='k'?'house':r==='red'?red:crown;
  switch(id){
    case 'b6': case 'b11': case 'b15': case 'x15': case 'x16': return bySide('hearth','yard');
    case 'b7': case 'b16': return bySide('sgcamp','yard');
    case 'b8': case 'b13': case 'b14': return bySide('hearth','tower');
    case 'b9': case 'b10': return bySide('wall','sgcamp');   /* on the Crown road the gate is sealed to you, so the camp is outside it */
    case 'b12': return 'tower';
    case 'b17': case 'x17': case 'b18': return 'edge';
    case 'b19': return 'tree';
  }
  return 'tower';
}
function fireNow(){
  const id=s2cur(); if(!/^[bx]\d+$/.test(id)||!BREATH[id]) return null;
  const k=fireSpotKey(id), sp=FSPOT[k], b=BREATH[id];
  return {id:id,key:k,place:sp.place,p:sp.p(),who:FIRE_WHO[b.who]?b.who:null};
}
campWhere=function(){ const f=fireNow(); if(!f) return ''; return f.place+(whP(f.p)||''); };
const FIRE_WHO={
  'Captain Halbeak':{pal:()=>BLUE_PAL,head:'helm'},
  'Warden Ruddock':{pal:()=>WARDEN_PAL,head:'helm'},
  'Little Poppy':{pal:()=>3,head:null},
  'Hermit Mallow':{pal:()=>RED_PALS[0],head:'hood'},
  'Keeper Brand':{pal:()=>cxP('#7a2a22','#4a1a14'),head:'wizard'}
};
Object.keys(FIRE_WHO).forEach((nm,i)=>{
  S2.npc({id:'firewho'+i,name:nm,pal:FIRE_WHO[nm].pal(),head:FIRE_WHO[nm].head,snap:0,still:true,when:()=>{ const f=fireNow(); return !!f&&f.who===nm; },
    talk(n,done){ const d=S2.props.get('breath_fire'); try{ d.use(); }catch(e){ console.error(e); } done(); }});
});
let _fireKey='';
function fireSync(){
  const f=fireNow(), key=f?f.id+'@'+f.key:'';
  if(key===_fireKey) return; _fireKey=key;
  if(!f) return;
  const put=(d,x,y)=>{ const p=snapFree(Math.round(x),Math.round(y),3); d.wx=p[0]; d.wy=p[1]; d.key=d.wx+','+d.wy; d._r=1; return p; };
  const fire=S2.props.get('breath_fire'); if(!fire) return;
  const fp=put(fire,f.p[0],f.p[1]);
  S2.npcs.forEach(d=>{ if(d.id&&d.id.indexOf('firewho')===0){ const p=put(d,fp[0]+1,fp[1]+1); if(d._o){ d._o.x=(p[0]+0.5)*TS; d._o.y=(p[1]+0.95)*TS; d._o.hx=d._o.x; d._o.hy=d._o.y; } } });
  /* the three things on the wall at dawn (x17) hang around the fire */
  [['x17_a',-2,-2],['x17_b',2,-2],['x17_c',0,-3]].forEach(a=>{ const d=S2.props.get(a[0]); if(d) put(d,fp[0]+a[1],fp[1]+a[2]); });
}
{
  const _su=storyUpdate;
  storyUpdate=function(dt){ try{ fireSync(); }catch(e){ console.error(e); } _su(dt); };
  /* the real Ruddock / Halbeak / Mallow step aside while the one at the fire is there, so there is only one of each */
  const _cn=collectNpcs;
  collectNpcs=function(){
    _cn();
    const f=fireNow(); if(!f||!f.who) return;
    for(let i=g.npcs.length-1;i>=0;i--){ const n=g.npcs[i]; if(n.name===f.who&&n.special!=='s2') g.npcs.splice(i,1); }
  };
}

/* ---------- the Elders' offer and the Academy: say where, from where you stand ---------- */
function spDoor(re){ try{ const b=getRed().specials.find(q=>re.test(q.name)); if(b) return [b.doorX,b.doorY]; }catch(e){} return null; }
PL.archive=()=>spDoor(/Archive/i)||[RX0+8,RY0+48];
{
  const _so=storyObjective;
  storyObjective=function(){
    let o=_so();
    if(!o||typeof o!=='string'||g.scene!=='world') return o;
    try{
      o=o.replace(/(<b>Mistress Vesper<\/b> at the Academy)/,'$1'+whP(spDoor(/Academy/i)))
        .replace(/(<b>gate of Cinderhold<\/b>)/,'$1'+whP(spDoor(/Cinderhold/i)))
        .replace(/(Attend the <b>Academy of the Ember Arts<\/b>) \(north-west of Emberwick\)/,'$1'+whP(spDoor(/Academy/i)))
        .replace(/(Hermit Mallow has come out of the castle\. <b>Talk to him<\/b>)/,'$1'+whN('Hermit Mallow'))
        .replace(/(Lay it at the <b>Great Hearth<\/b> in Emberwick)/,'$1'+whP(PL.hearth()))
        .replace(/(Brew the <b>Chromatic Potion<\/b> at the Great Hearth)/,'$1'+whP(PL.hearth()));
    }catch(e){}
    return o;
  };
}
