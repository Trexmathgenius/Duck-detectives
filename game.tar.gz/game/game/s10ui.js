/* ===== COMFORT IN A SMALL WINDOW (v1.25) =====
   The game lives in a window of 780x580 or so. This file makes it read and play well there:
   - long speech is split into short pages, and text speed is a setting
   - the top bar keeps three buttons and tucks the rest under "More"
   - the spell bar shows a carousel of five instead of twenty-one
   - the journal is an accordion with tabs, not one long wall
   - Esc opens one pause menu that reaches everything
   Everything here is wrapped in a function so it adds exactly one global: D10. */
(function(){
'use strict';
const D10=window.D10=window.D10||{};

/* ---------------- settings (kept across saves, in this browser) ---------------- */
const SKEY='dd_settings_v1';
const DEF={text:'normal',music:true,tips:true,keys:'arrows',reel:'hold',hud:'auto',pad:null,seen:{}};
let ST=Object.assign({},DEF,{seen:{}});
try{ const raw=localStorage.getItem(SKEY); if(raw){ const o=JSON.parse(raw); ST=Object.assign({},DEF,o,{seen:Object.assign({},o&&o.seen)}); } }catch(e){}
const save=()=>{ try{ localStorage.setItem(SKEY,JSON.stringify(ST)); }catch(e){} };
D10.settings=ST; D10.saveSettings=save;

/* ---------------- 1. speech in short pages ---------------- */
const MAXPAGE=170;
function splitPage(s){
  if(typeof s!=='string'||s.length<=MAXPAGE+25) return [s];
  const sents=s.split(/(?<=[.!?…])["”’)]?\s+(?=["“‘(A-Z0-9])/);
  if(sents.length<2) return [s];
  const out=[]; let cur='';
  for(const t of sents){
    if(cur&&(cur.length+1+t.length)>MAXPAGE){ out.push(cur); cur=t; }
    else cur=cur?cur+' '+t:t;
  }
  if(cur) out.push(cur);
  /* never leave a tiny orphan page */
  if(out.length>1&&out[out.length-1].length<28){ const l=out.pop(); out[out.length-1]+=' '+l; }
  return out;
}
D10.splitPage=splitPage;
{
  const _say=say;
  say=function(name,pages,onEnd){
    const out=[];
    for(const p of (pages||[])){ const s=typeof p==='function'?p(g):p; splitPage(s).forEach(x=>out.push(x)); }
    return _say(name,out,onEnd);
  };
  const _td=typeDialog;
  typeDialog=function(dt){
    if(ST.text==='instant') return _td(99);
    if(ST.text==='fast') return _td(dt*2.4);
    return _td(dt);
  };
}

/* ---------------- 2. the top bar: three buttons and "More" ---------------- */
function buildHud(){
  const btns=document.querySelector('.hud .btns'); if(!btns||btns.dataset.d10) return;
  btns.dataset.d10='1';
  const more=document.createElement('div'); more.className='moremenu'; more.hidden=true;
  const tog=document.createElement('button'); tog.className='hb'; tog.type='button'; tog.id='bMore'; tog.textContent='More ▾';
  tog.addEventListener('click',e=>{ e.currentTarget.blur(); more.hidden=!more.hidden; });
  const guide=document.createElement('button'); guide.className='hb'; guide.type='button'; guide.id='bGuide'; guide.textContent='Guide (G)';
  guide.addEventListener('click',e=>{ e.currentTarget.blur(); if(g.mode==='play') D10.openGuide&&D10.openGuide(); });
  const prim={bInv:'Pack (I)',bJr:'Journal (J)',bMap:'Map (M)'};
  for(const id in prim){ const b=document.getElementById(id); if(b){ b.textContent=prim[id]; b.classList.add('pri'); } }
  const bm=document.getElementById('bMenu'); if(bm) bm.textContent='Save & quit';
  btns.appendChild(guide); btns.appendChild(tog); btns.appendChild(more);
  const tuck=()=>{
    for(const b of [...btns.children]){
      if(b===tog||b===more||b===guide||b.classList.contains('pri')) continue;
      if(b.classList&&b.classList.contains('hb')){ b.classList.add('inmore'); more.appendChild(b); }
    }
  };
  tuck();
  new MutationObserver(tuck).observe(btns,{childList:true});
  document.addEventListener('pointerdown',e=>{ if(!more.hidden&&!btns.contains(e.target)) more.hidden=true; });
}
buildHud();

/* the bar quiets itself while somebody is speaking */
{
  const hud=document.getElementById('hud');
  const _uh=updateHud;
  updateHud=function(){
    _uh();
    const talk=(g.mode==='dialog'||g.mode==='choice');
    if(hud) hud.classList.toggle('dim',talk);
  };
}

/* ---------------- 3. the spell bar: a carousel of five ---------------- */
{
  const bar=document.getElementById('spellbar');
  if(bar){
    const tog=document.createElement('button'); tog.className='spmore'; tog.type='button'; tog.textContent='⋯';
    tog.title='Show all spells (Tab)';
    tog.addEventListener('click',e=>{ e.stopPropagation(); D10.toggleSpells(); });
    bar.appendChild(tog);
    let open=false;
    D10.toggleSpells=()=>{ open=!open; bar.dataset.open=open?'1':'0'; try{ spSig=''; }catch(e){} compact(); };
    function compact(){
      if(bar.hidden) return;
      const known=spKnown(), N=known.length; if(!N) return;
      const sel=spGetSel(); let si=known.indexOf(sel); if(si<0) si=0;
      const all=open||N<=6, show=new Map();
      if(all) known.forEach((n,i)=>show.set(n,i));
      else for(let o=-2;o<=2;o++) show.set(known[(si+o+N)%N],o+2);
      for(const n in spSlots){
        const d=spSlots[n].d; if(known.indexOf(n)<0) continue;
        const h=!show.has(n); if(d.hidden!==h) d.hidden=h;
        if(!h){ const ord=String(show.get(n)); if(d.style.order!==ord) d.style.order=ord; }
      }
      tog.hidden=N<=6; tog.style.order='99';
      tog.textContent=all&&N>6?'✕':(si+1)+'/'+N;
    }
    const _sbu=spBarUpdate;
    spBarUpdate=function(){ _sbu(); compact(); };
    KEYMAP.Tab='sp_toggle';
    const _p=press;
    press=function(k){ if(k==='sp_toggle'){ if(g.mode==='play'&&!bar.hidden) D10.toggleSpells(); return; } _p(k); };
  }
}

/* ---------------- 4. the journal: an accordion with tabs ---------------- */
const JTABS=[['All',null],['Story',/chapter|story|war|vision|ledger|known|hearth|crown|emberwick|mallow|ending|prologue|case|who you|road|deep art|verse|vow/i],['Magic',/spell|magic|art\b|verse|academy|school|lesson|ember|rune/i],['World',/favor|reputation|forag|fish|brew|collection|explor|home|town|notes|weather|calendar/i]];
let jTab=0; const jOpen=new Set();
function accordion(){
  const root=el.jrBody; if(!root||root.dataset.d10==='building') return;
  const kids=[...root.children]; root.innerHTML='';
  const head=[]; const secs=[]; let cur=null;
  for(const k of kids){
    if(k.tagName==='H3'){ cur={title:k.textContent,nodes:[]}; secs.push(cur); }
    else if(cur) cur.nodes.push(k); else head.push(k);
  }
  head.forEach(h=>root.appendChild(h));
  const bar=document.createElement('div'); bar.className='jtabs';
  JTABS.forEach((t,i)=>{ const b=document.createElement('button'); b.type='button'; b.className='hb jt'+(i===jTab?' on':''); b.textContent=t[0]; b.addEventListener('click',()=>{ jTab=i; renderJournal(); }); bar.appendChild(b); });
  const all=document.createElement('button'); all.type='button'; all.className='hb jt'; all.textContent='Open all'; all.addEventListener('click',()=>{ secs.forEach(s=>jOpen.add(s.title)); renderJournal(); }); bar.appendChild(all);
  const non=document.createElement('button'); non.type='button'; non.className='hb jt'; non.textContent='Close all'; non.addEventListener('click',()=>{ jOpen.clear(); jOpen.add('\u0000'); renderJournal(); }); bar.appendChild(non);
  root.appendChild(bar);
  const re=JTABS[jTab][1]; let shown=0;
  secs.forEach((s,idx)=>{
    if(re&&!re.test(s.title)) return;
    shown++;
    const open=jOpen.has(s.title)||(idx===0&&jOpen.size===0);
    const box=document.createElement('div'); box.className='jsec'+(open?' open':'');
    const h=document.createElement('button'); h.type='button'; h.className='jhead'; h.textContent=(open?'▾ ':'▸ ')+s.title+'  ('+s.nodes.length+')';
    h.addEventListener('click',()=>{ if(jOpen.has(s.title)) jOpen.delete(s.title); else jOpen.add(s.title); jOpen.add('\u0000'); renderJournal(); });
    box.appendChild(h);
    const body=document.createElement('div'); body.className='jbody2'; body.hidden=!open; s.nodes.forEach(n=>body.appendChild(n)); box.appendChild(body);
    root.appendChild(box);
  });
  if(!shown){ const p=document.createElement('p'); p.className='jdim'; p.textContent='Nothing in this tab yet.'; root.appendChild(p); }
}
{
  const _rj=renderJournal;
  renderJournal=function(){ _rj(); try{ accordion(); }catch(e){ console.error(e); } };
}

/* ---------------- 5. one pause menu (Esc) that reaches everything ---------------- */
function textLabel(){ return ({normal:'Normal',fast:'Fast',instant:'Instant'})[ST.text]; }
function settingsMenu(){
  const padOn=D10.padOn?D10.padOn():false;
  const opts=['Text speed: '+textLabel(),'Music: '+(ST.music?'on':'off'),'Tips: '+(ST.tips?'on':'off'),'Sound effects: '+(g.sound?'on':'off'),
    'Move with: '+(ST.keys==='wasd'?'WASD + arrows (dig is F)':'arrows only (dig is D)'),'Fishing reel: '+(ST.reel==='toggle'?'tap Z to lift / tap again to sink':'hold Z to lift'),
    'Top bar: '+(ST.hud==='always'?'always shown':'hides while you walk'),'On-screen buttons: '+(padOn?'on':'off'),'Back'];
  choose('','Settings',opts,k=>{
    if(k===0){ ST.text=ST.text==='normal'?'fast':ST.text==='fast'?'instant':'normal'; save(); settingsMenu(); }
    else if(k===1){ ST.music=!ST.music; save(); try{ D10.musicApply&&D10.musicApply(); }catch(e){} settingsMenu(); }
    else if(k===2){ ST.tips=!ST.tips; save(); settingsMenu(); }
    else if(k===3){ g.sound=!g.sound; try{ el.bSnd.textContent='Sound: '+(g.sound?'on':'off'); }catch(e){} settingsMenu(); }
    else if(k===4){ ST.keys=ST.keys==='wasd'?'arrows':'wasd'; save(); D10.applyKeys&&D10.applyKeys(); settingsMenu(); }
    else if(k===5){ ST.reel=ST.reel==='toggle'?'hold':'toggle'; save(); settingsMenu(); }
    else if(k===6){ ST.hud=ST.hud==='always'?'auto':'always'; save(); settingsMenu(); }
    else if(k===7){ ST.pad=!padOn; save(); D10.applyPad&&D10.applyPad(); settingsMenu(); }
    else pauseMenu();
  },8);
}
function pauseMenu(){
  const opts=['Resume','Pack','Journal','Map','Field Guide','Aims & commissions (K)','Controls (?)','Settings','Save & quit'];
  choose('','Paused',opts,k=>{
    if(k===0) return;
    if(k===1) openInv(); else if(k===2) openJournal(); else if(k===3) openMap();
    else if(k===4){ D10.openGuide&&D10.openGuide(); }
    else if(k===5){ D10.openAims&&D10.openAims(); }
    else if(k===6){ D10.openHelp&&D10.openHelp(); }
    else if(k===7) settingsMenu();
    else if(k===8){
      /* choices wrap, so "Save & quit" is one Up press from "Resume": ask first, and default to staying */
      choose('','Save your game and quit to the title screen?',['Keep playing','Save & quit'],j=>{
        if(j===1) saveAndQuit();
        else pauseMenu();
      },0);
    }
  },0);
}
D10.pauseMenu=pauseMenu; D10.settingsMenu=settingsMenu;
KEYMAP.g='guide'; KEYMAP.G='guide'; KEYMAP.p='pause'; KEYMAP.P='pause';
{
  const _p=press;
  press=function(k){
    if(g.mode==='play'){
      if(k==='x'||k==='pause'){ pauseMenu(); return; }
      if(k==='guide'){ D10.openGuide&&D10.openGuide(); return; }
    }
    _p(k);
  };
}
})();
