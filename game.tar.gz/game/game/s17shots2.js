'use strict';
/* ===== STORY SHOTS, PART TWO: the endings, the letter, the vault, the ridge, the names ===== */
(function(){
const SHOTS=window.S17SHOTS, H=window.S17H;
const {P,ez,rn,lerp,me,REDS,BLUES,duck,walk,vg,ridge,glow,stars,moon,night,flame,notes,word,lantern,crystal,charTree,houseSm,sitting,cottage,candle,wardBase}=H;

/* ---------- the clearing, and the four endings (chapter 20) ---------- */
function clearing(c,t,o){ o=o||{}; wardBase(c,t); if(o.dawn){ sky(c,'#3a2a5a','#f4b07a',22); ridge(c,118,'#4a3a5a',5,0.04,1); c.fillStyle='#4a4a54'; c.fillRect(0,128,LW,52); charTree(c,160,138,52,'#1c1a20'); circ(c,250,112,22,'rgba(255,214,150,0.3)'); circ(c,250,112,11,'#ffe2a0'); } }
SHOTS.youAtTree=(c,t)=>{ clearing(c,t); const p=0.6+0.4*Math.sin(t*2); glow(c,160,118,30,'rgba(255,214,150,'+(0.25*p).toFixed(2)+')'); for(let i=0;i<3;i++){ const q=(t*0.3+i/3)%1; c.strokeStyle='rgba(200,190,230,'+(0.4*(1-q)).toFixed(2)+')'; c.beginPath(); c.ellipse(160,130,14+q*120,5+q*28,0,0,6.3); c.stroke(); }
  duck(c,98,152,'right',me(),2.2); duck(c,60,154,'right',P.mallow,1.7,{head:'hood'}); duck(c,248,150,'left',P.halbeak,1.7,{head:'helm'}); duck(c,274,152,'left',P.poppy,1.2,{head:'bow'}); vg(c,0.5); };
SHOTS.humStops=(c,t)=>{ clearing(c,t); const k=ez(t/3); for(let i=0;i<4;i++){ const q=((t*0.35+i*0.25)%1)*(1-k)+k*(0.25*i+0.15); c.strokeStyle='rgba(200,190,230,'+(0.4*(1-q)*(1-k*0.9)).toFixed(2)+')'; c.beginPath(); c.ellipse(160,130,10+q*150,4+q*36,0,0,6.3); c.stroke(); }
  for(let i=0;i<26;i++){ const a=i/26*Math.PI*2, x=160+Math.cos(a)*112, y=132+Math.sin(a)*15; if(Math.sin(a)<-0.45) continue; ell(c,x,y,6,2.8,REDS[i%6]); circ(c,x,y-2,1.3,'#dfe9ff'); }
  /* the breath before a breath */
  c.fillStyle='rgba(0,0,0,'+(0.25*k).toFixed(2)+')'; c.fillRect(0,0,LW,LH); vg(c,0.6); };
SHOTS.eiderLetGo=(c,t)=>{ clearing(c,t); rect(c,110,134,100,5,'#6a4a30'); ell(c,160,128,32,8,'#f4f4ee'); circ(c,196,122,8,'#f4f4ee'); rect(c,203,122,8,2.4,'#ff9d2e'); circ(c,199,120,1,'#222');
  const k=ez(t/4); c.fillStyle='#f4f4ee'; ell(c,150,118-k*3,10,4,'#f4f4ee'); /* his wing, opening */ c.strokeStyle='rgba(255,230,180,'+(0.6*k).toFixed(2)+')'; c.lineWidth=1; for(let i=0;i<5;i++){ c.beginPath(); c.moveTo(140+i*3,116); c.lineTo(136+i*5,106-k*8); c.stroke(); }
  duck(c,118,150,'right',P.cinder,2.3,{head:'wizard'}); glow(c,160,120,60,'rgba(255,230,180,'+(0.15+0.2*k).toFixed(2)+')'); for(let i=0;i<10;i++){ const q=(t*0.18+i*0.1)%1; c.fillStyle='rgba(255,236,190,'+(0.8*(1-q)).toFixed(2)+')'; c.fillRect(150+Math.sin(q*6+i)*30,118-q*70,1.5,1.5); } vg(c,0.5); };
SHOTS.eiderCrown=(c,t)=>{ clearing(c,t); const k=ez((t-1)/3);
  duck(c,150,150,'right',P.eider,2.2,{head:null}); duck(c,206,150,'left',P.halbeak,2.2,{head:'helm'});
  const cx=lerp(166,196,k), cy=lerp(116,118,k)-Math.sin(k*3.14)*8; c.fillStyle='#c9a24a'; c.beginPath(); c.moveTo(cx-6,cy+4); c.lineTo(cx-6,cy-3); c.lineTo(cx-3,cy); c.lineTo(cx,cy-5); c.lineTo(cx+3,cy); c.lineTo(cx+6,cy-3); c.lineTo(cx+6,cy+4); c.fill(); glow(c,cx,cy,16,'rgba(255,220,120,0.4)');
  /* a council, seated in the same chairs */
  for(let i=0;i<6;i++){ const x=40+i*16; rect(c,x-4,136,8,3,'#6a4a30'); mini(c,x,134,i%2?'#4a6fb5':REDS[i%6],'right',1.2,0); } vg(c,0.5); };
SHOTS.wakeLamps=(c,t)=>{ clearing(c,t,{dawn:true}); /* a long street of lamps, lit one by one */
  for(let i=0;i<24;i++){ const a=i/24*Math.PI*2, x=160+Math.cos(a)*112, y=132+Math.sin(a)*15; if(Math.sin(a)<-0.45) continue; const k=ez((t-0.3-i*0.22)/0.9); if(k<=0.02){ ell(c,x,y,6,2.8,REDS[i%6]); } else { ell(c,x,y+1,5,1.6,'rgba(0,0,0,0.3)'); ell(c,x,y-3-k*5,4,3.5+k*4,REDS[i%6]); circ(c,x+2,y-8-k*6,2.4,REDS[i%6]); glow(c,x,y-6,14*k+4,'rgba(255,226,150,'+(0.45*k).toFixed(2)+')'); } }
  vg(c,0.35); };
SHOTS.tamHalbeak=(c,t)=>{ clearing(c,t,{dawn:true}); const k=ez((t-1.5)/2);
  duck(c,112,152,'right',{body:'#d9503f',wing:'#a83a2d',bill:'#e6c441'},2.3); duck(c,206,152,'left',P.halbeak,2.3,{head:k<0.5?'helm':null});
  if(k>0.1){ const hx=206+k*30, hy=118+k*20+Math.sin(k*3)*-10; c.fillStyle='#9aa0b0'; c.beginPath(); c.arc(hx,hy,7,Math.PI,0); c.fill(); }
  const w=ez((t-3.5)/2); c.fillStyle='#d9503f'; ell(c,lerp(124,150,w),128,10,3,'#d9503f'); heart(c,160,96-Math.sin(t*3)*2,0.9,'rgba(255,110,130,'+(w).toFixed(2)+')'); vg(c,0.35); };
SHOTS.orlaCinder=(c,t)=>{ clearing(c,t,{dawn:true}); const k=ez(t/6);
  for(let i=0;i<14;i++){ const a=i/14*Math.PI*2, x=160+Math.cos(a)*112, y=132+Math.sin(a)*15; if(Math.sin(a)<-0.45) continue; mini(c,x,y-3,REDS[i%6],x<160?'right':'left',1.1,0); }
  walk(c,lerp(70,198,k),152,'right',t,{body:'#d9503f',wing:'#a83a2d',bill:'#e6c441'},2.0); duck(c,226,152,'left',P.cinder,2.3,{head:'wizard'}); vg(c,0.4); };
SHOTS.waveBreaks=(c,t)=>{ clearing(c,t); const k=ez(t/3), q=ez((t-4)/3);
  for(let i=0;i<20;i++){ const a=i/20*Math.PI*2, x=160+Math.cos(a)*(112-k*50*(1-q)), y=148+Math.sin(a)*22, j=Math.abs(Math.sin(t*9+i))*(1-q)*4; if(Math.sin(a)<-0.45) continue; mini(c,x,y-j,REDS[i%6],x<160?'right':'left',1.4,0); if(q<0.5&&i%3===0){ c.fillStyle='rgba(255,230,200,0.9)'; c.font='700 8px Georgia,serif'; c.fillText('!',x,y-16-j); } }
  for(let i=0;i<5;i++){ duck(c,24+i*0,140+i*2,'right',P.halbeak,1.2,{head:'helm'}); } for(let i=0;i<6;i++){ mini(c,20,92+i*10,BLUES[i%4],'right',1.1,0); mini(c,300,92+i*10,'#a82a2a','left',1.1,0); }
  c.fillStyle='rgba(0,0,0,'+(0.2*q).toFixed(2)+')'; c.fillRect(0,0,LW,LH); vg(c,0.5); };
SHOTS.breeMallow=(c,t)=>{ clearing(c,t,{dawn:true}); const k=ez(t/3);
  duck(c,130,152,'right',P.bree,2.3); c.fillStyle='rgba(170,150,190,0.9)'; ell(c,128,140,16,6,'rgba(150,130,180,0.9)');
  duck(c,196,152,'left',P.mallow,2.3,{head:'hood'}); const hh=0.5+0.5*Math.sin(t*2.5); heart(c,162,100-hh*3,1.2,'rgba(255,100,130,'+k.toFixed(2)+')'); glow(c,162,128,40,'rgba(255,214,150,'+(0.2*k).toFixed(2)+')'); vg(c,0.4); };
SHOTS.poppyWing=(c,t)=>{ clearing(c,t,{dawn:true}); duck(c,140,154,'right',me(),2.4); duck(c,182,158,'left',P.poppy,1.5,{head:'bow'}); notes(c,160,110,t,'#ffe9b0',4,18); vg(c,0.35); };
SHOTS.morningSong=(c,t)=>{ clearing(c,t,{dawn:true}); notes(c,150,100,t,'#ffe9b0',5,24); notes(c,176,104,t+1.3,'#fff3c4',4,22); for(let i=0;i<5;i++){ const a=i/5*Math.PI*2, x=160+Math.cos(a)*112, y=132+Math.sin(a)*15; if(Math.sin(a)<-0.45) continue; mini(c,x,y-3,REDS[i%6],'down',1.2,0); } glow(c,160,100,70,'rgba(255,230,170,0.2)'); vg(c,0.35); };
/* the door ending */
SHOTS.fifthNote=(c,t)=>{ clearing(c,t); const cols=['#c9a6ff','#a6c9ff','#a6ffd0','#ffd9a6','#ffffff'];
  for(let i=0;i<5;i++){ const q=((t*0.28+i*0.2)%1); c.strokeStyle=cols[i]; c.globalAlpha=(1-q)*(i===4?0.9:0.55); c.lineWidth=i===4?2:1; c.beginPath(); c.ellipse(160,130,10+q*(i===4?150:120),4+q*(i===4?36:28),0,i===4?-0.2:0,6.3); c.stroke(); } c.globalAlpha=1;
  notes(c,160,112,t,'#ffffff',3,12); vg(c,0.5); };
SHOTS.keeperBetween=(c,t)=>{ clearing(c,t); const k=ez(t/3); c.save(); c.fillStyle='#4a3a28'; c.fillRect(150,92,20,40); c.fillStyle='#6a5a40'; c.fillRect(152,94,16,36); c.restore(); rect(c,168,110,2,4,'#c9a24a');
  for(let i=0;i<4;i++){ mini(c,40+i*14,140+(i%2)*4,REDS[i%6],'right',1.5,0); mini(c,280-i*14,140+(i%2)*4,BLUES[i%4],'left',1.5,0); }
  duck(c,160,152,'up',me(),2.0); c.strokeStyle='rgba(255,214,150,0.5)'; c.lineWidth=2; c.beginPath(); c.moveTo(150,134); c.lineTo(130+k*0,134); c.moveTo(170,134); c.lineTo(190,134); c.stroke(); vg(c,0.5); };
SHOTS.eiderRests=(c,t)=>{ clearing(c,t,{dawn:true}); rect(c,120,134,80,4,'#6a4a30'); duck(c,160,138,'down',P.eider,2.4,{head:null}); const k=ez(t/4); for(let i=0;i<8;i++){ const q=(t*0.4+i*0.13)%1; c.strokeStyle='rgba(150,190,255,'+(0.6*(1-k)*(1-q)).toFixed(2)+')'; c.beginPath(); c.moveTo(120+i*10,60+q*40); c.lineTo(122+i*10,70+q*50); c.stroke(); } glow(c,160,110,60,'rgba(255,236,190,'+(0.2+0.2*k).toFixed(2)+')'); vg(c,0.4); };
SHOTS.doorOpens=(c,t)=>{ clearing(c,t); const k=ez(t/4);
  /* the hollow becomes a door of old grey wood with a latch, a hand-width ajar */
  c.fillStyle='#3a3840'; c.fillRect(142,82,36,58); c.fillStyle='#6a6870'; c.fillRect(144,84,32,54); c.strokeStyle='#4a4850'; for(let x=150;x<176;x+=8){ c.beginPath(); c.moveTo(x,84); c.lineTo(x,138); c.stroke(); }
  const gap=6*k; c.fillStyle='rgba(255,230,170,'+(0.9).toFixed(2)+')'; c.fillRect(160-gap/2,86,gap,50); glow(c,160,112,50*k+8,'rgba(255,226,160,'+(0.5*k).toFixed(2)+')'); rect(c,172,110,3,5,'#c9a24a');
  notes(c,160,86,t,'#fff3c4',4,16); /* a lullaby, and a very distant bell */ const b=Math.sin(t*3); c.fillStyle='#c9a24a'; c.beginPath(); c.arc(250,40+b,4,Math.PI,0); c.fill(); rect(c,246,40+b,8,2,'#c9a24a'); vg(c,0.45); };
/* the keeper ending */
SHOTS.cupDown=(c,t)=>{ sky(c,'#2a2060','#f0a56b',20); ridge(c,118,'#2a2a52',7,0.03,1); c.fillStyle='#3a3a30'; c.fillRect(0,128,LW,52); charTree(c,60,140,60,'#1c1a20');
  rect(c,150,126,40,5,'#6a4a30'); rect(c,156,131,3,16,'#4a3020'); rect(c,181,131,3,16,'#4a3020'); const k=ez(t/2); const cy=lerp(100,116,k);
  rect(c,166,cy,10,10,'#efe6d0'); rect(c,175,cy+2,4,5,'#efe6d0'); for(let i=0;i<3;i++){ const q=(t*0.5+i*0.3)%1; c.fillStyle='rgba(235,235,240,'+(0.5*(1-q)).toFixed(2)+')'; c.fillRect(168+i*3+Math.sin(q*6)*2,cy-q*16,1.6,4); }
  duck(c,206,152,'left',me(),2.0); vg(c,0.4); };
SHOTS.ringOfChairs=(c,t)=>{ clearing(c,t,{dawn:true}); for(let i=0;i<8;i++){ const a=i/8*Math.PI*2, x=160+Math.cos(a)*54, y=140+Math.sin(a)*14; if(Math.sin(a)<-0.6) continue; rect(c,x-4,y-8,8,2,'#7a5d44'); rect(c,x-4,y-6,2,8,'#5a3d24'); rect(c,x+2,y-6,2,8,'#5a3d24'); rect(c,x-4,y-12,8,4,'#6a4a30'); }
  /* kettle and an open book on the roots */ rect(c,150,138,8,5,'#7d8896'); c.fillStyle='#7d8896'; c.beginPath(); c.arc(154,138,4,Math.PI,0); c.fill(); for(let i=0;i<3;i++){ const q=(t*0.5+i*0.3)%1; c.fillStyle='rgba(235,235,240,'+(0.5*(1-q)).toFixed(2)+')'; c.fillRect(154+Math.sin(q*6+i)*2,132-q*16,1.6,4); }
  rect(c,166,140,10,3,'#e8e0c8'); rect(c,176,140,10,3,'#f0e8d4'); const k=ez((t-1)/4); walk(c,lerp(270,214,k),154,'left',t,me(),1.9); vg(c,0.35); };
SHOTS.mallowArrives=(c,t)=>{ clearing(c,t,{dawn:true}); const k=ez(t/4); walk(c,lerp(-10,120,k),152,'right',t,P.mallow,2.2,{head:'hood'}); const x=lerp(-10,120,k); rect(c,x+14,126,10,8,'#7d8896'); rect(c,x+22,128,6,2,'#7d8896'); ell(c,x-14,130,8,4,'#d9a05b'); vg(c,0.35); };
/* the stay ending */
SHOTS.lightDims=(c,t)=>{ clearing(c,t); const k=ez(t/4); for(let i=0;i<3;i++){ const q=((t*0.28+i/3)%1); c.strokeStyle='rgba(200,190,230,'+(0.4*(1-q)).toFixed(2)+')'; c.beginPath(); c.ellipse(160,130,10+q*120,4+q*28,0,0,6.3); c.stroke(); }
  c.fillStyle='rgba(0,0,12,'+(0.45*k).toFixed(2)+')'; c.fillRect(0,0,LW,LH); for(let i=0;i<26;i++){ const a=i/26*Math.PI*2, x=160+Math.cos(a)*112, y=132+Math.sin(a)*15; if(Math.sin(a)<-0.45) continue; ell(c,x,y,6,2.8,REDS[i%6]); circ(c,x,y-2,1.3,'rgba(223,233,255,'+(1-k*0.5).toFixed(2)+')'); } vg(c,0.6); };
SHOTS.wardTakesEider=(c,t)=>{ clearing(c,t); rect(c,110,134,100,5,'#6a4a30'); ell(c,160,128,32,8,'#f4f4ee'); circ(c,196,122,8,'#f4f4ee'); rect(c,203,122,8,2.4,'#ff9d2e'); circ(c,199,120,1,'#222');
  const k=ez(t/5); c.save(); c.globalAlpha=0.6*k; c.strokeStyle='#a6c9ff'; c.lineWidth=1.5; for(let i=0;i<7;i++){ c.beginPath(); c.moveTo(120+i*13,56); c.lineTo(122+i*13,120); c.stroke(); } c.restore(); glow(c,160,110,60,'rgba(150,190,255,'+(0.25*k).toFixed(2)+')'); c.fillStyle='rgba(0,0,12,'+(0.3*k).toFixed(2)+')'; c.fillRect(0,0,LW,LH); vg(c,0.55); };
SHOTS.birdsRows=(c,t)=>{ sky(c,'#2a2a38','#6a6470',20); ridge(c,118,'#3a3a46',6,0.04,1); c.fillStyle='#4a474f'; c.fillRect(0,126,LW,54); for(let x=-4;x<LW;x+=22) charTree(c,x+6,128,36+rn(x)*20,'#1c1a20');
  for(let r=0;r<2;r++) for(let i=0;i<14;i++){ const x=20+i*21, y=92+r*10; c.fillStyle='#15131a'; c.beginPath(); c.ellipse(x,y,4,2.6,0,0,6.3); c.fill(); c.beginPath(); c.arc(x+3.4,y-2.4,1.8,0,6.3); c.fill(); rect(c,x+4.8,y-2.8,2.4,1,'#3a3a40'); } vg(c,0.5); };
SHOTS.mallowStays=(c,t)=>{ clearing(c,t); ell(c,176,146,22,5,'#4a474f'); c.fillStyle='#cf5a48'; ell(c,196,146,13,4.4,'#cf5a48'); circ(c,208,142,3.4,'#cf5a48'); glow(c,196,144,14,'rgba(170,200,255,0.3)'); duck(c,160,152,'right',P.mallow,2.3,{head:'hood'}); const b=Math.sin(t*1.2); vg(c,0.55); };
SHOTS.treeHollow=(c,t)=>{ clearing(c,t); const k=ez(t/3); c.fillStyle='#000'; c.beginPath(); c.ellipse(160,118,6+k*3,12+k*3,0,0,6.3); c.fill(); glow(c,160,118,34+k*14,'rgba(255,214,150,'+(0.3+0.2*k).toFixed(2)+')'); for(let i=0;i<4;i++){ const q=((t*0.3+i*0.25)%1); c.strokeStyle='rgba(200,190,230,'+(0.4*(1-q)).toFixed(2)+')'; c.beginPath(); c.ellipse(160,130,10+q*140,4+q*34,0,0,6.3); c.stroke(); }
  for(let i=0;i<26;i++){ const a=i/26*Math.PI*2, x=160+Math.cos(a)*112, y=132+Math.sin(a)*15; if(Math.sin(a)<-0.45) continue; ell(c,x,y,6,2.8,REDS[i%6]); circ(c,x,y-2,1.3,'#dfe9ff'); } notes(c,160,100,t,'#fff3c4',3,10); vg(c,0.5); };

/* ---------- the music box, the letter, the walkers (chapter 7, Red route) ---------- */
SHOTS.floorboard=(c,t)=>{ cottage(c,t,{sky:'#f0b080'}); c.fillStyle='#3a2a1c'; c.fillRect(70,120,180,44); for(let x=70;x<250;x+=30) rect(c,x,120,1,44,'rgba(0,0,0,0.3)'); rect(c,118,120,40,14,'#14100c');
  const k=ez(t/2); rect(c,110,116-k*10,52,5,'#5a4630'); c.fillStyle='#d8b0b0'; ell(c,138,130,14,6,'#d8b0b0'); rect(c,128,114,20,16,'#a8281c'); rect(c,128,112,20,4,'#c0392b'); c.fillStyle='#ffd166'; c.beginPath(); c.arc(138,114,3,0,6.3); c.fill(); glow(c,138,122,40,'rgba(255,200,120,0.3)'); notes(c,138,106,t,'#ffe9b0',5,14); vg(c,0.45); };
SHOTS.siegeGraves=(c,t)=>{ sky(c,'#4a3a5a','#c88a6a',22); ridge(c,112,'#4a4258',7,0.03,1); c.fillStyle='#4a5a3a'; c.fillRect(0,126,LW,54);
  for(let r=0;r<3;r++) for(let i=0;i<12;i++){ const x=22+i*24+(r%2)*10, y=128+r*12; c.fillStyle='#8a8e98'; c.beginPath(); c.moveTo(x-4,y); c.lineTo(x-4,y-8); c.quadraticCurveTo(x,y-14,x+4,y-8); c.lineTo(x+4,y); c.fill(); }
  /* the wind carries a hum up out of the graves */ for(let i=0;i<10;i++){ notes(c,22+i*30,126+(i%3)*8,t+i*0.7,'rgba(230,220,255,0.85)',1,6); }
  duck(c,262,152,'left',{body:'#8a7a5a',wing:'#6a5a3a',bill:'#d9a066'},1.7,{head:'cap'}); rect(c,282,120,1.6,32,'#6b4a2f'); for(let i=0;i<16;i++){ const x=(t*30+i*37)%LW, y=100+rn(i)*40; c.strokeStyle='rgba(255,255,255,0.15)'; c.beginPath(); c.moveTo(x,y); c.lineTo(x+14,y-2); c.stroke(); } vg(c,0.4); };
SHOTS.motherSings=(c,t)=>{ cottage(c,t,{sky:'#0e1430'}); rect(c,30,102,74,30,'#6a4a38'); rect(c,34,92,66,14,'#7a5a46'); rect(c,34,96,66,10,'#c8b898'); rect(c,34,104,66,12,'#a8503a'); mini(c,70,102,'#e04a3a','right',1.3,0);
  duck(c,136,150,'left',P.bree,2.3); candle(c,214,124,t,1.2); rect(c,200,124,30,4,'#6a4a30'); notes(c,120,108,t,'#ffe9b0',5,16); vg(c,0.5); };
SHOTS.foldedLetter=(c,t)=>{ cottage(c,t,{sky:'#f0b080'}); const k=ez(t/2); rect(c,150,110,100,6,'#6a4a30'); c.save(); c.translate(180,100); c.rotate(-0.1); rect(c,-22,-16,44,32,'#ece3cf'); rect(c,-22,-16,44,2,'#d8cdb4'); rect(c,-2,-16,1,32,'#d8cdb4'); for(let i=0;i<3;i++) rect(c,-16,-6+i*7,12,1,'#a89878'); c.restore();
  rect(c,120,100,24,12,'#a8281c'); rect(c,120,98,24,4,'#c0392b'); duck(c,92,152,'right',P.mallow,2.3,{head:'hood'}); duck(c,232,154,'left',me(),2.0); glow(c,180,100,50,'rgba(255,230,170,'+(0.25*k).toFixed(2)+')'); vg(c,0.45); };
SHOTS.motherWrites=(c,t)=>{ cottage(c,t,{sky:'#0e1430'}); rect(c,100,112,100,6,'#6a4a30'); rect(c,106,118,4,30,'#4a3020'); rect(c,190,118,4,30,'#4a3020'); candle(c,126,112,t,1.2);
  duck(c,160,150,'right',P.bree,2.4); c.strokeStyle='#f6f1e6'; c.lineWidth=1; const w=Math.sin(t*5)*2; c.beginPath(); c.moveTo(176,108); c.lineTo(188+w,98); c.stroke(); rect(c,168,106,26,6,'#ece3cf');
  rect(c,40,100,50,34,'#6a4a38'); rect(c,44,104,42,14,'#a8503a'); vg(c,0.5); };
SHOTS.walkersBack=(c,t)=>{ sky(c,'#3b2a6b','#f0a56b',22); ridge(c,112,'#2a2a52',8,0.03,1); c.fillStyle='#3a5a3a'; c.fillRect(0,126,LW,54); c.fillStyle='#b09a6a'; c.beginPath(); c.moveTo(-10,170); c.quadraticCurveTo(160,140,330,128); c.lineTo(330,138); c.quadraticCurveTo(160,160,-10,182); c.fill();
  houseSm(c,250,124,0.9,'#e6d6b0','#8a4a3a',true,t); houseSm(c,290,122,0.7,'#e6d6b0','#8a4a3a',true,t);
  for(let i=0;i<9;i++){ const x=300-((t*14+i*34)%360)+30, y=152-(x/LW)*16; if(x<-20||x>340) continue; walk(c,x,y,'left',t+i,{body:REDS[i%6],wing:'#962d22',bill:'#ff9d2e'},1.2); lantern(c,x-12,y-12,0.8,t); } vg(c,0.4); };
SHOTS.motherLeaves=(c,t)=>{ sky(c,'#14243a','#e8905a',22); ridge(c,118,'#2a2a52',7,0.03,1); c.fillStyle='#2a3a2a'; c.fillRect(0,128,LW,52); houseSm(c,96,136,2.2,'#6a4a48','#7a2a24',true,t); rect(c,86,114,20,22,'#f0b060');
  const k=ez(t/6); duck(c,lerp(122,230,k),152,k<0.99?'right':'right',P.bree,2.0); walk(c,lerp(122,230,k),152,'right',t,P.bree,2.0); mini(c,96,148,'#e04a3a','right',0.9,0); lantern(c,lerp(122,230,k)+16,134,1.1,t); vg(c,0.4); };
SHOTS.marchNorth=(c,t)=>{ night(c,t,'#14243a','#2a2a52'); ridge(c,120,'#161a3a',6,0.03,1); c.fillStyle='#232a3a'; c.fillRect(0,134,LW,46);
  for(let i=0;i<20;i++){ const x=-10+((t*14+i*20)%350), y=144+(i%4)*5; const turn=(i===9&&x>150); walk(c,x,y,turn?'left':'right',t+i,{body:REDS[i%6],wing:'#962d22',bill:'#ff9d2e'},1.1); }
  /* five fires along the way, the fifth lit */ for(let i=0;i<5;i++){ const x=40+i*60; rect(c,x-4,126,8,3,'#3a281c'); if(i===4){ flame(c,x,126,0.9,t); glow(c,x,116,34,'rgba(255,170,70,0.4)'); } }
  vg(c,0.5); };
SHOTS.woodOfTrees=(c,t)=>{ sky(c,'#35353d','#6c6872',20); ridge(c,104,'#4a4750',6,0.03,1); c.fillStyle='#55525a'; c.fillRect(0,126,LW,54);
  for(let r=0;r<3;r++) for(let i=0;i<14;i++){ const x=10+i*23+r*7, y=128+r*9, h=26+rn(i+r*9)*20; charTree(c,x,y,h); const a=0.25+0.15*Math.sin(t*1.5+i); circ(c,x,y-h*0.5,3.4,'rgba(230,200,190,'+a.toFixed(2)+')'); circ(c,x+2.2,y-h*0.5-3,1.6,'rgba(230,200,190,'+a.toFixed(2)+')'); } notes(c,160,100,t,'#dcd2f0',3,40); vg(c,0.45); };
SHOTS.hugLeg=(c,t)=>{ cottage(c,t,{sky:'#f0b080'}); duck(c,150,152,'right',P.mallow,2.6,{head:'hood'}); const k=ez(t/2); duck(c,134+k*8,158,'right',P.poppy,1.6,{head:'bow'}); heart(c,150,86-Math.sin(t*3)*2,1.3,'rgba(255,100,130,'+k.toFixed(2)+')'); duck(c,236,152,'left',me(),2.0); vg(c,0.4); };

/* ---------- the vault: the first flame, the two crystals (chapter 9, Crown route) ---------- */
SHOTS.firstFlame=(c,t)=>{ night(c,t,'#14243a','#2a2a52'); ridge(c,124,'#161a3a',6,0.03,1); c.fillStyle='#2a3a2a'; c.fillRect(0,132,LW,48);
  for(let i=0;i<4;i++) houseSm(c,30+i*30,132-(i%2)*2,0.8,'#6a4a48','#7a2a24',false,t);
  for(let i=0;i<10;i++){ const a=i/10*Math.PI*2; ell(c,160+Math.cos(a)*18,148+Math.sin(a)*5,5,3.5,'#5d6068'); } const k=ez((t-1.5)/2);
  duck(c,120,150,'right',P.eider,2.2,{head:'royal'}); lantern(c,138,134,1.3,t); if(k>0){ flame(c,160,146,1.4*k,t); glow(c,160,140,70*k+6,'rgba(255,170,70,'+(0.5*k).toFixed(2)+')'); }
  for(let i=0;i<10;i++){ const a=Math.PI*(0.1+0.8*i/9), x=160+Math.cos(a+Math.PI)*70, y=152+Math.sin(a)*8; mini(c,x,y,REDS[i%6],x<160?'right':'left',1.3,0); } vg(c,0.45); };
SHOTS.carryFire=(c,t)=>{ sky(c,'#e8b878','#f8e0a8',22); ridge(c,112,'#8aa070',7,0.03,1); c.fillStyle='#8fc46e'; c.fillRect(0,128,LW,52); c.fillStyle='#d8c898'; c.beginPath(); c.moveTo(-10,150); c.quadraticCurveTo(160,134,330,150); c.lineTo(330,158); c.quadraticCurveTo(160,144,-10,158); c.fill();
  houseSm(c,26,132,1.1,'#e6d6b0','#b5483a',true,t); crystal(c,28,104,22,'#ff9d2e',t); castle(c,290,136,0.5,'#d8d2c0','#3a5f9c',t,'#e0b84a'); crystal(c,290,58,16,'#6ab7ff',t);
  const k=ez(t/7); const x=lerp(44,270,k); walk(c,x,148-Math.sin(k*3.14)*4,'right',t,P.eider,1.9,{head:'royal'}); lantern(c,x+14,132,1.1,t);
  for(let i=0;i<4;i++){ const gx=lerp(34,280,(i+1)/5); if(gx<x){ rect(c,gx-1,142,2,6,'#4a3a2a'); circ(c,gx,140,2.2,'#ffd166'); } }
  mini(c,lerp(22,250,k)-20,152,REDS[1],'right',1.4,0); vg(c,0.3); };
SHOTS.twoLights=(c,t)=>{ night(c,t,'#0e1430','#2a2a52'); ridge(c,126,'#161a3a',6,0.03,1); c.fillStyle='#1c2230'; c.fillRect(0,132,LW,48);
  for(let i=0;i<30;i++) charTree(c,150+i*4+rn(i)*3,134,12+rn(i+3)*18,'#12101a'); glow(c,166,100,50,'rgba(120,100,160,0.25)');
  const dim=0.6+0.4*Math.sin(t*1.2), lean=ez(t/4)*0.18; crystal(c,56,134,52*(0.8+0.2*dim),'#ff9d2e',t,lean); crystal(c,264,134,52*(0.8+0.2*dim),'#6ab7ff',t,-lean);
  glow(c,56,100,40,'rgba(255,157,46,'+(0.3*dim).toFixed(2)+')'); glow(c,264,100,40,'rgba(106,183,255,'+(0.3*dim).toFixed(2)+')'); c.strokeStyle='rgba(255,230,180,0.18)'; c.setLineDash([3,4]); c.beginPath(); c.moveTo(56,100); c.lineTo(160,100); c.lineTo(264,100); c.stroke(); c.setLineDash([]); vg(c,0.5); };
SHOTS.eiderIsWard=(c,t)=>{ night(c,t,'#0e1430','#2a2a52'); c.fillStyle='#12101a'; c.fillRect(140,0,180,LH); for(let i=0;i<20;i++){ const x=170+rn(i)*140, y=20+rn(i+4)*110, a=0.2+0.2*Math.sin(t*2+i); c.fillStyle='rgba(120,100,150,'+a.toFixed(2)+')'; c.beginPath(); c.arc(x,y,8+rn(i+7)*10,0,6.3); c.fill(); }
  c.fillStyle='#e8d8b0'; c.fillRect(110,40,36,100); c.fillStyle='#fff3c4'; c.fillRect(114,44,28,92); glow(c,128,90,60,'rgba(255,230,160,0.4)');
  duck(c,128,136,'right',P.eider,1.9,{head:'royal'}); c.strokeStyle='rgba(255,230,160,0.8)'; c.lineWidth=2; c.beginPath(); c.moveTo(122,112); c.lineTo(118,100); c.moveTo(140,112); c.lineTo(146,100); c.stroke(); vg(c,0.5); };
SHOTS.coalCup=(c,t)=>{ c.fillStyle='#2a0e0c'; c.fillRect(0,0,LW,LH); const p=0.75+0.25*Math.sin(t*3); glow(c,160,110,100,'rgba(255,150,50,'+(0.4*p).toFixed(2)+')');
  c.fillStyle='#4a4a52'; c.beginPath(); c.moveTo(130,92); c.lineTo(190,92); c.lineTo(180,138); c.lineTo(140,138); c.closePath(); c.fill(); c.fillStyle='#6a6a74'; c.fillRect(126,88,68,6);
  circ(c,160,90,14,'#ff7a2a'); circ(c,160,90,9,'#ffd166'); circ(c,160,90,4.4,'#fff3c4'); for(let i=0;i<10;i++){ const q=(t*0.25+i*0.1)%1; c.fillStyle='rgba(255,210,120,'+(0.9*(1-q)).toFixed(2)+')'; c.fillRect(154+Math.sin(q*7+i)*10,86-q*50,1.5,1.5); }
  duck(c,70,152,'right',P.cinder,2.0,{head:'wizard'}); duck(c,252,154,'left',me(),1.9); vg(c,0.5); };

/* ---------- Ruddock's grandfather (chapter 14, Red route) ---------- */
SHOTS.grandfatherReturns=(c,t)=>{ sky(c,'#6a7a9a','#d8b890',22); ridge(c,112,'#6a8a6a',7,0.03,1); c.fillStyle='#8a9a5a'; c.fillRect(0,128,LW,52); c.fillStyle='#b09a6a'; c.beginPath(); c.moveTo(-10,166); c.quadraticCurveTo(160,146,330,150); c.lineTo(330,158); c.quadraticCurveTo(160,156,-10,176); c.fill();
  for(let i=0;i<12;i++){ const x=-10+((t*12+i*28)%380), y=146+(i%3)*4; walk(c,x,y,'right',t+i,{body:REDS[i%6],wing:'#962d22',bill:'#ff9d2e'},1.1); }
  rect(c,240,100,3,50,'#6b4a2f'); rect(c,278,100,3,50,'#6b4a2f'); rect(c,240,108,41,3,'#6b4a2f'); houseSm(c,300,130,0.9,'#e6d6b0','#8a4a3a',true,t);
  const k=ez((t-1)/4); mini(c,262,146,'#e8806a','left',1.3,0); const gx=lerp(170,254,k); walk(c,gx,148,'left',t,{body:'#a82a2a',wing:'#7f1f1f',bill:'#d9902a'},1.8,{head:'helm'}); heart(c,262,118-Math.sin(t*3)*2,1.0,'rgba(255,110,130,'+k.toFixed(2)+')'); vg(c,0.3); };
SHOTS.wallKeeps=(c,t)=>{ sky(c,'#2a1a3a','#f0a56b',22); ridge(c,112,'#2a2050',8,0.03,1); c.fillStyle='#4a3428'; c.fillRect(0,128,LW,52);
  for(let x=0;x<LW;x+=7){ const h=40+rn(x)*8; rect(c,x,128-h,5,h,'#4a3428'); c.fillStyle='#5a4030'; c.beginPath(); c.moveTo(x,128-h); c.lineTo(x+2.5,128-h-5); c.lineTo(x+5,128-h); c.fill(); }
  /* beyond the wall: the road out, which nobody went to look at */ c.fillStyle='rgba(255,214,150,0.35)'; c.fillRect(150,128,20,52); glow(c,160,60,60,'rgba(255,214,150,0.18)');
  duck(c,100,152,'right',P.ruddock,2.3,{head:'helm'}); for(let i=0;i<5;i++) mini(c,200+i*14,150+(i%2)*4,REDS[i%6],'up',1.4,0); vg(c,0.4); };
SHOTS.ruddockSit=(c,t)=>{ sky(c,'#2a1a3a','#f0a56b',22); ridge(c,112,'#2a2050',8,0.03,1); c.fillStyle='#4a3428'; c.fillRect(0,128,LW,52);
  for(let x=0;x<LW;x+=7){ const h=36+rn(x)*8; rect(c,x,128-h,5,h,'#2e2018'); } for(let i=0;i<5;i++){ const x=30+i*65; glow(c,x,96,24,'rgba(120,120,120,0.15)'); for(let j=0;j<3;j++){ const q=(t*0.3+j*0.3+i*0.1)%1; ell(c,x+Math.sin(q*5+j)*4,92-q*30,3+q*5,2+q*3,'rgba(60,56,60,'+(0.4*(1-q)).toFixed(2)+')'); } }
  rect(c,150,130,14,18,'#1a1410'); duck(c,162,146,'right',P.ruddock,2.2,{head:'helm'}); duck(c,214,152,'left',me(),2.0); vg(c,0.4); };

/* ---------- the Book of Days (chapter 14, hermit's table) ---------- */
SHOTS.bookPage=(c,t)=>{ cottage(c,t,{}); rect(c,60,112,200,8,'#6a4a30'); candle(c,88,112,t,1.2); const k=ez(t/2);
  c.save(); c.translate(160,104); rect(c,-46,-6,46,10,'#e8e0c8'); rect(c,0,-6,46,10,'#f0e8d4'); rect(c,-46,-8,92,2,'#8a2a2a'); rect(c,-1,-6,2,10,'#c9bfa0');
  /* small pictures drawn into the page as he reads: a bridge, a hand, a lantern */ c.strokeStyle='#6a5a3a'; c.lineWidth=1; c.beginPath(); c.arc(-34,-1,6,Math.PI,0); c.moveTo(-40,-1); c.lineTo(-28,-1); c.stroke(); circ(c,-18,-2,2,'#a89878'); circ(c,12,-1,2.4,'rgba(255,200,110,'+k.toFixed(2)+')'); for(let i=0;i<3;i++) rect(c,22,-4+i*2.4,18,0.6,'#9a8a6a'); c.restore();
  duck(c,96,152,'right',P.mallow,2.3,{head:'hood'}); duck(c,236,154,'left',me(),2.0); const q=0.5+0.5*Math.sin(t*3); glow(c,160,106,40,'rgba(255,230,170,'+(0.15*q).toFixed(2)+')'); vg(c,0.5); };

/* ---------- the Ash Road: the scout, the weeping ridge, the beacon, the names (chapter 16.5) ---------- */
function ashSky(c,t){ sky(c,'#4a4854','#9a96a0',20); for(let i=0;i<30;i++){ const x=(i*43+t*8)%LW, y=(t*10+i*31)%LH; c.fillStyle='rgba(210,206,216,0.3)'; c.fillRect(x,y,1.6,1.6); } ridge(c,92,'#6a6874',9,0.03,0); ridge(c,112,'#5a5862',7,0.04,2); }
SHOTS.scoutFeathers=(c,t)=>{ ashSky(c,t); ridge(c,132,'#4a4850',5,0.06,1); c.fillStyle='#3e3c44'; c.fillRect(0,138,LW,42);
  const k=ez((t-1)/3); /* the three hundred, passing below in the dusk */ for(let i=0;i<14;i++){ const x=-10+((t*10+i*26)%340), y=150+(i%3)*4; walk(c,x,y,'right',t+i,{body:REDS[i%6],wing:'#962d22',bill:'#ff9d2e'},0.9); }
  duck(c,226,130,'left',P.wrenna,2.2,{head:'hood'}); for(let i=0;i<7;i++){ const fx=214+i*3, fy=118+i*2; c.save(); c.translate(fx,fy); c.rotate(-0.5); c.fillStyle=i===6?'rgba(192,57,43,'+(1-k).toFixed(2)+')':'#c9bfa0'; c.fillRect(0,0,6,1.6); c.restore(); }
  rect(c,200,134,10,3,'#3a281c'); flame(c,205,134,0.7*k,t); glow(c,205,126,30*k+2,'rgba(255,170,70,'+(0.4*k).toFixed(2)+')'); vg(c,0.45); };
SHOTS.weepingRidge=(c,t)=>{ ashSky(c,t); ridge(c,128,'#4a4850',8,0.05,1); c.fillStyle='#3e3c44'; c.fillRect(0,144,LW,36);
  for(let i=0;i<6;i++){ const x=30+i*52; c.fillStyle='#2a2830'; c.beginPath(); c.moveTo(x,134); c.lineTo(x+3,118); c.lineTo(x+6,134); c.fill(); for(let j=0;j<8;j++){ const q=(t*0.6+j*0.13+i*0.07)%1; c.fillStyle='rgba(235,240,250,'+(0.8*(1-q)).toFixed(2)+')'; c.fillRect(x+3,120+q*28,1.2,3); } c.fillStyle='rgba(235,240,250,0.35)'; c.fillRect(x+2,140,3,4); }
  duck(c,160,154,'right',me(),1.9); vg(c,0.45); };
SHOTS.cairnBeacon=(c,t)=>{ ashSky(c,t); ridge(c,126,'#4a4850',6,0.05,1); c.fillStyle='#3e3c44'; c.fillRect(0,142,LW,38);
  c.fillStyle='#8a8f98'; c.beginPath(); c.moveTo(130,146); c.lineTo(142,98); c.lineTo(178,98); c.lineTo(190,146); c.fill(); c.fillStyle='#14100c'; c.beginPath(); c.ellipse(160,104,12,5,0,0,6.3); c.fill();
  const k=ez((t-1.5)/3); duck(c,100,152,'right',me(),2.0); lantern(c,134-k*0,118-k*6,1.4,t); c.strokeStyle='rgba(255,214,150,'+(0.5*k).toFixed(2)+')'; c.lineWidth=2; c.beginPath(); c.moveTo(138,112); c.quadraticCurveTo(150,104,158,104); c.stroke(); vg(c,0.45); };
SHOTS.cairnsLight=(c,t)=>{ night(c,t,'#14161e','#3a3a46'); ridge(c,126,'#2a2830',8,0.05,1); c.fillStyle='#2a2830'; c.fillRect(0,140,LW,40);
  for(let i=0;i<9;i++){ const x=250-i*28, y=106+i*3.4, s=1-i*0.07; c.fillStyle='#6a6e78'; c.beginPath(); c.moveTo(x-9*s,y+8); c.lineTo(x-4*s,y-12*s); c.lineTo(x+4*s,y-12*s); c.lineTo(x+9*s,y+8); c.fill(); const k=ez((t-0.4-i*0.55)/0.7); if(k>0){ glow(c,x,y-14*s,22*s*k+4,'rgba(235,240,255,'+(0.5*k).toFixed(2)+')'); circ(c,x,y-14*s,2.4*s,'rgba(250,252,255,'+k.toFixed(2)+')'); } }
  const b=ez(t/5); const bx=250-b*224, by=70+Math.sin(b*8)*6+b*20; glow(c,bx,by,18,'rgba(240,244,255,0.5)'); circ(c,bx,by,2.6,'#ffffff'); vg(c,0.5); };
SHOTS.womanTea=(c,t)=>{ cottage(c,t,{sky:'#0e1430'}); rect(c,60,118,110,6,'#6a4a30'); rect(c,66,124,4,28,'#4a3020'); rect(c,160,124,4,28,'#4a3020'); candle(c,82,118,t,1.1);
  const k=ez((t-1)/2); duck(c,200,150,'left',P.bree,2.4); rect(c,128,106,10,10,'#efe6d0'); rect(c,137,108,4,5,'#efe6d0'); for(let i=0;i<3;i++){ const q=(t*0.5+i*0.3)%1; c.fillStyle='rgba(235,235,240,'+(0.5*(1-q)).toFixed(2)+')'; c.fillRect(131+i*3,102-q*16,1.6,4); }
  if(k>0.1){ c.fillStyle='rgba(255,230,180,'+(0.2*k).toFixed(2)+')'; c.fillRect(0,0,LW,LH); } vg(c,0.5); };
SHOTS.namesWriting=(c,t)=>{ night(c,t,'#14161e','#3a3a46'); c.fillStyle='#8a94a8'; c.fillRect(0,132,LW,48); for(let r=0;r<3;r++) for(let i=0;i<20;i++){ const x=40+i*11+(r%2)*5, y=138+r*10; rect(c,x,y,10,6,'#5a4640'); if(i<14||r<2) rect(c,x+2,y+2.5,6,0.8,'rgba(255,230,200,0.5)'); }
  candle(c,214,146,t,1.4); const k=ez(t/5); duck(c,120,150,'right',P.gord,2.4,{head:'helm'}); const w=Math.sin(t*8)*1.2; c.strokeStyle='#f6f1e6'; c.lineWidth=1.4; c.beginPath(); c.moveTo(140,134); c.lineTo(156+w,142); c.stroke(); for(let i=0;i<30;i++){ const x=(i*37+t*6)%LW, y=(t*10+i*21)%90; c.fillStyle='rgba(255,255,255,0.6)'; c.fillRect(x,y,1.2,1.2); } vg(c,0.5); };
SHOTS.childHand=(c,t)=>{ night(c,t,'#0a0e1c','#1c2038'); c.fillStyle='#1c2030'; c.fillRect(0,130,LW,50); c.fillStyle='#2a2e44'; c.beginPath(); c.moveTo(-10,170); c.quadraticCurveTo(160,140,330,138); c.lineTo(330,148); c.quadraticCurveTo(160,152,-10,182); c.fill();
  const x=-20+ez(t/9)*270; walk(c,x,150,'right',t,{body:'#5a1a1a',wing:'#3a1010',bill:'#b87a1a'},2.4); walk(c,x+22,156,'right',t+0.3,{body:'#c0392b',wing:'#962d22',bill:'#ff9d2e'},1.2); c.strokeStyle='#c9a24a'; c.lineWidth=1.5; c.beginPath(); c.moveTo(x+8,140); c.lineTo(x+20,146); c.stroke(); vg(c,0.6); };
SHOTS.ashRim=(c,t)=>{ ashSky(c,t); ridge(c,126,'#4a4850',6,0.05,1); c.fillStyle='#3e3c44'; c.fillRect(0,140,LW,40);
  /* the wall of the Burnt Wood, far and quiet */ for(let i=0;i<30;i++) charTree(c,150+i*6,128,22+rn(i)*22,'#1c1a20'); duck(c,92,152,'right',P.mallow,2.4,{head:'hood'}); duck(c,50,156,'right',me(),1.9); vg(c,0.45); };

/* ---------- Bree and Mallow, the whistler, the stay (chapters 21, 24) ---------- */
SHOTS.breeTells=(c,t)=>{ sky(c,'#14243a','#e8905a',22); ridge(c,118,'#2a2a52',7,0.03,1); c.fillStyle='#2a3a2a'; c.fillRect(0,128,LW,52); houseSm(c,206,136,2.4,'#6a4a48','#7a2a24',true,t); rect(c,192,112,22,24,'#f0b060');
  duck(c,160,152,'right',P.bree,2.3); mini(c,126,154,'#e04a3a','left',1.4,0);
  const items=[['hearth',150],['eat',176],['stay',204]]; items.forEach((it,i)=>{ const k=ez((t-1-i*1.6)/1); if(k>0){ c.globalAlpha=k; const y=96-k*4; if(i===0){ flame(c,70,y+10,0.8,t); } if(i===1){ circ(c,100,y+4,6,'#d9a05b'); rect(c,96,y,8,2,'#e6b673'); } if(i===2){ c.strokeStyle='rgba(255,214,150,0.9)'; c.lineWidth=1.6; c.beginPath(); c.arc(130,y+4,6,0,6.3); c.moveTo(126,y); c.lineTo(134,y+8); c.stroke(); } c.globalAlpha=1; } }); vg(c,0.4); };
SHOTS.breeMallowHands=(c,t)=>{ sky(c,'#3a2a5a','#f4b07a',22); ridge(c,118,'#4a3a5a',5,0.04,1); c.fillStyle='#4a4a54'; c.fillRect(0,128,LW,52); charTree(c,60,140,54,'#1c1a20');
  duck(c,130,152,'right',P.bree,2.3); ell(c,126,142,16,6,'rgba(150,130,180,0.9)'); duck(c,190,152,'left',P.mallow,2.3,{head:'hood'}); c.strokeStyle='#e8d0c0'; c.lineWidth=2.4; c.beginPath(); c.moveTo(146,138); c.lineTo(176,138); c.stroke(); circ(c,161,138,2.6,'#d9a05b'); rect(c,150,152,10,5,'#efe6d0'); const k=0.5+0.5*Math.sin(t*2); heart(c,160,98-k*3,1.1,'rgba(255,100,130,0.9)'); vg(c,0.35); };
SHOTS.ruddockWalks=(c,t)=>{ sky(c,'#6fb0e8','#f7e0a0',22); ridge(c,112,'#6d7fae',6,0.025,1); ridge(c,126,'#4d7a5a',6,0.035,3); c.fillStyle='#4f8a50'; c.fillRect(0,138,LW,42); c.fillStyle='#b09a6a'; c.beginPath(); c.moveTo(-10,170); c.quadraticCurveTo(120,150,250,134); c.lineTo(262,134); c.quadraticCurveTo(130,158,60,182); c.fill();
  const k=ez(t/8); walk(c,lerp(-10,200,k),152-k*14,'right',t,P.ruddock,1.9-k*0.4,{head:'helm'}); rect(c,lerp(-10,200,k)+10,120+k*16,1.6,28-k*8,'#6b4a2f'); houseSm(c,270,128,1.0,'#e6d6b0','#8a4a3a',true,t); vg(c,0.25); };
SHOTS.tuneMan=(c,t)=>{ sky(c,'#6fb0e8','#f7e0a0',22); ridge(c,118,'#4d7a5a',6,0.035,3); c.fillStyle='#4f8a50'; c.fillRect(0,132,LW,48); houseSm(c,250,134,1.8,'#e6d6b0','#8a4a3a',true,t); rect(c,60,126,70,5,'#6a4a30'); rect(c,66,131,4,20,'#4a3020'); rect(c,120,131,4,20,'#4a3020'); rect(c,80,118,22,8,'#a8844a');
  duck(c,160,152,'left',{body:'#8a7a5a',wing:'#6a5a3a',bill:'#d9a066'},2.1,{head:'cap'}); notes(c,150,118,t,'#fff6c0',6,22); duck(c,214,154,'left',P.ruddock,2.1,{head:'helm'}); vg(c,0.25); };
SHOTS.eiderStay=(c,t)=>{ night(c,t); moon(c,268,34,10,'#0a0e2a'); ridge(c,124,'#161a3a',6,0.03,1); H.stoneWall(c,0,200,92,88,'#4a4e6a'); duck(c,132,92,'down',P.eider,1.7,{head:'royal'});
  const k=ez(t/3); word(c,'stay',132,62-k*10,15,'#dfe8ff',k*(1-ez((t-4)/3)*0.6),'#8fb0ff'); for(let i=0;i<14;i++){ const x=212+(i%7)*14, y=134+Math.floor(i/7)*12; mini(c,x,y,REDS[i%6],'left',1.25,0); }
  /* the word goes out, and nobody answers */ for(let i=0;i<5;i++){ const q=((t*0.3+i*0.2)%1); c.strokeStyle='rgba(223,232,255,'+(0.4*(1-q)).toFixed(2)+')'; c.beginPath(); c.ellipse(132,78,10+q*90,6+q*30,0,0,6.3); c.stroke(); } vg(c,0.55); };
SHOTS.vaultCinder=(c,t)=>{ SCENES.s17vault(c,t); };

window.S17SHOTS=SHOTS;
})();
