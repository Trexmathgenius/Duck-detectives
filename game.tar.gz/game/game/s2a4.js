'use strict';
/* ===== ACT IV: THE SLEEPERS ===== chapters 13 to 16, red and crown ===== */

function ledHas(k,n){ return (s2led(k)||0)>=n; }
function pgive(m){ toast(m,3200); }
const POPPY_FOLLOW={name:'Little Poppy',pal:RED_PALS[3],head:null,scale:0.7,seen:true};
const BLUE_PAL={body:'#4a6a9a',wing:'#34507a',bill:'#e6c441'};

/* ---------- shared: elders as story NPCs ---------- */
S2.npc({id:'sorrel13',name:'Archivist Sorrel',red:[31,34],pal:RED_PALS[1],head:'wizard',neck:'scarf',when:()=>s2at('c13r')||s2at('c14r'),mark:()=>(s2at('c13r',1)&&!s2fl('e_sor'))?'!':null,talk(n,done){ S2.ch[s2cur()].talk(n,done)||done(); }});
S2.npc({id:'cinder13',name:'Elder Cinder',red:[38,34],pal:RED_PALS[2],head:'wizard',when:()=>s2at('c13r')||s2at('c14r'),mark:()=>(s2at('c13r',2)||s2at('c14r',2))?'!':null,talk(n,done){ S2.ch[s2cur()].talk(n,done)||done(); }});

/* =========================================================
   CHAPTER 13 (RED): THE WALL OF LOST
   ========================================================= */
const WL={id:'wl',title:'Where Were They Going?',
  clues:{p1:'Plaque at the Wall: "Hollis, aged six. Lost at the third fire, in the Reeds."',p2:'Plaque: "Tansy and Wren, twins. Lost at the fourth fire, at the Ford."',p3:'Plaque: "Alder, aged four. Last seen at the fifth fire, on the Rise."',p4:'Sorrel\'s roll: after the fifth fire the walkers turned south, to the Reeds, the Ford and the Rise.'},
  links:[{a:'p1',b:'p2',id:'south',t:'The Reeds and the Ford are both south of the fifth fire. The children were lost on the road they had already walked.'},{a:'p3',b:'p4',id:'back',t:'The walkers did not march north to fight. They turned back, all of them, to search for the lost.'}],
  need:['south','back'],q:'Where were the three hundred going, the night the siege began?',
  answers:[{t:'North, to take the castle by force'},{t:'Back down the road, searching for their lost children',ok:1,yes:'Yes. It all fits. A search party that turned into a siege. Nobody ever asked them what they were looking for.'},{t:'Home to Emberwick, to hide'},{t:'To the Hollow, to wait for Gordamom'}]};
const WLP=[['p1',[26,27]],['p2',[28,27]],['p3',[30,27]]];
function wlCount(){ return ['p1','p2','p3','p4'].filter(k=>S2.hasClue('wl',k)).length; }
S2.ch.c13r={route:'red',title:'The Wall of Lost',sub:'Forty-one plaques. One question nobody asked.',
  intro:['The summit has failed. Overnight, Emberwick fills with the sound of sharpening: wardens, hearthkeepers, the Hands in their grey, all arguing in the square about what to do about the sleepers.','Ruddock wants a wall. The Hands want a rite. Cinder wants peace and has no idea how to pay for it. Nobody wants to ask what the sleepers want. Nobody has read the Wall in a hundred years.'],
  recap:'The Wall of Lost showed the three hundred were searching, not marching. The Elders voted for a small party, not an army: the Lantern Road.',
  start(){ s2set(0); },
  obj(s){ return ['Read the <b>Wall of Lost</b>, in Emberwick\'s square, and ask <b>Archivist Sorrel</b> in the <b>Ashen Archive</b> (south-west corner of town) ('+wlCount()+'/4 notes). Open your <b>Case Board</b> (bag) and link them.',
    'Argue the council round. Speak to <b>Archivist Sorrel</b>, <b>Hearthwarden Pyre</b> and <b>Warden Ruddock</b> ('+['e_sor','e_pyr','e_rud'].filter(k=>s2fl(k)).length+'/3 persuaded; two are enough). Then <b>Elder Cinder</b>.',
    'Tell <b>Elder Cinder</b> what the Elders decided.'][s]; },
  board(){ return s2at('c13r',0)?{def:WL,solved:()=>{ s2set(1); toast('The question is answered. Now persuade the council.',4200); }}:null; },
  mark(n){ if(n.name==='Warden Ruddock'&&s2at('c13r',1)&&!s2fl('e_rud')) return {ch:'!',col:'#ffd166'}; if(n.name==='Hearthwarden Pyre'&&s2at('c13r',1)&&!s2fl('e_pyr')) return {ch:'!',col:'#ffd166'}; return null; },
  talk(n,done){
    const s=s2step();
    if(n.name==='Archivist Sorrel'&&s===0){
      if(S2.hasClue('wl','p4')){ say(n.name,['It is in the roll. You have read it. I can say no more than the page.'],done); return true; }
      say(n.name,['The roll of the March. I have read it three thousand times. I did not read the line I should have: the bit between the fifth fire and the sixth.','"After the fifth fire, the walkers turned south." Look at it. Just look. We were so sure we knew where they were going.'],()=>{ S2.clue('wl','p4','Clue: Sorrel\'s roll.'); hudCache.obj=null; done(); }); return true;
    }
    if(s===1&&n.name==='Archivist Sorrel'){ return elderRound(n,done,'e_sor','Sorrel',[
      {t:'"The roll says south. Let me read the line aloud to the council."',p:2,say:['She breathes out. "Yes. I will stand beside you when you do."']},
      {t:'"A hundred years of records, and nobody asked."',p:1,led:{truth:1},say:['"Hm. That one cuts."']},
      {t:'"The archive is why we are in this."',p:0,led:{pride:1},say:['She closes the book, quietly.']}]); }
    if(s===1&&n.name==='Hearthwarden Pyre'){ return elderRound(n,done,'e_pyr','Pyre',[
      {t:'Hold up the Keeper\'s Lantern. "It leans toward them. It does not lean toward a battle."',p:2,req:()=>!!g.inv.keeperlantern,say:['Pyre looks at it a long moment. "No. It leans like a mother."']},
      {t:'"The Hearth is dimming. You know why."',p:1,led:{truth:1},say:['"I know. I have known a month."']},
      {t:'"Do what you like with the Hearth."',p:0,say:['Pyre adds a log, and does not look at you.']}]); }
    if(s===1&&n.name==='Warden Ruddock'){ return elderRound(n,done,'e_rud','Ruddock',[
      {t:'"Come with us. Bring the wardens, and bring them to guard, not to fight."',p:2,say:['He unfolds his arms, one at a time. "Hm. Guard. I can do guard. I have been doing guard my whole life."']},
      {t:'Remind him: "I kept your secret."',p:2,req:()=>!!s2fl('ruddockSecret'),led:{trust:1},say:['"You did. I owe you that."']},
      {t:'"You told me yourself you would not wake them for any reason."',p:1,say:['"I did. I did say that."']},
      {t:'"You are afraid."',p:0,led:{pride:1},say:['"Everyone is afraid. The question is whether you are useful about it."']}]); }
    if(n.name==='Elder Cinder'&&(s===1||s===2)){
      const c=['e_sor','e_pyr','e_rud'].filter(k=>s2fl(k)).length;
      if(c<2){ say(n.name,['The council has not agreed. Two, Detective. Two voices, and I can carry it.'],done); return true; }
      seq([['Elder Cinder',['Sorrel says the roll supports it. Pyre says the lantern leans. Ruddock says he will guard, and I did not expect to hear that sentence in my lifetime.','The council has decided. Not an army. Not a rite. A small party, by the old road, to the Burnt Wood, to ask the sleepers what they want.','We call it the Lantern Road. You will carry the lantern. Poppy will not be told to stay behind, because she has already packed.']]],()=>{ addRep(getRed(),5); S2.finish('c13r'); done(); });
      return true;
    }
    return false;
  }
};
function elderRound(n,done,flag,nm,opts){
  if(s2fl(flag)){ say(n.name,['I have said I will stand with you. Go and find the others.'],done); return true; }
  S2.persuade({who:n.name,intro:[nm+' folds '+(nm==='Pyre'?'his':'her')+' wings. "Speak. And be brief. The square is full of people with better ideas than yours."'],rounds:[{q:'What do you say?',opts:opts}],need:1,
    win:()=>{ s2fl(flag,1); coin(); const c=['e_sor','e_pyr','e_rud'].filter(k=>s2fl(k)).length; toast(nm+' will stand with you. ('+c+'/3)',3000); if(c>=2&&s2at('c13r',1)) s2set(2); hudCache.obj=null; done(); },
    lose:()=>{ say('',['That did not land. Think about what they care about, and try again.'],done); }});
  return true;
}
WLP.forEach(w=>S2.prop({id:'wl_'+w[0],red:w[1],glyph:'grave',col:'#9a8f86',when:()=>s2at('c13r',0),mark:()=>S2.hasClue('wl',w[0])?null:'!',use(){
  const t=WL.clues[w[0]];
  say('The Wall of Lost',['Cut deep into red stone, in the style of a hundred years ago, each name a little unsteady:',t.replace(/^[^:]*: ?/,'')],()=>{ S2.clue('wl',w[0],'Clue: the Wall of Lost.'); hudCache.obj=null; });
}}));

/* =========================================================
   CHAPTER 14 (RED): RUDDOCK'S FIRE
   ========================================================= */
const FIRES=[[6,9],[64,12],[8,48],[62,46],[36,5]];
function fireCount(){ return [0,1,2,3,4].filter(i=>s2fl('fire'+i)).length; }
S2.h.c14r_fire=function(){ s2fl('palBurn',1); hudCache.obj=null; say('Warden Ruddock',['The palisade is down in three places. The gate is scorched. Nobody died, which is the only good thing I can say.','You were slow. I do not hold it against you. I hold it against me.'],()=>{ s2set(2); }); };
S2.ch.c14r={route:'red',title:'Ruddock\'s Fire',sub:'Fear is the most organised thing in the world, again.',
  intro:['The night before the Lantern Road sets out, the Hands strike.','Not at the Hearth. At the walls. Five fires, set at five points of the palisade, in the hour before dawn. Brand\'s followers have decided the only way to keep the sleepers asleep is to make Emberwick too burnt to leave.'],
  recap:'You put out the Hands\' fires. Ruddock confessed he is the grandson of a soldier who died on the Siege Field, and agreed to guard the Lantern Road.',
  start(){ s2set(0); seq([['Warden Ruddock',['FIRE! East wall! North! They are all along the palisade! Apprentice! The Art! You know what to do!']]],()=>{ S2.deadline('fire',3,'Fires','c14r_fire'); s2set(1); }); },
  obj(s){ return ['','Put out the <b>five fires</b> along Emberwick\'s palisade ('+fireCount()+'/5).','Find <b>Warden Ruddock</b> at the south gate.','Speak with <b>Elder Cinder</b> at the Hearth.'][s]; },
  mark(n){ if(n.name==='Warden Ruddock'&&s2at('c14r',2)) return {ch:'!',col:'#ffd166'}; return null; },
  talk(n,done){
    const s=s2step();
    if(s===2&&n.name==='Warden Ruddock'){
      const burnt=!!s2fl('palBurn');
      cutSeq({story:[['ruddockSit'],['grandfatherReturns','wallKeeps']]},[['Warden Ruddock',[burnt?'(He is sitting on a burnt post, black to the elbows.)':'(He is standing at the gate, sooty and upright.)','I was wrong about you. I do not say it often. The first time I was wrong about you was the first day. The second time was tonight.','Sit. Sit, I said. I want to tell you a thing.']],
        ['Warden Ruddock',['My grandfather did not die in the Wood. He died on the Siege Field. On the wrong side. My family has not said so in Emberwick for a hundred years. He was one of the three hundred. He went back for his daughter.','I have been a wall my whole life because I thought the walls were what kept us from becoming him. I have it backwards. The wall is what kept us from going to look.']]],()=>{
        choose('Warden Ruddock','He looks at you, and waits.',['"Come with us. Be one of the party."','"You would have been a good man to lose a child to."','Say nothing. Put a wing on his shoulder.'],k=>{
          if(k===0){ s2led('trust',1); } else if(k===1){ s2led('mercy',1); s2led('truth',1); } else { s2led('mercy',2); }
          say('Warden Ruddock',[['I will. I will come. I will carry the Hearth\'s flame on my own back if that is what it takes.','...That is not a thing a captain says. I will pretend you did not say it. And I will think about it for a long while.','(He does not say anything. He does not need to. His shoulder, under your wing, is shaking.)'][k]],()=>{ if(s2fl('palBurn')) addRep(getRed(),2); else addRep(getRed(),6); s2set(3); done(); });
        },2);
      }); return true;
    }
    if(s===3&&n.name==='Elder Cinder'){ seq([['Elder Cinder',['Ruddock told me. I did not know. Thank you for not making him say it twice.','The Lantern Road leaves at dawn. Sorrel has the map. Pyre has the lanterns. And Poppy, God help us, has the sandwiches.']]],()=>{ S2.finish('c14r'); done(); }); return true; }
    return false;
  }
};
FIRES.forEach((p,i)=>{
  const out=(how)=>{ s2fl('fire'+i,1); coin(); const n=fireCount(); toast(how+' ('+n+'/5)',2400); if(n>=5){ S2.clearDeadline('fire'); addRep(getRed(),5); s2set(2); } hudCache.obj=null; };
  S2.prop({id:'fire'+i,red:p,glyph:'hearth',when:()=>s2at('c14r',1)&&!s2fl('fire'+i),mark:'!',
    use(){
      choose('A fire on the palisade','The post is burning from the foot, and the flames are climbing.',['Beat it out with your wings','Leave it'],k=>{ if(k===0){ advanceClock(0.3); out('You beat it out. It takes a while.'); } },1);
    },
    cast:{
      Frost(){ out('Frost: the fire stiffens and goes out.'); },
      Gust(){ out('Gust: the fire is pulled off the post like a cloth.'); }
    }});
});

/* =========================================================
   CHAPTER 15 (RED): THE LANTERN ROAD (escort Poppy)
   ========================================================= */
S2.ch.c15r={route:'red',title:'The Lantern Road',sub:'A small party, a lit road, and a child who has packed too many sandwiches.',
  intro:['The party leaves at dawn: you, the lantern, Poppy, and a very sleepy Ruddock a few steps behind, who says he is only coming as far as the first gate.','The Lantern Road is the oldest path in the Hollow Wood. It leaves Emberwick by the west gate, goes through three glades, and ends at the edge of the Burnt Wood. Every duck who has ever walked it has come back different.'],
  recap:'You brought Poppy through the Lantern Road. She asked three questions on the way. You answered.',
  start(){ s2set(0); },
  obj(s){ return ['Take Poppy west by the <b>Lantern Road</b>: out of the <b>west gate</b> of Emberwick and keep walking west'+hostWhere(231,-1177)+'.','The Lantern Road continues west through the glades. Keep Poppy close, and out of sight of the Grove Wardens.'][s]; }
};
S2.prop({id:'lanternroad',wx:233,wy:-1175,snap:0,glyph:'lantern',when:()=>s2at('c15r',0,1),mark:'!',use(){
  say('',['The west gate. A track of pale pebbles leads out under black trees, with a lantern on a post every fifty steps, all unlit, each one waiting to be asked.','(Walk west, out of the gate. Poppy will keep close.)']);
}});
const POPPYQ=[['Mallow said the sleepers are my great-great-granny. Is that true?',['Yes, I think so.','"That is so many greats. Do I have to say them all?"']],['Are the Grove Wardens bad?',['No. They are afraid of the same thing you are.','"I am not afraid. I am only hungry."']],['What if they do not want to wake?',['Then we ask them what they want.','"That is a good plan. Mama says the best plans are the ones where you ask."']]];
function poppyTalk(S,i){ return (S2,n)=>{}; }
sxDef('lr1',{name:'The First Glade',theme:'wood',dark:0.6,lightR:90,start:[1,4,'right'],follow:POPPY_FOLLOW,
  hint:'Poppy follows you, and they can see her too. Wait for the Wardens to turn, or use the shadows.',
  caughtLines:['"HALT." A tall grey shape turns toward you, and toward the very small shape behind you.','"Back," says the Warden. "Not as a punishment. As a kindness." You are set down at the start of the glade, gently, with Poppy under one wing.'],
  rows:sxGrid(24,9,[[0,4,'D'],[23,4,'>'],[6,1,2,7,'#'],[6,4,2,1,'.'],[15,1,2,3,'#'],[15,5,2,3,'#'],[15,4,2,1,'.'],[9,1,5,2,','],[9,6,5,2,','],[18,3,4,3,','],[11,4,'L'],[19,4,'L']]),
  exits:{D:{to:'world',wx:RX0+2,wy:RY0+27},'>':{to:'lr2',tx:1,ty:4,dir:'right'}},
  objs:{L:{name:'Unlit lantern',glyph:'lamp',desc:'A lantern on a post, dark. Poppy wants to light it.',use:(S)=>{ if(S.fl.lit){ say('',['It is lit. Poppy is proud of it.']); return; } S.fl.lit=1; coin(); sxSay(S,'Little Poppy',['"Can I? Can I do the lantern? Mallow showed me how. You hold the wick, and you ask nicely, and then you wait."','(A tiny flame stands up in the glass, and looks around, delighted.)']); }}},
  guards:[{name:'Grove Warden',path:[[3,1],[3,7]],speed:24,range:5.5,fov:70,pause:0.9,scan:true,pal:{body:'#6a7a5a',wing:'#4a5a3a',bill:'#8a9a6a'},head:'hood'},
          {name:'Grove Warden',path:[[12,1],[12,7]],speed:26,range:5.5,fov:70,pause:0.9,scan:true,pal:{body:'#6a7a5a',wing:'#4a5a3a',bill:'#8a9a6a'},head:'hood'}],
  onEnter(S){ if(!S.fl.hint){ S.fl.hint=1; sxSay(S,'Little Poppy',['Are we being quiet? I am being quiet. This is my quiet voice. Can you hear it? No? Then it is working.']); } }
});
sxDef('lr2',{name:'The Briar Glade',theme:'wood',dark:0.64,lightR:84,start:[1,4,'right'],follow:POPPY_FOLLOW,seek:S=>[21,4],
  rows:sxGrid(24,9,[[0,4,'<'],[23,4,'>'],[8,1,1,3,'#'],[8,5,1,3,'#'],[8,4,'T'],[14,1,1,3,'#'],[14,5,1,3,'#'],[14,4,'C'],[19,1,1,3,'#'],[19,5,1,3,'#'],[19,4,'F']]),
  exits:{'<':{to:'lr1',tx:22,ty:4,dir:'left'},'>':{to:'lr3',tx:1,ty:4,dir:'right'}},
  objs:{
    T:sxSpellObj({name:'Briar wall',glyph:'thorns',desc:'A wall of black briar, thick as a door.',solid:true,when:S=>!S.fl.t},{Kindle:'ask the briar to burn'},(S)=>{ S.fl.t=1; coin(); sxSay(S,'Little Poppy',['(The briar burns tidily to ash.)','"Ooh. Do it again."']); },'Briar burns. The Ember Wand remembers fire.'),
    C:sxSpellObj({name:'Curse-mark',glyph:'curse',desc:'A glowing circle on the path. Poppy has put her foot very near it.',solid:true,when:S=>!S.fl.c},{Ward:'hold the knot to your heart'},(S)=>{ S.fl.c=1; coin(); sxSay(S,'',['The mark flares, flinches, and goes out. Poppy applauds, very quietly, and then stops, because she has remembered she is being quiet.']); },'A curse is turned by a ward.'),
    F:sxSpellObj({name:'Fog',glyph:'fog',desc:'Fog, thick as wool.',solid:true,when:S=>!S.fl.f},{Gust:'blow it away'},(S)=>{ S.fl.f=1; coin(); sxSay(S,'Little Poppy',['"Away," you whisper. The fog goes, grumbling.','"Can I ask you something? On the way. I have three questions. Mama says I should only ask one at a time."']); },'Fog is air.')
  }
});
sxDef('lr3',{name:'The Edge of the Wood',theme:'ash',dark:0.55,lightR:90,start:[1,4,'right'],follow:POPPY_FOLLOW,
  rows:sxGrid(20,9,[[0,4,'<'],[19,4,'E'],[12,3,'q'],[6,2,'k']]),
  exits:{'<':{to:'lr2',tx:22,ty:4,dir:'left'},E:{fn:S=>{ if(S.fl.n<3){ say('',['Poppy has more questions. It is a long way and she means to ask them all.']); return; } sxLeave(RX0+2,RY0+27); S2.finish('c15r'); }}},
  objs:{q:{name:'Fallen log',glyph:'rock',col:'#4a3a2a',desc:'A fallen log. Poppy is sitting on it.',use:(S)=>{
      S.fl.n=S.fl.n||0;
      if(S.fl.n>=3){ say('Little Poppy',['I am not tired. I am only sitting. Can we go?'],null); return; }
      const q=POPPYQ[S.fl.n];
      say('Little Poppy',[q[0]],()=>{
        choose('Little Poppy','What do you say?',[q[1][0],'Tell her the truth, all of it','Change the subject'],k=>{
          if(k===0){ s2led('kin',1); say('Little Poppy',[q[1][1]],()=>{ S.fl.n++; coin(); }); }
          else if(k===1){ s2led('truth',1); s2led('kin',1); say('Little Poppy',['(You tell her. All of it, as plainly as a ten-year-old can hear. She is quiet for a long time.)','"...Okay. I think I always knew. I did not know I knew."'],()=>{ S.fl.n++; coin(); }); }
          else say('Little Poppy',['(She looks at you with the stern patience of a child who has been changed-the-subject-ed before.)','"Ask me again later."'],()=>{ S.fl.n++; });
        },2);
      });
    }},k:{name:'Pillar',glyph:'pillar',block:true,col:'#3a3a38'}},
  onEnter(S){ S.fl.n=S.fl.n||0; if(!S.fl.hint){ S.fl.hint=1; sxSay(S,'Little Poppy',['This is the edge. After this it is all grey. Can we sit for a minute? I have a sandwich, and three questions, and they go together.']); } }
});

/* =========================================================
   CHAPTER 16 (RED): THE GATE OF ASH
   ========================================================= */
function gateScene(id,red){
  const leader=red?'Captain Halbeak':'Warden Ruddock';
  const gpal=red?BLUE_PAL:WARDEN_PAL, gh='helm';
  sxDef(id,{name:red?'The Crown\'s Line':'The Hollow\'s Line',theme:'ash',dark:0.5,lightR:100,start:[1,5,'right'],
    hint:'Talk to the leader, or slip past the line in the dark. Shadows halve what they see.',
    caughtLines:[red?'"HALT! IN THE KING\'S NAME!" A dozen spears come down. They are young, and very afraid, and not at all sure what they are guarding.':'"HALT!" A dozen wardens in red close the gap. They are tired, and very afraid, and not at all sure what they are guarding.','You are held, not roughly, and set back on the road.'],
    rows:sxGrid(26,11,[[0,5,'D'],[25,5,'E'],[8,1,1,4,'#'],[8,6,1,4,'#'],[17,1,1,4,'#'],[17,6,1,4,'#'],[12,4,'N'],[5,2,4,2,','],[12,7,5,3,','],[20,5,'.'],[21,3,'t'],[21,7,'t']]),
    exits:{D:{to:'world',wx:KX-30,wy:KY-30},E:{fn:S=>{ if(!S.fl.pass){ say('',['A line of soldiers closes the road. You will have to talk, or sneak.']); return; } sxLeave(KX-44,KY-50); S2.finish(red?'c16r':'c16c'); }}},
    trig:[{id:'sneak',tx:19,ty:1,w:2,h:9,fn:S=>{ if(!S.fl.pass){ S.fl.pass=1; s2fl('sneaked',1); toast('You are through the line, unseen.',3200); } }}],
    objs:{N:{name:leader,glyph:'none',solid:false},t:{name:'Torch',glyph:'torch',light:true,lightR:80,solid:true}},
    npcs:[{name:leader,tx:12,ty:5,pal:red?BLUE_PAL:RED_PALS[2],head:red?'helm':'helm',talk:(S,n)=>{
      if(S.fl.pass){ say(leader,['Go. I did not see you.'],null); return; }
      const m=s2fl('march')||s2fl('marchFinal');
      S2.persuade({who:leader,intro:red?['Captain Halbeak has set his men in a line across the road, with the Burnt Wood behind them.','"You. The red duck from the summit. I will not have blood on this road if I can help it. Say what you came to say, in ten words or fewer."']:['Warden Ruddock has set the Hollow\'s wardens across the road, with the Burnt Wood behind them.','"You. The yellow from the summit. I have thought about you since the fire. Say your piece, and spare me the rhetoric."'],
        rounds:[{q:red?'"Why should I let you through?"':'"Why should I let you through?"',opts:[
            {t:'"Because I carry something the sleepers have been waiting for."',p:1,say:['"That is not an answer. That is a poem."']},
            {t:red?'"Because the king asked me to go, and he cannot."':'"Because the king asked me to go, and he cannot."',p:2,req:()=>!!s2fl('echo')||!!g.inv.keeperlantern,say:['A long pause. "...He asked."']},
            {t:'"Because you do not want to do this, and neither do I."',p:2,led:{truth:1},say:['A silence that says more than a speech.']},
            {t:'"Because I will go through anyway."',p:0,led:{pride:1},say:['"Then you are no better than they are."']}]},
          {q:red?'"My men are frightened. They have been told the red ducks are coming to burn the kingdom. How do I tell them you are not?"':'"My wardens have been told the Crown is coming to burn Emberwick. How do I tell them you are not?"',opts:[
            {t:red?'"Tell them the king\'s Captain stood down because he read Eider\'s first draft, and it said shelter."':'"Tell them the Elders sent a small party to ask the sleepers what they want, and not an army."',p:2,say:['"That I can say. That is a thing a man can say."']},
            {t:'Offer to walk through unarmed, with the lantern held high.',p:2,req:()=>!!g.inv.keeperlantern||!!g.inv.hearthcoal,say:['"A lantern. A coal. Yes. Walk. Slowly."']},
            {t:m==='went'?'"I am sorry the march went. It was not what the king wanted."':'"Because I am one duck, and I am not afraid of them."',p:m==='went'?1:0,led:m==='went'?{truth:1}:undefined,say:['"Hm."']}]}],
        need:3,
        win:()=>{ S.fl.pass=1; coin(); s2led(red?'ember':'crown',1); say(leader,['Stand aside. All of you. Let them through. If the king or the Elders hang me for it, I will have done one decent thing.','Go. And, Detective: come back alive.'],()=>{ sxSet(S,17,5,'.'); toast('The line parts.',3000); }); },
        lose:()=>{ say(leader,['No. I am sorry. I cannot. Find another way, or find another argument.'],null); }});
    }}],
    guards:[{name:red?'Crown Soldier':'Hollow Warden',path:[[3,2],[3,8],[6,8],[6,2]],speed:30,range:5,fov:60,pal:gpal,head:gh},
            {name:red?'Crown Soldier':'Hollow Warden',path:[[13,1],[13,9]],speed:28,range:5,fov:60,pal:gpal,head:gh,pause:0.8,scan:true},
            {name:red?'Crown Soldier':'Hollow Warden',path:[[21,2],[21,8]],speed:30,range:5,fov:60,pal:gpal,head:gh,pause:0.6,scan:true,off:S=>!!S.fl.pass}],
    onEnter(S){ if(!S.fl.hint){ S.fl.hint=1; sxSay(S,'',['The road ends at a line of soldiers, with the Burnt Wood behind them. Grey ash drifts in the lantern light.','Talk to the leader, or slip past. Both are possible. Neither is easy.']); }
      for(const g2 of S.guards){ if(g2.off) {} } }
  });
}
gateScene('bgR',true); gateScene('bgC',false);
S2.ch.c16r={route:'red',title:'The Gate of Ash',sub:'The road ends where the Crown\'s line begins.',
  intro:['The Lantern Road ends at the Burnt Wood\'s edge. And at the edge, a line of men in blue, with their spears planted and their faces set.','Halbeak has not marched into the Hollow. He has marched to the one place both sides must pass. It is the most sensible thing anyone has done all week, and it is going to get somebody killed.'],
  recap:'You passed the Gate of Ash. The Burnt Wood waits.',
  start(){ s2set(0); },
  obj(s){ return ['Go to the <b>Gate of Ash</b>: take the ash path that leaves the road just west of Kingsbill\'s west bridge and runs north along the moat'+hostWhere(28,-1057)+'. Get past the Crown\'s line: argue, or sneak.'][s]; }
};
S2.prop({id:'bgate_r',wx:26,wy:-1004,snap:2,glyph:'banner',col:'#4a6a9a',when:()=>s2at('c16r'),mark:'!',use(){ say('',['The road narrows, and the ash begins. A line of blue stands across it, in the grey.'],); }});

/* =========================================================
   CHAPTER 13 (CROWN): THE COURT
   ========================================================= */
const CRT={id:'ct',title:'Who Wants War?',
  clues:{gander:'Chancellor Gander: the march order carries the king\'s seal, and no signature but the seal. "It was brought to me already stamped."',plume:'Lord Plume: he bought four hundred swords last month from a stranger in grey. "Cheap. Very cheap."',teal:'Lady Teal: her family sat on the Council that rewrote the Edict. "We have been ashamed of it, privately. We have not said so."',mink:'Treasurer Mink: the war chest was opened in the king\'s name, three weeks ago, by a key that is not in the treasury.'},
  links:[{a:'plume',b:'mink',id:'funded',t:'Swords bought cheap from a stranger in grey, paid for from a chest opened by a key nobody can find. Someone is funding this war from outside the court.'},{a:'gander',b:'teal',id:'faction',t:'A seal with no signature, and a family ashamed of the Edict. A faction at court wants the old story to stay true, because the new one would indict them.'}],
  need:['funded','faction'],q:'Who is pushing the kingdom toward war?',
  answers:[{t:'The red ducks, in revenge'},{t:'Families who wrote the Edict, and a stranger who is paying them',ok:1,yes:'Yes. The Council families who cast out the red ducks, still ashamed, and still unwilling to admit it. And someone in grey who has been feeding their fear.'},{t:'The king, in madness'},{t:'Nobody. It is misunderstanding'}]};
const CRTN={'Chancellor Gander':'gander','Lord Plume':'plume','Lady Teal':'teal','Treasurer Mink':'mink'};
const CRTP={'Chancellor Gander':[-6,16,1,'wizard','scarf'],'Lord Plume':[6,17,4,'royal','bowtie'],'Lady Teal':[0,19,5,'bow',null],'Treasurer Mink':[-10,20,3,'cap','scarf']};
Object.keys(CRTP).forEach((nm,i)=>{ const p=CRTP[nm]; S2.npc({id:'court'+i,name:nm,k:[p[0],p[1]],pal:p[2],head:p[3],neck:p[4],when:()=>s2at('c13c'),mark:()=>(s2at('c13c',0)&&!S2.hasClue('ct',CRTN[nm]))||(s2at('c13c',1)&&!s2fl('c_'+CRTN[nm]))?'!':null,talk(n,done){ S2.ch[s2cur()].talk(n,done)||done(); }}); });
function crtCount(){ return Object.values(CRTN).filter(k=>S2.hasClue('ct',k)).length; }
const CRTSAY={gander:['Chancellor Gander wrings his hat.','"The seal. Yes. The seal. I did not question it. A king who has not spoken in a hundred years might sign something. I did not wish to be the one to say it is not his hand."'],plume:['Lord Plume flushes.','"Swords? Oh, yes, a few. A stranger came to the gate with a cart. He was in grey, and polite, and said the king would be pleased. I did not ask who paid. It seemed rude."'],teal:['Lady Teal does not look up from the window.','"My great-great-grandfather sat on the Council. I read his signature on the Edict, once, in the library. I have been ashamed of it since. I did not know what to do with the shame. I think some of us have been looking for somewhere to put it."'],mink:['Treasurer Mink pulls out a ledger, and hands it over, and does not seem to care who sees.','"There. See? The war chest. Opened, three weeks ago. By a key. It is not in the treasury. I have the only key. I have it here. So who has the other?"']};
S2.ch.c13c={route:'crown',title:'The Court',sub:'Somebody is paying for this war, and it is not the king.',
  intro:['The summit failed, and Quackenhold sets its jaw. Halbeak\'s men sharpen. The lords of the Court gather in the plaza, saying "inevitable" in several accents.','But something is wrong with the arithmetic. The war chest is open. The swords are new. The seal is real, and nobody remembers signing for it.'],
  recap:'You found the court faction behind the march. Lady Teal and the Chancellor stood down, and the lords split.',
  start(){ s2set(0); },
  obj(s){ return ['Ask the Court: <b>Chancellor Gander, Lord Plume, Lady Teal, Treasurer Mink</b>, in the Castle Plaza ('+crtCount()+'/4 notes). Open your <b>Case Board</b>.','Persuade the Court to stand down. Speak to <b>Chancellor Gander</b>, <b>Lady Teal</b> and <b>Lord Plume</b> ('+['c_gander','c_teal','c_plume'].filter(k=>s2fl(k)).length+'/3; two are enough).','Report to <b>Captain Halbeak</b>, who is waiting on the south wall.'][s]; },
  board(){ return s2at('c13c',0)?{def:CRT,solved:()=>{ s2set(1); toast('The faction is exposed. Now press them.',4200); }}:null; },
  talk(n,done){
    const s=s2step(), k=CRTN[n.name];
    if(s===0&&k){ if(S2.hasClue('ct',k)){ say(n.name,['I have said what I know.'],done); return true; } say(n.name,CRTSAY[k],()=>{ S2.clue('ct',k,'Clue: '+n.name+'.'); hudCache.obj=null; done(); }); return true; }
    if(s===1&&k&&k!=='mink'){
      const flag='c_'+k;
      if(s2fl(flag)){ say(n.name,['You have my word. I shall say so, in the hall.'],done); return true; }
      const opts={gander:[{t:'"The seal was stamped by the echo. The king is signing in his sleep. Do you want that on your hands?"',p:2,req:()=>!!s2fl('echo'),say:['"The echo. Oh. I feared as much. I will not have it said I enabled a man\'s nightmare."']},{t:'"You are the Chancellor. You may refuse a stamped order."',p:1,say:['"Technically. Yes. Technically."']},{t:'"Do as you are told, Chancellor."',p:0,led:{pride:1},say:['"I have done as I am told for forty years."']}],
        teal:[{t:'"Your family can put the shame down. Put it down now, in public."',p:2,led:{mercy:1},say:['Her wings tremble. "That is the kindest thing anyone has said to me this year."']},{t:'Show her Eider\'s Draft: "Read what the Council changed."',p:2,req:()=>!!g.inv.edictdraft,led:{truth:1},say:['She reads. She does not speak for a long time.']},{t:'"You should be ashamed."',p:0,led:{pride:1},say:['"I am. That is what is wrong."']}],
        plume:[{t:'"The stranger sold you swords at a loss. Why?"',p:2,say:['"...He wanted them used. Not owned. Used."']},{t:'"Return the swords, and nothing will be said."',p:1,say:['"Nothing? Nothing at all?"']},{t:'"You are a fool, Plume."',p:0,led:{pride:1},say:['"Possibly. I am a rich fool."']}]}[k];
      S2.persuade({who:n.name,intro:[n.name+' looks at you, and then, quickly, at the door.'],rounds:[{q:'What do you say?',opts:opts}],need:1,
        win:()=>{ s2fl(flag,1); coin(); const c=['c_gander','c_teal','c_plume'].filter(x=>s2fl(x)).length; toast(n.name+' will stand down. ('+c+'/3)',3000); if(c>=2) s2set(2); hudCache.obj=null; done(); },
        lose:()=>{ say('',['Not persuaded. Try again with something they care about.'],done); }});
      return true;
    }
    if(s===2&&n.name===ROYAL){ seq([[ROYAL,['The Court has stood down. I heard it from three mouths in an hour. Three, in this Court. I have not heard three agree on the weather since I was a recruit.','I owe you an apology, and a report. Both can wait. But there is one more thing, and it is my own.']]],()=>{ S2.finish('c13c'); done(); }); return true; }
    return false;
  },
  mark(n){ if(n.name===ROYAL&&s2at('c13c',2)) return {ch:'!',col:'#ffd166'}; return null; }
};

/* =========================================================
   CHAPTER 14 (CROWN): HALBEAK'S OATH
   ========================================================= */
S2.ch.c14c={route:'crown',title:'Halbeak\'s Oath',sub:'An order, a seal, and a man who has never disobeyed.',
  intro:['Halbeak asks to speak with you alone. In the barracks, with the door shut, he takes a folded page out of his tunic, and puts it on the table.','"The march order. The original, with the seal. I have been carrying it for six days. I swore an oath to the Crown, and this is the Crown\'s hand, and I cannot make myself burn it."'],
  recap:'You swapped the march orders for a recall. Halbeak swore a new oath: not to the seal, but to the king.',
  start(){ s2set(0); },
  obj(s){ return ['Break into the <b>barracks office</b> (Training Yard, east of Kingsbill) and replace the march order with a recall. Halbeak will leave the door on the latch.','Speak to <b>Captain Halbeak</b> at the south wall.'][s]; }
};
S2.prop({id:'barracks',k:[30,30],glyph:'door',col:'#3a3a52',when:()=>s2at('c14c',0),mark:'!',use(){ say('',['The barracks office. The door is on the latch, as promised. Inside, a lamp is burning, and somewhere deeper, boots.'],()=>sxEnter('barr')); }});
sxDef('barr',{name:'The Barracks Office',theme:'castle',indoor:true,dark:0.4,lightR:100,start:[1,6,'right'],
  hint:'The pillars block their sight. Wait until the guards\' backs are turned.',
  caughtLines:['"WHO\'S THAT?" A guard swings a lantern, and finds you, face to face with a desk.','You are seen out, quietly, by someone who is clearly not going to report you. You walk straight back in.'],
  rows:sxGrid(22,13,[[0,6,'D'],[18,2,'O'],[7,4,'P'],[7,8,'P'],[13,4,'P'],[13,8,'P'],[4,1,4,3,','],[14,10,5,2,','],[18,3,'.']]),
  exits:{D:{fn:S=>{ sxLeave(KX+30,KY+31); if(S.fl.swapped&&s2at('c14c',0)) s2set(1); }}},
  objs:{P:{name:'Pillar',glyph:'pillar',block:true,col:'#a8a698'},
    O:{name:'Orders desk',glyph:'desk',desc:'A desk with a stack of orders, and a lamp.',use:(S)=>{
      if(S.fl.swapped){ say('',['The desk is as you found it. The recall is where the march order was.']); return; }
      S.fl.swapped=1; coin();
      seq([['',['You find it in the third drawer: the march order, with its seal. You lay the recall on top of it, in your own hand, and the Royal Seal over the recall, and the two of them look, in the lamplight, as if they have always lived together.']]],()=>{ s2led('crown',1); if(s2fl('march')==='went') s2led('truth',1); toast('The orders are swapped. Leave quietly.',3400); });
    }}},
  guards:[{name:'Barracks Guard',path:[[2,2],[19,2],[19,11],[2,11]],speed:34,range:5,fov:62,pal:BLUE_PAL,head:'helm'},
          {name:'Barracks Guard',path:[[10,1],[10,11]],speed:30,range:5,fov:60,pal:BLUE_PAL,head:'helm',pause:0.8,scan:true},
          {name:'Barracks Guard',path:[[16,6],[20,6]],speed:26,range:5,fov:60,pal:BLUE_PAL,head:'helm',pause:1,scan:true}],
  onEnter(S){ if(!S.fl.hint){ S.fl.hint=1; sxSay(S,'',['The office is long and low, and lit by one lamp. Three guards, three patrols. The desk is at the back. The seal is warm in your satchel.']); } }
});
S2.ch.c14c.talk=function(n,done){
  if(n.name===ROYAL&&s2step()===1){
    seq([[ROYAL,['I read the recall. I read it three times. The king\'s hand, and the king\'s seal, and the king\'s kindness, in a page I did not write.','I swore an oath at nineteen: to obey the Crown. I swear a new one. Not to the seal. Not to the signature. To the one who made it, and he is behind a door, in the dark, and he is the best of us.','Detective. Whatever comes, I stand beside you. I think it will come to that.']]],()=>{ S2.finish('c14c'); done(); }); return true; }
  return false;
};
S2.ch.c14c.mark=function(n){ if(n.name===ROYAL&&s2at('c14c',1)) return {ch:'!',col:'#ffd166'}; return null; };

/* =========================================================
   CHAPTER 15 (CROWN): THE LONG NIGHT
   ========================================================= */
const WATCH=[[-30,-2],[-44,-14],[-56,-24],[-68,-32],[-80,-38]];
function watchCount(){ return [0,1,2,3,4].filter(i=>s2fl('wf'+i)).length; }
S2.h.c15c_dawn=function(){ s2fl('lineWeak',1); hudCache.obj=null; say('',['Dawn. The grey comes up behind the ridge, and shows you the western hills: some of the watch-fires lit, some dark, and a gap in the line you could drive a cart through.','It will hold. It will not hold well.'],()=>{ s2set(2); }); };
S2.ch.c15c={route:'crown',title:'The Long Night',sub:'Five fires, one coal, and a night with no end in sight.',
  intro:['Dusk, on the day before the armies meet. The Crown\'s line along the western hills has gone dark: the watch-fires were never relit after the winter.','You carry a coal of the First Hearth, in an iron cup. It does not go out. It does not burn. It lights anything you ask it to, and it leans, always, toward the Burnt Wood.'],
  recap:'You lit the five watch-fires with the First Hearth\'s coal. Halbeak\'s line held through the night.',
  start(){ if(g.clock<17||g.clock>21) advanceClock(((18.5-g.clock)+24)%24); S2.deadline('night',10,'Dawn','c15c_dawn'); s2set(0); },
  obj(s){ return ['','Light the <b>five watch-fires</b> on the western hills with the Coal of the First Hearth, before dawn ('+watchCount()+'/5).','Report to <b>Hermit Mallow</b> at the watchtower.'][s]||(s>2?'Report to <b>Hermit Mallow</b> at the watchtower.':'Light the <b>five watch-fires</b> ('+watchCount()+'/5).'); },
  mark(n){ if(n.name==='Hermit Mallow'&&s2at('c15c',2)) return {ch:'!',col:'#ffd166'}; return null; },
  talk(n,done){
    if(n.name==='Hermit Mallow'&&s2at('c15c',2)){ seq([[H3,s2fl('lineWeak')?['The line is thin. But it held. A few lit fires are better than none, and a few men who believe in them are better than a wall.','Little detective. I watched you from the tower. All night. You did not stop.']:['All five. All lit. The whole line, from the tower to the lake. They say the sky over the hills was gold until dawn.','Little detective. I watched you from the tower. All night. You did not stop.']],[H3,['Tomorrow, at the Gate of Ash, there is a line of my own people in red, and I would give a great deal to be on the other side of it. I will be at your elbow. I will be useless and afraid.']]],()=>{ S2.finish('c15c'); done(); }); return true; }
    return false;
  }
};
S2.npc({id:'mallow15',name:'Hermit Mallow',k:[-84,-34],pal:RED_PALS[0],head:'hood',when:()=>s2at('c15c',2),mark:'!',talk(n,done){ S2.ch.c15c.talk(n,done); }});
WATCH.forEach((p,i)=>S2.prop({id:'wf'+i,k:p,glyph:'lantern',colf:()=>s2fl('wf'+i)?'on':null,when:()=>s2at('c15c',0,1),mark:()=>s2fl('wf'+i)?null:'!',use(){
  if(s2fl('wf'+i)){ say('',['The watch-fire burns gold and steady.']); return; }
  if(!g.inv.hearthcoal){ say('',['You will need the Coal of the First Hearth.']); return; }
  s2fl('wf'+i,1); coin(); if(s2step()===0) s2set(1);
  const n=watchCount(); toast('The coal lights the watch-fire. ('+n+'/5)',2800);
  if(n>=5){ S2.clearDeadline('night'); s2led('crown',1); toast('The line is lit. Go to Mallow at the watchtower.',4000); s2set(2); }
  hudCache.obj=null;
}}));

/* =========================================================
   CHAPTER 16 (CROWN): THE GATE OF GOLD
   ========================================================= */
S2.ch.c16c={route:'crown',title:'The Gate of Gold',sub:'The same road, from the other side.',
  intro:['The Burnt Wood\'s west gate. A line of red wardens across the road, with the Hearth\'s flame on a staff in the middle of them, and Ruddock, in front, with his arms folded.','He has the look of a man who has made a decision and would very much like someone to talk him out of it.'],
  recap:'You passed the Hollow\'s line. The Burnt Wood waits.',
  start(){ s2set(0); },
  obj(s){ return ['Go to the <b>Gate of Gold</b>: take the ash path that leaves the road just west of Kingsbill\'s west bridge and runs north along the moat'+hostWhere(28,-1057)+'. Get past the Hollow\'s line: argue, or sneak.'][s]; }
};
S2.prop({id:'bgate_c',wx:26,wy:-1004,snap:2,glyph:'banner',col:'#c0392b',when:()=>s2at('c16c'),mark:'!',use(){ say('',['The road narrows, and the ash begins. A line of red stands across it, in the grey, with a flame on a staff.'],); }});
