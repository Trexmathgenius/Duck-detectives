'use strict';
/* ===== ACT II, CROWN PATH: TAKING A SIDE ===== chapters 5 to 8 ===== */

const ROYAL='Captain Halbeak';
function crownStand(){ try{ return crownStanding(); }catch(e){ return 0; } }
ITEMS.edictdraft={name:'Eider\'s Draft',desc:'Four pages in a steady, young hand. The Red Edict, as its author first wrote it. It is not the Edict you were taught.',use:'note',note:'"...and let those of the red feather go north, and be sheltered there, until it is safe."',nogift:true};
ITEMS.royalseal={name:'Royal Seal',desc:'A heavy blue seal-ring on a chain. It has not been used in a hundred days, and it is still warm from the king\'s hand.',use:'note',note:'It will stop an order. It will not make anyone believe you.',nogift:true};
ITEMS.hollowtoken={name:'Hollow Token',desc:'A small wooden disc, burned with a flame inside a door. Mallow says it opens the door beneath the Hearth, from the outside, once.',use:'note',note:'It is warm. It hums very faintly, like a held note.',nogift:true};
Object.assign(RICON,{
  edictdraft:(R,C,E)=>{ R(3,3,10,10,'#f2e6c4'); R(3,3,10,2,'#d9c9a0'); R(5,6,6,1,'#8a6a3a'); R(5,8,6,1,'#8a6a3a'); R(5,10,4,1,'#c0392b'); },
  royalseal:(R,C,E)=>{ C(8,9,5,'#2a3a7a'); C(8,9,3,'#e0b84a'); R(7,2,2,3,'#9a9aa4'); },
  hollowtoken:(R,C,E)=>{ C(8,8,6,'#8a5a2b'); C(8,8,4,'#6a3f1e'); R(7,5,2,5,'#ff9d2e'); R(6,7,4,2,'#ff9d2e'); }
});
function crownIntro(){ hermitGoHome(); }

/* =========================================================
   CHAPTER 5 (CROWN): THE ROYAL DETECTIVE
   ========================================================= */
const DT={id:'dt',title:'The Dreaming Town',
  clues:{oats:'Farmer Oats: his crows will not fly toward the north-west woods. Not for corn, not for bread.',
    millie:'Millie the Miller: the mill sails turn by themselves at night, slowly, toward the north-west.',
    rue:'Old Rue: the graves in the Siege Field hum the same lullaby, all of them, when the wind is right.',
    thistle:'Warden Thistle: the Siege Field will not grow grass. Beyond the north-west ridge, the king\'s spell changed Gordamom.',
    pip:'Pip Ember: the tower crystal hums when anyone says "Gordamom". It is louder every week.',
    penna:'Archivist Penna: the original Edict has a last line that is in no copy. A word of Eider\'s, in the margin, scratched out.'},
  links:[{a:'oats',b:'millie',id:'pull',t:'Crows and sails agree. Something in the Burnt Wood is pulling at living things, and has begun to pull harder.'},
    {a:'rue',b:'pip',id:'voice',t:'The graves hum a lullaby and the crystal hums a name. One voice, answering itself across the kingdom.'},
    {a:'thistle',b:'penna',id:'ward',t:'A king spoke a word on his wall, and the Wood stopped. A ward. A word that is still being held, a hundred years on.'}],
  need:['pull','voice','ward'],q:'What is happening to the kingdom?',
  answers:[{t:'The red ducks are working a curse from Emberwick',no:'It fits nothing on the board. An hour is lost, and you feel a little ashamed.'},{t:'The Burnt Wood is waking, behind the king\'s ward',ok:1,yes:'Yes. It all lines up: the pull, the humming, the word. The king has held something asleep for a hundred years, and he is losing his grip.'},{t:'Gordamom\'s ghost is haunting the kingdom'},{t:'Nothing. A run of coincidences'}]};
const DTNPC={'Farmer Oats':'oats','Millie the Miller':'millie','Old Rue':'rue','Warden Thistle':'thistle','Pip Ember':'pip','Archivist Penna':'penna'};
const DTSAY={oats:['Farmer Oats scratches his head.','"My crows. Sixty years, never a day they would not fly for corn. Now they sit on the fence, all facing the same way, and will not go north-west for love or bread. Do you know what that is? That is fear. Birds have good reasons."'],
  millie:['Millie the Miller wipes her wings on her apron.','"The sails turn all night, you know. Nobody pushes them. Slow, always toward the north-west. As if somebody was calling the wind. I stopped the mill last week. It started itself again."'],
  rue:['Old Rue looks up from the grave she is tending.','"They hum, you see. Every one. The same four notes. A lullaby. I asked the Warden what it was and he said it was the wind. Wind does not know the second verse."'],
  thistle:['Warden Thistle straightens, and looks past you, up the ridge.','"The ground here will not grow grass, in the places where the red ducks fell. A hundred years. Past that ridge the king turned Gordamom into a tree, with a word. My grandfather watched. He did not say what the word was. He said it was the kindest thing he ever saw, and the worst."'],
  pip:['Pip Ember jumps, and drops a duster.','"The crystal! It hums if you say the name. Gordamom. See? No, do not say it. It does not like it. I think... I think it is not the crystal. I think it is the king, humming. Through the crystal. Do not tell anyone I said that."']};
function dtCount(){ return Object.values(DTNPC).filter(k=>S2.hasClue('dt',k)).length; }
S2.ch.c5c={route:'crown',title:'The Royal Detective',sub:'The Crown has a case. It is the first time in a century it has asked.',
  intro:['You wake in the inn at Kingsbill with a purse of three hundred crumbs and a headache the size of a castle.','The dinner is a blur: a long cold hall, a voice from the dark, a table laid for two. The voice said very little, and every word of it was kind. It said the kingdom was ill. It said it needed a detective.','On the pillow beside you, a letter with a blue seal.'],
  recap:'The king set you to find what ails the kingdom. You answered: the Burnt Wood is waking behind his ward.',
  start(){
    crownIntro(); addItem('caseboard');
    seq([
      ['Royal Letter',['"To the Detective, with the Crown\'s thanks."','"You have been to the dark side of this kingdom and returned. We have not. We should like you to go about the realm, quietly, and tell us what you find. Ask the people who have noticed. They are the ones nobody asks."','"Pin what you learn. Put what fits beside what fits. When you are sure, bring us the answer, by way of our Captain. - E."']],
      ['',['(A cork board in a leather folio is tucked inside the envelope. It is yours now. Open it from your bag to read your notes and link clues together.)']]
    ],()=>s2set(0));
  },
  obj(s){ return ['Ask around the kingdom: <b>Farmer Oats, Millie the Miller, Old Rue, Warden Thistle, Pip Ember, Archivist Penna</b> ('+dtCount()+'/6 notes). Open your <b>Case Board</b> (bag) to link them.',
    'Take your answer to <b>Captain Halbeak</b>, at the Castle Plaza.'][s]; },
  board(){ return s2at('c5c',0)?{def:DT,solved:()=>{ s2set(1); toast('Answer found. Take it to Captain Halbeak.',4200); }}:null; },
  mark(n){ const k=DTNPC[n.name]; if(k&&s2at('c5c',0)&&!S2.hasClue('dt',k)) return {ch:'!',col:'#ffd166'}; if(n.name===ROYAL&&s2at('c5c',1)) return {ch:'!',col:'#ffd166'}; return null; },
  talk(n,done){
    const s=s2step(), k=DTNPC[n.name];
    if(s===0&&k){
      if(S2.hasClue('dt',k)){ say(n.name,['I have told you all I know. Mind how you go.'],done); return true; }
      if(k==='penna'){
        S2.persuade({who:n.name,intro:['Archivist Penna adjusts her spectacles.','"The Royal Library does not lend its marginalia. Not to the public, and not to yellow ducks with an inn-room smell. Why should I?"'],
          rounds:[{q:'What do you say?',opts:[
            {t:'Show the royal letter and its seal.',p:2,led:{crown:1},say:['She reads it twice, and her spectacles slip.','"The Crown asks? In its own hand? Come. Quietly."']},
            {t:'"Because the people who scratched it out were ashamed. Weren\'t they?"',p:2,led:{truth:1},say:['A long pause.','"...Yes. I have thought so for forty years. Nobody has ever asked me."']},
            {t:'"Because I will find it anyway."',p:0,led:{pride:1},say:['"Will you now. The library has a great many shelves, and a great many doors, and I have all the keys."']},
            {t:'Tell her your standing in the realm.',p:1,req:()=>crownStand()>=1,say:['"Hm. The towns speak well of you. That counts for something."']}]}],need:2,
          win:()=>{ say(n.name,DTSAY.penna||['Archivist Penna lowers her voice.','"There is a last line in the original Edict, in the margin, in Eider\'s own hand. It was scratched out in the same ink as the rest. But ink is vain. It ghosts. I have held it to the window for forty years: one word. I will not say it. I cannot. It seems to be an old word. It seems like a promise."'],()=>{ S2.clue('dt','penna','Clue: Archivist Penna.'); hudCache.obj=null; done(); }); },
          lose:()=>{ say('',['The door of the archive closes, politely. You could try again with something better to offer.'],done); }});
        return true;
      }
      say(n.name,DTSAY[k],()=>{ S2.clue('dt',k,'Clue: '+n.name+'.'); hudCache.obj=null; done(); }); return true;
    }
    if(s===1&&n.name===ROYAL){
      seq([[P3,['The Burnt Wood is waking, Captain. Behind the king\'s ward. The crows, the sails, the graves, the crystal: it is one thing. I would stake my badge.']],
        [ROYAL,['The Burnt Wood. Waking. You say it as if it were weather.','I saw the walls of the castle go quiet, the night the voice stopped speaking in anything but the king\'s own tone. I have a hundred and twelve men on this wall and not one has slept through a night in a month.','You will go further than I may, Detective. The king wishes you to see where he lives. Tonight, after dark: the servants\' door, east side. Take nothing. Say nothing. See everything.']]],()=>{ S2.finish('c5c'); done(); });
      return true;
    }
    return false;
  }
};

/* =========================================================
   CHAPTER 6 (CROWN): THE SILENT CASTLE
   ========================================================= */
S2.ch.c6c={route:'crown',title:'The Silent Castle',sub:'A castle where nobody sleeps, and nobody speaks.',
  intro:['Quackenhold at night. Every window is lit. Nobody is awake in any of them.','The servants\' door stands an inch ajar, as if someone had been told to leave it so. Beyond it, a hundred years of silence is waiting to be disturbed.'],
  recap:'You read Eider\'s first draft of the Edict. The Edict said: shelter. Then the Council changed it.',
  start(){ s2set(0); },
  obj(s){ return ['After dark, go to the <b>servants\' door</b>, east side of the castle. Get inside.',
    'The servants\' hall: find the keys, and slip past the night watch. The way up is at the east end.',
    'The Crystal Stair: the candles must be lit in the right order. Study what the stair is telling you.',
    'The king\'s study: read what he left, then try the throne door.'][s]; }
};
S2.prop({id:'servantdoor',k:[11,10],glyph:'door',col:'#3a3a52',when:()=>s2at('c6c',0,3),mark:'!',use(){
  const t=g.clock;
  const go=()=>{ if(s2step()===0) s2set(1); say('',['The door gives without a sound. The kitchens beyond smell of bread nobody ate.'],()=>sxEnter('cs1')); };
  if(t>=21||t<5) go();
  else choose('The servants\' door','It is not dark enough. The night watch is sleepy only after midnight.',['Wait for night','Come back later'],k=>{ if(k===0){ fade(1.2); advanceClock(((21.2-g.clock)+24)%24); setTimeout(go,300); } },1);
}});
sxDef('cs1',{name:'The Servants\' Hall',theme:'castle',indoor:true,dark:0.42,lightR:100,start:[1,5,'right'],
  hint:'The pillars block their sight. The dark floor halves how far they can see. Time your crossing.',
  caughtLines:['"WHO GOES THERE?" A lantern swings. The guard\'s face is gaunt and sleepless.','You are escorted, politely and without a word, back to the door.'],
  rows:sxGrid(22,11,[[0,5,'D'],[21,5,'>'],[6,4,'P'],[6,6,'P'],[12,4,'P'],[12,6,'P'],[3,8,4,2,','],[14,1,5,2,','],[8,9,'k'],[16,8,'S'],[18,5,'.']]),
  doors:[{tx:19,ty:5,key:'key'}],
  exits:{D:{to:'world',wx:KX+11,wy:KY+11},'>':{to:'cs2',tx:1,ty:5,dir:'right'}},
  objs:{
    P:{name:'Pillar',glyph:'pillar',block:true,col:'#a8a698'},
    k:{name:'Key hooks',glyph:'chest',desc:'A rack of keys on hooks, each tagged in a tidy hand.',use:(S)=>{ if(S.fl.key){ say('',['The rack hangs empty, except for one hook.']); return; } sxOpen(S,'key'); say('',['You run a claw down the tags. "Pantry." "Linen." "Stair." That one is warm, as though somebody held it a moment ago and then forgot why.']); }},
    S:{name:'Steward\'s desk',glyph:'desk',desc:'A steward\'s desk, with a ledger left open.',use:(S)=>{ s2fl('stairHint',1); say('Steward\'s Ledger',['"Servants are to light the Crystal Stair in the colours of the flag: first the gold, for the Crown. Then the blue, for the sky. Then the white, for the swan. Never otherwise. The stair remembers."','(You pin it to your board, mentally.)']); }}
  },
  guards:[{name:'Night Guard',path:[[2,2],[19,2],[19,8],[2,8]],speed:34,range:5,fov:62,head:'helm'},
          {name:'Night Guard',path:[[9,1],[9,9]],speed:30,range:5,fov:60,head:'helm',pause:0.8,scan:true}],
  onEnter(S){ if(!S.fl.hint){ S.fl.hint=1; sxSay(S,'',['The kitchens. Cold ovens, laid tables, and two guards pacing in the half-dark with their eyes open and nobody home behind them.','You need the stair key. Then the east end. They have not blinked in ten minutes.']); } }
});
sxDef('cs2',{name:'The Crystal Stair',theme:'tower',indoor:true,dark:0.5,lightR:90,start:[1,5,'right'],
  rows:sxGrid(15,11,[[0,5,'<'],[14,5,'>'],[3,2,'g'],[7,2,'b'],[11,2,'w'],[7,6,'X'],[13,5,'.']]),
  doors:[{tx:13,ty:5,key:'open'}],
  exits:{'<':{fn:S=>{ if(s2red()) sxGoto('inf2',22,6,'left'); else sxGoto('cs1',20,5,'left'); }},'>':{to:'cs3',tx:1,ty:4,dir:'right'}},
  objs:{
    g:{name:'Gold candle',glyph:'candle',key:'cg',desc:'A tall gold candle in a sconce, unlit.',use:(S)=>candlePick(S,'g','gold')},
    b:{name:'Blue candle',glyph:'candle',key:'cb',desc:'A tall blue candle in a sconce, unlit.',use:(S)=>candlePick(S,'b','blue')},
    w:{name:'White candle',glyph:'candle',key:'cw',desc:'A tall white candle in a sconce, unlit.',use:(S)=>candlePick(S,'w','white')},
    X:{name:'Tower crystal',glyph:'crystal',solid:true,desc:'A pillar of blue crystal that fills the stairwell. It hums, very low, one note, and the note is the shape of a name.',use:(S)=>{ say('',['The crystal is warm. Looking into it, you see the stair reversed: the candles in a different order, and a door that is open. Behind the door, someone is sitting very still.'+(s2fl('stairHint')?'':' (You wish you had found something that told you the order.)')]); }}
  },
  onEnter(S){ if(!S.fl.hint){ S.fl.hint=1; sxSay(S,'',['A spiral stair, bright blue, wound around the great tower crystal. Three unlit candles in three sconces. A door at the top, shut.','The stair is waiting for something. It has been waiting for a hundred years, and is a little weary of it.']); } }
});
function candlePick(S,k,nm){
  if(S.fl.open){ say('',['The candle burns steady. The stair is satisfied.']); return; }
  const seqn=S.cseq||(S.cseq=[]); if(S.fl['c'+k]){ say('',['It is lit already.']); return; }
  const want=['g','b','w'][seqn.length];
  if(k===want){ seqn.push(k); S.fl['c'+k]=1; coin(); toast('The '+nm+' candle catches.',1800);
    if(seqn.length===3){ S.fl.open=1; coin(); say('',['The third flame catches, and the stair goes bright from the crystal outward, gold, blue, and white, like a flag in the wind. The door at the top swings open.']); } }
  else { S.cseq=[]; for(const c of ['cg','cb','cw']) S.fl[c]=0; toast('The flames gutter, and go out. Wrong order. The stair has forgotten nothing.',3200); }
}
sxDef('cs3',{name:'The King\'s Study',theme:'castle',indoor:true,dark:0.35,lightR:110,start:[1,4,'right'],
  rows:sxGrid(13,9,[[0,4,'<'],[12,4,'T'],[3,1,5,1,'h'],[6,3,'D'],[9,6,'c'],[3,6,'q'],[2,3,'r']]),
  exits:{'<':{to:'cs2',tx:13,ty:5,dir:'left'}},
  objs:{
    h:{name:'Shelves',glyph:'shelf',desc:'Books on kingship, on masonry, on the migration of swans. Every spine is cracked. Someone read all of them, looking for a different book.'},
    D:{name:'Eider\'s desk',glyph:'desk',desc:'A writing desk. A single drawer, unlocked.',use:(S)=>{
      if(S.fl.read){ say('',['The drawer is empty. The four pages are in your satchel.']); return; }
      S.fl.read=1; addItem('edictdraft'); s2fl('journal',1); coin();
      seq([['Eider\'s Draft',['"The Red Edict. First draft. E., on the wall, the night before the bells."','"To the council: The red ducks are many, and afraid. A frightened people fights; a people allowed to leave may be sheltered. Let them go north, into the great wood, and be given leave to light their fires there, unharmed. Let those of the red feather go, and be sheltered, until it is safe."']],
        ['Eider\'s Draft',['(A second hand has struck through "sheltered" and written "cast out". A third has struck through "until it is safe" and written nothing.)','"I signed it. I signed what they brought me. I told myself the word was the same. It was not."']],
        ['',['The last page is not a draft. It is a note, written very recently, in a hand that shakes.','"If anyone reads this: I am not asleep. I am keeping something. I am keeping all of it. Do not open the door."']]],()=>{ hudCache.obj=null; });
    }},
    c:{name:'Cold hearth',glyph:'fireplace',desc:'A hearth, scrubbed clean. The ash has been swept into a perfect circle, and left.'},
    q:{name:'Chair',glyph:'chair',desc:'A high-backed chair, facing the great black door. It has the shape of someone who sat in it for a very long time.'},
    r:{name:'Rug',glyph:'rug',solid:false,col:'#2a3a7a'},
    T:{name:'The throne door',glyph:'gate',solid:true,desc:'A tall door of black iron, bound with silver wire. Something on the other side is breathing. Slowly. In time with the crystal.',use:(S)=>{
      if(!S.fl.read){ say('',['Locked, and a deep note answers your knock. You feel you ought to know more before knocking again. (The desk has a drawer.)']); return; }
      const red=s2red(), fin=()=>{ s2fl('echo',1); sxLeave(KX+11,KY+11); S2.finish(red?'c9r':'c6c'); };
      if(red) seq([['',['You lay a wing on the iron. It is as warm as an egg. In your satchel, the Keeper\'s Lantern leans toward the door, and burns so brightly it throws your shadow across the ceiling.']],
        ['The Voice',['"The lantern. Oh. They have sent me the lantern. Do not bring it nearer. I cannot... it is too like home."','"You are the red one. The yellow one. Cinder\'s duck. Of course. Of course they would send you. I should have known how it would be."','"I cannot open the door. I am the door. But I can tell you where to come, and when, and I will see you then. Wait for the summons. And please. Be kind to the Captain. He thinks he is guarding a king."']],
        ['',['The voice does not say goodbye. It is simply not there, the way a clock is not there when it has stopped.']]],fin);
      else seq([['',['You lay a wing on the iron. It is as warm as an egg. From the other side, a voice, close, in a tone you have heard once, across a long cold table.']],
        ['The Voice',['"Detective. You read it. Good. That is the first thing I wanted. I did not have the courage to say it."','"I cannot open the door. Do not ask it of me. It is not that I will not. It is that I am the door."','"Go to the Captain. Tell him what you found. There is a march being drawn up in my name, and I am signing it, because I am signing everything, and I cannot stop my hand."']],
        ['',['The voice does not say goodbye. It simply is not there, the way a clock is not there when it has stopped.']]],fin);
    }}
  }
});

/* =========================================================
   CHAPTER 7 (CROWN): THE MARCH
   ========================================================= */
S2.h.c7c_march=function(){ if(!s2at('c7c')) return; s2fl('march','went'); hudCache.obj=null; say('Captain Halbeak',['The horn sounds on the south wall. Three hundred and twelve ducks, in blue, march out of Kingsbill toward the Hollow Wood.','You are too late.'],()=>{ if(s2at('c7c')) s2set(4); }); };
S2.ch.c7c={route:'crown',title:'The March',sub:'An order signed in a sleeping hand.',
  intro:['The next morning the whole of Kingsbill smells of polish and sharpened steel.','The Herald is on the plaza steps, hoarse. The Captain is in the Training Yard. And the king, somewhere behind his black door, is signing every page they bring him.'],
  recap:'Halbeak\'s march on Emberwick: stopped, delayed or sent, depending on what you showed him.',
  start(){ seq([['Herald Fanfare',['Hear ye! Hear ye! By order of the Crown, three hundred of the Royal Guard are to march on the red town, at noon, to "secure the realm"! Hear ye, further: nobody told me why!']],[P3,['(Six hours. That is all you have.)']]],()=>{ S2.deadline('march',6,'The March','c7c_march'); s2set(0); }); },
  obj(s){ return ['The Captain means to march at noon. Find what will stop him: the <b>Royal Seal</b> from <b>Pip Ember</b> ('+(g.inv.royalseal?'got it':'not yet')+'), and <b>Warden Thistle</b>\'s word at the Siege Field, far south-west of the castle, past the moat ('+(s2fl('thistleOk')?'heard':'not yet')+'). You already hold <b>Eider\'s Draft</b>. Then speak to <b>Captain Halbeak</b> at the Training Yard (south-east of the castle plaza).',
    'Speak to <b>Captain Halbeak</b> at the Training Yard (south-east of the castle plaza).','','','Your order has gone out. Walk west to the old watchtower hills. A <b>red feather</b> has been asking for you.'][s]; },
  journal(line){ const m=s2fl('march'); if(m) line('The march: '+({stopped:'stopped',delayed:'delayed',went:'sent'})[m]+'.','jdim'); },
  mark(n){ if(n.name==='Pip Ember'&&s2at('c7c',0)&&!g.inv.royalseal) return {ch:'!',col:'#ffd166'}; if(n.name==='Warden Thistle'&&s2at('c7c',0)&&!s2fl('thistleOk')) return {ch:'!',col:'#ffd166'}; if(n.name===ROYAL&&s2at('c7c',0,1)) return {ch:'!',col:'#ffd166'}; if(n.name==='Scout Wick'&&s2at('c7c',4)) return {ch:'!',col:'#ffd166'}; return null; },
  talk(n,done){
    const s=s2step();
    if(s===0&&n.name==='Pip Ember'){
      if(g.inv.royalseal){ say(n.name,['Keep it safe! It is warm. That is odd. It has never been warm.'],done); return true; }
      seq([['Pip Ember',['The seal? The King\'s seal? It is in the study cabinet. I mean, it was. I... he gave it to me, last night, in a dream. It was in my apron when I woke.','He said: "For the man who asks." I think that is you. Take it. Please do not make me say that twice.']]],()=>{ addItem('royalseal'); coin(); toast('Received: the Royal Seal.',3600); done(); }); return true;
    }
    if(s===0&&n.name==='Warden Thistle'){
      if(s2fl('thistleOk')){ say(n.name,['I have said my piece. Go.'],done); return true; }
      seq([['Warden Thistle',['A march on Emberwick? Against them? These are the grandchildren of the people we buried.','I will say it to the Captain myself, if he will listen: the ground here is full of children who were marching home. Do not make more of them.']]],()=>{ s2fl('thistleOk',1); toast('Warden Thistle will speak for you.',3200); done(); }); return true;
    }
    if(s===4&&n.name==='Scout Wick'){ const m=s2fl('march');
      seq([['Scout Wick',['Detective! A red feather has been asking for you. He is up in the old tower, and he is very polite about being a fugitive.',m==='went'?'(Far behind you, a horn sounds, and keeps sounding.)':'(The wind is quiet.)']]],()=>{ S2.finish('c7c'); done(); }); return true; }
    if(n.name===ROYAL&&(s===0||s===1)){
      const have=[!!g.inv.edictdraft,!!g.inv.royalseal,!!s2fl('thistleOk')];
      S2.persuade({who:ROYAL,intro:['Captain Halbeak is buckling a strap, and does not look up.','"State your business, Detective. I have six hundred boots to count and an order I do not like."'],
        rounds:[
         {q:'"What do you want me to do, exactly?"',opts:[
           {t:'"Stand down. The king did not write this. He signed it asleep."',p:1,led:{truth:1},say:['"That is not as comforting as you think. A king who signs asleep is a king who needs a captain."']},
           {t:'Show him the Royal Seal, and its warmth.',p:2,req:()=>!!g.inv.royalseal,led:{crown:1},say:['He takes the ring. Turns it over. His wing is not quite steady.','"It is warm. I have never felt it warm. All right. All right. I believe it came from his hand."']},
           {t:'"Delay. One day. Give me one day."',p:1,say:['"A day. The order says noon."']}]},
         {q:'He looks at you at last. "And why should a blue duck believe a yellow one?"',opts:[
           {t:'Show him Eider\'s Draft. "Read the first line."',p:2,req:()=>!!g.inv.edictdraft,led:{truth:1},say:['He reads. His jaw works.','"\'Sheltered.\' He wrote \'sheltered.\' And we taught our children \'cast out\'. For a hundred years."']},
           {t:'"The Siege Field wardens will speak. The graves hum a lullaby."',p:2,req:()=>!!s2fl('thistleOk'),say:['"Thistle. I have known Thistle thirty years. She has never once lied to me, even when I wanted her to."']},
           {t:'"Because if you march, you will do exactly what they did. And you will be the one who is ashamed."',p:1,led:{pride:1},say:['A very long silence.','"That is not fair."','"It is not unfair, either."']}]},
         {q:'He holds the order in one wing. "Last thing. I am not asking what you believe. I am asking what I tell my men."',opts:[
           {t:'"Tell them the Crown asks for patience. And that I vouch for it."',p:1,led:{crown:1},say:['"I will tell them the Crown asks. I will not tell them about you."']},
           {t:'"Tell them the truth. That something old is waking, and you will not be the one to wake it faster."',p:2,led:{truth:1},say:['"...Yes. That is it. That is the first thing anyone has said all week I could say to my men."']}]}],
        need:2,
        win:(sc)=>{ S2.clearDeadline('march'); const v=sc>=4?'stopped':'delayed'; s2fl('march',v); if(v==='stopped') s2led('crown',1);
          seq([[ROYAL,v==='stopped'?['Stand down. All of you. Unbuckle. The march is cancelled by the hand of the Crown, and by the hand of this yellow duck, which is a sentence I never thought I would say.','Detective. I have a great deal of apologising to do, and I will begin with my own men.']:['A day. I will give you one day. The order will be read, and not obeyed, and I will write that I was ill.','Use the day well. I do not think I can give you a second.']]],()=>{ s2set(4); done(); }); },
        lose:()=>{ S2.clearDeadline('march'); s2fl('march','went'); say(ROYAL,['I am sorry. I would have liked to believe you.','Sound the horn. We march.'],()=>{ s2set(4); done(); }); }});
      return true;
    }
    return false;
  }
};
S2.zone({id:'march_out',k:[0,35],r:200,when:()=>s2at('c7c',4),fn(){ /* kept for the harness: finish handled by wick */ }});

/* =========================================================
   CHAPTER 8 (CROWN): THE WATCHTOWER
   ========================================================= */
const TW=[
  {id:'lamp',nm:'The signal lamp',at:[-82,-32],q:'The signal lamp on the tower wall has been dark since before the siege. You clean the glass, trim the wick, and light it.',led:'trust'},
  {id:'door',nm:'The tower door',at:[-84,-30],q:'The door hangs on one hinge, and the tower is cold. You prop it, bind the hinge with your own scarf, and swing it shut. It holds.',led:'trust'},
  {id:'well',nm:'The old well',at:[-86,-33],q:'The well is choked with leaves. You clear it, draw a bucket, and carry water up for a man who has not had a hot drink in three nights.',led:'mercy'}
];
function twDone(){ return TW.filter(t=>s2fl('tw_'+t.id)).length; }
S2.ch.c8c={route:'crown',title:'The Watchtower',sub:'The hermit cannot come to you. You will have to go to him.',
  intro:['The old watchtower stands on the west hills, a stump of stone with a lamp room nobody has lit since the war.','In its shadow, someone has made a small fire out of nothing and sat down beside it. He looks very tired. He looks, as you climb, as if he is not entirely sure you are real.'],
  recap:'You earned Mallow back with three small kindnesses. He gave you a Hollow Token: a door beneath the Hearth, once.',
  start(){ st_(); s2set(0); },
  obj(s){ return ['Climb to the <b>old watchtower</b> in the west hills. A red hermit is waiting.',
    'Mallow does not trust you yet. Earn it: the <b>lamp</b>, the <b>door</b>, the <b>well</b> ('+twDone()+'/3). Then speak with him.',
    'Sit with <b>Hermit Mallow</b>.'][s]; },
  mark(n){ if(n.name==='Hermit Mallow'&&s2at('c8c',0,2)) return {ch:'!',col:'#ffd166'}; return null; },
  talk(n,done){
    if(n.name!=='Hermit Mallow') return false;
    const s=s2step();
    if(s===0){
      seq([[H3,['(He stands. Sits. Stands again.)','Little detective. You dined with him. You sat at the king\'s own table, and they cast you out, and all I said was her name, and it did no good.','I came anyway. I am very bad at being angry at people I like.']],
        [H3,['But I cannot just trust you again. I was wrong once, about the wrong thing, and it cost my Elders\' faith. I need you to show me. Not in words. Words are the cheapest thing in the Wood.','The tower needs mending. Small things. A lamp, a door, a well. If you are the duck I think you are, you will do them without being asked twice.']]],()=>{ s2set(1); done(); });
      return true;
    }
    if(s===1){
      if(twDone()<3){ say(H3,['The tower is still cold. Lamp, door, well. In whatever order your conscience prefers.'],done); return true; }
      S2.persuade({who:H3,intro:['Mallow has a mug of hot water in both wings. He looks at it as if it were a letter.','"Three small things. I did not ask for the third. You did the third because the well was choked. That is the one that counted."'],
        rounds:[{q:'What do you say?',opts:[
          {t:'"I am sorry. I chose the table over you, and I cannot undo it."',p:2,led:{truth:1,trust:1},say:['He nods, slowly.','"Thank you. That was the correct sentence."']},
          {t:'"Tell me what Emberwick needs."',p:2,led:{mercy:1},say:['"Oh. Oh, well. That is the correct sentence too. Sit."']},
          {t:'"I did what a detective does."',p:0,led:{pride:1},say:['"Yes. And you may do it again, when you have learned the other half of the sentence."']}]},
         {q:'He puts down the mug. "The Elders have not forgiven you. I have, partly. What will you do with that?"',opts:[
          {t:'"Let me earn the rest."',p:2,led:{trust:1},say:['"Good."']},
          {t:'"Whatever Cinder asks."',p:1,led:{kin:0},say:['"Cinder does not ask. She waits. It is worse."']},
          {t:'"Nothing. I do not deserve it."',p:0,say:['"That is not humility, little detective. That is a way of not trying."']}]}],need:2,
        win:()=>{ seq([[H3,['All right. Here.','(He presses a small wooden disc into your wing. A flame, burned inside a door.)','There is a door under the Great Hearth, for emergencies. Poppy found it, because Poppy finds everything. It opens from outside, once. Cinder says the Hearth is failing, and a yellow duck may be the only one who can say so to the king.','The way in is dangerous. You will be a banished duck sneaking into a town that cast you out. I will be there. At the old well, at midnight. And little detective: bring the Draft.']],
            ['',['You hold the token. It is warm. It hums, very faintly, like a held note. The king has a crystal that hums in the dark. This one hums in your hand.']]],()=>{ addItem('hollowtoken'); coin(); S2.finish('c8c'); done(); }); },
        lose:()=>{ say(H3,['Not yet. I think I need a little longer. Go and mend something else. Come back.'],done); }});
      return true;
    }
    return false;
  }
};
function st_(){ hermitGoHome(); }
S2.npc({id:'mallow8c',name:'Hermit Mallow',k:[-83,-30],pal:RED_PALS[0],head:'hood',still:true,when:()=>s2at('c8c'),mark:()=>s2at('c8c',0)?'!':null,talk(n,done){ S2.ch.c8c.talk(n,done); }});
TW.forEach(t=>S2.prop({id:'tw_'+t.id,k:t.at,glyph:t.id==='lamp'?'lantern':t.id==='door'?'door':'box',col:t.id==='well'?'#5a5a64':null,when:()=>s2at('c8c',1),mark:()=>s2fl('tw_'+t.id)?null:'!',
  use(){ if(s2fl('tw_'+t.id)){ say('',['Done, and a little proud of itself.']); return; } say('',[t.q],()=>{ s2fl('tw_'+t.id,1); s2led(t.led,1); coin(); toast(t.nm+' mended. ('+twDone()+'/3)',2600); hudCache.obj=null; }); }}));
