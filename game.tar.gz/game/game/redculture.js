'use strict';
/* ===== EMBERWICK: culture =====
   The red ducks have their own faith (the Hearth), their own holy hours, their own shops and foods, their own history set
   in stone, and their own opinion of you. Everything a visitor can buy, read, see or overhear lives here.
   THE RULE OF THE TOWN: you can work here, shop here, help here. You can never earn standing here. */

/* ---------- reputation never moves in Emberwick ---------- */
let _repToastAt=0;
{
  const _addRep=addRep;
  addRep=function(t,n){
    if(t&&t.isRed&&!(g.story&&g.story.isRed)){
      if(!n||n<=0) return;
      if(g.time-_repToastAt>45){ _repToastAt=g.time; toast(pick(['The red ducks nod. It changes nothing.','Thank you, they say. They do not say it warmly.','Noted. And, as always, forgotten.']),2600); }
      return;
    }
    _addRep(t,n);
  };
}

/* ---------- food, tools and charms sold only here ---------- */
function rItem(id,name,price,desc,eat,note){
  ITEMS[id]=eat?{name:name,price:price,desc:desc,use:'eat',boost:eat[0],quip:eat[1],nogift:true}:{name:name,price:price,desc:desc,use:'note',note:note,nogift:true};
}
rItem('beetloaf','Beetroot Loaf',4,'Emberwick bread, baked with beetroot. This is why every crust in town is red.',[35,'Earthy, sweet and an alarming shade of crimson. Your bill stays pink for an hour.']);
rItem('emberroll','Ember Roll',5,'Cinnamon, a little pepper, and a glaze that glows when it is warm.',[30,'It warms you from the inside out, and then a bit further.']);
rItem('ashbread','Ash-Crust Loaf',3,'Baked under embers. The crust is black. The middle is wonderful. Do not ask.',[20,'Smoky and soft. You leave a small trail of soot.']);
rItem('pepcocoa','Pepper Cocoa',5,'Thick cocoa with a kick. The red ducks drink it before the cold watches.',[45,'Sweet, then not sweet, then very warm. Your feathers fluff.']);
rItem('cinderstew','Cinder Stew',7,'Beets, barley and a secret. It has been simmering since the March, they say.',[65,'A bowl of stew that feels like being forgiven. You feel like you could waddle for days.']);
rItem('embertea','Ember Tea',4,'Smoked tea with a slice of dried orange. Served in a mug that hums.',[40,'Smoke and citrus. Warm all the way down to your tail.']);
rItem('roastnut','Roast Chestnuts',3,'A paper cone of them, still too hot to hold.',[20,'Pop, crack, ouch, mmm.']);
rItem('warmtonic','Warming Tonic',6,'Hearthleaf, ginger and honey. Sold in small bottles with red wax seals.',[70,'It tastes like a hug from someone who is a little cross with you. Your feet barely touch the ground.']);
rItem('spiceseed','Spice Seeds',3,'Sunflower seeds roasted in pepper. A bag lasts exactly one conversation.',[20,'Crack, crack, crack, ow, crack.']);
rItem('vigil','Vigil Candle',3,'A short red candle. The red ducks light one each night and say a name softly.',null,'You roll the candle between your wings. It smells of wax and quiet. You could light it at the Hearth of the First Ember.');
rItem('flint','Flint & Steel',4,'Strike it and a spark leaps. "A fire shared does not shrink," says the label.',null,'You strike it. A spark. Another. Somewhere nearby, a red duck looks up at the sound and smiles for half a second before remembering.');
rItem('tinderbox','Tinderbox',6,'Dry shavings, a small flint, and a tiny card: "KEEP. KINDLE. BANK."',null,'Dry as a bone. You tuck it away. It feels like a promise.');
rItem('redthread','Red Thread Braid',4,'Every red duckling is given one at birth and wears it until they are grown. This one is for sale.',null,'You hold it up. The braid is warm. It is not magic. It does not need to be.');
rItem('tinkerbeetle','Clockwork Ember Beetle',8,'Wind it up and it scuttles, glowing. Children love them. Adults pretend not to.',null,'Click, click, click. It scuttles across the floor and bumps into the wall. It tries again. You admire its determination.');
rItem('healleaf','Hearthleaf Bundle',4,'Dried leaves tied in red twine. Steep them, or just sniff them. Both work.',null,'You sniff. Your nose is suddenly very awake. Your worries file out one by one.');
rItem('redbraid','Children\'s Braid',0,'A bracelet of red thread, braided by small and clumsy wings. Eight different knots.',null,'Eight knots, none of them alike. You tie it on. It is a bit too tight and absolutely perfect.');
rItem('embertoken','Ember Token',0,'A warm clay disc from the Banking. A flame is pressed into one side. A hand into the other.',null,'It is warm. Not hot: warm, like a hand held a moment longer than needed.');
rItem('emberbook','Book of Embers',0,'The creed of the Hearth. Examine it to read. (Also in your journal.)',null,'');
rItem('annals','Annals of the March',0,'A copy of the town\'s oldest record, written by lamplight on the road. Examine it to read.',null,'');
ITEMS.emberbook.use='rbook'; ITEMS.annals.use='rbook';
for(const id of ['redbraid','embertoken','emberbook','annals']) delete ITEMS[id].price;

const RICON={
  beetloaf:(R,C,E)=>{ E(8,9,6.5,4.5,'#8a2a3a'); R(4,7,8,2,'#a8384a'); R(6,6,1,3,'#5a1a22'); R(9,6,1,3,'#5a1a22'); },
  emberroll:(R,C,E)=>{ E(8,9,6,4,'#d9a05b'); R(4,7,8,2,'#ff9d2e'); R(6,8,1,1,'#fff3d0'); R(9,8,1,1,'#fff3d0'); },
  ashbread:(R,C,E)=>{ E(8,9,6.5,4.5,'#2a2220'); R(4,7,8,2,'#3a302c'); R(6,6,1,3,'#7a6a60'); R(9,6,1,3,'#7a6a60'); },
  pepcocoa:(R,C,E)=>{ R(4,6,8,7,'#8a2a1a'); R(12,7,2,4,'#8a2a1a'); R(5,7,6,2,'#4a2418'); R(6,2,1,3,'rgba(255,255,255,0.6)'); R(9,1,1,4,'rgba(255,255,255,0.6)'); R(7,10,2,2,'#ff7a2a'); },
  cinderstew:(R,C,E)=>{ E(8,10,6.5,4.5,'#3a2a24'); E(8,9,5.5,3,'#a8384a'); C(6,9,1,'#e8c27a'); C(10,9,1,'#e8c27a'); R(6,3,1,3,'rgba(255,255,255,0.6)'); R(9,2,1,4,'rgba(255,255,255,0.6)'); },
  embertea:(R,C,E)=>{ R(4,7,7,6,'#f2ddd0'); R(5,8,5,2,'#a8541f'); R(11,8,2,3,'#f2ddd0'); R(6,3,1,3,'rgba(255,255,255,0.6)'); R(9,2,1,4,'rgba(255,255,255,0.6)'); R(7,8,2,1,'#ffb347'); },
  roastnut:(R,C,E)=>{ R(4,7,8,7,'#f4efe0'); R(4,7,8,1,'#d8cfae'); E(6,6,2.5,2,'#8a5a2b'); E(9,5,2.5,2,'#8a5a2b'); E(8,7,2.5,2,'#a8732f'); },
  warmtonic:(R,C,E)=>{ R(6,6,4,8,'#c0392b'); R(6,6,4,2,'#f2a7a0'); R(7,3,2,3,'#c9a06a'); R(6,2,4,1,'#8a2a1a'); },
  spiceseed:(R,C,E)=>{ R(4,5,8,9,'#f4efe0'); R(4,5,8,2,'#d8cfae'); R(5,8,6,3,'#c0392b'); E(8,12,1.2,2,'#4a4a4a'); },
  vigil:(R,C,E)=>{ R(6,6,4,8,'#c0392b'); R(6,6,4,1,'#e8685a'); R(7,3,2,3,'#ffb347'); R(7,2,2,1,'#fff3c4'); },
  flint:(R,C,E)=>{ R(3,9,10,4,'#7d838c'); R(4,9,4,2,'#a8aeb6'); R(8,5,2,5,'#c9a24a'); R(10,3,1,1,'#fff3c4'); R(11,4,1,1,'#ffb347'); R(9,2,1,1,'#ffd166'); },
  tinderbox:(R,C,E)=>{ R(3,6,10,7,'#8a5a2b'); R(3,6,10,2,'#a97c50'); R(7,8,2,3,'#c9a24a'); R(5,4,6,2,'#d8b878'); },
  redthread:(R,C,E)=>{ C(8,8,5,'#c0392b'); C(8,8,3.4,'#a02a22'); C(8,8,1.6,'#7a1f1f'); R(8,2,1,3,'#c0392b'); R(11,5,3,1,'#e8685a'); },
  tinkerbeetle:(R,C,E)=>{ E(8,9,5,3.5,'#d9482b'); R(3,7,2,1,'#2a2220'); R(11,7,2,1,'#2a2220'); R(3,11,2,1,'#2a2220'); R(11,11,2,1,'#2a2220'); C(8,5,2,'#2a2220'); R(7,8,2,2,'#ffb347'); },
  healleaf:(R,C,E)=>{ R(7,4,2,10,'#4f9a4a'); E(5,6,3,1.6,'#5fb04e'); E(11,8,3,1.6,'#5fb04e'); E(5,10,3,1.6,'#4f9a4a'); R(5,12,6,2,'#c0392b'); },
  redbraid:(R,C,E)=>{ C(8,8,5.5,'#c0392b'); C(8,8,3.6,'rgba(0,0,0,0)'); R(5,4,2,2,'#e8685a'); R(9,3,2,2,'#a02a22'); R(11,8,2,2,'#e8685a'); R(4,9,2,2,'#a02a22'); R(8,12,2,2,'#e8685a'); },
  embertoken:(R,C,E)=>{ C(8,8,6,'#8a4a3a'); C(8,8,4.6,'#a8604c'); c_=0; R(7,5,2,6,'#ffb347'); R(6,7,4,3,'#ffb347'); R(7,4,2,2,'#fff3c4'); },
  emberbook:(R,C,E)=>{ R(3,2,10,12,'#7a2a22'); R(3,2,2,12,'#4a1410'); R(6,5,6,1,'#d8b878'); R(6,8,5,1,'#d8b878'); R(8,10,2,3,'#ff9d2e'); R(8,9,2,1,'#fff3c4'); },
  annals:(R,C,E)=>{ R(3,2,10,12,'#5a3a4a'); R(3,2,2,12,'#3a2230'); R(6,5,6,1,'#d8b878'); R(6,8,5,1,'#d8b878'); R(6,11,5,1,'#d8b878'); }
};
let c_=0; void c_;
{
  const _drawIcon=drawIcon;
  drawIcon=function(c,id,s){
    if(RICON[id]){
      const u=s/16; c.save(); c.scale(u,u); c.clearRect(0,0,16,16);
      RICON[id]((x,y,w,h,col)=>{ c.fillStyle=col; c.fillRect(x,y,w,h); },(x,y,r,col)=>circ(c,x,y,r,col),(x,y,rx,ry,col)=>ell(c,x,y,rx,ry,col));
      c.restore(); return;
    }
    _drawIcon(c,id,s);
  };
}

/* ---------- shops: stock, hours, floors and greetings ---------- */
Object.assign(STOCK,{
  rbake:['beetloaf','emberroll','ashbread','muffin'],
  rcafe:['pepcocoa','cinderstew','embertea','roastnut'],
  rcandle:['vigil','flint','tinderbox','lantern'],
  rloom:['scarf','redthread','socks','bowtie'],
  rtoy:['tinkerbeetle','kite','marbles','ducky'],
  rforge:['lantern','glass','compass','flint'],
  rherb:['warmtonic','spiceseed','healleaf','peas']
});
Object.assign(HOURS,{rbake:[5,19],rcafe:[7,23],rcandle:[8,20],rloom:[9,18],rtoy:[9,18],rforge:[8,17],rherb:[8,19]});
Object.assign(FLOORS,{rbake:['#b8805a','#a9724c'],rcafe:['#7a4a38','#6e4032'],rcandle:['#8a5a4a','#7c4e40'],rloom:['#a04a5a','#923f50'],rtoy:['#c9955a','#bb894f'],rforge:['#5a4a46','#4e3f3b'],rherb:['#6f7f4a','#637340']});
Object.assign(RUGS,{rbake:'#e0b890',rcafe:'#c9604a',rcandle:'#d98a5a',rloom:'#d6607a',rtoy:'#e0a050',rforge:'#7a5a50',rherb:'#9ab070'});
Object.assign(GOODS,{rbake:['#8a2a3a','#d9a05b','#2a2220'],rcafe:['#8a2a1a','#f2ddd0','#a8384a'],rcandle:['#c0392b','#f4efe0','#ffb347'],rloom:['#c0392b','#e8685a','#7a1f1f'],rtoy:['#d9482b','#e0a050','#3a7ca5'],rforge:['#7d838c','#c9a24a','#4a4a4a'],rherb:['#4f9a4a','#c0392b','#c9a06a']});
Object.assign(GREET,{
  rbake:['The crust is red. Everything here is red. You will adjust.','Beetroot loaf is the only loaf. Take two, or take none.'],
  rcafe:['Sit anywhere there is room. There is room. Please do not look so surprised.','The stew is the town\'s oldest recipe. You are the first yellow to taste it. Do not make it a story.'],
  rcandle:['A candle for a name. A flame for a cold night. A wick for anyone.','Careful with the flint. Sparks are easy to start here.'],
  rloom:['Red thread keeps the ducklings safe. Red thread keeps the old ones close. What does it do for you? We shall see.','Hold still. I do not measure for yellow. I will make an exception.'],
  rtoy:['The beetles are for children. The children are for the Wood. Do not tell the Warden I said that.','Careful. If a beetle follows you out, it means it likes you.'],
  rforge:['Tools for the roof. Tools for the road. Tools for the fire. What do you need?','Everything here was made twice and burned once.'],
  rherb:['A leaf for every ache. For the ones that are not aches, there is tea.','You look tired. Not the sleeping kind. Sit.']
});
Object.assign(JOBS,{
  rbake:['Rake the Ovens','Rake the coals when the marker is in the zone.'],
  rcafe:['Stir the Stew','Stir and stop right in the zone.'],
  rcandle:['Dip the Candles','Dip and lift at just the right moment.'],
  rloom:['Thread the Loom','Pull the red thread when the marker is in the zone.'],
  rtoy:['Wind the Beetles','Wind just enough: stop in the zone.'],
  rforge:['Work the Bellows','Pump when the coals glow.'],
  rherb:['Grind the Herbs','Grind until the marker is in the zone.']
});

/* ---------- the people of the town ---------- */
const RP0=PERSONAS.length;
PERSONAS.push(
 /* 0 Warden */ [['Halt. Names. Detective Duck. Fine. It will not be remembered long.','We have kept this town hidden for a hundred years. One yellow feather does not change that. Do not give me a reason.'],
   ['The hermit vouches for you. The hermit also vouched for a stray cat once. It ate the Elders\' supper.'],['I am not unkind. I am careful. They are different. I have buried friends who confused them.']],
 /* 1 Acolyte Wren */ [['Warm hearth, stranger. That is what we say. It is also what we are supposed to mean.','I carry the ash at dusk and the coal at dawn. It is dull work. It is holy work. I never know which one I am doing.'],
   ['Keeper Brand says a flame has never asked whose hands lit it. I think about that when I look at you.']],
 /* 2 Courier Jay */ [['I run messages from the Hall to everywhere. Everywhere is small. I am fast.','I am not allowed to tell you what is in them. I am also not allowed to tell you they are many.'],
   ['The Hall has been sending very many messages. Every one of them says "later".']],
 /* 3 Hearthwarden Pyre */ [['The Great Hearth was lit from the Keeper\'s Lantern, the one flame we carried the whole March and never let go out. A hundred years. I add one log an hour. I have never missed.','Sit by it if you like. A fire does not check feathers. That is rather the point of fire.'],
   ['When the Hearth burns low, the Wood leans in. When it burns high, the Wood leans out. I do not know which of us is looking after the other.']],
 /* 4 Old Garnet */ [['I was a girl on the March. I carried the ash bucket. Sixty pounds of ash and I was nine.','At the seventh river a stranger in a yellow coat gave my mother his last bread, and asked nothing. We never learned his name.','So. Yellow is not one thing. I keep telling myself that. Some days it works.'],['Every child in this town has asked me about the stranger. I tell them what I know: a yellow coat, a loaf of bread, no name. Then they ask for the loaf story again.']],
 /* 5 Widow Ash */ [['Yellow. Yellow like the banners. Yellow like the balcony.','Do not look at me like I am cruel. Look at me like I am a woman who has a lot to remember.'],
   ['My mother\'s name is on the Wall. Your kind put it there.']],
 /* 6 Scout Fennel */ [['Is it true the sky is open outside the Wood? All of it at once, with nothing on top?','Please do not tell the Warden I asked. I am meant to be guarding the wall, not wondering.'],
   ['If I ever leave, I will leave in the morning. Mornings are the least watched.']],
 /* 7 Farmer Clay */ [['Beets grow best in the Wood\'s shade. The Wood leans in when we are afraid. It has been leaning a great deal lately.','My grandmother said the Wood is not a wall. She said it is a hand, held out, trembling.'],
   ['The beets are fine. It is the soil I do not trust. It hums at night.']],
 /* 8 Night-watch Ashby */ [['I walk the wall when the town sleeps. Some nights the Wood whispers back. Three words. Always the same.','I will not say them. I will say that they are not for the likes of me.'],
   ['If you hear it, do not answer. The Warden says that is the first rule. The second rule is: they will not tell you why.']],
 /* 9 Gossip Marrow */ [['Have you heard? No? Good. I will tell you what I have not heard.','The Elders do not sleep. The Hall\'s lamps burn all night. The Quiet Shelf has a new lock. Nobody will say why. Everybody knows something.'],
   ['They are keeping something from you. From all of us, really, but especially from you. The yellow ones are always the last to know. We would know. We were the last, too.']]
);
const RED_ADULTS=[
 ['Warden Ruddock',36,52,0,'helm',null,0,true],['Acolyte Wren',10,26,1,'wizard','scarf',1],['Courier Jay',30,43,2,'wizard',null,2],
 ['Hearthwarden Pyre',33,32,3,'wizard','scarf',3,true],['Old Garnet',43,26,4,'wizard',null,4],['Widow Ash',22,30,0,'wizard',null,5],
 ['Scout Fennel',46,44,1,'cap',null,6],['Farmer Clay',49,30,2,'wizard',null,7],['Night-watch Ashby',36,40,3,'helm',null,8,false,true],['Gossip Marrow',30,25,4,'wizard','scarf',9]
];
function snapFree(wx,wy,r){
  r=r||5;
  const ok=(x,y)=>{ const t=tileAt(x,y); return !SOLID.has(t)&&t!==T.WATER&&t!==T.PATH&&t!==T.GRASS?true:(!SOLID.has(t)&&t!==T.WATER); };
  if(ok(wx,wy)) return [wx,wy];
  for(let d=1;d<=r;d++) for(let dy=-d;dy<=d;dy++) for(let dx=-d;dx<=d;dx++){ if(Math.max(Math.abs(dx),Math.abs(dy))!==d) continue; if(ok(wx+dx,wy+dy)) return [wx+dx,wy+dy]; }
  return [wx,wy];
}
function redPopulate(t){
  RED_ADULTS.forEach((a,i)=>{
    const p=snapFree(RX0+a[1],RY0+a[2]);
    t.npcs.push({idx:i,name:a[0],pal:RED_PALS[a[3]],acc:{head:a[4],neck:a[5]},persona:RP0+a[6],owl:!!a[8],town:t,
      x:(p[0]+0.5)*TS,y:(p[1]+0.95)*TS,hx:(p[0]+0.5)*TS,hy:(p[1]+0.95)*TS,dir:'down',moving:false,t:Math.random()*2,phase:0,talking:false,still:!!a[7]&&false,red:true});
  });
  const ch=t.specials.find(b=>b.type==='church'), ar=t.specials.find(b=>b.type==='library');
  LIBEXIT.rchurch=[ch.doorX-KX,ch.doorY-KY];
  LIBEXIT.rlib=[ar.doorX-KX,ar.doorY-KY];
}
{
  const _getRed=getRed;
  getRed=function(){ const fresh=!RED; const t=_getRed(); if(fresh) redPopulate(t); return t; };
}
const RED_WHISPERS=[
  '"...yellow. In the square. Walking about as if he were a guest..."','"Mallow vouches for it, they say. Mallow was out in the cold too long."','"Look at the feathers. The same as the crown\'s banner."',
  '"If the Elders let it stay, there is a reason. There is always a reason."','"Do not teach it our songs."','"Lock the shutters. Lock everything."','"What does a yellow-feather want with Emberwick?"',
  '"The children are not afraid of it. The children are fools."','"Hush. It is looking."','"A hundred years of silence, and this is who comes."','"The Hall is hiding something. And it does not want him anywhere near."',
  '"Count the days. They keep us counting for a reason."'
];

/* ---------- the red ducks' houses ---------- */
const RED_HOUSE_LINES=[
  'A curtain twitches, then snaps shut.','Inside, someone stops humming. Nobody comes to the door.',
  'A paper charm hangs by the door: a flame in a circle. Under it, a smaller, newer scrap: a drawing of a yellow feather with a line through it.',
  'The door stays shut. Through the wood you hear a mother say, "Away from the window." And a child say, "But he is yellow, Mama. He is so yellow."',
  'A bowl of ash sits by the step, the way the red ducks leave it for the dawn. It is cold. The door is closed.'
];
{
  const _interact=interact;
  interact=function(){
    const tg=g.target;
    if(tg&&tg.k==='tile'&&tg.t===T.HOUSEDOOR&&g.story.redOpen&&inRed(tg.tx,tg.ty)){ quack(); say('',[pick(RED_HOUSE_LINES)]); return; }
    _interact();
  };
}

/* ---------- monuments, lanterns, the Hearth ---------- */
const RCOLD_TEXT=[
  'THE FIRST FIRE. Below the East Gate. We could still see the walls. We did not look.',
  'THE SECOND FIRE. On the lake road. A child asked if we were coming back. Nobody had the heart to answer.',
  'THE THIRD FIRE. In the rain. It would not light. We sat in the dark and called that a fire.',
  'THE FOURTH FIRE. At the water crossing. We carried the old ones over. Not one was let go.',
  'THE FIFTH FIRE. Where the road split. Some went north, toward the hills and the anger. The rest kept walking east. Both groups wept.',
  'THE SIXTH FIRE. We stopped singing so the soldiers could not follow the sound.',
  'THE SEVENTH FIRE. A stranger in a yellow coat gave his last bread to a mother who had none, and asked nothing. We still speak of it.',
  'THE EIGHTH FIRE. At the hollow where the road ended. One of us stayed behind to tend the stones. Every spring they are set straight. We never learned who.'
];
function redMonInteract(tx,ty){
  const k=rMonKind(tx,ty), st=g.story;
  st.redMon=st.redMon||{}; st.redMon[k]=1;
  if(k==='march') say('',['"THE MARCH." A bronze parent walking, a duckling asleep on its back. The plinth reads: "EIGHT NIGHTS. EIGHT FIRES PUT OUT. NOT ONE DUCKLING LOST."','Under it, a smaller line, newer, scratched in by hand: "Except the ones who did not make it. We carry them too."']);
  else if(k==='empty') say('',['A tall, plain stone with a rectangle chiselled out of its face, as if a name was removed. A faded red ribbon is tied round it and replaced every spring.','The plaque: "THE EMPTY STONE. For those who left us in anger. We do not say the name. We do not take the stone away."']);
  else if(k==='bell') say('',['THE FIRST BELL. A small bronze bell on a plinth, with no rope and no clapper. The plaque: "Cast from the kettles of the March, the winter we arrived. Rung once, the night the walls were finished, then retired. The Dawn Bell in the square hangs in its place."','You touch the rim. It hums, very quietly. At the castle gate, a guard clears his throat.']);
  else if(k==='founders'){
    const named=st.hermitFollow||st.redOpen;
    say('',['THE FOUNDERS\' WALL. Sixty-two families, cut into the stone in the first winter. Beneath the last line, newer letters: the names of those who did not arrive.',
      named?'"MALLOW, son of BREE. Aged seven. LOST ON THE ROAD." A thin line has been scratched through "Lost", and under it, in fresh white stone: "RETURNED."':'Some lines have been recarved so often the stone is thin there.']);
  }
}
function redColdInteract(tx,ty){
  const i=RCOLDPOS.findIndex(p=>p[0]+RX0===tx&&p[1]+RY0===ty), st=g.story;
  st.redCold=st.redCold||{}; st.redCold[i]=1;
  const pages=[RCOLD_TEXT[i]];
  if(i===7&&st.hermitFollow&&!st.hermitStones){
    st.hermitStones=1;
    say('',pages,()=>say('Hermit Mallow',['...One of us stayed.','It was me. I was seven, and nobody had told me the road was over. So I stayed and set the stones straight, because someone had to, and because I did not know how to stop.','A hundred springs. I am glad someone wrote it down. I am a little sorry they did not write my name.']));
    return;
  }
  say('',pages);
  const n=st.redCold?Object.keys(st.redCold).length:0;
  if(n===8&&!st.redColdAll){ st.redColdAll=1; toast('You have read all eight fires of the March.',3200); }
}
function redLanternLine(){ return pick(['A paper lantern, red as a berry. It sways. It gives light, and a little warmth, and an awful lot of opinion.','The red ducks light these at dusk, one at a time. The first lantern is lit from the Hearth. The last, from the one before.','A lantern, hung low enough for a duckling to reach. Low enough for a hundred years of ducklings.']); }
function redGateTalk(){
  if(g.story.banished){ say('Palisade',['The gate is sealed with a ring of glowing red runes, hand-high and humming. Nobody on the wall looks down.','Cut into the nearest post, fresh and deep: "CARRIED THE KING\'S WORD. NOT WELCOME."']); return; }
  say('Palisade',['Logs bound with red cord, each one the same height. It is a rule: no log taller than the rest. Even the walls are meant to be equal.']);
}
{
  const _kInteract=kingdomInteract;
  kingdomInteract=function(t,tx,ty){
    switch(t){
      case RWALL: redGateTalk(); return;
      case RPOST: say('',['A gate post, lantern on top. Someone has carved into it, small, at duckling height: "HOME". Someone else has carved, much higher: "FOR NOW".']); return;
      case RCSTONE: say('',[pick(['Red sandstone, quarried by hand and carried by hand. The mortar still smells of woodsmoke.','The castle wall. The stones were set in the first decade, by masons who had once built other walls for other masters.','Cinderhold. Raised from memory, the plaque says. From whose memory, it does not say.'])]); return;
      case RCWIN: say('',[pick(['A narrow window. Behind it, someone is arguing very quietly.','Warm light. A shadow crosses it and does not come back.','The shutters are half-closed. From within comes the soft sound of a ladle on a pot, and nobody speaking.'])]); return;
      case RCGATE: if(typeof redCastleGate==='function') redCastleGate(); return;
      case RBWIN: say('',[tileAt(tx,ty)===RBWIN&&redBuildingAtLocal(tx-RX0,ty-RY0)&&redBuildingAtLocal(tx-RX0,ty-RY0).type==='church'?'Glass in four reds and a gold. The light it throws on the courtyard is the colour of a banked coal.':'A tall window, shelves glimpsed behind it. A face in the glass, then none.']); return;
      case RBDOOR: {
        const b=redBuildingAtLocal(tx-RX0,ty-RY0);
        if(b&&b.type==='church'){ enterRChurch(); return; }
        if(b&&b.type==='school'){ enterRSchool(); return; }
        if(b&&b.type==='library'){ if(archiveOpen()) enterRArchive(); else say('',['The Archive doors are barred. A card: "OPEN 9 IN THE MORNING TO 7 IN THE EVENING. KNOCK IF YOU MUST. DO NOT KNOCK."']); return; }
        return; }
      case RLANT: say('',[redLanternLine()]); return;
      case RBANNER: say('',[pick(['A red banner with a gold flame sewn into it. It hangs a little lower than the kingdom\'s, on purpose.','The Hearth banner: a flame inside a circle. Under it, in thread: KEEP. KINDLE. BANK.'])]); return;
      case RHEARTH: redHearthInteract(); return;
      case RMON: redMonInteract(tx,ty); return;
      case RCOLD: redColdInteract(tx,ty); return;
    }
    _kInteract(t,tx,ty);
  };
}
function redHearthInteract(){
  const st=g.story, near=(g.clock>=5&&g.clock<7);
  st.redHearth=1;
  say('The Great Hearth',['A stone basin the size of a cart, and in it a fire taller than a duck. It has not gone out since the last night of the March.','A bronze plate on the rim: "A FIRE SHARED DOES NOT SHRINK."'],()=>{
    choose('','What will you do?',['Warm your wings','Look at the people watching you','Step back'],k=>{
      if(k===0){ fade(0.6); advanceClock(0.5); say('',['You hold out your wings. The heat is enormous and gentle at the same time.','Across the square, two red ducks watch you from beside a stall. One of them looks away first. Neither leaves.']); }
      else if(k===1) say('',['A red duck with a basket. A red duck with a ladder. A red duck with a child on her hip. Each of them is carefully not looking at you.','The child on her hip is looking at you. She waves one small wing.']);
    },2);
  });
  void near;
}

/* ---------- opening hours of the Archive ---------- */
function archiveOpen(){ return g.clock>=9&&g.clock<19; }
const BANK_START=18, BANK_END=19;
function bankingOn(){ return g.clock>=BANK_START&&g.clock<BANK_END; }

/* ---------- interiors: the church and the archive ---------- */
INTLAYOUT.rchurch=[
  'WWWWWWWWWWWWW',
  'WV....K....MW',
  'W....HHH....W',
  'WB...HHH...BW',
  'W...........W',
  'W.PPP...PPP.W',
  'W.PPP...PPP.W',
  'W.PPP...PPP.W',
  'W...........W',
  'WWWWWWDWWWWWW'
];
INTLAYOUT.rlib=[
  'WWWWWWWWWWWWW',
  'WBBBBBQBBBBBW',
  'W...........W',
  'WS.TT...TT.SW',
  'WS.........SW',
  'WS.TT...TT.SW',
  'W.........G.W',
  'WS...AAA...SW',
  'W...........W',
  'WWWWWWDWWWWWW'
];
LIBINT.rchurch='VKMHBP'; LIBINT.rlib='BQSTAG';
function enterRChurch(){
  enterInterior('rchurch');
  if(bankingOn()) toast('The bells ring six. The Banking is under way. Every head turns. Then, slowly, every head turns back.',3800);
  else toast('The Hearth of the First Ember. Warm stone, wax and woodsmoke. A few red ducks look up, then down.',3600);
}
function enterRArchive(){
  enterInterior('rlib');
  toast('The Ashen Archive. Paper, wax and a very long silence.',3000);
}
const BANK_HYMNS=[
  ['The congregation hums the Banking Song. It is a slow, low, tender tune. You have heard it before: from the hermit, from Lyric Lark, from nowhere you can name.','Nobody sings it to you. Nobody sings it at you. Somebody, near the front, hums a note longer than the rest.'],
  ['Keeper Brand reads: "Keep the flame in the house. Kindle the flame in the stranger\'s. Bank the flame when the night is long."','At "stranger", nobody looks at you. Every back in the room becomes very straight.'],
  ['The sermon is on the Third Duty: patience. "A banked fire is not a dead fire," says Keeper Brand. "It is a fire that has agreed to wait."','Beside you, a very small red duck whispers: "That is what the hermit did." Her mother hushes her. Her mother also looks at you, for the first time.']
];
function attendBanking(){
  const st=g.story;
  const t=BANK_END-g.clock;
  say('Keeper Brand',['There is a bench at the back. It is not a punishment. It is where the cold gets in first.','Sit. If you wish to.'],()=>{
    fade(1.2); advanceClock(t);
    st.bankings=(st.bankings||0)+1;
    const first=!st.bankToken;
    seq([['',['You sit at the back. Candles are put out one by one, and the ash is drawn over the Hearth in a long slow sweep. The red ducks do this without speaking, as if the whole hall were a single set of wings.']],['',pick(BANK_HYMNS)],['Keeper Brand',['Keep. Kindle. Bank. Warm hearth to you.','(He says "to you" very quietly. But he says it.)']]],()=>{
      if(first){ st.bankToken=1; addItem('embertoken'); coin(); toast('Received: Ember Token',3200); }
      else toast('The hall is dark and warm. It is '+clockStr()+'.',2600);
    });
  });
}
const EMBER_FAITH=[
 'THE BOOK OF EMBERS  (Hearth copy, very well thumbed)',
 'In the beginning there was the Cold Dark Pond. The Firstmother, who was old and tired, sat upon the last warm stone and laid a single egg. A spark fell from the sun and hatched it. That spark is the Ember, and every duck carries a little of it. Red ducks carry it where it shows.',
 'THE THREE DUTIES. KEEP: to keep a fire in the house, always, even when no one is cold. KINDLE: to light another\'s fire from your own, and lose nothing. BANK: to cover the flame, and wait, and trust that morning will come.',
 'THE RITES. The Kindling (dawn): every hearth is relit from a coal. The Banking (dusk, at six): every hearth is covered in ash, together. The Walk of the Cold Fires (once a year): the town walks to the Wood\'s edge and puts out a fire, in memory of the March.',
 'THE GREAT SAYING. "A fire shared does not shrink." It is the first thing a duckling learns. It is carved above the Hearth and on the doors of every house in Emberwick.',
 'THE LAST LEAF. In the margin of this copy, in the Keeper\'s own hand: "We are a people who have been turned from many doors. The Book says never to turn another. I have read this page four hundred times and it has never once got easier."'
];
function readEmberBook(){
  g.story.emberRead=1;
  seq([['',EMBER_FAITH.slice(0,3)],['',EMBER_FAITH.slice(3,5)],['',EMBER_FAITH.slice(5)]]);
}
const ANNALS=[
 'THE ANNALS OF THE MARCH  (second copy, kept in the Ashen Archive)',
 'Entry, the first night. Eleven hundred ducks passed the East Gate. The guards did not look at us. One of them was crying. We put out the fire at dawn, so that the smoke would not tell the soldiers which way we went.',
 'Entry, the fifth night. The road forked. Gordamom, who was the son of a miller and the smartest of us, spoke for a long time. He spoke of what we were owed. Three hundred followed him north. We did not stop them. We did not agree. We both wept.',
 'Entry, the eighth night. The road ended in a hollow of flowers. We had no word for it. We called it a place to sleep. We walked on, north and east, and by midwinter we had the first posts of a wall.',
 'Entry, the first spring. We found the Wood, or the Wood found us. It moves when we are afraid. Nobody asked it to. Nobody has ever been able to ask it to stop.',
 'A later hand, in pencil: "We call this the Annals of the March. It is not. It is the Annals of the Silence. We could have said what was done to us. We chose to be quiet instead. I am no longer sure we chose well."'
];
function readAnnals(){
  g.story.annalsRead=1;
  seq([['',ANNALS.slice(0,2)],['',ANNALS.slice(2,4)],['',ANNALS.slice(4)]]);
}
const ARCH_SHELF=[
  'Ledgers of the Wall: who raised which post, in which winter. Every name has a number. Every number has a bowl of soup next to it.','Seed books. Four hundred kinds of beet. The pages are warped where someone wept on them.',
  'Hymnals in nine voices. One has a pressed flower and the note: "Mama sang alto."','Maps of the Wood, drawn and redrawn. Not one matches another. A note: "It moves. It is allowed to."',
  'Songs of the March, written down by children who remembered the tunes and forgot the words.','A shelf of "Letters Not Sent": addressed to Mallardia, to the Crown, to old neighbours. None has a stamp.',
  'Recipes. The same recipe, copied eleven hundred times, for beet bread. In the margin of one: "My mother\'s. The one she carried."','Almanacs of the Banking: the exact minute of every dusk for a hundred years. Someone has been very patient.'
];
function archiveInteract(tg){
  const st=g.story, ch=tg.ch;
  if(ch==='Q'){
    st.quietSeen=1;
    say('',['A shelf set into the north wall, at its centre. A brass plaque: "THE QUIET SHELF. ELDERS ONLY."','The lock is new. The dust around it is not.'],()=>{
      if(st.redOpen&&!st.quietNoted){ st.quietNoted=1; toast('Journal: the Quiet Shelf.',2600); }
    });
    return;
  }
  if(ch==='B'){ say('',[ARCH_SHELF[(tg.tx*3+tg.ty)%ARCH_SHELF.length]]); return; }
  if(ch==='S'){ say('',[ARCH_SHELF[(tg.tx*5+tg.ty*2+3)%ARCH_SHELF.length]]); return; }
  if(ch==='T'){ say('',[pick(['A reading table scarred with initials. One set has been carved over three times.','A half-finished sampler on a hoop: "KEEP KINDLE BA".'])]); return; }
  if(ch==='G'){
    st.marchMap=1;
    say('',['A great table-map under glass. A line of red dots runs from a castle in the south-west to a hollow in the north-east: eight, in all.','At the fifth dot, the line forks. One branch is labelled "North: the hills." The other: "East: us."']);
    return;
  }
  if(ch==='A'){
    const first=!st.annalsGiven;
    const talk=()=>say('Archivist Sorrel',pick([
      ['The Archive is open to all who can read. That is, to you. I checked the rule twice.','Do not ask for the Quiet Shelf. It does not exist. (It has a lock.)'],
      ['Everything here is a copy. The originals burned in the first winter. We rewrote them from memory. Sometimes memory disagrees. We keep both.'],
      ['I keep records. I am told I am meant to also keep quiet. I am working on the second part.']
    ]));
    if(first){
      say('Archivist Sorrel',['Take one thing. Only one. The Annals of the March, a copy. It is not secret. It is only unread.','No one in Emberwick asked me to give it to you. No one asked me not to, either. I am a very careful archivist.'],()=>{
        choose('','Take the Annals?',['Take it','Leave it'],k=>{ if(k===0){ st.annalsGiven=1; addItem('annals'); coin(); toast('Received: Annals of the March',3000); } },1);
      });
    } else talk();
  }
}
function churchInteract(tg){
  const st=g.story, ch=tg.ch;
  if(ch==='K'){
    if(bankingOn()){ choose('Keeper Brand','The Banking is about to begin. There is a bench at the back, if you wish it.',['Sit at the back','Not now'],k=>{ if(k===0) attendBanking(); },1); return; }
    const left=((BANK_START-g.clock)+24)%24;
    const lines=[
      ['Warm hearth, stranger. Yes, I said stranger. The Book says no one is turned from the fire. I am working hard to remember that.'],
      ['You are welcome in this house. You are not welcome in a good many others. I wanted you to hear someone say the first part.'],
      ['The Banking is at six, every dusk. Sit at the back. No one will speak to you. No one will stop you.']
    ];
    say('Keeper Brand',pick(lines).concat(left<2?['Not long now.']:[]));
    return;
  }
  if(ch==='H'){ redHearthInteract(); return; }
  if(ch==='V'){
    const has=g.inv.vigil;
    if(has){
      choose('','A rack of short red candles, each set before a small tin plate with a name scratched in it. Light a vigil candle?',['Light one','Not now'],k=>{
        if(k===0){ delInv('vigil'); st.vigil=(st.vigil||0)+1; coin(); say('',['You light the candle from the Hearth. It catches at once.','There is nobody to say a name for. You say nothing. The flame says it for you. It is, as it turns out, a very good flame.']); }
      },1);
    } else say('',['A rack of short red candles, each before a small tin plate with a name scratched in it. A card: "A vigil candle is about '+ITEMS.vigil.price+' crumbs at Wick & Flint. Light it for anyone."']);
    return;
  }
  if(ch==='M'){
    say('',['A long bronze plaque, with a row of small hooks. On each hook hangs a bit of red thread, one for each family on the March. A few hooks are empty.','Under the empty ones: "WAITING."']);
    return;
  }
  if(ch==='B'){
    if(st.emberBook){ say('',['The shelf of Hearth books: hymns, the almanac of the Banking, recipes for feast-day beet bread. Your copy of the Book of Embers is safe in your pack.']); return; }
    say('',['A low shelf of hymnals. One thick volume is worn dark at the corners: "The Book of Embers".'],()=>{
      choose('','Take it? (A card says: "For borrowing. For everyone.")',['Take it','Leave it'],k=>{ if(k===0){ st.emberBook=1; addItem('emberbook'); coin(); toast('Received: The Book of Embers',3000); } },1);
    });
    return;
  }
  if(ch==='P'){
    if(bankingOn()){ choose('','The Banking is starting. Sit?',['Sit at the back','Not now'],k=>{ if(k===0) attendBanking(); },1); }
    else say('',['The pews are worn smooth. At the back there is a single bench set slightly apart, with a cushion. It looks like it has been recently dusted.']);
  }
}
{
  const _libInteract=libInteract;
  libInteract=function(tg){
    if(g.libKind==='rchurch'){ churchInteract(tg); return; }
    if(g.libKind==='rlib'){ archiveInteract(tg); return; }
    _libInteract(tg);
  };
  const _areaName=areaName;
  areaName=function(){
    if(g.scene==='lib'){
      if(g.libKind==='rchurch') return 'Hearth of the First Ember';
      if(g.libKind==='rlib') return 'The Ashen Archive';
    }
    return _areaName();
  };
  const _useItem=useItem;
  useItem=function(id){
    const it=ITEMS[id];
    if(it&&it.use==='rbook'){ closeInv(); if(id==='emberbook') readEmberBook(); else readAnnals(); return; }
    _useItem(id);
  };
}
function drawMiniFolk(c,x,y,col,hood){ miniDuck(c,x,y,col,hood); }
function drawRChurch(c,W,H,kd,time){
  const vw=W/kd, vh=H/kd, RWp=LIBW*TS, RHp=LIBH*TS;
  const fx=vw>=RWp?(RWp/2-vw/2):Math.max(0,Math.min(RWp-vw,g.px-vw/2)), fy=vh>=RHp?(RHp/2-vh/2):Math.max(-30,Math.min(RHp-vh+10,g.py-14-vh/2));
  const ox=Math.round(fx*kd)/kd, oy=Math.round(fy*kd)/kd;
  c.setTransform(kd,0,0,kd,-ox*kd,-oy*kd);
  const svc=bankingOn();
  for(let ty=0;ty<LIBH;ty++) for(let tx=0;tx<LIBW;tx++){
    const ch=libCh(tx,ty), px=tx*TS, py=ty*TS;
    if(ch==='W'){ rect(c,px,py,TS,TS,'#7a4a3a'); rect(c,px,py+TS-4,TS,4,'#4a2a20'); rect(c,px+4,py+4,TS-8,2,'rgba(255,200,160,0.12)'); continue; }
    rect(c,px,py,TS,TS,((tx+ty)&1)?'#5a3a30':'#4f322a'); rect(c,px,py+15,TS,1,'rgba(0,0,0,0.14)');
    if(ch==='D') rect(c,px+2,py+4,TS-4,TS-4,'#7b4a22');
  }
  /* long red aisle runner, and a gold-trimmed hearth carpet */
  rect(c,5.3*TS,3.7*TS,2.4*TS,5.7*TS,'#8a1f2a'); rect(c,5.3*TS+4,3.7*TS,2,5.7*TS,'#d9b84a'); rect(c,7.7*TS-6,3.7*TS,2,5.7*TS,'#d9b84a');
  /* windows throw red-gold light */
  for(const wx of [2.5,10.5]){
    const px=wx*TS-12, py=4;
    rect(c,px-2,py-2,28,30,'#5a2f22'); rect(c,px,py,24,26,'#3a1a1a');
    const cols=['#c0392b','#e0b84a','#d9602a','#c0392b'];
    for(let i=0;i<4;i++) rect(c,px+(i%2)*12,py+Math.floor(i/2)*13,12,13,cols[(i+Math.floor(wx))%4]);
    rect(c,px+11,py,2,26,'#5a2f22'); rect(c,px,py+12,24,2,'#5a2f22');
    c.fillStyle='rgba(255,140,70,'+(svc?0.18:0.09)+')'; c.beginPath(); c.moveTo(px,py+26); c.lineTo(px+24,py+26); c.lineTo(px+24+30,py+9*TS-20); c.lineTo(px-30,py+9*TS-20); c.fill();
  }
  const spine=['#e0b84a','#c0392b','#f4efe0','#d9602a','#8a5a2b'];
  for(let ty=0;ty<LIBH;ty++) for(let tx=0;tx<LIBW;tx++){
    const ch=libCh(tx,ty), px=tx*TS, py=ty*TS;
    if(ch==='P'){ rect(c,px,py+8,TS,TS-8,'#6a3a22'); rect(c,px,py+8,TS,4,'#8a5a38'); rect(c,px,py+TS-3,TS,3,'#3a2012'); }
    else if(ch==='H'){
      /* the Great Hearth, three tiles wide and two deep */
      const lx0=(tx===5), rx0=(tx===7), top=(ty===2);
      rect(c,px,py,TS,TS,'#5a5252'); rect(c,px+(lx0?3:0),py+(top?3:0),TS-(lx0?3:0)-(rx0?3:0),TS-(top?3:0)-3,'#1c1210');
      if(lx0&&top){ rect(c,px,py,TS*3,3,'#8a8484'); }
      if(tx===6&&top){
        const f1=Math.sin(time*8)*3, f2=Math.sin(time*12+1)*2;
        c.fillStyle='#e0502a'; c.beginPath(); c.moveTo(px-20,py+TS*2-4); c.quadraticCurveTo(px-16,py+4,px,py-16+f1); c.quadraticCurveTo(px+16,py-6,px+TS+20,py+TS*2-4); c.closePath(); c.fill();
        c.fillStyle='#ff9d2e'; c.beginPath(); c.moveTo(px-10,py+TS*2-4); c.quadraticCurveTo(px-6,py+14,px+8,py-4+f2); c.quadraticCurveTo(px+18,py+14,px+TS+10,py+TS*2-4); c.closePath(); c.fill();
        c.fillStyle='#ffd166'; c.beginPath(); c.moveTo(px,py+TS*2-4); c.quadraticCurveTo(px+4,py+18,px+16,py+6+f1); c.quadraticCurveTo(px+TS-2,py+18,px+TS,py+TS*2-4); c.closePath(); c.fill();
        circ(c,px+16,py+22,70,'rgba(255,140,60,0.10)');
      }
    }
    else if(ch==='V'){
      rect(c,px+2,py+4,TS-4,TS-4,'#3a1d15'); rect(c,px+2,py+TS-8,TS-4,5,'#5a2f22');
      for(let r=0;r<2;r++) for(let k=0;k<3;k++){ const bx=px+5+k*8, by=py+8+r*10; rect(c,bx,by+2,4,6,'#c0392b'); c.fillStyle='#ffb347'; c.beginPath(); c.ellipse(bx+2,by,1.3,2.2+Math.sin(time*9+k+r)*0.5,0,0,6.3); c.fill(); }
      circ(c,px+16,py+14,22,'rgba(255,170,80,0.12)');
    }
    else if(ch==='M'){ rect(c,px+2,py+4,TS-4,TS-8,'#8a6a3a'); for(let k=0;k<5;k++) rect(c,px+5+k*5,py+8,2,10,'#c0392b'); rect(c,px+4,py+20,TS-8,3,'#3a2a14'); }
    else if(ch==='B'){ rect(c,px,py,TS,TS,'#5b4430'); rect(c,px+2,py+2,TS-4,TS-4,'#3b2b1e');
      for(let r=0;r<3;r++){ rect(c,px+2,py+3+r*9+8,TS-4,1.5,'#8a6a45'); for(let k=0,x=px+3;k<6;k++){ const w=3+((r*3+k)%3); rect(c,x,py+3+r*9,w,8,spine[(r*2+k)%5]); x+=w+0.5; } } }
    else if(ch==='K'){ miniDuck(c,px+16,py+12,'#c0392b','#7a1f1f'); circ(c,px+16,py+20,12,'rgba(255,170,80,0.14)'); }
  }
  /* the congregation, red on red, with a cushioned bench left empty at the back */
  if(svc){ for(const [dx,dy,col] of [[2,5.2,'#b5322a'],[3,5.6,'#d9503f'],[3,6.6,'#a82a2a'],[8.8,5.2,'#c0392b'],[9.6,5.8,'#d9503f'],[2.2,6.8,'#b5322a'],[9.2,6.8,'#a82a2a'],[2.6,7.4,'#c0392b']]) miniDuck(c,dx*TS+14,dy*TS-6+Math.sin(time*2+dx)*0.8,col,null); }
  else { for(const [dx,dy,col] of [[2.4,5.6,'#b5322a'],[9.4,6.6,'#c0392b']]) miniDuck(c,dx*TS+14,dy*TS-6,col,'#7a1f1f'); }
  const gl=c.createRadialGradient(6.5*TS,2.8*TS,10,6.5*TS,2.8*TS,6*TS); gl.addColorStop(0,'rgba(255,150,70,'+(svc?0.30:0.20)+')'); gl.addColorStop(1,'rgba(255,150,70,0)'); c.fillStyle=gl; c.fillRect(0,0,RWp,RHp);
  drawMe(c,time);
  if(g.target&&g.mode==='play') drawBubble(c,g.target.x,g.target.y,time,'Z');
  const a2=ambient(g.clock);
  if(a2[3]>0.1){ c.fillStyle='rgba(20,18,50,'+(a2[3]*0.12).toFixed(2)+')'; c.fillRect(ox,oy,vw,vh); }
  c.setTransform(1,0,0,1,0,0);
}
function drawRArchive(c,W,H,kd,time){
  const vw=W/kd, vh=H/kd, RWp=LIBW*TS, RHp=LIBH*TS;
  const fx=vw>=RWp?(RWp/2-vw/2):Math.max(0,Math.min(RWp-vw,g.px-vw/2)), fy=vh>=RHp?(RHp/2-vh/2):Math.max(-30,Math.min(RHp-vh+10,g.py-14-vh/2));
  const ox=Math.round(fx*kd)/kd, oy=Math.round(fy*kd)/kd;
  c.setTransform(kd,0,0,kd,-ox*kd,-oy*kd);
  const spine=['#7a2a2a','#5a3a4a','#c9a24a','#8a5a2b','#a8432b','#4a5a6a','#c0392b','#6a4a3a'];
  for(let ty=0;ty<LIBH;ty++) for(let tx=0;tx<LIBW;tx++){
    const ch=libCh(tx,ty), px=tx*TS, py=ty*TS;
    if(ch==='W'){ rect(c,px,py,TS,TS,'#4a3430'); rect(c,px,py+TS-4,TS,4,'#2e201c'); rect(c,px+4,py+4,TS-8,2,'rgba(255,255,255,0.07)'); continue; }
    rect(c,px,py,TS,TS,((tx+ty)&1)?'#7a5f4a':'#6f5640'); rect(c,px,py+15,TS,1,'rgba(0,0,0,0.15)');
    if(ch==='D') rect(c,px+2,py+4,TS-4,TS-4,'#7b4a22');
  }
  rect(c,3.2*TS,3.4*TS,6.6*TS,2.2*TS,'#6a2a32'); c.strokeStyle='#d9b84a'; c.lineWidth=2; c.strokeRect(3.2*TS+5,3.4*TS+5,6.6*TS-10,2.2*TS-10);
  for(let ty=0;ty<LIBH;ty++) for(let tx=0;tx<LIBW;tx++){
    const ch=libCh(tx,ty), px=tx*TS, py=ty*TS;
    if(ch==='B'||ch==='S'||ch==='Q'){
      rect(c,px,py,TS,TS,'#5b4430'); rect(c,px+2,py+2,TS-4,TS-4,'#3b2b1e');
      for(let r=0;r<3;r++){ const y=py+3+r*9; rect(c,px+2,y+8,TS-4,1.5,'#8a6a45');
        for(let k=0,x=px+3;k<6&&x<px+TS-4;k++){ const w=3+((tx*5+ty*3+r*7+k*3)%3); rect(c,x,y+(k%3===0?1:0),w,8-(k%3===0?1:0),spine[(tx*3+ty+r*5+k)%spine.length]); x+=w+0.5; } }
      if(ch==='Q'){ rect(c,px+2,py+2,TS-4,TS-4,'#1c1210'); rect(c,px+4,py+4,TS-8,TS-8,'#2a1a14'); rect(c,px+13,py+13,6,8,'#c9a24a'); c.strokeStyle='#c9a24a'; c.lineWidth=2; c.beginPath(); c.arc(px+16,py+13,3.4,Math.PI,0); c.stroke(); circ(c,px+16,py+17,1,'#3a2a14'); }
    } else if(ch==='T'){
      rect(c,px,py+6,TS,TS-6,'#8a6238'); rect(c,px,py+6,TS,5,'#b98a55'); rect(c,px,py+TS-4,TS,4,'#5b3f22');
      if(tx%2===0){ rect(c,px+6,py+2,14,6,'#e8d9b5'); rect(c,px+8,py+4,10,1,'#7a5a3a'); }
    } else if(ch==='A'){
      rect(c,px,py+6,TS,TS-6,'#7a4a30'); rect(c,px,py+6,TS,4,'#a87850'); rect(c,px,py+TS-4,TS,4,'#4a2a18');
      if(tx===5) { rect(c,px+8,py+2,14,6,'#e8d9b5'); }
      if(tx===7) { rect(c,px+10,py,3,8,'#c0392b'); }
    } else if(ch==='G'){
      rect(c,px-10,py+8,TS+20,22,'#8a6238'); rect(c,px-8,py+10,TS+16,16,'#e8d9b5');
      c.fillStyle='#c0392b'; for(let k=0;k<8;k++){ c.fillRect(px-6+k*5,py+14+Math.sin(k*0.8)*2+4,2,2); }
      c.strokeStyle='rgba(122,42,34,0.6)'; c.lineWidth=1; c.beginPath(); c.moveTo(px-6,py+18); for(let k=1;k<8;k++) c.lineTo(px-6+k*5,py+18+Math.sin(k*0.8)*2); c.stroke();
    }
  }
  /* Archivist Sorrel at her desk */
  miniDuck(c,6.5*TS,7*TS+2,'#d9503f','#5a3a4a');
  const gl=c.createRadialGradient(6.5*TS,4.5*TS,10,6.5*TS,4.5*TS,6*TS); gl.addColorStop(0,'rgba(255,190,120,0.18)'); gl.addColorStop(1,'rgba(255,190,120,0)'); c.fillStyle=gl; c.fillRect(0,0,RWp,RHp);
  drawMe(c,time);
  if(g.target&&g.mode==='play') drawBubble(c,g.target.x,g.target.y,time,'Z');
  const a2=ambient(g.clock);
  if(a2[3]>0.1){ c.fillStyle='rgba(20,18,50,'+(a2[3]*0.18).toFixed(2)+')'; c.fillRect(ox,oy,vw,vh); }
  c.setTransform(1,0,0,1,0,0);
}
{
  const _drawInterior=drawInterior;
  drawInterior=function(c,W,H,kd,time){
    if(g.scene==='lib'){
      if(g.libKind==='rchurch'){ drawRChurch(c,W,H,kd,time); return; }
      if(g.libKind==='rlib'){ drawRArchive(c,W,H,kd,time); return; }
    }
    _drawInterior(c,W,H,kd,time);
  };
}

/* ---------- Emberwick's own calendar ---------- */
const RED_EVENTS=[
  {id:'rbank',title:'The Banking of the Fires',h:18,dur:2,tag:'fest',c:3,desc:'At dusk every hearth in Emberwick is covered in ash, together, house by house. Visitors may watch from the square.',join:['The bells ring six. All over Emberwick, doors open and ash is drawn across coals, one house after another, like a wave.','Nobody speaks. For a moment the whole town sounds like a single, enormous sigh.']},
  {id:'rcoldwalk',title:'Walk of the Cold Fires',h:10,dur:3,tag:'fest',c:4,desc:'The town walks to the Wood\'s edge and puts out a fire, in memory of the March. Visitors are not asked to join. Visitors are not stopped. It is held once a year.',join:['A long line of red ducks, carrying small lanterns in the daylight, walks to the edge of the Wood. They put out the lanterns one by one.','You follow at a respectful distance. A small hand slips into your wing for the last part of the walk. It is gone before you look.']},
  {id:'rmarket',title:'Ember Market',h:11,dur:5,tag:'market',c:4,item:'beetloaf',desc:'Stalls in the square. Beet bread, red thread, tiny clockwork beetles. Haggling is considered rude. So is staring.',join:['The square is a river of red. Stalls sell loaves, braids, candles. A woman presses a loaf into your wing without a word and walks on.','It is warm. It is not a gift. It is a loaf. You eat it anyway.']},
  {id:'rstory',title:'Hearthside Hour',h:17,dur:2,tag:'fest',c:3,desc:'Elders tell the old stories to the children by the Great Hearth. Short ones. The long ones are not told.',join:['An old duck tells of the time a beetle carried a coal across the Wood in the dark and kept the first fire lit.','You are at the very back. A child turns around halfway through to make sure you are still there. You are.']},
  {id:'rthread',title:'Thread-Tying Day',h:12,dur:3,tag:'market',c:4,item:'redthread',desc:'Every duckling gets a red braid at birth and a new knot each year. Today the knots are tied.',join:['Small ducks line up with their wings out. Grown ones tie one knot each, with great seriousness.','A ribbon is placed in your wing as well. No one asks if you want it. No one asks if you do not. You keep it.']},
  {id:'rsong',title:'Banking Song Night',h:20,dur:2,tag:'music',c:3,desc:'The old lullaby, sung low, house by house. It is not a performance. You are allowed to listen.',join:['From window after window comes the same tune, slow and tender. It is the one the old ducks hum when they think no one is listening.','You do not sing. It does not feel like yours. But your feathers know it anyway.']}
];
const RED_YEAR=112, RED_YEARLY={rthread:57,rcoldwalk:85};   /* day-of-year of Thread-Tying Day and the Walk of the Cold Fires (both odd, so they land on event days) */
{
  const _eventFor=eventFor;
  eventFor=function(t,day){
    if(t&&t.isRed){
      if(day%2===0) return null;
      /* two of the festivals are yearly, so they come round once a (112-day, sixteen-week) year, not in the weekly rotation */
      const yd=((day-1)%RED_YEAR)+1;
      if(yd===RED_YEARLY.rthread) return RED_EVENTS.find(e=>e.id==='rthread');
      if(yd===RED_YEARLY.rcoldwalk) return RED_EVENTS.find(e=>e.id==='rcoldwalk');
      const often=RED_EVENTS.filter(e=>!(e.id in RED_YEARLY));
      return often[((day-1)/2|0)%often.length];
    }
    return _eventFor(t,day);
  };
}

/* ---------- the standing chip and the journal speak the truth ---------- */
{
  const _updateHud=updateHud;
  updateHud=function(){
    _updateHud();
    const tw=g.scene==='shop'?g.shop.town:townAtTile(Math.floor(g.px/TS),Math.floor((g.py-2)/TS));
    if(tw&&tw.isRed&&!g.story.isRed){ const v='Outsider'; if(el.repTxt.textContent!==v) el.repTxt.textContent=v; hudCache.rep=v; }
  };
  const _renderJournal=renderJournal;
  renderJournal=function(){
    _renderJournal();
    const rows=el.jrBody.querySelectorAll('.jrow');
    rows.forEach(r=>{
      const nm=r.firstChild&&r.firstChild.firstChild&&r.firstChild.firstChild.textContent;
      if(nm==='Emberwick'&&!g.story.isRed){
        const kids=r.children;
        kids[1].textContent='Outsider';
        kids[3].textContent='Standing cannot be earned here.';
        if(kids[2].firstChild) kids[2].firstChild.style.width='0%';
      }
    });
  };
}
