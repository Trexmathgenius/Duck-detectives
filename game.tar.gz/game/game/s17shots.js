'use strict';
/* ===== STORY SHOTS: pictures of what is being told =====
   A narrated cutscene page shows the thing being narrated: the siege night, the two words, the march north, the beacon.
   SHOTS[name](c,t,o) draws one full picture in scene space (320 x 180; the text box covers the bottom, so keep the action
   above y=158). t is seconds since this page appeared, so every shot moves. cutSeq (s17cuts.js) maps pages to shots. */
(function(){
const SHOTS={};
const ez=x=>{ x=Math.max(0,Math.min(1,x)); return x*x*(3-2*x); };
const rn=i=>{ const s=Math.sin(i*127.1+311.7)*43758.5453; return s-Math.floor(s); };
const lerp=(a,b,k)=>a+(b-a)*k;
const P={
  eider:{body:'#f4f4ee',wing:'#d4d8cf',bill:'#ff9d2e'},
  gord:{body:'#8a2a2a',wing:'#5a1a1a',bill:'#c9a24a'},
  mallow:{body:'#c0392b',wing:'#962d22',bill:'#ff9d2e'},
  cinder:{body:'#b5322a',wing:'#8a2620',bill:'#ff9d2e'},
  ruddock:{body:'#a82a2a',wing:'#7f1f1f',bill:'#d9902a'},
  halbeak:{body:'#4a6fb5',wing:'#37558c',bill:'#e6c441'},
  poppy:{body:'#e0603f',wing:'#b24a30',bill:'#e6c441'},
  bree:{body:'#cf5a48',wing:'#9a3a2e',bill:'#ff9d2e'},
  wrenna:{body:'#7a8a6a',wing:'#5a6a4a',bill:'#d9a066'},
  grey:{body:'#8a8f99',wing:'#6a6f78',bill:'#d9a066'}
};
const me=()=>{ try{ return (g.story&&g.story.isRed)?P.mallow:{body:'#ffd84a',wing:'#f0b921',bill:'#ff8a1f'}; }catch(e){ return {body:'#ffd84a',wing:'#f0b921',bill:'#ff8a1f'}; } };
const REDS=['#c0392b','#d9503f','#a83a2d','#e04a3a','#b5352b','#d9503f'], BLUES=['#4a6fb5','#5a82c9','#3f5f9f','#6a8fd0'];
const duck=(c,x,y,dir,pal,sc,o)=>drawDuck(c,x,y,dir,0,false,pal,Object.assign({scale:sc||1.8},o||{}));
const walk=(c,x,y,dir,t,pal,sc,o)=>drawDuck(c,x,y,dir,t*6,true,pal,Object.assign({scale:sc||1.8},o||{}));
function vg(c,a){ const gr=c.createRadialGradient(LW/2,LH/2,LH*0.35,LW/2,LH/2,LW*0.7); gr.addColorStop(0,'rgba(0,0,0,0)'); gr.addColorStop(1,'rgba(4,2,14,'+a+')'); c.fillStyle=gr; c.fillRect(0,0,LW,LH); }
function ridge(c,y,col,amp,fr,ph){ c.fillStyle=col; c.beginPath(); c.moveTo(0,LH); for(let x=0;x<=LW;x+=8) c.lineTo(x,y+Math.sin(x*fr+(ph||0))*amp); c.lineTo(LW,LH); c.closePath(); c.fill(); }
function glow(c,x,y,r,col){ const gr=c.createRadialGradient(x,y,1,x,y,r); gr.addColorStop(0,col); gr.addColorStop(1,col.replace(/[\d.]+\)$/,'0)')); c.fillStyle=gr; c.fillRect(x-r,y-r,r*2,r*2); }
function stars(c,t,n,ymax){ for(let i=0;i<n;i++){ const x=rn(i)*LW, y=rn(i+50)*ymax, a=0.35+0.65*Math.abs(Math.sin(t*1.4+i)); c.fillStyle='rgba(255,255,230,'+a.toFixed(2)+')'; c.fillRect(x,y,1,1); } }
function moon(c,x,y,r,bg){ circ(c,x,y,r*1.8,'rgba(244,239,208,0.10)'); circ(c,x,y,r,'#f4efd0'); circ(c,x+r*0.45,y-r*0.3,r*0.85,bg); }
function night(c,t,top,bot){ sky(c,top||'#0a0e2a',bot||'#2a2a58',22); stars(c,t,60,90); }
function flame(c,x,y,s,t){ const f=0.85+0.15*Math.sin(t*9+x); c.fillStyle='#ff7a2a'; c.beginPath(); c.moveTo(x-4*s,y); c.quadraticCurveTo(x-5*s,y-8*s*f,x+Math.sin(t*11+x)*1.5*s,y-16*s*f); c.quadraticCurveTo(x+6*s,y-8*s*f,x+4*s,y); c.fill(); c.fillStyle='#ffd166'; c.beginPath(); c.moveTo(x-2.4*s,y); c.quadraticCurveTo(x-3*s,y-5*s*f,x,y-10*s*f); c.quadraticCurveTo(x+3*s,y-5*s*f,x+2.4*s,y); c.fill(); }
/* floating music notes */
function notes(c,x,y,t,col,n,spread){ n=n||5; for(let i=0;i<n;i++){ const k=(t*0.28+i/n)%1, nx=x+Math.sin(k*6+i*2)*(spread||14)+i*3, ny=y-k*54; c.globalAlpha=Math.max(0,1-k)*0.9; c.fillStyle=col||'#fff3c4'; c.beginPath(); c.ellipse(nx,ny,2.2,1.6,-0.4,0,6.3); c.fill(); c.fillRect(nx+1.6,ny-6,1,6.5); c.fillRect(nx+1.6,ny-6,3,1.2); } c.globalAlpha=1; }
function word(c,txt,x,y,size,col,a,glowc){ c.save(); c.globalAlpha=a===undefined?1:a; c.font='italic 700 '+size+'px Georgia,serif'; c.textAlign='center'; c.textBaseline='middle'; c.shadowColor=glowc||col; c.shadowBlur=10; c.fillStyle=col; c.fillText(txt,x,y); c.shadowBlur=0; c.restore(); }
function lantern(c,x,y,s,t,lit){ s=s||1; rect(c,x-1*s,y-8*s,2*s,2*s,'#4a4a4a'); rect(c,x-4*s,y-6*s,8*s,10*s,'#3a2a1a'); rect(c,x-3*s,y-5*s,6*s,8*s,lit===false?'#554':'rgba(255,226,140,'+(0.85+0.15*Math.sin(t*7)).toFixed(2)+')'); if(lit!==false) glow(c,x,y-1*s,14*s,'rgba(255,200,110,0.4)'); }
function crystal(c,x,y,h,col,t,lean){ const a=0.6+0.4*Math.sin(t*2.5), w=h*0.18; c.save(); c.translate(x,y); c.rotate(lean||0); c.fillStyle=col; c.beginPath(); c.moveTo(-w,0); c.lineTo(-w*0.7,-h*0.8); c.lineTo(0,-h); c.lineTo(w*0.7,-h*0.8); c.lineTo(w,0); c.closePath(); c.fill(); c.fillStyle='rgba(255,255,255,0.4)'; c.fillRect(-w*0.3,-h*0.85,w*0.25,h*0.8); c.restore(); }
function charTree(c,x,y,h,col){ col=col||'#1c1a20'; rect(c,x-2,y-h,4,h,col); c.strokeStyle=col; c.lineWidth=2; c.beginPath(); c.moveTo(x,y-h*0.7); c.lineTo(x-9,y-h*0.95); c.moveTo(x,y-h*0.55); c.lineTo(x+10,y-h*0.85); c.moveTo(x,y-h*0.85); c.lineTo(x+5,y-h*1.05); c.stroke(); }
function houseSm(c,x,y,s,wall,roof,lit,t){ rect(c,x-12*s,y-14*s,24*s,14*s,wall); c.fillStyle=roof; c.beginPath(); c.moveTo(x-16*s,y-13*s); c.lineTo(x,y-30*s); c.lineTo(x+16*s,y-13*s); c.fill(); rect(c,x-3*s,y-9*s,6*s,9*s,'#3b2a2a'); if(lit){ const f=0.75+0.25*Math.sin((t||0)*6+x); rect(c,x+5*s,y-11*s,5*s,5*s,'rgba(255,214,130,'+f.toFixed(2)+')'); } }
function stoneWall(c,x0,x1,y,h,col){ c.fillStyle=col||'#4a4e6a'; c.fillRect(x0,y,x1-x0,h); for(let x=x0;x<x1;x+=24) c.fillRect(x,y-10,14,10); c.fillStyle='rgba(0,0,0,0.22)'; for(let yy=y+12;yy<y+h;yy+=12) c.fillRect(x0,yy,x1-x0,1); }
function arrows(c,t,x0,x1,y0,y1,n,frozen,col){ c.strokeStyle=col||'rgba(190,200,230,0.8)'; c.lineWidth=1; for(let i=0;i<n;i++){ const k=frozen?((i*0.37)%1):((t*0.25+i*0.173)%1), x=x0+rn(i)*(x1-x0)+k*8, y=y0+k*(y1-y0); c.beginPath(); c.moveTo(x,y); c.lineTo(x+2,y+9); c.stroke(); c.fillStyle='rgba(220,226,245,0.9)'; c.beginPath(); c.moveTo(x+2,y+11); c.lineTo(x,y+6); c.lineTo(x+4,y+6); c.fill(); } }
function sitting(c,x,y,col,dir,s){ mini(c,x,y,col,dir||'left',s||1.3,0); }
function cottage(c,t,o){ o=o||{}; c.fillStyle=o.wall||'#3a2420'; c.fillRect(0,0,LW,LH); c.fillStyle=o.wall2||'#4a2e28'; c.fillRect(0,0,LW,108); for(let x=0;x<LW;x+=16) rect(c,x,0,1,108,'rgba(0,0,0,0.2)'); c.fillStyle=o.floor||'#2a1a16'; c.fillRect(0,116,LW,64); if(o.window!==false){ rect(c,230,20,60,48,'#1a100c'); rect(c,234,24,52,40,o.sky||'#0e1430'); if(!o.sky) stars(c,t,10,38); rect(c,258,24,2,40,'#1a100c'); rect(c,234,42,52,2,'#1a100c'); } }
function candle(c,x,y,t,s){ s=s||1; rect(c,x-2*s,y-8*s,4*s,8*s,'#efe6c8'); flame(c,x,y-8*s,0.35*s,t); glow(c,x,y-12*s,26*s,'rgba(255,190,100,'+(0.3+0.05*Math.sin(t*6)).toFixed(2)+')'); }

/* ---------- the siege night (chapter 11's dream, and what Gordamom tells later) ---------- */
function siegeBase(c,t,o){
  o=o||{};
  night(c,t); moon(c,268,34,10,'#0a0e2a'); ridge(c,124,'#161a3a',6,0.03,1);
  stoneWall(c,0,200,92,88,'#4a4e6a');
  c.fillStyle='#2a2c44'; c.fillRect(70,128,52,52); c.beginPath(); c.arc(96,128,26,Math.PI,0); c.fill();
  c.fillStyle='#232a3a'; c.fillRect(0,144,LW,36); c.fillStyle='#1c2230'; c.fillRect(200,106,120,74);
  if(!o.noEider){ duck(c,132,92,'down',P.eider,1.7,{head:'royal'}); }
  for(let i=0;i<18;i++){ const x=212+(i%6)*16+(Math.floor(i/6)%2)*6, y=130+Math.floor(i/6)*13; sitting(c,x,y,REDS[i%6],'left',1.25); if(o.children&&i%4===1) mini(c,x+7,y+2,'#e8806a','left',0.8,0); }
  if(!o.noGord) duck(c,194,150,'left',P.gord,2.2,{head:'helm'});
}
SHOTS.wallNight=(c,t)=>{ siegeBase(c,t,{}); const p=0.5+0.5*Math.sin(t*1.5); for(let i=0;i<9;i++){ const x=8+i*22; c.fillStyle='rgba(30,30,50,0.85)'; c.beginPath(); c.moveTo(x,82); c.lineTo(x+1,72); c.lineTo(x+2,82); c.fill(); } vg(c,0.55); };
SHOTS.arrowsChildren=(c,t)=>{ siegeBase(c,t,{children:true}); arrows(c,t,10,196,34,76,60,false); glow(c,194,140,40,'rgba(255,200,120,0.12)'); vg(c,0.55); };
SHOTS.gordAsk=(c,t)=>{ night(c,t); ridge(c,128,'#161a3a',6,0.03,1); c.fillStyle='#232a3a'; c.fillRect(0,128,LW,52); duck(c,110,150,'right',P.gord,3.0,{head:'helm'}); duck(c,236,152,'left',me(),2.1); const k=0.5+0.5*Math.sin(t*2); glow(c,172,100,50,'rgba(255,214,150,'+(0.15+0.1*k).toFixed(2)+')'); notes(c,172,120,t,'#ffe9b0',3,10); vg(c,0.5); };
SHOTS.eiderWord=(c,t)=>{ siegeBase(c,t,{noEider:true}); const k=ez(t/2.5); duck(c,132,92,'down',P.eider,1.7,{head:'royal'});
  /* wings raised, a word with no sound: rings that thin to nothing, and water running through an open wing */
  c.strokeStyle='rgba(240,244,255,'+(0.5*(1-ez((t-3)/3))).toFixed(2)+')'; c.lineWidth=1; for(let i=0;i<4;i++){ const q=((t*0.35+i*0.25)%1); c.globalAlpha=(1-q)*0.7*(1-ez((t-3.5)/3)); c.beginPath(); c.ellipse(132,78,10+q*60,6+q*28,0,0,6.3); c.stroke(); } c.globalAlpha=1;
  for(let i=0;i<10;i++){ const q=((t*0.9+i*0.1)%1); c.fillStyle='rgba(150,190,255,'+(0.7*(1-q)).toFixed(2)+')'; c.fillRect(120+i*2.6,74+q*60,1,3); }
  vg(c,0.55); };
SHOTS.gordWord=(c,t)=>{ siegeBase(c,t,{noGord:true}); duck(c,132,92,'down',P.eider,1.7,{head:'royal'});
  const k=ez(t/3); duck(c,194,150-k*6,'up',P.gord,2.2+k*0.2,{head:'helm'});
  /* an open shape, like an arm, or a door */
  const a=ez((t-1)/4); c.save(); c.globalAlpha=0.85*a; c.strokeStyle='#ffd9a0'; c.lineWidth=3; c.shadowColor='#ffb860'; c.shadowBlur=12; c.beginPath(); c.moveTo(166,150); c.lineTo(166,100); c.quadraticCurveTo(194,70,222,100); c.lineTo(222,150); c.stroke(); c.restore();
  c.fillStyle='rgba(255,214,150,'+(0.22*a).toFixed(2)+')'; c.fillRect(170,104,48,46); vg(c,0.55); };
SHOTS.twoWords=(c,t)=>{ siegeBase(c,t,{}); arrows(c,t,10,196,40,80,40,true); for(let i=0;i<40;i++){ const x=(i*29)%LW, y=(i*47)%130; c.fillStyle='rgba(180,200,240,0.4)'; c.fillRect(x,y,1,4); }
  const w=ez((t-0.5)/5); const a1=t*1.4, a2=t*1.4+Math.PI, R=60*(1-w)+6*w, cx=150, cy=104;
  const x1=cx+Math.cos(a1)*R, y1=cy+Math.sin(a1*1.3)*R*0.4, x2=cx+Math.cos(a2)*R, y2=cy+Math.sin(a2*1.3)*R*0.4;
  glow(c,x1,y1,26,'rgba(235,240,255,0.55)'); circ(c,x1,y1,3,'#f4f6ff'); glow(c,x2,y2,26,'rgba(255,190,100,0.55)'); circ(c,x2,y2,3,'#ffd9a0');
  if(w>0.9){ glow(c,cx,cy,70,'rgba(255,230,180,0.25)'); }
  vg(c,0.55); };
SHOTS.gordTired=(c,t)=>{ night(c,t); ridge(c,126,'#161a3a',6,0.03,1); c.fillStyle='#232a3a'; c.fillRect(0,130,LW,50); for(let i=0;i<16;i++){ const x=170+(i%8)*18+(i>7?8:0), y=142+(i>7?12:0); mini(c,x,y,REDS[i%6],'left',1.3,Math.sin(t*1.1+i)*0.3); }
  duck(c,120,150,'left',P.gord,2.8,{head:'helm'}); for(let i=0;i<3;i++){ const q=(t*0.2+i*0.33)%1; c.fillStyle='rgba(220,220,255,'+(0.6*(1-q)).toFixed(2)+')'; c.font='700 9px Georgia,serif'; c.fillText('z',150+i*8+q*10,100-q*26); } vg(c,0.5); };
SHOTS.gordLookUp=(c,t)=>{ siegeBase(c,t,{noGord:true}); duck(c,194,150,'up',P.gord,2.2,{head:'helm'}); const k=0.5+0.5*Math.sin(t*2); c.strokeStyle='rgba(255,214,150,'+(0.25+0.2*k).toFixed(2)+')'; c.lineWidth=1.5; c.beginPath(); c.moveTo(188,128); c.quadraticCurveTo(160,108,136,98); c.stroke(); glow(c,136,98,24,'rgba(255,214,150,0.25)'); vg(c,0.55); };

/* ---------- the two words, told again by the Old Tree (chapter 18) ---------- */
SHOTS.wordsOnWall=(c,t)=>{ siegeBase(c,t,{noGord:false}); const a=ez(t/2), b=ez((t-2)/2);
  /* Eider's word: a door swinging shut. Gordamom's: a door swinging open. */
  const door=(x,open,col)=>{ const w=18*(1-open*0.85); c.fillStyle=col; c.fillRect(x-w,52,w,40); c.fillRect(x,52,w,40); c.strokeStyle='rgba(255,255,255,0.4)'; c.strokeRect(x-w+0.5,52.5,w*2-1,39); };
  c.save(); c.globalAlpha=0.9*a; door(112,1-Math.min(1,t/4),'rgba(200,215,255,0.55)'); c.restore(); word(c,'STAY',112,40,14,'#dfe8ff',a,'#8fb0ff');
  c.save(); c.globalAlpha=0.9*b; door(246,Math.min(1,(t-2)/3),'rgba(255,200,120,0.5)'); c.restore(); word(c,'SHELTER',246,40,14,'#ffd9a0',b,'#ff9d3e');
  vg(c,0.5); };
SHOTS.sleepersToTrees=(c,t)=>{ night(c,t,'#12142a','#2a2a40'); ridge(c,118,'#1c1c2a',5,0.04,1); c.fillStyle='#2a2a34'; c.fillRect(0,128,LW,52);
  const k=ez(t/6);
  for(let i=0;i<22;i++){ const a=i/22*Math.PI*2, x=160+Math.cos(a)*110, y=132+Math.sin(a)*15; if(Math.sin(a)<-0.5) continue;
    if(k<0.98){ c.globalAlpha=1-k; mini(c,x,y,REDS[i%6],x<160?'right':'left',1.3,0); c.globalAlpha=1; }
    c.globalAlpha=k; charTree(c,x,y,14+rn(i)*12); c.globalAlpha=1; }
  /* the word leaves, a small light rising and drifting south */
  const q=ez((t-3)/5); glow(c,160+q*110,100-q*70,22,'rgba(255,214,150,0.55)'); circ(c,160+q*110,100-q*70,3,'#fff3c4');
  vg(c,0.5); };
SHOTS.wordFlies=(c,t)=>{ night(c,t); ridge(c,128,'#161a3a',6,0.03,1); c.fillStyle='#1c2a3a'; c.fillRect(0,128,LW,52);
  /* a river, and on its far bank a line of red feathers: the only thing the Edict reaches */
  c.fillStyle='#2a4a7a'; c.beginPath(); c.moveTo(0,118); c.quadraticCurveTo(160,98,320,126); c.lineTo(320,142); c.quadraticCurveTo(160,122,0,138); c.fill();
  for(let i=0;i<14;i++){ const x=10+i*22, y=118+Math.sin(i)*3; c.save(); c.translate(x,y); c.rotate(-0.3); c.fillStyle='rgba(192,57,43,0.7)'; c.fillRect(0,0,6,1.6); c.restore(); }
  const q=ez(t/7); const x=-10+q*340, y=70+Math.sin(q*5)*8+q*30; glow(c,x,y,26,'rgba(255,214,150,0.55)'); circ(c,x,y,3.2,'#fff3c4'); for(let i=1;i<7;i++){ circ(c,x-i*7,y-Math.sin((q-i*0.02)*5)*0+i*0.6,3-i*0.4,'rgba(255,214,150,'+(0.5-i*0.07).toFixed(2)+')'); }
  vg(c,0.5); };
SHOTS.hatch=(c,t)=>{ sky(c,'#2a3a50','#e8b878',22); ridge(c,112,'#3a5a4a',7,0.03,1); c.fillStyle='#3a6a44'; c.fillRect(0,126,LW,54); for(let x=0;x<LW;x+=24) charTree(c,x+6,126,40+rn(x)*20,'#1e3a28');
  circ(c,250,100,18,'rgba(255,214,150,0.3)'); circ(c,250,100,9,'#ffe2a0');
  ell(c,160,148,26,8,'#2a4a30'); const k=ez((t-2)/3);
  ell(c,160,138,9,12*(1-k*0.5),'#f4efe0'); c.strokeStyle='#5a4a30'; c.lineWidth=1; c.beginPath(); c.moveTo(152,138); c.lineTo(156,134); c.lineTo(160,139); c.lineTo(164,133); c.lineTo(168,138); c.stroke();
  glow(c,160,136,30+k*20,'rgba(255,230,160,'+(0.3+0.3*k).toFixed(2)+')');
  if(k>0.1){ duck(c,160,150-k*4,'down',{body:'#ffd84a',wing:'#f0b921',bill:'#ff8a1f'},0.7+k*1.5); }
  vg(c,0.35); };
SHOTS.threeRoads=(c,t)=>{ sky(c,'#2a2060','#f0a56b',22); ridge(c,112,'#2a2a52',8,0.03,1); c.fillStyle='#2a3a30'; c.fillRect(0,126,LW,54);
  houseSm(c,40,128,1.0,'#6a4a48','#932d22',true,t); houseSm(c,66,126,0.8,'#6a4a48','#7a2a24',true,t);
  c.fillStyle='#d8d2c0'; c.fillRect(256,92,40,36); c.fillStyle='#3a5f9c'; c.beginPath(); c.moveTo(252,92); c.lineTo(276,72); c.lineTo(300,92); c.fill();
  for(let i=0;i<10;i++) charTree(c,150+i*5+rn(i)*5,126,16+rn(i+3)*14,'#1c1a20');
  const g1=0.5+0.5*Math.sin(t*2); c.lineWidth=5; c.lineCap='round';
  for(const [x,col] of [[54,'rgba(255,170,120,'],[276,'rgba(150,190,255,'],[170,'rgba(190,180,230,']]){ c.strokeStyle=col+(0.35+0.2*g1).toFixed(2)+')'; c.beginPath(); c.moveTo(x,126); c.quadraticCurveTo(160,150,160,164); c.stroke(); }
  const q=ez(t/6); walk(c,lerp(66,160,q),148+q*0,'right',t,me(),1.8); duck(c,276,140,'down',P.halbeak,1.1,{head:'helm'}); duck(c,40,140,'down',P.ruddock,1.1,{head:'helm'});
  vg(c,0.4); };
SHOTS.eiderChains=(c,t)=>{ night(c,t,'#12142a','#2a2a40'); c.fillStyle='#2a2a34'; c.fillRect(0,128,LW,52);
  rect(c,112,126,96,6,'#6a4a30'); ell(c,160,120,30,8,'#f4f4ee'); circ(c,196,114,8,'#f4f4ee'); rect(c,203,114,8,2.4,'#ff9d2e'); circ(c,198,112,1.1,'#222');
  const k=ez(t/6); c.save(); c.strokeStyle='rgba(150,190,255,'+(0.7*(1-k)).toFixed(2)+')'; c.lineWidth=1.5; for(let i=0;i<7;i++){ const x=120+i*14; c.beginPath(); c.moveTo(x,60+k*-10); c.lineTo(x+(i-3)*2,118); c.stroke(); } for(let i=0;i<3;i++){ c.beginPath(); c.ellipse(160,114,40+i*10,12+i*3,0,0,6.3); c.stroke(); } c.restore();
  for(let i=0;i<14;i++){ const q=(t*0.3+i*0.07)%1; c.fillStyle='rgba(180,210,255,'+(0.6*(1-q)*(1-k)+0.25*k*(1-q)).toFixed(2)+')'; c.fillRect(120+rn(i)*80,118-q*60,1.4,1.4); }
  if(k>0.5){ glow(c,196,112,34,'rgba(255,230,180,'+(0.4*(k-0.5)*2).toFixed(2)+')'); }
  vg(c,0.55); };

/* ---------- the ward lets go, or breaks (chapter 19) ---------- */
function wardBase(c,t){ night(c,t,'#12142a','#2a2a40'); ridge(c,118,'#1c1c2a',5,0.04,1); c.fillStyle='#2a2a34'; c.fillRect(0,128,LW,52); charTree(c,160,138,52,'#1c1a20'); }
const ANCH=[[60,70],[260,70],[60,124],[260,124]];
SHOTS.wardOpen=(c,t)=>{ wardBase(c,t); const k=ez(t/5);
  c.save(); c.strokeStyle='rgba(200,170,255,'+(0.8*(1-k*0.8)).toFixed(2)+')'; c.lineWidth=1.5; for(const a of ANCH){ for(const b of ANCH){ if(a===b) continue; c.beginPath(); c.moveTo(a[0],a[1]+(a[1]<100?-k*10:k*10)); c.lineTo(b[0],b[1]+(b[1]<100?-k*10:k*10)); c.stroke(); } c.beginPath(); c.moveTo(a[0],a[1]); c.lineTo(160,98); c.stroke(); } c.restore();
  for(const a of ANCH){ crystal(c,a[0],a[1]+8,22,'#c9a6ff',t); glow(c,a[0],a[1]-6,22,'rgba(200,170,255,0.4)'); }
  /* a hand, opening */
  c.save(); c.translate(160,60); c.globalAlpha=0.55; c.fillStyle='#e8e0f0'; for(let i=0;i<5;i++){ const a=-Math.PI/2+(i-2)*0.4*k; c.save(); c.rotate(a); c.fillRect(-2,-26,4,26); c.restore(); } ell(c,0,4,14,8,'#e8e0f0'); c.restore();
  vg(c,0.5); };
SHOTS.sleepersBreathe=(c,t)=>{ wardBase(c,t); for(let i=0;i<26;i++){ const a=i/26*Math.PI*2, x=160+Math.cos(a)*112, y=132+Math.sin(a)*15; if(Math.sin(a)<-0.45) continue; const b=Math.sin(t*1.8-0.0); ell(c,x,y,6,2.8+b*0.6,REDS[i%6]); glow(c,x,y-2,10+b*3,'rgba(170,200,255,'+(0.2+0.12*b).toFixed(2)+')'); circ(c,x,y-2,1.3,'#dfe9ff'); }
  for(let i=0;i<3;i++){ const q=(t*0.4+i/3)%1; c.strokeStyle='rgba(200,190,230,'+(0.35*(1-q)).toFixed(2)+')'; c.beginPath(); c.ellipse(160,142,20+q*130,6+q*30,0,0,6.3); c.stroke(); } vg(c,0.5); };
SHOTS.wardShatter=(c,t)=>{ wardBase(c,t); const k=ez(t/2.4);
  if(t<0.6){ c.fillStyle='rgba(220,230,255,'+(0.8*(1-t/0.6)).toFixed(2)+')'; c.fillRect(0,0,LW,LH); }
  for(let i=0;i<46;i++){ const a=rn(i)*6.283, r=k*(30+rn(i+9)*150), x=160+Math.cos(a)*r, y=88+Math.sin(a)*r*0.7+k*k*40*rn(i+4); c.save(); c.translate(x,y); c.rotate(a+t*3*rn(i+2)); c.globalAlpha=Math.max(0,1-k*0.8); c.fillStyle=i%2?'rgba(200,170,255,0.9)':'rgba(240,235,255,0.9)'; c.beginPath(); c.moveTo(0,-5); c.lineTo(3,3); c.lineTo(-3,2); c.fill(); c.restore(); }
  for(const a of ANCH){ crystal(c,a[0],a[1]+8,22,'#9a86c8',t,(rn(a[0])-0.5)*k); }
  c.strokeStyle='rgba(235,240,255,0.7)'; c.lineWidth=1; for(let i=0;i<12;i++){ const a=i*0.5236+0.2, r=k*190; c.beginPath(); c.moveTo(160,88); c.lineTo(160+Math.cos(a)*r,88+Math.sin(a)*r*0.7); c.stroke(); }
  vg(c,0.55); };
SHOTS.farKingFalls=(c,t)=>{ night(c,t); ridge(c,126,'#161a3a',6,0.03,1); c.fillStyle='#1c2230'; c.fillRect(0,140,LW,40);
  castle(c,230,140,0.9,'#565c78','#3a5f9c',t,'#e0b84a'); const p=0.6+0.4*Math.sin(t*2.4); glow(c,230,42,40,'rgba(140,180,255,'+(0.4*p).toFixed(2)+')'); circ(c,230,40,2.6,'#cfe6ff');
  const k=ez((t-1)/3); rect(c,206,76,40,3,'#6b6458'); duck(c,226,76+k*0,'down',P.eider,0.9+0,{head:'royal'}); c.save(); c.translate(226,70); c.rotate(k*1.4); c.restore();
  /* the crystal flickers and a white speck falls */
  const fy=76+ez((t-2)/3)*50; circ(c,226+Math.sin(t*3)*2,fy,2,'rgba(255,255,255,'+(0.9*(1-ez((t-4.5)/1.5))).toFixed(2)+')');
  c.fillStyle='rgba(0,0,0,'+(0.3*k).toFixed(2)+')'; c.fillRect(0,0,LW,LH); vg(c,0.55); };
SHOTS.litterArrives=(c,t)=>{ wardBase(c,t); const k=ez(t/6); const x=-40+k*190;
  for(let i=0;i<4;i++){ const dx=[-22,22,-22,22][i]; walk(c,x+dx,148+(i>1?4:-2),'right',t+i,i%2?P.halbeak:P.mallow,1.3,{head:i%2?'helm':null}); }
  rect(c,x-26,126,52,4,'#6a4a30'); ell(c,x,122,17,5,'#f4f4ee'); circ(c,x+14,118,5,'#f4f4ee'); rect(c,x+18,118,5,1.6,'#ff9d2e'); c.fillStyle='#c9a24a'; c.fillRect(x+10,111,8,3);
  vg(c,0.5); };

window.S17SHOTS=SHOTS;
window.S17H={P:P,ez:ez,rn:rn,lerp:lerp,me:me,REDS:REDS,BLUES:BLUES,duck:duck,walk:walk,vg:vg,ridge:ridge,glow:glow,stars:stars,moon:moon,night:night,flame:flame,notes:notes,word:word,lantern:lantern,crystal:crystal,charTree:charTree,houseSm:houseSm,stoneWall:stoneWall,arrows:arrows,sitting:sitting,cottage:cottage,candle:candle,siegeBase:siegeBase,wardBase:wardBase};
})();
