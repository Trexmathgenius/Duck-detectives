'use strict';
/* ===== v1.29: VOICES, PART ONE =====
   How people talk to you, by kind; and what every person of Mallardia says, from the sealed castle to the world after the end.
   A voice is { tone, role, intro, early, p2, a2..a6 / war / crisis / after, end, recall, feathers, meet, knows, claim }.
   Any value can be keyed by ending (wake/door/keeper/stay), by road ('red' / 'crown' / 'k' for the keeper's road),
   by feathers ('redfeather' / 'yellow'), or 'any'; or be a function of the moment (ctx). See s20lives.js. */
(function(){
const LV=window.LV;
const V=LV.voice;
const A=(...c)=>c;   /* a list of conversations */
const base=(name,i)=>{ try{ const n=kNpcList().find(x=>x.name===name); return n?n.lines[i]:null; }catch(e){ return null; } };
const baseAll=name=>{ try{ const n=kNpcList().find(x=>x.name===name); return n?n.lines.slice():null; }catch(e){ return null; } };
const s4=()=>{ try{ return S4st(); }catch(e){ return {}; } };
const arc=()=>{ try{ return S4st().arc||{}; }catch(e){ return {}; } };
const hasRec=(ctx,k,v)=>ctx.seen(k)===v;
const ENDW={wake:'It is safe now',door:'It will be safe',keeper:'It will be tended',stay:'Let it stay'};
LV.ENDW=ENDW;

/* ======================================================================
   TONES: how a kind of person greets you
   ====================================================================== */
const T=LV.TONE;
const warmNick=(ctx,m)=>ctx.nick&&m&&m.n>=4?ctx.nick:null;
T.folk={
  call:(ctx,m)=>warmNick(ctx,m)||(ctx.pi>=4?'Detective':m&&m.n>=3?'friend':'traveller'),
  away:['{Call}! Two days, three? I lose count. Welcome back.','There you are. I was wondering where you had got to.','Back again, {call}? Good. I had things saved up to tell you.'],
  long:['{Call}! {days} days! I had started to think the road had kept you.','Well, look who it is. {days} days, and not a word. I am not cross. I am a little cross.','{Call}. You have been gone {days} days, and you look like every one of them.'],
  feathers:A(['Your feathers! They are red. Properly red, all the way down.','Well. It suits you. I did not think I would say that, and there it is.']),
  nick:A(['People have started to call you something, you know. "{nick}." I heard it at the market.','I think it fits. Do not let it go to your head.']),
  meet:A(['Oh! You are the detective. Everybody knows the detective by now. I am {name}.'])
};
T.merchant={
  call:(ctx,m)=>warmNick(ctx,m)||(m&&m.n>=6?'my best customer':m&&m.n>=2?'friend':ctx.pi>=4?'Detective':'traveller'),
  away:['{Call}! Back already? Business is better when you are in town.','There is my {call}. I kept the good ones back.'],
  long:['{Call}! {days} days! I nearly sold your usual to a stranger.','{days} days, {call}. The stall missed you. I did not. I did, a bit.'],
  feathers:A(['Red! Red feathers! I have a scarf that would go with that. No, not that one. This one.','(Very quietly.) Nobody here will charge you more for it. If they do, you send them to me.']),
  nick:A(['They call you "{nick}" now, down the row. I put it on a sign once, by accident. It sold well.']),
  meet:A(['A customer! Oh, wait, you are the detective. A customer AND a detective. I am {name}. Pears are half price for heroes. Not for detectives. For heroes.'])
};
T.soldier={
  call:(ctx,m)=>ctx.pi>=7&&m&&m.n>=4?'friend':'Detective',
  away:['Detective. As you were.','Detective. Back on the wall, I see. Well, in front of it.'],
  long:['Detective. {days} days absent. I had begun to post your name with the missing.','{Call}. {days} days. You look like you walked every one of them twice.'],
  feathers:A(['(He looks at your feathers, then at the wall, then at your feathers.)','Red. I am told I am not to remark on it. I am remarking on it. That is the end of the remark.']),
  nick:A(['The barracks have a name for you, Detective. "{nick}." It was meant as a joke. It has stopped being one.']),
  meet:A(['Detective. You will not know me. Everyone in Kingsbill knows you. {name}, at your service.'])
};
T.elder={
  call:(ctx,m)=>warmNick(ctx,m)||(m&&m.n>=3?'little one':'child'),
  away:['There you are, {call}. Sit a moment. Old knees like company.','Back again. Good. I have been saving a thought for you.'],
  long:['{days} days, {call}. At my age you start to count them.','{Call}. {days} days. I thought of you every one of them. That is not a complaint. It is an accounting.'],
  feathers:A(['Red, now. Well. I was a child when red was a crime. I am too old to be frightened of a colour. Come here, let me look.']),
  nick:A(['They have started calling you "{nick}". A name is a coat other people sew for you. Try it on. Keep it if it fits.']),
  meet:A(['So you are the one everybody talks about. You are smaller than the stories. They always are. I am {name}.'])
};
T.gentle={
  call:(ctx,m)=>warmNick(ctx,m)||(m&&m.n>=3?'friend':'little one'),
  away:['Welcome back, {call}. There is always room.','Peace to you, {call}. You look as if you could use some.'],
  long:['{Call}. {days} days. I lit a candle for you on the fourth. It seemed the thing to do.','{days} days. We kept your place on the pew. Nobody sat in it. Somebody wanted to.'],
  feathers:A(['Your feathers have turned. Let me say it plainly, as a blessing: there is nothing wrong with you. There never was anything wrong with them.']),
  nick:A(['I hear they call you "{nick}" now. It is a kind name. People do not give kind names to people they do not need.']),
  meet:A(['Welcome, little one. I know your face. Half the kingdom does. I am {name}.'])
};
T.scholar={
  call:(ctx,m)=>ctx.pi>=7&&m&&m.n>=4?'my friend':'Detective',
  away:['Detective. Good. I have marginalia for you.','You are back. I have three new questions and one new answer. The answer is less interesting.'],
  long:['{days} days, Detective. I have kept notes. Some of them are about you.','Detective. {days} days. The records do not stop for anyone, but they do wait, a little.'],
  feathers:A(['Your feathers are red. I have written it down. I write everything down. It is the first time I have written it down without feeling I ought to report it to somebody.']),
  nick:A(['There is a new name in the margins of the market ledgers. "{nick}." I have cross-referenced it. It is you.']),
  meet:A(['You are the detective. I have read about you. Mostly in my own handwriting. I am {name}.'])
};
T.child={
  call:()=>'detective',
  away:['You came back! I knew you would. I said so. Nobody listened.','DETECTIVE. Hello. Hello. That is two hellos, because you were gone.'],
  long:['You were gone for {days} WHOLE days. I counted on my feet. I ran out of feet.','Where did you go? For {days} days? Was it a mystery? Was it a big one?'],
  feathers:A(['YOUR FEATHERS ARE RED. How? Can mine? Do you have to eat something? I will eat it.']),
  nick:A(['The big ducks call you "{nick}". I call you detective. Mine is better.']),
  meet:A(['Are you the detective? THE detective? I am {name}. I know all about you. I know about three things about you.'])
};
T.herald={
  call:()=>'Detective',
  away:['Hear ye! The Detective is back! (That was for you. You are welcome.)','Hear ye, hear ye: Detective. That is the whole announcement.'],
  long:['Hear ye! After {days} days, the Detective returns! Hear ye further: I have been saving announcements!','{days} days! I very nearly announced you missing. I had the parchment out.'],
  feathers:A(['Hear ye! Hear ye! The Detective is red! Hear ye further: nobody is to make anything of it! By order of me!','(Lower.) I asked nobody\'s permission for that one. It felt correct.']),
  nick:A(['Hear ye! The Detective is now commonly called "{nick}"! I did not make that up. I wish I had.']),
  meet:A(['Hear ye! It is the Detective! I am {name}, Herald of Kingsbill! I announce things! You are a thing! Welcome!'])
};
T.nervous={
  call:()=>'Detective',
  away:['Oh! Detective. You startled me. Everything startles me. It is not you.','Detective! Hello. I was just. I was not doing anything. Hello.'],
  long:['Detective! {days} days. I thought something had happened. Something always might have happened.'],
  feathers:A(['Your feathers! They are. They are red. Is that. Is that on purpose? It looks on purpose. It looks nice. Sorry.']),
  nick:A(['People say "{nick}" when you go past. I say it too, now, in my head. Is that all right?']),
  meet:A(['Oh! The detective. I. Hello. I am {name}. You have probably heard of me. You have not heard of me.'])
};
T.road={
  call:(ctx,m)=>m&&m.n>=3?'old road-friend':'traveller',
  away:['Back on the road, {call}? It is a good road. It is long, but it is good.','There you are. The road always brings people back. Mostly.'],
  long:['{Call}! {days} days. The road told me you were well. The road says that about everyone. I believed it this time.'],
  feathers:A(['Red now, is it? The road does not care what colour your feet are. Neither do I.']),
  nick:A(['Travellers coming south talk about a "{nick}". I said, I know that one. They did not believe me.']),
  meet:A(['A traveller! No: the detective. The road talks about you. I am {name}.'])
};
T.royal={
  call:(ctx,m)=>m&&m.n>=4?'my friend':'Detective',
  away:['Detective. You came back. People do not, as a rule. I have been finding out how pleasant it is when they do.'],
  long:['{days} days. I used to measure time in centuries. I find days are much harder.'],
  feathers:A(['Red. Yes. It was always going to be someone red who asked. I am glad it was a friend.']),
  nick:A(['They call you "{nick}". I was called "the Wise". Yours is better. Yours is true.']),
  meet:A(['You will forgive me for not rising. I have been sitting for a very long time, and I have only just learned how to stop.'])
};
T.hearth={
  call:(ctx,m)=>{
    if(warmNick(ctx,m)) return ctx.nick;
    if(ctx.pi>=7) return m&&m.n>=4?'neighbour':'friend';
    if(ctx.red) return m&&m.n>=3?'kin':'red one';
    if(ctx.route==='red'&&ctx.pi>=4) return 'friend';
    return ctx.pi<=3?'yellow one':'Detective';
  },
  away:['{Call}. Warm hearth.','Warm hearth, {call}. You have been somewhere cold. I can tell.'],
  long:['{Call}. {days} days. The Hearth did not go out. I checked it for you.','Warm hearth, {call}. {days} days. Sit. The fire is the same fire. You are not quite the same.'],
  feathers:A(['(A long look at your feathers.)','So. The potion took. Red to the root. Welcome to a colour that has never once been easy. Warm hearth, kin.']),
  nick:A(['The children have a name for you. "{nick}." Children are the only honest record-keepers we have.']),
  meet:A(['You are the one. Everyone in Emberwick has an opinion of you. I am {name}. I am still forming mine.'])
};

/* ======================================================================
   ROLES: what anyone of a kind says, in each part of the story
   (the fallback: a person with nothing of their own to say still never says something out of date)
   ====================================================================== */
const R=LV.ROLE;
R.folk={
  p2:{redfeather:A(['People are whispering about a red-feathered stranger. Then they look at you, and stop whispering.']),any:A(['They say you went north into the Hollow Wood and came back. Most people do not come back from places like that with all their feathers.'])},
  war:{crown:A(['The Crown has a detective now. A real one. You. Everybody is very proud and very nervous.']),red:A(['There are red ducks, real ones, in a town in the Wood. Everybody says so now. Nobody says what we are supposed to do about it.']),any:A(['Soldiers drilling, heralds shouting, prices up. It feels like the old stories. I did not like the old stories.'])},
  crisis:A(['The ground shook last night. Not much. Enough to wake the cups.','Everybody is waiting for something. Nobody will say what.']),
  after:{wake:A(['The Burnt Wood is going green. My grandmother would not have believed it. I do not quite believe it, and I have seen it.']),door:A(['A red duck came through the market today. Bought two pears. Paid. Left. It was the most ordinary thing, and everybody stood very still.']),keeper:A(['There is a table in the Burnt Wood now, they say, with a ring of chairs. Anyone can sit. I have been meaning to go. I am working up to it.']),stay:A(['Quiet days. Good days, I suppose. I keep waiting for something to happen, and nothing does, and I am told that is the point.']),any:A(['Things are different now. Better, mostly. Stranger, certainly.'])}
};
R.soldier={
  p2:A(['Orders are orders. The orders are: wait. We are very good at waiting.']),
  war:{crown:A(['The barracks smell of polish and argument. Everyone has an opinion about the march. Nobody has the rank to have one.']),red:A(['They say there is a red army in the Wood. There is no red army in the Wood. There are red families in the Wood. I have started saying so out loud.']),any:A(['Double watches. Nobody sleeps. The crystal hums.'])},
  crisis:A(['We stood the line all night. Nobody came. Everybody was afraid somebody would.']),
  after:{stay:A(['The orders are: nothing. Stand easy. I do not know what to do with my wings when they are not holding a spear.']),any:A(['I have not drawn a weapon in weeks. I keep checking it is still there. It is still there. Nobody needs it.'])}
};
R.faith={
  p2:A(['We pray for the ones in the Wood now, by name, when we know the names. We are learning some.']),
  war:A(['The pews are full. Fear fills a church faster than faith does. I take them both.']),
  crisis:A(['I have buried no one this week. I say that every week now, in thanks. It is the shortest prayer I know.']),
  after:{stay:A(['The temple is quiet. I pray for the sleepers. I do not know why. Something in me says they are still sleeping.']),any:A(['We have started a second bell for the red families. Nobody voted on it. It simply rang one day, and nobody stopped it.'])}
};
R.lore={
  p2:A(['The records are wrong in places. I have known it a long time. I am beginning to know where.']),
  war:A(['History is happening outside the window, and I am inside, copying out the last lot. That is the job.']),
  crisis:A(['If this is written down properly, it will be the most important page in the library. I am sharpening a great many pens.']),
  after:{stay:A(['The records are closed on the matter. That is what they told me to write. I wrote it. I have never hated a sentence so much.']),any:A(['The Edict has a new last page now. It is in plain hand, and it says what happened. I have read it eleven times.'])}
};
R.child={
  p2:A(['Mama says there are red ducks in the forest. I want to meet one. Mama says that is the problem.']),
  war:A(['The soldiers are marching about. I am marching about too. Nobody is telling ME where to march.']),
  crisis:A(['Papa says not to be frightened. Then he checked the door three times.']),
  after:{stay:A(['Everybody says everything is all right now. I keep asking what was wrong. Nobody says.']),any:A(['There is a red girl called Poppy who came to the fair. She is good at hide and seek. Better than me. Nobody is better than me.'])}
};
R.hearth={
  p2:A(['A yellow one, walking about in Emberwick. A hundred years, and this is the year.']),
  war:{red:A(['The Elders are frightened. They do not show it. They show it in how often they count the children.']),crown:A(['They say the yellow detective works for the Crown now. I do not know if that is better or worse. Different.'])},
  crisis:A(['The Hearth burned low last night, and the Wood leaned in. Everybody sat up with it. Even the ones who do not believe.']),
  after:{stay:A(['The Wood is quiet. The Hearth is high. The Elders say it is over. They do not say what was over.']),any:A(['There are yellow ducks on the Lantern Road. Walking. In the day. I keep going to the window to look.'])}
};

/* ======================================================================
   THE PEOPLE OF MALLARDIA
   ====================================================================== */

/* ---------- Captain Halbeak ---------- */
V('Captain Halbeak',{tone:'soldier',role:'soldier',who:'Captain of the Royal Guard',
  intro:()=>base('Captain Halbeak',0),
  lines:A(()=>base('Captain Halbeak',1)),
  knows:ctx=>ctx.route==='crown'&&ctx.pi>=3||ctx.pi>=5,
  call:(ctx,m)=>{
    if(ctx.pi>=7&&(ctx.friend('halbeak')||(m&&m.n>=4))) return 'friend';
    if(ctx.route==='crown'&&ctx.pi>=3) return 'Detective';
    return ctx.red&&ctx.pi<=3?'red one':'Detective';
  },
  p2:{redfeather:A(['(He looks you over, slowly, from crest to feet.) Red. Last month you were yellow. I have a report somewhere that says so.','I will not ask. I am told I am a better captain when I do not ask. I am beginning to doubt the people who told me.']),
      crown:A(['You dined with the king. He has not dined with anyone in a hundred days. I have been told not to ask what was said.','I have not asked. It is very hard.']),
      any:A(['There are rumours you went into the Hollow Wood and came out the other side. My grandfather said nothing comes out of that wood but wind.','(He looks at you a long moment.) And here you are. Not wind.'])},
  a2:{crown:ctx=>ctx.march==='stopped'?A(['Three hundred and twelve ducks unbuckled their boots that day because a yellow duck asked me to read one line of a draft. I have been apologising to them in batches.','Most of them were relieved. That was the hardest part to hear.'],['I sleep now. Not well. But I sleep.'])
        :ctx.march==='delayed'?A(['One day. You asked for one day, and I wrote that I was ill. I have never been ill in my life. The physician has started bringing me broth. I cannot tell him.'],['The order is still in my desk. Read, and not obeyed. It is the heaviest piece of paper in the kingdom.'])
        :ctx.march==='went'?A(['(He does not look at you.) The march went. You were too late, and I was on time. I have always been on time.','Three hundred and twelve. I gave the order. I will be giving it in my sleep for the rest of my life.'],['Do not say you are sorry, Detective. You did more than anyone. It was not enough. That is mine to carry, not yours.'])
        :A(['The king wants a detective. The kingdom has a captain. I am curious, Detective, to see which of us he listens to.','(It is very nearly a joke.)'],['A hundred and twelve men on the wall, and not one has slept through a night in a month. The crystal hums. I hum back. I did not use to.']),
      red:A(['A red duck at my plaza. A month ago I would have called the guard. I am the guard.','I have orders about red ducks. I have read them twice. They are older than my grandfather. I am finding them harder to obey than he did.'],['Do not loiter, red one. Not for my sake. For theirs. (He nods at the windows.) Fear is the most organised thing in this kingdom.'])},
  a3:{crown:A(['The king is not ill. The king is holding something shut, and has been for a hundred years. I thought he was sleeping. He was working.','I have stood outside his door my whole life. I have never once asked if he wanted a chair.'],['The summit failed. I knew it would. I went anyway. Some failures are worth the walk.']),
      red:A(['The summit failed. You were in the room. So was I. We were the only two people in it trying.','(He does not quite smile.) If it comes to a line, red one, I will be on mine. I would rather you were not on the other side of it.'],['I am told you saw the siege. In a tree. I have read every account of that night. None of them say what my grandfather said, which was: the red soldiers were very young.'])},
  a4:{crown:A(['I swore an oath to a seal, once. I have sworn a new one, to a man. It is harder. A seal does not need anything from you.'],['The line held all night. Five fires. Nobody crossed. Nobody tried. I think that was the point, and I think it was yours.']),
      red:A(['I have been asked to hold the road against your people. I have been asked by lords I have never met, on behalf of a king I have never seen awake.','I am holding the road. I am not holding it against anybody. That is as far as my courage goes, today.']),
      k:A(['You sat down at the hermit\'s table instead of choosing. My officers think you are a coward. I think you are the only one of us who has read the whole map.'])},
  a5:A(['The ward is breaking. I can feel it in my teeth. The men can feel it in their spears.','Whatever you are about to do, Detective, my line will be where you need it. That is not an order. It is a promise, which I find I prefer.'],['If I do not see you again: you were the best thing that happened to this wall in a hundred years. There. I have said it, and I will deny it.']),
  a6:A(['They are awake. Three hundred of them, sitting up in the ash, asking for water. I carried a bucket. I have carried a great many things in my life. Nothing so heavy, and nothing so light.'],['There is talk of a road between the towns. I have been asked to guard it. I said I would rather walk it.']),
  end:{
    wake:A(['It is safe now. You said so, and it was. I stood on the south wall last night and looked north and there was nothing to guard against. Only trees. Green ones.','My grandfather held that tower with twelve ducks and a broom. I am going to retire the broom. With honours.'],
      ['The red families come in by the Lantern Road on market days. My men stand at the gate and say "good morning". That is the whole of their orders now. It is the hardest drill I have ever set. They are getting good at it.'],
      ['I keep my spear by the door. I have not touched it in a month. Some mornings I look at it the way you look at an old friend who has moved away.']),
    door:A(['It will be safe. You said "will", and you meant it, and the door has been opening a hand-width at a time ever since.','I go up most evenings to hold it. Warden Ruddock holds the other side. We argue about whose turn it is. It is the best argument I have ever had.'],
      ['A red duck came through the door this morning with a basket of beetroot and asked me where the market was. I walked her there. I am Captain of the Royal Guard. I carried the basket.'],
      ['A wall keeps people out. A door lets them choose. I have been a wall all my life. I am trying to learn to be a door. It is much more work.']),
    keeper:A(['It will be tended. That was your word, and now there is a table in the Burnt Wood and I have been made to sit at it. I sat on the third chair. I was very bad at it.','Nobody gave orders. Nobody took them. Somebody poured tea. I have never been so frightened, and I have stood on a siege wall.'],
      ['Envoys arrive. Treaties do not. Tea does. I have started to keep a spare cup in my barracks, in case anyone wants to sit down. Nobody has. The cup waits. I am learning about waiting from a cup.']),
    stay:A(['(He is standing very straight, looking north.)','It is quiet. The ward holds. The king is gone back into it. Everyone is safe, so long as no one asks.','I stood at the gate and watched you walk away, that day, until you were out of sight. I have not told anyone why. I am not sure I know.'],
      ['The men are glad. Nobody marches. Nobody dies. I write it in the log every night: "All quiet." It is true. I have never written anything so true that felt so much like a lie.'],
      ['If you ever go back to that Tree and ask again, Detective, I will be on the wall when you do. That is not an order. I do not have the rank to give you one. I never did.']),
    any:A(['The war is over. I do not know what a captain is for, without one. I am finding out. It involves a great deal of tea.'])},
  feathers:A(['(He takes off his helmet, looks at your feathers, and puts it back on.)','Red. If anyone in this city gives you trouble for it, they will give it to me first. I want that clearly understood. I am going to say it at drill.']),
  recall:[
    {id:'hal_march_stop',when:ctx=>ctx.march==='stopped'&&ctx.pi>=4,lines:['You know what they call the day you stopped the march, in the barracks? "The Day of the Boots." Three hundred and twelve pairs, unbuckled at once. It sounded like rain.']},
    {id:'hal_march_went',when:ctx=>ctx.march==='went'&&ctx.pi>=5,lines:['I went back to the Hollow road, after. Where we stopped. There is a stone there now, red and blue, and nobody will say who put it there. I think it was me. I do not remember doing it.']},
    {id:'hal_letter_carried',when:ctx=>hasRec(ctx,'wall','carried'),lines:['You carried my letter exactly as I wrote it. Every proud, stupid word. They read it, and they answered it, and they answered it kindly. I do not deserve that, and I have it anyway.']},
    {id:'hal_letter_altered',when:ctx=>hasRec(ctx,'wall','altered'),lines:['I have been told my letter to the Hollow was very gracious. I did not write it gracious. (He looks at you.) I am not going to ask. I am going to say thank you, and you are going to let me.']},
    {id:'hal_letter_refused',when:ctx=>hasRec(ctx,'wall','refused'),lines:['You would not carry my letter. You said it was not yours to carry. I was angry for a week. Then I carried it myself. It was the right answer. I hate that.']},
    {id:'hal_witness',when:ctx=>hasRec(ctx,'wall','witness'),lines:['You stood in the room when the lords called me insubordinate. You did not say anything. You did not have to. I have your name on my gate list. I will keep it there until they carry me out.']},
    {id:'hal_quiet',when:ctx=>hasRec(ctx,'wall','quiet'),lines:['You told me to stand down quietly. I did. The lords forgot about it in a week. I have not. It was good advice and I did not enjoy one minute of following it.']},
    {id:'hal_told',when:ctx=>ctx.seen('told')==='halbeak',lines:['You came to me first, after the dream. Not to the Elder, not to the hermit. To a soldier. I did not know what to do with that. I still do not. I keep it in a pocket.']},
    {id:'hal_arc',when:()=>{ const h=arc().hal; return h==='back'||h==='needed'; },lines:['At the fire you asked me whether I would have followed the order. I have been asking it of myself every day since. It has not got easier. It has got truer.']},
    {id:'hal_lantern',when:ctx=>ctx.did('c24')&&!ctx.eiderLives,lines:['I held the pole of the first lantern. There was an empty place on the roots, where a king would have stood. I kept looking at it. I think it was looking back.']}
  ]
});

/* ---------- the castle guards ---------- */
const guardClaim=ctx=>ctx.pi>=3;
V('Castle Guard Drake',{tone:'soldier',role:'soldier',claim:guardClaim,
  intro:()=>base('Castle Guard Drake',0),lines:A(()=>base('Castle Guard Drake',1)),
  a2:{crown:A(['The gate is open for you, Detective. Only for you. I am told it is an honour. It is mostly paperwork.'],['They brought the king a pen this morning. I heard him sign eleven times. I did not hear him wake once.']),red:A(['Red feathers at the gate. I have orders for red feathers. They are very old orders. I am reading them very slowly.'],['Move along. Please. Not because of you. Because of the windows. Somebody is always at a window.'])},
  a3:A(['The castle is not asleep. I know that now. Something in there is holding its breath, and has been since before I was born.'],['They say you met the king. In the dark. (He glances up at the tower.) Did he seem. All right?']),
  a4:A(['Lords in and out all day. Seals, papers, shouting behind doors. I preferred it when it was closed.'],['If the Captain says hold, I hold. If the Captain says open, I open. The Captain is the only one round here who still says anything plainly.']),
  a5:A(['The walls hum at night now. Louder. I put my wing on the stone and it is warm. Stone should not be warm.']),
  a6:A(['The gate is open. All day. Anyone. I stand here out of habit. Habit is the last thing to be told the war is over.']),
  end:{stay:A(['Closed again. The king has gone back to his work, they say. I know what his work is now. I bring the tray up anyway. Somebody should.'],['Quiet. It is quiet. (He says it the way you might say "it is raining".)']),
    wake:ctx=>ctx.eiderLives?A(['The king walks in the gardens now. In the day. He waved at me. I dropped my spear. He picked it up and gave it back and said "carry on". I will be telling that story until I die.']):A(['The king is dead, they say, and the Wood is green. I keep thinking those two things are the same thing. I think he would have liked that.']),
    any:A(['Open gate, open windows, nobody whispering. My feet still have opinions. They are better ones.'],['Do you remember when I said "Halt. Not really"? I meant it then. I mean it more now. Not really. Come in.'])}
});
V('Castle Guard Teal',{tone:'soldier',role:'soldier',claim:guardClaim,
  intro:()=>base('Castle Guard Teal',0),lines:A(()=>base('Castle Guard Teal',1)),
  a2:A(['The meals still go up. Fewer come back down untouched. I count the plates. It is the only report anybody lets me make.']),
  a3:A(['The windows have been lit blue every night this week. I asked the Captain. He said "keep watching". I have been watching. They watch back.'],['Forty days, I told you, once. It is a hundred and nine now. My feet have formed a union.']),
  a4:A(['There is a lady in green who comes and goes from the east passage at night. I have written her down four times. Nobody has asked for my book.']),
  a5:A(['The blue went out last night. Every window at once. Then it came back, weaker. Like a candle that has been breathed on.']),
  a6:A(['They carried the king out into the garden to see the sun. He sat on the bench with his eyes shut and his face up. Nobody said anything for an hour. It was the best hour of my service.']),
  end:{stay:A(['Blue in the windows again. Every night. I used to be frightened of it. Now I know it is him, holding on. I salute it. Nobody sees. I do it anyway.']),
    wake:ctx=>ctx.eiderLives?A(['Something that is not a hand used to take the trays in. Now the king comes down for them himself and asks what we are having. He has opinions about the soup.']):A(['There is a bench in the garden nobody sits on. It was his. We leave a cup on it in the mornings. Nobody told us to.']),
    any:A(['A hundred and twelve days I stood here looking at a shut door. Now it is open and I keep looking at it anyway. Habit. Or love. My mother says they are often the same.'])}
});
V('Gate Guard Pintail',{tone:'soldier',role:'soldier',claim:guardClaim,intro:()=>base('Gate Guard Pintail',0),
  a2:A(['Welcome to Kingsbill, Detective! The fountain still bites. Everything else is getting nervous.']),
  a3:A(['We check every cart now. Cabbages, mostly. I have become an expert in cabbages. I did not want this.']),
  a4:A(['Lords\' carriages, three a day, all going to the castle, none of them stopping to say thank you. You always say thank you. I have noticed.']),
  a5:A(['Folk coming in from the north road say the sky over the Burnt Wood is the wrong colour. I tell them to mind the fountain. It is all I am qualified to say.']),
  a6:A(['Red ducks at the gate this morning! A whole family! I said "welcome to Kingsbill, mind the fountain". The little one put her wing in it. It soaked her. Everybody laughed. Even her. ESPECIALLY her.']),
  end:{stay:A(['Same gate, same fountain, same everything. Restful. I keep looking north and I do not know why.']),door:A(['A trickle of red ducks through the gate every day now. One or two. I have learned all their names. Nobody asked me to. It seemed polite.']),any:A(['Welcome to Kingsbill, Detective! Mind the fountain. It bites! (It still does not bite. Some things never change, and I am glad of the ones that do not.)'])}
});
V('Gate Guard Gadwall',{tone:'soldier',role:'soldier',claim:guardClaim,intro:()=>base('Gate Guard Gadwall',0),
  a2:A(['Market is west, training yard east, castle straight ahead, and the army is everywhere. Go on in.']),
  a3:A(['Fewer travellers from Puddlewick. They say the forest is humming. I say: it always hummed. They say: louder.']),
  a4:A(['I have been told to turn back "suspicious persons". I asked what one looks like. They said "red". I said that is not a description, that is a colour. I am on night shifts now.']),
  a5:A(['Mind how you go out there. Everything north of the walls feels like it is listening.']),
  a6:A(['A cart from Emberwick came through today. Beetroot and candles. I bought a candle. It smells of somebody\'s grandmother\'s house. I do not know whose. I miss them anyway.']),
  end:{stay:A(['Market is west, training yard east, castle straight ahead. Same as ever. That is the whole report.']),any:A(['Market is west, training yard east, castle straight ahead, and the Lantern Road is north. I have added a direction. I am very proud of it.'])}
});
V('Guard Wigeon',{tone:'soldier',role:'soldier',claim:guardClaim,intro:()=>base('Guard Wigeon',0),
  a2:A(['West Gate. Hills, watchtower, Siege Field. The ghosts have been quieter since you started poking about. I do not know if that is good.']),
  a3:A(['There was a summit at the old watchtower. I watched the lanterns go up the hill and come back down too soon. Nobody waved.']),
  a4:A(['Torches on the ridge every night. Ours, theirs, I cannot tell any more. Torches all look the same from here.']),
  a5:A(['The Siege Field grew grass. One patch. Overnight. Warden Thistle went out to look at it and did not come back in until dark.']),
  a6:A(['The ghosts are gone. Well. Not gone. Resting. You can feel the difference. It is like a room after the music stops.']),
  end:{stay:A(['West Gate. Hills, tower, field, and the old stones. The ghosts still hum, on some nights. Just one verse. Same as always.']),any:A(['West Gate. Hills, the watchtower, the Siege Field, which is green now, and the old stones, which are only stones. No ghosts. I almost miss them. I do not miss them.'])}
});
V('Guard Shoveler',{tone:'soldier',role:'soldier',claim:guardClaim,intro:()=>base('Guard Shoveler',0),
  a2:A(['East Gate. Farms and the lake. Oats\' crows still will not fly north-west. Nobody has asked them why. I asked. They did not say.']),
  a3:A(['Peaceful out east. Mostly. Less mostly than it was.']),
  a4:A(['The farms are sending half their grain to the barracks. Oats says the war is eating his wheat before anybody has fired a shot.']),
  a5:A(['The lake went still last night. Not a ripple. Skipper Reed says the fish held their breath. Fish do not hold their breath. They did.']),
  a6:A(['The crows flew north-west this morning. All of them, in a cloud, out over the Wood and back. Oats cried. He says it was the wind.']),
  end:{stay:A(['East Gate. Farms and the lake. Peaceful. Properly peaceful. The crows still will not fly north-west, mind.']),any:A(['East Gate. Farms, the lake, and the crows, who go wherever they like now. Peaceful. Not mostly. Peaceful.'])}
});

/* ---------- Herald Fanfare ---------- */
V('Herald Fanfare',{tone:'herald',role:'folk',intro:()=>base('Herald Fanfare',0),lines:A(()=>base('Herald Fanfare',1)),
  p2:A(['Hear ye! The Castle is still closed! Hear ye further: there are rumours of a red town in the Hollow Wood! Hear ye further still: I am not allowed to announce rumours! Disregard!']),
  a2:{crown:A(['Hear ye! The Crown has appointed a Royal Detective! Hear ye further: it is you! (I have been dying to announce that.)'],['I announced the march. It was the worst announcement of my career. My voice went at "secure". I have not got it back properly since.']),
      red:A(['Hear ye! By order of the Crown, citizens are to report any red-feathered persons! (Quietly.) I have reported none. I am a very bad reporter. I am an excellent herald.'])},
  a3:A(['Hear ye! A summit! At the watchtower! Between the Crown and the Hollow! Hear ye further: it failed! I hate announcing the further bits.'],['I have run out of hear-yes. I have been using "listen". It does not have the same ring.']),
  a4:A(['Hear ye! The lords have split! Hear ye further: into how many pieces is not yet clear! I will update you!'],['Hear ye: watch-fires tonight at five places. Hear ye further: nobody is to be frightened. Hear ye further still: I am frightened. Unofficially.']),
  a5:A(['Hear ye! The ward has broken! Hear ye further: do not panic! Hear ye further: I have been told to say that and I do not know what a ward is! Somebody tell me what a ward is!']),
  a6:A(['Hear ye! Hear ye! The sleepers are awake! Three hundred of them! Hear ye further: they would like soup! Hear ye further still: bring soup!'],['Hear ye! A road is to be built between Kingsbill and Emberwick! Hear ye further: I have been asked to announce it in BOTH towns! I have been practising a red accent! I have been told not to!']),
  end:{wake:A(['Hear ye! Hear ye! It is safe now! Hear ye further: I announce that every morning. Nobody has asked me to stop. I do not think I will ever stop.']),
    door:A(['Hear ye! The door stands open another hand-width today! Hear ye further: I measure it! With my own wing! Hear ye further still: it is the best job I have ever had!']),
    keeper:A(['Hear ye! Tea at the Keeper\'s Table, at four! Hear ye further: everybody is welcome! Hear ye further: I have stopped announcing who is not! There is nobody who is not!']),
    stay:A(['Hear ye. Hear ye. The Castle is closed. (He says it softly.) I used to announce that cheerfully. I do not know what changed. Nothing changed. That is what changed.'],['Hear ye: all is well. Hear ye further: all is quiet. Hear ye further still: I will stop there.']),
    any:A(['Hear ye! The Castle is open! Hear ye further: it is OPEN! I have waited my whole career to say that!'])}
});

/* ---------- the market ---------- */
V('Mother Quince',{tone:'merchant',role:'folk',intro:()=>base('Mother Quince',0),
  p2:A(['Pears! Plums! And gossip, free with every pear. They say you have been north. North north. I gave you the big pear. You did not notice. I noticed.']),
  war:{crown:A(['The barracks buy my plums by the barrow now. Soldiers eat when they are frightened. I charge them less. Do not tell them.']),red:A(['A red-feathered lad bought a pear from me yesterday. I gave him the big one. He looked at it like it might bite. Pears do not bite. Fountains bite.'])},
  crisis:A(['The tree that hums has stopped humming. I miss it. I did not know you could miss a nuisance.'],['Pears are dear this month. Everything is dear. I am keeping yours the same. You did something. I do not know what. I can tell.']),
  a6:A(['There is a cook called Hob who woke up after a hundred years and asked for a pear. I gave him the big one. He cried. I cried. We had a lovely morning.']),
  end:{stay:A(['Pears, plums, perfectly priced. Same as ever. Same as ever. (She polishes a pear that is already very shiny.)']),any:A(['Pears! Plums! Beetroot! I have beetroot now, from Emberwick. It turns everything red. It turned my apron red. I have decided I like it.'],['The tree that hums is in blossom. First time in a hundred years. My pears are going to be extraordinary. I can feel it in my wings.'])}
});
V('Barnaby Bill',{tone:'merchant',role:'folk',intro:()=>base('Barnaby Bill',0),
  p2:A(['Rope! Lanterns! Lanterns for the Burnt Wood, which nobody goes into. Except you, I hear. Take two lanterns. You are the sort who needs two.']),
  war:A(['I have sold more rope this month than in ten years. The army buys it. I do not ask what for. I sleep badly.'],['Lanterns are sold out. The barracks took them. I have one left, under the counter, for you. You look like someone who walks into dark places.']),
  crisis:A(['Somebody bought every candle in Kingsbill yesterday. All of them. For five watch-fires, they said. I do not know who. I think it was a good use for candles.']),
  a6:A(['Rope for the road! Lanterns for the Lantern Road! I put a sign up. "Lanterns for the Lantern Road." I am a genius. I have sold eleven.']),
  end:{stay:A(['Rope that looks like tools. Tools that look like rope. Nobody is buying lanterns. Nobody is going anywhere. Good for nerves, bad for business.']),any:A(['I went into the Burnt Wood. Me! With a lantern! It is only a wood now, with birds in it. I came back and told everybody and nobody believed me, so I went again.'])}
});
V('Quillfeather',{tone:'scholar',role:'lore',intro:()=>base('Quillfeather',0),
  p2:A(['A map of the Hollow Wood, you ask? There is no map of the Hollow Wood. The Hollow Wood moves. I tried. The map moved.']),
  war:A(['I have been asked by the barracks for maps of the north road. Then by a quiet lady in green for the same maps. Then by you. Everybody wants the north road this month.'],['Your map draws itself. I have stopped being jealous. I have started being curious. Where does it get the ink?']),
  crisis:A(['The Ash Road. Nobody has walked it in a century. I have drawn it from the old accounts. If you walk it, come back and tell me where I was wrong. I will be wrong in at least nine places.']),
  a6:A(['I am drawing the Lantern Road. Both ends. It is the first map I have ever made with two towns on it that are both pleased to be there.']),
  end:{stay:A(['The maps have not changed. The Burnt Wood is still black on them. I keep wanting to draw it green and I do not know why.']),any:A(['New maps! The Burnt Wood, in green. Emberwick, with its name on it, for the first time on any map in the kingdom. I wrote it large. I wrote it twice.'],['The best secrets used to be under the standing stones. Now the best secrets are on the Lantern Road, and anybody can walk it. I have had to find a new line.'])}
});
V('Old Crumb',{tone:'elder',role:'folk',intro:()=>base('Old Crumb',0),
  p2:A(['Bread! I hear you have eaten red bread. Beetroot bread. I am not jealous. I am a professional. I am a little jealous.']),
  war:A(['The army eats bread. Bread is made of flour. Flour is made of wheat. Wheat is made of peace. You see my problem.'],['I bake an extra loaf every morning. Nobody asked me to. In case somebody needs it who cannot pay. Somebody always does, these days.']),
  crisis:A(['I took bread to the watch-fires. All night. Fifty loaves. My knees will never speak to me again. I would do it twice.']),
  a6:A(['A cook called Hob came by. Slept a hundred years, they say. He tasted my bread and said it was not as good as it used to be. I could have kissed him. Nobody has had the nerve to say that to me in forty years.']),
  end:{stay:A(['That rock of a loaf in the temple. The first loaf, from when the red ducks left. Sometimes I think it is still waiting for them to come back and eat it.']),any:A(['They took the first loaf out of the temple, the rock one, and broke it in half. One half went to Emberwick. They say the Elders have it on the Hearth. A hundred-year-old loaf, finally shared. I wept into my dough.'],['Beetroot bread and wheat bread, on the same counter. I sell more of the beetroot. I do not know how I feel about that. Proud, I think.'])}
});
V('Lyric Lark',{tone:'folk',role:'lore',intro:()=>base('Lyric Lark',0),lines:A(()=>base('Lyric Lark',1)),
  call:(ctx,m)=>m&&m.n>=3?'my muse':'friend',
  p2:A(['I have been working on verse two of the Ballad. Then I heard the red ducks have a song of their own, and now I cannot finish mine. It feels like singing over somebody.']),
  war:A(['They have asked me to sing marching songs. I know three. They are all sad. I sang them anyway. Nobody marched quite as fast.'],['That tune the old ducks hum. I heard it again, in the castle garden, at night, coming from a window. Four notes. I wrote them down. Do not tell anyone.']),
  crisis:A(['Four notes. The lullaby. I hear it everywhere now: the crystal, the graves, the mill. It wants a fifth note. I have tried every one. None of them are right.']),
  a6:A(['There is a fifth note! Somebody sang it at the Old Tree. A red child. I fell over. I have the bruise. It was worth it.']),
  end:{stay:A(['Four notes. Only four. I sing them to myself at night and stop where the song stops. It is a very beautiful place to stop. I wish it were not.']),
    any:A(['I have finished the Ballad! It is not about a rebellion any more. It is about a lullaby that took a hundred years to find its second verse. It is eleven verses long. Not nine hundred. Eleven.','Would you like to hear it? No? Later? Later is good. Later is a word I like now.'],
      ['I am teaching the lullaby in the square. Red ducks and yellow ducks, in rows. They all sing it slightly differently. It is the best choir I have ever had.'])},
  recall:[{id:'lark_you',when:ctx=>ctx.pi>=8,lines:['There is a verse about you in the Ballad. Do not look at me like that. It is a short verse. It rhymes "detective" with "perspective". I am very proud of it.']}]
});

/* ---------- the library, the temple, the tower ---------- */
V('Archivist Penna',{tone:'scholar',role:'lore',intro:()=>base('Archivist Penna',0),lines:A(()=>base('Archivist Penna',1)),
  p2:A(['You have been to the red town. Do not deny it. You have ash on your collar of a kind they do not sell in the kingdom.','I have forty years of questions. Sit. No: stand. You will want to leave quickly, after the first one.']),
  a2:{crown:A(['The Crown came to my library with a seal and a detective. I opened the marginalia for the first time in forty years. I feel lighter. I feel slightly arrested.'],['Eider wrote "sheltered". The Council wrote "cast out". It was the same page. I have been reading the wrong side of it my whole life.']),
      red:A(['A red-feathered duck, in my library. I have catalogued a hundred years of laws against people like you. Sit wherever you like. I am going to enjoy watching anybody try to stop you.'])},
  a3:A(['The torn page. I have found where it went. Not who tore it: where it went. It went into the king\'s own desk. He kept it. A hundred years. Whatever it says, he could not bear to burn it.'],['History is mostly a list of people who were not asked. I have started a second list. You are on it, under "asked anyway".']),
  a4:A(['There is a lady of the court who has been reading the Edict files at night. Lady Teal. She reads quickly and takes no notes. That is how you know someone is planning to use something.'],['The Hall of Names, in the north. If you go, copy one name for me. Any name. I want one real name from the other side of my records.']),
  a5:A(['I have stopped cataloguing. For the first time in forty years. I am sitting by the window. Something is about to be written, and it will not be written by me, and I find I want to see it.']),
  a6:A(['They have asked me to write the last page of the Edict. The true one. In plain hand. I have written it nine times. It keeps coming out shorter. The last draft is one line. "And they came home."']),
  end:{wake:A(['"It is safe now." I have written it into the Edict, under Eider\'s scratched-out word. The scratched-out word was "safe". He wrote it a hundred years ago and could not keep it. You kept it for him.']),
    door:A(['"It will be safe." A promise, not a fact. I have filed it under both. It is the only document in the library with two shelf-marks. I visit it.']),
    keeper:A(['"It will be tended." I had to make a new category. It is not a law, it is not a treaty, it is not a history. I have called it "a habit". It is the first habit in the Royal Library.']),
    stay:A(['"Let it stay." I have written it down. It is the shortest entry I have ever made. It is the only one I have made that I hope somebody will one day cross out.'],['The torn page is back in the king\'s desk. I put it there myself. Somebody will want it again. In a hundred years, perhaps. I have left them a note.']),
    any:A(['The Red Edict has a last page now. I have read it eleven times.'])},
  recall:[{id:'penna_truth',when:ctx=>(ctx.led.truth||0)>=6&&ctx.pi>=4,lines:['I keep a list of people who told me the truth when it cost them. It is a short list. You have three entries. Nobody else has two.']}]
});
V('Sister Dove',{tone:'gentle',role:'faith',intro:()=>base('Sister Dove',0),lines:A(()=>base('Sister Dove',1)),
  p2:{redfeather:A(['Your feathers. Come in, little one. Come right to the front. The front pew is for whoever needs it most, and today that is the person the town is staring at.']),any:A(['You have seen them, haven\'t you. The red ones. Real ones. Tell me one thing about them. One small thing. I will pray it.'])},
  war:A(['We bless the soldiers before they march. I have started blessing the people they are marching toward, too. Out loud. Some of the flock have stopped coming. More have started.'],['A flock that remembers every wrong has no room left for ducklings. I said that years ago. I did not know then how hard it would be to mean it.']),
  crisis:A(['I prayed with a captain last night. I will not say which. He did not know the words. I told him the words do not matter. He said, "then what does?" I said: "That you came."']),
  a6:A(['The sleepers are waking. One of them asked me what year it was. I told her. She said, "then everyone I knew is gone." I said, "yes. And everyone here is new. Let us start."']),
  end:{stay:A(['I light a candle every night for the three hundred. Nobody knows why I do it. I do not quite know why I do it. It feels like keeping a promise somebody else made.']),
    any:A(['We have a red acolyte now. Wren, from Emberwick. She rings our bell at dusk and theirs at dawn. She says it is the same bell, really. I have stopped arguing.'],['The church once said red ducks were cursed. Then we said we were wrong. Now we have stopped saying anything about feathers at all. It is the best sermon we have ever not preached.'])},
  feathers:A(['Your feathers. Oh, little one. Come here. Let me bless them. I bless every feather. I have never meant it so much.'])
});
V('Pip Ember',{tone:'nervous',role:'folk',intro:()=>base('Pip Ember',0),lines:A(()=>base('Pip Ember',1)),
  p2:A(['The crystal hums louder every week. I have stopped saying the name near it. I have stopped thinking the name near it. I am thinking it now. Sorry.']),
  a2:{crown:A(['I gave you the seal. In a dream he gave it to me, and then I gave it to you, and now I keep dreaming about what else he might hand me. Mostly mops.'],['He rang for me. The bell. For the first time since the new moon. When I went up, the door was shut and he said, through it: "Thank you, Pip." Just that. I have not stopped shaking.']),
      red:A(['A red duck in the tower courtyard! I. Hello. Are you going to. You are not going to do anything. Sorry. Everyone says red ducks do things. You are just standing there.'])},
  a3:A(['You met him. In the dark. Did he say. Did he mention me? He did not mention me. That is fine. He is very busy holding the world shut.'],['I swept the stairs and the dust swept back. Up. Toward the crystal. Dust does not fall up. I did not sweep for a week.']),
  a4:A(['The crystal cracked. A hair. I found it this morning. I put my wing over it as if that would help. It did not help. I am still doing it.']),
  a5:A(['I am the king\'s apprentice. I have been sweeping his stairs for six years. I did not know until last week that I was sweeping the stairs of a ward. I would have swept them better.']),
  a6:{any:ctx=>ctx.eiderLives?A(['He has asked me to be his apprentice again! Properly! He is teaching me a spell! It is a spell for boiling a kettle! It is the most important spell I have ever learned!']):A(['The bell does not ring any more. I go up anyway, in the mornings, and I sweep. The crystal is just a crystal now. It does not hum. I hum for it.'])},
  end:{stay:A(['The crystal hums again. Low. All the time. He is back in there, holding. I sweep the stairs every morning, very gently, in case he can feel it.'],['I am not to say the name. I do not say it. I say "good morning" to the crystal instead. It is the same thing, nearly.']),
    any:ctx=>ctx.eiderLives?A(['The king rings for me every morning now, for tea. He takes it very weak. He says he has had a hundred years of strong. I am the king\'s apprentice. Properly. I have a hat.']):A(['The tower is empty. He left me his books and a note that said, "Sweep only when it needs it." I sweep every day. It never needs it. I think he knew I would.'])},
  recall:[{id:'pip_seal',when:ctx=>!!(g.inv&&g.inv.royalseal)||ctx.did('c7c'),lines:['The seal was warm when I gave it to you. It went cold again the day after. I think he spent something, warming it. I think he spent it on you.']}]
});

/* ---------- the garden ---------- */
V('Gardener Hubert',{tone:'elder',role:'folk',intro:()=>base('Gardener Hubert',0),
  p2:A(['Eighty years in this maze. I got lost twice, found a chest once, and saw the king once, at night, walking it alone. I never told anyone. I am telling you. I do not know why.']),
  war:A(['The hedge grows toward the north-west now. Eighty years it grew straight. I trim it back every morning. Every night it leans again.'],['The king used to walk the maze at night. He has not come in a month. The paths miss him. I miss him. The paths more.']),
  crisis:A(['I have stopped trimming the hedge. Let it lean. It knows something I do not.']),
  a6:{any:ctx=>ctx.eiderLives?A(['The king walked the maze again last night. With a lantern. He got lost. I found him. He laughed. I have never heard him laugh. Eighty years.']):A(['There is a bench in the middle of the maze, by the chest. I put it there this week. For anyone who gets lost. Somebody who used to get lost here would have liked a bench.'])},
  end:{stay:A(['The hedge leans north-west again. I trim it. It leans. We have an understanding.']),
    any:A(['I planted a Hearthbloom at the centre of the maze. A red one. You get lost, and you find it, and it is warm. That is all a maze is for, in the end.'],['Eighty years I have trimmed this maze. I have decided to let one corner grow wild. I am eighty-nine. I would like to see what happens.'])}
});
V('Tuft',{tone:'child',role:'child',intro:()=>base('Tuft',0),
  p2:A(['I am in the maze. Do not look. (You can see her. She is not in the maze.)']),
  war:A(['Tiny says soldiers are going to fight red ducks. I said red ducks are just ducks. He said how do you know. I said I am very clever.']),
  crisis:A(['Mama says we are not to play near the north wall. So we are playing near the north wall. Very quietly. It is still hide and seek.']),
  after:{stay:A(['Mama says the trouble is all over. I asked what trouble. She said "exactly". Grown-ups are very strange.'],['When I grow up I am going to be a detective. Or a gardener. Hubert says both is allowed.']),
    any:A(['I played hide and seek with a red girl called Poppy! She hid in the Hearthbloom bush and she is red so I could not SEE her. It is cheating. It is brilliant.'],['When I grow up I am going to be a detective. Or a gardener. Hubert says both is allowed.'])}
});
V('Tiny',{tone:'child',role:'child',intro:()=>base('Tiny',0),
  p2:A(['The maze has a chest in the middle. Did you get it? I bet you got it. Was it good? Do not tell me. Tell me.']),
  war:A(['I am going to be a soldier! Then I will march! Then I will come home! That is the whole plan.'],['Keep turning left. Or right. That is the maze. I have been practising on the war. Nobody listens.']),
  crisis:A(['I am not a soldier any more. I decided. Soldiers have to go away. I would rather be a baker. Bakers get to stay.']),
  after:{stay:A(['I am taller! Look! Taller than the little hedge. Not the big hedge. The big hedge is cheating.'],['I went to look at the Burnt Wood with Tuft. It hummed at us. Just a little. We ran all the way home. It was the best day.']),
    any:A(['I am taller! Look! Taller than the little hedge. Not the big hedge. The big hedge is cheating.'],['A red boy showed me how to make a spark with two stones. Mama took the stones. I remember how. I am not telling.'])}
});

/* ---------- the farms, the mill, the lake ---------- */
V('Farmer Oats',{tone:'folk',role:'folk',intro:()=>base('Farmer Oats',0),
  p2:A(['My crows still will not fly north-west. I have started leaving corn on that side of the field anyway. In case they change their minds. In case somebody else needs it.']),
  war:{crown:A(['You asked me about my crows, for the Crown! In sixty years nobody asked me about anything but wheat. I have been telling everybody. My wife is sick of it.']),any:A(['The barracks want half my wheat. The wheat does not mind. I mind.'])},
  crisis:A(['One crow flew north-west yesterday. Just one. Out and back. The others watched it the whole way like it was a fool. It was the bravest thing I ever saw a crow do.']),
  after:{stay:A(['The crows sit on the fence and look north-west. All of them, every evening, in a row. They do not go. They just look.']),any:A(['My crows fly wherever they please now. North-west and all. I stood in the field and watched them go and I cried like a duckling. Do not tell my wife. She saw.'],['Wheat as far as you can see! And beetroot, in the far corner. A red farmer from Emberwick showed me how. It does well in the shade. So do I.'])}
});
V('Millie the Miller',{tone:'folk',role:'folk',intro:()=>base('Millie the Miller',0),lines:A(()=>base('Millie the Miller',1)),
  p2:A(['The sails turned all night again. Toward the north-west. I sat up and watched. At three in the morning I swear they slowed down, as if whatever was calling had paused to listen.']),
  war:A(['I stopped the mill. It started itself again. I stopped it. It started. In the end I let it turn. You cannot argue with wind that has made up its mind.']),
  crisis:A(['The sails stopped last night. Dead stop. No wind at all. Then one turn, slow, the other way. I have never been so frightened, and I do not know why.']),
  after:{stay:A(['The sails turn north-west at night again. Slowly. Like someone asleep, turning over. I leave them be.']),any:A(['The sails turn with the wind now. Just the wind. Ordinary wind. I could kiss it.'],['The smoke smell from the Burnt Wood is gone. Now when the wind blows from the north-west it smells like cut grass and somebody else\'s bread.'])}
});
V('Skipper Reed',{tone:'folk',role:'folk',intro:()=>base('Skipper Reed',0),
  p2:A(['I sang to the fish this morning and a ghost fish sang back. Same tune. Four notes. I have stopped singing that one.']),
  war:A(['Fishing is good. Fish do not care about wars. I have been trying to learn from them.']),
  crisis:A(['The lake went flat and still last night. Like glass. I could see the whole sky in it, and in the sky, the Burnt Wood, upside down, glowing.']),
  after:{stay:A(['The ghost fish still sing, nights. Only the first verse. I sing it back. It seems polite.']),any:A(['The ghost fish are gone. Swam off one morning, all together, north-west, up the stream. I think they went home. I hope it was home.'],['Still cannot swim. I am learning. A red duckling is teaching me. She is six. She is very strict.'])}
});

/* ---------- the field and the graves ---------- */
V('Warden Thistle',{tone:'soldier',role:'lore',intro:()=>base('Warden Thistle',0),lines:A(()=>base('Warden Thistle',1)),
  call:(ctx,m)=>m&&m.n>=4?'friend':'Detective',
  p2:A(['You have been past the ridge. Do not deny it. You walk like someone who has seen the old tree look at them.']),
  a2:{crown:ctx=>ctx.march==='stopped'||ctx.march==='delayed'?A(['I told the Captain: the ground here is full of children who were marching home. He listened. Thirty years, and he listened. I did not know what to do with my wings.']):A(['I said my piece to the Captain. He marched anyway. I came back here and sat with the graves. They have heard it all before.']),any:A(['The graves are humming louder. The lullaby. I have started humming it back, so they know someone is listening.'])},
  a3:A(['There was a summit on the hill above my field. I watched the lanterns go up. I watched them come down. I counted them both ways. The numbers matched. That is all I could hope for.']),
  a4:A(['I have started to plant grass in the bare patches. It does not take. I plant it anyway. My grandfather said the ground would grow again when somebody asked it properly. I am asking.']),
  a5:A(['A patch of grass came up. Overnight. In the worst place. Where the young ones fell. I sat in it all morning. Do not tell anyone. Tell everyone.']),
  a6:A(['They are awake. The ones under the Old Tree. I keep thinking: some of mine were their brothers. I walked out to the camp with a list. I am working through it.']),
  end:{stay:A(['The field is bare again. The patch of grass died back. The graves hum. I sit with them. Somebody should.']),
    any:A(['The Siege Field is green. All of it. Every bare patch. It grew in a week, as if it had been waiting for permission. I mow round the graves very carefully.'],['My grandfather said the king\'s word was the kindest thing he ever saw, and the worst. I think it is only kind now. I think he would have liked to know that.'])},
  recall:[{id:'thistle_spoke',when:ctx=>!!ctx.fl.thistleOk,lines:['You came to my field and asked me to speak to the Captain. Nobody had ever asked me to say anything to anyone. I have been talking ever since. My graves are sick of me.']}]
});
V('Old Rue',{tone:'elder',role:'faith',intro:()=>base('Old Rue',0),
  p2:A(['They hummed all night. The lullaby. The whole field. I sat on my stool and listened and I thought: somebody must have told them someone is coming.']),
  war:A(['I put a flower on each red grave and a flower on each blue one. I ran out of flowers. I put pebbles. A pebble is a flower that has decided to stay.']),
  crisis:A(['The lullaby has a second verse. I heard it. Faint. Under the first. Like someone humming in another room.']),
  a6:A(['There is a woman called Orla among the woken. She came to the field and read the stones one by one and said, "I knew him." And then, "and him." I held her stick. It was the most useful I have ever been.']),
  end:{stay:A(['First verse only. Every night. I do not mind. I know the second now. I hum it for them. They do not answer. I hum it anyway.']),
    any:A(['They do not hum any more. They are resting. You can tell the difference, if you have listened as long as I have. It is the difference between waiting and being home.'],['I still tend the graves. Nobody asked me to. Somebody has to. But now people come and help. Red ones, too. A boy called Ash pulls the weeds. He is very bad at it. He is here every Tuesday.'])}
});
V('Scout Wick',{tone:'soldier',role:'soldier',intro:()=>base('Scout Wick',0),
  p2:A(['Quiet at the tower. Too quiet. Then last night, not quiet. Somebody walked up the hill with a lantern and walked back down. I was too polite to ask.']),
  war:A(['A red feather was hiding in my tower last month. Very polite fugitive. He made tea. I did not report it. I am a very polite scout.']),
  crisis:A(['The summit was held in my tower. I swept it first. Nobody noticed. It failed anyway. I think it would have failed worse in a dirty tower.']),
  after:{stay:A(['Quiet at the tower. Properly quiet. Nobody comes up the hill. Nobody needs to.']),any:A(['There is a sign on my tower now. "Halfway House. Tea." The red folk on the Lantern Road stop on their way to market. I am a scout. I am a very good host.'],['The chest in the ruined tower? Somebody took it at last. Left a note: "Sorry. Needed it. Will bring it back." Signed with a little flame. I believe them.'])}
});

/* ---------- the road ---------- */
V('Wanda Wanderer',{tone:'road',role:'folk',intro:()=>base('Wanda Wanderer',0),
  p2:A(['Travellers say there are red ducks in the far woods. I have shared bread with a lot of strangers on this road. I would share it with them too. I would want to see if they share back.']),
  war:A(['Soldiers on the road north, carts of rope and lanterns. I give them bread. They eat it like it is the last bread in the world. Nobody should eat bread like that.']),
  crisis:A(['Nobody is walking south any more. Everyone is walking north, to see. To see what, I ask. They do not know. They walk anyway.']),
  after:{stay:A(['Mallard\'s Rest. Sit by the fire. Quiet road these days. Restful. I sleep well. I dream about a tree.']),any:A(['Red travellers on my road! A family from Emberwick, going south to see the sea. They have never seen the sea. I told them it is like the sky, lying down. They did not believe me. They will.'],['Mallard\'s Rest. Bread for anyone. Same as always. More anyones than there used to be. That is the only change, and it is the best one.'])}
});
V('Toll-duck Boris',{tone:'road',role:'folk',intro:()=>base('Toll-duck Boris',0),
  meet:A(['Toll bridge. The fee is one compliment. You are the detective, so I want a good one.']),
  p2:A(['Toll bridge. One compliment. (He waits.) ... You have improved. Somebody has been teaching you to be kind.']),
  war:A(['Toll bridge. Soldiers pay too. A soldier told me I had a very straight bridge. It was the saddest compliment I have ever received.']),
  crisis:A(['Toll bridge. I have waived the fee this week. People have enough to say. I just nod them over.']),
  after:{stay:A(['Toll bridge. One compliment. Go on. (He closes his eyes.) Ah. That is a good one. Pass, friend.']),any:A(['Toll bridge. A red duck paid me a compliment in the old Hearth tongue yesterday. I did not understand a word. Best toll I ever took.'],['Toll bridge. The fee is one compliment. I have started paying them back. It is a two-way bridge now. Very popular.'])}
});
V('Brother Tuck',{tone:'gentle',role:'faith',intro:()=>base('Brother Tuck',0),
  p2:A(['The stranger who spoke of a tree that remembers came back through. He looked older. Much older. He did not stay for tea again. I am starting to take it personally.']),
  war:A(['The Feather Fair is cancelled. Too many soldiers on the road. We walk anyway. A pilgrimage does not need a fair. It needs feet.']),
  crisis:A(['We have stopped walking to the kingdom. We walk to the edge of the Burnt Wood now, and stand there, and pray. Nobody told us to. It seemed the right direction.']),
  after:{stay:A(['Pilgrim\'s Rest. The road is long. The road is long. I have been saying that for years. I said it to a tree once. It hummed.']),any:A(['The Feather Fair is back. And this year there is a red stall, with red bread and red candles. We bless them all. We always did. Now they are here to be blessed.'],['The stranger came back again. He stayed for tea. He drank it all, and thanked me, and told me who he was. I will not tell you. It is his to tell.'])}
});

/* ---------- Mallow (his own story lives in the chapters; this is what he says at home) ---------- */
V('Hermit Mallow',{tone:'elder',role:'hearth',
  /* before Act II, Mallow's own chapter code speaks for him; from then on this does, unless a chapter needs him */
  claim:ctx=>ctx.pi>=3,
  call:(ctx,m)=>ctx.nick&&ctx.pi>=4?ctx.nick:'little detective',
  knows:()=>true,
  a2:{red:A(['Red suits you. I did not think it would. I am glad to have been wrong.','I always told Ruddock yellow could learn. He told me not to say that out loud. I said it very loud.'],['The kettle is on. It is always on. That is a hermit\'s one luxury: a kettle that never quite boils dry.']),
      crown:A(['A banished duck, home by the back way. Sit. I am not going to ask you what the king said. I am going to make tea and wait for you to tell me.'],['Emberwick sent me a letter. It said "come home". It did not say whose. I have been reading it every night.'])},
  a3:A(['You saw it. The siege. In the tree. I can tell; you have the look of someone who has been asked a question by a very old voice.','Whose child are you, little detective? Do not answer me. Answer it.'],['I have been thinking about my mother. I have not let myself in eighty years. You have made me very inconvenient to myself.']),
  a4:{k:A(['You sat at my table. Nobody has ever sat at my table. There were three chairs. There have always been three chairs. I never knew who the third was for.'],['A table is only a habit. A kettle, a cloth, a chair pulled out. You do it until it does itself.']),
      any:A(['My mother left Emberwick to look for me, the first spring. I was in a hollow, a mile away, crying. She walked right past. A hundred years.','(He pours tea. His wing is quite steady. That is the worst part.)'],['The Wall of Lost has a plaque for her. I have not been to see it. I will. I will go when I can bear the colour of the stone.'])},
  a5:A(['Whatever the Tree asks you, little detective, I will be at the edge of the clearing. With a kettle. Somebody should bring a kettle to the end of the world.'],['I am frightened. I want to tell you that, because you are the only one I have ever told the truth to first.']),
  a6:A(['She is awake. My mother. She asked if I had eaten. That is the whole conversation. We have been having it for a week. It is the best conversation of my life.'],['I have been thinking about the house. The one with the third chair. I think I know who it was for, now.']),
  end:{
    wake:A(['It is safe now. You said it, and it was, and my mother sleeps in a bed with a window, and wakes up in the morning, and complains about my cooking.','I am not a hermit any more, little detective. I do not know what I am. I am somebody\'s son. It is enough.'],
      ['The Burnt Wood is green by spring, they keep saying, as if it were the weather. It is not the weather. It is you.'],
      ['Come in. Sit. Three chairs. My mother in one, me in the other, and you, if you like, in the third. You were always the third. I did not know until I saw you in it.']),
    door:A(['It will be safe. I go up to the door some mornings and watch people come through it. One at a time. Looking about as if the air might be different on this side.','It is not. It is the same air. That is what they come through to find out.'],['My mother keeps the door with me some days. She says she has had a hundred years of waiting by a door and she would like the next hundred to be on the opening side.']),
    keeper:A(['The table. The kettle. A ring of chairs round the Old Tree, and nobody agreed on who put them there. (He looks at you over the cup.) It was not me.','It is the only thing I have ever built. I did not build it. You let me.'],['Envoys come, and argue, and drink my tea, which is very bad. They go home less angry. It is not the tea. It is the sitting down.']),
    stay:A(['(He is sitting at the foot of the Old Tree, with his back to the bark, the way a child sits against a parent.)','She is in there. Asleep. I can hear her breathing, if I am very still. Let it stay, you said. I am staying.'],['Do not be sad, little detective. You chose a quiet thing. I have lived a quiet life. I know how much quiet holds.','But if you ever want to ask it again: I will be here. I will move my chair.']),
    any:A(['It is a good day to be somebody\'s son.'])},
  recall:[
    {id:'mal_home',when:ctx=>ctx.k3('mallowHouse')===1&&ctx.pi>=8,lines:['The old house is an inn now. Three envoys and a lost duck stayed there last week. The lost duck was the best guest. He did the washing up.']},
    {id:'mal_window',when:ctx=>ctx.k3('mallowHouse')===2&&ctx.pi>=8,lines:['I have a window now. In Emberwick. I sit at it in the mornings and watch the street. I did not know I was allowed to want a window. You told me I was.']},
    {id:'mal_poppy',when:ctx=>ctx.k3('mallowHouse')===3&&ctx.pi>=8,lines:['Poppy has the house now. She comes on Sundays and sweeps it very badly and tells me she is practising being a Keeper. She is going to be a very good one. She is a terrible sweeper.']},
    {id:'mal_sold',when:ctx=>ctx.seen('informer')==='sold',lines:['You sold what you knew of me, once. For a purse. I know. I have known a long time. I am still making you tea. That is the whole of what I have to say about it.']}
  ]
});
LV.homes.push({name:'Hermit Mallow',always:true,where:()=>{ const q=s2(); return (q&&q.ch==='end'&&q.ending==='stay')?[KX-63,KY-58]:null; }});
})();
