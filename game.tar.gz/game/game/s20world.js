'use strict';
/* ===== v1.29: THE WORLD KEEPS UP =====
   The places and crowds that used to say the same thing forever now follow the story and who you are:
   - small talk: once a person has told you everything they have for this part of the story, every other visit is about
     the day itself (weather, hour, what is going on in the world), so nobody repeats one speech on every visit;
   - Emberwick's whispers, its closed doors, its shop greetings, and the kingdom's ducklings move on with the acts;
   - the toast when a red duck walks into a yellow town changes as the towns change;
   - the castle gate, its windows, the old reward poster and the king's statue say what is true now;
   - the epilogue says the runes on Emberwick's gate went out: now they really do, and the gate opens. */
(function(){
const LV=window.LV;
const safe=(f,d)=>{ try{ return f(); }catch(e){ return d; } };
const pick=(a,seed)=>a[LV.strHash(seed)%a.length];

/* ======================================================================
   SMALL TALK
   ====================================================================== */
const WEATHER={
  clear:['Lovely day for it. Whatever "it" is.','Not a cloud. I keep looking up in case one sneaks in.','Sun on the feathers. Best thing there is, after bread.','Bright day. The pond is showing off.','Clear as a bell. You can see all the way to the hills, and the hills can see all the way to you.','Warm enough to sit on a wall and do nothing. I intend to.','Everybody is out today. You can hear the whole town at once.'],
  cloud:['Grey today. Good for thinking. Bad for drying socks.','Clouds sitting low. Like they are listening in.','Overcast. My knees say rain by supper. My knees are rarely wrong.','A soft grey sort of day. Nobody hurries on a grey day.','The light is all one colour today. Like the world is waiting to be painted.','Cloudy. The geese do not mind. Geese do not mind anything.'],
  rain:['Rain! Proper duck weather. I do not know why everyone else goes indoors.','Wet one today. Good for the pears, bad for the paperwork.','Listen to it on the roofs. Like a thousand small knocks.','Rain down the back of the neck. Lovely. I mean it.','Everything smells green when it rains. Even the bread.','The gutters are singing. I have been listening to them all morning.'],
  fog:['Fog so thick you could spread it on toast.','Mind how you go in this. I walked into the same post twice this morning. It apologised. I think it was a person.','Fog makes everything sound closer. I heard a kettle from three streets away.','You cannot see the end of the street. It is very restful, not knowing what is there.','Foggy. Everyone looks like a ghost until they say good morning.'],
  storm:['Hear that? Thunder, rolling round the hills like a barrel. Stay near a door.','Storm coming over the ridge. The geese are all facing the same way. That is never a good sign.','Lightning over the north woods. I counted. Seven seconds. Not close. Close enough.','Hold on to your hat. And your feathers. And me, if it comes to it.','The wind has been arguing with the shutters all morning. The shutters are losing.']
};
const HOUR={
  morning:['Early yet. The bread is still warm and nobody has had time to be cross.','Good morning. I always think the first hour is the honest one.','Morning. The light comes in low and makes everything look like it is about to happen.','You are up early. Or late. I will not ask which.','Morning! The dew is still on everything. Mind your feet.','First thing, and already you are about. You keep detective hours.'],
  day:['Middle of the day already. Where does it go?','Busy hour. Everybody walking about as if they are late for something.','Afternoon. My favourite time to sit down and pretend I am not sitting down.','Lunch. I have had it. I am thinking about having it again.','The sun is right on top of us. No shadows. Nowhere to hide. I like it.','Long afternoon. They go slower when you are waiting for something.'],
  evening:['Evening coming in. The lamps will be lit soon.','Getting on for supper. You can smell every kitchen in town.','The light goes gold about now. It makes everybody look kinder. Some of them are.','The day is nearly done. I always feel I ought to have done more with it. I never do.','Evening. The swallows are out. They are very busy for birds with no job.'],
  night:['Late to be about. Owls and detectives.','Quiet night. You can hear the pond breathing.','Stars out. I never know any of their names. I give them new ones.','Night. Everybody sensible is asleep. Here we are.','The moon is very bright. Go carefully, but do look at it.']
};
const IDLE={
  soldier:['Nothing to report. That is the best report there is.','My boots need resoling. My feet need resoling. The spear is fine.','I drilled the new ones this morning. They are terrible. I was terrible. It gets better.'],
  merchant:['Slow day at the stall. I have rearranged the pears four times. They look exactly the same.','Prices are prices. Do not ask me about prices. Ask me about pears.','I sold a hat to a goose. Do not ask. It suited her.'],
  elder:['My knees told me the weather this morning. They were right, as usual. I wish they were wrong about more things.','I have been sitting here thinking about nothing at all. It is very hard work, at my age.','When I was young this street was mud. It is cobbles now. I miss the mud. Do not tell anyone.'],
  gentle:['Sit a moment, if you like. Nobody has to be anywhere.','I have been watching the sparrows on the roof. They argue constantly and they never leave each other. There is a sermon in that.','We mended the temple roof this week. It still leaks in one place. I have put a bowl there and called it a font.'],
  scholar:['I have been reading about the old roads. They went everywhere, once. Then people stopped walking them, and they stopped going anywhere.','I found a mistake in a book from three hundred years ago. I have been happy all day.','A footnote. I am writing a footnote. It is going to be longer than the page. It always is.'],
  herald:['Nothing to announce. I am announcing that. It is a very small announcement.','My voice is resting. This is it resting.'],
  nervous:['I dropped a broom on my foot this morning. That is my news. It was a big broom.','I am fine. Everything is fine. I just like to say so out loud. In case.'],
  road:['The road was kind today. Not too dusty. Not too long. Well. Long.','I met a carter with a mule called Gerald. Gerald does not like compliments. I tried. He bit me.'],
  hearth:['The coal came in this morning. Good coal. You can tell by the sound it makes in the scuttle.','The children were at their sums all morning. You could hear them through the wall. Nineteen, nineteen-one, nineteen-two.','Banking at six. Same as every day. It is the best hour.'],
  royal:['I have been watching the gardener. He has been watching me watching him. We have reached an understanding.'],
  folk:['Nothing much doing. I have been meaning to fix that gate for a year. Today is not the day either.','I made soup. It is soup. That is all I can say for it.','My neighbour has a new hat. It is very large. I have opinions.']
};
const KID_WEATHER={
  clear:['It is SUNNY. I am going to run until I fall over.','The sun is out. I am out. We are both out.'],
  cloud:['The clouds look like bread. All of them. I am hungry.'],
  rain:['PUDDLES. Do you want to jump in one? You do. I can tell.','It is raining and Mama says I cannot go out but I AM out.'],
  fog:['I cannot see anything. I am a ghost. Wooo.'],
  storm:['The sky is SHOUTING. I am not scared. I am a little scared.']
};
const TODAY={
  war:['Everybody is talking in low voices today. I keep doing it too, without meaning to.','More soldiers on the road again. I count their boots. I do not know why.','The bakery sold out by nine. Everyone is buying two of everything.','A rider went through at dawn with a blue seal. Everybody watched him go and nobody asked.'],
  crisis:['Another night of watch-fires, they say. You can see the glow from the hill.','Nobody slept much. You can tell by the shops. Everything opens late and closes early.','The dogs would not settle last night. Every dog in town, facing north.','People keep stopping in the street to look at the sky. Then they look at each other. Then they walk on.'],
  a6:['They are laying the first stones of the Lantern Road. Folk are walking out just to look at stones.','There was singing in the square last night. Red and yellow. Out of tune, together.','Somebody hung a red lantern and a blue one from the same hook outside the inn. Nobody has taken either down.','The sleepers keep asking what everything costs. Then they sit down. Then they laugh. Prices have gone up in a hundred years.'],
  end:{wake:['Somebody walked in from the Burnt Wood this morning with a basket of mushrooms. Mushrooms! From there!','Market day tomorrow. Red stalls and yellow ones, side by side. My favourite day of the week now.'],
    door:['Two more came through the door yesterday, they say. A grandmother and a boy. Somebody gave them a pear.','The door is open another hand. People keep saying it to each other, like the weather.'],
    keeper:['Tea at the Tree today, if you are going. Bring a cup. They are always short of cups.','An envoy went up to the table this morning looking furious. Came back down looking sleepy. That is how you know.'],
    stay:['Quiet day. They are all quiet days. I am getting used to it.','Nothing doing. Nothing at all. Good, I suppose.']}
};
const tod=()=>{ const h=g.clock; return h<5?'night':h<11?'morning':h<17?'day':h<21?'evening':'night'; };
LV.small=function(V,ctx,name,i,m){
  const wx=safe(()=>wxNow(),'clear')||'clear', seed=name+'|'+g.day+'|'+i;
  const kid=V&&V.tone==='child';
  const out=[];
  if(kid){ out.push(pick(KID_WEATHER[wx]||KID_WEATHER.clear,seed)); return out; }
  const r=LV.strHash(seed)%4;
  if(r===0) out.push(pick(WEATHER[wx]||WEATHER.clear,seed));
  else if(r===1) out.push(pick(HOUR[tod()],seed));
  else if(r===3) out.push(pick(IDLE[(V&&V.tone)||'folk']||IDLE.folk,seed));
  else{
    const t=LV.resolve(TODAY[ctx.ph]!==undefined?TODAY[ctx.ph]:TODAY[ctx.grp],ctx);
    out.push(t&&t.length?pick(t,seed):pick(WEATHER[wx]||WEATHER.clear,seed));
  }
  if(m&&m.n>=10&&LV.strHash(seed+'r')%4===0) out.push('You come by most days now. I have started setting the clock by you.');
  if(V&&V.tone==='herald') return out.map(s=>'Hear ye! '+s);
  return out;
};

/* ======================================================================
   WHO YOU HAVE BECOME, AS OTHER PEOPLE SEE IT
   ====================================================================== */
const TRAITSEEN={
  candid:['You will tell me the truth, I suppose. You always do. It is very inconvenient, and I have come to rely on it.','People say you do not soften things. I have noticed you do not need to. You say them kindly instead.'],
  gentle:['You look tired. Kind people always look tired. Sit a moment.','I hear you gave something away again. You will have nothing left at this rate. (A pause.) I do not think you mind.'],
  proud:['Chin up, as ever. Somebody has to keep it up, I suppose.','You hold your ground. I have watched you do it. I hope you check, now and then, that it is the right ground.'],
  guarded:['You are giving nothing away today, I see. That is all right. I will talk. You can listen.','You keep a door on the latch, {call}. I am not asking you to open it. I am telling you I have noticed it is there.'],
  steady:['Good. You are here. Things go steadier when you are here. I do not think you know that.','People lean on you. I have seen them do it without noticing. Mind you have somewhere to lean, too.'],
  tender:['I saw you with the little ones earlier. They follow you about like ducklings. Well. They are ducklings. You know what I mean.','You always notice who is at the edge of the room. Somebody should notice you noticing.']
};
const STANDING={
  soldier:{hi:['The barracks speak well of you, {call}. Soldiers do not speak well of anyone. I thought you should know.'],lo:['Some of the officers do not care for you, {call}. I do not care what the officers care for. Mind how you go near them.']},
  hearth:{hi:['The Hearth speaks well of you. The Elders do not say so. The Elders are not the Hearth.'],lo:['Not everyone at the Hearth has forgiven you, {call}. I am telling you so you are not surprised. Not so you stop coming.']}
};
LV.whoLine=function(V,ctx,name,m){
  const seed=name+'|'+ctx.ph;
  if(LV.strHash(seed)%2) return null;   /* not everybody says it, and not every time */
  const role=V&&V.role;
  if(role==='soldier'||role==='hearth'){
    const st=role==='soldier'?ctx.crown:ctx.hearth, S=STANDING[role];
    if(st>=3) return [pick(S.hi,seed)];
    if(st<=-2) return [pick(S.lo,seed)];
  }
  if(ctx.trait&&TRAITSEEN[ctx.trait]&&V&&V.tone!=='child') return [pick(TRAITSEEN[ctx.trait],seed)];
  return null;
};

/* word gets about: each thing you did is passed on by at most two people, one at a time, never twice by the same person */
const GOSSIP={
  folk:['Word gets about, you know. They say you {deed}.','I heard something about you at the well. That you {deed}. People talk. I thought you should know what they say.'],
  merchant:['Customers talk. One of them said you {deed}. I said: that sounds like them. I did not say whether I meant it kindly. I am still deciding.'],
  elder:['A little bird told me you {deed}. Old ducks hear everything. We have nothing else to do.'],
  gentle:['Someone came to the temple and said you {deed}. They did not say it to complain. They said it the way you say a thing you cannot stop thinking about.'],
  scholar:['It is in the market ledgers, more or less: you {deed}. I have filed it. I file everything. I have not decided which shelf.'],
  soldier:['The barracks heard you {deed}. Soldiers gossip worse than fishwives. I am only passing it on.'],
  hearth:['Emberwick knows you {deed}. Emberwick knows everything, eventually. It is a small town with a long memory.'],
  road:['The road carries news faster than carts. It says you {deed}.'],
  herald:['Hear ye! It is said that you {deed}! Hear ye further: I was not asked to announce that. I am announcing it to you only.'],
  nervous:['Somebody said you {deed}. I. Is that true? You do not have to say. I just. I wondered.']
};
LV.gossip=function(V,ctx,name,m){
  if(!V||V.tone==='child'||V.tone==='royal') return null;
  const mem=safe(()=>S4st().mem,[])||[]; if(!mem.length) return null;
  const L=(g.story.lv.heard=g.story.lv.heard||{});
  if(m.seen['gossip:'+ctx.ph]) return null;
  for(let i=mem.length-1;i>=Math.max(0,mem.length-6);i--){
    const d=String(mem[i]||''); if(!d) continue;
    const k='g'+LV.strHash(d);
    const who=L[k]||(L[k]=[]);
    if(who.length>=2||who.indexOf(name)>=0) continue;
    if(LV.strHash(name+k)%3===0) continue;   /* not everybody has heard */
    who.push(name); m.seen['gossip:'+ctx.ph]=1;
    const pool=GOSSIP[V.tone]||GOSSIP.folk;
    return [pick(pool,name+k).replace('{deed}',d)];
  }
  return null;
};

/* ======================================================================
   CROWDS, DOORS AND SHOPS THAT MOVE ON
   ====================================================================== */
const SWAPS=[];
const swap=(arr,fn)=>{ if(Array.isArray(arr)) SWAPS.push({arr,orig:arr.slice(),fn}); };
function swapKey(){ const st=g.story||{}, q=st.s2||{}; return LV.phase()+'|'+(!!st.isRed)+'|'+(q.ending||'')+'|'+(q.route||''); }
let lastSwap='';
function applySwaps(){
  const k=swapKey(); if(k===lastSwap) return; lastSwap=k;
  const ctx=LV.ctx();
  for(const s of SWAPS){
    let rep=null; try{ rep=s.fn(ctx,s.orig); }catch(e){ rep=null; }
    const v=rep||s.orig;
    s.arr.length=0; for(const x of v) s.arr.push(x);
  }
}
LV.applySwaps=()=>{ lastSwap=''; applySwaps(); };

/* Emberwick's whispers, for a yellow duck walking its streets */
safe(()=>swap(RED_WHISPERS,(ctx)=>{
  if(ctx.pi<=4) return null;
  if(ctx.ph==='end'&&ctx.ending==='stay') return ['"...the yellow one. Back again..."','"...they say it was there, at the end. At the Tree..."','"...leave it be. It is quiet now. Leave it be..."','"...warm hearth, I suppose..."'];
  if(ctx.pi>=7) return ['"...warm hearth, Detective!..."','"...that is the one. From the lantern..."','"...Mama, Mama, it is the detective!..."','"...he sat with the sleepers. All week..."','"...I will save them a seat at Banking..."','"...yellow. Still yellow. Funny how you stop noticing..."'];
  return ['"...that is the one who went to the Wall..."','"...they say it walked the Lantern Road with the children..."','"...yellow. But not like the banners..."','"...the Elders listen to it. Imagine..."','"...hush. It is looking. Wave, then..."'];
}));
safe(()=>swap(RED_HOUSE_LINES,(ctx)=>{
  if(ctx.pi<=3&&!ctx.red) return null;
  if(ctx.ph==='end'&&ctx.ending==='stay') return ['Nobody answers. Inside, someone is humming the first verse of a lullaby, and stops at the same place every time.','A bowl of ash by the step, the way they leave it for the dawn. The door stays shut, but not, you think, against you.'];
  if(ctx.pi>=7) return ['The door opens before you knock. "Warm hearth! Oh, it is you. Come in, come in. No? Next time, then. There is always a next time now."','A child opens the door, shrieks your name, and runs off to tell someone. The door is left wide open behind her.','A paper charm hangs by the door: a flame in a circle. Under it, newer, a drawing of a yellow feather and a red one, holding wings.','From inside, someone calls: "Is that the detective? Tell them the stew is on!"'];
  if(ctx.red) return ['A curtain twitches, then stays open. Someone inside nods at you. It is a very small nod. It counts.','The door stays shut, but someone inside calls "warm hearth", the way you would to a neighbour.','A bowl of ash sits by the step, the way the red ducks leave it for the dawn. Someone has set a second bowl beside it.'];
  return ['A curtain twitches, and stays open a little longer than it used to.','Inside, someone stops humming. Then, after a moment, starts again.','A paper charm hangs by the door: a flame in a circle. The scrap with the crossed-out yellow feather has been taken down.'];
}));
/* the red shops greet a red duck (or a friend) as one */
safe(()=>{
  const fix=(kind,i,red,late)=>{ const a=GREET[kind]; if(!a) return; const o=a[i]; swap(a,(ctx,orig)=>{ const c=orig.slice(); if(ctx.pi>=7) c[i]=late; else if(ctx.red) c[i]=red; else return null; return c; }); };
  fix('rcafe',1,'Sit anywhere there is room. The stew is the town\'s oldest recipe. You are one of us now. That does not make it any less hot.','Sit anywhere! The stew is the town\'s oldest recipe. Half of Kingsbill has tried it now. Most of them cried. It is the pepper.');
  fix('rloom',1,'Hold still. I measure for red. You are red. Look at that. I did not even have to make an exception.','Hold still. I measure for any feather now. Yellow takes a different thread. I have learned. I am rather proud.');
  fix('rbake',0,'The crust is red. Everything here is red. You have adjusted.','The crust is red. The kingdom buys it by the cartload now. They have adjusted.');
});
/* the kingdom's ducklings and the village ducklings */
safe(()=>swap(KID_KING,(ctx,orig)=>{
  if(ctx.pi<=2) return null;
  const c=orig.slice();
  if(ctx.pi>=7&&!(ctx.ph==='end'&&ctx.ending==='stay')){
    c[0]=ctx.eiderLives?['My da is on guard duty at the castle. He says the king came down to the gate and asked his name. His NAME. Da went red. Not red red. Embarrassed red.']:['My da is on guard duty at the castle. He says the king is gone and nobody is sad in the shouting way. Just in the quiet way.'];
    c[1]=['There is a red girl called Poppy who comes to the fair. Gran says red ducks were a story. I said Gran, she is RIGHT THERE. Gran said "hm".','Gran gave her a pear.'];
    c[5]=['The tower crystal used to go "mmmm". Now it does not go anything. I said the name to it and nothing happened. I was a bit disappointed.'];
  } else if(ctx.pi>=3){
    c[0]=['My da is on guard duty at the castle. He says there is a detective who goes in and out. He says it is you. Is it you? It is you.'];
    c[1]=['Are red ducks real? Everybody says yes now. Even Gran. Gran says it is very inconvenient.'];
  }
  return c;
}));
safe(()=>swap(KID_TALK,(ctx,orig)=>{
  const c=orig.slice();
  if(ctx.pi>=7&&!(ctx.ph==='end'&&ctx.ending==='stay')){
    c[3]=['The big ducks used to say the dark trees hum. They do not hum any more. I put my head on one. Nothing. Just tree. I miss it a bit.'];
    c[10]=['My brother says there is a town of red ducks in a forest that moved. A red family came to our town on their way to the sea. They let me hold their lantern. It was warm.'];
    return c;
  }
  if(ctx.pi>=4){ c[10]=['My brother says the red town is real and there is going to be a war. I said there is not. He said how do you know. I said because you are the detective and you would not let it.','You would not let it. Would you?']; return c; }
  return null;
}));

{
  const _su=storyUpdate;
  storyUpdate=function(dt){ _su(dt); safe(applySwaps); safe(liftBanishment); };
}

/* ---------- a red duck walking into a yellow town ---------- */
{
  const HEADS='Heads turn. A shutter closes. Somebody pulls a child indoors.';
  const _toast=toast;
  toast=function(msg,ms){
    if(msg===HEADS){
      const c=LV.ctx();
      if(c.ph==='end'&&c.ending==='stay') msg='Heads turn, and then turn back. Nobody pulls anyone indoors any more. Nobody quite says hello, either.';
      else if(c.pi>=7) msg=pick(['A few heads turn. Somebody waves. A child runs up to look at your feathers and is not called back.','Heads turn. Somebody says "warm hearth", carefully, the way you say a word in a language you are learning.','Nobody stares. A shopkeeper holds the door. It is such a small thing that it is enormous.'],g.day+'|'+g.clock);
      else if(c.pi>=5) msg='Heads turn. A shutter half closes, then stops. Somebody looks at you as if they have heard your name.';
    }
    return _toast(msg,ms);
  };
}

/* ---------- the runes on Emberwick's gate go out at the end, as the epilogue says they do ---------- */
function liftBanishment(){
  const st=g.story; if(!st||!st.banished) return;
  const q=st.s2; if(!q||!(q.ending||q.ch==='end')) return;
  if(LV.phase()!=='end'&&LV.pi()<7) return;
  st.banished=0; st.castOutSeen=1;
  try{ const A=ART(); if(A) A.readmit=1; }catch(e){}
  try{ tileCache.clear(); }catch(e){}
  setTimeout(()=>{ try{ if(g.mode==='play') toast('Far off, in the Hollow Wood, a ring of red runes goes out. Emberwick\'s gate is open to you.',5200); }catch(e){} },1500);
}

/* ======================================================================
   THE CASTLE, ITS WINDOWS, THE POSTER, THE STATUE
   ====================================================================== */
{
  const KPOST_ID=(typeof KPOSTER!=='undefined')?KPOSTER:null;
  const _ki=kingdomInteract;
  kingdomInteract=function(t,tx,ty){
    try{
      const c=LV.ctx(), stay=c.ph==='end'&&c.ending==='stay', open=c.pi>=7&&!stay;
      if(t===KPORT&&c.pi>=4){
        g.story.castleSeen=1;
        if(stay){ say('Castle Gate',['The great gate of Castle Quackenhold is sealed again. Nobody has put up a notice this time. Nobody needs to.','Behind the bars the corridor is dark. From deep inside, faint and steady, one held note. You know whose it is now.']); return; }
        if(open){ say('Castle Gate',c.eiderLives?['The great gate of Castle Quackenhold stands open. The portcullis is up, and somebody has hung a basket of red Hearthblooms from it.','A guard on each side. Both of them are trying, without much success, not to smile at you.']:['The great gate of Castle Quackenhold stands open. The portcullis is up. Inside, the corridor is full of ordinary daylight.','Somebody has chalked a small lantern on the gatepost, and under it: "He held it shut so we could open it."']); return; }
        say('Castle Gate',['The great gate is shut. The notice is still nailed to the post, but somebody has crossed out "NO VISITORS" and written, very small, "ask the Captain".','You know now what is behind it: not a sleeping king. A king holding a door.']); return;
      }
      if(t===KCWIN&&c.pi>=7){
        say('',[stay?'A narrow castle window. Blue light behind it, steady as a held breath.':pick(['A narrow castle window. Somebody has put a pot of red Hearthblooms on the sill.','You stand on tiptoes. A shadow in the glass looks right back. It is somebody inside, waving. You wave back.','The window is open. You can hear somebody inside arguing, very cheerfully, about soup.'],tx+','+ty+'|'+g.day)]); return;
      }
      if(KPOST_ID!==null&&t===KPOST_ID&&c.pi>=5){
        g.story.posterSeen=1;
        if(stay){ say('Royal Notice',['The old reward notice has faded nearly to nothing. You can make out "300" and "red", and the rest is weather.']); return; }
        if(open){ say('Notice',['THE LANTERN ROAD. Open from dawn to dusk, and after dusk to anyone with a lantern. Travellers of every feather welcome.','Underneath, in a child\'s hand: "AND DUCKLINGS".','The old reward notice is pinned beneath it, face to the wall.']); return; }
        say('Royal Notice',['The reward poster has been torn down. Only the corners are left, under the nails.','Someone has written on the wall where it hung: "Who were we going to pay to find?"']); return;
      }
    }catch(e){ console.warn('lives world',e); }
    _ki(t,tx,ty);
  };
}
{
  const _ks=kStatue;
  kStatue=function(tx,ty){
    try{
      const c=LV.ctx(), lx=tx-KX, ly=ty-KY;
      if(Math.abs(lx)===14&&ly===12&&c.pi>=7){
        const stay=c.ph==='end'&&c.ending==='stay';
        const tail=stay?'Somebody has set a candle at the foot of it. It is lit every night. Nobody will say by whom.'
          :c.eiderLives?'Somebody has hung a scarf round its neck. Under the plaque, in fresh chalk: "And is paying it back."'
          :'Under the plaque, newly cut: "He kept his word a hundred years. Somebody else said it for him at the end."';
        say('',['A golden duck in a regal pose. The plaque reads: "KING EIDER THE WISE. He who saved Mallardia with a single word."','Below, in smaller letters: "And paid for it."',tail]); return;
      }
    }catch(e){}
    _ks(tx,ty);
  };
}
})();
