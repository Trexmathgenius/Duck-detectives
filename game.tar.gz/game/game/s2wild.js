'use strict';
/* ===== THE LONG ROAD, IN THE WILD (v1.17) =====
   Joins the Story II campaign (chapters 5 to 20) to the 1.16 wilderness systems.
   - The Burnt Wood and the lands the ward touches now hold EMBER finds and Ember Essence for you to forage.
   - Five new finds live in the Collection Log. Four story potions are brewed in the Recipe Book.
   - A herbalist (Yarrow in Emberwick, Marjoram in Kingsbill) gives one commission each act. They use the pack, the satchel,
     the Collection Log, the hotbar and the Recipe Book, and they pay in crumbs, standing and goodwill.
   - The Keeper's Lantern, the Case Board and the new Ward-Lens are hotbar tools. Hold them and they do something.
   - A Hearthward potion calms the ward's hum and sharpens your eye for Ember finds.
   - The journal gains Field Notes, and the ending gains an epilogue line. */

/* ---------------- state ---------------- */
function SWS(){
  const q=s2(); if(!q.w) q.w={c:{},ember:0,found:0,drank:0};
  return q.w;
}
const swStarted=()=>!!(g.story&&g.story.s2&&g.story.s2.ch);
const swChNum=()=>{ const c=s2cur(); return c?s2num(c):0; };
const swPast=n=>swChNum()>=n;

/* ---------------- Ember finds (they join the Collection Log) ---------------- */
const SW_FINDLIST=[
 ['s_cinderbloom','Cinderbloom',14,'petal',['#ff7a3a','#a8301a','#ffd0a0'],'A flower that grew out of the ash and kept some of it. It is warm to hold, and it has never wilted.'],
 ['s_ashglass','Ashglass Shard',18,'shard',['#7a64a8','#2a2040','#d0c0ff'],'Glass the fire made out of sand and grief. Held slantwise, it shows a hearth that is not there.'],
 ['s_hummoss','Hum-Moss',12,'sachet',['#6a8a58','#364a30','#c8e0b0'],'A pad of moss that hums very faintly when the ward does. It is the quietest instrument in the world.'],
 ['s_keeperpin','Keeper\'s Pin',22,'pin',['#e0b84a','#8a6a1a','#fff0b0'],'A pin in the shape of a flame. A Keeper wore one once, and lost it somewhere in the wood.'],
 ['s_hearthember','Hearth-Ember',26,'orb',['#ff9d2e','#c0392b','#fff0b0'],'A coal that has not gone out in a hundred years and is not in the least bothered about it.']
];
WL_FINDS_BY.story=[];
WL_BY.story={id:'story',name:'Burnt Wood and the ashlands around it',sps:[],finds:[]};
for(const f of SW_FINDLIST){
  const it=ITEMS[f[0]]={name:f[1],sell:f[2],desc:f[5],use:'note',note:'It is warm. Warmer than the rest of you.',nogift:true,glyph:f[3],gc:f[4],cat:'find',src:'story',night:false,day:false};
  it.rar=f[2]<15?2:f[2]<24?3:4;
  WL_FIND[f[0]]=it; WL_FINDS_BY.story.push(f[0]);
}
const SW_FINDIDS=SW_FINDLIST.map(f=>f[0]);
FXD.s_cinderbloom='glow300 luck2'; FXD.s_ashglass='glow600'; FXD.s_hummoss='forage3'; FXD.s_keeperpin='rep1'; FXD.s_hearthember='glow900 speed40';
for(const id of SW_FINDIDS){ FXP[id]=brFxParse(FXD[id]); ITEMS[id].desc+=' Use it: '+fxSummary(FXP[id])+'.'; }

/* ---------------- the Ward-Lens (a reward you hold) ---------------- */
ITEMS.wardlens={name:'Ward-Lens',desc:'A disc of Ashglass in a brass ring. Hold it (put it on your hotbar and select it) and Ember finds come to you far more often. It also makes the ward\'s hum look like a pattern instead of a threat.',use:'note',note:'Through the lens, the air in the Burnt Wood is full of threads, all pulled the same way. You are not afraid of them. That is new.',nogift:true,glyph:'orb',gc:['#7a64a8','#2a2040','#d0c0ff']};
ITEMS.s_kettle={name:'The Last Kettle',sell:0,desc:'A small copper kettle, dented, with a handle wrapped in red thread (or gold, depending whose it was). It is always just warm enough.',use:'note',note:'You pour a cup of nothing and it smells of every hearth you have stood beside.',nogift:true,glyph:'bottle',gc:['#c98a4a','#7a4a1a','#ffe0b0']};
HB_AUTO.push('keeperlantern','wardlens','caseboard');

/* ---------------- Ember Essence and the story potions ---------------- */
BR_ESS.ember='Ember';
Object.assign(FX_NAMES,{ward:'Hearthward'});
Object.assign(FX_TEXT,{ward:'the ward\'s hum is calm, and Ember finds come more often'});
{
  const _fxs=fxSummary;
  fxSummary=function(list){
    let s=_fxs(list);
    for(const e of list) if(e.k==='ward') s=(s?s+', ':'')+'Hearthward for '+e.a+'h (the ward\'s hum is calm and Ember finds come more often)';
    return s;
  };
  const _bb=brBrief;
  brBrief=function(list){
    let s=_bb(list);
    for(const e of list) if(e.k==='ward') s=(s?s+', ':'')+'Hearthward '+e.a+'h';
    return s;
  };
  const _fa=fxApply;
  fxApply=function(id,list){
    const ok=_fa(id,list);
    if(ok){
      let any=false; for(const e of list) if(e.k==='ward'){ fxGive('ward',e.a); any=true; }
      if(any){ el.dNote.textContent=(el.dNote.textContent+' Hearthward.').trim(); if(swStarted()) SWS().drank++; }
    }
    return ok;
  };
}
const SW_RECIPES=[
 {id:'hearthward',name:'Hearthward Tonic',tier:1,req:[['e:ember',1],['flower',2]],cost:20,fx:'ward6 glow600',col:['#ff9d2e','#c0392b','#fff0b0'],
  desc:'Brewed for the Wardens of Emberwick, and for anyone who has to walk toward a hum. The ward\'s whisper goes calm for six hours.'},
 {id:'keepercordial',name:'Keeper\'s Cordial',tier:1,req:[['e:ember',2],['tree',1,1]],cost:30,fx:'ward8 charm5 rep1',col:['#e0b84a','#8a6a1a','#fff6c8'],
  desc:'Resin, ember and manners. Warm to the throat, and shopkeepers think you are someone important for a while.'},
 {id:'wakingtea',name:'Waking Tea',tier:1,req:[['e:ember',1],['mush',2,1]],cost:26,fx:'ward4 luck3 glow900',col:['#c8a8e0','#6a4a98','#f6e8ff'],
  desc:'For the ones who sleep too deeply, and the ones who sit beside them. Smells of toast and the first bird.'},
 {id:'quietdraught',name:'Quiet Draught',tier:2,req:[['e:ember',2],['flower',1,2],['stump',1,1]],cost:60,fx:'ward10 luck6 rep2',col:['#8aa8ff','#4a3a98','#f0e8ff'],
  desc:'The last recipe, and the only one that tastes of nothing at all. It is the taste of a held breath being let go.'}
];
for(const r of SW_RECIPES){
  BR_RECIPES.push({id:r.id,name:r.name,tier:r.tier,req:r.req.map(q=>({c:q[0],n:q[1],g:q[2]||0})),cost:r.cost,fx:r.fx,col:r.col,desc:r.desc});
  const id='p_'+r.id, list=brFxParse(r.fx);
  FXD[id]=r.fx; FXP[id]=list;
  ITEMS[id]={name:r.name,price:0,cat:'potion',desc:r.desc+' Use it: '+fxSummary(list)+'.',use:'note',note:'',nogift:true,glyph:'flask',gc:r.col};
}

/* ---------------- foraging in the ashlands ---------------- */
/* 2 = in or near the Burnt Wood, 1 = in the kingdom or Emberwick (the ward's reach), 0 = elsewhere */
function swZone(){
  if(!swStarted()||g.scene!=='world') return 0;
  const p=s2tile(), m=18;
  if(p.x>=BW.x0-m&&p.x<=BW.x1+m&&p.y>=BW.y0-m&&p.y<=BW.y1+m) return 2;
  if(inK(p.x,p.y)||inRed(p.x,p.y)) return 1;
  return 0;
}
function swEmberChance(){
  const z=swZone(); if(!z) return 0;
  let p=z===2?0.14:0.04;
  p*=1+0.15*s2ward();
  if(fxLeft('ward')>0) p*=1.6;
  if(isHeld('keeperlantern')) p*=1.35;
  if(isHeld('wardlens')) p*=1.8;
  return Math.min(0.6,p);
}
function swEmberRoll(){
  const p=swEmberChance(); if(p<=0||rnd()>=p) return;
  const w=SWS();
  if(rnd()<0.5){
    BS().ess.ember=(BS().ess.ember||0)+1; w.ember++;
    toast('A drop of Ember Essence gathers where you worked. (Ember Essence: '+BS().ess.ember+')',3800); coin();
  } else {
    const id=SW_FINDIDS[Math.floor(rnd()*SW_FINDIDS.length)];
    const first=wlPlace(id,1,true); w.found++;
    toast('Ember find: a '+ITEMS[id].name+'!'+(first&&g.inv.clog?' (New in your Collection Log.)':''),4200); coin();
  }
}
{
  const _wf=wlForage;
  wlForage=function(tg){
    const n0=WD().stats.forage||0;
    _wf(tg);
    if((WD().stats.forage||0)>n0) swEmberRoll();
  };
}

/* ---------------- the ward's hum, calmed ---------------- */
const SW_CALM=['The hum is still there. It is only a hum.','You can hear the ward, and you are not afraid of it.','Somewhere under the ground, something very old is breathing slowly. You breathe with it.','The candle flames lean north-west. You lean the other way, politely.'];
{
  const _swu=s2wardUpdate;
  s2wardUpdate=function(dt){
    if(fxLeft('ward')<=0){ _swu(dt); return; }
    const st=s2ward(); if(!st||st>5||g.scene!=='world'||g.mode!=='play') return;
    S2.hum-=dt; if(S2.hum>0) return; S2.hum=70+Math.random()*40;
    const p=s2tile(); if(!(inK(p.x,p.y)||inBW(p.x,p.y)||inRed(p.x,p.y))) return;
    toast(pick(SW_CALM),3800);
  };
}

/* ---------------- the Keeper's Lantern, held ---------------- */
{
  const _u=useItem;
  useItem=function(id){
    if(id==='keeperlantern'&&swStarted()){
      if(!isHeld(id)){ el.dNote.textContent=holdText(id); blip(); return; }
      const p=s2tile(), cx=(BW.x0+BW.x1)/2, cy=(BW.y0+BW.y1)/2, dx=cx-p.x, dy=cy-p.y, d=Math.round(Math.hypot(dx,dy));
      el.dNote.textContent=(d<30)
        ?'The flame stands straight up, bright and quite still. You are inside the Burnt Wood. Ember finds come to a held lantern.'
        :'The flame leans '+wlDir(dx,dy)+' '+wlArrow(dx,dy)+'. The Burnt Wood is about '+d+' waddles away.';
      return;
    }
    _u(id);
  };
}

/* ---------------- the herbalists ---------------- */
const SW_NPC={
  red:{name:'Herbalist Yarrow',pos:{red:[27,32]},pal:2,head:'cap',neck:'scarf',home:'Emberwick',
    open:'Yarrow wipes her wings on an apron the colour of old embers. Her stall smells of woodsmoke and thyme.',
    side:'the Wardens'},
  crown:{name:'Herbalist Marjoram',pos:{k:[-9,30]},pal:5,head:'bow',neck:null,home:'Kingsbill',
    open:'Marjoram looks up from a mortar. Her stall is the only one in Kingsbill that smells of anything, which she considers a political position.',
    side:'the Watch'}
};
function swRt(){ return s2red()?'red':'crown'; }
function swBoost(n){ const rt=swRt(); if(rt==='red'){ addRep(getRed(),n); s2led('ember',1); } else { s2led('crown',1); } }

const SWC=[
 {n:1,at:5,title:'A Tonic for the Road',
  offer(N){ return [
    'You are the one the town is whispering about. Good. I need someone the whispers have not worn out yet.',
    'The ward hums, and people are starting to hear it. I cannot make the hum stop. I can make it bearable. There is a tonic, and the recipe is old, and the missing piece is Ember.',
    'Ember is what the ash keeps: a drop of it, left on whatever you gather in the Burnt Wood and in the lands the ward leans on. Forage there. Flowers, mostly. Bring two flowers and a drop of Ember to the Recipe Book, brew me a Hearthward Tonic, and bring it here.',
    'Here. You will need the tools, and the book, and something to write the finds in. I would rather you took them than listened to me explain where shops are.'];},
  gift(){ const out=[]; for(const [id,txt] of [['recipebook','a Brewer\'s Recipe Book (press B)'],['clog','a Collection Log (press L)'],['axe','an axe'],['pickaxe','a pickaxe'],['shovel','a shovel']]) if(!g.inv[id]){ addItem(id); out.push(txt); } return out; },
  need:'p_hearthward', count:1, label:'1 Hearthward Tonic',
  hint:'Forage flowers in the Burnt Wood or the kingdom for Ember Essence and petals. Open the Recipe Book (B) and brew a Hearthward Tonic.',
  thanks(N){ return ['It is the right colour. It is the right smell. It is, I will admit, slightly better than mine.','Drink one before you go anywhere quiet. The ward will still hum. It will simply stop talking to you personally.'];},
  pay(){ g.crumbs+=40; swBoost(3); coin(); return '+40 crumbs and standing.'; }},
 {n:2,at:9,title:'What the Fire Left',
  offer(N){ return [
    'Now you are going where the hum comes from, I would like something back from it.',
    'The Burnt Wood leaves things. Cinderblooms, Ashglass, Hum-Moss, a Keeper\'s Pin if you are lucky. Five kinds of find. They turn up when you forage there, more often at night, and a good deal more often if you hold the Keeper\'s Lantern.',
    'Bring me three different kinds. I will not sell them. I will read them. The wood is writing something and I would like to see the handwriting.'];},
  need:'finds3', count:3, label:'3 different Ember finds',
  hint:'Forage in or near the Burnt Wood. Put the Keeper\'s Lantern on your hotbar and hold it for better luck. The Collection Log lists the five Ember finds.',
  thanks(N){ return ['Ashglass and Hum-Moss and a pin. Of course. Of course it is a pin.','Hm. The wood is not angry. It is... filing things. Cataloguing.','Take this lens. I ground it from the oldest Ashglass I had. Hold it, and the wood shows you what it is leaving.'];},
  pay(){ g.crumbs+=50; addItem('wardlens'); swBoost(2); coin(); return 'The Ward-Lens is in your pack. Put it on your hotbar and hold it.'; }},
 {n:3,at:13,title:'Tea for the Sleepers',
  offer(N){ return [
    'You have heard about the Sleepers. Everyone has, now that someone has said the name aloud.',
    'I cannot wake them. I would not know how. But I can make a thing that is gentle to the ones sitting beside them, and to the ones who have to be awake for a long time.',
    'Waking Tea. A drop of Ember and two Choice mushroom caps (or better). Two cups. One for the vigil, one for whoever relieves it.'];},
  need:'p_wakingtea', count:2, label:'2 Waking Teas',
  hint:'Waking Tea needs 1 Ember Essence and 2 Choice (or better) mushroom parts. Glimmer Caps come from uncommon mushrooms.',
  thanks(N){ return ['Toast and the first bird. Yes. That is it exactly.','I shall take these to the vigil myself. I will not say who they are from. They will drink them anyway; they are very tired.'];},
  pay(){ g.crumbs+=80; s2led('mercy',1); swBoost(3); coin(); return '+80 crumbs, and the quiet satisfaction of a kindness done.'; }},
 {n:4,at:17,title:'The Last Kettle',
  offer(N){ return [
    'Last one. I have only ever tried to make it once, and I put it down the sink.',
    'A Quiet Draught is not a cure and not a weapon. It is a thing you drink before you go into the quiet, so you do not take the hum in with you. Two Ember, a Prime flower, a Choice stump. Prime flowers are rare. Look in strange places.',
    'Bring it to me and I will pour the first cup myself. Then I will give you my kettle. I am done with it, I think. Or it is done with me.'];},
  need:'p_quietdraught', count:1, label:'1 Quiet Draught',
  hint:'Quiet Draught needs 2 Ember Essence, 1 Prime flower part (from a Rare or better flower) and 1 Choice stump part.',
  thanks(N){ return ['...Oh.','It tastes of nothing. It tastes of nothing so thoroughly that I can hear my own heart for the first time since spring.','Take the kettle. It is not magic. It is just always warm. Those are different, and the second is rarer.'];},
  pay(){ g.crumbs+=150; addItem('s_kettle'); s2led('mercy',2); swBoost(5); SWS().epi=1; coin(); return 'You are given The Last Kettle. You are thanked properly, which is rarer than the kettle.'; }}
];
function swHave(c){
  if(c.need==='finds3') return SW_FINDIDS.filter(id=>g.inv[id]>0).length;
  return g.inv[c.need]||0;
}
function swReady(c){ return swHave(c)>=c.count; }
function swTake(c){
  if(c.need==='finds3'){ let n=0; for(const id of SW_FINDIDS){ if(n>=3) break; if(g.inv[id]>0){ delInv(id); n++; } } }
  else for(let i=0;i<c.count;i++) delInv(c.need);
}
function swState(c){ return SWS().c[c.n]||0; }
function swAvail(c){ return swPast(c.at); }
function swNextOpen(){ return SWC.find(c=>swAvail(c)&&swState(c)<2&&!c.opt)||SWC.find(c=>swAvail(c)&&swState(c)<2); }

function swTalk(n,done,rt){
  const N=SW_NPC[rt], who=N.name, w=SWS();
  const open=SWC.filter(swAvail);
  const cur=open.find(c=>swState(c)<2&&!c.opt);
  const sides=open.filter(c=>c.opt&&swState(c)<2);
  const opts=[], fns=[];
  const work=c=>{
    const st=swState(c), tag=c.opt?'[Side work] ':'';
    if(st===0){ opts.push(tag+'Ask about the work'+(c.opt?': '+c.title:'')); fns.push(()=>{
      say(who,c.offer(N),()=>{
        const gifts=c.gift?c.gift():[];
        w.c[c.n]=1; hudCache.obj=null; coin();
        const after=()=>{ toast('Commission taken: '+c.title+'.',3600); done(); };
        if(gifts.length) say('',[N.name.replace('Herbalist ','')+' is already pressing things into your wings: '+gifts.join(', ')+'.'],after); else after();
      }); }); }
    else if(swReady(c)){ opts.push(tag+'Hand over: '+c.label); fns.push(()=>{
      swTake(c); w.c[c.n]=2; hudCache.obj=null;
      say(who,c.thanks(N),()=>{ const m=c.pay(); say('',[m],()=>{ toast('Commission done: '+c.title+'.',3600); done(); }); }); }); }
    else { opts.push(tag+'How is the work going? ('+c.label+': '+swHave(c)+'/'+c.count+')'); fns.push(()=>say(who,['The work is: '+c.title+'. I need '+c.label+' ('+swHave(c)+' so far).',c.hint],done)); }
  };
  if(cur) work(cur);
  for(const c of sides) work(c);
  opts.push('Ask about foraging and brewing'); fns.push(()=>{
    const tips=[];
    if(!g.inv.axe||!g.inv.pickaxe) tips.push('Trees and stumps need an axe, rocks need a pickaxe. A toolshed or a supply shop will sell you both.');
    if(!g.inv.recipebook) tips.push('A Brewer\'s Recipe Book comes from a brewery. Press B once you have it.');
    tips.push('Every plant you gather leaves an ingredient in your satchel. Rarer plants leave finer ones, and some leave a drop of Essence.');
    tips.push('Ember Essence comes from foraging in the Burnt Wood and the lands the ward leans on. Hold the Keeper\'s Lantern (put it on your hotbar, press its number) and the Ember comes to you.');
    tips.push('Ember so far: '+(BS().ess.ember||0)+' Essence in your satchel. Finds: '+SW_FINDIDS.filter(id=>WD().got[id]).length+'/'+SW_FINDIDS.length+' in your Collection Log.');
    say(who,tips,done); });
  if(typeof deepLeft==='function'&&swPast(9)&&deepLeft(who)>0){ opts.push('Ask about '+(rt==='red'?'her':'her')+' life'); fns.push(()=>deepTalk(null,done,who)); }
  opts.push('Just talk'); fns.push(()=>{
    const ward=s2ward();
    const lines=[
      ['Quiet in the stall today. Quiet is rare. I am trying not to notice it.'],
      ['The sage has gone strange. It grows toward the north-west now, all of it, like a field of small green compasses.'],
      ['I had a customer who could not sleep. Then a customer who could not wake. I would rather have the first one back.'],
      ['The herbs know before we do. Mine have been leaning for a month. Today they are bowing.'],
      ['Whatever happens, ducks will want tea afterwards. I intend to be open.'],
      ['There is nothing left to say, and I find I am quite comfortable with that.']][Math.min(5,ward)];
    say(who,[N.open].concat(lines),done); });
  opts.push('Leave'); fns.push(done);
  choose(who,N.open,opts,k=>fns[k](),opts.length-1);
}
function swMark(){
  const c=swNextOpen(); if(!c) return null;
  const st=swState(c);
  if(st===0) return '!'; if(swReady(c)) return '?'; return null;
}
for(const rt of ['red','crown']){
  const N=SW_NPC[rt];
  const d={id:'herb_'+rt,name:N.name,pal:N.pal,head:N.head,neck:N.neck,still:true,
    when:()=>swStarted()&&swChNum()>=5&&s2route()===rt,
    mark:()=>swMark(),
    talk(n,done){ swTalk(n,done,rt); }};
  Object.assign(d,N.pos);
  S2.npc(d);
}

/* ---------------- objective hint, journal, epilogue ---------------- */
{
  const _so=storyObjective;
  storyObjective=function(){
    const o=_so();
    if(!swStarted()) return o;
    const c=swNextOpen();
    if(c&&swState(c)===1&&typeof o==='string'&&(o.indexOf('Ch ')>=0||o.indexOf('Quiet hour:')>=0)&&o.length<260){
      const N=SW_NPC[swRt()];
      return o+'  <span style="opacity:.75">[Side: '+c.title+' for '+N.name.replace('Herbalist ','')+': '+swHave(c)+'/'+c.count+']</span>';
    }
    if(typeof o==='string'&&o.indexOf('The door is open')===0&&SWS().epi) return o+' (A kettle somewhere is always just warm enough.)';
    return o;
  };
  const _je=journalExtra;
  journalExtra=function(sec,line){
    _je(sec,line);
    if(!swStarted()) return;
    const w=SWS();
    sec('Field Notes');
    const N=SW_NPC[swRt()];
    for(const c of SWC){
      if(!swAvail(c)) continue;
      const st=swState(c);
      line((st===2?'[done] ':st===1?'[open] ':'[new]  ')+c.title+' ('+N.name+')'+(st===1?': '+swHave(c)+'/'+c.count+' '+c.label:st===0?': go and ask.':''),st===2?'jdim':undefined);
    }
    line('Ember Essence in the satchel: '+(BS().ess.ember||0)+'.  Ember finds in the log: '+SW_FINDIDS.filter(id=>WD().got[id]).length+'/'+SW_FINDIDS.length+'.',w.ember+w.found?undefined:'jdim');
    const made=['hearthward','keepercordial','wakingtea','quietdraught'].map(id=>(BS().made[id]||0)).reduce((a,b)=>a+b,0);
    if(made) line('Story potions brewed: '+made+'.  Held tools: the Keeper\'s Lantern'+(g.inv.wardlens?', the Ward-Lens':'')+'.','jdim');
  };
}
