'use strict';
/* ===== SIDE QUESTS FOR THE ROAD'S REQUESTS =====
   Some answers to a request ("dig the field for it", "carry water", "sit up the night") used to be a menu line that
   skipped the hours. They are now real:
     - WORK quests send you out into the world: dig-spots to search (hot and cold), a shuttle between a source and the
       person (water, sandbags), a patch of things to gather. Every action spends game time, so the quest takes about as long
       as the option says.
     - TALK quests are a sitting-with: a few beats of real conversation, each with things you can say. What you say moves
       the ledger (truth, mercy, pride, trust, kin...) and the factions.
   When it is done the answer is applied exactly as before (same rewards, same memories, same later visits).
   Progress is kept on the request's own save entry (st.sq), so it survives a save.
   Content: s15talk.js (conversations), s15work.js (searches and trips). */
(function(){
'use strict';
const D10=window.D10=window.D10||{};
const DEF={};
const SQ=window.SQ={ def(key,d){ DEF[key]=d; }, DEF };
const RS=()=>D10.reqState();
const KEY=(r,o)=>r.id+'.'+o.flag;
SQ.has=(r,o)=>!!DEF[KEY(r,o)];
SQ.tag=(r,o)=>{ const d=DEF[KEY(r,o)]; return d&&d.night?'  (a task, after dark)':'  (a task)'; };

/* ---------- the one active quest ---------- */
function act(){
  const S=RS(); if(!S) return null;
  for(const id in S){ const st=S[id]; if(st&&st.sq){ if(st.st!=='open'){ delete st.sq; continue; } return {id,st,sq:st.sq,r:D10.reqGet(id),d:DEF[st.sq.key]}; } }
  return null;
}
SQ.active=act;

/* ---------- little helpers ---------- */
const nm=(r,w)=>w==='@'?r.who[0]:w;
const play=(r,list,cb)=>seq(list.map(x=>[nm(r,x[0]),x[1]]),cb);
function fx(f){
  if(!f) return;
  for(const k in (f.led||{})) s2led(k,f.led[k]);
  for(const k in (f.cap||{})) S6.cap(k,f.cap[k]);
  if(f.habit){ const h=S4st().h; h[f.habit]=(h[f.habit]||0)+1; }
}
function rng(seed){ let s=seed>>>0||1; return ()=>{ s=(Math.imul(s,1664525)+1013904223)>>>0; return s/4294967296; }; }
function hash(str){ let h=2166136261; for(let i=0;i<str.length;i++){ h^=str.charCodeAt(i); h=Math.imul(h,16777619); } return h>>>0; }
const DIRS=['east','south-east','south','south-west','west','north-west','north','north-east'];
const dirOf=(dx,dy)=>DIRS[((Math.round(Math.atan2(dy,dx)/(Math.PI/4))%8)+8)%8];
function okT(x,y){ try{ const t=tileAt(x,y); return !SOLID.has(t)&&t!==T.WATER&&!solidTile(x,y); }catch(e){ return false; } }
/* the tiles a duck can actually walk to from a point (so nothing is placed in a sealed-off pocket) */
let REACH=null;
function reachFrom(cx,cy,R){
  const seen=new Set([cx+','+cy]), q=[[cx,cy]];
  while(q.length){ const [x,y]=q.shift(); for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){ const nx=x+dx, ny=y+dy, k=nx+','+ny; if(seen.has(k)||Math.abs(nx-cx)>R||Math.abs(ny-cy)>R||!okT(nx,ny)) continue; seen.add(k); q.push([nx,ny]); } }
  return seen;
}
const reach=(x,y)=>!REACH||REACH.has(x+','+y);
/* n walkable tiles around a point, spread out from each other */
function scatter(cx,cy,n,rmin,rmax,seed,gap){
  const R=rng(seed), out=[]; let tries=0;
  while(out.length<n&&tries<900){
    tries++;
    const grow=Math.floor(tries/200)*4, a=R()*6.2832, d=rmin+R()*(rmax+grow-rmin);
    const x=Math.round(cx+Math.cos(a)*d), y=Math.round(cy+Math.sin(a)*d);
    if(!okT(x,y)||!reach(x,y)) continue;
    if(Math.abs(x-cx)<2&&Math.abs(y-cy)<2) continue;
    if(out.some(p=>Math.abs(p[0]-x)<(gap||3)&&Math.abs(p[1]-y)<(gap||3))) continue;
    out.push([x,y]);
  }
  return out;
}
/* a walkable tile beside water, within reach of a point (or just a far-off tile if there is no water about) */
function waterSpot(cx,cy,seed){
  let best=null;
  for(let r=8;r<=46&&!best;r+=2){
    for(let k=0;k<40&&!best;k++){
      const a=(k/40)*6.2832+seed*0.01, x=Math.round(cx+Math.cos(a)*r), y=Math.round(cy+Math.sin(a)*r);
      let w=false; try{ w=tileAt(x,y)===T.WATER||tileAt(x+1,y)===T.WATER||tileAt(x-1,y)===T.WATER||tileAt(x,y+1)===T.WATER||tileAt(x,y-1)===T.WATER; }catch(e){}
      if(w&&okT(x,y)&&reach(x,y)) best=[x,y];
    }
  }
  return best;
}

/* ---------- the world props (a small pool, moved to wherever the quest needs them) ---------- */
const POOL=12;
function setProp(i,xy){ const d=S2.props.get('sqp'+i); if(!d) return; d.wx=xy[0]; d.wy=xy[1]; d._r=0; d.key=null; }
PGLYPH.furrow=(c,x,y,col,t)=>{
  ell(c,x+16,y+25,12,5,'rgba(0,0,0,0.22)');
  if(col==='dug'){ ell(c,x+16,y+22,10,4,'#2a1c10'); ell(c,x+16,y+21,8,3,'#3d2a18'); return; }
  c.fillStyle='#6b4a2a'; c.beginPath(); c.ellipse(x+16,y+21,12,6,0,0,6.3); c.fill();
  c.fillStyle='#8a6a40'; c.beginPath(); c.ellipse(x+14,y+19,8,3.4,0,0,6.3); c.fill();
  rect(c,x+9,y+20,2,2,'#4a3320'); rect(c,x+19,y+22,3,2,'#4a3320');
  const a=0.5+0.5*Math.sin(t*3); circ(c,x+16,y+12,8+2*a,'rgba(255,220,140,'+(0.10+0.08*a).toFixed(2)+')');
};
PGLYPH.herb=(c,x,y,col,t)=>{
  ell(c,x+16,y+26,9,3,'rgba(0,0,0,0.2)');
  c.strokeStyle='#4a8a3a'; c.lineWidth=2;
  for(let i=-2;i<=2;i++){ c.beginPath(); c.moveTo(x+16+i*2,y+26); c.quadraticCurveTo(x+16+i*5,y+16,x+16+i*6,y+9+Math.abs(i)*2+Math.sin(t*2+i)*1.2); c.stroke(); }
  circ(c,x+16,y+11,5,'rgba(190,255,150,0.25)');
  circ(c,x+22,y+9,2.5,'#e8d36a'); circ(c,x+10,y+11,2.5,'#e8d36a');
};
PGLYPH.bucketspot=(c,x,y,col,t)=>{
  ell(c,x+16,y+26,12,4,'rgba(60,110,170,0.35)');
  rect(c,x+9,y+14,14,12,'#8a6a45'); rect(c,x+9,y+17,14,2,'#5a3f22'); rect(c,x+9,y+23,14,2,'#5a3f22');
  c.strokeStyle='#5a3f22'; c.lineWidth=1.5; c.beginPath(); c.arc(x+16,y+14,7,3.14,6.28); c.stroke();
  const a=Math.sin(t*3); circ(c,x+16,y+12,3,'rgba(120,180,240,'+(0.35+0.15*a).toFixed(2)+')');
};
PGLYPH.sandbags=(c,x,y,col,t)=>{
  ell(c,x+16,y+27,13,4,'rgba(0,0,0,0.25)');
  const bag=(bx,by)=>{ c.fillStyle='#b59a6a'; c.beginPath(); c.ellipse(bx,by,7,4,0,0,6.3); c.fill(); c.fillStyle='#8f7a50'; c.fillRect(bx-1,by-4,2,3); };
  bag(x+10,y+23); bag(x+22,y+23); bag(x+16,y+17);
};
function propOn(i){
  const A=act(); if(!A||!A.d) return false;
  const sq=A.sq, k=A.d.kind;
  if(k==='dig'||k==='gather') return !!sq.spots&&i<sq.spots.length&&!(k==='gather'&&sq.dug[i]);
  if(k==='shuttle') return i===0&&!!sq.src;
  return false;
}
for(let i=0;i<POOL;i++){
  S2.prop({id:'sqp'+i,wx:0,wy:0,snap:0,glyph:'furrow',
    colf:()=>{ const A=act(); if(!A) return null; const k=A.d&&A.d.kind; if(k==='dig') return A.sq.dug[i]?'dug':null; return null; },
    when:()=>propOn(i),
    mark:()=>{ const A=act(); if(!A) return null; const k=A.d.kind; if(k==='dig') return A.sq.dug[i]?null:'!'; if(k==='shuttle') return A.sq.carry?null:'!'; return '!'; },
    use(){ spotUse(i); }});
}
/* glyph follows the quest's flavour */
{
  const _g={};
  for(let i=0;i<POOL;i++){ const d=S2.props.get('sqp'+i); Object.defineProperty(d,'glyph',{get(){ const A=act(); return (A&&A.d&&A.d.glyph)||'furrow'; },set(v){},configurable:true}); }
}

/* ---------- starting a quest ---------- */
SQ.begin=function(r,o,done){
  const key=KEY(r,o), d=DEF[key], st=RS()[r.id];
  const A=act();
  if(A&&A.id!==r.id){ say('',['You already have a promise to keep for '+A.r.who[0]+'.','Finish it, or tell them you cannot, before you take on another.'],()=>done()); return; }
  st.sq={key,kind:d.kind,ready:0,n:0};
  hudCache.obj=null;
  if(d.kind==='talk'){
    const W=r.who[0];
    if(d.night&&g.clock>=6&&g.clock<20){ delete st.sq; say(W,['"It has to be the night itself. Come back after dark, and we will do it properly."','(Talk to them again once the sun has gone down.)'],()=>done()); return; }
    const fin=()=>{ delete st.sq; D10.reqComplete(r,o,done); };
    seq([[W,d.open||[]]].filter(x=>x[1].length),()=>runBeats(r,d,fin));
    return;
  }
  const lines=d.intro||[];
  const go=()=>{ SQ.setup(r,d,st.sq); toast(d.start||'A task: '+d.title,4200); done(); };
  if(lines.length) seq([[r.who[0],lines]],go); else go();
};
SQ.setup=function(r,d,sq){
  const xy=RS()[r.id].xy||[Math.floor(g.px/TS),Math.floor(g.py/TS)], seed=hash(r.id+d.kind+g.day);
  sq.home=xy; REACH=reachFrom(xy[0],xy[1],42); if(REACH.size<60) REACH=null;
  if(d.kind==='dig'){
    sq.spots=scatter(xy[0],xy[1],d.spots||10,5,13,seed,3); sq.dug=sq.spots.map(()=>0);
    sq.target=Math.floor(rng(seed+7)()*sq.spots.length);
  } else if(d.kind==='gather'){
    sq.spots=scatter(xy[0],xy[1],d.spots||6,6,15,seed,4); sq.dug=sq.spots.map(()=>0);
  } else if(d.kind==='shuttle'){
    sq.src=(d.water&&waterSpot(xy[0],xy[1],seed))||scatter(xy[0],xy[1],1,14,22,seed,3)[0]||[xy[0]+14,xy[1]]; sq.trips=d.trips; sq.carry=0;
  }
  restore(sq);
};
/* put the props back where the save says (after loading) */
function restore(sq){
  if(sq.spots) sq.spots.forEach((p,i)=>setProp(i,p));
  if(sq.src) setProp(0,sq.src);
}
let lastKey='';
setInterval(()=>{
  try{ const A=act(); const k=A?A.sq.key+JSON.stringify(A.sq.spots||A.sq.src||''):''; if(k!==lastKey){ lastKey=k; if(A) restore(A.sq); } }catch(e){}
},1000);

/* ---------- talking: sitting-with quests ---------- */
function runBeats(r,d,fin){
  let i=0; const W=r.who[0], per=(d.hours||0)/d.beats.length;
  const next=()=>{
    if(i>=d.beats.length){ if(d.close&&d.close.length) play(r,d.close,fin); else fin(); return; }
    const b=d.beats[i++];
    play(r,b.l,()=>{
      choose(W,b.q,b.o.map(x=>x[0]),k=>{
        const op=b.o[Math.min(k,b.o.length-1)];
        fx(op[2]);
        play(r,op[1],()=>{ if(per) advanceClock(per); fade(0.5); next(); });
      });
    });
  };
  next();
}

/* ---------- talking to the person while a task is open ---------- */
SQ.talk=function(r,done){
  const st=RS()[r.id]; if(!st||!st.sq||st.st!=='open') return false;
  const sq=st.sq, d=DEF[sq.key]; if(!d||d.kind==='talk'){ delete st.sq; return false; }
  const o=r.opts.find(x=>KEY(r,x)===sq.key);
  const W=r.who[0];
  const finish=()=>{
    const fin=()=>{ delete st.sq; D10.reqComplete(r,o,done); };
    if(d.back&&d.back.length) play(r,d.back,fin); else fin();
  };
  if(d.kind==='shuttle'&&sq.carry){
    advanceClock(d.cost/2); fade(0.4); sq.carry=0; sq.n++;
    if(sq.n>=sq.trips){ say('',d.last||['That was the last one.'],finish); return true; }
    say('',[ (d.drop||['You set it down.'])[Math.min(sq.n-1,(d.drop||['x']).length-1)]+' ('+sq.n+'/'+sq.trips+')' ],()=>{ done(); });
    return true;
  }
  if(sq.ready){ finish(); return true; }
  say(W,[ (typeof d.remind==='function'?d.remind(sq):d.remind)||'Have you got it?' ],()=>{
    choose(W,'',['Carry on.','I cannot do this now. Give it up.'],k=>{
      if(k===1){ delete st.sq; hudCache.obj=null; say(W,d.giveup||['Another time, then. It is all right.'],()=>done()); }
      else done();
    },0);
  });
  return true;
};

/* ---------- using the world props ---------- */
function bearing(from,to){ return dirOf(to[0]-from[0],to[1]-from[1]); }
function spotUse(i){
  const A=act(); if(!A||!A.d) return;
  const {sq,d,r}=A, k=d.kind, me=[Math.floor(g.px/TS),Math.floor((g.py-2)/TS)];
  if(k==='shuttle'){
    if(sq.carry){ say('',['Your wings are already full. Take it back to '+r.who[0]+' first.']); return; }
    advanceClock(d.cost/2); fade(0.4); sq.carry=1; hudCache.obj=null;
    say('',[d.take||'You fill it.']); return;
  }
  if(sq.dug[i]){ say('',[k==='dig'?'Already turned over. Nothing else here.':'Already picked.']); return; }
  if(k==='dig'&&!(g.inv.shovel>0)){ say('',['Without your shovel you are only scratching at it with a wing. Fetch it from your pack (or buy another).']); return; }
  if(k==='gather'){
    sq.dug[i]=1; sq.n++; advanceClock(d.cost); fade(0.4); hudCache.obj=null;
    const left=sq.spots.length-sq.n;
    const line=(d.pick||['You gather it.'])[(sq.n-1)%(d.pick||['x']).length];
    if(left<=0){ say('',[line,d.done||'That is everything.'],()=>{ sq.ready=1; toast('Take it back to '+r.who[0]+'.',3600); hudCache.obj=null; }); }
    else say('',[line+' ('+sq.n+'/'+sq.spots.length+')']);
    return;
  }
  /* dig */
  if(i===sq.target&&sq.n<3){
    const far=sq.spots.map((p,j)=>[j,Math.hypot(p[0]-sq.spots[i][0],p[1]-sq.spots[i][1])]).filter(x=>!sq.dug[x[0]]&&x[0]!==i).sort((a,b)=>b[1]-a[1])[0];
    if(far) sq.target=far[0];
  }
  sq.dug[i]=1; sq.n++; advanceClock(d.cost); fade(0.5); hudCache.obj=null;
  if(i===sq.target){
    say('',d.found,()=>{ sq.ready=1; toast('You have it. Take it back to '+r.who[0]+'.',4200); hudCache.obj=null; });
    return;
  }
  const junk=d.junk[(sq.n-1)%d.junk.length];
  const T0=sq.spots[sq.target], here=sq.spots[i], dist=Math.hypot(T0[0]-here[0],T0[1]-here[1]);
  const hint=dist<=3.5?d.hot:dist<=7.5?d.warm:d.cold;
  const dir=bearing(here,T0);
  const left=sq.spots.filter((_,j)=>!sq.dug[j]).length;
  say('',[junk,hint.replace('{dir}',dir)+(left<=1?' (Only one place left. It must be there.)':'')]);
}

/* ---------- the bottom-of-screen line, the journal ---------- */
function status(){
  const A=act(); if(!A||!A.d) return '';
  const {sq,d,r}=A, W=r.who[0];
  if(sq.ready) return 'Side task done: take it back to <b>'+W+'</b>.';
  if(d.kind==='dig'){
    const me=[Math.floor(g.px/TS),Math.floor((g.py-2)/TS)];
    const un=sq.spots.map((p,j)=>[p,j]).filter(x=>!sq.dug[x[1]]).map(x=>[Math.hypot(x[0][0]-me[0],x[0][1]-me[1]),x[0]]).sort((a,b)=>a[0]-b[0])[0];
    return 'Side task for '+W+': '+d.title+' ('+sq.n+' dug). '+(un?'The nearest unturned patch is '+Math.round(un[0])+' waddles '+bearing(me,un[1])+'.':'');
  }
  if(d.kind==='gather') return 'Side task for '+W+': '+d.title+' ('+sq.n+'/'+sq.spots.length+').';
  if(d.kind==='shuttle'){
    const me=[Math.floor(g.px/TS),Math.floor((g.py-2)/TS)], tgt=sq.carry?(RS()[r.id].xy||sq.home):sq.src;
    return 'Side task for '+W+': '+d.title+' ('+sq.n+'/'+sq.trips+'). '+(sq.carry?'Carrying it: take it back to '+W:'Go to '+d.srcName)+', '+Math.round(Math.hypot(tgt[0]-me[0],tgt[1]-me[1]))+' waddles '+bearing(me,tgt)+'.';
  }
  return '';
}
SQ.status=status;
{
  const _so=storyObjective;
  storyObjective=function(){
    const base=_so();
    let s=''; try{ s=status(); }catch(e){}
    return s?(base?base+'  ·  ':'')+s:base;
  };
}
{
  const _je=journalExtra;
  journalExtra=function(sec,line){
    _je(sec,line);
    try{ const A=act(); if(A&&A.d&&A.d.kind!=='talk'){ sec('A Task You Took On'); line(status().replace(/<[^>]+>/g,''),''); } }catch(e){}
  };
}
})();
