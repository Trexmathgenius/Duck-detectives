'use strict';
/* ===== v1.29: VOICES, PART TWO =====
   Emberwick's people, the ducklings, the cast who stay in the world after the end, and the small lives of the townducks. */
(function(){
const LV=window.LV;
const V=LV.voice;
const A=(...c)=>c;
const persona=(i,j)=>()=>{ try{ return PERSONAS[RP0+i][j]; }catch(e){ return null; } };
const k3s=k=>{ try{ return k3(k); }catch(e){ return undefined; } };
const arc=()=>{ try{ return S4st().arc||{}; }catch(e){ return {}; } };

/* ======================================================================
   EMBERWICK
   ====================================================================== */
const hearthGreet={
  p2:{redfeather:['Warm hearth. (She looks at your feathers for a long moment.) Warm hearth.'],any:['Yellow one.','Hm. You again.','Warm hearth. (It is said the way you would say "mind the step".)']},
  a2:{red:['Warm hearth, red one.','Warm hearth. You are still here. Good.'],crown:['You. The Crown\'s detective. In Emberwick. Bold.','The banished one. Hm.']},
  a3:['Warm hearth, Detective.','Warm hearth. Sit if you are sitting.'],
  a4:{red:['Warm hearth, friend.','Warm hearth. The Wall has your fingerprints on it now.'],any:['Warm hearth.']},
  a5:['Warm hearth. Tonight, of all nights.','Warm hearth. Stay near the fire.'],
  a6:['Warm hearth, friend.','Warm hearth! The road is open, they say.'],
  end:{stay:['Warm hearth.','Warm hearth. Quiet tonight.'],any:['Warm hearth, neighbour.','Warm hearth! Come in, come in.']}
};
V('Warden Ruddock',{tone:'hearth',role:'hearth',intro:persona(0,0),lines:A(persona(0,1),persona(0,2)),greet:hearthGreet,knows:ctx=>ctx.pi>=3,
  call:(ctx,m)=>ctx.pi>=7?(m&&m.n>=4?'friend':'Detective'):ctx.red?'red one':'Detective',
  p2:A(persona(0,1),persona(0,2)),
  a2:{red:A(['Three proofs. The bell, the lanterns, the grievances. I made them hard on purpose. You did them anyway. I am not going to say I am impressed.','(He is impressed.)'],['The Hearth is failing. I said that to you. I have never said it to anyone. Do not make me regret it.']),
      crown:A(['The Crown\'s detective, inside my wall. I should have you walked out. I am going to stand here and watch you instead, and you are going to behave.'])},
  a3:A(['Tidy. You put things very tidily, Detective. I noticed. I notice when people are careful with the truth. I am careful with it too. It is how I know.'],['The summit. I was in the room. I watched a Crown captain try to be honest. It was like watching a bear try to knit. I respected it more than I can say.']),
  a4:{red:A(['I told you about my grandfather. On the Siege Field. I have not told anyone that, in thirty years of standing on this wall. I do not know why I told you. I do not want to know.'],['I guard the Lantern Road now. A road, not a wall. I keep walking to the end of it and turning round. It feels like a trick.']),any:A(['There is a list. Eleven names. I keep it in my helmet. You know about the list. That is all I am going to say.'])},
  a5:A(['If the ward breaks tonight, I will be on the wall. If it breaks badly, I will be on the road. If it breaks very badly, I will be wherever you are. That is the order of things.']),
  a6:A(['I laid down the spear and walked to the third village on the bend. There is an old man there who whistles my grandfather\'s tune. I stood in his doorway for an hour. He gave me soup. I did not tell him why I was crying.']),
  end:{wake:A(['The watch is posted. Nobody is watching. It is lovely.'],['I carry the post to the three villages on the bend. On foot. I whistle. Badly. A warden who whistles. My grandfather would have laughed until he fell off the wall.']),
    door:A(['I hold the door on the Hollow side. Halbeak holds it on his. We argue about whose turn it is. I have never enjoyed an argument so much. Do not tell him.'],['Someone came through the door this morning with a yellow face and a basket of pears. I said "warm hearth". She said "good morning". We stood there and worked it out.']),
    keeper:A(['I sit at the hermit\'s table on Thursdays. I do not speak. I drink the tea, which is terrible, and listen. A warden who listens. I have been told it is an improvement.']),
    stay:A(['The wall holds. The Wood holds. Nobody passes. Nobody needs to. (He says it the way he always said it, and then stops, and looks north.)'],['Quiet. You did what you thought was kind. I have done that. It is a heavy thing to carry for a lifetime. I would carry it with you, if you asked.']),
    any:A(['Nobody passes the Wood, I used to say. Nobody. I was wrong. Everybody does now. I am very happy to have been wrong.'])},
  recall:[{id:'rud_watch',when:ctx=>ctx.seen('watch')==='stood',lines:['You stood the cold watch with me. I have not forgotten. I will not forget. That is not a threat. It is the opposite of a threat. I do not have a word for it.']},
    {id:'rud_snub',when:ctx=>ctx.seen('watch')==='snubbed',lines:['You walked past me in the yard, once, when I rebuked you. I deserved to be walked past. I am telling you so I do not have to keep remembering it alone.']}]
});
V('Acolyte Wren',{tone:'hearth',role:'hearth',intro:persona(1,0),lines:A(persona(1,1)),greet:hearthGreet,
  p2:A(persona(1,1)),
  war:A(['I carry the ash at dusk and the coal at dawn. This week I carried both at once. The Hearth is low. I am not supposed to say so. I am an acolyte. We say things.']),
  crisis:A(['Keeper Brand used to say a flame never asks whose hands lit it. He has been saying other things lately. Angrier things. I keep the old sayings. Someone should.']),
  a6:A(['There is talk of a second bell. In the kingdom. A sister there, Dove, wrote to ask if a red acolyte would ring it. I wrote back yes before I had finished reading.']),
  end:{stay:A(['The Hearth is high. The Wood is still. I carry the ash at dusk and the coal at dawn. Nothing has changed. I am trying to decide if that is a blessing.']),
    any:A(['I ring the bell in Kingsbill at dusk and ours at dawn. Sister Dove says it is the same bell, really. I have stopped arguing. She makes very good tea for a yellow.'],['Warm hearth. We say it to everyone now. It is also what we mean. Both at once. I did not know that was allowed.'])}
});
V('Courier Jay',{tone:'hearth',role:'hearth',intro:persona(2,0),lines:A(persona(2,1)),greet:hearthGreet,
  p2:A(persona(2,1)),
  war:A(['Messages from the Hall to everywhere, and back. They have stopped saying "later". They say "soon" now. I like "later" better.']),
  crisis:A(['I ran a message to the Crown\'s line last night. To the Crown! Through the Wood, in the dark, with a white rag on a stick. A blue soldier gave me a biscuit. I did not know what to do with it. I ate it.']),
  a6:A(['I run messages to Kingsbill now. Every day. Down the Lantern Road. The guards at the gate know my name. One of them saves me a pear.']),
  end:{stay:A(['No messages. Nothing to say. I run anyway, every morning, to the edge of the Wood and back. My legs do not know the war is over.']),
    any:A(['Messages to everywhere! Everywhere is bigger now. I am still fast. I am faster. I have a road.'])}
});
V('Hearthwarden Pyre',{tone:'hearth',role:'hearth',intro:persona(3,0),lines:A(persona(3,1)),greet:hearthGreet,
  p2:A(persona(3,1)),
  war:A(['The Hearth burns lower every week. I add two logs an hour now. Then three. The Wood leans in anyway. It is not the wood that is failing. It is something under it.']),
  crisis:A(['Last night the Hearth went out. For a breath. One breath. The whole town woke at once, as if someone had called their names. Then it caught again. I have not slept since.']),
  a6:A(['The Hearth burns without me. I sat beside it all night with a log in my lap and it did not need it. A hundred years of one log an hour. I did not know what to do with my wings. I held the log.']),
  end:{stay:A(['One log an hour. I have never missed. The Wood leans out. Nothing has changed. I will not be the one to miss.']),
    any:A(['I took a coal of the Great Hearth to Kingsbill. They have a brazier for it now, in the temple. The first fire in the kingdom lit from ours. It burns blue at the edges. Nobody can explain it. Nobody tries.'],['Sit by it if you like. A fire does not check feathers. That was always the point of fire. It is the point of a great many things now.'])}
});
V('Old Garnet',{tone:'elder',role:'hearth',intro:persona(4,0),lines:A(persona(4,1)),greet:hearthGreet,
  p2:A(persona(4,1)),
  war:A(['I carried sixty pounds of ash on the March. I was nine. I have been waiting a hundred years to set it down, and the world keeps giving me more to carry.'],['A stranger in a yellow coat gave my mother his last bread, at the seventh river. I keep thinking: what if it was your grandfather? It was not. But what if.']),
  crisis:A(['There is a plaque on the Wall of Lost for my sister. Forty-one plaques. I am the only one left who knew any of them. When I go, they are only names. That frightens me more than the Wood.']),
  a6:A(['They woke up. Three hundred. My sister was not among them. I asked. I knew. I asked anyway. A woman called Orla held my hand while they looked. She lost a son. We sat a long time.']),
  end:{stay:A(['Quiet. A hundred and nine years old and quiet at last. Good. I am too tired for anything else. But I dream of the seventh river every night now.']),
    any:A(['I went to the kingdom. A hundred years. I walked through the gate on my own feet and a guard said "welcome to Kingsbill, mind the fountain". I sat on the edge of it and laughed until I had to be helped up.'],['Yellow is not one thing. I told myself that for a hundred years. Now I do not have to tell myself. I just know some of them.'])}
});
V('Widow Ash',{tone:'hearth',role:'hearth',intro:persona(5,0),lines:A(persona(5,1)),greet:hearthGreet,
  call:(ctx,m)=>ctx.red?'red one':ctx.pi>=7&&m&&m.n>=3?'Detective':'yellow one',
  p2:A(persona(5,1)),
  war:{redfeather:A(['Red. You made yourself red. You think that makes it different. (A pause.) It does a little. I hate that it does.']),any:A(['Still here. Still yellow. Still asking questions in my town. My mother would have spat. I am too old to spit. I glare.'])},
  crisis:A(['They read my mother\'s plaque out at the Wall. You were there. You stood very still. Most people fidget. You did not. (She looks away.) That is all.']),
  a6:A(['I walked the Lantern Road to the kingdom. To see the balcony. The one from the stories, where the banners were. It is small. Very small. A little stone shelf. I stood under it and I did not know what I felt. I still do not.']),
  end:{stay:A(['Quiet. The Wood is quiet and the Wall is quiet and my mother\'s name is still on it. Some things do not change. Some things should not.']),
    any:A(['A yellow woman came to the Wall of Lost yesterday. She read every plaque. She asked me which one was my mother. She put a flower on it. A yellow flower. I let her.','(A long silence.) I am not saying anything else about it.'],['Do not look at me like I am cruel. I was never cruel. I was a woman with a lot to remember. I still am. I am remembering it differently.'])},
  recall:[{id:'ash_red',when:ctx=>ctx.red&&ctx.pi>=4,lines:['My mother would not have known what to make of you. Red by choice. Nobody chose it, in her day. It chose them. (She looks at you for a long time.) She would have made you tea. She made everyone tea. Even when she should not.']}]
});
V('Scout Fennel',{tone:'hearth',role:'hearth',intro:persona(6,0),lines:A(persona(6,1)),greet:hearthGreet,
  p2:A(persona(6,1)),
  war:A(['Is it true the kingdom has a castle with blue windows? And a fountain that bites? And a market where you can buy a pear from a yellow lady with a scarf? I am asking for a friend. I am the friend.']),
  crisis:A(['I went past the wall. In the morning. Mornings are the least watched. I saw the sky. All of it. At once. I sat down in the road. Ruddock found me and did not shout. That frightened me more than the sky.']),
  a6:A(['The road is open. I have walked it four times. I keep stopping in the middle, where you can see both towns, and turning round and round until I fall over.']),
  end:{stay:A(['The wall. The Wood. The sky through the trees, in pieces. I have seen it whole once. I keep that morning in my pocket.']),
    any:A(['I have seen the sea. There is a sea! South! It is the sky lying down! Nobody told me! A hundred years and NOBODY TOLD ME!'])}
});
V('Farmer Clay',{tone:'hearth',role:'hearth',intro:persona(7,0),lines:A(persona(7,1)),greet:hearthGreet,
  p2:A(persona(7,1)),
  war:A(['The Wood leans in more every week. My beets are growing sideways, toward the Hearth, like children toward a fire.']),
  crisis:A(['The soil stopped humming last night. Then it started again, wrong. Lower. My grandmother said the Wood was a hand held out, trembling. I think it is trying to let go of something.']),
  a6:A(['There are Hearthblooms coming up in the Burnt Wood. Red, in the ash. I went to see them. I am a beet farmer. I knelt down in the ash and touched one, and it was warm.']),
  end:{stay:A(['Beets are fine. Soil is fine. Everything is fine. The Wood leans in a little, still, at night. Like a hand that has not quite decided.']),
    any:A(['A yellow farmer came to learn about beets. Oats, his name is. He talks about crows the whole time. I have learned a great deal about crows. He has learned a great deal about beets. It is a fair trade.'],['The soil does not hum any more. It just grows things. I did not know I missed ordinary dirt until I had it back.'])}
});
V('Night-watch Ashby',{tone:'hearth',role:'hearth',intro:persona(8,0),lines:A(persona(8,1)),greet:hearthGreet,
  p2:A(persona(8,1)),
  war:A(['The Wood whispers louder. Three words. I am not to say them. I will say: it is a question.']),
  crisis:A(['Last night the three words changed. The last one. It is still a question. It is a different question. I wrote it on my wrist so I would not forget. It washed off. I remember it anyway.']),
  a5:A(['Whose child are you. Those were the words. All this time. I am allowed to say them now, the Warden says, because you have answered them. Have you? You look like you have.']),
  a6:A(['The Wood does not whisper any more. I walk the wall and it is only wind. I do not know what to listen for. I have started listening to the town instead. It is very loud. Snoring, mostly.']),
  end:{stay:A(['It whispers again. Only the first two words. "Whose child." It does not finish. I hum it to sleep, some nights. It is a lullaby, if you do not finish it.']),
    any:A(['Nobody whispers in the Wood now. I walk the wall anyway. Old habit. Some nights a yellow guard from the kingdom walks the other side of the Wood, and we wave our lanterns at each other. Just to say: still here.'])}
});
V('Gossip Marrow',{tone:'hearth',role:'hearth',intro:persona(9,0),lines:A(persona(9,1)),greet:hearthGreet,
  p2:A(persona(9,1)),
  war:{red:A(['Have you heard? You have been inside the Hall! You! The Elders asked you things! Nobody tells ME anything and they asked YOU things! I am not jealous. I am beside myself.']),crown:A(['Have you heard? The yellow one went to the king! Then came back! Then went again! I cannot keep up! I have had to start writing it down!'])},
  crisis:A(['Have you heard? No? Good. I have heard nothing. Nobody knows anything. The Elders sit with the door open now. I can hear everything. It is all very sad and very sensible. I hate it.']),
  a6:A(['Have you heard? The sleepers! The road! The king! The beetroot prices! I have so much to tell you I have forgotten the order!']),
  end:{stay:A(['Have you heard? Nothing has happened. Nothing at all. I have checked everywhere. It is the strangest news I have ever had.']),
    any:A(['Have you heard? Everybody knows everything now. The Elders publish the minutes. On the door. I have nothing to whisper. I have taken up knitting. I am terrible at it. It is the best news I have.'])}
});

/* ---------- the guards of Cinderhold ---------- */
const rgClaim=ctx=>ctx.pi>=3;
V('Cinderhold Guard Soot',{tone:'hearth',role:'hearth',claim:rgClaim,knows:()=>true,
  a2:{red:A(['The Elders will see you when the Elders see you. That is the procedure. I do not like the procedure. I like you, a little. That is not procedure.']),crown:A(['Cinderhold is closed to the Crown\'s detective. Do not make that face. It is not personal. It is a war.'])},
  a3:A(['The Elders have been in session nine days. They send out for bread and more lamp-oil. They do not send out for anything else.']),
  a4:A(['Eyes front. Feet on the red. The Elders voted for a small party, not an army. I am allowed to tell you that. I am very glad I am allowed.']),
  a5:A(['If the ward breaks, I am to hold this door. Against what, nobody says. I have decided: against panic. Panic does not get in.']),
  a6:A(['The doors are open. All day. The Elders said: let them see us. Yellow ducks come in and look at the carpet and ask if they are allowed to walk on it. I say: that is what it is for.']),
  end:{stay:A(['The doors are shut again. A single red ribbon across them. The Elders have had their say. It is quiet.']),any:A(['Move along! (He grins. He has never grinned before.) No. Come in. Everyone comes in now. I only say "move along" for practice.'])}
});
V('Cinderhold Guard Flint',{tone:'hearth',role:'hearth',claim:rgClaim,knows:()=>true,
  a2:A(['Elders only. You are not an Elder. (A pause.) You are not nothing, either. I am told to say only the first part.']),
  a3:A(['A yellow ambassador came to the door yesterday. With a flag. I did not know whether to salute. I did a sort of nod. He did a sort of nod. We were both very relieved.']),
  a4:A(['I have a cousin on the Lantern Road. With the small party. She packed too many sandwiches. She always packs too many sandwiches. I hope she has to share them.']),
  a5:A(['The carpet is warm. It has never been warm. Something under the town is breathing.']),
  a6:A(['There is a yellow guard at the kingdom gate called Pintail. We write to each other. About doors. It is a very specialist correspondence.']),
  end:{stay:A(['Eyes front. Feet on the red. Nothing to guard. I guard it.']),any:A(['My cousin came home from the Lantern Road with an empty sandwich basket. She shared them. I have never been so proud of anybody.'])}
});

/* ---------- Elder Umber, deep in the Wood ---------- */
V('Elder Umber',{tone:'elder',role:'hearth',claim:ctx=>ctx.pi>=3&&!!(g.story&&g.story.colorBook),knows:()=>true,
  a2:{redfeather:A(['Red as a coal. I cannot see it. I can hear it. The colour hums. It hums a little louder than it did. You have been using it.']),any:A(['The recipe was not a gift. It was a question. You have not answered it yet. That is allowed. Most people take their whole lives.'])},
  a3:A(['I hear the Old Tree from here. It used to snore. It is talking in its sleep now. Somebody has asked it something.']),
  crisis:A(['Blind ducks hear the ward. It is a high note, very thin, like a wet finger on a glass. It has gone thinner every day this month.']),
  a6:A(['The high note is gone. I sat here all night listening for it. Instead: birds. A great many birds. I had forgotten what birds sound like when they are not frightened.']),
  end:{stay:A(['The thin note is back. Steady. Held. Somebody is holding it again. I know who. I hum along, very quietly, so he is not alone.']),any:A(['I cannot see the Wood go green. I can hear it. It sounds like a hundred thousand very small doors opening.'])}
});

/* ---------- the children of Emberwick, after their questions ---------- */
V('@redkid',{tone:'child',role:'child',knows:()=>true,
  call:ctx=>ctx.red?'red one':'detective',
  p2:A(['The big ducks go quiet when you walk past. I am practising quiet. I am not good at it.'],['Our Banking is at six. Everyone sits. I get to hold the ash-shovel. Sit at the back if you come. I will save you a very small place.']),
  war:{red:A(['You are red now! Like us! Mama says it does not wash off. I tried to wash mine off once. It does not.']),any:A(['Mama says the yellow ones are going to come with soldiers. I said you are a yellow one and you came with questions. She went quiet.'])},
  crisis:A(['Everyone is counting the children. They count me four times a day. I am still one. I keep telling them.']),
  a6:A(['I walked to the kingdom! On the road! There is a fountain that bites! It did not bite me. It soaked me. Best day.']),
  end:{stay:A(['Mama says it is all over. I asked what was over. She said "the waiting". I said I am still waiting for my birthday. She laughed. She does not laugh much.']),any:A(['I have a yellow friend now. His name is Tiny. He is not tiny. We are going to be detectives. Like you. But two.'])}
});
V('Little Poppy',{tone:'child',role:'child',knows:()=>true,
  call:(ctx,m)=>ctx.pi>=7?(ctx.nick||'detective'):'detective',
  p2:A(['Mama says not to talk to you. I told her I was practising my questions.','She said "on whom"? I said "on the yellow one". She said, "that is not who". I am still thinking.']),
  war:A(['I have been keeping count of something. I am not telling you what. It is a big count. It has your name in it.'],['I made the braid with eight knots. Did you keep it? You kept it. I can tell. You have a braid face.']),
  crisis:A(['I packed sandwiches for the Lantern Road. Too many. Mama says too many. I say there is no such thing as too many sandwiches when you are walking toward someone.'],['I asked you three questions on the road. You answered all three. Nobody answers all three. I wrote them down.']),
  a5:A(['I am not frightened. I am a little frightened. If I hold your wing I am less frightened. That is just science.']),
  a6:{any:ctx=>ctx.k3('lanternBy')==='poppy'?A(['They want ME to light the lantern. Me! I have been practising with a candle. I burned the tablecloth. Mama says that is part of practising.']):A(['There is going to be a lantern. A big one. On the road. I am going to stand right at the front. Right right at the front.'])},
  end:{wake:A(['I am going to be the Keeper of the First Hearth when I am grown. Everyone says so. I say so loudest.','I will need a detective. For keeping. You can be it.']),
    door:A(['I walked through the door first. Holding Papa\'s boot. Everyone said it was very brave. It was not brave. I just wanted to see what was on the other side. It was a lady with pears.']),
    keeper:A(['I keep a chair at the table. For Papa. In case. Mallow says every table should have one chair for in case.']),
    stay:A(['Is it finished? Mama says it is finished. It does not feel finished. It feels like the middle of a story when someone closes the book.','You can open it again. Can\'t you? You are a detective. Detectives open things.']),
    any:A(['Will you come back when the flowers are tall? You promised. Or you tried. Both count.'])},
  recall:[{id:'pop_letter',when:()=>arc().poppyEnd==='letter',lines:['I keep Papa\'s letter in the boot. It is one line. I have stopped squinting at it. I know what it says. I just like to look.']},
    {id:'pop_told',when:()=>arc().poppyEnd==='told',lines:['Papa has a room with a lamp. People ask him questions. Halbeak says that is how it begins. I visit on Sundays. I bring the questions I think are easy.']},
    {id:'pop_promise',when:ctx=>ctx.did('c24'),lines:['I water the flowers every day. Especially when it rains. You said you would come back when they are tall. They are a bit tall. You came. That counts.']}]
});

/* ======================================================================
   THE PEOPLE WHO STAY, AFTER THE END
   ====================================================================== */
const after=()=>{ try{ return LV.after(); }catch(e){ return false; } };
const notStay=()=>LV.ending()!=='stay';
LV.resident({id:'lv_eider',name:'King Eider',like:'eider_a',k:[-16,14],when:()=>after()&&notStay()&&LV.ctx().eiderLives});
LV.resident({id:'lv_cinder',name:'Elder Cinder',like:'cinder_a',red:[38,31],when:()=>after()});
LV.resident({id:'lv_bree',name:'Bree',like:'bree',k:[74,-54],when:()=>after()&&notStay()});
LV.resident({id:'lv_hob',name:'Hob, a cook',like:'hob',k:[-11,33],when:()=>after()&&notStay()});
LV.resident({id:'lv_orla',name:'Orla, a mother',like:'orla',wx:237,wy:-1328,when:()=>after()&&notStay()});
LV.resident({id:'lv_tam',name:'Tam, a soldier',like:'tam',k:[27,31],when:()=>after()&&notStay()});
LV.resident({id:'lv_brand_t',name:'Keeper Brand',like:'brand_a',k:[-61,-57],when:()=>after()&&k3s('brandFate')==='shelter'});
LV.resident({id:'lv_brand_e',name:'Keeper Brand',like:'brand_a',red:[30,29],when:()=>after()&&(k3s('brandFate')==='trial'||k3s('brandFate')==='witness')});
LV.resident({id:'lv_whistle',name:'Clerk Whistle',like:'whistle_a',k:[43,-18],when:()=>after()&&!!(g.story&&g.story.met&&g.story.met['Clerk Whistle'])});

V('King Eider',{tone:'royal',role:'lore',knows:()=>true,
  end:{wake:A(['It is safe now. You said it for me. I wrote that word a hundred years ago, in a margin, and could not keep it. I have been sitting by my own statue all morning, trying to forgive the man it is of.','I am told I am a retired king. It seems an odd thing to be, like a retired tide.'],
      ['I walk the maze at night. I get lost. Hubert finds me. He laughs at me. Nobody has laughed at me in a hundred years. I had no idea how much I needed it.'],
      ['My word was "stay". I thought it was a command. It was only a wish, said too loudly. I am trying to learn to say things at the right size.']),
    door:A(['It will be safe. Not "is". "Will be." You gave me a word with a future in it. I have never owned one before.','I go up to the door some mornings and watch them come through. I do not say who I am. They do not ask. It is the best disguise in the world: an old duck on a bench.'],
      ['I find I like being a guest. Nobody has ever asked me to help with the washing up.']),
    keeper:A(['I have sat at your hermit\'s table. I have eaten his soup. It is very bad. It is the best soup I have ever had.','A king is a person who decides. A table is a place where nobody has to. I am learning which I prefer.'],
      ['Envoys come and ask me what I think. I say, "Sit down first." Then I forget to answer. It works remarkably well.']),
    any:A(['I find I like being a guest. Nobody has ever asked me to help with the washing up.'])},
  recall:[{id:'eid_seal',when:ctx=>ctx.did('c7c'),lines:['I warmed the seal for you. In a dream, through Pip. It cost me a night of the ward. I would spend it again. It is the only thing I have ever spent that I did not have to count.']}]
});
V('Elder Cinder',{tone:'elder',role:'hearth',knows:()=>true,
  end:{wake:A(['I used to think peace was the absence of risk. It is the presence of a kettle, and someone who will come when it whistles.','The Hall publishes its minutes on the door now. Marrow is furious. She has nothing left to whisper.'],
      ['A yellow Elder came to our Hall last week. A real one, with a chain. He asked to sit at the back. I put him at the front. He has not recovered.']),
    door:A(['The door is open a pace. I go every evening and stand on our side and count who comes back. More come back than go. That is how you know a door is working.']),
    keeper:A(['I sit at the table on the first day of every month. Halbeak sits across from me. We do not agree on anything. We have agreed on that.']),
    stay:A(['The Hall voted to close the matter. I voted with them. I go home at night and I do not sleep, and I think about the three hundred, still dreaming. That is the price of quiet. I am paying it.'],['You chose the gentle thing. Gentle things are heavy. If you ever want to set it down, I will be at the Hearth.']),
    any:A(['Thank you for letting me learn it late. I would rather learn it late than never. It is a very small difference, and I am holding on to it with both wings.'])}
});
V('Bree',{tone:'elder',role:'hearth',knows:()=>true,
  call:()=>'dear',
  end:{any:A(['I left him three instructions under a floor. Light the hearth. Eat something. Do not follow. He did his best with all three without knowing he had been asked.','Now I am telling him a fourth. Let someone else cook. He is ignoring it magnificently.'],
    ['A hundred years asleep, and the first thing I learned awake is that my son makes terrible tea. I drink it every morning. It is the best thing I have ever tasted.'],
    ['You were the third chair, you know. He told me. He set it out for eighty years for nobody, and then it was you. Sit. Sit, dear. It is your chair.'])}
});
V('Hob, a cook',{tone:'merchant',role:'folk',knows:()=>true,
  end:{any:A(['They gave me a kitchen! In Kingsbill! A baker called Crumb lets me use his oven before dawn. I made the bread for three hundred, once. Now I make it for anyone. Anyone is more.'],
    ['Taste this. No. Taste it. It is the red bread, the old recipe, the one from before. I remembered it in my hands. My head forgot. My hands did not.'],
    ['I never put my name on anything. Now Crumb has put a sign up: "Hob\'s Loaf, Tuesdays." I stand under it and pretend not to look. I look.'])}
});
V('Orla, a mother',{tone:'gentle',role:'lore',knows:()=>true,
  end:{any:A(['I keep the Hall of Names now. I am the Warden of Names. I did not ask to be. I was the only one who wanted to read all of them.','There is a brick here: "Alder, who held on." Under it, someone has written a second line: "We held on to you." It was not me. I do not know who. I come and read it every morning.'],
    ['People come from both towns to find a name. I help them look. When they find it they usually do not cry. They usually say, "there," like you would to a child who has been found. Then they cry.'])}
});
V('Tam, a soldier',{tone:'soldier',role:'soldier',knows:()=>true,
  end:{any:A(['I drill the young ones at the Training Yard. Halbeak asked. I said I have not held a spear in a hundred years. He said, "neither have they." So now I teach them how to put one down properly. It is the most important drill.'],
    ['I was told to hold the line at the Reeds until I was relieved. You relieved me. I still think about that. Relieved, by a duck with no rank. I have been relieved ever since.'],
    ['Halbeak is a good man. He does not know it. I tell him every Thursday.'])}
});
V('Keeper Brand',{tone:'hearth',role:'hearth',knows:()=>true,
  end:{any:ctx=>({
      shelter:A(['I tend the lamps at the Tree. Nobody asks me to speak. I find I do not have much to say that is not already in the flame.'],['My sister was one of the ones the ward took. I light her lamp first, every night. Then the others. Then I sit. That is the whole of the job, and it is enough.']),
      trial:A(['The Hearth heard me. It is still deciding. I wait. It is strange to wait for others to say what I am. I think it is the most honest thing I have ever done.']),
      witness:A(['I said it. All of it. At the council, in front of both towns. Whatever they do after, I have said it. I sleep, now. Not well. But I sleep.'])
    }[ctx.k3('brandFate')]||A(['I keep a lamp. That is all I do now. It is enough.']))}
});
V('Clerk Whistle',{tone:'nervous',role:'lore',knows:()=>true,
  end:{any:ctx=>ctx.k3('hn_clerk')?A(['I read the brick in the Hall of Names. My ancestor. The family said he was a bad copyist. The brick says he copied the true Edict and hid it, and was dismissed for it. Brave, it says. Brave.','I have started copying very slowly. In case it runs in families.']):A(['The Quiet Chair has been dissolved. I am a clerk of nothing. I straighten paper. The paper is already straight. I find it soothing.'],
      ctx.ending==='keeper'?['There are two courts in Kingsbill. Were. Now there is a table in the Burnt Wood and everybody goes there instead. I take the minutes. Nobody reads them. They are very good minutes.']
      :ctx.ending==='stay'?['The court has gone back to sleep, more or less. The ones with guards say the wall holds. They are right. I write it down. I write very small.']
      :['There are two courts in Kingsbill. Were. Now there is one, and it has red Elders in it on Tuesdays. I take the minutes. I have had to learn new words. "Warm hearth." I say it under my breath, for practice.'])}
});

/* ======================================================================
   TOWNDUCKS
   ====================================================================== */
LV.TOWNTALK={
  away:['Back again! Two days, three? It goes so fast.','There you are! I was just thinking about you.','Oh, hello again! I was hoping you would come by.'],
  long:['{days} days! Where have you BEEN? Never mind. You are here.','Well! {days} days. I thought you had forgotten us.','{days} days, and look at you. You look like you have been somewhere enormous.'],
  feathers:A(['Your feathers! They are red! Is that. Is it. Does it hurt?','(A long look.) Well. You are still you, underneath. I think. You talk the same. That is what matters, Mama always said: does it talk the same.']),
  menuLong:['Look who it is! It has been {days} days!','Oh! You are back! {days} days, I counted.','{days} days! I saved you a seat.'],
  menuFriend:['My favourite duck in the world!','There you are, friend. Sit, sit.','Oh good, it is you. It is always a better day when it is you.'],
  menuKnown:['Hello again!','Oh, it is you again. Hello!','Back already? Hello, hello.','There you are.'],
  keepLong:['{days} days! I thought you had found a better shop. There is no better shop.','Back after {days} days! Your usual is still on the shelf. I would not sell it.']
};
LV.NEWS={
  a2:{crown:A(['Have you heard? The Crown has a detective! A proper one, with a seal! (She looks at you.) Oh. Oh, it is you. I am going to tell everyone I said hello first.'],
        ['Soldiers came through on the north road, three hundred, all in blue. My cousin waved. One of them waved back and then looked very sorry.'],
        ['The king sent letters with a blue seal to every town. Ours says "ask the people nobody asks". So I have been asking my hens. They have opinions.'],
        ['They say the castle lights stay on all night, every window, and nobody is awake behind any of them. My aunt says that is how you know a house is frightened.']),
      red:A(['They say a red-feathered duck has been seen in the kingdom. Walking about! In the day! My neighbour fainted. She faints at everything. Still.'],
        ['There really is a red town, in the Hollow Wood. Emberwick. My grandmother used to say it in her sleep. I thought it was a word for a nightmare. It is a word for a town.'],
        ['A peddler says the red ducks do magic. Real magic. Lanterns that light with a snap. I bought a lantern from him. It did not snap. I want my crumbs back.'],
        ['My brother saw a lantern moving in the Hollow Wood at night. Then five. Then a whole line of them. He says it looked like a street. Forests do not have streets.']),
      any:A(['Everybody is talking about the Hollow Wood. Nobody is going there. Except you, I suppose.'])},
  a3:A(['There was a summit, they say, at an old watchtower. Both sides. It failed. My uncle says it was always going to fail. My aunt says that is why it mattered that somebody tried.'],
    ['The dark trees out by the road went darker last week. Then, one night, one of them hummed so loud the whole town heard. Nobody slept. Nobody admits to being frightened. Everybody was.'],
    ['They say the king is not a king at all. They say he is a door. I do not know what that means. It sounds lonely.'],
    ['A traveller says the Old Tree in the Burnt Wood shows you things, if you sit under it. Old things. He would not say what he saw. He bought three pies and ate them all at once.'],
    ['Bread is dear. Rope is dear. Lanterns are gone entirely. Everybody is buying things as if they will not be able to tomorrow. That is how wars start, my mother said: with shopping.']),
  a4:{red:A(['There is a road through the Wood now, lit with lanterns, and a small party walking it, with children. Children! Walking into the dark! Either they are very foolish or something has changed.'],
        ['They say the red town has a wall with forty-one names on it. People who went north and never came back. My grandmother had a list like that, of her own. I never asked whose.'],
        ['Somebody set fires at the red town\'s wall, they say. Five of them, in the night. And somebody else put them out. Everyone has a different story about who.'],
        ['The red ducks voted, they say. For a small party, not an army. My husband did not believe it. Then he went very quiet and fixed the gate he had been meaning to fix for a year.']),
      crown:A(['The lords in Kingsbill have fallen out. My brother is a footman there. He says there was shouting, and a lady in green left in a hurry, and the Captain swore an oath in front of everyone with his eyes shut.'],
        ['Five watch-fires burned all night on the hills. You could see them from the well. Nobody came. Everybody was glad. Nobody went to bed.'],
        ['The court has stopped paying the soldiers, they say. A soldier knocked on our door last night and asked for bread. I gave him bread. He was about fifteen.'],
        ['They say the Captain refused an order. THE Captain. The one who never refuses anything. My father says the sky will fall. It has not fallen yet. I have been checking.']),
      k:A(['There is a table in the Burnt Wood, people say, where a hermit pours tea for anybody, red or blue, and nobody is allowed to shout. My sister went. She said nobody shouted. She sounded disappointed and also like she had been crying.'],
        ['A red Elder and a blue lord sat at the same table, they say, and drank the same terrible tea, and neither of them left. My uncle says that is a miracle. My aunt says it is just manners.'],
        ['Nobody is picking a side, they say. There is a third road. Nobody knows where it goes. Everybody wants to know who is walking it.']),
      any:A(['Everybody is waiting for something. Nobody will say what.'])},
  a5:A(['The ground shook last night. Did you feel it? Of course you did. You were probably standing on it.'],
    ['The dark trees went out. All at once, at midnight. Not gone: out, like candles. Then a sound came from the north-west like an enormous breath. I am still shaking.'],
    ['People are walking north to see. To see what? They do not know. They just walk.'],
    ['The birds have stopped singing in the north woods. All of them. The same morning. A naturalist came through to write it down and could not think what to write.'],
    ['My grandmother says this is how it felt before the siege, a hundred years ago. Everyone waiting. Everyone polite. She says politeness is what frightened people do with their hands.']),
  a6:A(['The sleepers are awake! Three hundred red ducks, asleep a hundred years! One of them is a cook. I would like to know what bread tasted like a hundred years ago. I bet it was better.'],
    ['There is going to be a road. Between the kingdom and the red town. A real one. With lanterns. My son wants to walk it. I said, when it is finished. He said, it will never be finished. He is right, I think. That is the good kind of road.'],
    ['Flowers are coming up in the Burnt Wood! Red ones, in the ash. My cousin went to look and came back with ash to the knees and the biggest smile I have ever seen on him.'],
    ['A red Elder and the old Captain sat down together and agreed on a road. Or nearly. They are still arguing about the lanterns. Everyone says that is a very good sign.'],
    ['They say the old king walks in his garden now, in the daytime, and talks to the gardener about hedges. A king who talks about hedges. I like him already.']),
  end:{wake:A(['The dark trees have gone ordinary! The one by the well is just a tree now! The children climbed it. Nobody shouted. It is the best tree in town.'],
      ['A red family came through on the way to the sea. They stopped for lunch. We fed them. They fed us something red and spicy back. I have not been the same since.'],
      ['It is safe now. That is what people say to each other, coming in or going out. "It is safe now." It used to be a thing you said to a frightened child. Now we say it to each other.'],
      ['My daughter has gone up the Lantern Road to work at the red bakery for a season. A season! She sends letters. They smell of beetroot.'],
      ['There is a market at the halfway tower now, every new moon. Red stalls and yellow stalls. My husband bought a red hat. He looks ridiculous. He has not taken it off.']),
    door:A(['They say there is a door in the Burnt Wood, and it opens a little more every day. One or two red ducks come through, and look about, and go to market. My cousin sold one a hat. She said it was the most nervous she has ever been selling a hat.'],
      ['"It will be safe." People say it like a promise. I have started to like promises better than facts. Facts just sit there.'],
      ['A red grandmother moved in at the end of our lane. She came through the door with one bag. She sits on her step in the evenings and everyone stops to say good evening. She has never had so many good evenings.'],
      ['The Captain goes up to the door most nights, they say, and holds it. Holds a door! The Captain! My father laughed for an hour and then went up to see.'],
      ['My son asked if the door will ever be all the way open. I said, I hope not. A door that is all the way open is just a hole. A door that opens a bit more every day is a promise kept every day.']),
    keeper:A(['There is a table in the Burnt Wood, with a ring of chairs, and anyone can sit. My husband went. He came back and did not say anything for an hour and then he said, "I should like us to have more chairs." We have more chairs now.'],
      ['Envoys go up to the Old Tree every week and drink bad tea and come back less angry. Nobody knows how it works. Nobody wants to look too closely in case it stops.'],
      ['"It will be tended." My mother says that about her garden. Now everybody says it about everything. The bridge. The well. Each other.'],
      ['The hermit at the Tree makes the worst tea in the world. Everybody says so. Everybody goes back for more. That is the whole of the peace, as far as I can tell.'],
      ['I sat at the table. A red woman sat next to me and asked how my day was. I told her. All of it. I do not know why. She listened to every word.']),
    stay:A(['It is very quiet these days. Good quiet. I think. The dark trees are still dark, but nobody minds them now. We just walk round.'],
      ['They say it is over. The trouble, whatever it was. Nobody says what it was. I have stopped asking. It seemed to make people sad.'],
      ['Sometimes, at night, the dark tree by the road hums. Just four notes. Then stops. Like somebody who started to ask a question and decided not to.'],
      ['Nobody goes north any more. There is nothing to go for, people say. I said: then why does everyone keep looking that way?'],
      ['Safe. Everybody is safe. My grandmother says she has never been so safe and so sad at once, and she does not know why, and she would rather not be asked.'])}
};
/* small lives: about (when you first hear of it), then four steps that move on with the days and with friendship */
LV.LIFE=[
 {about:['I keep bees. Three hives behind the house. They are very well behaved. They are much better behaved than {kin}.'],
  steps:[['The bees have swarmed. Into {kin}\'s hat. With {kin} under it. Nobody was stung. {kin} was mostly offended.'],['First honey of the year! It is dark, like toffee. I have saved you a jar. In my head. In real life {kin} ate it.'],['A fourth hive! The bees built it themselves, in the old well. I did not ask them to. They are expanding. I respect it.'],['I have taught {kin} to keep the bees. {kin} is better at it than me. I am trying to be proud and not jealous. I am both.']]},
 {about:['My {kin} is learning to swim. In the pond. Very badly. A duck who cannot swim. We are a laughing stock.'],
  steps:[['{kin} swam across the pond! Halfway! Then sank, a bit, gracefully. Progress!'],['{kin} swam the whole pond! The WHOLE pond! I cried. In public. I do not care.'],['Now {kin} wants to swim the river. I said no. {kin} said I said no to the pond too. I am losing this argument.'],['{kin} is teaching the little ones to swim now. Very patiently. Patience! From {kin}! I do not know where it came from. Probably from sinking.']]},
 {about:['I am building a boat. In the yard. It does not look like a boat yet. It looks like an argument with wood.'],
  steps:[['The boat has a bottom! A bottom is the most important part of a boat. I learned that by doing the top first.'],['It floats! Sort of! It floats with me in it if {kin} bails!'],['I took it out on the pond. Round once. Then {kin} and me just sat in it, in the middle, not going anywhere. Best afternoon of my life.'],['I am building a second boat. For {kin}. {kin} says it should be called "The Argument". It is a good name.']]},
 {about:['I am writing a song. For {kin}. For the wedding. It is a love song. It is going badly. Everything rhymes with "duck".'],
  steps:[['Verse two is done! It does not rhyme with "duck" any more. It rhymes with "luck". Progress.'],['The wedding is next week! I am going to sing it! I am going to be sick! Both!'],['I sang it. My voice broke on the high bit. {kin} cried. Everyone cried. I am told it was perfect. It was not perfect. It was better.'],['{kin} is expecting! Ducklings! I am writing another song. Everything rhymes with "egg". I am in trouble.']]},
 {about:['I collect buttons. Do not laugh. I have four hundred and twelve. Each one is from somewhere. {kin} thinks it is a waste of drawers.'],
  steps:[['Four hundred and thirteen! A brass one, from a soldier\'s coat. He gave it to me on the road. He said he would not need it.'],['I sewed all of them onto a quilt. Every one. It weighs as much as {kin}. {kin} sleeps under it anyway.'],['A red duck gave me a button! A little carved one, with a flame on it. I put it right in the middle of the quilt.'],['I gave a button to every child in town. One each, from the jar. To start their own. Collecting is for sharing, it turns out.']]},
 {about:['My {kin} is poorly. Coughing all night. I make soup. It is not good soup. I make a lot of it.'],
  steps:[['{kin} is a little better. Coughing only half the night. I have improved the soup. It has a carrot in it now.'],['{kin} sat up and asked for bread! Bread! I ran all the way to the baker and back without a hat!'],['{kin} is up and about and complaining about everything. It is the best sound in the world.'],['{kin} made ME soup yesterday. It was awful. I ate it all. That is how you know someone is better: they start looking after you.']]},
 {about:['I paint. Mostly the pond. Mostly badly. {kin} says I paint water like it owes me money.'],
  steps:[['I painted the dark trees. It came out better than the pond. I do not like what that says about me.'],['A traveller bought one of my paintings! For three crumbs! I would have given it away! I did not tell them that!'],['I am painting people now. {kin} sat for me. {kin} fidgets. The painting fidgets too. It is my best work.'],['I painted the whole town, on the side of the barn. Everybody is in it. I put you in, in the corner, small, walking away. Everybody knows it is you.']]},
 {about:['I am the town\'s worst baker. Everybody says so. I bake anyway. {kin} eats it, out of loyalty.'],
  steps:[['I made a loaf that rose! It ROSE! Then it fell. But it ROSE.'],['{kin} says my bread is "edible". From {kin}, that is a medal.'],['I won the bread prize at the fair! There were two entries. The other one was a stone. Still!'],['The baker asked for my recipe. MY recipe. I did not have one. I made one up on the spot. It is very popular now.']]},
 {about:['My old dog, Biscuit, is very old. We do not know how old. Older than {kin}. Ducks with dogs, I know. Biscuit does not know he is a dog.'],
  steps:[['Biscuit sleeps all day now. In the sun. He follows it round the yard, an inch at a time.'],['Biscuit chased a butterfly! For a whole yard! Then lay down for a day. Worth it, he said. With his face.'],['Biscuit is gone. Last week. In the sun, asleep. {kin} buried him under the apple tree. I keep putting out his bowl.'],['There is a puppy. Do not ask. {kin} found it on the road. It is called Biscuit Two. It is terrible. I love it.']]},
 {about:['I want to see the sea. I never have. {kin} says it is just a big pond. {kin} has never seen it either.'],
  steps:[['I have been saving crumbs. For the sea. Forty so far. It is a long way to the sea.'],['A carter says he will take me most of the way to the sea, in the spring. Most of the way! The rest I can walk!'],['I am going. In a week. I have packed. I have unpacked. I have packed again. {kin} is coming. {kin} pretends not to want to.'],['I saw it. The sea. It is not a big pond. It is the sky lying down. {kin} went in up to the knees and laughed so hard he fell over. I will never be the same.']]},
 {about:['I am the town clock-mender. Every clock in {town}. They are all wrong. I keep them wrong together, so at least they agree.'],
  steps:[['I fixed the square clock! It is right! Now it disagrees with all the others. There has been unrest.'],['{kin} gave me a pocket watch that belonged to a great-grandmother. It has not ticked in sixty years. I am going to make it tick.'],['It ticks! The old watch! It ticked for the first time in sixty years and {kin} and I just sat and listened to it for an hour.'],['All the clocks in {town} agree now. Exactly. It took me twenty years. Nobody has noticed. I have noticed.']]},
 {about:['I am in love with the miller\'s daughter. Do not tell anyone. Everybody knows. {kin} told everybody.'],
  steps:[['She smiled at me! Over the flour sacks! Or at the flour sacks. It was in my direction.'],['I asked her to the fair. She said yes. I said "really?" She said "do not make me take it back."'],['We are walking out together. On Sundays. To the bridge and back. It is the longest walk in the world and the shortest.'],['I asked her. She said yes. Properly yes. {kin} is planning everything and will not let either of us choose a single flower.']]}
];

/* ======================================================================
   DUCKLINGS
   ====================================================================== */
LV.KIDS={
  back:['You came BACK! I knew it. I told everyone.','Where did you GO? Never mind. Hello!','You were gone for ages. I grew. Look.'],
  feathers:A(['YOUR FEATHERS ARE RED. How? Can mine be? Do I have to drink something? I will drink it. I will drink anything. Not soup.']),
  grow:[
    ['I lost a tooth! Ducks do not have teeth. I lost it anyway. It was a pebble. I was keeping it in my mouth.','I can whistle now. Listen. (She cannot whistle.) I can whistle INSIDE.','I am taller. Look. LOOK. I am taller than the bucket.'],
    ['Mama says I am getting too big for the little pond. I am going to the big pond now. With the big ducks. I am going to be very serious.','I can read! Four words. "Duck." "Pond." "No." And "bread". That is all the words you need.'],
    ['I am helping at the bakery now. I mostly eat. But I help. Eating is helping, a bit.','I am nearly as tall as you! On tiptoe. On a box. On tiptoe on a box.'],
    ['I am going to be a detective when I grow up. I have started already. I have solved who took the last biscuit. It was me. Case closed.']
  ],
  news:{
    a2:A(['Papa says there is a red town in the woods. I want to go. Papa says absolutely not. That means maybe.'],['Soldiers went past! I saluted! One of them saluted back! I am going to be a soldier. Or a pond.']),
    a3:A(['The dark trees hummed last night. I hummed back. Mama said do not hum at trees. I said they started it.']),
    a4:A(['Mama counts us every night now. I am always there. I am very easy to count.']),
    a5:A(['The ground went WOBBLE. Did you feel it? I fell over. On purpose. To match.']),
    a6:A(['There is a red boy at the fair who can make sparks with two stones! I am going to marry him. Or be him. One of those.']),
    end:{stay:A(['Nothing is happening anywhere. I checked. Mama says that is good. It is very boring and good.']),any:A(['I have a red friend! She came on the road! She is called Ember and she is EXTREMELY good at hide and seek because she can hide in the red flowers!'],['The scary tree is not scary any more. I climbed it. Mama watched with her eyes shut.'])}
  }
};

LV.installResidents();
})();
