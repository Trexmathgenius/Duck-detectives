'use strict';
/* ===== v1.20 CONSISTENCY PATCHES =====
   Runtime fixes that sit on top of the story engine. The plain text fixes live in the files they belong to;
   this file holds the ones that depend on the route, the chapter or where somebody is standing. */

/* ---------- Quiet hour b9 (Night Watch) on the Crown road ----------
   On that road the gate of Emberwick is sealed to you, so the watch is kept outside the palisade, not on the parapet. */
(function(){
  try{
    const c=S2.ch.b9; if(!c) return;
    const orig=c.intro.slice();
    const crown=[
      'The camp outside Emberwick\'s south gate is quiet. Ruddock has come out through a door in the palisade that is supposed to stay shut, and asked you to take the second half of the night watch with him. He does not say why.',
      'You sit on an upturned bucket with a lantern between you, and the whole sleeping town behind its wall.'
    ];
    Object.defineProperty(c,'intro',{configurable:true,enumerable:true,get(){ let r='red'; try{ r=routeOf(); }catch(e){} return r==='crown'?crown:orig; }});
  }catch(e){ console.error(e); }
})();

/* ---------- Captain Halbeak stands where the objective says he does ----------
   The kingdom NPC list puts him in the Castle Plaza. The Crown chapters send you to him at the Training Yard
   (chapter 7) and at the south wall (chapters 13 and 14), so he goes there while those steps are live. */
(function(){
  let at='';
  const HAL='Captain Halbeak';
  function halSpot(){
    try{
      if(s2at('c7c',0)||s2at('c7c',1)) return {k:'yard',p:[KX+28,KY+30]};
      if(s2at('c13c',2)||s2at('c14c',1)) return {k:'swall',p:[KX+4,KY+36]};
    }catch(e){}
    return null;
  }
  function place(n,x,y){ const p=snapFree(Math.round(x),Math.round(y),3); n.x=(p[0]+0.5)*TS; n.y=(p[1]+0.95)*TS; n.hx=n.x; n.hy=n.y; n.moving=false; }
  const _su=storyUpdate;
  storyUpdate=function(dt){
    try{
      if(g.story&&g.story.s2){
        const sp=halSpot(), key=sp?sp.k:'';
        if(key!==at){
          at=key;
          const n=kNpcList().find(q=>q.name===HAL);
          if(n){ if(sp) place(n,sp.p[0],sp.p[1]); else place(n,KX-8,KY+13); }
        }
      }
    }catch(e){ console.error(e); }
    _su(dt);
  };
})();

/* ---------- only one Mallow in the world ----------
   Several story scenes (the Keeper's Road house, the tower, the Hollow Door, the rim) put their own Mallow on the map.
   While one of those is standing there, the ordinary hermit steps aside. */
(function(){
  const _en=extraNpcs;
  extraNpcs=function(list){
    _en(list);
    let keep=null;
    for(const n of list) if(n.name==='Hermit Mallow'&&n.special==='s2'){ keep=n; break; }
    if(!keep) return;
    for(let i=list.length-1;i>=0;i--){ const n=list[i]; if(n!==keep&&n.name==='Hermit Mallow') list.splice(i,1); }
  };
})();

/* ---------- Quiet hour b7 (Bread) on the Red road ----------
   "Followed the order" means the Crown's march. On the Red road the player never saw that order,
   so Halbeak says what it was instead of assuming you know. */
(function(){
  try{
    const b=BREATH.b7; if(!b) return;
    const crownQ=b.q;
    const redQ='"Do you ever wonder if you are the kind of person who would have done what I did? Marched on a town of children, because a page told me to?"';
    Object.defineProperty(b,'q',{configurable:true,enumerable:true,get(){ let r='crown'; try{ r=routeOf(); }catch(e){} return r==='red'?redQ:crownQ; }});
  }catch(e){ console.error(e); }
})();
