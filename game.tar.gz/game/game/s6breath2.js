'use strict';
/* ===== THREE MORE QUIET HOURS, AND THE ROLL CALL (v1.20) =====
   b8  "Small Things"  - the people you helped, or did not, come back to the fire with what it cost them.
   b12 "The Count"     - after the summit fails, three people from the road come to say what the failure has done to them.
   b18 "Who Came"      - the night before the ward breaks, the ones who earned it come out of the dark. Nobody asked them. */

Object.assign(BREATH_AFTER,{c8r:'b8',c8c:'b8',c12:'b12',c18:'b18'});

/* ---------- a small stage for vignettes ---------- */
function playV(v,next){
  say(v.who,v.pre,()=>{
    const opts=v.opts.filter(turnOK);
    choose(v.who,v.q,opts.map(turnLabel),k=>{
      const o=opts[k]; turnApply(v.tag,o);
      if(o.ok) S6st().stand[v.name]=1; else if(o.ok===false) delete S6st().stand[v.name];
      say(o.who||v.who,o.say,()=>{ coin(); next(); });
    },opts.length-1);
  });
}
function vignettes(list,intro,done){
  const run=list.filter(v=>{ try{ return v.when(); }catch(e){ return false; } });
  const next=()=>{ const v=run.shift(); if(!v){ done(); return; } playV(v,next); };
  if(!run.length){ say('',['Nobody comes tonight. The fire is yours, and the road is quiet, and you are left alone with what you did and did not do.'],done); return; }
  say('',intro,next);
}
const VO=(t,o)=>Object.assign({t},o);
const cx1=(a,b)=>S4.cx(a)||S4.cx(b);

/* ---------- b8: Small Things ---------- */
BREATH.b8={title:'Small Things',sub:'What you did on the road did not stay on the road.',who:'The Fire',
  intro:['The camp is quiet the way a camp is quiet after something has gone right. A few people have found their way to the fire without being sent for.'],
  run(done){ vignettes(V8,this.intro,done); }};
S2.ch.b8={route:'both',theme:'both',numLabel:'A QUIET HOUR',title:BREATH.b8.title,sub:BREATH.b8.sub,intro:BREATH.b8.intro,recap:'Small things, come back.',start(){ s2set(0); },
  obj(s){ return ['Go to the <b>campfire</b> '+campWhere()+'. A few people have come looking for you.'][s]||''; }};
const V8=[
 {name:'Linnet',tag:'v8_linnet',who:'Page Linnet',when:()=>['carry','read'].indexOf(cx1('c6r','c6c'))>=0,
  pre:['(Linnet is at the edge of the light with her messenger\'s cap in both hands.)','"It got there. The quartermaster read it standing up. Then he wrote one line on the back with a stub of pencil and gave it to me for you. It says: Bread first. Then we talk."','"I do not know what it means. I think it means yes." She holds out the page, and then, quieter, "I have not told my mother what I carried. Do I?"'],
  q:'Linnet is eighteen, and has done a very large thing, and is waiting to be told how large.',
  opts:[VO('"Tell her. She will be proud."',{ok:true,led:{kin:1},h:'tender',flag:'told',mem:'told a young messenger her mother should know what she carried',say:['She grins, enormous and uncertain. "I will. I will tell her tonight, before I lose my nerve."']}),
        VO('"Not yet. Let it be a thing that happened first."',{ok:true,led:{trust:1},h:'steady',flag:'held',mem:'told a young messenger to keep her great deed quiet for now',say:['She nods slowly. "A thing that happened first. I like that. I will keep it until it is finished."']}),
        VO('"Never. If anyone learns, you are a spy."',{ok:false,led:{lie:1},h:'guarded',flag:'secret',mem:'told a young messenger her bravery must stay secret forever',say:['She nods. She puts her cap back on. "Yes," she says. "Of course." She is much older than she was when she walked in.']})]},
 {name:'Linnet',tag:'v8_linnet',who:'Page Linnet',when:()=>cx1('c6r','c6c')==='burn',
  pre:['(Linnet comes into the firelight with a small tin in her hands. She holds it out without opening it.)','"I kept the ashes. I do not know why. It seemed wrong to throw them in the river. It was a peace offer. It had a hundred and nine words in it."','"I told them I lost it, like you said. They believed me. It is the worst lie I have ever told."'],
  q:'The tin is warm from her hands.',
  opts:[VO('"I was wrong to tell you to burn it. I am sorry."',{ok:true,led:{truth:1},h:'candid',flag:'sorry',mem:'told a young messenger you were wrong to make her burn it',say:['She breathes out, as though she had been holding it since the road. "Thank you. I thought it was only me who thought it."','She sets the tin by the fire, between you, and neither of you opens it.']}),
        VO('"It was the safest thing."',{ok:false,led:{pride:1},h:'proud',flag:'safe',mem:'stood by an order that made a girl burn a peace offer',say:['"Yes," she says. "It was." She sets the tin back in her bag, and does not look at you again.']}),
        VO('(Say nothing. Sit with her.)',{ok:true,led:{kin:1},h:'tender',flag:'sat',mem:'sat with a messenger who kept the ashes',say:['You sit. She does not speak. After a while she opens the tin, and the two of you look at the pale, soft ash in it for a long time.']})]},
 {name:'Tarn',tag:'v8_tarn',who:'Mim, Tarn\'s daughter',when:()=>['fed','broth'].indexOf(cx1('c7r','c7c'))>=0,
  pre:['(A small girl walks into the firelight with her fist held out in front of her, as though the thing in it might go off.)','"I brought you this. Mama says you are not to say no. It is a shell, from the river. It has a hole in it. You can hear the river in it. You can hear Mama in it, too, if you do not breathe."'],
  q:'Mim is very serious about shells.',
  opts:[VO('Hold it to your ear and listen.',{ok:true,led:{kin:1},h:'tender',flag:'listened',mem:'held a child\'s river-shell to your ear',say:['You listen. You do not breathe. For a moment you hear it: the long soft rush of water, and, under it, a tired voice humming something flat.','"Told you," Mim says, delighted. She sits down beside you, very close, and begins to explain the river.']}),
        VO('Ask her to keep it, and mind the river for you.',{ok:true,led:{trust:1},h:'steady',flag:'keep',mem:'asked a child to keep the shell safe for you',say:['She considers this with great gravity. "That is a job," she says. "I will do it properly." She puts it back in her pocket, and pats it, twice.']}),
        VO('"It is too precious. Keep it for yourself."',{ok:false,led:{mercy:1},h:'gentle',flag:'declined',mem:'turned down a child\'s only gift out of misplaced kindness',say:['Her face does something complicated. "Oh," she says. "Okay." She puts it away carefully, as if she had been told off.']})]},
 {name:'Tarn',tag:'v8_tarn',who:'Mim, Tarn\'s daughter',when:()=>cx1('c7r','c7c')==='refused',
  pre:['(A small girl is standing at the edge of the firelight. She is not supposed to be here. She looks at the ground, and at the pot, and not at you.)','"Mama said not to bother you. She said you were busy. I am not bothering. I am only standing."','"Do you have any bread?"'],
  q:'Mim has been walking for a long time to ask this.',
  opts:[VO('Give her ten crumbs\' worth of bread.',{cost:{crumbs:10},ok:true,led:{mercy:1},h:'gentle',flag:'gave',mem:'gave a hungry child bread you once refused her family',say:['She eats it slowly, with great dignity, all the way down. She says "Thank you" to the last crumb.','You do not say that you are sorry for the road. She says, to the fire, "Mama says it is all right. She says people are tired." You are not sure that is forgiveness. It is as close as the evening will come.']}),
        VO('Walk her home to her mother, and say sorry.',{cost:{hours:1},ok:true,led:{truth:1,kin:1},h:'candid',flag:'walked',mem:'walked a child home and apologised to her mother',say:['Tarn opens the door with a face like a closed window. You say it. She does not say it is all right. She says "Come in, it is cold," which is more.']}),
        VO('"You should not be out here. Go home."',{ok:false,h:'guarded',flag:'sent',mem:'sent a hungry child away from your fire',say:['She goes. She does not run. She is careful not to make a sound, and that is what you will remember.']})]},
 {name:'Quill',tag:'v8_quill',who:'Peddler Quill',when:()=>cx1('c8r','c8c')==='stand',
  pre:['(Quill is selling buttons by the fire, genially, to nobody.)','"They have started bringing me their sick! Can you heal, do you suppose? I said probably. I said you were modest about it."','(A woman stands behind him in the dark with a boy in a blanket. The boy is not well.)'],
  q:'Quill has realised what he did. He is trying not to show it.',
  opts:[VO('Tell her plainly: you cannot heal him. Take him to the herbalist.',{cost:{hours:1},ok:true,led:{truth:1},h:'candid',flag:'plain',mem:'told a desperate mother the plain truth and walked her to the herbalist',say:['She looks at you for a very long moment, and then nods. "I thought so. Thank you for saying." You walk them to the herbalist.','Quill has gone quiet. He has stopped selling buttons. "I have done a foolish thing," he says. He fixes it, in the following weeks, by being the loudest honest man in the street.']}),
        VO('Give her hope and a herb tea.',{ok:false,led:{lie:1},h:'gentle',flag:'hope',mem:'told a desperate mother a kind thing that was not quite true',say:['She cries, from relief. The tea is chamomile. It will not hurt him.','But she will come back, and next time you will have to say the other thing.']}),
        VO('"Quill, undo this. Tell them the truth in the market tomorrow."',{ok:true,led:{truth:1},h:'proud',flag:'undo',mem:'made a peddler undo a flattering story in public',say:['Quill goes pale. "In the market." "Tomorrow." He does it. It takes him all morning, and he sells no buttons, and the crowd likes him better for it.']})]},
 {name:'Quill',tag:'v8_quill',who:'Peddler Quill',when:()=>['correct','credit'].indexOf(cx1('c8r','c8c'))>=0,
  pre:['(Quill has a new patter. You can hear it from the fire.)','"And there were FIVE who did the work, ladies and gentlemen. A page with a letter. A baker with a loaf. A woman with a shovel. And somewhere in the middle, quietly, a detective."','(He comes over, flushed with the telling.) "I have put you sixth. You do not mind?"'],
  q:'Quill is the happiest he has been in years, and does not know why.',
  opts:[VO('"Sixth is right."',{ok:true,led:{trust:1},h:'steady',flag:'sixth',mem:'let a peddler put you sixth in his story',say:['He beams. "Sixth. Splendid." He goes back to his patter, a little taller than before.']}),
        VO('"Put the others first, and give their names."',{ok:true,led:{mercy:1},h:'gentle',flag:'names',mem:'asked a peddler to say the other helpers\' names',say:['Quill nods slowly, and the next morning the street is full of five names, said clearly, one after the other. People who had never been named in public stand a little straighter.']})]}
];

/* ---------- b12: The Count ---------- */
BREATH.b12={title:'The Count',sub:'A failed summit has a bill. It arrives in small coins.',who:'The Fire',
  intro:['The tents have been taken down. The rain has stopped. At the fire, there is a particular quiet, the kind that follows a thing that did not work.','Three people have come to count what it cost them.'],
  run(done){ vignettes(V12,this.intro,done); }};
S2.ch.b12={route:'both',theme:'dark',numLabel:'A QUIET HOUR',title:BREATH.b12.title,sub:BREATH.b12.sub,intro:BREATH.b12.intro,recap:'The count, after the summit.',start(){ s2set(0); },
  obj(s){ return ['Go to the <b>campfire</b> '+campWhere()+'. A few people have come to say what the failure cost them.'][s]||''; }};
const V12=[
 {name:'Wick',tag:'v12_wick',who:'Gatekeeper Wick',when:()=>cx1('c9r','c9c')==='shortcut',
  pre:['(Wick is standing very straight, hat in his hands.)','"The guard whose logbook the shortcut skipped. They found out. He lost his post. His wife had a baby on the Thursday. He sits at the back gate every day, in case there is work."','"I am not blaming you. I told you the way. I am only reporting."'],
  q:'Wick is a man who reports things so he does not have to say how he feels about them.',
  opts:[VO('Give twenty-five crumbs for the baby.',{cost:{crumbs:25},ok:true,led:{mercy:1},h:'gentle',flag:'paid',mem:'paid for the baby of a man your shortcut cost his post',say:['Wick takes the purse as though it were a live coal. "I will see he gets it." "Say it came from me." "I will say it came from a stranger," he says. "It is cleaner."']}),
        VO('Find him a post, even if it takes a day.',{cost:{hours:2},ok:true,led:{trust:1},h:'steady',flag:'post',mem:'spent a day finding a post for a man your shortcut cost his',say:['It takes two hours and some very undignified asking. The Watch needs a night-lamp man at the east gate. The pay is low. The man takes it with both hands.']}),
        VO('"I am sorry. It was a bad bargain."',{ok:false,led:{truth:1},h:'candid',flag:'sorry',mem:'said sorry to a gatekeeper and did nothing else',say:['Wick nods. "I know." The word is a door closing, politely. He puts his hat on and goes.']})]},
 {name:'Wick',tag:'v12_wick',who:'Gatekeeper Wick',when:()=>cx1('c9r','c9c')==='name',
  pre:['(Wick has a small brass badge in his palm. It is plain, worn, stamped with a gate.)','"The guard whose logbook you signed. He asked me to bring you this. He said: I am going to remember this. It will let you through any gate on this side. He is not meant to have given it away."'],
  q:'Wick holds the badge out and does not look at you.',
  opts:[VO('Take it, and thank him.',{ok:true,led:{trust:1},h:'steady',flag:'badge',mem:'accepted a guard\'s brass badge of thanks',say:['The badge is warm from his hand. It is the lightest thing you carry, and it will matter later.','Wick nods. "He said you would say thank you. He said you were the kind." He seems to find this embarrassing.']}),
        VO('Give it back. It might cost him his post a second time.',{ok:true,led:{mercy:1},h:'gentle',flag:'returned',mem:'gave a guard\'s badge back so it could not cost him again',say:['Wick blinks. He turns the badge over. "He said you might do that." He tucks it away. "He said if you did, to say: he is glad he was right about you."']})]},
 {name:'Dobb',tag:'v12_dobb',who:'Watchman Dobb',when:()=>cx1('c10')==='relieved'||S4.cx('c10')==='relieved',
  pre:['(Dobb arrives rested and bright, in a clean tunic. He has the careful posture of a man who has recently slept.)','"I sleep now. I have not slept like it in a year. I wanted to say thank you, and also to say something worse."','"The watch rosters are wrong. No one sleeps more than three nights in seven. It is why I nearly fell. I have said it to the Warden. He listened, which is not like him."'],
  q:'Dobb is deciding whether to be proud of himself or not.',
  opts:[VO('"Say it to the Warden again. Louder."',{ok:true,led:{truth:1},h:'candid',flag:'louder',mem:'told a tired watchman to speak louder about the rosters',say:['"I will," says Dobb, and goes red with the weight of having been told to. The rosters change before the month is out. The Warden does not say whose idea it was.']}),
        VO('"Rest first. The rosters can wait a week."',{ok:true,led:{mercy:1},h:'gentle',flag:'rest',mem:'told a watchman the rosters could wait while he rested',say:['"A week." He considers it. "I think I have not been told I could wait since I was nine." He sits down.']})]},
 {name:'Dobb',tag:'v12_dobb',who:'Watchman Dobb',when:()=>S4.cx('c10')==='sent',
  pre:['(Dobb stands in the firelight, his sword belt missing. He has the stooped, careful look of someone who has been quietly demoted.)','"I was not ill. They know. They did not say. I am on lamp duty now, which is fine. I want to say thank you and I want to say it was the wrong lie."','"A kinder man would have kept the lie. I cannot stop going over it."'],
  q:'Dobb is not angry. That is what makes it hard.',
  opts:[VO('"It was a mistake. I am sorry."',{ok:true,led:{truth:1},h:'candid',flag:'sorry',mem:'told a demoted watchman you had made a mistake',say:['He lets out a long breath. "Thank you. That is the thing I wanted. Not a different lie. Just that."']}),
        VO('Go with him to the captain and tell the truth.',{cost:{hours:1},ok:true,led:{trust:1,truth:1},h:'steady',flag:'truth',mem:'went with a watchman to tell his captain the truth',say:['The captain listens to both of you, and says, "I knew." He puts Dobb back on his post. It takes him an hour to say it.']}),
        VO('"I would do it again."',{ok:false,led:{pride:1},h:'proud',flag:'again',mem:'told a watchman you would lie for him again',say:['Dobb stares at you. "I know you would," he says. He says it the way you say a thing about the weather. He does not come to the fire again.']})]},
 {name:'Dobb',tag:'v12_dobb',who:'Dobb\'s wife',when:()=>S4.cx('c10')==='held',
  pre:['(A woman you do not know stands at the edge of the light with a covered bowl in both hands. She is perfectly polite.)','"I am Dobb\'s wife. He fell at his post. He is in the infirmary. He will be all right. I have brought soup, because that is what I do when I do not know what to do."','She puts the bowl down. She does not sit. "You told him to hold on. He did. That is the kind of man he is."'],
  q:'She is not angry. That would be easier.',
  opts:[VO('Go to the infirmary now.',{cost:{hours:1},ok:true,led:{kin:1},h:'tender',flag:'visited',mem:'went to a watchman\'s bedside after telling him to hold on',say:['He is sitting up, grey, and slightly embarrassed. "I fell on my own spear," he says. "Do not fuss." You sit with him an hour, and neither of you says anything useful. It is exactly right.']}),
        VO('Send a note and a flask of tea.',{ok:false,h:'guarded',flag:'note',mem:'sent a note to a man you had told to hold on',say:['She takes the note. She does not read it in front of you. "I will give it to him." She has the face of someone who has been given a note before.']}),
        VO('(Say nothing.)',{ok:false,silent:true,flag:'silent',mem:'said nothing to the wife of a man you had told to hold on',say:['She waits. When it is clear you will not speak, she picks up the empty bowl and goes. The soup is still warm.']})]},
 {name:'Marta',tag:'v12_marta',who:'Old Marta',when:()=>['walked','told'].indexOf(S4.cx('c11'))>=0,
  pre:['(Old Marta is sitting by the fire as though she had always been there. She has a stick, a blanket, and the look of someone who has arrived at an answer.)','"I said his name at the edge of the wood. Teodor. It is the first time in a hundred years I have said it where he could hear."','"Now I want to say yours. I realised I never asked. What is your mother\'s name?"'],
  q:'Marta waits, as the old do, with no hurry at all.',
  opts:[VO('Tell her, and say a little about her.',{ok:true,led:{kin:1},h:'tender',flag:'told',mem:'told an old woman your mother\'s name',say:['She repeats it softly, twice. "That is a good name for a fire." She says it into the dark, once, to see if it will carry.','You did not know you needed that. You find, in the morning, that you do.']}),
        VO('"I do not know. I never did."',{ok:true,led:{truth:1},h:'candid',flag:'unknown',mem:'told an old woman you did not know your mother\'s name',say:['"Then we will make one for her," says Marta, entirely seriously. "A temporary one. Until we find the real." She chooses "Marigold." It is a ridiculous name. You find you cannot stop saying it.']})]},
 {name:'Marta',tag:'v12_marta',who:'Old Marta',when:()=>S4.cx('c11')==='warned',
  pre:['(Old Marta is sitting at the edge of the firelight. She is not looking at you. She is looking at the dark where the Burnt Wood begins.)','"I went anyway, you know. In the opposite direction at first, for show. Then the right one. I said his name at the edge. I am a hundred and three. I am allowed."','"You were right that it was dangerous. You were wrong that I should go home. Both are true. I wanted to tell you so you could stop doing the arithmetic."'],
  q:'Marta is not being unkind. She is being thorough.',
  opts:[VO('"I am sorry I told you to go home."',{ok:true,led:{truth:1},h:'candid',flag:'sorry',mem:'told an old woman you were sorry for telling her to turn back',say:['"Accepted," she says briskly. "Next time, ask if I am afraid. I will tell you. It will take less time."']}),
        VO('"I was afraid for you."',{ok:true,led:{kin:1},h:'tender',flag:'afraid',mem:'told an old woman you had been afraid for her',say:['She puts her hand over yours. It is dry and light as paper. "I know," she says. "It is the nicest thing about being old, to be afraid for."']}),
        VO('"You would have been safer at home."',{ok:false,led:{pride:1},h:'proud',flag:'safer',mem:'told an old woman she would have been safer at home',say:['"Safer," she says, tasting it. "Yes. That is the word I have heard all my life, from people who were afraid." She gets up with great care and goes to her own fire.']})]}
];

/* ---------- b18: Who Came ---------- */
const ROLL=[
 {n:'Linnet',who:'Page Linnet',ok:()=>!!S6st().stand.Linnet,line:'Linnet, cap on, with a lantern she did not think to hide.'},
 {n:'Tarn and Mim',who:'Tarn Mudd',ok:()=>!!S6st().stand.Tarn,line:'Tarn, with Mim on her hip and a pot of something warm.'},
 {n:'Quill',who:'Peddler Quill',ok:()=>!!S6st().stand.Quill,line:'Quill, for once not selling anything, carrying a bundle of candles.'},
 {n:'Wick',who:'Gatekeeper Wick',ok:()=>!!S6st().stand.Wick,line:'Wick, hat in his hands, with the guard whose logbook you signed, in a borrowed coat.'},
 {n:'Dobb',who:'Watchman Dobb',ok:()=>!!S6st().stand.Dobb,line:'Dobb, in a clean tunic, who has slept.'},
 {n:'Marta',who:'Old Marta',ok:()=>!!S6st().stand.Marta,line:'Marta, with her stick, on the arm of a boy who has agreed to carry her bag.'},
 {n:'Bellis',who:'Trader Bellis',ok:()=>['ended','lent','baked','both'].indexOf(S4.cx('v13'))>=0,line:'Bellis, with a sack of bread and the look of a man who would deny it.'},
 {n:'Nettle',who:'Nettle, a lantern-lighter',ok:()=>['owned','waited','lit','kind','apologised'].indexOf(S4.cx('v15'))>=0,line:'Nettle, with a taper and the clay lamp, small as a thought.'},
 {n:'Fenn',who:'Private Fenn',ok:()=>['stands','home'].indexOf(S4.cx('v17'))>=0,line:'Fenn, in his best helmet, with a cake wrapped in a cloth.'},
 {n:'Orrin',who:'Baker Orrin',ok:()=>['queue','army'].indexOf(cx1('c16r','c16c'))>=0,line:'Orrin, with a basket, counting aloud under his breath.'}
];
const rollCall=()=>ROLL.filter(r=>{ try{ return r.ok(); }catch(e){ return false; } });
const rollMiss=()=>ROLL.filter(r=>{ try{ return !r.ok(); }catch(e){ return true; } });

const ROLLX={
 Linnet:()=>({told:'Her mother is a few paces behind her in a shawl, fierce and small, holding a lantern of her own. Neither of them says anything. Both stand very straight.',held:'She hands you a pencil stub. "The quartermaster\'s. He said you would know what to write, when it was time."',sorry:'She has pressed the ashes from the tin into the base of her lantern. "So it burns with what it was meant to."',sat:'She does not speak. She stands beside you, and when you look, she is holding the tin.'})[S4.cx('v8_linnet')],
 Tarn:()=>({listened:'Mim holds the shell to your ear before you can ask. "Told you," she whispers. "You can hear the river."',keep:'Mim pats her pocket twice, to show you the shell is safe. She is extremely proud of the job.',gave:'Mim has brought you a heel of bread in a cloth. It is half a day stale. It is the best bread you have ever been given.',walked:'Tarn nods to you across the clearing, once, the way you nod to someone you have decided to trust.'})[S4.cx('v8_tarn')],
 Quill:()=>({plain:'He has stopped selling anything. He tells whoever stands near him exactly what happened in the market, in a plain voice, and it is the best patter he has ever done.',undo:'He says to anyone who will listen, "I told them a story once and it nearly cost a boy his chance. I have learned to say less and mean more." He means it.',sixth:'He says he is "only sixth," loudly, with obvious pleasure. It is, you reflect, a fair place to be.',names:'He recites the five names, one after the other, before anything else. Then yours, sixth. He does it every night now.'})[S4.cx('v8_quill')],
 Wick:()=>({badge:'You still have the brass badge. Wick says the guard sent a message with him: it opens any gate on this side, and any door you decide to be honest at.',returned:'The guard stands beside him in a borrowed coat. He nods to you and says nothing. It is the most eloquent nothing of the night.',paid:'The guard\'s baby is on Wick\'s shoulder, sound asleep. "He said you would not want thanks," says Wick. "I told him I would deliver it anyway."',post:'The man you found a post for is carrying a lamp. "East gate," Wick says. "Nine nights out of ten, nobody comes. He says it is the best job he has ever had."'})[S4.cx('v12_wick')],
 Dobb:()=>({louder:'Dobb is awake and unhurried, with a flask. He says the new rosters start on Monday and that he intends to sleep through the whole of Tuesday.',rest:'Dobb has brought a folding stool, and sits down on it, and immediately falls asleep, and then wakes, and says "I am so sorry," and falls asleep again. It is the most beautiful thing you have seen.',sorry:'He stands beside you, not quite touching, as a man stands who has decided to be near. "I am not on duty," he says. "I am here."',truth:'He has been put back on his post, and has swapped it for a night. "I wanted to be somewhere I had chosen," he says.',visited:'He is leaning on his wife, who is leaning on him, and neither of them is pretending not to.'})[S4.cx('v12_dobb')],
 Marta:()=>({told:'She says your mother\'s name into the dark, once, to see if it will carry. It does.',unknown:'She calls you "Marigold\'s child," aloud, once, with great ceremony, and is delighted with herself.',sorry:'She sits on a stump and announces that it is the best seat in the clearing. She is probably right.',afraid:'She takes your arm without asking, as the old do, and does not let go until it is time.'})[S4.cx('v12_marta')],
 Bellis:()=>({ended:'He puts the sack down and says it is flour, and not a gesture. Nobody believes him.',lent:'He says the bakery is called "Rather Fair." He has already burned two batches.',baked:'He has brought a loaf. It is only slightly burnt. It is, he insists, an improvement.',both:'He says the fine was exactly what he deserved, and the bread is exactly what he owes.'})[S4.cx('v13')],
 Nettle:()=>({owned:'She has the taper in one hand and the clay lamp in the other. She says she lit the last lantern slowly tonight, with both hands, for the first time since her father left.',waited:'She sits on the ground with her back against your leg, as though you were a tree.',lit:'She lights your lamp from hers, and the two flames lean together.',kind:'She says your clay lamp is the first thing she has ever made that someone kept.',apologised:'She hands you the taper without a word. The last lantern is yours to light, and she is going to watch.'})[S4.cx('v15')],
 Fenn:()=>({stands:'He stands at attention, badly, in a helmet that does not fit. "At the back," he says. "As promised."',home:'He has brought his mother, who has brought a second cake, and who is looking at you very hard.'})[S4.cx('v17')],
 Orrin:()=>({queue:'He counts the loaves under his breath and gets, every time, the right number.',army:'He has brought a basket for the line and another for the queue. "I am not choosing," he says. "I am only carrying."'})[cx1('c16r','c16c')]
};
BREATH.b18={title:'Who Came',sub:'Nobody was sent for. Word travels.',who:'The Edge Of The Wood',
  intro:['It is the night before the ward breaks. The edge of the Burnt Wood is dark, and it is warmer than it ought to be.'],
  run(done){
    const here=rollCall(), miss=rollMiss();
    const lines=here.map(r=>{ let x=''; try{ x=ROLLX[r.n.split(' ')[0]]()||''; }catch(e){} return '('+r.line+')'+(x?' '+x:''); });
    const pages=['(They come out of the dark one at a time, along the road you made, not because anyone sent for them but because word travels, and they heard.)'].concat(lines.length?lines:['(Nobody comes. The edge of the wood is very large.)']);
    if(here.length&&here.length<ROLL.length) pages.push('(There are others you half expected. You notice who is not here. Nobody says it.)');
    say('',pages,()=>{
      S6st().rollN=here.length;
      if(!here.length){ say('',['You sit at the edge of the wood and listen to it hum. It is a very long night. It will end in the morning, and the morning will not ask who was missing.'],done); return; }
      const opts=['"Stand with me at the anchors. It may be dangerous."','"Wait at the edge of the wood. I will call if I need you."','"Go home. This is mine to carry."'];
      choose('The Edge Of The Wood','They are waiting for you to say what they came for.',opts,k=>{
        const mode=['hold','edge','home'][k]; S6st().rollMode=mode;
        const extra={hold:[ 'They take their places in the dark without being told twice. Linnet holds the lantern. Tarn passes the pot. Nobody speaks, and every one of them is afraid, and every one of them is here.','It is not a plan. It is a ring of people, which is better than a plan.'],
                     edge:[ 'They sit at the edge of the wood in a long row with their backs to the trees, and watch the road. It is a sensible thing to do. It is also, you realise, a way of being close without being in the way.'],
                     home:[ 'They go, one by one, quietly. Nobody argues. The road is dark when they are gone, and the fire is much smaller than it was.']}[mode];
        if(mode==='hold'){ S4st().h.steady++; s2led('trust',1); S6.cap('sleepers',1); }
        if(mode==='edge'){ S4st().h.guarded++; }
        if(mode==='home'){ S4st().h.proud++; s2led('pride',1); S6.cap('sleepers',-1); }
        S4.setcx('roll',mode,mode==='hold'?'asked everyone who came to stand with you at the anchors':mode==='edge'?'let everyone who came wait at the wood\'s edge':'sent everyone who came back home');
        say('',extra,()=>{ coin(); done(); });
      },2);
    });
  }};
S2.ch.b18={route:'both',theme:'both',numLabel:'A QUIET HOUR',title:BREATH.b18.title,sub:BREATH.b18.sub,intro:BREATH.b18.intro,recap:'The ones who came.',start(){ s2set(0); },
  obj(s){ return ['Meet the people at the <b>edge of the Burnt Wood</b>. They have come unasked.'][s]||''; }};

/* the roll call changes what the ring can do at the anchors */
const RING=()=>{
  const out=[], a=A5();
  if(a.hal==='back'||a.hal==='needed') out.push({n:'Halbeak',secs:12,line:'Halbeak takes the north line without being asked, sword sheathed, hands open.'});
  if(!S6.lost('Ruddock')&&S4.cx('v17')!=='pulled') out.push({n:'Ruddock',secs:12,line:'Ruddock plants his spade in the ash at the east anchor and does not move from it.'});
  if(['letter','told','carry'].indexOf(a.poppyEnd)>=0) out.push({n:'Poppy',secs:8,line:'Poppy sits down under the third anchor with her father\'s boot in her lap and hums the second verse.'});
  if(a.brand==='heard'||a.brand==='helped') out.push({n:'Brand',secs:8,line:'A red hood moves between the wisps, always one step ahead of their lamps. Brand does not look at you.'});
  return out;
};
{
  const d=SX.defs.wardsc, _oe=d.onEnter;
  d.onEnter=function(S){
    _oe.call(this,S);
    try{
      const ring=RING(), mode=S6st().rollMode, n=S6st().rollN||0;
      let bonus=ring.reduce((s,r)=>s+r.secs,0);
      if(mode==='hold') bonus+=Math.min(60,n*6);
      if(mode==='edge') bonus+=Math.min(20,n*2);
      if(S.timer&&bonus>0){ S.timer.t+=bonus; S.timer.max+=bonus; }
      S6st().ringBonus=bonus;
      const pages=ring.map(r=>'('+r.line+')');
      if(mode==='hold'&&n) pages.push('(And around the clearing, small and frightened and holding lanterns, '+n+' people from the road.)');
      if(pages.length) sayWhenFree('',pages,null,3500,()=>SX.S===S);   /* only if you are still in the Ring, and never over a menu */
    }catch(e){ console.error(e); }
  };
}

/* the people from the road, at the end */
const S6PHR={
  Linnet:{wake:'handed out lanterns, one by one, to the waking',door:'carried the first letter through the door',keep:'wrote the names of the waking on a long strip of paper',stay:'walked the road home with her cap in her pocket'},
  Tarn:{wake:'passed the pot, and Mim passed the spoons',door:'sat on the threshold with Mim asleep in her lap',keep:'cooked for a hundred, badly and joyfully',stay:'went home and put the kettle on'},
  Quill:{wake:'told the story, truthfully, to anyone who would listen',door:'told it with the other names first',keep:'sold buttons to the sleepers, who did not need them, and gave them away',stay:'told nobody anything, which for him was heroic'},
  Wick:{wake:'held the road open with his hat',door:'closed the door behind everyone, softly, in the old gatekeeper\'s way',keep:'brought the logbook and entered everyone\'s name',stay:'closed the gate behind you and left it unlatched'},
  Dobb:{wake:'stood the watch for the whole night, and was relieved at dawn',door:'stood at the door, awake, for the first night',keep:'slept in a chair, at last, in a ring of chairs',stay:'saluted you as you left'},
  Marta:{wake:'said every name she could find, aloud, at the edge',door:'walked through slowly, with a boy carrying her bag',keep:'sat in the oldest chair and told the sleepers about Teodor',stay:'went home, entirely satisfied'},
  Bellis:{wake:'brought bread, which he denies',door:'sold the first fair-priced loaf to the first through the door',keep:'kept the till, honestly, for once',stay:'sent grain to the gate, anonymously and poorly disguised'},
  Nettle:{wake:'lit the last lantern, slowly',door:'lit the lamp by the door',keep:'brought the clay lamp and set it on the third chair',stay:'lit one for the road'},
  Fenn:{wake:'stood at the back, with a cake',door:'stood at the door in his best helmet',keep:'brought his mother, and his mother brought a second cake',stay:'ploughed the field the day you left'},
  Orrin:{wake:'broke the first loaf into pieces so small, and counted aloud',door:'baked the first loaf for whoever came through',keep:'kept the bread table',stay:'left a loaf at the gate'}
};
const S6extra=()=>{
  const out=[];
  for(const r of rollCall()){ const key=r.n.split(' ')[0]; if(S6PHR[key]) out.push({n:r.n,w:S6PHR[key]}); }
  return out;
};

/* Brand, at the fire: what you did in chapter 8 is the first thing he says */
{
  const base=BREATH.x16.scene[0][1].slice();
  BREATH.x16.prep=function(){
    const t8=S4.cx('t8'), pre=[];
    if(s2red()){
      if(t8==='court') pre.push('"You sent me before the Hearth in public. I want you to know that I understood why. It was not kind. It was correct. I have been trying to be grateful for correct."');
      if(t8==='free') pre.push('"You let me walk, with a warning. I did not deserve it. It is the only reason I am here tonight, asking to be looked at instead of hiding."');
      if(t8==='kept') pre.push('"You brought me supper yourself. Nobody has brought me supper since my sister. I have not forgotten. It is why I am telling you first."');
    }
    BREATH.x16.scene=[['Keeper Brand',pre.concat(base)]];
  };
}
/* Ruddock, if you pulled rank, is not at the council */
{
  const r=S2.npcs.find(d=>d.id==='ruddock_a');
  if(r){ const w=r.when; r.when=()=>(!w||w())&&S4.cx('v17')!=='pulled'; }
}
