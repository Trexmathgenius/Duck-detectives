'use strict';
/* ===== LOOSE ENDS (v1.22) =====
   Things the early chapters set up that nothing picked up again:
   the lost memory, the clerk who hid the book, Elder Umber, and the answers you gave that nobody remembered. */

/* ---- the lost memory: the Burnt Wood hums, and your first answer is the one it answers ---- */
{
  const WOOD=[
    'The Wood hums four slow notes. You told the Warden you came from Mallardia, and for the first time you wonder what Mallardia hums.',
    'The Wood hums four slow notes, and you know them. You cannot say from where. You told the Warden you woke in a forest and did not know. The tune does not argue. It only knows you.',
    'The Wood hums four slow notes, with a lean to them that goes south, as though somewhere across the river a window had been left open.',
    'The Wood hums four slow notes. It does not ask where you are from. You notice this at once, and notice that noticing is a kind of answer.'
  ];
  const _begin=S2.begin;
  S2.begin=function(id,skip){
    try{
      if(id==='c17'){
        const c=S2.ch.c17; c.__i0=c.__i0||(c.intro||[]).slice();
        if(c.__wl){ const i=c.__i0.indexOf(c.__wl); if(i>=0) c.__i0.splice(i,1); c.__wl=null; }
        const f=P1().from, line=WOOD[f];
        if(line){ c.__i0.push(line); c.__wl=line; }
      }
    }catch(e){ console.error(e); }
    return _begin(id,skip);
  };
}

/* ---- the clerk who hid the book: the Whistles have been clerks for a hundred years ---- */
S2.prop({id:'hall_clerk',wx:SW_WP.hall.x+2,wy:SW_WP.hall.y+1,glyph:'grave',col:'#a89c80',when:()=>s2at('c16x',4),mark:()=>k3('hn_clerk')?null:'?',use(){
  if(k3('hn_clerk')){ say('',['Ennis Whistle, copyist. The pen in the brick is still cut deep. Beside it, the single word, which has been dusted by someone.']); return; }
  seq([['',['At the foot of the last row, set a little apart as if someone were not sure it belonged, there is a brick cut in a small, neat, frightened hand.','Ennis Whistle, copyist. "He could not carry the Edict, and could not drop it. He hid the pages in three places, and the way to them in a book that nobody would borrow."','Under the name, a single word: later.']]],()=>{
    k3('hn_clerk',1); s2led('truth',1); coin(); hudCache.obj=null;
    toast('The clerk who hid the Red Book was a Whistle.',3600);
  });
}});
rc(['Clerk Whistle'],'rc_clerk',()=>!!k3('hn_clerk'),['(Whistle has stopped straightening the paper.)','"They tell me you went to the Hall. There is a brick there. I have not had the courage to read it. In my family we were told he was a bad copyist."','"I should like to hear that he was a brave one. If you cannot say it truthfully, say nothing. I will understand."']);
echo('eclerk',17,()=>!!k3('hn_clerk')&&!!k3('whistle'),'Clerk Whistle',['"I wrote it down," Whistle says. "On the back of the Chair\'s minutes, in the margin, where nobody reads. The word is: brave."','"I do not know if it is true. But I have decided it is the kind of thing that is true if enough people write it."']);

/* ---- Elder Umber writes back ---- */
{
  const NOTE='(A child you have never met hands you a note, folded small, smelling of mushrooms. The handwriting is large and careful: the script of someone who learned to write without seeing the page.)';
  const U=[
    '"You told me the Elders would only trust you if you did it. I gave you the recipe anyway. I hope that someone, by now, trusts you for no reason at all."',
    '"You said you wanted to know what it is to be hunted, and then to be at home. I have been wondering, these months, which half you are in. I hope the second."',
    '"You told me honestly that you were not sure. Almost nobody has said that to me. I want you to know I wrote it down, in the only way I can: I remembered it."',
    '"You told a blind man you came to spy for the king. I told the Elders nothing, which I think you knew I would. I cannot see your face. I hope it is the face of someone who stopped."'
  ];
  for(let k=0;k<4;k++) echo('eumber'+k,12,()=>P1().umber===k,'Elder Umber',[NOTE,U[k]]);
}

/* ---- the answers nobody remembered ---- */
rc(['Archivist Sorrel'],'rc_why0',()=>P1().why===0,['"I wrote down why you said you came. A tale in Puddlewick. I have thought, since, that every town has one of those, and that none of them is ever the whole reason."']);
rc(['Archivist Sorrel'],'rc_why1',()=>P1().why===1,['"You told the Elders the castle was shut and something was wrong at its heart. I wrote that down. It is the only answer that evening that was about somebody other than yourself."']);
rc(['Archivist Sorrel'],'rc_why2',()=>P1().why===2,['"You said you were a detective and followed mysteries. I wrote it down. You will notice I have not asked what kind of mystery you are."']);
rc(['Archivist Sorrel'],'rc_why3',()=>P1().why===3,['"A vision called you. I wrote that down in the margin, with a question mark. I would like to take the question mark out. That is a thing I do not say often."']);
rc(['Warden Ruddock'],'rc_exp0',()=>P1().explain===0,['"You told me you did not know how to say it to a child. I have thought about that more than I expected. I would have done the same, and I have the grey hair to prove I have not."']);
rc(['Warden Ruddock'],'rc_exp1',()=>P1().explain===1,['"When I caught you out, you told me the true thing straightaway. I have known worse orders of events."']);
rc(['Warden Ruddock'],'rc_exp2',()=>P1().explain===2,['"You said nothing, when I asked you to explain. I have sat in that silence a number of times myself. It is not a lie. It is not a rest either."']);
rc(['Captain Halbeak'],'rc_purse1',()=>P1().purse==='took',['"The king\'s purse. Three hundred. I saw it in the ledger, in the column marked things for which a man is paid. I would not worry. I only note which column."']);
rc(['Captain Halbeak'],'rc_purse2',()=>P1().purse==='left',['"You left the purse on the table. A servant told the quartermaster, who told me. The king has not yet decided whether to be insulted. I think he is, a little, relieved."']);
