'use strict';
/* ===== v1.28: FACTIONS THAT ANSWER, QUIET HOURS THAT DEPEND ON YOU, AND AN EPILOGUE THAT KNOWS WHO YOU WERE =====
   1. Faction arcs. The four standings the story already kept (hearth, crown, mallow, sleepers) were only counters. Each now has
      two scenes unlocked by how high it is, and you choose a reward in each: a recipe, a tool, rare stock in the shops, or to give
      it away. The crown has a third, for people the Crown has come to dislike.
   2. Four optional quiet hours (b6, b10, b14, b16). Each only happens if the ledger says it should: a mercy streak, a habit of
      tidy lies, a taste for being right, or a table that has fed a lot of people.
   3. A "What the Road Remembers" page in the journal and an epilogue that names the people, rather than just the last few
      memories. Choices that mattered most come first. People who asked and were passed by are in it too. */
(function(){
'use strict';
const D10=window.D10=window.D10||{};
const P=(b,w,h)=>({body:b,wing:w,bill:h||'#e6c441'});
const cap=k=>{ try{ return S6.get(k); }catch(e){ return 0; } };

/* ---------- 1. faction arcs ---------- */
D10.reqAdd([
 { id:'oats1', a:8, b:19, if:()=>cap('hearth')>=2, who:[`Granny Pease, the camp matriarch`,P('#c9a06a','#8a6a3a'),'scarf'],
   brief:`The camp wants to say thank you. You may choose how.`,
   intro:[`(An old woman with arms like a baker's stands in front of the hearth with the camp behind her, trying to look as though they have not arranged this.)`,`"We do not make speeches. We make dinners. But we have been told that a person who feeds people ought to be fed, and we have had a meeting about it, which is rare."`,`"There is something we would like to give you. You may choose which. I am told it is polite to hesitate."`],
   q:`Granny Pease folds her arms, and waits for you to hesitate properly.`,
   gone:`(The camp had a meeting about you, and decided to do it next year. They did not.)`,
   opts:[
    {t:`Take the recipe the camp cooks when it decides to look after someone.`,habit:'gentle',led:{trust:1,kin:1},fx:{recipe:'campbroth'},flag:'recipe',mem:`was given the camp's own recipe for looking after someone`,
     say:[`She writes it on the back of a ration tag, in a hand like a row of potatoes. "Mushrooms," she says. "Flowers. A reason. You cannot brew it without the reason."`]},
    {t:`Ask for nothing. Sit at their table with them.`,need:{hours:1},habit:'tender',led:{kin:1,mercy:1},cap:{hearth:1},fx:{unlock:'hearth'},flag:'table',mem:`sat at the camp's table when you were offered a prize`,stand:true,
     say:[`They are unsettled, then delighted. A bowl appears. The table makes room, which tables do not do, in general, until someone has said something.`,`Afterwards, several people mention to the baker that you were easy to feed, and the baker puts something extra in the back room.`]},
    {t:`Take the tins of stew for the road.`,habit:'steady',led:{trust:1},fx:{give:{campstew:3}},flag:'tins',mem:`took the camp's stew for the road`,
     say:[`They are heavy tins, with a handle each. "For the day you are very tired," says Granny Pease. "Not before. We shall know."`]}]},
 { id:'oats2', a:12, b:19, if:()=>cap('hearth')>=4, who:[`Granny Pease, the camp matriarch`,P('#c9a06a','#8a6a3a'),'scarf'],
   brief:`Granny Pease has something old and heavy for you, and a question about it.`,
   intro:[`(Granny Pease stands beside a pot that is much too large for the fire it is sitting on. She is not smiling, in the way people don't when they are about to be generous.)`,`"This pot fed the first camp, the one before the one before. Ten winters of stew in its bones. It does not belong to a person. It belongs to the fire."`,`"I should like to give it to the one who has done the most for the fire. I do not think that is anyone else but you. But it is your decision, and I shall not be offended."`],
   q:`She puts a wing on the pot, and it clangs, very faintly, like a thing agreeing with her.`,
   gone:`(The pot stayed with the camp. It is still on the fire. It was a good pot.)`,
   opts:[
    {t:`Accept the pot. It should be cooked with.`,habit:'steady',led:{trust:1},fx:{item:'cookpot'},flag:'pot',mem:`took a camp's oldest pot as thanks`,
     say:[`She hands it over with a small, stiff bow. "It is heavy," she says. "That is how you know it is good."`,`It is a dented, ugly, wonderful thing, and it smells of onions, rain and being fed.`]},
    {t:`Leave it with the camp. It belongs to the fire.`,habit:'tender',led:{kin:1,mercy:1},cap:{hearth:1},fx:{unlock:'hearth'},flag:'leave',mem:`left a camp's oldest pot with its fire`,stand:true,
     say:[`She stares at you, and her mouth works for a moment. "Well," she says. "That is what I hoped you would say."`,`She puts a small cloth bundle in your wing. In it is the camp's other treasure: a handful of salt, wrapped in a handful of thanks.`]},
    {t:`Ask her to teach you the first recipe instead.`,need:{hours:2},habit:'candid',led:{truth:1,kin:1},fx:{recipe:'campbroth'},flag:'teach',mem:`asked to learn the camp's first recipe`,stand:true,
     say:[`It takes two hours, and a quantity of stirring. She does not say anything while she does it. At the end she tastes it and says, "Mm. Hm," which in her is a great deal.`]}]},

 { id:'wrenfeld1', a:8, b:19, if:()=>cap('crown')>=1, who:[`Lady-Clerk Wrenfeld`,P('#8a7ab0','#6a5a90'),'hat'],
   brief:`A senior Crown clerk has noticed you did right by someone. She has a small offer.`,
   intro:[`(A woman in a very good coat is standing a precise distance from you, with a letter of introduction held in both wings like a menu.)`,`"I am told you have done a number of things, lately, that a Crown clerk would call correct. Rudge's paper. A girl's stall. A thing or two of the sort."`,`"The Crown notices. Often late, and almost never in time. It would like to say so. I am the one who says so."`],
   q:`She does not smile. She raises, very slightly, one eyebrow, which in her is the same thing.`,
   gone:`(A letter of thanks from the Crown arrived at the camp, addressed to "the duck who did the correct thing." You never saw it.)`,
   opts:[
    {t:`Accept the letter of passage. It will help with shops and tolls.`,habit:'steady',led:{trust:1},fx:{pay:0.03},flag:'letter',mem:`accepted a Crown letter of passage`,
     say:[`She hands it over with a stamp, and watches it be put away, as one watches a promise being made.`,`"It will open nothing it should not," she says. "That is the point of it."`]},
    {t:`Take the court recipe: a cordial that makes shopkeepers listen.`,habit:'gentle',led:{trust:1,kin:1},fx:{recipe:'courtcord'},flag:'recipe',mem:`took a recipe from a Crown clerk`,
     say:[`She writes it carefully on a sealed card. "A Courtier's Cordial. It does not lie. It merely reminds everyone present that you are worth listening to."`]},
    {t:`Decline. The Crown owes you nothing.`,habit:'proud',led:{pride:1,truth:1},flag:'decline',mem:`refused a thank-you from the Crown`,
     say:[`Her eyebrow rises another fraction. "How very unusual," she says. "I shall have to put it in the margin."`]}]},
 { id:'wrenfeld2', a:12, b:19, if:()=>cap('crown')>=3, who:[`Lady-Clerk Wrenfeld`,P('#8a7ab0','#6a5a90'),'hat'],
   brief:`The Crown has something for you. It has conditions.`,
   intro:[`(Lady-Clerk Wrenfeld has brought a small lacquered box, a seal, and an escort of one rather uncomfortable page.)`,`"The Crown does not give gifts. It issues instruments. This is a writ. It says the bearer has done the Crown a service, and that clerks at all counters are to read it before arguing."`,`"There is a small matter of what it means to carry one. I shall be frank: some will think you the Crown's. Some will think you theirs. Both will be partly right."`],
   q:`She opens the box. The writ is inside, flat, pale and quite heavy for its size.`,
   gone:`(The writ went back to the Crown's drawer. Wrenfeld says it will keep.)`,
   opts:[
    {t:`Accept the writ. You earned it.`,habit:'steady',led:{trust:1},cap:{crown:1},fx:{item:'crownwrit'},flag:'writ',mem:`carried a Crown writ`,
     say:[`She puts it in your wing with the deliberateness of a woman performing an operation. "It will make some things easier," she says, "and some things not."`]},
    {t:`Accept it for someone else: ask it to be sent to Rudge.`,habit:'tender',led:{kin:1,mercy:1,trust:1},cap:{crown:1},flag:'pass',mem:`asked a Crown writ be sent to a ferryman`,stand:true,
     say:[`Her mouth makes a small, tight shape. "That is not what the instrument is for," she says. She writes Rudge's name on the back anyway. "Nobody has ever asked."`]},
    {t:`Decline it. You want no one's colours.`,habit:'candid',led:{truth:1,pride:1},flag:'decline',mem:`turned down a Crown writ, to stay your own duck`,
     say:[`"Mm," she says, and closes the box. "I shall not argue. A good clerk never argues with a clean answer." She sounds, strangely, relieved.`]}]},
 { id:'notice', a:10, b:19, if:()=>cap('crown')<=-1, who:[`Clerk of Debts`,P('#6a6a7a','#4a4a5a'),'helm'],
   brief:`The Crown has noticed you too, and is sending a bill.`,
   intro:[`(A clerk of the Crown's Debt Office, with a ledger and a face like a closed door, approaches you at the edge of the camp.)`,`"I am here about a matter of conduct. Several of the Crown's officers have filed notes, and the notes use the word 'unhelpful' with unusual frequency."`,`"There is a sum, and there is a way of discussing the sum. I am prepared to do either."`],
   q:`He turns a page in the ledger. It makes a small, final noise.`,
   gone:`(A notice of debt was filed against your name. The Crown has long memories and a weak filing system.)`,
   opts:[
    {t:`Pay the sum.`,need:{crumbs:40},habit:'steady',led:{trust:1},cap:{crown:1},flag:'paid',mem:`paid the Crown's bill for your conduct`,
     say:[`He writes the receipt with the economy of a man who has done so many. "Thank you," he says. "That does not mean I like you. It means the page is closed."`]},
    {t:`Discuss it. Explain what was done, and why.`,need:{hours:1},habit:'candid',led:{truth:1},cap:{crown:1},flag:'discuss',mem:`argued your case to the Crown's Debt Office`,stand:true,
     say:[`It takes an hour. You are unfailingly plain. At the end he closes the ledger. "I do not entirely agree," he says. "But I understand the order in which things happened. That is worth something."`]},
    {t:`Ignore the notice.`,habit:'proud',led:{pride:1},fx:{cold:2},flag:'ignore',mem:`ignored a Crown bill`,
     say:[`He closes the ledger, quietly. "As you like," he says. "The Crown shall be informed." He does not sound surprised.`]}]},

 { id:'teasel1', a:9, b:19, if:()=>cap('mallow')>=1, who:[`Teasel, Mallow's messenger`,P('#7a9a7a','#5a7a5a'),'hood'],
   brief:`Mallow has sent his messenger with something he swore never to write down.`,
   intro:[`(A small duck with a satchel and an enormous hat stands on a stump to be heard.)`,`"Hermit Mallow sent me. He says: this is the recipe he swore never to write down, and has now written down, and would like you to burn if it goes wrong."`,`"He also says you will want to say something clever. He says please do not."`],
   q:`Teasel holds out a folded paper in one wing and a tin in the other, and visibly regrets both.`,
   gone:`(Mallow burned the recipe himself, in the end. He says it was lighter, afterwards.)`,
   opts:[
    {t:`Take the recipe, with thanks.`,habit:'steady',led:{trust:1},fx:{recipe:'mosstea'},flag:'recipe',mem:`was given a hermit's unwritten recipe`,
     say:[`The paper smells of woodsmoke. The writing is cramped and kind. "Stumps," it says. "Mushrooms. Do not rush. A reason is optional."`]},
    {t:`Ask Teasel to bring Mallow's thanks instead, and go and sit with him.`,need:{hours:2},habit:'tender',led:{kin:1,mercy:1},cap:{mallow:1},fx:{recipe:'mosstea'},flag:'visit',mem:`sat with a hermit instead of taking his recipe`,stand:true,
     say:[`You sit with him for two hours and do not say much. At the end he hands you the recipe himself, with a look that has no speeches in it.`]},
    {t:`Send it back. A hermit should keep what he swore to.`,habit:'proud',led:{pride:1,truth:1},flag:'back',mem:`sent a hermit's recipe back unopened`,
     say:[`Teasel stares at you. "He said you might," he says. "He said I should say: good. And then he said nothing for a while."`]}]},
 { id:'teasel2', a:13, b:19, if:()=>cap('mallow')>=2, who:[`Teasel, Mallow's messenger`,P('#7a9a7a','#5a7a5a'),'hood'],
   brief:`Mallow has sent his boots, and a message about walking.`,
   intro:[`(Teasel arrives staggering slightly under a pair of boots that are rather bigger than he is.)`,`"Mallow says: these are the second-best boots in the world. The best pair he was buried in, forty years ago, in his mind. He says you should have them."`,`"He says they are exactly one size too large, which is the right size for walking a long way."`],
   q:`The boots stand on their own, in the manner of boots that have done a great deal.`,
   gone:`(The boots went back to the hermit. He is said to be walking in them, in the evenings, in a small circle.)`,
   opts:[
    {t:`Take the boots. They are good.`,habit:'steady',led:{trust:1},fx:{item:'hermitboots'},flag:'boots',mem:`took a hermit's boots for the long road`,
     say:[`They fit, after a while. They smell of cedar, and time, and a number of places you have not been.`]},
    {t:`Ask for the story of the best pair instead.`,need:{hours:1},habit:'candid',led:{truth:1,kin:1},cap:{mallow:1},flag:'story',mem:`asked a hermit for the story of his boots`,stand:true,
     say:[`Teasel tells it, haltingly, as he was told it. It is about a road, and a promise, and a wedding that did not happen. Halfway through, the boots seem to shift on the ground, as if listening.`]}]},

 { id:'thistle1', a:12, b:19, if:()=>cap('sleepers')>=2, who:[`Linden, a woken sleeper`,P('#a09ac0','#807aa0'),'scarf'],
   brief:`A sleeper who stirred early has something for you.`,
   intro:[`(A young duck in a nightgown of an older fashion stands among the cots, blinking, holding a small shuttered lantern in both wings.)`,`"I woke up on Tuesday. I was meant to wake in the spring. The nurse says it is a great nuisance, and she is thrilled."`,`"I was dreaming something, as I woke. It was about you. It was a strange dream, and it ended with me being given this to give you."`],
   q:`Linden holds out the lantern. It hums, very faintly, like a held breath.`,
   gone:`(Linden went back to sleep, in the end, in the usual way. The nurse says she dreams mostly of cake.)`,
   opts:[
    {t:`Take the lantern. It is a gift.`,habit:'steady',led:{trust:1},fx:{item:'dreamlantern'},flag:'lantern',mem:`accepted a lantern from a woken sleeper`,
     say:[`It is warm. The light behind the shutter is soft and dim, like something sung a long way off. You can feel which way the dark trees lie, as if someone had been pointing quietly for a hundred years.`]},
    {t:`Ask her to tell you what she dreamed.`,need:{hours:1},habit:'tender',led:{kin:1,truth:1},cap:{sleepers:1},fx:{unlock:'sleepers'},flag:'dream',mem:`listened to a sleeper's dream`,stand:true,
     say:[`She tells it slowly. It is long, and odd, and most of it is a corridor. But near the end there is a table with four hollows, and a room that smells of old fish, and someone you do not quite recognise holding a lantern.`,`"I think it was you," she says. "I think I was dreaming forward."`]},
    {t:`Ask her to keep it, and light it for the next sleeper.`,habit:'gentle',led:{mercy:1,kin:1},cap:{sleepers:1},flag:'keep',mem:`asked a sleeper to keep her lantern for the next one`,stand:true,
     say:[`She looks at the lantern, and at you, and she cries, a little. "That is the right answer," she says. "I was hoping it was."`]}]},
 { id:'thistle2', a:15, b:19, if:()=>cap('sleepers')>=3, who:[`Linden, a woken sleeper`,P('#a09ac0','#807aa0'),'scarf'],
   brief:`Linden remembers how to brew what the sleepers hum.`,
   intro:[`(Linden is sitting up in bed, with a tin of dried things in her lap, and a slight look of triumph.)`,`"I remembered. Not much, but this. Before I slept, my mother taught me a draught to see in the dark. We brewed it from what the sleepers hum. I thought it was a lullaby, and it was, but it was other things."`,`"I think it will help. I would like you to have it, and I would like to have told it before I forget."`],
   q:`She holds out the tin. The writing inside the lid is in a very old hand.`,
   gone:`(Linden forgot the draught on the third day. She says it was a nice thing to have known.)`,
   opts:[
    {t:`Accept the recipe, and thank her.`,habit:'steady',led:{trust:1},fx:{recipe:'dreamdraught'},flag:'recipe',mem:`learned a sleeper's draught`,
     say:[`She tells it to you twice, carefully, in the order her mother did. "Mushrooms. Flowers. Grade one, for the flowers. And the hum."`]},
    {t:`Ask her to teach it to Ivy, who will use it for the others.`,habit:'tender',led:{mercy:1,trust:1},cap:{sleepers:1},flag:'ivy',mem:`asked a sleeper to teach the nurse her draught`,stand:true,
     say:[`She is quiet, then she smiles. "Yes. She will need it more." She calls for the nurse, and the next half hour is spent over a small pot, three women, and a sudden easing of the room.`]}]}
]);

/* ---------- 2. four quiet hours, each only if the ledger says so ---------- */
Object.assign(BREATH,{
 b6:{title:`A Small Debt`,sub:`Poppy has been keeping count of something.`,who:`Little Poppy`,
  intro:[`Poppy is sitting by the fire with a stub of pencil and a piece of bark, writing down very small numbers.`,`She does not hide it. She does not explain it either.`],
  scene:[[`Little Poppy`,[`"It is the things you have given away. Mama says you cannot trust a person who gives things away. She says they want something."`,`"I have a list. Fish. Bread. A potion. I am keeping count so I can tell her what you want. It is a long list. I do not know what it adds up to."`]]],
  q:`"What do you want? You can tell me. I will not tell Mama."`,
  opts:[[`"Nothing. It is just what you do."`,`gentle`,`steady`,`She considers. "Mama says that is the thing people want you to believe." Then, after a long time: "I think I believe it anyway."`],[`"I want people to be all right."`,`tender`,`candid`,`"That is a real thing to want," says Poppy. "That is the most real thing on the list." She crosses out a number.`],[`"I don't know. I'll tell you when I do."`,`guarded`,`candid`,`She nods, as if she has been told something much more satisfactory than an answer. "That is allowed," she says.`]],
  tail:[`She tears the bark in half, and gives you half, and keeps half.`,`It has one word on it, in pencil. It says: ALLOWED.`]},
 b10:{title:`Tidy Lies`,sub:`Ruddock has noticed how neatly you put things.`,who:`Warden Ruddock`,
  intro:[`Ruddock is mending a bridle by the fire, slowly, with the attention of a man who is mending something else.`,`He does not look up when you sit. "You are very good at this," he says.`],
  scene:[[`Warden Ruddock`,[`"The tidy thing. The small adjustment. A false word here, to save a harder one there. I do it, too. I have done it for forty years. I would like to tell you what it costs."`,`"It costs you the ability to tell, afterwards, which of your own memories are true. I have a drawer in my head full of kind things I said that were not. I cannot always find the real ones."`]]],
  q:`"Would you rather be believed, or be right? I do not mean at once. I mean in the end."`,
  opts:[[`"Right. Even if it costs me."`,`candid`,`proud`,`"Hm." He puts the bridle down. "That is easier to say at this fire than at the next."`],[`"Believed. People need someone to believe."`,`steady`,`guarded`,`"That is the honest answer," he says, surprised. "That is the worst and the most honest answer, and I thank you for it."`],[`"Both. I haven't found a way yet."`,`gentle`,`candid`,`"Nor have I," says Ruddock, almost to himself. "Let us not stop looking."`]],
  tail:[`He finishes the bridle. He hangs it up. He looks at it for some time.`,`"Put the tidy things down when you can," he says. "They are heavy. They do not look it."`]},
 b14:{title:`The Weight`,sub:`Mallow, on the subject of being right.`,who:`Hermit Mallow`,
  intro:[`Mallow is shelling peas into a bowl with the unhurried grace of someone who has been right a great deal and found it of limited use.`,`He pats the bench. "Sit. I have a thing to say, and I have not the patience to say it nicely."`],
  scene:[[`Hermit Mallow`,[`"You have been right a good many times lately. I have watched. It is a fine thing to be right. It has a particular taste, like a cold coin."`,`"I was right for a hundred years, once. I was right about everything, and everyone I was right about left. I did not understand it for some time."`]]],
  q:`"Which would you rather be, in the end? Right, or kept company?"`,
  opts:[[`"Kept company. I'd trade a lot of right for it."`,`tender`,`gentle`,`"Ah." He is smiling at the peas. "Then you are not as far down this road as I was. Good."`],[`"Right. Someone has to be."`,`proud`,`steady`,`"Yes," he says. "Someone does. I will sit with you while you do it. That is all I know how to offer."`],[`"I don't see why it's one or the other."`,`candid`,`guarded`,`"It is not," says Mallow, with interest. "It is just that most people never find the third thing. Go and find it."`]],
  tail:[`He hands you a bowl of peas. They are bright, and slightly sweet.`,`"Eat," he says. "It is hard to be right on an empty stomach."`]},
 b16:{title:`A Table for Everyone`,sub:`The camp has been fed, and wants to say something about it.`,who:`Captain Halbeak`,
  intro:[`Someone has set a long table in the middle of the camp, and nobody can say who. It is laid for more people than are here.`,`Halbeak is standing at the head of it, not sitting, with a ladle he does not seem to know how to hold.`],
  scene:[[`Captain Halbeak`,[`"I have counted the camp three times, and the number of people who have eaten tonight is the same as the number who are here. I have never been present at such a count."`,`"I do not know what you did. I know it was not mine. I have been trying for a week to work out how to say that."`]]],
  q:`"May I ask you to sit at the head of the table? I would feel more correct if you did."`,
  opts:[[`"Yes. I'll sit."`,`steady`,`proud`,`He seems relieved. The table seems relieved. You take the chair, which is rather too big. Several children look at you as if you were an ornament.`],[`"No. Put someone who needs the chair."`,`tender`,`gentle`,`He hesitates, then nods. He pulls out the chair for a small boy with a helmet, who sits in it with immense seriousness and says grace.`],[`"Let's have no head. Everyone sits."`,`candid`,`tender`,`He laughs, once, which is rare, and rearranges the chairs himself, with great care, into something that is nearly round.`]],
  tail:[`The soup comes round. It is good. It tastes of a great many people deciding to look after each other.`,`Somewhere near the end, Halbeak says, quite quietly, "Thank you." He does not say what for. He doesn't need to.`]}
});
for(const id of ['b6','b10','b14','b16']){ const b=BREATH[id];
  S2.ch[id]={route:'both',theme:'both',numLabel:'A QUIET HOUR',title:b.title,sub:b.sub,intro:b.intro,recap:'A quiet hour, between two loud ones.',
    start(){ s2set(0); },
    obj(s){ return ['Go to the <b>campfire</b> '+campWhere()+', and spend a quiet hour with <b>'+b.who.replace(/^(Captain|Warden|Hermit|Little) /,'')+'</b>.'][s]||''; }
  };
}
const anyDone=()=>D10.reqList().some(x=>x.st&&x.st.st==='done');
const OPT={
 c6r:{id:'b6',if:()=>anyDone()||s2led('mercy')+s2led('kin')>=1},c6c:{id:'b6',if:()=>anyDone()||s2led('mercy')+s2led('kin')>=1},
 c10:{id:'b10',if:()=>s2led('lie')>=2},
 c14r:{id:'b14',if:()=>s2led('pride')>=2||cap('hearth')<0},c14c:{id:'b14',if:()=>s2led('pride')>=2||cap('hearth')<0},c14k:{id:'b14',if:()=>s2led('pride')>=2||cap('hearth')<0},
 c16r:{id:'b16',if:()=>cap('hearth')>=3},c16c:{id:'b16',if:()=>cap('hearth')>=3}
};
{
  const _sn=s2next;
  s2next=function(id){
    const q=s2(), nx=_sn(id), o=OPT[id];
    if(o&&nx&&!q.done[o.id]){ let ok=false; try{ ok=!!o.if(); }catch(e){} if(ok){ q.bnext=nx; return o.id; } }
    return nx;
  };
}

/* ---------- 3. the road remembers ---------- */
function weight(r,o){
  let w=0; for(const k in (o.led||{})) w+=Math.abs(o.led[k]); for(const k in (o.cap||{})) w+=Math.abs(o.cap[k]);
  if(o.stand) w+=1; if(o.fx) w+=2; if(o.need) w+=Object.keys(o.need).length*0.5;
  return w;
}
function resolved(){
  const out=[];
  for(const x of D10.reqList()){
    if(!x.st||x.st.st!=='done') continue;
    const o=x.r.opts.find(q=>q.flag===x.st.pick); if(!o) continue;
    out.push({r:x.r,o:o,w:weight(x.r,o)});
  }
  return out;
}
const shortName=r=>r.who[0].split(',')[0].replace(/^(Old|Cook|Keeper|Nurse|Quartermaster|Granny|Lady-Clerk|The) /,'');
function remembered(){
  const done=resolved().sort((a,b)=>b.w-a.w);
  const pages=[];
  if(!done.length) return pages;
  const tpl=[(n,m)=>`${n} has not forgotten that you ${m}.`,(n,m)=>`Somewhere on the road, ${n} still tells the story of the time you ${m}.`,(n,m)=>`${n} remembers, and is quiet about it: you ${m}.`,(n,m)=>`It is known, to ${n} at least, that you ${m}.`];
  done.slice(0,5).forEach((d,i)=>pages.push(tpl[i%tpl.length](shortName(d.r),d.o.mem)));
  const gone=D10.reqList().filter(x=>x.st&&x.st.st==='gone');
  if(gone.length) pages.push(gone.length===1?`There was one person who asked, and was passed by. Nobody ever told you what became of ${shortName(gone[0].r)}.`:`There were ${gone.length} who asked, and were passed by. You never learned what became of ${shortName(gone[0].r)}, or of the others, and the road did not say.`);
  try{ const n=ROLL.filter(r=>{ try{ return r.ok(); }catch(e){ return false; } }).length; if(n>=8) pages.push(`On the last night, ${n} people from the road came out of the dark to stand with you. It was not a plan. It was a ring.`); else if(n>=3) pages.push(`On the last night, ${n} people from the road came to stand with you. They were few, and they were enough.`); }catch(e){}
  try{ const nick=S4.nick(); if(nick) pages.push(`The road has a word for you now. It is "${nick}". It was not given as a prize, and nobody remembers who said it first.`); }catch(e){}
  return pages;
}
{
  const _ec=epiCard;
  epiCard=function(label,title,sub,pages,theme,cb){
    try{ if(label==='EPILOGUE'&&Array.isArray(pages)){ const r=remembered(); if(r.length) pages=pages.concat(r); } }catch(e){ console.error(e); }
    return _ec(label,title,sub,pages,theme,cb);
  };
}
{
  const _je=journalExtra;
  journalExtra=function(sec,line){
    _je(sec,line);
    try{
      const done=resolved(); if(!done.length) return;
      sec('What the Road Remembers');
      for(const d of done.slice().sort((a,b)=>b.w-a.w).slice(0,12)) line('You '+d.o.mem+'.','jdim');
      const mods=D10.fxState(), bits=[];
      if(mods.pay>0) bits.push('jobs pay a little better'); if(mods.pay<0) bits.push('jobs pay a little worse');
      if(mods.buy>0) bits.push('shops quote you higher'); if(mods.buy<0) bits.push('shops quote you lower');
      if(mods.sell>0) bits.push('shopkeepers pay more for your finds'); if(mods.sell<0) bits.push('shopkeepers pay less for your finds');
      if(g.day<mods.badUntil) bits.push('the towns are cool toward you, for '+(mods.badUntil-g.day)+' more days');
      for(const k in mods.unlock) bits.push('a back room is open ('+k+')');
      if(bits.length) line('Because of it: '+bits.join('; ')+'.','jdim');
    }catch(e){}
  };
}
})();
