'use strict';
/* ===== VILLAGE CALENDAR: events every other day, posted on each notice board ===== */
g.ev={};      /* attended events: 'townKey:day' -> 1 */
g.story={};   /* storyline state (stranger, ghost story, kingdom discoveries, chests) */
const evSkip={};   /* declined this session */
const EV_TAGS={fest:'#ffb347',spooky:'#b388ff',food:'#86e29a',sport:'#6ec1ff',music:'#ff8fb8',market:'#f6d55c'};
const PUD='2,0';

const EV_ALL=[
 {id:'bread',title:'Bread Toss',h:15,dur:2,tag:'sport',mini:1,c:5,desc:'Toss a crust. Catch a crust. Eat the crust. Prizes for the steadiest bill.',say:'Time your toss in the green zone.',join:['The Bread Toss is on! A line of ducks stares at a single crust with great intensity.']},
 {id:'regatta',title:'Pond Regatta',h:14,dur:2,tag:'sport',mini:1,c:6,desc:'Tiny walnut-shell boats race across the water. Cheering is mandatory.',say:'Steer your shell: press when the marker is in the zone.',join:['Ducks line the water with walnut-shell boats. Yours has a leaf sail.']},
 {id:'lantern',title:'Lantern Parade',h:19,dur:2,tag:'fest',c:6,item:'lantern',desc:'Paper lanterns drift through the streets at dusk. Everyone carries one.',join:['A hundred paper lanterns bob down the street, glowing like small tame moons.','You walk the whole parade with a lantern and a wide smile. A little girl duck hands you hers to keep.']},
 {id:'talent',title:'Quack-Off Talent Show',h:18,dur:2,tag:'music',c:6,desc:'Singing, juggling, and one extremely long quack. Sign up at the stage.',join:['The Quack-Off begins. A duck juggles three eggs, very carefully. Another quacks in four-part harmony, alone.','You get a standing ovation for simply showing up. Ducks are generous judges.']},
 {id:'pie',title:'Pie-Eating Contest',h:13,dur:2,tag:'food',mini:1,c:6,desc:'Fast, messy, and glorious. No forks. Not that you would use one.',say:'Gobble on the beat: press in the zone.',join:['A table of pies appears. Everyone looks at everyone. Someone yells GO.']},
 {id:'puddle',title:'Puddle Jumping Day',h:10,dur:3,tag:'sport',mini:1,c:5,desc:'It has not rained. The town has made puddles anyway.',say:'Jump when the marker hits the zone.',join:['The puddles were made with watering cans. Nobody mentions it. Everybody jumps.']},
 {id:'bake',title:'Great Bake-Off',h:12,dur:3,tag:'food',mini:1,c:7,item:'muffin',desc:'Ducks bring their finest breads. A very serious panel judges.',say:'Bake it just right: press in the zone.',join:['The tent smells of warm bread. The judges wear tiny aprons and enormous frowns.']},
 {id:'feather',title:'Feather Fair',h:11,dur:4,tag:'market',c:4,item:'feather',desc:'Stalls of feathers, ribbons, and shiny nothings. Bring crumbs.',join:['The Feather Fair is a riot of colour. You haggle over a ribbon for ten minutes and win nothing but joy.','A stallkeeper presses an odd feather into your wing: "On the house. It likes you."']},
 {id:'story',title:'Storytelling Hour',h:17,dur:2,tag:'fest',c:4,desc:'Elders swap tall tales by the fire. Each is taller than the last.',join:['An old duck tells of the time a pond swallowed a whole afternoon.','Another claims to have outrun a fox, a hawk, and a very slow tax collector. The crowd roars.']},
 {id:'trivia',title:'Detective Trivia Night',h:20,dur:2,tag:'music',c:6,desc:'Teams of sleuths answer clues. Last place gets a rubber duckie.',join:['Question one: Which animal stole the Great Bun in 1840? Your team writes DUCK. The answer is Raccoon.','The quiz-master taps her card. "Six questions, twelve seconds each. Pencils up, sleuths."'],
  result:S=>S>=9?{lines:['You answer almost everything. The quiz-master checks her answer card twice, then hands you the trophy, a small tin cup, with a worried look.']}
    :S>=6?{lines:['You finish near the top of the table. The quiz-master applauds with only one wing, on principle.']}
    :S>=3?{lines:['You finish mid-table, which is a dignified place to be.']}
    :{lines:['You lose gloriously. Last place gets the rubber duckie, and the rubber duckie is yours. You squeak it once, with dignity.'],item:'ducky'}},
 {id:'tea',title:'Tea & Gossip Social',h:16,dur:2,tag:'food',c:4,item:'tea',desc:'Warm cups, sharp whispers. Everything said here is strictly secret.',join:['You hear that Pip is secretly a baker, Dot secretly hates bread, and Mabel secretly knows both.','You sip your tea and say nothing. This makes you the most trusted duck at the table.']},
 {id:'dig',title:'Treasure Dig',h:9,dur:3,tag:'market',mini:1,c:6,desc:'Somebody buried a chest in the meadow. Maybe. Bring a spoon.',say:'Dig at the right moment: press in the zone.',join:['A map with a big X is handed round. The X is on the town hall. Nobody minds.']},
 {id:'goose',title:'Duck-Duck-Goose Tournament',h:14,dur:2,tag:'sport',mini:1,c:5,desc:'A deadly serious sport. The Goose is feared. The Goose is fair.',say:'Dash on the beat: press in the zone.',join:['Everyone sits in a circle. The Goose walks around. Tension is high. Hearts are low.']},
 {id:'dance',title:'Moonlit Dance',h:20,dur:3,tag:'music',c:6,desc:'Lanterns, a fiddle, and a floor full of flapping. Two left feet welcome.',join:['The fiddler starts a jig and the whole square flaps in rhythm.','You step on three tails and are forgiven four times. A fine night.']}
];
const EV_STYLE={
 cobble:[{id:'wishday',title:'Fountain Wishing Day',h:12,dur:4,tag:'fest',c:5,desc:'Toss a crumb in the fountain and make a wish. Wishes are not guaranteed.',join:['The whole town lines up at the fountain. You toss in a crumb and wish for a bigger crumb.']},
         {id:'chalk',title:'Cobblestone Chalk Art',h:11,dur:3,tag:'market',c:4,desc:'The plaza becomes a giant drawing. Mind where you step.',join:['You draw a duck. Someone draws a bigger duck. A war of ducks begins, peacefully.']}],
 garden:[{id:'crownshop',title:'Flower Crown Workshop',h:11,dur:3,tag:'market',c:4,item:'daisy',desc:'Weave a crown from daisies and violets. Bees supervise.',join:['You learn the over-under-over weave. The bees approve with a low hum.']},
         {id:'bees',title:'Bee Parade',h:15,dur:2,tag:'fest',c:5,desc:'Tiny bee costumes. Big bee feelings.',join:['A hundred bees in tiny hats buzz down the lane. You are not stung. You are honoured.']}],
 harvest:[{id:'pumpkin',title:'Pumpkin Roll',h:15,dur:2,tag:'sport',mini:1,c:6,desc:'Roll your pumpkin to the barn. The pumpkin has opinions.',say:'Push at the right moment: press in the zone.',join:['Pumpkins the size of ducks line up. They wobble. They are ready.']},
          {id:'haymaze',title:'Hay Bale Maze',h:10,dur:5,tag:'market',c:5,desc:'A maze of hay. There is a prize in the far corner. And a mouse.',join:['You get lost twice, found once, and tickled by hay forever. The mouse waves.']}],
 frost:[{id:'snowduck',title:'Snowduck Building',h:12,dur:3,tag:'fest',c:5,desc:'Build the finest snow duck you can. Ice-carving judges are strict.',join:['Your snow duck has a carrot bill and one lopsided eye. The judges call it "brave".']},
        {id:'iceslide',title:'Ice Slide Derby',h:14,dur:3,tag:'sport',mini:1,c:6,desc:'Down the hill on your belly. Nothing but joy and wind.',say:'Lean in: press in the zone.',join:['The slide is long, icy, and very fast. You scream with delight the whole way.']}],
 cove:[{id:'sandcastle',title:'Sandcastle Contest',h:11,dur:3,tag:'sport',mini:1,c:6,desc:'Castles, moats, tiny flags. The tide is the final judge.',say:'Pack it right: press in the zone.',join:['You scoop, pat, and decorate. A seagull critiques loudly.']},
        {id:'shells',title:'Shell Hunt',h:9,dur:4,tag:'market',c:5,item:'pebble',desc:'Hunt the shore for the loveliest shell. Keep it or trade it.',join:['You find a spiral shell that sounds like the sea. And one that sounds like a very small sea.']}],
 grove:[{id:'glowwalk',title:'Glow-Cap Night Walk',h:20,dur:3,tag:'spooky',c:6,desc:'Walk the mushroom paths after dark. Do not touch the pretty ones.',join:['The mushrooms hum softly as you pass. The path glows teal and then violet and then teal again.']},
        {id:'spore',title:'Spore Lantern Concert',h:19,dur:3,tag:'music',c:6,desc:'A concert where the instruments glow. The audience glows, too.',join:['A band of glowing frogs plays slow, shimmering music. Even the mushrooms sway.']}],
 bazaar:[{id:'bonanza',title:'Bargain Bonanza',h:10,dur:6,tag:'market',c:5,desc:'Everything is a little cheaper. Or looks that way.',join:['Banners scream SALE! The crowd surges. You come out with a stranger\'s hat and a good story.']},
         {id:'haggle',title:'Haggling Championship',h:13,dur:2,tag:'sport',mini:1,c:6,desc:'The loudest, longest, most polite fight in town.',say:'Hold your ground: press in the zone.',join:['Two ducks haggle over a single pea for forty minutes. The pea is eventually eaten by a pigeon.']}]
};
/* Puddlewick's own early schedule */
const PUD_FIXED={
 1:{id:'picnic',title:'Welcome Picnic',h:12,dur:3,tag:'food',c:5,item:'scone',desc:'Blankets, bread and gossip on the green. All newcomers welcome.',join:['The whole town is on the green with baskets and blankets. Everybody wants to meet the new duck.','You end up with more scones than you can carry. Welcome to Puddlewick.']},
 3:{id:'ghost',title:'Ghost Story Night',h:19,dur:6,tag:'spooky',special:'ghost',desc:'A traveler is said to be passing through. They say he tells stories. The kind you do not forget. Gather by the fountain after dark.'},
 5:EV_ALL[1], 7:EV_ALL[6], 9:EV_ALL[2], 11:EV_ALL[9], 13:EV_ALL[7], 15:EV_ALL[3], 17:EV_ALL[4], 19:EV_ALL[11], 21:EV_ALL[13], 23:EV_ALL[12], 25:EV_ALL[10], 27:EV_ALL[5], 29:EV_ALL[8]
};
function eventFor(t,day){
  if(!t||day%2===0) return null;
  if(t.key===PUD&&PUD_FIXED[day]) return PUD_FIXED[day];
  const pool=EV_ALL.concat(EV_STYLE[t.style.id]||[],EV_STYLE[t.style.id]||[]);
  return pool[Math.floor(hash(t.rx*7+day,t.ry*13+day,3300+day)*pool.length)];
}
const evKey=(t,day)=>t.key+':'+day;
function evLive(e){ return e&&!e.special&&g.clock>=e.h&&g.clock<e.h+e.dur; }
function evHour(h){ return fmtHour(Math.floor(h)%24).replace(/^(\d+)/,'$1')+(h%1?':30':''); }
function hourLabel(h){ const hh=Math.floor(h), mm=h%1?'30':'00', x=hh%12===0?12:hh%12; return x+':'+mm+(hh>=12&&hh<24?' PM':' AM'); }

function attendEvent(t,e){
  const key=evKey(t,g.day);
  const reward=(S)=>{
    g.ev[key]=1;   /* attended only once the prize is paid: backing out of the mini-game (X) must not forfeit the event */
    const pay=Math.max(3,Math.round((e.c+(S===undefined?3:S*0.6))*payMul(t)));
    g.crumbs+=pay; coin(); advanceClock(e.mini?1:0.5);
    const rs=(e.result&&S!==undefined)?e.result(S):null;   /* some events answer to how you did, not just that you came */
    const lines=rs?rs.lines.concat(['The night pays '+pay+' crumbs for your trouble.']):['You had a wonderful time. Prize and thanks: '+pay+' crumbs.'];
    const itemId=rs&&rs.item?rs.item:e.item;
    if(itemId){ addItem(itemId); lines.push('You also got a '+ITEMS[itemId].name+'.'); }
    addRep(t,(S===undefined||S>=6)?2:1);   /* granted before the dialogue: the popup can close while it is still on screen */
    say('',lines);
  };
  if(e.mini) say('',e.join,()=>startMini({title:e.title,say:e.say,onDone:S=>reward(S)}));
  else say('',e.join,()=>reward());
}
function offerEvent(t,e){
  choose('',e.title+' is happening right now in '+t.name+'. Join in?',['Join','Not now'],k=>{
    if(k===0) attendEvent(t,e); else evSkip[evKey(t,g.day)]=true;
  },1);
}
let evT=0, evTown=null;
function extraUpdate(dt){
  if(g.mode!=='play'||g.scene!=='world') return;
  evT-=dt; if(evT>0) return; evT=0.5;
  const tw=townAtTile(Math.floor(g.px/TS),Math.floor((g.py-2)/TS));
  if(tw!==evTown){
    evTown=tw;
    if(tw){
      const e=eventFor(tw,g.day);
      if(e&&g.clock<e.h+e.dur) setTimeout(()=>{ if(g.mode==='play') toast((evLive(e)?'Happening now: ':'Today: ')+e.title+' at '+hourLabel(e.h),3600); },3200);
    }
  }
  if(!tw) return;
  const e=eventFor(tw,g.day), k=tw?evKey(tw,g.day):'';
  if(e&&evLive(e)&&!g.ev[k]&&!evSkip[k]) offerEvent(tw,e);
}

/* ---- the calendar panel on the notice board ---- */
const cal={t:null,sel:1};
let calEl=null;
function openCalendar(t){
  cal.t=t; cal.sel=g.day; g.mode='cal'; g.story.calSeen=1;
  calEl=document.getElementById('cal'); calEl.hidden=false; renderCalendar(); blip();
}
function closeCalendar(){ g.mode='play'; calEl.hidden=true; blip(); }
PANEL_CLOSE.cal=()=>closeCalendar();
function calPress(k){
  if(k==='x'||k==='z') { closeCalendar(); return; }
  let s=cal.sel;
  if(k==='left') s--; else if(k==='right') s++; else if(k==='up') s-=7; else if(k==='down') s+=7; else return;
  if(s<1) s=1;
  cal.sel=s; blip(); renderCalendar();
}
function daysUntil(d){ return d-g.day; }
function renderCalendar(){
  const t=cal.t, page=Math.floor((cal.sel-1)/28), start=page*28+1;
  document.getElementById('calTitle').textContent=t.name+' Calendar';
  document.getElementById('calSub').textContent='Today is day '+g.day+'  -  '+clockStr()+'.  Weeks '+(page*4+1)+' to '+(page*4+4);
  const grid=document.getElementById('calGrid'); grid.innerHTML='';
  ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].forEach(n=>{ const d=document.createElement('div'); d.className='ch'; d.textContent=n; grid.appendChild(d); });
  for(let i=0;i<28;i++){
    const day=start+i, e=eventFor(t,day), c=document.createElement('div');
    c.className='cc'+(day===g.day?' today':'')+(day===cal.sel?' sel':'')+(day<g.day?' past':'');
    const n=document.createElement('span'); n.className='cn'; n.textContent=day; c.appendChild(n);
    if(e){
      const tg=document.createElement('span'); tg.className='ct'; tg.style.background=EV_TAGS[e.tag]; tg.textContent=e.title; c.appendChild(tg);
      if(g.ev[evKey(t,day)]){ const ok=document.createElement('span'); ok.className='ck'; ok.textContent='done'; c.appendChild(ok); }
    }
    c.addEventListener('click',()=>{ cal.sel=day; renderCalendar(); blip(); });
    grid.appendChild(c);
  }
  const e=eventFor(t,cal.sel), box=document.getElementById('calDetail'); box.innerHTML='';
  const h=document.createElement('h3'); h.textContent='Day '+cal.sel+(cal.sel===g.day?'  (today)':daysUntil(cal.sel)>0?'  (in '+daysUntil(cal.sel)+' day'+(daysUntil(cal.sel)===1?'':'s')+')':'  (past)'); box.appendChild(h);
  const p=document.createElement('p');
  if(!e) p.textContent='Nothing is planned. A quiet day in '+t.name+'. Maybe a nap.';
  else {
    const b=document.createElement('b'); b.textContent=e.title; b.style.color=EV_TAGS[e.tag];
    p.appendChild(b); p.appendChild(document.createTextNode('  -  '+hourLabel(e.h)+' to '+hourLabel((e.h+e.dur)%24)));
    const q=document.createElement('p'); q.className='jdim'; q.textContent=e.desc; box.appendChild(p); box.appendChild(q);
    if(g.ev[evKey(t,cal.sel)]){ const r=document.createElement('p'); r.style.color='var(--good)'; r.textContent='You attended this one.'; box.appendChild(r); }
    return;
  }
  box.appendChild(p);
}
document.addEventListener('click',e=>{ if(e.target&&e.target.id==='calClose'&&g.mode==='cal') closeCalendar(); });
