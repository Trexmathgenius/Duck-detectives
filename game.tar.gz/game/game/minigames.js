/* ===== MINI-GAME ENGINE: every event and shop job has its own game ===== */
const MG={}, MGW=480, MGH=270;
const MG_BY_TITLE={
 'Bread Toss':'bread','Pond Regatta':'regatta','Pie-Eating Contest':'pie','Puddle Jumping Day':'puddle','Great Bake-Off':'bake','Treasure Dig':'dig',
 'Duck-Duck-Goose Tournament':'goose','Pumpkin Roll':'pumpkin','Ice Slide Derby':'iceslide','Sandcastle Contest':'sandcastle','Haggling Championship':'haggle',
 'Knead the Dough':'knead','Sort the Produce':'produce','Polish the Lenses':'lens','Dust the Curios':'curio','Pour the Tea':'pour',
 'Arrange the Bouquets':'bouquet','Shelve the Books':'shelve','Stitch the Hems':'stitch','Wind the Toys':'toys'
};
let mgs=null;
const mgClamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const mgRnd=(a,b)=>a+Math.random()*(b-a);
function mgT(c,s,x,y,sz,col,al){ c.font='bold '+sz+'px monospace'; c.textAlign=al||'center'; c.textBaseline='middle'; c.fillStyle=col||'#fff'; c.fillText(s,x,y); }
function mgDuck(c,x,y,k,col,face){
  k=k||1; col=col||'#ffd84a'; const f=face===-1?-1:1;
  c.save(); c.translate(x,y); c.scale(f*k,k);
  ell(c,0,1,10,3,'rgba(0,0,0,0.25)'); ell(c,0,-8,10,8,col); circ(c,7,-17,6,col);
  rect(c,12,-18,6,3,'#ff8a1f'); rect(c,9,-20,2,2,'#222'); ell(c,-2,-8,5,4,'rgba(0,0,0,0.12)');
  c.restore();
}
function mgSky(c,top,bot){ const gr=c.createLinearGradient(0,0,0,MGH); gr.addColorStop(0,top); gr.addColorStop(1,bot); c.fillStyle=gr; c.fillRect(0,0,MGW,MGH); }
function mgBar(c,x,y,w,h,f,col,bg){ rect(c,x,y,w,h,bg||'#1c2b24'); rect(c,x,y,w*mgClamp(f,0,1),h,col||'#7fd37a'); c.strokeStyle='#0008'; c.lineWidth=1; c.strokeRect(x+.5,y+.5,w-1,h-1); }
const mgTone=(ok)=>{ if(ok) coin(); else tone('square',300,180,0.12,0.05); };

function startMG(id,o){
  const def=MG[id];
  mgs={id:id,def:def,o:o,st:'intro',t:0,s:{},score:0};
  g.mode='mg';
  document.getElementById('mg').hidden=false;
  document.getElementById('mgTitle').textContent=o.title;
  document.getElementById('mgSay').textContent=def.hint;
  document.getElementById('mgKeys').textContent=def.keys+'  -  X give up';
  def.init(mgs.s);
  mgDraw();
}
function mgFinish(quit){
  const m=mgs; mgs=null;
  document.getElementById('mg').hidden=true; g.mode='play'; blip();
  if(!quit&&m.o.onDone) m.o.onDone(m.score);
}
function mgPress(k){
  const m=mgs; if(!m) return;
  if(k==='x'&&m.st!=='done'){ mgFinish(true); return; }
  if(m.st==='intro'){ if(k==='z'){ m.st='play'; blip(); } return; }
  if(m.st==='done'){ if(k==='z') mgFinish(false); return; }
  m.def.press(m.s,k);
}
function mgUpdate(dt){
  const m=mgs; if(!m) return;
  dt=Math.min(dt,0.05); m.t+=dt;
  if(m.st==='play'){
    m.s.time=(m.s.time||0)+dt;
    m.def.update(m.s,dt);
    if(m.s.time>(m.def.cap||45)&&!m.s.done){ m.s.done=1; if(m.s.score===undefined) m.s.score=0; }
    if(m.s.done){ m.st='done'; m.score=mgClamp(Math.round(m.s.score||0),0,10); m.dt=0; if(m.score>=6) coin(); }
  }
  mgDraw();
}
function mgDraw(){
  const m=mgs; if(!m) return;
  const cv2=document.getElementById('mgc'), c=cv2.getContext('2d');
  c.setTransform(1,0,0,1,0,0); c.clearRect(0,0,MGW,MGH);
  m.def.draw(m.s,c,m.t);
  if(m.s.msg&&m.st==='play') mgT(c,m.s.msg,MGW/2,20,16,'#fff4c2');
  document.getElementById('mgHud').innerHTML=m.def.hud?m.def.hud(m.s):'&nbsp;';
  document.getElementById('mgMsg').textContent=m.st==='done'?'Press Z to finish.':m.st==='intro'?'Press Z to start.':' ';
  if(m.st==='intro'){
    c.fillStyle='rgba(8,16,12,0.88)'; c.fillRect(0,0,MGW,MGH);
    mgT(c,m.o.title,MGW/2,50,22,'#ffd166');
    m.def.how.forEach((l,i)=>mgT(c,l,MGW/2,100+i*24,14,'#e6f0e8'));
    mgT(c,'Press Z to start',MGW/2,236,16,(Math.floor(m.t*2)%2)?'#ffd166':'#fff');
  } else if(m.st==='done'){
    c.fillStyle='rgba(8,16,12,0.8)'; c.fillRect(0,0,MGW,MGH);
    mgT(c,m.score+' / 10',MGW/2,100,46,m.score>=9?'#ffd166':m.score>=6?'#9be08a':m.score>=3?'#e6f0e8':'#e0a090');
    mgT(c,m.score>=9?'Flawless!':m.score>=6?'Great work!':m.score>=3?'Not bad.':'Well, you showed up.',MGW/2,150,18,'#fff');
    mgT(c,'Press Z to finish',MGW/2,236,16,(Math.floor(m.t*2)%2)?'#ffd166':'#fff');
  }
}
function startMini_MG(o){ const id=MG_BY_TITLE[o.title]; if(id&&MG[id]) return startMG(id,o); return null; }
{
  const _startMini=startMini;
  startMini=function(o){ if(startMini_MG(o)===null) _startMini(o); };
}

/* ============ EVENT GAMES ============ */

/* Bread Toss: swing the power bar, land the crust in the open bill */
MG.bread={
 hint:'Toss the crust into the open bill.', keys:'Z toss',
 how:['A power bar swings back and forth.','Press Z to toss the crust.','Land it in the open bill. Five tosses.'],
 hud:s=>'Toss '+Math.min(5,s.round+1)+'/5',
 init(s){ s.round=0; s.pts=0; this.next(s); },
 next(s){ s.pw=0; s.dir=1; s.tg=0.3+Math.random()*0.62; s.ph='aim'; s.fly=0; s.spd=0.95+s.round*0.22; s.msg=''; },
 update(s,dt){
  if(s.ph==='aim'){ s.pw+=s.dir*s.spd*dt; if(s.pw>=1){ s.pw=1; s.dir=-1; } if(s.pw<=0){ s.pw=0; s.dir=1; } }
  else if(s.ph==='fly'){ s.fly+=dt/0.8; if(s.fly>=1){ s.fly=1; const e=Math.abs(s.shot-s.tg), r=e<0.045?2:e<0.12?1:0; s.pts+=r; s.msg=['Splat!','Nearly!','Perfect catch!'][r]; mgTone(r); s.ph='res'; s.w=0.9; } }
  else { s.w-=dt; if(s.w<=0){ s.round++; if(s.round>=5){ s.done=1; s.score=s.pts; } else this.next(s); } }
 },
 press(s,k){ if(k==='z'&&s.ph==='aim'){ s.shot=s.pw; s.ph='fly'; s.fly=0; blip(); } },
 draw(s,c,t){
  mgSky(c,'#9fd3f0','#d9f0c8'); rect(c,0,200,MGW,70,'#6aa84f'); rect(c,0,200,MGW,4,'#4f8a3a');
  mgDuck(c,50,205,1.3);
  const tx=95+s.tg*340;
  mgDuck(c,tx,215,1.5,'#f4f4ee'); rect(c,tx+9,186,14,3,'#ff9d2e'); rect(c,tx+9,192,14,3,'#ff9d2e'); rect(c,tx+11,189,10,3,'#7a2a2a');
  if(s.ph==='fly'||s.ph==='res'){
    const u=s.fly, sx=70, ex=95+s.shot*340, x=sx+(ex-sx)*u, y=170+(200-170)*u-Math.sin(u*Math.PI)*100;
    ell(c,x,y,7,4,'#c98a3c'); ell(c,x-1,y-1,4,2,'#e8b46a');
  }
  mgBar(c,60,245,360,12,s.pw,'#ffd166'); rect(c,60+360*s.pw-2,241,4,20,'#fff');
  mgT(c,'power',40,251,11,'#bcd',  'right');
 }
};

/* Pond Regatta: dodge the lilies in three lanes */
MG.regatta={
 hint:'Steer your walnut-shell boat. Dodge the lily pads.', keys:'Up / Down steer',
 how:['Your boat races across the pond.','Press Up and Down to change lanes.','Every hit costs you. Reach the finish line!'],
 hud:s=>'Hits '+s.hits+'  |  '+Math.max(0,Math.ceil(s.dur-s.t))+'s',
 init(s){ s.lane=1; s.obs=[]; s.t=0; s.hits=0; s.spawn=0.5; s.flash=0; s.dur=14; s.off=0; },
 update(s,dt){
  s.t+=dt; const sp=150+s.t*7; s.off=(s.off+sp*dt)%60; s.spawn-=dt;
  if(s.spawn<=0){ s.spawn=mgRnd(0.5,0.8); s.obs.push({x:MGW+30,l:Math.floor(Math.random()*3)}); }
  for(const o of s.obs){ o.x-=sp*dt; if(!o.hit&&o.l===s.lane&&Math.abs(o.x-90)<24){ o.hit=1; s.hits++; s.flash=0.4; mgTone(0); } }
  s.obs=s.obs.filter(o=>o.x>-40); s.flash=Math.max(0,s.flash-dt);
  if(s.t>=s.dur){ s.done=1; s.score=Math.max(0,10-s.hits*2); }
 },
 press(s,k){ if(k==='up') s.lane=Math.max(0,s.lane-1); else if(k==='down') s.lane=Math.min(2,s.lane+1); },
 draw(s,c,t){
  mgSky(c,'#2f7fb0','#1d5e8a');
  for(let l=0;l<3;l++){ const y=70+l*65; rect(c,0,y-28,MGW,56,l%2?'#256f9c':'#2b78a6'); for(let x=-s.off;x<MGW;x+=60) rect(c,x,y-2+Math.sin(x*0.1+t*3)*2,26,2,'rgba(255,255,255,0.22)'); }
  for(const o of s.obs){ const y=70+o.l*65; ell(c,o.x,y+4,20,8,'#3f9a4a'); ell(c,o.x-3,y+2,16,6,'#57b85a'); rect(c,o.x+4,y,16,3,'#2b78a6'); circ(c,o.x-6,y,4,'#f4c6e0'); }
  const by=70+s.lane*65;
  c.save(); if(s.flash>0) c.translate(Math.sin(t*60)*2,0);
  ell(c,90,by+8,22,8,'#7a4f26'); ell(c,90,by+5,20,6,'#a8743a'); mgDuck(c,90,by+2,0.9);
  rect(c,96,by-40,2,26,'#6b4a2f'); c.fillStyle='#f4efe0'; c.beginPath(); c.moveTo(98,by-40); c.lineTo(98,by-16); c.lineTo(122,by-16); c.fill();
  c.restore();
  const fin=Math.max(0,1-(s.dur-s.t)/2.5); if(fin>0){ for(let i=0;i<10;i++) rect(c,MGW-fin*80,i*27,10,13,i%2?'#fff':'#222'); }
 }
};

/* Pie-Eating Contest: mash it */
MG.pie={
 hint:'Gobble as many pies as you can before time runs out.', keys:'Z / Left / Right gobble',
 how:['Mash Z (or Left and Right) to gobble!','Ten seconds on the clock.','Do not stop to think about it.'],
 hud:s=>Math.max(0,Math.ceil(s.dur-s.t))+'s  |  Pies '+Math.floor(s.bites/8),
 init(s){ s.t=0; s.bites=0; s.dur=10; s.chew=0; s.crumbs=[]; },
 update(s,dt){ s.t+=dt; s.chew=Math.max(0,s.chew-dt*7); for(const q of s.crumbs){ q.x+=q.vx*dt; q.y+=q.vy*dt; q.vy+=400*dt; } s.crumbs=s.crumbs.filter(q=>q.y<260);
  if(s.t>=s.dur){ s.done=1; s.score=Math.min(10,s.bites/3.5); } },
 press(s,k){ if(k==='z'||k==='left'||k==='right'){ s.bites++; s.chew=1; blip(); for(let i=0;i<3;i++) s.crumbs.push({x:250,y:150,vx:mgRnd(-70,70),vy:mgRnd(-120,-40)}); } },
 draw(s,c,t){
  mgSky(c,'#f2d9a8','#e8c88a'); rect(c,0,170,MGW,100,'#a8743a'); rect(c,0,170,MGW,6,'#7a5226');
  for(let i=0;i<5;i++){ const done=Math.floor(s.bites/8), x=60+i*90, y=190;
    if(i<done) continue; const f=i===done?1-(s.bites%8)/8:1;
    ell(c,x,y,32,12,'#d9b86a'); c.save(); c.beginPath(); c.moveTo(x,y); c.arc(x,y-4,30,-Math.PI*2*f+Math.PI*0.5,Math.PI*0.5); c.lineTo(x,y); c.fillStyle='#b0343a'; c.fill(); c.restore(); if(f<1) ell(c,x,y,32,12,'rgba(217,184,106,0.55)'); }
  const sc=1.8+s.chew*0.3; mgDuck(c,250,150,sc); rect(c,250+13*sc*0.8,150-20*sc,8*sc,3*sc+s.chew*5,'#ff8a1f');
  for(const q of s.crumbs) rect(c,q.x,q.y,3,3,'#b0343a');
  mgBar(c,60,245,360,10,1-s.t/s.dur,'#ff8a1f');
 }
};

/* Puddle Jumping Day: jump the puddles */
MG.puddle={
 hint:'Jump the puddles. Landing in one is a splash, and a miss.', keys:'Z jump',
 how:['You run on your own.','Press Z to jump over each puddle.','Ten puddles, and they get wider.'],
 hud:s=>'Cleared '+s.cleared+'/10',
 init(s){ s.px=0; s.y=0; s.vy=0; s.cleared=0; s.n=0; s.end=0; s.pud=[]; let x=420; for(let i=0;i<10;i++){ const w=44+i*3+Math.random()*16; s.pud.push({x:x,w:w,hit:0,done:0}); x+=w+mgRnd(150,230); } s.splash=0; },
 update(s,dt){
  s.px+=(170+s.n*9)*dt;
  s.vy+=900*dt; s.y+=s.vy*dt; if(s.y>=0){ s.y=0; s.vy=0; }
  s.splash=Math.max(0,s.splash-dt);
  for(const p of s.pud){
    if(p.done) continue;
    if(s.px>p.x&&s.px<p.x+p.w&&s.y>-8&&!p.hit){ p.hit=1; s.splash=0.5; mgTone(0); }
    if(s.px>p.x+p.w+10){ p.done=1; s.n++; if(!p.hit){ s.cleared++; mgTone(1); } }
  }
  if(s.n>=10){ s.end+=dt; if(s.end>0.6){ s.done=1; s.score=s.cleared; } }
 },
 press(s,k){ if(k==='z'&&s.y===0&&s.n<10){ s.vy=-340; blip(); } },
 draw(s,c,t){
  mgSky(c,'#b8c9d8','#d7dfe6'); rect(c,0,200,MGW,70,'#8a8f98'); rect(c,0,200,MGW,5,'#6b7078');
  for(let x=-(s.px%80);x<MGW;x+=80) rect(c,x,236,40,3,'rgba(255,255,255,0.25)');
  for(const p of s.pud){ const x=p.x-s.px+100; if(x>MGW||x+p.w<0) continue; ell(c,x+p.w/2,208,p.w/2,8,p.hit?'#4a86b0':'#5aa0c8'); ell(c,x+p.w/2-6,206,p.w/4,2.5,'rgba(255,255,255,0.4)'); }
  mgDuck(c,100,210+s.y,1.5);
  if(s.splash>0){ for(let i=0;i<6;i++) circ(c,100+Math.cos(i)*14*(1.5-s.splash),198-Math.abs(Math.sin(i*2))*22*s.splash*2,2.5,'#9ad0f0'); }
 }
};

/* Great Bake-Off: remember the recipe */
const BAKE_ING=[{n:'flour',k:'up'},{n:'egg',k:'right'},{n:'butter',k:'down'},{n:'berries',k:'left'}];
MG.bake={
 hint:'Watch the recipe, then repeat it with the arrow keys.', keys:'Arrow keys',
 how:['The judges show you a recipe, ingredient by ingredient.','Repeat it with the arrows:','Up flour, Right egg, Down butter, Left berries.'],
 hud:s=>'Recipe '+Math.min(5,s.round+1)+'/5',
 init(s){ s.round=0; s.pts=0; this.next(s); },
 next(s){ s.seq=[]; for(let i=0;i<s.round+2;i++) s.seq.push(Math.floor(Math.random()*4)); s.ph='show'; s.si=0; s.w=0.5; s.lit=-1; s.inp=0; s.msg='Watch the recipe...'; },
 update(s,dt){
  s.w-=dt;
  if(s.ph==='show'){
   if(s.w<=0){ if(s.lit>=0){ s.lit=-1; s.si++; s.w=0.25; if(s.si>=s.seq.length){ s.ph='input'; s.msg='Your turn!'; } } else { s.lit=s.seq[s.si]; s.w=0.6; blip(); } }
  } else if(s.ph==='input'){ if(s.w<=0) s.lit=-1; }
  else if(s.ph==='res'&&s.w<=0){ s.round++; if(s.round>=5){ s.done=1; s.score=s.pts; } else this.next(s); }
 },
 press(s,k){
  if(s.ph!=='input') return;
  const i=BAKE_ING.findIndex(b=>b.k===k); if(i<0) return;
  s.lit=i; s.w=0.2;
  if(s.seq[s.inp]===i){ s.inp++; tone('triangle',380+i*90,380+i*90,0.12,0.06); if(s.inp>=s.seq.length){ s.pts+=2; s.msg='Delicious!'; s.ph='res'; s.w=1; coin(); } }
  else { s.msg='Oh no, a flat loaf!'; s.ph='res'; s.w=1.1; mgTone(0); }
 },
 draw(s,c,t){
  mgSky(c,'#f6e7c8','#ead4a8'); rect(c,0,190,MGW,80,'#b98a55');
  ell(c,240,170,60,22,'#e8e0d0'); ell(c,240,164,52,16,'#cfc4ae'); ell(c,240,166,30,8,'#e8c88a');
  const pos=[[240,60],[360,150],[240,222],[120,150]];
  BAKE_ING.forEach((b,i)=>{
   const [x,y]=pos[i], lit=s.lit===i;
   circ(c,x,y,lit?36:30,lit?'rgba(255,230,140,0.55)':'rgba(0,0,0,0.12)');
   if(i===0){ rect(c,x-15,y-18,30,34,'#f4f4ee'); rect(c,x-15,y-18,30,6,'#d8d8d0'); mgT(c,'flour',x,y+2,11,'#7a7a70'); }
   if(i===1){ ell(c,x,y,13,17,'#f6efe0'); ell(c,x-4,y-5,4,6,'rgba(255,255,255,0.7)'); }
   if(i===2){ rect(c,x-18,y-9,36,18,'#f2d45a'); rect(c,x-18,y-9,36,5,'#fbe58a'); }
   if(i===3){ circ(c,x-7,y+2,9,'#6a3a8a'); circ(c,x+8,y-3,9,'#7a4a9a'); circ(c,x+1,y+9,8,'#5a2a7a'); }
   mgT(c,b.n,x,y+(i===2?28:i===0?30:34),11,lit?'#fff':'#6a5a40');
  });
  if(s.ph==='input'){ for(let i=0;i<s.seq.length;i++) circ(c,240-(s.seq.length-1)*9+i*18,110,5,i<s.inp?'#7fd37a':'#8a7a5a'); }
 }
};

/* Treasure Dig: hot and cold */
MG.dig={
 hint:'Dig where the chest is buried. The ground tells you hot or cold.', keys:'Arrows move, Z dig',
 how:['Move with the arrow keys and press Z to dig.','Each hole shows how close the chest is:','red is hot, blue is cold. Seven digs at most.'],
 hud:s=>'Digs '+s.n+'/7',
 init(s){ s.cols=8; s.rows=5; s.cx=3; s.cy=2; s.chest=[Math.floor(Math.random()*8),Math.floor(Math.random()*5)]; s.holes={}; s.n=0; s.found=0; s.w=0; s.msg='Where could it be?'; },
 update(s,dt){ if(s.w>0){ s.w-=dt; if(s.w<=0){ s.done=1; s.score=s.found?[10,9,8,7,5,3,1][s.n-1]:0; } } },
 press(s,k){
  if(s.w>0) return;
  if(k==='left') s.cx=Math.max(0,s.cx-1); else if(k==='right') s.cx=Math.min(s.cols-1,s.cx+1);
  else if(k==='up') s.cy=Math.max(0,s.cy-1); else if(k==='down') s.cy=Math.min(s.rows-1,s.cy+1);
  else if(k==='z'){
   const key=s.cx+','+s.cy; if(s.holes[key]!==undefined) return;
   s.n++; const d=Math.abs(s.cx-s.chest[0])+Math.abs(s.cy-s.chest[1]);
   s.holes[key]=d; blip();
   if(d===0){ s.found=1; s.msg='THE CHEST!'; s.w=1.4; coin(); }
   else { s.msg=d<=1?'Scorching hot!':d<=2?'Hot!':d<=4?'Warm...':'Cold.'; if(s.n>=7){ s.w=1.4; s.msg='Out of digs. It was here...'; } }
  }
 },
 draw(s,c,t){
  mgSky(c,'#7fc4e8','#bfe3a0'); rect(c,0,40,MGW,230,'#6aa84f');
  const ox=48, oy=40;
  for(let y=0;y<s.rows;y++) for(let x=0;x<s.cols;x++){
   const px=ox+x*48, py=oy+y*44, k=x+','+y, d=s.holes[k];
   rect(c,px,py,48,44,(x+y)%2?'#79b45a':'#70ad52');
   if(d!==undefined){ const col=d===0?'#f2c230':d<=1?'#e0452f':d<=2?'#f08a3a':d<=4?'#e8d060':'#5a9ad8'; ell(c,px+24,py+24,17,10,'#3b2a18'); ell(c,px+24,py+22,15,8,col); }
  }
  if(s.w>0||s.found){ const [x,y]=s.chest; rect(c,ox+x*48+9,oy+y*44+12,30,22,'#7a4f26'); rect(c,ox+x*48+9,oy+y*44+12,30,7,'#a8743a'); rect(c,ox+x*48+21,oy+y*44+17,6,8,'#f2c230'); }
  c.strokeStyle='#fff'; c.lineWidth=3; c.strokeRect(ox+s.cx*48+2,oy+s.cy*44+2,44,40);
  mgDuck(c,ox+s.cx*48+24,oy+s.cy*44+36,0.9);
 }
};

/* Duck-Duck-Goose: react when you are the goose */
MG.goose={
 hint:'Wait for the word GOOSE, then run! Not a moment before.', keys:'Z run',
 how:['You sit in the circle. Someone walks round','saying "Duck... duck... duck..."','When they say GOOSE, press Z to run! (Not before.)'],
 hud:s=>'Round '+Math.min(5,s.round+1)+'/5',
 init(s){ s.round=0; s.pts=0; this.next(s); },
 next(s){ s.n=8; s.me=6; s.steps=3+Math.floor(Math.random()*6); s.step=0; s.idx=((s.me-s.steps)%8+8)%8; s.w=mgRnd(0.5,0.9); s.ph='walk'; s.rt=0; s.msg='Duck...'; },
 update(s,dt){
  if(s.ph==='walk'){
   s.w-=dt;
   if(s.w<=0){ s.step++; s.idx=(s.idx+1)%8; if(s.step>=s.steps){ s.ph='goose'; s.rt=0; s.msg='GOOSE!'; tone('square',520,760,0.2,0.07); } else { s.w=mgRnd(0.28,0.55); } }
  } else if(s.ph==='goose'){ s.rt+=dt; if(s.rt>1.2){ s.msg='Too slow!'; s.ph='res'; s.w=1; mgTone(0); } }
  else if(s.ph==='res'){ s.w-=dt; s.run=Math.min(1,(s.run||0)+dt*1.6); if(s.w<=0){ s.round++; s.run=0; if(s.round>=5){ s.done=1; s.score=s.pts; } else this.next(s); } }
 },
 press(s,k){
  if(k!=='z') return;
  if(s.ph==='walk'){ s.msg='Too early! Wait for it...'; s.ph='res'; s.w=1.1; mgTone(0); }
  else if(s.ph==='goose'){ const r=s.rt<0.45?2:s.rt<0.8?1:0; s.pts+=r; s.msg=r===2?'Lightning!':r===1?'Caught up!':'Barely.'; s.ph='res'; s.w=1; mgTone(r); }
 },
 draw(s,c,t){
  mgSky(c,'#a8d8ef','#cfe9b0'); ell(c,240,160,190,100,'#6aa84f'); ell(c,240,160,150,76,'#79b45a');
  const pal=['#f4f4ee','#8d7352','#9aa4ad','#d9a066','#e9b7c8','#87b4d8','#ffd84a','#c9a46a'];
  for(let i=0;i<8;i++){
   const a=i/8*Math.PI*2+Math.PI/2, x=240+Math.cos(a)*150, y=170+Math.sin(a)*72;
   const me=(i===s.me), isG=(s.ph==='goose'||s.ph==='res')&&me&&s.idx===i;
   mgDuck(c,x,y,me?1.4:1.1,me?'#ffd84a':pal[i%pal.length],Math.cos(a)>0?-1:1);
   if(s.idx===i&&s.ph==='walk') mgT(c,'*',x,y-48,20,'#fff');
   if(isG&&s.ph==='goose') mgT(c,'!',x,y-52,26,'#e0452f');
  }
  mgT(c,'(you)',240+Math.cos(Math.PI/2+6/8*Math.PI*2)*150,170+Math.sin(Math.PI/2+6/8*Math.PI*2)*72+14,10,'#222');
  if(s.ph==='goose'||s.ph==='walk') { const w=s.ph==='goose'?mgClamp(1-s.rt/1.2,0,1):1; mgBar(c,160,246,160,8,w,s.ph==='goose'?'#e0452f':'#4a6a5a'); }
 }
};

/* Pumpkin Roll: keep the pumpkin on the track */
MG.pumpkin={
 hint:'Nudge the pumpkin and keep it on the path. It has opinions.', keys:'Up / Down nudge',
 how:['The pumpkin rolls toward the barn.','Hold Up or Down to nudge it back on the path.','It drifts. It always drifts.'],
 hud:s=>Math.max(0,Math.ceil(s.dur-s.t))+'s',
 init(s){ s.t=0; s.y=0; s.vy=0; s.dv=0; s.inb=0; s.dur=12; s.ang=0; },
 update(s,dt){
  s.t+=dt; s.dv+=(Math.random()-0.5)*700*dt; s.dv*=1-0.7*dt; s.dv=mgClamp(s.dv,-110,110);
  s.vy+=s.dv*dt*2; if(keys.up) s.vy-=300*dt; if(keys.down) s.vy+=300*dt; s.vy*=1-dt*1.1; s.y+=s.vy*dt;
  if(Math.abs(s.y)>105){ s.y=mgClamp(s.y,-105,105); s.vy*=-0.3; }
  s.ang+=dt*7; if(Math.abs(s.y)<30) s.inb+=dt;
  if(s.t>=s.dur){ s.done=1; s.score=Math.min(10,10*s.inb/s.dur*1.08); }
 },
 press(s,k){},
 draw(s,c,t){
  mgSky(c,'#f6d29a','#e8a45a'); rect(c,0,60,MGW,210,'#8fb04a'); rect(c,0,60,MGW,6,'#6a8a30');
  rect(c,0,135-32,MGW,64,'#c9a46a'); rect(c,0,135-32,MGW,3,'#a8844a'); rect(c,0,135+29,MGW,3,'#a8844a');
  for(let x=-((s.t*140)%60);x<MGW;x+=60){ rect(c,x,131,28,3,'rgba(255,255,255,0.2)'); circ(c,x+20,70,2,'#e0a050'); }
  const bx=MGW-70-(1-Math.min(1,s.t/s.dur))*0; rect(c,MGW-60,70,56,50,'#a8432b'); c.fillStyle='#7a2a1a'; c.beginPath(); c.moveTo(MGW-66,70); c.lineTo(MGW-32,46); c.lineTo(MGW-2,70); c.fill(); rect(c,MGW-42,92,20,28,'#3b2a18');
  const py=135+s.y, px=220;
  ell(c,px,py+16,18,5,'rgba(0,0,0,0.25)'); circ(c,px,py,17,'#e8832a'); c.save(); c.translate(px,py); c.rotate(s.ang*0.3);
  c.strokeStyle='#c4661a'; c.lineWidth=2; for(let i=-1;i<=1;i++){ c.beginPath(); c.ellipse(i*7,0,5,16,0,0,6.3); c.stroke(); } rect(c,-2,-21,4,6,'#4f7a2a'); c.restore();
  const grin=Math.abs(s.y)<30; rect(c,px-7,py-4,4,4,'#3b2a18'); rect(c,px+3,py-4,4,4,'#3b2a18'); rect(c,px-6,py+5,12,grin?3:2,'#3b2a18');
  mgBar(c,60,250,360,8,s.inb/s.dur,'#e8832a');
 }
};

/* Ice Slide Derby: steer down the hill */
MG.iceslide={
 hint:'Lean left and right to dodge the rocks on your belly slide.', keys:'Left / Right steer',
 how:['You slide down the hill on your belly.','Hold Left or Right to steer.','Rocks cost you points. Dodge them!'],
 hud:s=>'Hits '+s.hits+'  |  '+Math.max(0,Math.ceil(s.dur-s.t))+'s',
 init(s){ s.x=240; s.t=0; s.dur=13; s.hits=0; s.rocks=[]; s.spawn=0.4; s.flash=0; s.snow=[]; for(let i=0;i<30;i++) s.snow.push([Math.random()*MGW,Math.random()*MGH]); },
 update(s,dt){
  s.t+=dt; const sp=190+s.t*9;
  if(keys.left) s.x-=250*dt; if(keys.right) s.x+=250*dt; s.x=mgClamp(s.x,50,MGW-50);
  s.spawn-=dt; if(s.spawn<=0){ s.spawn=mgRnd(0.4,0.7); s.rocks.push({x:mgRnd(40,MGW-40),y:-20,w:mgRnd(18,28)}); }
  for(const r of s.rocks){ r.y+=sp*dt; if(!r.hit&&Math.abs(r.x-s.x)<r.w+10&&Math.abs(r.y-200)<22){ r.hit=1; s.hits++; s.flash=0.4; mgTone(0); } }
  s.rocks=s.rocks.filter(r=>r.y<MGH+30); s.flash=Math.max(0,s.flash-dt);
  for(const p of s.snow){ p[1]+=sp*dt*0.8; if(p[1]>MGH){ p[1]=0; p[0]=Math.random()*MGW; } }
  if(s.t>=s.dur){ s.done=1; s.score=Math.max(0,10-s.hits*2); }
 },
 press(s,k){},
 draw(s,c,t){
  mgSky(c,'#dcecf8','#f4fbff');
  c.fillStyle='rgba(180,210,235,0.35)'; for(let i=0;i<4;i++) c.fillRect(30+i*130+Math.sin(s.t*1.5+i)*10,0,5,MGH);
  for(const p of s.snow) rect(c,p[0],p[1],2,2,'#fff');
  for(const r of s.rocks){ ell(c,r.x,r.y+6,r.w,r.w*0.55,'rgba(0,0,0,0.15)'); ell(c,r.x,r.y,r.w,r.w*0.7,'#7a808c'); ell(c,r.x-r.w*0.3,r.y-r.w*0.2,r.w*0.4,r.w*0.25,'#9aa0ac'); }
  c.save(); c.translate(s.x,200); if(s.flash>0) c.rotate(Math.sin(t*50)*0.25); c.scale(1.2,1.2);
  ell(c,0,10,22,7,'#3a62a8'); mgDuck(c,0,8,1); c.restore();
  const fin=Math.max(0,1-(s.dur-s.t)/2); if(fin>0) for(let i=0;i<24;i++) rect(c,i*20,MGH-fin*60,10,10,i%2?'#222':'#fff');
 }
};

/* Sandcastle Contest: stack the blocks */
MG.sandcastle={
 hint:'Stack the sand blocks as neatly as you can.', keys:'Z drop',
 how:['A block of sand swings overhead.','Press Z to drop it onto the tower.','Overhang gets trimmed off. Five blocks.'],
 hud:s=>'Block '+Math.min(5,s.n+1)+'/5',
 init(s){ s.n=0; s.pts=0; s.tower=[{x:140,w:200}]; s.w=Math.min(200,180); s.x=0; s.dir=1; s.spd=200; s.fall=null; s.fx=null; },
 update(s,dt){
  if(s.fall){ s.fall.t+=dt; if(s.fall.t>0.25){ const f=s.fall, top=s.tower[s.tower.length-1];
    const ov=Math.min(f.x+f.w,top.x+top.w)-Math.max(f.x,top.x);
    if(ov<=4){ s.msg='Missed the tower!'; s.done=1; s.score=s.pts; return; }
    const fr=ov/f.w, r=fr>=0.9?2:fr>=0.55?1:0; s.pts+=r; s.msg=r===2?'Perfect!':r===1?'Good':'Wobbly...'; mgTone(r>0);
    s.tower.push({x:Math.max(f.x,top.x),w:Math.max(40,ov)}); s.n++; s.fall=null;
    if(s.n>=5){ s.done=1; s.score=s.pts; return; }
    s.w=s.tower[s.tower.length-1].w; s.spd=210+s.n*35; s.x=0; s.dir=1; } return; }
  s.x+=s.dir*s.spd*dt; if(s.x+s.w>=MGW){ s.x=MGW-s.w; s.dir=-1; } if(s.x<=0){ s.x=0; s.dir=1; }
 },
 press(s,k){ if(k==='z'&&!s.fall){ s.fall={x:s.x,w:s.w,t:0}; blip(); } },
 draw(s,c,t){
  mgSky(c,'#9fd8f0','#f6e8c0'); rect(c,0,236,MGW,34,'#e8d29a'); rect(c,0,236,MGW,4,'#c9b078'); rect(c,0,200,MGW,36,'#3a8fc0');
  rect(c,0,236,MGW,34,'#e8d29a');
  const bh=26;
  s.tower.forEach((b,i)=>{ const y=236-(i+1)*bh; rect(c,b.x,y,b.w,bh,'#d9b86a'); rect(c,b.x,y,b.w,4,'#ecd28a'); rect(c,b.x,y+bh-3,b.w,3,'#b8964a'); for(let k=0;k<b.w;k+=14) rect(c,b.x+k+3,y+8,2,2,'#b8964a'); });
  if(s.n>=5){ const b=s.tower[s.tower.length-1], y=236-s.tower.length*bh; rect(c,b.x+b.w/2-1,y-24,2,24,'#6b4a2f'); rect(c,b.x+b.w/2,y-24,16,9,'#e0452f'); }
  const top=236-(s.tower.length)*bh;
  if(!s.fall){ rect(c,s.x,40,s.w,bh,'#e0c27a'); rect(c,s.x,40,s.w,4,'#f0d898'); rect(c,s.x+s.w/2-1,0,2,40,'#6b4a2f'); }
  else { const u=Math.min(1,s.fall.t/0.25); const y=40+(top-40)*u; rect(c,s.fall.x,y,s.fall.w,bh,'#e0c27a'); }
 }
};

/* Haggling Championship: tug the price your way */
MG.haggle={
 hint:'Hold your price. Mash Z to push the marker to your side.', keys:'Z push',
 how:['The vendor drags the price his way.','Mash Z to pull it back to your side.','Get it all the way over to win the haggle.'],
 hud:s=>Math.max(0,Math.ceil(s.dur-s.t))+'s',
 init(s){ s.t=0; s.m=0; s.dur=10; s.flash=0; },
 update(s,dt){
  s.t+=dt; const pull=0.2+0.03*s.t+0.12*Math.abs(Math.sin(s.t*2.7));
  s.m-=pull*dt; s.flash=Math.max(0,s.flash-dt);
  if(s.m>=1){ s.done=1; s.score=mgClamp(Math.round(14-s.t),8,10); s.msg='SOLD, at your price!'; }
  else if(s.m<=-1){ s.done=1; s.score=1; }
  else if(s.t>=s.dur){ s.done=1; s.score=mgClamp(Math.round(5+4*s.m),1,9); }
 },
 press(s,k){ if(k==='z'){ s.m=Math.min(1,s.m+0.09); s.flash=0.15; blip(); } },
 draw(s,c,t){
  mgSky(c,'#f2d9a8','#e0b878'); rect(c,0,190,MGW,80,'#b98a55'); rect(c,0,190,MGW,5,'#8a6238');
  rect(c,150,150,180,40,'#8a6238'); rect(c,150,150,180,6,'#b98a55');
  mgDuck(c,70+s.m*20,205,1.7); mgDuck(c,410+s.m*20,205,1.7,'#8d7352',-1); rect(c,396+s.m*20,178,18,4,'#3b2a18');
  const bx=60, bw=360, by=70;
  rect(c,bx,by,bw,22,'#1c2b24'); rect(c,bx+bw/2,by,bw/2*mgClamp(s.m,0,1),22,'#7fd37a'); if(s.m<0) rect(c,bx+bw/2+bw/2*s.m,by,-bw/2*s.m,22,'#e0452f');
  rect(c,bx+bw/2-1,by-4,2,30,'#fff'); const mx=bx+bw/2+s.m*bw/2; circ(c,mx,by+11,12+s.flash*20,'#f2c230'); mgT(c,'$',mx,by+11,14,'#7a5a10');
  mgT(c,'vendor',bx+bw-24,by-14,11,'#e0a090'); mgT(c,'you',bx+22,by-14,11,'#9be08a');
 }
};

/* ============ SHOP JOB GAMES ============ */

/* Bakery: knead the dough by alternating left and right */
MG.knead={
 hint:'Fold the dough: alternate Left and Right as fast as you can.', keys:'Left, Right, Left, Right...',
 how:['Fold the dough from side to side.','Alternate Left and Right as quickly as you can.','The smoother the dough, the better the bread.'],
 hud:s=>Math.max(0,Math.ceil(s.dur-s.t))+'s',
 init(s){ s.t=0; s.alt=0; s.last=null; s.dur=9; s.sq=0; s.puff=[]; },
 update(s,dt){ s.t+=dt; s.sq=Math.max(0,s.sq-dt*6); for(const p of s.puff){ p.y-=40*dt; p.a-=dt*1.4; } s.puff=s.puff.filter(p=>p.a>0);
  if(s.t>=s.dur){ s.done=1; s.score=Math.min(10,s.alt/3.2); } },
 press(s,k){ if((k==='left'||k==='right')&&k!==s.last){ s.last=k; s.alt++; s.sq=1; blip(); s.puff.push({x:240+(k==='left'?-50:50),y:170,a:1}); } else if(k==='left'||k==='right'){ s.msg='Alternate!'; } },
 draw(s,c,t){
  mgSky(c,'#f6e7c8','#ead4a8'); rect(c,0,190,MGW,80,'#b98a55'); rect(c,0,190,MGW,5,'#8a6238');
  const sm=Math.min(1,s.alt/32), w=60+sm*50, sx=(s.last==='left'?-1:s.last==='right'?1:0)*s.sq*8;
  ell(c,240+sx,185,w+8,18,'rgba(255,255,255,0.35)');
  ell(c,240+sx,170-s.sq*4,w,26-s.sq*4,'#f0dcb0'); ell(c,240+sx-w*0.25,164-s.sq*4,w*0.4,8,'rgba(255,255,255,0.4)');
  const rough=1-sm; for(let i=0;i<8;i++) if(rough>i/9) rect(c,240+sx+Math.sin(i*2.3)*w*0.7,160+Math.cos(i*3.1)*8,5,3,'#cfae78');
  for(const p of s.puff) circ(c,p.x,p.y,6,'rgba(255,255,255,'+(p.a*0.6).toFixed(2)+')');
  mgDuck(c,100,200,1.4); mgBar(c,60,245,360,10,sm,'#e8c070');
  mgT(c,sm>0.95?'Silky smooth!':sm>0.5?'Getting there':'Lumpy',240,228,12,'#6a4a22');
 }
};

/* Market: sort ripe from rotten */
MG.produce={
 hint:'Ripe fruit goes up in the basket. Rotten goes down in the bin.', keys:'Up ripe, Down rotten',
 how:['Fruit rolls past on the belt.','Press Up to keep the ripe ones.','Press Down to bin the rotten ones (brown and spotty).'],
 hud:s=>'Sorted '+s.sorted+'/10  |  Right '+s.right,
 init(s){ s.items=[]; s.sp=0; s.sorted=0; s.right=0; s.spawn=0.5; s.cnt=0; s.flash=null; },
 update(s,dt){
  s.spawn-=dt; if(s.spawn<=0&&s.cnt<10){ s.spawn=1.05; s.cnt++; s.items.push({x:-20,ripe:Math.random()<0.5,t:Math.floor(Math.random()*3),res:null}); }
  const sp=120+s.sorted*8;
  for(const it of s.items){ if(it.res===null){ it.x+=sp*dt; if(it.x>350){ it.res=false; s.sorted++; mgTone(0); it.fx=0; } } else { it.fx+=dt; } }
  s.items=s.items.filter(i=>i.res===null||i.fx<0.45);
  if(s.sorted>=10&&!s.items.length){ s.done=1; s.score=s.right; }
 },
 press(s,k){
  if(k!=='up'&&k!=='down') return;
  const it=s.items.find(i=>i.res===null&&i.x>150&&i.x<350)||s.items.find(i=>i.res===null&&i.x>60);
  if(!it) return;
  const ok=(k==='up')===it.ripe; it.res=ok; it.dir=k; it.fx=0; s.sorted++; if(ok) s.right++; mgTone(ok);
 },
 draw(s,c,t){
  mgSky(c,'#cfe8c0','#b8d8a0'); rect(c,0,135,MGW,36,'#4a4f5a'); for(let x=-((s.time||0)*100%24);x<MGW;x+=24) rect(c,x,135,2,36,'#3a3f48');
  rect(c,0,171,MGW,6,'#2a2e36');
  ell(c,240,60,56,26,'#8a5a2b'); ell(c,240,52,52,20,'#a8743a'); mgT(c,'RIPE',240,56,16,'#fff4c2');
  rect(c,190,215,100,38,'#5a5f6a'); rect(c,190,215,100,6,'#7a808c'); mgT(c,'BIN: ROTTEN',240,238,12,'#fff');
  const cols=[['#d6402f','#f0705a'],['#f2c230','#ffe07a'],['#7ac24a','#a8e070']];
  for(const it of s.items){
   const y=res=>res;
   let yy=153, x=it.x, a=1;
   if(it.res!==null&&it.fx!==undefined&&it.dir){ const u=Math.min(1,it.fx/0.45); yy=153+(it.dir==='up'?-95:80)*u; x=it.x+(240-it.x)*u*0.5; a=1-u*0.4; }
   else if(it.res===false){ a=0.4; }
   c.globalAlpha=a;
   if(it.ripe){ circ(c,x,yy,13,cols[it.t][0]); circ(c,x-4,yy-4,4,cols[it.t][1]); rect(c,x-1,yy-17,2,5,'#4f7a2a'); }
   else { circ(c,x,yy,13,'#7a6a3a'); circ(c,x+3,yy+2,3,'#3b2a18'); circ(c,x-5,yy-3,2.5,'#3b2a18'); circ(c,x+2,yy-6,2,'#5a8a3a'); rect(c,x-1,yy-17,2,5,'#4a3a22'); mgT(c,'~',x,yy-24+Math.sin(t*6+x)*2,14,'#6a8a30'); }
   c.globalAlpha=1;
  }
  rect(c,150,127,200,2,'rgba(255,255,255,0.35)'); rect(c,150,177,200,2,'rgba(255,255,255,0.35)');
 }
};

/* Supply shop: rub the smudges off the lens */
MG.lens={
 hint:'Polish every smudge off the lens before time runs out.', keys:'Arrows move, hold Z to rub',
 how:['Move the cloth with the arrow keys.','Hold Z over a smudge to rub it away.','Get the whole lens sparkling.'],
 hud:s=>Math.max(0,Math.ceil(s.dur-s.t))+'s  |  '+Math.round(s.clean*100)+'% clean',
 init(s){ s.t=0; s.dur=15; s.cx=240; s.cy=135; s.sm=[]; for(let i=0;i<6;i++){ const a=Math.random()*6.28, r=Math.random()*70; s.sm.push({x:240+Math.cos(a)*r,y:135+Math.sin(a)*r*0.9,r:mgRnd(24,36),a:1}); } s.clean=0; s.sh=0; },
 update(s,dt){
  s.t+=dt; const sp=190*dt;
  if(keys.left) s.cx-=sp; if(keys.right) s.cx+=sp; if(keys.up) s.cy-=sp; if(keys.down) s.cy+=sp;
  s.cx=mgClamp(s.cx,130,350); s.cy=mgClamp(s.cy,40,230);
  s.rub=!!keys.z;
  if(s.rub) for(const m of s.sm) if(Math.hypot(s.cx-m.x,s.cy-m.y)<m.r+8) m.a=Math.max(0,m.a-dt*1.3);
  s.clean=1-s.sm.reduce((a,m)=>a+m.a,0)/s.sm.length;
  if(s.clean>0.985||s.t>=s.dur){ s.done=1; s.score=Math.min(10,s.clean*10+ (s.clean>0.985?0.5:0)); }
 },
 press(s,k){},
 draw(s,c,t){
  mgSky(c,'#2a3a34','#1c2924'); rect(c,0,230,MGW,40,'#5a3f22');
  circ(c,240,135,102,'#8a6a2a'); circ(c,240,135,94,'#9ad3f0'); circ(c,240,135,94,'rgba(255,255,255,0.15)');
  c.fillStyle='rgba(255,255,255,0.35)'; c.beginPath(); c.ellipse(205,95,40,12,-0.6,0,6.3); c.fill();
  for(const m of s.sm){ if(m.a>0.02){ circ(c,m.x,m.y,m.r,'rgba(70,55,40,'+(0.7*m.a).toFixed(2)+')'); circ(c,m.x+4,m.y-3,m.r*0.5,'rgba(50,40,30,'+(0.5*m.a).toFixed(2)+')'); } }
  if(s.clean>0.6) for(let i=0;i<3;i++){ const u=(t*1.5+i)%3; if(u<0.4) mgT(c,'*',200+i*50,90+i*20,16+u*10,'rgba(255,255,255,'+(1-u*2.2).toFixed(2)+')'); }
  c.save(); c.translate(s.cx,s.cy); c.rotate(s.rub?Math.sin(t*40)*0.3:0); circ(c,0,0,18,'#e8dcc0'); circ(c,0,0,14,'#f4ecd8'); rect(c,-10,-3,20,2,'#d0c4a4'); c.restore();
  if(s.rub) mgT(c,'rub rub',s.cx,s.cy-28,11,'#fff');
 }
};

/* Curio shop: spot the thing that changed */
function mgCurio(c,id,x,y,sc){
  sc=sc||1; c.save(); c.translate(x,y); c.scale(sc,sc);
  if(id===0){ ell(c,0,6,12,14,'#3a7ca5'); rect(c,-5,-14,10,10,'#3a7ca5'); rect(c,-8,-16,16,4,'#2a5c85'); ell(c,-3,4,3,7,'rgba(255,255,255,0.4)'); }
  else if(id===1){ rect(c,-10,-16,20,3,'#8a6a2a'); rect(c,-10,13,20,3,'#8a6a2a'); c.fillStyle='#e8d29a'; c.beginPath(); c.moveTo(-8,-13); c.lineTo(8,-13); c.lineTo(0,0); c.lineTo(8,13); c.lineTo(-8,13); c.lineTo(0,0); c.fill(); }
  else if(id===2){ ell(c,0,4,13,10,'#c0392b'); rect(c,-5,-9,10,5,'#8a2a20'); rect(c,13,-2,8,3,'#c0392b'); rect(c,-18,-2,6,8,'#c0392b'); circ(c,0,-12,3,'#f2c230'); }
  else if(id===3){ c.fillStyle='#e0b84a'; c.beginPath(); c.moveTo(-13,12); c.quadraticCurveTo(-13,-12,0,-14); c.quadraticCurveTo(13,-12,13,12); c.fill(); rect(c,-14,11,28,4,'#b8902a'); circ(c,0,16,3,'#6a4a10'); }
  else if(id===4){ circ(c,0,0,14,'#4a9a5a'); ell(c,-4,-3,5,7,'#7ac27a'); ell(c,6,5,5,4,'#7ac27a'); c.strokeStyle='#8a6a2a'; c.lineWidth=2; c.beginPath(); c.ellipse(0,0,17,5,-0.5,0,6.3); c.stroke(); }
  else if(id===5){ circ(c,-6,-5,8,'#d9b030'); circ(c,-6,-5,3,'#0b130f'); rect(c,0,-3,18,5,'#d9b030'); rect(c,12,2,4,7,'#d9b030'); rect(c,17,2,3,6,'#d9b030'); }
  else if(id===6){ rect(c,-5,-4,10,18,'#f4efe0'); c.fillStyle='#ff9d2e'; c.beginPath(); c.ellipse(0,-10,4,8,0,0,6.3); c.fill(); circ(c,0,-10,2,'#fff4c2'); }
  else { c.fillStyle='#8a5ac8'; c.beginPath(); c.moveTo(-13,12); c.lineTo(-13,-6); c.lineTo(-7,2); c.lineTo(0,-10); c.lineTo(7,2); c.lineTo(13,-6); c.lineTo(13,12); c.fill(); rect(c,-13,10,26,3,'#5a3a98'); circ(c,0,-10,2.5,'#f2c230'); }
  c.restore();
}
MG.curio={
 hint:'Memorise the shelf. Something is swapped while the cloth is on.', keys:'Left / Right pick, Z choose',
 how:['Six curios sit on the shelf. Memorise them.','A cloth covers them for a moment.','One has been swapped. Pick the new one!'],
 hud:s=>'Shelf '+Math.min(5,s.round+1)+'/5',
 init(s){ s.round=0; s.pts=0; this.next(s); },
 next(s){
  const ids=[0,1,2,3,4,5,6,7].sort(()=>Math.random()-0.5);
  s.a=ids.slice(0,6); s.spare=ids.slice(6); s.b=s.a.slice(); s.ch=Math.floor(Math.random()*6); s.b[s.ch]=s.spare[Math.floor(Math.random()*2)];
  s.ph='look'; s.w=3.4-s.round*0.25; s.cur=0; s.msg='Memorise!';
 },
 update(s,dt){
  s.w-=dt;
  if(s.ph==='look'&&s.w<=0){ s.ph='cover'; s.w=1.0; s.msg='...'; }
  else if(s.ph==='cover'&&s.w<=0){ s.ph='pick'; s.msg='Which one changed?'; }
  else if(s.ph==='res'&&s.w<=0){ s.round++; if(s.round>=5){ s.done=1; s.score=s.pts; } else this.next(s); }
 },
 press(s,k){
  if(s.ph!=='pick') return;
  if(k==='left') s.cur=(s.cur+5)%6; else if(k==='right') s.cur=(s.cur+1)%6;
  else if(k==='z'){ const ok=s.cur===s.ch; if(ok) s.pts+=2; s.msg=ok?'Sharp eyes!':'That was not it.'; s.ph='res'; s.w=1.2; mgTone(ok); }
 },
 draw(s,c,t){
  mgSky(c,'#3a2a1c','#2a1c12'); rect(c,20,150,440,10,'#8a5a2b'); rect(c,20,160,440,6,'#5a3a1a'); rect(c,20,60,440,8,'#8a5a2b');
  const show=(s.ph==='look')?s.a:s.b;
  for(let i=0;i<6;i++){
   const x=70+i*68, y=130;
   if(s.ph==='pick'||s.ph==='res'){ if(s.cur===i) rect(c,x-30,y-34,60,62,'rgba(255,230,140,0.25)'); }
   if(s.ph==='cover') continue;
   mgCurio(c,show[i],x,y,1.5);
   if(s.ph==='res'&&i===s.ch) { c.strokeStyle='#7fd37a'; c.lineWidth=3; c.strokeRect(x-30,y-34,60,62); }
  }
  if(s.ph==='cover'){ c.fillStyle='#7a2a3a'; c.fillRect(24,88,432,66); c.fillStyle='#9a3a4a'; for(let i=0;i<9;i++) c.fillRect(24+i*48,88,3,66); }
  if(s.ph==='look') mgBar(c,100,205,280,8,s.w/(3.4-s.round*0.25),'#ffd166');
  if(s.ph==='pick') mgT(c,'Left / Right to choose, Z to confirm',240,215,12,'#bca');
 }
};

/* Cafe: pour the tea to the line */
MG.pour={
 hint:'Hold Z to pour. Let go right at the gold line.', keys:'Hold Z pour',
 how:['Hold Z to pour the tea.','Let go when the tea reaches the gold line.','Too much and it spills. Five cups.'],
 hud:s=>'Cup '+Math.min(5,s.round+1)+'/5',
 init(s){ s.round=0; s.pts=0; this.next(s); },
 next(s){ s.fill=0; s.line=mgRnd(0.4,0.86); s.ph='ready'; s.armed=false; s.msg='Hold Z to pour'; s.w=0; },
 update(s,dt){
  if(s.ph==='ready'){ if(!keys.z) s.armed=true; else if(s.armed){ s.ph='pour'; } }
  if(s.ph==='pour'){
   if(keys.z){ s.fill+=0.4*dt; if(s.fill>=1){ s.fill=1; s.ph='res'; s.w=1.1; s.msg='Overflow! Mop!'; mgTone(0); } }
   else { const e=Math.abs(s.fill-s.line), r=e<0.035?2:e<0.09?1:0; s.pts+=r; s.msg=r===2?'Perfect pour!':r===1?'Close enough':(s.fill<s.line?'Half empty...':'A bit much.'); mgTone(r); s.ph='res'; s.w=1.1; }
  } else if(s.ph==='res'){ s.w-=dt; if(s.w<=0){ s.round++; if(s.round>=5){ s.done=1; s.score=s.pts; } else this.next(s); } }
 },
 press(s,k){},
 draw(s,c,t){
  mgSky(c,'#f2e2c0','#e4cc9a'); rect(c,0,200,MGW,70,'#b98a55'); rect(c,0,200,MGW,5,'#8a6238');
  const cx=300, top=70, bot=200, h=bot-top;
  c.fillStyle='#f4efe0'; c.beginPath(); c.moveTo(cx-44,top); c.lineTo(cx+44,top); c.lineTo(cx+34,bot); c.lineTo(cx-34,bot); c.fill();
  const fy=bot-h*s.fill; c.fillStyle='#b8742e'; c.beginPath(); c.moveTo(cx-34-(10*s.fill)+10,fy); c.lineTo(cx+44-10-(0),fy); c.lineTo(cx+34,bot-2); c.lineTo(cx-32,bot-2); c.fill();
  c.fillStyle='#b8742e'; c.fillRect(cx-40+s.fill*6,fy,80-s.fill*12,bot-fy-2);
  rect(c,cx+42,top+20,18,8,'#f4efe0'); rect(c,cx+54,top+20,6,40,'#f4efe0');
  const ly=bot-h*s.line; rect(c,cx-52,ly-1,104,3,'#f2c230'); c.fillStyle='#f2c230'; c.beginPath(); c.moveTo(cx-60,ly-6); c.lineTo(cx-52,ly); c.lineTo(cx-60,ly+6); c.fill();
  c.save(); c.translate(130,60); c.rotate(s.ph==='pour'?0.6:0.1); ell(c,0,0,36,26,'#3a7ca5'); rect(c,28,-6,30,8,'#3a7ca5'); rect(c,-8,-34,16,8,'#2a5c85'); rect(c,-48,-12,14,24,'#2a5c85'); c.restore();
  if(s.ph==='pour'&&keys.z){ rect(c,cx-3,98,6,fy-98,'#b8742e'); }
  if(s.fill>=1) { ell(c,cx,bot+2,70,10,'#b8742e'); }
  mgDuck(c,70,210,1.3);
 }
};

/* Florist: make up the customer's bouquet */
const FL_COL=[{n:'rose',k:'up',c:'#e0452f'},{n:'daisy',k:'right',c:'#f2d45a'},{n:'violet',k:'down',c:'#8a5ac8'},{n:'lily',k:'left',c:'#f4efe8'}];
MG.bouquet={
 hint:'Pick the flowers in the order the customer wants.', keys:'Up rose, Right daisy, Down violet, Left lily',
 how:['A customer shows you the bouquet they want.','Add the flowers in order with the arrows:','Up rose, Right daisy, Down violet, Left lily.'],
 hud:s=>'Order '+Math.min(5,s.round+1)+'/5  |  '+Math.max(0,Math.ceil(s.tl))+'s',
 init(s){ s.round=0; s.pts=0; this.next(s); },
 next(s){ s.want=[]; const n=3+(s.round>=3?1:0); for(let i=0;i<n;i++) s.want.push(Math.floor(Math.random()*4)); s.got=[]; s.ph='go'; s.tl=7; s.msg='Make this bouquet!'; s.w=0; },
 update(s,dt){
  if(s.ph==='go'){ s.tl-=dt; if(s.tl<=0){ s.msg='Too slow!'; s.ph='res'; s.w=1; mgTone(0); } }
  else if(s.ph==='res'){ s.w-=dt; if(s.w<=0){ s.round++; if(s.round>=5){ s.done=1; s.score=s.pts; } else this.next(s); } }
 },
 press(s,k){
  if(s.ph!=='go') return;
  const i=FL_COL.findIndex(f=>f.k===k); if(i<0) return;
  if(s.want[s.got.length]===i){ s.got.push(i); tone('triangle',420+i*80,420+i*80,0.1,0.06); if(s.got.length>=s.want.length){ s.pts+=2; s.msg='Beautiful! Pays well.'; s.ph='res'; s.w=1; coin(); } }
  else { s.msg='Wrong flower! The customer sighs.'; s.ph='res'; s.w=1.1; mgTone(0); }
 },
 draw(s,c,t){
  mgSky(c,'#f6e0ec','#e8c8d8'); rect(c,0,200,MGW,70,'#a8743a'); rect(c,0,200,MGW,5,'#7a5226');
  const bub=(x,y,col,sz)=>{ circ(c,x,y,sz,col); circ(c,x,y,sz*0.35,'#f2c230'); };
  rect(c,150,28,180,52,'rgba(255,255,255,0.8)'); mgT(c,'I would like:',240,40,11,'#6a4a5a');
  s.want.forEach((w,i)=>{ const x=240-(s.want.length-1)*18+i*36; bub(x,62,FL_COL[w].c,i<s.got.length?7:12); if(i<s.got.length) mgT(c,'ok',x,62,10,'#2a6a2a'); });
  FL_COL.forEach((f,i)=>{ const pos=[[240,115],[370,160],[240,205],[110,160]][i]; rect(c,pos[0]-28,pos[1]-6,56,26,'#8a6238'); for(let k=0;k<3;k++){ rect(c,pos[0]-14+k*14,pos[1]-22,2,16,'#4f9a4a'); bub(pos[0]-14+k*14,pos[1]-26,f.c,8); } mgT(c,f.n,pos[0],pos[1]+30,11,'#4a2a3a'); });
  s.got.forEach((w,i)=>{ bub(240-(s.got.length-1)*10+i*20,160-Math.abs(i-(s.got.length-1)/2)*4,FL_COL[w].c,12); }); if(s.got.length) rect(c,236,168,8,20,'#4f9a4a');
  mgBar(c,150,255,180,8,s.tl/7,s.tl<2?'#e0452f':'#ff8ab0');
 }
};

/* Bookshop: shelve by number, fast */
MG.shelve={
 hint:'Send each book to the right shelf by its number. Quick!', keys:'Left low, Up middle, Right high',
 how:['A book arrives with a number on its spine.','Left shelf: 1 to 33.  Up shelf: 34 to 66.','Right shelf: 67 to 99. Beat the clock!'],
 hud:s=>'Book '+Math.min(10,s.n+1)+'/10  |  Shelved '+s.right,
 init(s){ s.n=0; s.right=0; this.next(s); },
 next(s){ s.num=1+Math.floor(Math.random()*99); s.col=['#7a2a2a','#2f6f4f','#3a62a8','#c9a24a','#6a3a7a','#2f7f8a'][Math.floor(Math.random()*6)]; s.tl=2.6-s.n*0.1; s.ph='go'; s.msg=''; s.maxt=s.tl; },
 update(s,dt){
  if(s.ph==='go'){ s.tl-=dt; if(s.tl<=0){ s.msg='Too slow!'; s.ph='res'; s.w=0.5; s.n++; mgTone(0); } }
  else { s.w-=dt; if(s.w<=0){ if(s.n>=10){ s.done=1; s.score=s.right; } else this.next(s); } }
 },
 press(s,k){
  if(s.ph!=='go') return;
  const sec=s.num<=33?'left':s.num<=66?'up':s.num>=67?'right':'';
  if(k!=='left'&&k!=='up'&&k!=='right') return;
  const ok=k===sec; s.ph='res'; s.w=0.4; s.n++; s.dest=k; if(ok){ s.right++; s.msg=''; } else s.msg='Wrong shelf!'; mgTone(ok);
 },
 draw(s,c,t){
  mgSky(c,'#e8dcc0','#d8c8a0'); rect(c,0,210,MGW,60,'#8a6238');
  const sh=[['left',20,'1-33'],['up',180,'34-66'],['right',340,'67-99']];
  for(const [k,x,l] of sh){ const hit=s.ph==='res'&&s.dest===k; rect(c,x,50,120,110,hit?'#6a5438':'#5b4430'); rect(c,x+6,56,108,98,'#3b2b1e'); for(let r=0;r<3;r++){ rect(c,x+6,56+r*33+30,108,3,'#8a6a45'); for(let b=0;b<7;b++) rect(c,x+10+b*14,60+r*33,10,28,['#7a2a2a','#2f6f4f','#3a62a8','#c9a24a','#6a3a7a'][(b+r)%5]); } mgT(c,l,x+60,172,14,'#3a2a1a'); mgT(c,k==='up'?'(Up)':k==='left'?'(Left)':'(Right)',x+60,188,10,'#7a6a4a'); }
  {   /* the stamp is always drawn */
   const u=s.ph==='res'&&s.dest?Math.min(1,(0.4-s.w)/0.4):0;
   const tx=s.dest==='left'?80:s.dest==='right'?400:240, ty=s.dest==='up'?110:110, x=240+(s.dest?(tx-240)*u:0), y=232+(s.dest?(ty-232)*u:0);
   rect(c,x-26,y-8,52,16,s.col); rect(c,x-26,y-8,52,3,'rgba(255,255,255,0.25)'); mgT(c,String(s.num),x,y,14,'#fff');
  }
  mgBar(c,170,250,140,8,s.ph==='go'?s.tl/s.maxt:0,s.tl<0.8?'#e0452f':'#c9a24a');
 }
};

/* Tailor: stitch along the dotted line */
MG.stitch={
 hint:'Steer the needle along the dotted line.', keys:'Up / Down steer',
 how:['The needle moves right on its own.','Hold Up or Down to follow the dotted line.','Stay close to the line for a neat hem.'],
 hud:s=>Math.max(0,Math.ceil(s.dur-s.t))+'s  |  '+Math.round(s.on/Math.max(0.01,s.t)*100)+'% neat',
 init(s){ s.t=0; s.dur=12; s.y=135; s.on=0; s.p1=Math.random()*6; s.p2=Math.random()*6; s.trail=[]; },
 curve(s,x){ return 135+52*Math.sin(x*0.017+s.p1)+24*Math.sin(x*0.041+s.p2); },
 update(s,dt){
  s.t+=dt; const x=40+(s.t/s.dur)*400;
  if(keys.up) s.y-=140*dt; if(keys.down) s.y+=140*dt; s.y=mgClamp(s.y,35,235);
  const ok=Math.abs(s.y-this.curve(s,x))<14; if(ok) s.on+=dt; s.trail.push([x,s.y,ok]);
  if(s.t>=s.dur){ s.done=1; s.score=Math.min(10,10*s.on/s.dur*1.06); }
 },
 press(s,k){},
 draw(s,c,t){
  mgSky(c,'#d8e0f0','#c4d0e8'); c.fillStyle='rgba(255,255,255,0.18)'; for(let i=0;i<MGH;i+=14) c.fillRect(0,i,MGW,1);
  rect(c,0,0,MGW,18,'#4a5a8a'); rect(c,0,MGH-18,MGW,18,'#4a5a8a');
  c.fillStyle='#8a6a2a'; for(let x=30;x<450;x+=12){ c.fillRect(x,this.curve(s,x)-1,6,3); }
  c.lineWidth=3; for(let i=1;i<s.trail.length;i++){ const a=s.trail[i-1], b=s.trail[i]; c.strokeStyle=b[2]?'#e0452f':'#9a6a6a'; c.beginPath(); c.moveTo(a[0],a[1]); c.lineTo(b[0],b[1]); c.stroke(); }
  const x=40+(s.t/s.dur)*400; rect(c,x-2,s.y-26,4,34,'#cfd4dc'); circ(c,x,s.y-26,4,'#fff'); circ(c,x,s.y-26,1.8,'#4a5a8a'); rect(c,x-1,s.y+6,2,6,'#e0452f');
 }
};

/* Toy shop: hit the beat to wind and release each toy */
MG.toys={
 hint:'Press Z on the beat as the notes reach the key.', keys:'Z on the beat',
 how:['Wind-up toys hop in time with a tune.','Press Z when each note reaches the ring.','Ten notes. Keep the rhythm!'],
 hud:s=>'Notes '+s.judged+'/10',
 init(s){ s.t=-0.4; s.notes=[]; let tt=1.6; const gaps=[0.7,0.7,0.35,0.35,0.7,0.7,0.35,0.35,0.7]; for(let i=0;i<10;i++){ s.notes.push({t:tt,r:null}); tt+=gaps[i%gaps.length]; } s.judged=0; s.sum=0; s.hop=0; s.last=''; },
 update(s,dt){
  s.t+=dt; s.hop=Math.max(0,s.hop-dt*4);
  for(const n of s.notes) if(n.r===null&&s.t>n.t+0.25){ n.r=0; n.res='miss'; s.judged++; mgTone(0); s.last='Miss'; }
  if(s.judged>=10){ s.fin=(s.fin||0)+dt; if(s.fin>0.8){ s.done=1; s.score=s.sum; } }
 },
 press(s,k){
  if(k!=='z') return;
  let best=null; for(const n of s.notes) if(n.r===null&&Math.abs(n.t-s.t)<0.28&&(!best||Math.abs(n.t-s.t)<Math.abs(best.t-s.t))) best=n;
  if(!best) return;
  const d=Math.abs(best.t-s.t), r=d<0.09?1:d<0.17?0.7:0.35; best.r=r; best.res=r===1?'Perfect':r>0.5?'Good':'Late'; s.sum+=r; s.judged++; s.hop=1; s.last=best.res; mgTone(r>0.5);
 },
 draw(s,c,t){
  mgSky(c,'#f6dcc0','#e8c4a0'); rect(c,0,200,MGW,70,'#b98a55'); rect(c,0,200,MGW,5,'#8a6238');
  rect(c,0,100,MGW,40,'#6a4a2f'); rect(c,0,100,MGW,3,'#8a6a45'); rect(c,0,137,MGW,3,'#4a2f1a');
  const tx=100, spd=(MGW-100)/1.4;
  circ(c,tx,120,24,'rgba(255,230,140,0.25)'); c.strokeStyle='#ffd166'; c.lineWidth=3; c.beginPath(); c.arc(tx,120,18,0,6.3); c.stroke();
  for(const n of s.notes){ const x=tx+(n.t-s.t)*spd; if(x>MGW+20||x<20) continue; if(n.r!==null&&n.res!=='miss'&&x<tx-4) continue; const col=n.res==='miss'?'#7a4a4a':n.r===null?'#e0452f':'#7fd37a'; circ(c,x,120,12,col); mgT(c,'♪',x,120,14,'#fff'); }
  const hy=-Math.abs(Math.sin(s.hop*Math.PI))*30;
  ell(c,240,208,22,6,'rgba(0,0,0,0.25)'); rect(c,226,176+hy,28,26,'#3a7ca5'); rect(c,222,170+hy,36,10,'#c0392b'); circ(c,240,164+hy,12,'#7ac24a'); circ(c,235,162+hy,3,'#fff'); circ(c,246,162+hy,3,'#fff'); rect(c,234,172+hy,12,2,'#222');
  rect(c,254,184+hy,10,3,'#8a6a2a'); c.save(); c.translate(270,188+hy); c.rotate(t*3*(s.hop>0?3:0.3)); rect(c,-8,-2,16,4,'#c9a24a'); rect(c,-2,-8,4,16,'#c9a24a'); c.restore();
  if(s.last) mgT(c,s.last,tx,80,14,s.last==='Miss'?'#e0a090':'#fff4c2');
 }
};

/* shop-job blurbs now describe the real game */
JOBS.bakery=['Knead the Dough','Fold the dough: alternate Left and Right as fast as you can.'];
JOBS.market=['Sort the Produce','Ripe fruit up, rotten fruit down.'];
JOBS.supply=['Polish the Lenses','Rub every smudge off the lens.'];
JOBS.curio=['Dust the Curios','Spot which curio was swapped while you dusted.'];
JOBS.cafe=['Pour the Tea','Hold Z to pour, let go at the gold line.'];
JOBS.florist=['Arrange the Bouquets','Make up each customer\'s bouquet in order.'];
JOBS.books=['Shelve the Books','Send each book to the right shelf by its number.'];
JOBS.tailor=['Stitch the Hems','Follow the dotted line with the needle.'];
JOBS.toys=['Wind the Toys','Press Z on the beat.'];
