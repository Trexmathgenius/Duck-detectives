'use strict';
/* ===== CHAPTER 3: A DOOR THAT OPENS ONE WAY =====
   Emberwick lets you in for Mallow's sake and for no other reason. Whispers follow your yellow feathers. For three days nothing
   happens, then at noon on three days the Elders send for the hermit, only for him, and keep him five hours.
   After the third, the red castle opens for you: a long red carpet, guards on both sides, and a room at the end. */

const H3='Hermit Mallow', P3='Detective Duck';
function absT(){ return g.day*24+g.clock; }
function meetTime(m){ const st=g.story; return (Math.floor(st.redT0/24)+2+m)*24+12; }  /* day +3, +4, +5 at noon */
function mtgDays(){ const st=g.story; return Math.max(0,Math.floor(absT()/24)-Math.floor(st.redT0/24)); }

/* ---------- small helpers ---------- */
function tilePath(sx,sy,tx,ty){
  const key=(x,y)=>x+','+y, walk=(x,y)=>{ const t=tileAt(x,y); return !SOLID.has(t)&&t!==T.WATER; };
  const prev=new Map(); prev.set(key(sx,sy),null);
  const q=[[sx,sy]]; let qi=0, found=false;
  while(qi<q.length&&qi<9000){
    const [x,y]=q[qi++]; if(x===tx&&y===ty){ found=true; break; }
    for(const d of [[1,0],[-1,0],[0,1],[0,-1]]){
      const nx=x+d[0], ny=y+d[1], k=key(nx,ny);
      if(prev.has(k)||!walk(nx,ny)) continue;
      prev.set(k,[x,y]); q.push([nx,ny]);
    }
  }
  if(!found) return null;
  const path=[]; let c=[tx,ty];
  while(c){ path.push(c); c=prev.get(key(c[0],c[1])); }
  return path.reverse();
}
let hermitPath=null, hermitPi=0;

/* ---------- guards of Cinderhold ---------- */
let gateGuards=null;
function castleGuards(){
  if(gateGuards) return gateGuards;
  const mk=(name,x,y,dir)=>{ const p=snapFree(RX0+x,RY0+y,3); const n=K(name,p[0]-KX,p[1]-KY,RED_PALS[2],'helm',null,[['Move along.']],{special:'rguard',still:true,dir:dir||'down',deco:spearDeco,owl:true}); return n; };
  gateGuards=[mk('Cinderhold Guard',33,14,'down'),mk('Cinderhold Guard',38,14,'down')];
  return gateGuards;
}
const GUARD_LINES={
  closed:[
    ['Cinderhold is closed to you. The hermit may pass. You may not.','Do not make that face. It is not personal. It is procedure.'],
    ['Elders only. You are not an Elder. You are not even a red.','(He says the last part softly. It does not help.)'],
    ['The Hall is in session. Move along, Yellow. Please.','(He says "please" like it costs him a coin.)']
  ],
  summoned:[['The hermit is with the Elders. He is not to be disturbed. Nor are you to disturb the door.','He will be out when he is out.'],['The Elders keep long hours. So do I. I have not been asked how I feel about it.']],
  open:[['The Elders will see you. Walk on the carpet. Do not step off it. If you step off it, it will be unpleasant for both of us.'],['Eyes front. Feet on the red. Enter when you are ready. Nobody is ever ready.']],
  done:[['The Elders have spoken. Nothing more to say. Go carefully.']]
};
function guardTalk(n){
  const st=g.story; n.dir='down'; n.talking=true;
  const done=()=>{ n.talking=false; n.t=1; };
  const k=st.ch3Met?'done':st.castleOpen?'open':(st.hermitAway?'summoned':'closed');
  const L=GUARD_LINES[k]; n.cycle=(n.cycle||0)+1;
  say(n.name,L[n.cycle%L.length],done);
}
function redCastleGate(){
  const st=g.story;
  if(castleOpenNow()){ enterCastle(); return; }
  if(st.ch3Met){ say('',['The great doors are shut again. A single red ribbon is tied across them, the way they are tied for a house that has had its say.']); return; }
  const near=castleGuards()[(g.px/TS<RX0+36)?0:1];
  quack();
  say('',['Two spears cross in front of the great doors before you reach them.'],()=>guardTalk(near));
}

/* ---------- the arrival ---------- */
function redArrival(){
  const st=g.story;
  seq([
    ['',['The last tree bends aside, almost politely. Ahead: a wall of red-bound logs, and a gate with lanterns, and a hundred red faces turned toward you.','Hermit Mallow stops beside you. His lantern stops swinging.']],
    ['Warden Ruddock',['You again. I told you. Elder Cinder told you.','Nobody...']],
    [H3,['Ruddock. Hello.','You used to bite my ears when we were small. I have always held it against you.']],
    ['Warden Ruddock',['...','That is not possible.']],
    [H3,['Mallow, son of Bree. Seven years old, lost on the road. I stayed, Ruddock. I set the stones straight every spring. I am so sorry it took me this long to walk the rest of the way.']],
    ['',['The gate guard is crying. He is trying very hard not to. Behind him, a murmur runs through the crowd like wind through reeds: "Mallow. Mallow. Mallow."','Then Elder Cinder walks out of the crowd, leaning on her stick, and nobody says a word.']],
    ['Elder Cinder',['Bree\'s boy.','We searched for you for a year. We stopped because there was no more road to search. We cut your name into the Wall under "LOST".','And here you are. Grey as I am, and walking beside one of them.']],
    [H3,['He is not one of them, Cinder. He is one of us, in every way that matters. He walked into your Wood twice, to bring me here.','I trust him completely. I would have walked into any fire for him. That is all I ask you to consider.']],
    ['Elder Cinder',['I will consider it. I have considered it. Here is my consideration.','You may come in, Detective Duck. Not because we trust you. Not because we want you here. Because we trust him, and he trusts you, and a hundred years have taught us what it costs to turn a trusted friend away.','Do not mistake this for a welcome.']],
    ['Warden Ruddock',['Stay in the square. Touch nothing. Speak to no one who does not speak first.','And keep that yellow tail out of the Hall.']],
    ['Little Poppy',['(somewhere far below the adults\' wings, a very small voice)','Mama. Mama. He is SO yellow.']]
  ],()=>{
    st.redOpen=1; st.redT0=absT(); tileCache.clear();
    const p=snapFree(RX0+35,RY0+RH-7,4);
    g.px=(p[0]+0.5)*TS; g.py=(p[1]+0.95)*TS; g.dir='up'; g.camX=g.px; g.camY=g.py-10;
    const h=hermitObj(); if(h){ h.x=g.px-26; h.y=g.py; h.moving=false; }
    fade(1.4);
    toast('Emberwick lets you in. Not warmly. (Reputation cannot be earned here.)',5200);
    setTimeout(()=>{ if(g.mode==='play') say('',['The red ducks part around you, wide and careful, the way water parts round a stone.','You can buy things here. You can work here. You can help here. They will take your crumbs, and your help, and they will not remember either.','Stay close to Mallow. Keep your ears open. Somewhere in this town there is something they are not telling you.']); },900);
  });
}
{
  const _villageArrive=villageArrive;
  villageArrive=function(){
    const st=g.story;
    if(st.ch2Done&&st.hermitFollow&&!st.redOpen){ if(wood.arrived) return; wood.arrived=true; redArrival(); return; }
    if(st.redOpen) return;
    _villageArrive();
  };
  const _woodUpdate=woodUpdate;
  woodUpdate=function(dt){ if(g.story.redOpen) return; _woodUpdate(dt); };
}

/* ---------- the hermit and the noon summons ---------- */
const SUMMONS=[
  {page:['Hermit Mallow? The Elders ask for you. In the Hall, at noon, as agreed.','Only you.'],
   h:['I am sorry, little detective. They have not told me why. Wait here. I will tell you everything I am allowed to.'],
   p:['They did not invite me.'],h2:['No. I noticed. I am noticing a great deal today.']},
  {page:['Hermit Mallow. The Elders ask for you again. Noon. The Hall.','Only you, they said. Again.'],
   h:['The second day. The same table, I expect. The same questions, put three ways.'],
   p:['Do they say what they are asking?'],h2:['They ask what I carry. They ask what I saw. They ask about you. They always ask about you.']},
  {page:['Hermit Mallow. The third day. The Elders ask for you.','They said to say: "this is the last".'],
   h:['The last. I hope it is the last. I am old, and I am cold, and I am beginning to understand why the Wood is afraid.'],
   p:['Come back and tell me.'],h2:['I will come out with news. Good or bad. I promise it will be news.']}
];
function startSummons(m){
  const st=g.story, S=SUMMONS[m-1], h=hermitObj();
  if(!h) return;
  st.hermitBusy=1;
  const jay=snapFree(Math.floor(g.px/TS)+2,Math.floor(g.py/TS)+1,3);
  seq([
    ['',['A red duck in a courier\'s cap runs up from the direction of the Hall, out of breath. Several heads in the square turn, and turn away.']],
    ['Courier Jay',S.page],
    [H3,S.h],[P3,S.p],[H3,S.h2]
  ],()=>{
    st.mtgNow=m;
    const sx=Math.floor(h.x/TS), sy=Math.floor((h.y-2)/TS);
    hermitPath=tilePath(sx,sy,RX0+35,RY0+14); hermitPi=0;
    if(!hermitPath){ st.hermitAway=1; st.hermitBusy=0; } else st.hermitWalking=1;
    st.hermitUntil=absT()+5;
    void jay;
  });
}
function hermitWalkStep(dt){
  const st=g.story, h=hermitObj(); if(!h) return;
  if(!hermitPath){ st.hermitWalking=0; st.hermitAway=1; return; }
  if(hermitPi>=hermitPath.length){
    st.hermitWalking=0; st.hermitAway=1; hermitPath=null;
    if(Math.hypot(h.x-g.px,h.y-g.py)<TS*14) toast('The guards lift their spears for Mallow. They lower them again behind him.',3600);
    return;
  }
  const tg=hermitPath[hermitPi], tx=(tg[0]+0.5)*TS, ty=(tg[1]+0.95)*TS, dx=tx-h.x, dy=ty-h.y, d=Math.hypot(dx,dy);
  h.talking=false; h.still=true;
  if(d<4){ hermitPi++; return; }
  const sp=84*dt; h.x+=dx/d*Math.min(sp,d); h.y+=dy/d*Math.min(sp,d);
  h.moving=true; h.phase+=dt*10;
  h.dir=Math.abs(dx)>Math.abs(dy)?(dx>0?'right':'left'):(dy>0?'down':'up');
}
function hermitReturns(){
  const st=g.story, h=hermitObj(), m=st.mtgNow;
  const p=snapFree(RX0+35,RY0+16,3);
  h.x=(p[0]+0.5)*TS; h.y=(p[1]+0.95)*TS; h.dir='down'; h.moving=false; h.still=true; h.talking=false;
  st.hermitAway=0; st.hermitHold=m; st.hermitBusy=0;
  toast('The castle doors open. Hermit Mallow comes out, blinking in the daylight.',4200);
}
const REPORTS=[
  [['They kept me in a room with a fire and no window. They asked me about the Crown. About the Edict. About my mother. About you.','Who you are. Where you came from. Why a yellow-feather would walk into the Wood. I told them what I know: that you are kind, and stubborn, and fainted at a castle gate once and followed a trail of cold fires to find an old duck in a flower garden.','They did not say why they asked. They said: come again tomorrow at noon.']],
  [['Again. Another table, another five hours. They fed me soup. I think soup is how they apologise.','I heard a word through a door as I left. "Quackenhold". Said very quietly, like a word you do not want a child to hear.','They asked whether you can be trusted. I said yes. Four times. I am beginning to feel like the Wood, answering the same question every day in a different tree.']],
  [['It is done. The third. They have decided something.','They want to meet you. In the Hall of Cinderhold, tonight, whenever you are ready. The gate will be open for you.','Walk the carpet. Do not step off it. Whatever they say, remember: I vouched for you. I would do it again. I would do it a thousand times.']]
];
function hermitReport(n){
  const st=g.story, m=st.hermitHold;
  n.dir=OPP[g.dir]; n.talking=true; n.moving=false;
  say(H3,REPORTS[m-1][0],()=>{
    st.mtgDone=m; st.hermitHold=0; n.talking=false; n.t=1;
    if(m===3){ st.castleOpen=1; toast('The gate of Cinderhold stands open. The Elders will see you.',5200); }
  });
}
const HERMIT_RED=[
  ['They are my people, little detective. Funny. A hundred years, and I am home, and I am a stranger.','You can be home and a stranger in the same afternoon. I had not known.'],
  ['Do not mind the whispers. Whispers are how Emberwick breathes. It is not a town for shouting.'],
  ['Ruddock was my age-mate. He pretended not to know me for most of the afternoon. That is how I knew he did.'],
  ['The Hearth has not gone out in a hundred years. I sat by it for an hour. I think it is the first time I have been warm since I was seven.']
];
const HERMIT_BETWEEN=[
  ['The Elders ask me the same questions three ways. I give the same answer three ways.'],
  ['Be patient with them. Patience is the only thing they have in plenty.']
];
const HERMIT_AFTER=['You did well in there. They are frightened. So am I.','Shall we go and see a king, little detective?'];
{
  const _specialTalk=specialTalk;
  specialTalk=function(n){
    const st=g.story;
    if(n.special==='rguard'){ guardTalk(n); return; }
    if(n.name===H3&&st.redOpen){
      if(st.hermitHold){ hermitReport(n); return; }
      n.dir=OPP[g.dir]; n.moving=false; n.talking=true;
      const done=()=>{ n.talking=false; n.t=1; };
      if(st.ch3Met) say(H3,[pick(HERMIT_AFTER)],done);
      else if(inRed(Math.floor(g.px/TS),Math.floor(g.py/TS))){
        const pool=st.mtgDone?HERMIT_BETWEEN.concat(HERMIT_RED):HERMIT_RED;
        say(H3,pick(pool),done);
      } else say(H3,['Lead on, little detective.'],done);
      return;
    }
    _specialTalk(n);
  };
  const _specialMark=specialMark;
  specialMark=function(n){
    if(n.special==='rguard') return null;
    if(n.name===H3&&g.story.redOpen){ if(g.story.hermitHold&&!n.talking) return {ch:'!',col:'#ffd166'}; return null; }
    return _specialMark(n);
  };
  const _extraNpcs=extraNpcs;
  extraNpcs=function(list){
    _extraNpcs(list);
    const st=g.story;
    if(g.scene!=='world') return;
    if(st.redOpen){
      const vn=villageNpcs(); for(let i=list.length-1;i>=0;i--) if(vn.indexOf(list[i])>=0) list.splice(i,1);
      if(inRed(Math.floor(g.px/TS),Math.floor(g.py/TS))||Math.abs(g.px/TS-RX0-36)<50&&Math.abs(g.py/TS-RY0-28)<40) for(const gd of castleGuards()) list.push(gd);
    }
    if(st.hermitAway){ const h=hermitObj(); const i=list.indexOf(h); if(i>=0) list.splice(i,1); }
  };
  const _followUpdate=followUpdate;
  followUpdate=function(dt){
    const st=g.story;
    if(st.redOpen){
      if(st.hermitWalking){ hermitWalkStep(dt); return; }
      if(st.hermitAway||st.hermitHold){ const h=hermitObj(); if(h&&st.hermitHold){ h.still=true; h.moving=false; } return; }
    }
    _followUpdate(dt);
  };
}

/* ---------- the per-frame driver ---------- */
let whisperT=20, ch3Frame=0;
function ch3Update(dt){
  const st=g.story;
  if(!st.redOpen||g.scene!=='world'||g.mode==='title'||g.mode==='cut') return;
  const tx=Math.floor(g.px/TS), ty=Math.floor((g.py-2)/TS), inTown=inRed(tx,ty);
  if(st.hermitAway&&absT()>=st.hermitUntil) hermitReturns();
  if(g.mode!=='play') return;
  if(st.hermitFollow&&!st.hermitBusy&&!st.hermitAway&&!st.hermitHold&&!st.hermitWalking&&!st.ch3Met){
    const m=(st.mtgDone||0)+1;
    if(m<=3&&inTown&&absT()>=meetTime(m)) startSummons(m);
  }
  if(inTown){
    ch3Frame++;
    whisperT-=dt;
    if(whisperT<=0){
      whisperT=24+Math.random()*30;
      let near=false;
      for(const n of g.npcs) if(n.red&&!n.talking&&Math.hypot(n.x-g.px,n.y-g.py)<TS*8){ near=true; break; }
      if(near&&g.moving&&!st.isRed) toast(pick(RED_WHISPERS),3200);
      else if(near&&g.moving) toast(pick(MAGIC_TOASTS),3200);
    }
    if(ch3Frame%6===0) for(const n of g.npcs){
      if(!n.red||n.moving||n.talking) continue;
      const dx=g.px-n.x, dy=g.py-n.y;
      if(Math.hypot(dx,dy)<TS*5) n.dir=Math.abs(dx)>Math.abs(dy)?(dx>0?'left':'right'):(dy>0?'up':'down');
    }
  }
}
{
  const _storyUpdate=storyUpdate;
  storyUpdate=function(dt){ _storyUpdate(dt); ch3Update(dt); };
}

/* ---------- Cinderhold: the carpet and the meeting room ---------- */
const CAW=13, CAH=44;
const CASTLE=(()=>{
  const rows=[];
  for(let ty=0;ty<CAH;ty++){
    let r;
    if(ty===0) r='WWWWWWWWWWWWW';
    else if(ty<=9){
      const a=('W'+'.'.repeat(11)+'W').split('');
      if(ty===3){ for(let x=3;x<=9;x++) a[x]='T'; }
      if(ty>=4){ for(let x=5;x<=7;x++) a[x]='c'; }
      if(ty===5||ty===8){ a[2]='P'; a[10]='P'; }
      r=a.join('');
    } else if(ty===43) r='WWWWWDDDWWWWW';
    else {
      const a='WWWWWcccWWWWW'.split('');
      if(ty>=11&&ty<=39){
        if(ty%3===0){ a[4]='G'; a[8]='G'; }
        else if(ty%6===2) a[4]='R';
        else if(ty%6===5) a[8]='R';
      }
      r=a.join('');
    }
    rows.push(r);
  }
  return rows;
})();
LIBINT.castle='GR'; LIBEXIT.castle=[RX0+35-KX,RY0+13-KY];
let castleMtgOn=false;
function enterCastle(){
  const st=g.story;
  castleMtgOn=false;
  enterInterior('castle');
  g.px=6.5*TS; g.py=42.3*TS; g.dir='up'; g.camX=g.px; g.camY=g.py;
  const first=!st.castleIn; st.castleIn=1;
  if(first) say('Captain of the Guard',['Stop at the door. Look straight ahead.','You will walk to the end of the carpet. You will stay on the carpet. Guards on both sides will remind you if you forget.','Nothing in this hall is for you to see except the room at the end. Walk.']);
  else toast('The carpet runs on and on. The guards do not blink.',3000);
}
const CASTLE_ROOMS=[
  'A door of black wood, a brass plate: KITCHENS. Through the keyhole you smell onions, smoke and an enormous, enormous soup. A guard coughs politely. You look away.',
  'RECORDS. The door is locked. Under it is a pale strip of light. Someone inside is turning pages very slowly, as if each one weighed a stone.',
  'The ARMOURY. The grindstone inside sings a low note. A guard shifts to block the keyhole, as if the sound itself were secret.',
  'INFIRMARY. Someone inside is coughing and being told off for it. The guard clears his throat: eyes front.',
  'A small door, painted with a flame in a circle. Faintly, from behind it: a lullaby. A guard steps in front of the door, gently. "Eyes front."',
  'ELDERS ONLY. A second, smaller plate under it: STILL ELDERS ONLY. The guard does not look at you. Somehow he looks at you.'
];
const CASTLE_GUARD=['Feet on the carpet.','Eyes front. Walk on.','The Elders are waiting. Do not keep them.','Off the carpet is not an option. On the carpet is a good option.','(He does not blink. You do not check.)'];
{
  const _libCh=libCh;
  libCh=function(tx,ty){
    if(g.libKind==='castle'){ if(tx<0||ty<0||tx>=CAW||ty>=CAH) return 'W'; return CASTLE[ty][tx]; }
    return _libCh(tx,ty);
  };
  const _libSolid=libSolid;
  libSolid=function(tx,ty){
    if(g.libKind==='castle'){ const c=libCh(tx,ty); return c!=='.'&&c!=='c'&&c!=='D'; }
    return _libSolid(tx,ty);
  };
  const _libUpdate=libUpdate;
  libUpdate=function(){
    if(g.scene==='lib'&&g.libKind==='castle'){
      if(g.mode!=='play') return;
      if(g.py-2>=43*TS){ exitLibrary(); return; }
      if(g.py<8.6*TS&&!castleMtgOn){ castleMtgOn=true; startElderMeeting(); }
      return;
    }
    _libUpdate();
  };
  const _libInteract=libInteract;
  libInteract=function(tg){
    if(g.libKind==='castle'){
      if(tg.ch==='G'){ say('Castle Guard',[CASTLE_GUARD[(tg.ty+tg.tx)%CASTLE_GUARD.length]]); return; }
      if(tg.ch==='R'){ say('',[CASTLE_ROOMS[(tg.ty*7+tg.tx)%CASTLE_ROOMS.length]]); return; }
      return;
    }
    _libInteract(tg);
  };
  const _areaName=areaName;
  areaName=function(){ if(g.scene==='lib'&&g.libKind==='castle') return 'Cinderhold'; return _areaName(); };
  const _drawInterior=drawInterior;
  drawInterior=function(c,W,H,kd,time){
    if(g.scene==='lib'&&g.libKind==='castle'){ drawCastle(c,W,H,kd,time); return; }
    _drawInterior(c,W,H,kd,time);
  };
}
function drawCastle(c,W,H,kd,time){
  const vw=W/kd, vh=H/kd, RWp=CAW*TS, RHp=CAH*TS;
  const fx=vw>=RWp?(RWp/2-vw/2):Math.max(0,Math.min(RWp-vw,g.px-vw/2)), fy=Math.max(-30,Math.min(RHp-vh+10,g.py-14-vh/2));
  const ox=Math.round(fx*kd)/kd, oy=Math.round(fy*kd)/kd;
  c.setTransform(kd,0,0,kd,-ox*kd,-oy*kd);
  const t0=Math.max(0,Math.floor(oy/TS)-1), t1=Math.min(CAH-1,Math.ceil((oy+vh)/TS)+1);
  const stone=['#5e3030','#5a2c2c'];
  for(let ty=t0;ty<=t1;ty++) for(let tx=0;tx<CAW;tx++){
    const ch=CASTLE[ty][tx], px=tx*TS, py=ty*TS;
    if(ch==='W'){
      rect(c,px,py,TS,TS,stone[(tx+ty)&1]); rect(c,px,py+TS-3,TS,3,'#3a1a1a'); rect(c,px+((ty&1)?0:16),py,1,TS,'rgba(0,0,0,0.18)'); rect(c,px,py+15,TS,1,'rgba(0,0,0,0.16)');
      if(ty>=11&&ty<=39&&(tx===3||tx===9)&&ty%3===1){ rect(c,px+14,py+6,4,10,'#2a1a14'); circ(c,px+16,py+5,5,'rgba(255,170,80,0.18)'); c.fillStyle='#ffb347'; c.beginPath(); c.ellipse(px+16,py+5,2,3.2+Math.sin(time*8+ty)*0.5,0,0,6.3); c.fill(); }
      continue;
    }
    if(ch==='c'||ch==='G'||ch==='R'){
      /* the carpet always runs under the corridor, guards stand on the wall tiles beside it */
      if(ch==='c'){
        rect(c,px,py,TS,TS,'#9a1f2b'); rect(c,px+((tx===5)?0:(tx===7?TS-3:0)),py,(tx===6?0:3),TS,'#d9b84a');
        if(tx===6){ const a=(ty&1); rect(c,px+10,py+10+a*6,12,2,'rgba(217,184,74,0.35)'); rect(c,px+14,py+6+a*6,4,10,'rgba(217,184,74,0.25)'); }
        else rect(c,px+(tx===5?3:0),py+8,TS-3,1,'rgba(0,0,0,0.12)');
        continue;
      }
      rect(c,px,py,TS,TS,stone[(tx+ty)&1]); rect(c,px,py+TS-3,TS,3,'#3a1a1a');
      if(ch==='R'){ rect(c,px+3,py+2,TS-6,TS-2,'#4a2c18'); rect(c,px+5,py+4,TS-10,TS-6,'#6b4423'); rect(c,px+(tx<6?TS-9:6),py+16,3,3,'#d9b84a'); }
      continue;
    }
    if(ch==='D'){ rect(c,px,py,TS,TS,'#7b4a22'); rect(c,px,py,TS,2,'#4a2c18'); continue; }
    rect(c,px,py,TS,TS,((tx+ty)&1)?'#5a3a30':'#4f322a'); rect(c,px,py+15,TS,1,'rgba(0,0,0,0.14)');
    if(ch==='T'){ rect(c,px,py+4,TS,TS-4,'#4a2c18'); rect(c,px,py+4,TS,5,'#6b4423'); rect(c,px,py+TS-3,TS,3,'#2a1a10'); }
    if(ch==='P'){ rect(c,px+6,py-8,20,TS+8,'#7a4a44'); rect(c,px+4,py+TS-4,24,4,'#4a2a28'); rect(c,px+4,py-10,24,4,'#4a2a28'); }
  }
  /* guards line both sides of the carpet, spears upright */
  for(let ty=Math.max(12,t0);ty<=Math.min(39,t1);ty++) if(ty%3===0){
    for(const tx of [4,8]){
      const px=tx*TS, py=ty*TS;
      rect(c,px+(tx<6?24:6),py-16,2,40,'#8a5a2b'); c.fillStyle='#c3ccd6'; c.beginPath(); c.moveTo(px+(tx<6?22:4),py-16); c.lineTo(px+(tx<6?25:7),py-26); c.lineTo(px+(tx<6?28:10),py-16); c.fill();
      miniDuck(c,px+16,py+TS-6,'#a82a2a','#7a7f88');
    }
  }
  /* the meeting room: elders behind a long table, a grand window, banners */
  if(t0<=4){
    rect(c,TS*4.5,TS*0.1,TS*4,TS*1.2,'#2a1a30'); for(let k=0;k<4;k++) rect(c,TS*4.5+k*TS,TS*0.1,2,TS*1.2,'#5a2f22');
    const g1=c.createLinearGradient(0,0,0,TS*1.2); g1.addColorStop(0,'rgba(255,170,90,0.45)'); g1.addColorStop(1,'rgba(255,170,90,0)'); c.fillStyle=g1; c.fillRect(TS*4.5,TS*0.1,TS*4,TS*7);
    for(const bx of [2,10.5]){ rect(c,bx*TS,TS*0.4,TS*0.8,TS*1.7,'#a02a22'); c.fillStyle='#e0b84a'; c.beginPath(); c.moveTo(bx*TS+13,TS*0.9); c.quadraticCurveTo(bx*TS+24,TS*1.3,bx*TS+13,TS*1.8); c.quadraticCurveTo(bx*TS+4,TS*1.3,bx*TS+13,TS*0.9); c.fill(); }
    const ec=[['#c0392b',3.4,'#7a7f88'],['#a82a2a',4.7,'#4a3a58'],['#d9503f',6.5,'#e0b84a'],['#b5322a',8.3,'#4a3a58'],['#c0392b',9.6,'#7a7f88']];
    for(const [col,x,hood] of ec) miniDuck(c,x*TS+6,2.55*TS,col,hood);
    miniDuck(c,11.4*TS,2.7*TS,'#c0392b','#7d8896');
    rect(c,5.4*TS,3.1*TS,TS*1.2,TS*0.18,'#d9b84a');
  }
  const gl=c.createRadialGradient(6.5*TS,g.py,10,6.5*TS,g.py,5*TS); gl.addColorStop(0,'rgba(255,150,70,0.12)'); gl.addColorStop(1,'rgba(255,150,70,0)'); c.fillStyle=gl; c.fillRect(0,g.py-5*TS,RWp,10*TS);
  drawMe(c,time);
  if(g.target&&g.mode==='play') drawBubble(c,g.target.x,g.target.y,time,'Z');
  c.setTransform(1,0,0,1,0,0);
}

/* ---------- the meeting ---------- */
/* the Elders' own account of the old days, told as a cutscene */
TELLERBG.emberhall=function(c,t,b){
  const g1=c.createLinearGradient(0,0,0,LH); g1.addColorStop(0,'#1c0c10'); g1.addColorStop(1,'#3a1a1c'); c.fillStyle=g1; c.fillRect(0,0,LW,LH);
  for(let i=0;i<7;i++){ rect(c,i*50-8,0,4,LH,'rgba(0,0,0,0.25)'); }
  const fl=0.85+0.15*Math.sin(t*9);
  const gr=c.createRadialGradient(160,150,4,160,150,150*fl); gr.addColorStop(0,'rgba(255,150,70,0.55)'); gr.addColorStop(1,'rgba(255,90,40,0)'); c.fillStyle=gr; c.fillRect(0,0,LW,LH);
  c.fillStyle='#ff7a2a'; c.beginPath(); c.moveTo(142,150); c.quadraticCurveTo(146,118+Math.sin(t*8)*3,160,98); c.quadraticCurveTo(176,120,178,150); c.fill();
  c.fillStyle='#ffd166'; c.beginPath(); c.moveTo(150,150); c.quadraticCurveTo(153,130,160,118+Math.sin(t*11)*2); c.quadraticCurveTo(168,130,170,150); c.fill();
  rect(c,120,150,80,8,'#4a2c28');
  const cols=['#c0392b','#a82a2a','#d9503f','#b5322a','#c0392b'], hoods=['#7a7f88','#4a3a58','#e0b84a','#4a3a58','#7a7f88'];
  for(let i=0;i<5;i++){ const x=40+i*60; drawDuck(c,x,150,i<2?'right':i>2?'left':'down',0,false,{body:cols[i],wing:'#7f1f1f',bill:'#ff9d2e'},{scale:1.6,head:'wizard'}); }
  for(let i=0;i<14;i++){ const tt=(t*0.4+i*0.13)%1, x=(i*47)%LW, y=140-tt*130; c.fillStyle='rgba(255,210,120,'+(0.6*(1-tt)).toFixed(2)+')'; c.fillRect(x,y,1.5,1.5); }
  vignette(c,0.4);
};
function spark(c,x,y,s,col){ c.fillStyle=col||'#ffe9a8'; c.fillRect(x-s,y-0.5,s*2,1); c.fillRect(x-0.5,y-s,1,s*2); }
SCENES.histBefore=function(c,t){
  sky(c,'#7fb8e8','#ffeec8',22);
  circ(c,262,40,22,'rgba(255,230,160,0.35)'); circ(c,262,40,13,'#fff3b0');
  c.fillStyle='#8fb870'; c.beginPath(); c.moveTo(0,118); for(let x=0;x<=LW;x+=12) c.lineTo(x,110+Math.sin(x*0.04)*8); c.lineTo(LW,LH); c.lineTo(0,LH); c.fill();
  c.fillStyle='#79b862'; c.fillRect(0,134,LW,46);
  castle(c,250,126,0.9,'#c4beac','#34507e',t,'#a8892f');
  /* lamps on poles being lit by sparks */
  for(let i=0;i<5;i++){ const x=30+i*52; rect(c,x,92,2,42,'#6b4a2f'); rect(c,x-4,86,10,8,'#5a4a30'); const lit=((t*0.6+i*0.4)%2)<1.2; if(lit){ circ(c,x+1,90,9,'rgba(255,190,90,0.25)'); rect(c,x-2,88,6,4,'#ffd166'); } }
  const cols=['#ffd84a','#87b4d8','#e9b7c8','#c0392b','#8d7352','#c0392b','#f4f4ee'];
  for(let i=0;i<9;i++){ const x=((i*37+t*8)%(LW+40))-20, y=150+(i%3)*8; mini(c,x,y,cols[i%cols.length],'right',1.7,-Math.abs(Math.sin(t*5+i))*1.2,i%3===0?'#4a3a7a':null); if(cols[i%cols.length]==='#c0392b') spark(c,x+4,y-16-Math.sin(t*6+i)*3,2); }
  vignette(c,0.2);
};
SCENES.histMarch=function(c,t){
  sky(c,'#0b0f2a','#2a2450',22);
  for(let i=0;i<50;i++){ const a=0.4+0.6*Math.abs(Math.sin(t*1.5+i)); c.fillStyle='rgba(255,255,230,'+a.toFixed(2)+')'; c.fillRect((i*53)%LW,(i*29)%90,1,1); }
  circ(c,40,34,12,'#f4efd0'); circ(c,35,30,10,'#0b0f2a');
  c.fillStyle='#14201c'; c.beginPath(); c.moveTo(0,110); for(let x=0;x<=LW;x+=14) c.lineTo(x,104+Math.sin(x*0.045)*9); c.lineTo(LW,LH); c.lineTo(0,LH); c.fill();
  c.fillStyle='#1d2f22'; c.fillRect(0,128,LW,52);
  c.strokeStyle='rgba(230,200,150,0.25)'; c.lineWidth=7; c.beginPath(); c.moveTo(-10,166); c.quadraticCurveTo(140,150,330,138); c.stroke();
  coldFire(c,60,164,1.1,t); coldFire(c,150,152,0.9,t+1); coldFire(c,230,144,0.75,t+2);
  const p=(t*18)%LW;
  for(let i=0;i<16;i++){ const x=((p-i*20)%(LW+60)+LW+60)%(LW+60)-30, y=158-(x/LW)*16+(i%2)*4; mini(c,x,y,i%2?'#c0392b':'#d9503f','right',1.5,-Math.abs(Math.sin(t*6+i))*1.2); if(i%4===0){ rect(c,x+4,y-11,2,4,'#8a6a2a'); circ(c,x+5,y-12,3,'rgba(255,190,90,0.35)'); } }
  vignette(c,0.45);
};
SCENES.histWar=function(c,t){
  sky(c,'#4a2430','#e08a5a',22);
  circ(c,250,96,26,'rgba(255,160,90,0.3)'); circ(c,250,96,15,'#ffd9a0');
  c.fillStyle='#3a2230'; c.beginPath(); c.moveTo(0,120); for(let x=0;x<=LW;x+=14) c.lineTo(x,112+Math.sin(x*0.05)*10); c.lineTo(LW,LH); c.lineTo(0,LH); c.fill();
  c.fillStyle='#4a3a28'; c.fillRect(0,140,LW,40);
  castle(c,284,138,0.7,'#6a5a58','#34507e',t,'#a8892f');
  /* smoke over the castle */
  for(let i=0;i<4;i++){ const tt=(t*0.2+i*0.25)%1; ell(c,276+Math.sin(tt*5+i)*8,96-tt*50,6+tt*8,4+tt*5,'rgba(60,50,60,'+(0.35*(1-tt)).toFixed(2)+')'); }
  /* the fork: a road that splits */
  c.strokeStyle='rgba(230,200,150,0.35)'; c.lineWidth=6; c.beginPath(); c.moveTo(-10,166); c.quadraticCurveTo(80,158,130,150); c.stroke();
  c.beginPath(); c.moveTo(130,150); c.quadraticCurveTo(170,120,200,104); c.stroke(); c.beginPath(); c.moveTo(130,150); c.quadraticCurveTo(190,160,330,150); c.stroke();
  const p=Math.min(1,t/6);
  for(let i=0;i<10;i++){ const k=Math.max(0,Math.min(1,p*1.4-i*0.06)); const x=130+k*70, y=150-k*46; if(k>0) { mini(c,x,y,'#8a1f2a','right',1.4,-Math.abs(Math.sin(t*6+i))*1.1); if(i%2===0){ rect(c,x+3,y-12,2,5,'#6b4a2f'); circ(c,x+4,y-13,2.5,'rgba(255,120,50,0.6)'); } } }
  for(let i=0;i<12;i++){ const k=Math.max(0,Math.min(1,p*1.2-i*0.04)); const x=130+k*150, y=150+Math.sin(k*3)*4; if(k>0) mini(c,x,y,i%2?'#c0392b':'#d9503f','right',1.4,-Math.abs(Math.sin(t*6+i))*1.1); }
  mini(c,128,150,'#e0b84a','right',2.0,0,'#4a3a58');
  vignette(c,0.4);
};
SCENES.histHollow=function(c,t){
  sky(c,'#0e2a2a','#4a6a4a',22);
  const sway=Math.sin(t*0.8)*3;
  for(let i=0;i<14;i++){ const x=i*26+((i*13)%9)+sway*(i%2?1:-1)*(i<7?1:0.4), h=60+((i*31)%40); rect(c,x,180-h,5,h,'#2a2a22'); c.fillStyle=i%2?'#1f5a38':'#2a6a40'; c.beginPath(); c.arc(x+2,180-h,14+(i%3)*3,0,6.3); c.fill(); }
  c.fillStyle='#2a4a2a'; c.fillRect(0,140,LW,40);
  const house=(x,y,s,roof)=>{ rect(c,x-12*s,y-14*s,24*s,14*s,'#f0e0c0'); c.fillStyle=roof; c.beginPath(); c.moveTo(x-16*s,y-13*s); c.lineTo(x,y-30*s); c.lineTo(x+16*s,y-13*s); c.fill(); rect(c,x-3*s,y-9*s,6*s,9*s,'#5c3d7a'); rect(c,x+5*s,y-10*s,4*s,4*s,'#ffd166'); };
  house(70,146,1.2,'#b5483a'); house(160,142,1.0,'#9b2d20'); house(250,146,1.3,'#8a2a2a');
  rect(c,150,150,2,10,'#6b4a2f'); circ(c,151,148,12,'rgba(255,150,70,0.18)');
  /* children making sparks: the Art being taught */
  for(let i=0;i<5;i++){ const x=100+i*28, y=166+(i%2)*4; mini(c,x,y,i%2?'#c0392b':'#d9503f','up',1.2,0,'#4a3a7a'); for(let k=0;k<4;k++){ const tt=(t*0.6+k*0.25+i*0.13)%1; spark(c,x+Math.sin(tt*7+k)*8,y-12-tt*26,1.5+tt,'rgba(255,230,160,'+(1-tt).toFixed(2)+')'); } }
  vignette(c,0.35);
};
const HIST=[
  {k:'teller',bg:'emberhall',who:'Elder Cinder',pages:['We tell this once, and only to those we trust. We are telling it to you, though we do not trust you, because you carry the pages. That is the only reason.','Listen, Detective Duck. Listen the way Mallow listens.']},
  {k:'anim',scene:'histBefore',dur:9,cap:'Before the Edict'},
  {k:'teller',bg:'emberhall',who:'Elder Cinder',pages:['Before the Edict, Mallardia was not yellow and not red. It was every colour.','The red ducks carried the Ember: the first spark, the Art. We lit the lamps and mended the roofs and kept the hearths, and we taught it freely to anyone who asked. Teaching was the whole point of it.','The Crown called us wizards. It was not an insult, then.']},
  {k:'anim',scene:'castOut',dur:11,cap:'The Red Edict'},
  {k:'teller',bg:'emberhall',who:'Archivist Sorrel',pages:['King Eider, who was himself a warlock, and a frightened one, saw that the Ember answered to hearts and not to crowns. He could not order it. He could not take it.','So he wrote an Edict "for the safety of the realm". Every duck hatched in red, beyond the northern hills, before the next dawn.','He read it from the balcony. He did not look at us. The margin says why: "It was not the red ducks I feared." We think he feared the day we might say no.']},
  {k:'anim',scene:'histMarch',dur:10,cap:'The March'},
  {k:'teller',bg:'emberhall',who:'Hearthwarden Pyre',pages:['Eleven hundred of us. Eight nights. Eight fires, each put out at dawn so the smoke would not point the way.','We carried the old on our backs and the young in our wings. We carried the Ember in a lantern, and not one night did anyone let it go out.']},
  {k:'anim',scene:'histWar',dur:10,cap:'The fork in the road'},
  {k:'teller',bg:'emberhall',who:'Warden Ruddock',pages:['At the fifth fire the road forked. Gordamom, the miller\'s son, the cleverest of us, spoke of what we were owed. Three hundred followed him north. We did not stop them. We did not agree. We wept.','The siege of Quackenhold was Gordamom\'s, not ours. The Crown has made it ours for a hundred years, and we have never been allowed to say so.','They say the king ended it with a word, and a tree burned. We say something happened in the Burnt Wood that neither side has dared name. The Ember was in Gordamom, too. It answered the king\'s word with a word of its own.']},
  {k:'anim',scene:'histHollow',dur:10,cap:'The Hollow'},
  {k:'teller',bg:'emberhall',who:'Keeper Brand',pages:['We came to a hollow in the north-east, and a wood that moved when we were afraid. We do not know who first asked it to. We asked it, later, to stay.','We built Emberwick behind our own fear, and we raised every child in the Art, because a people driven out once must be able to light their own fire anywhere.','Every duck in this town is a witch or a wizard. It is not a secret. It is our culture. It is why we are still here.']},
  {k:'teller',bg:'emberhall',who:'Elder Cinder',pages:['That is what happened. From us. Nobody has heard it from us in a hundred years.']}
];
function startElderMeeting(){
  const st=g.story, E='Elder Cinder', B='Keeper Brand', R='Warden Ruddock', S='Archivist Sorrel', Y='Hearthwarden Pyre';
  const poppy=(st.kidA&&st.kidA['Little Poppy'])||[];
  const pagesHave=Object.keys(st.pages||{}).filter(k=>st.pages[k]).map(Number).sort();
  let said1=-1, said2=-1;
  const aftermath=()=>{
    fade(0.8);
    seq([
      [E,['We have told you more than we have told any outsider in a hundred years. And still we do not trust you.']],
      [R,['A yellow duck finds the cipher, the pages, our hermit and our Wood in a single season. Either the stars are generous, or someone is steering. I am not fond of either.']],
      [S,[(poppy[0]===undefined)?'He is suspicious. I have written it down. I have also written down that he sat very still when the Warden asked, and did not look away.':(poppy[0]!==said2&&poppy[0]!==3&&said2!==3)?'He is suspicious. I have written it down. I have also written down that the child and the Warden were told two different things, and that when he was asked about it, he did not pretend otherwise.':'He is suspicious. I have written it down. I have also written down that he did not once lie to the child who asked.']],
      [E,['There is only one way we will trust you, Detective Duck. You must become one of us.']],
      [B,['Not in feather. In the Art. Every red duckling is raised to it. You will be taught as they are taught: twelve days at the Academy of the Ember Arts, one for each year a child normally spends there.']],
      [Y,['You will be given tasks. Easy on the first day. Moderately hard on the last. You will learn to use the charms and wands sold in our shops, which are only trinkets until you do.']],
      [E,['When you have learned, you will travel farther north-east, through the Umbral Wood, where the trees do not hum but listen. Use what you have learned to find your way and to open what is closed.','At its heart lives an old red elder, blind, who has not left the dark in sixty years. He keeps the recipe of the Chromatic Potion, which changes a duck\'s colour.']],
      [B,['Be warned of what you would be choosing. In the kingdom, red ducks are tolerated now, since the temple apologised and the king stopped speaking of the Edict. But tolerance is a thin cloak.','Were you to become red, you would be an outcast there. Every kindness you have earned in those towns would be forgotten, and earning new would be very hard. Here, for the first time, your deeds would count.']],
      [H3,['I will not tell you what to do. I will tell you that I would walk beside you either way.']]
    ],()=>{
      choose(E,'What will you do?',['Follow the Elders and learn the Art','Return to the kingdom, and stay loyal','I need time'],k=>{
        const fin=()=>{
          st.ch3Met=1; st.castleOpen=0; tileCache.clear();
          if(st.path==='crown'&&st.hermitFollow) hermitGoHome();   /* he said goodbye; he does not keep following */
          fade(1.4); exitLibrary();
          toast(st.path==='red'?'The Academy of the Ember Arts is open to you. (north-west of the town)':st.path==='crown'?'You leave Cinderhold with the Elders\' silence behind you.':'The Elders let you go. Decide when you are ready.',5200);
        };
        if(k===0){ st.path='red'; seq([[E,['Then go to the Academy, in the north-west of the town. Mistress Vesper has been told to expect you.','Do not mistake this for a welcome. It is a beginning.']],[R,['(Ruddock says nothing. He looks, for once, a little less like a wall.)']]],fin); }
        else if(k===1){ st.path='crown'; seq([[E,['Then go. The door of Emberwick will not be locked behind you. Remember who held it open.']],[R,['(He says "good" very quietly. It is not clear whether he means it.)']],[H3,['I shall be sorry. And I shall understand.']]],fin); }
        else { st.path='undecided'; seq([[E,['Time is the one thing we have always had in plenty. Take it. Both doors stay open: the Academy for those who would be one of us, the king\'s gate for those who would not.']]],fin); }
      },2);
    });
  };
  const history=()=>{
    startCutscene(HIST,aftermath,{hint:'Press X again to skip'});
  };
  const pagesPhase=()=>{
    const show=()=>{
      const list=pagesHave.length?pagesHave:[0,1,2];
      const readers=[S,Y,B];
      const reads=list.map((i,n)=>[readers[n%3],[PAGE_TEXT[i]]]);
      seq(reads.concat([
        [S,['The hand in the margin is Eider\'s. I would know it anywhere. It is the only line in the whole of the Edict that was not dictated.']],
        [E,['They are real. All three. How did you come by them?']],
        [H3,['He found them where I told him: in the ash of the Siege Field, in the ruined tower, on the island. He did not have to. He did.']],
        [E,['So we have been told. Now: sit, Detective Duck. Hear what the pages have never said.']]
      ]),history);
    };
    say(E,['Mallow has vouched for you. He says you are trustworthy, and that you carry the pages of the Red Edict.','Show them to us. Let us read.'],()=>{
      choose(E,'The Elders wait.',['Hand over the pages','Hesitate'],k=>{
        if(k===0) show();
        else say(H3,['Show them. They deserve to read it. So, I think, do you.'],show);
      },0);
    });
  };
  const originPhase=()=>{
    const o1=['A stranger told me a tale in Puddlewick, and I wanted to know if it was true','The kingdom\'s castle is shut, and something is wrong at its heart','I am a detective. I follow mysteries','I do not entirely know. A vision called me'];
    const r1=['A tale. And you came all this way north on the strength of one. Hm. People like that are either very good or very dangerous.','Shut. Yes. We know. We know a good deal more about that than we have said.','A detective. Of course you are. Sorrel, add it to the list.','A vision. Mallow told us. We are not in the habit of believing in visions. We are in the habit of believing in the Wood, and the Wood let you through.'];
    choose(E,'Why have you sought out the red ducks?',o1,k=>{
      said1=k;
      say(E,[r1[k]],()=>{
        choose(R,'And where do you come from? Whose child are you?',RK_Q1.o,k2=>{
          said2=k2;
          const rr=['Mallardia. Of course. The yellow banners fly there.','You woke in a forest and do not remember? Convenient. Or sad. I cannot tell which, and that troubles me.','South of the river. We have never sent anyone south of the river. We have no idea what is there.','You would rather not say. I have buried people for less honest silences.'];
          const lines=[rr[k2]];
          const pp=poppy[0];
          if(pp!==undefined&&pp!==k2&&pp!==3&&k2!==3) lines.push('The child Poppy tells us you told him something else. Children keep what you give them. Explain that.');
          else if(pp!==undefined&&pp===k2&&pp!==3) lines.push('The child Poppy told us the same, a week ago. That, at least, is consistent.');
          say(R,lines,()=>{
            if(pp!==undefined&&pp!==k2&&pp!==3&&k2!==3){
              choose(R,'Explain.',['I was not sure how to say it to a child','I am telling you the truth now','Say nothing'],k3=>{
                say(R,[['Honest, at least.','Convenient.','Silence. I know that one well.'][k3]],pagesPhase);
              },2);
            } else pagesPhase();
          });
        },3);
      });
    },3);
  };
  seq([
    ['',['The carpet ends at a long table of dark red wood. Five elders sit behind it, and at the far end, a sixth chair holds Hermit Mallow, who gives you a small, nervous nod.','Behind them, a tall window pours amber light across the room. Each elder wears a tall, pointed hat. The hats are very old, and very well mended.']],
    [E,['Come no further, Detective Duck. Stand on the last of the carpet.','In this room, everyone stands on something.']],
    [E,['We let you in some days ago for one reason. The reason is sitting at the end of this table. We have spent three days asking him whether we were right.']],
    [R,['I voted no. I vote no still. Write that down, Sorrel.']],[S,['It is written. It is always written.']],
    [E,['Now. We have questions, and you will answer them.']]
  ],originPhase);
}

/* ---------- objective and journal ---------- */
function ch3Objective(){
  const st=g.story;
  if(st.ch3Met) return 'The Elders\' offer stands. See <b>Mistress Vesper</b> at the Academy to become one of them, or take your report to the king.';
  if(st.castleOpen) return 'The Elders will see you. The <b>gate of Cinderhold</b> is open. Walk the red carpet to the end. Do not step off it.';
  if(st.hermitHold) return 'Hermit Mallow has come out of the castle. <b>Talk to him</b>.';
  if(st.hermitAway) return 'Mallow is with the Elders. Do not wait. Learn what you can: talk to the children, read in the Archive, sit through the Banking at six.';
  const m=(st.mtgDone||0)+1, left=meetTime(m)-absT();
  const mt=meetTime(m), dd=Math.floor(mt/24)-g.day;
  const when=(dd<=0?'today':dd===1?'tomorrow':'in '+dd+' days')+' at noon';
  if(m===1&&left>0) return 'Emberwick tolerates you for Mallow\'s sake. Something is being kept from you. Stay in town near the hermit. The Elders are expected to send for him '+when+'.';
  return 'Stay in Emberwick, near the hermit. The Elders send for him '+when+' (meeting '+m+' of 3). You are not invited.';
}
function ch3Journal(sec,line){
  const st=g.story;
  if(!st.redOpen) return;
  sec('Chapter 3: A Door That Opens One Way');
  line('Emberwick let you in because the hermit trusts you completely, not because they do. Your standing here cannot rise. They will buy from you, work with you, and forget it all by morning.');
  line('There are whispers about your yellow feathers. The children are not afraid of you.');
  if(st.mtgDone) line('The Elders have called Mallow into Cinderhold at noon on '+st.mtgDone+' of 3 days, for five hours each time. You are not allowed inside.');
  if(st.hermitAway||st.mtgNow) line('"They asked about you. They always ask about you." (Hermit Mallow)','jdim');
  if(st.castleOpen) line('After the third meeting the hermit told you the Elders want to meet you. The red castle is open.');
  if(st.ch3Met){
    line('The Elders questioned you, read the pages of the Red Edict, and told their own history: the Ember, the Edict, the March, the fork in the road, the Hollow.');
    line('They still do not trust you. The only way they will is if you become one of them: twelve days at the Academy of the Ember Arts, the Umbral Wood, the blind elder, the Chromatic Potion.');
  }
  if(st.redCold&&Object.keys(st.redCold).length) line('Cold-fire stones read: '+Object.keys(st.redCold).length+' of 8.','jdim');
  if(st.bankings) line('Bankings attended: '+st.bankings+'.','jdim');
}
{
  const _storyObjective=storyObjective;
  storyObjective=function(){ if(g.story.redOpen){ const o=ch3Objective(); if(o) return o; } return _storyObjective(); };
  const _journalExtra=journalExtra;
  journalExtra=function(sec,line){ _journalExtra(sec,line); ch3Journal(sec,line); };
}
