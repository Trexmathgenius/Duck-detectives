'use strict';
/* ===== GROWTH: the road changes you, and you can feel it =====
   1. WHO YOU ARE BECOMING (Y, and a journal section): the hidden traits, ledger and standings put into words.
   2. GIFTS OF THE ROAD: finishing certain chapters gives a real ability (waymarks, pay, luck, free travel, deeper reading).
   3. WAYMARKS (T): lit places you have walked to. Once you have the first gift you can travel between two you have visited.
   4. SUPPLY LINKS: brews and crumbs from the sandbox matter to the story (a ward tonic buys time at the Ward; waymark travel costs crumbs).
   5. WHAT CHANGED: a short note after each chapter says what it did to you, and it is kept in the Y page.
   6. MASTERY: long-term story goals that pay out on their own.
   Everything is saved in g.story.grow. Nothing here edits story text; it only wraps existing functions. */
(function(){
const G=()=>{ const s=g.story||(g.story={}); if(!s.grow) s.grow={wp:{},got:{},snap:null,sum:[],mast:{},lore:[]}; return s.grow; };
const safeCall=(f,d)=>{ try{ return f(); }catch(e){ return d; } };
const esc=s=>String(s).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
const doneAny=(ids,extra)=>{ const q=s2(); return ids.some(i=>(q.done&&q.done[i])||i===extra); };

/* ---------- 2. gifts of the road ---------- */
const GIFTS=[
  {id:'waylight', n:'Waylight',      ch:['c6r','c8c'],   d:'You can light a waymark where you stand and travel between waymarks you have visited. (T)'},
  {id:'hands',    n:'Steady Hands',  ch:['c7r','c7c'],   d:'Jobs and favours pay a little more. People can tell you will finish what you start.'},
  {id:'sight',    n:'Ember Sight',   ch:['c11'],         d:'Your eyes catch what is worth finding. Foraging and digging turn up more.'},
  {id:'reader',   n:'Name-Reader',   ch:['c14r','c14c'], d:'You can read what lies under a person: the Y page shows the cost of each thing you have become.'},
  {id:'stride',   n:'Long Stride',   ch:['c16r','c16c'], d:'Waymark travel takes half the time and half the crumbs.'},
  {id:'word',     n:"Keeper's Word", ch:['c20'],         d:'Waymark travel is free, and your word is worth a little more at every counter.'}
];
const has=(id,extra)=>{ const gf=GIFTS.find(x=>x.id===id); return !!gf&&safeCall(()=>doneAny(gf.ch,extra),false); };
const giftsNow=extra=>GIFTS.filter(x=>has(x.id,extra)).map(x=>x.id);
if(typeof payMul==='function'){ const o=payMul; payMul=function(t){ return o(t)+(has('hands')?0.06:0)+(has('word')?0.06:0); }; }
if(typeof luckBonus==='function'){ const o=luckBonus; luckBonus=function(){ return o()+(has('sight')?1:0)+(has('word')?1:0); }; }

/* ---------- 3. waymarks ---------- */
const WP=[
  {id:'plaza',  n:'Castle Plaza, Mallardia',        p:()=>PL.plaza()},
  {id:'yard',   n:'The Training Yard',              p:()=>PL.yard()},
  {id:'tower',  n:'The Old Watchtower',             p:()=>PL.tower()},
  {id:'house',  n:"Mallow's House",                 p:()=>[KX-44,KY-51]},
  {id:'edge',   n:'Edge of the Burnt Wood',         p:()=>[KX-48,KY-55]},
  {id:'tree',   n:'The Old Tree',                   p:()=>[KX-64,KY-59]},
  {id:'hearth', n:'The Great Hearth, Emberwick',    p:()=>PL.hearth(),   red:1},
  {id:'sgate',  n:"Emberwick's South Gate",         p:()=>PL.sgate(),    red:1}
];
const avail=w=>!w.red||safeCall(()=>!!g.story.redOpen,false);
const pos=()=>({x:g.px/TS,y:(g.py-2)/TS});
const distTo=p=>{ const c=pos(); return Math.hypot(p[0]-c.x,p[1]-c.y); };
function wpScan(){
  if(g.mode!=='play'||g.scene!=='world') return;
  for(const w of WP){
    if(G().wp[w.id]||!avail(w)) continue;
    const p=safeCall(w.p,null); if(!p) continue;
    if(distTo(p)<6){
      G().wp[w.id]=1; blip();
      toast('Waymark found: '+w.n+'.'+(has('waylight')?' You can travel here from any other waymark (T).':''),4600);
    }
  }
}
setInterval(()=>safeCall(wpScan),700);
const nearWp=()=>WP.find(w=>G().wp[w.id]&&avail(w)&&distTo(w.p())<8);
function fare(d){
  if(has('word')) return {cost:0,hrs:Math.max(0.5,d/160)};
  const half=has('stride')?0.5:1;
  return {cost:Math.round(d/25*half),hrs:Math.max(0.5,d/80*half)};
}
function travelTo(w){
  const near=nearWp();
  if(!has('waylight')){ toast('You have not yet learned to light a waymark. Keep walking the road.',3600); return false; }
  if(g.scene!=='world'){ toast('Waymarks only work in the open.',2400); return false; }
  if(!near){ toast('Stand near a waymark you have found to travel.',3200); return false; }
  if(near.id===w.id){ toast('You are already here.',2200); return false; }
  const p=w.p(), f=fare(distTo(p));
  if(g.crumbs<f.cost){ toast('The waymark asks '+f.cost+' crumbs for the lamp-oil. You have '+g.crumbs+'.',3600); return false; }
  g.crumbs-=f.cost; if(f.cost) coin(); fade(1.2);
  advanceClock(f.hrs);
  const sp=snapFree(Math.round(p[0]),Math.round(p[1]),4);
  g.px=(sp[0]+0.5)*TS; g.py=(sp[1]+0.95)*TS; g.dir='down'; unstick(); g.camX=g.px; g.camY=g.py-10; tileCache.clear(); g.lastTx=null; hudCache.obj=null;
  G().trips=(G().trips||0)+1;
  toast('You walk the lamp-line to '+w.n+'. '+(f.hrs<1.5?'About an hour':'About '+Math.round(f.hrs)+' hours')+' later'+(f.cost?', '+f.cost+' crumbs lighter.':'.'),4200);
  return true;
}

/* ---------- 1. who you are becoming ---------- */
const TR={
  candid: ['tell the truth','plain-spoken'],  gentle:['give people the benefit of the doubt','gentle'],
  proud:  ['hold your ground','proud'],        guarded:['keep a little back','careful'],
  steady: ['let people lean on you','steady'], tender:['notice the small ones first','tender']
};
const EDGE={
  candid:'It has cost you friends, and bought you the ones who stayed.', gentle:'It has been spent on people who did not earn it.',
  proud:'It has kept you upright, and kept others at a distance.',       guarded:'It has kept you safe, and kept you from being known.',
  steady:'Nobody has asked who holds you.',                              tender:'It is the part of you the world is hardest on.'
};
const word=n=>n>=8?'It defines you':n>=5?'It is clear to everyone':n>=3?'It is becoming a habit':'It has begun';
function traits(){ const h=safeCall(()=>S4st().h,{}); return Object.keys(TR).map(k=>[k,h[k]||0]).filter(x=>x[1]>=2).sort((a,b)=>b[1]-a[1]); }
const LEDW={
  truth:['You have told hard truths, and people remember which ones.'], mercy:['You have chosen mercy when it cost you.'],
  pride:['You have held your ground when you could have bent.'],         trust:['Someone has begun to trust you with something that matters.'],
  kin:['The kin of the red town speak of you at their tables.'],         crown:['The Crown has noted your name.'], ember:['The Hearth has noted your name.']
};
const STAND={crown:'The Crown',hearth:'The Hearth',mallow:'Mallow',sleepers:'The sleepers'};
const regard=(n,pl)=>n>=5?'would stand beside you':n>=3?(pl?'trust you':'trusts you'):n>=1?(pl?'have noticed you':'has noticed you'):(pl?'do not know you yet':'does not know you yet');
function becomingLines(){
  const out=[]; const t=traits();
  const nick=safeCall(()=>S4.nick(),null);
  out.push(['h','Who you are becoming']);
  out.push(['p',nick?'Some have started to call you the '+nick+'.':'You have not written much of yourself yet. That is not a fault. It is a page left open.']);
  for(const [k,n] of t.slice(0,3)) out.push(['p','You '+TR[k][0]+'. '+word(n)+'.'+(has('reader')?' '+EDGE[k]:'')]);
  const L=safeCall(()=>s2().led,{})||{};
  const led=Object.keys(LEDW).filter(k=>(L[k]||0)>=2);
  if(led.length){ out.push(['h','What the road has made of you']); led.forEach(k=>out.push(['p',LEDW[k][0]])); }
  const cap=safeCall(()=>S6st().cap,null);
  if(cap){ out.push(['h','Who is watching']); for(const k of Object.keys(STAND)) out.push(['p',STAND[k]+' '+regard(cap[k]||0,k==='sleepers')+'.']); }
  const mem=safeCall(()=>S4st().mem,[])||[];
  if(mem.length){ out.push(['h','What people remember']); mem.slice(-5).forEach(m=>out.push(['p','You '+m+'.'])); }
  return out;
}

/* ---------- 5. what changed ---------- */
const UPW={truth:'You told the truth when it was hard.',mercy:'You chose mercy.',pride:'You held your ground.',trust:'Someone trusts you more.',
  kin:'The kin will remember this.',crown:'The Crown has taken note.',ember:'The Hearth has taken note.',lie:'You kept something back.'};
const CAPW={crown:'The Crown thinks differently of you.',hearth:'The Hearth thinks differently of you.',mallow:'Mallow thinks differently of you.',sleepers:'The sleepers stir toward you.'};
function takeSnap(){
  const s=G();
  s.snap={led:Object.assign({},safeCall(()=>s2().led,{})),cap:Object.assign({},safeCall(()=>S6st().cap,{})),h:Object.assign({},safeCall(()=>S4st().h,{})),gifts:giftsNow()};
}
function chapterNote(id){
  const s=G(), sn=s.snap, lines=[];
  if(sn){
    const L=safeCall(()=>s2().led,{})||{};
    for(const k of Object.keys(UPW)) if((L[k]||0)>(sn.led[k]||0)) lines.push(UPW[k]);
    const cap=safeCall(()=>S6st().cap,{})||{};
    for(const k of Object.keys(CAPW)) if((cap[k]||0)>(sn.cap[k]||0)) lines.push(CAPW[k]);
    const h=safeCall(()=>S4st().h,{})||{};
    const dh=Object.keys(h).sort((a,b)=>(h[b]-(sn.h[b]||0))-(h[a]-(sn.h[a]||0)))[0];
    if(dh&&h[dh]-(sn.h[dh]||0)>=2) lines.push('You are leaning toward being someone who '+TR[dh][0]+'.');
  }
  const now=giftsNow(id), before=sn?sn.gifts:giftsNow();
  const newG=now.filter(x=>before.indexOf(x)<0);
  newG.forEach(x=>{ const gf=GIFTS.find(y=>y.id===x); lines.unshift('New gift: '+gf.n+'. '+gf.d); });
  return lines;
}
if(typeof S2!=='undefined'){
  const _b=S2.begin;
  S2.begin=function(id){ const r=_b.apply(this,arguments); safeCall(takeSnap); return r; };
  const _f=S2.finish;
  S2.finish=function(id,msg){
    let lines=[]; const title=safeCall(()=>S2.ch[id].title,id);
    lines=safeCall(()=>chapterNote(id),[]);
    if(lines.length||title){ const s=G(); s.sum.push({id,title,lines:lines.slice(0,5)}); if(s.sum.length>30) s.sum.shift(); }
    const r=_f.apply(this,arguments);
    if(lines.length) setTimeout(()=>{ if(g.mode==='play') toast('What changed: '+lines.slice(0,3).join(' '),8200); },4200);
    return r;
  };
}

/* ---------- 4. supply links ---------- */
if(typeof sxTimer==='function'){
  const _t=sxTimer;
  sxTimer=function(S,secs,label,onEnd){
    if(label==='The Ward'){
      const tonics=['p_ess_ashwood','p_ess_sealed'].filter(i=>(g.inv[i]||0)>0);
      if(tonics.length){
        const i=tonics[0]; g.inv[i]--; if(g.inv[i]<=0) delete g.inv[i];
        secs+=25;
        setTimeout(()=>safeCall(()=>{ if(typeof sxIn==='function'&&sxIn()) toast('You drink the tonic you brewed. The hum thins: +25 seconds on the Ward.',6500); }),2500);
        G().tonic=(G().tonic||0)+1;
      }
    }
    return _t(S,secs,label,onEnd);
  };
}

/* ---------- 6. mastery ---------- */
const MAST=[
  {id:'marks',   n:'Every Waymark',    d:'Find all the waymarks.',                   pay:120, p:()=>{ const a=WP.filter(avail); return [a.filter(w=>G().wp[w.id]).length,WP.length]; },
   lore:'Every lamp-line ever walked runs through someone who stopped to light it.'},
  {id:'gifts',   n:'All the Gifts',    d:'Earn every gift of the road.',             pay:200, p:()=>[giftsNow().length,GIFTS.length],
   lore:'A gift is a door the road leaves unlocked after you have walked far enough to need it.'},
  {id:'ch10',    n:'Ten Chapters',     d:'Live through ten chapters.',               pay:80,  p:()=>[Object.keys(safeCall(()=>s2().done,{})||{}).length,10],
   lore:'You have started to be able to tell a long road from a long night.'},
  {id:'ch20',    n:'The Long Road',    d:'Live through twenty chapters.',            pay:200, p:()=>[Object.keys(safeCall(()=>s2().done,{})||{}).length,20],
   lore:'Twenty doors. Each one was a choice that did not look like one.'},
  {id:'trait',   n:'A Defining Habit', d:'Let one way of being define you.',         pay:100, p:()=>[Math.min(8,(traits()[0]||[0,0])[1]),8],
   lore:'A habit is only a decision you stopped noticing you made.'},
  {id:'spells',  n:'Spell-Keeper',     d:'Know twelve spells.',                      pay:110, p:()=>[Math.min(12,safeCall(()=>spKnown().length,0)),12],
   lore:'The Art asks, then listens. You have learned how to do both.'},
  {id:'trips',   n:'Lamp-Walker',      d:'Travel between waymarks ten times.',       pay:90,  p:()=>[Math.min(10,G().trips||0),10],
   lore:'Distance is only the time you decline to spend.'}
];
function mastScan(){
  if(g.mode!=='play') return;
  const m=G().mast;
  for(const x of MAST){
    if(m[x.id]) continue;
    const [a,b]=safeCall(x.p,[0,1]);
    if(a>=b){
      m[x.id]=1; g.crumbs+=x.pay; coin();
      G().lore.push(x.lore);
      toast('Mastery: '+x.n+'. +'+x.pay+' crumbs. "'+x.lore+'"',7000);
      break;
    }
  }
}
setInterval(()=>safeCall(mastScan),2500);

/* ---------- panels ---------- */
function mkPanel(id,title,sub,closeLabel){
  const pan=document.createElement('div'); pan.className='panel xpanel'; pan.id=id; pan.hidden=true;
  pan.innerHTML='<div class="ph"><div><h2></h2><div class="say"></div></div><button class="hb" type="button">'+closeLabel+'</button></div><div class="xbody"></div><div class="pf"><span></span><span>Up/Down scroll &middot; X close</span></div>';
  pan.querySelector('h2').textContent=title; pan.querySelector('.say').textContent=sub;
  (document.getElementById('stage')||document.body).appendChild(pan);
  return {pan,body:pan.querySelector('.xbody'),say:pan.querySelector('.say'),btn:pan.querySelector('.ph button')};
}
const row=(cls,html)=>{ const d=document.createElement('div'); d.className='axrow '+(cls||''); d.innerHTML=html; return d; };
const head=(b,t)=>{ const h=document.createElement('h3'); h.textContent=t; b.appendChild(h); };

const BP=mkPanel('becompan','Who You Are Becoming','Not a score. A portrait, written in what you did.','Close (Y)');
function renderBecoming(){
  const b=BP.body; b.innerHTML='';
  for(const [k,t] of becomingLines()){ if(k==='h') head(b,t); else b.appendChild(row('', '<span class="gdbox"></span><div class="ds">'+esc(t)+'</div>')); }
  head(b,'Gifts of the road');
  for(const gf of GIFTS){ const ok=has(gf.id); b.appendChild(row(ok?'ok':'', '<span class="gdbox">'+(ok?'✓':'○')+'</span><div><b>'+esc(gf.n)+'</b><div class="ds">'+(ok?esc(gf.d):'Not yet earned. It comes with the road.')+'</div></div>')); }
  head(b,'Mastery');
  for(const x of MAST){
    const [a,c]=safeCall(x.p,[0,1]), ok=!!G().mast[x.id], pct=Math.min(100,Math.round(a/c*100));
    b.appendChild(row(ok?'ok':'', '<span class="gdbox">'+(ok?'✓':'○')+'</span><div><b>'+esc(x.n)+'</b><div class="ds">'+esc(x.d)+' '+Math.min(a,c)+' / '+c+(ok?' &middot; done':' &middot; pays '+x.pay+' crumbs')+'</div><div class="axbar"><i style="width:'+(ok?100:pct)+'%"></i></div></div>'));
  }
  const hint=[]; if(has('waylight')) hint.push('A tonic brewed from Ashwood or Winter essence buys 25 seconds at the Ward.');
  head(b,'Provisions that matter');
  b.appendChild(row('', '<span class="gdbox"></span><div class="ds">Brew an Ashwood Ember-Tea or a Winter-Hearth Tonic and carry it: it buys you 25 seconds when the Ward breaks. Crumbs from jobs and favours pay the lamp-oil for waymark travel.</div>'));
  const s=G().sum;
  if(s.length){ head(b,'Chapters behind you'); s.slice(-8).reverse().forEach(c=>b.appendChild(row('', '<span class="gdbox"></span><div><b>'+esc(c.title||c.id)+'</b><div class="ds">'+(c.lines.length?esc(c.lines.join(' ')):'A quiet chapter. It left its mark in smaller ways.')+'</div></div>'))); }
  if(G().lore.length){ head(b,'Lore unlocked'); G().lore.forEach(l=>b.appendChild(row('', '<span class="gdbox"></span><div class="ds axquote">'+esc(l)+'</div>'))); }
  BP.say.textContent=(safeCall(()=>S4.nick(),null)?'Known as the '+S4.nick()+'.':'Still being written.');
}
const WPAN=mkPanel('wppan','Waymarks','Lit places you have walked to.','Close (T)');
let wpSel=0, wpList=[];
function renderWp(){
  const b=WPAN.body; b.innerHTML='';
  const near=nearWp();
  wpList=WP.filter(w=>G().wp[w.id]&&avail(w));
  if(!has('waylight')){ b.appendChild(row('', '<span class="gdbox"></span><div class="ds">You have not yet learned to light a waymark. Walk the road; a gift will come. You can still see which waymarks you have found.</div>')); }
  else if(!near){ b.appendChild(row('', '<span class="gdbox"></span><div class="ds">Stand near a waymark you have found to travel from it.</div>')); }
  if(!wpList.length) b.appendChild(row('', '<span class="gdbox"></span><div class="ds">No waymarks found yet. Waymarks are the camps, gates and houses along the story road.</div>'));
  wpSel=Math.max(0,Math.min(wpSel,wpList.length-1));
  wpList.forEach((w,i)=>{
    const here=near&&near.id===w.id, f=fare(near?Math.hypot(w.p()[0]-near.p()[0],w.p()[1]-near.p()[1]):distTo(w.p()));
    const d=document.createElement('div'); d.className='axrow'+(i===wpSel?' ok':''); d.style.cursor='pointer';
    d.innerHTML='<span class="gdbox">'+(i===wpSel?'▶':(here?'●':'○'))+'</span><div><b>'+esc(w.n)+'</b><div class="ds">'+(here?'You are here.':(f.cost?f.cost+' crumbs &middot; ':'free &middot; ')+(f.hrs<1.5?'about an hour':'about '+Math.round(f.hrs)+' hours'))+'</div></div>';
    d.addEventListener('click',()=>{ wpSel=i; if(travelTo(w)) closeWp(); else renderWp(); });
    b.appendChild(d);
  });
  const lost=WP.filter(w=>avail(w)&&!G().wp[w.id]).length;
  if(lost) b.appendChild(row('', '<span class="gdbox"></span><div class="ds">'+lost+' waymark'+(lost===1?'':'s')+' still to find.</div>'));
  WPAN.say.textContent=wpList.length+' of '+WP.filter(avail).length+' found'+(has('word')?'. Travel is free.':(has('stride')?'. Fares halved.':'.'));
}
function openBecoming(){ if(g.mode!=='play') return; g.mode='becoming'; BP.pan.hidden=false; renderBecoming(); BP.body.scrollTop=0; blip(); }
function closeBecoming(){ if(g.mode!=='becoming') return; g.mode='play'; BP.pan.hidden=true; blip(); }
PANEL_CLOSE.becoming=()=>closeBecoming();
function openWp(){ if(g.mode!=='play') return; g.mode='waypts'; WPAN.pan.hidden=false; wpSel=0; renderWp(); WPAN.body.scrollTop=0; blip(); }
function closeWp(){ if(g.mode!=='waypts') return; g.mode='play'; WPAN.pan.hidden=true; blip(); }
PANEL_CLOSE.waypts=()=>closeWp();
BP.btn.addEventListener('click',closeBecoming); WPAN.btn.addEventListener('click',closeWp);
KEYMAP.y=KEYMAP.Y='becoming'; KEYMAP.t=KEYMAP.T='waypts';
{
  const _p=press;
  press=function(k){
    if(g.mode==='becoming'){ if(k==='x'||k==='becoming') closeBecoming(); else if(k==='down') BP.body.scrollTop+=60; else if(k==='up') BP.body.scrollTop-=60; return; }
    if(g.mode==='waypts'){
      if(k==='x'||k==='waypts') closeWp();
      else if(k==='down'){ wpSel=Math.min(wpList.length-1,wpSel+1); renderWp(); }
      else if(k==='up'){ wpSel=Math.max(0,wpSel-1); renderWp(); }
      else if(k==='z'&&wpList[wpSel]){ if(travelTo(wpList[wpSel])) closeWp(); else renderWp(); }
      return;
    }
    if(g.mode==='play'&&k==='becoming'){ openBecoming(); return; }
    if(g.mode==='play'&&k==='waypts'){ openWp(); return; }
    _p(k);
  };
}
{
  const btns=document.querySelector('.hud .btns');
  if(btns){
    const mk=(id,txt,fn)=>{ const b=document.createElement('button'); b.className='hb'; b.type='button'; b.id=id; b.textContent=txt; b.addEventListener('click',e=>{ e.currentTarget.blur(); fn(); }); btns.appendChild(b); };
    mk('bBecome','Becoming (Y)',openBecoming); mk('bWay','Waymarks (T)',openWp);
  }
}

/* ---------- the journal ---------- */
{
  const _j=journalExtra;
  journalExtra=function(sec,line){
    _j(sec,line);
    safeCall(()=>{
      sec('Who you are becoming');
      const L=becomingLines().filter(x=>x[0]==='p').slice(0,3); L.forEach(x=>line(x[1]));
      const gs=GIFTS.filter(x=>has(x.id)); line(gs.length?'Gifts of the road: '+gs.map(x=>x.n).join(', ')+'.':'No gifts of the road yet. Press Y for your portrait.');
      const w=WP.filter(x=>G().wp[x.id]&&avail(x)).length; if(w) line('Waymarks found: '+w+' of '+WP.filter(avail).length+'. Press T.');
    });
  };
}
window.GROW={G,GIFTS,WP,MAST,has,travelTo,openBecoming,openWp,becomingLines,chapterNote};
})();
