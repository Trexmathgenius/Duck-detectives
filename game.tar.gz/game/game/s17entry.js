/* Chapters 10, 19, 20 used to drop the player straight into the throne room / Old Tree the moment the
   chapter began, wherever they were standing. Now the objective names the place, a door/hollow stands
   there in the world, and the scene only opens when the player walks up and uses it. */
(function(){
  const ENT=[
    {ch:'c10', sx:'throne', pt:()=>PL.castle(), glyph:'door', col:'#7a4a24',
     first:'Go to <b>Castle Quackenhold</b> and find the door that is waiting',
     say:['The gate stands open an inch. Beyond it: the cold hall, the stair that remembers, and a door that has waited a hundred years for somebody to knock.']},
    {ch:'c19', sx:'wardsc', pt:()=>PL.tree(), glyph:'oldtree', col:null,
     first:'Run to the <b>Old Tree</b> in the Burnt Wood: the sleepers are moving',
     say:['The trunk is split like a door, and the notes are coming through it, slowly, a whole tone down. The sleepers are stirring around the ring.']},
    {ch:'c20', sx:'tree20', pt:()=>PL.tree(), glyph:'oldtree', col:null,
     first:'Go to the <b>Old Tree</b> in the Burnt Wood',
     say:['The ring is silent. Beneath the roots, a half-circle of people who did not know they were all coming. You step in among them.']}
  ];
  const seen=(id)=>{ const q=s2(); q.ent=q.ent||{}; return q.ent; };
  for(const e of ENT){
    const c=S2.ch[e.ch]; if(!c) continue;
    c.start=function(){ s2set(0); hudCache.obj=null; };
    const o=c.obj;
    c.obj=function(s){
      let t=o.call(c,s); if(!t||s!==0) return t;
      if(seen()[e.ch]) return t.replace(/\s*\(about [^)]*\)/,'');
      let w=''; try{ w=whP(e.pt()); }catch(_){}
      return e.first+w+'.';
    };
    const pt=e.sx==='throne'?e.pt():[KX-66,KY-64];
    S2.prop({id:'ent_'+e.ch, wx:pt[0], wy:pt[1], glyph:e.glyph, col:e.col, mark:'!',
      when:()=>g.scene==='world'&&s2at(e.ch,0),
      use(){ say('',e.say,()=>{ seen()[e.ch]=1; hudCache.obj=null; sxEnter(e.sx); }); }});
  }
})();
