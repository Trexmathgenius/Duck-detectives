'use strict';
/* ===== DOORSTEPS STAY CLEAR =====
   With some world seeds the random scatter of trees, hay and bushes can land on the tiles in front of a door and wall a building
   in. Nothing that is scattered by chance is allowed within a wing's reach of a door. */
{
  const _genTile=genTile;
  const SCATTER=new Set([T.TREE,T.DARK,T.HAY,T.STUMP,T.ROCK,T.BUSH]);
  const DOORS=new Set([T.DOOR,T.HOUSEDOOR,KHDOOR,RBDOOR]);
  genTile=function(x,y){
    const t=_genTile(x,y);
    if(SCATTER.has(t)){
      for(let dy=1;dy<=3;dy++) for(let dx=-1;dx<=1;dx++) if(DOORS.has(_genTile(x+dx,y-dy))) return T.GRASS;
    }
    return t;
  };
}

/* ===== THE MAP FOLLOWS THE WORLD =====
   The explored map keeps a painted picture of every chunk. When the world changes (Emberwick opening, the Umbral Wood clearing...) those pictures
   showed the old dark forest. Whenever the tile cache is dropped, the painted chunks are repainted from the current world. */
{
  const _clear=tileCache.clear.bind(tileCache);
  tileCache.clear=function(){
    _clear();
    chunks.forEach(ch=>{ if(ch.cv) buildChunk(ch); });
  };
}


/* ===== THE STORY ROADS =====
   Whatever the world seed, the story must always be finishable. Two meandering corridors, three tiles wide, are kept free of
   the random trees, rocks and bushes: one from the first pond to Puddlewick, and one from the kingdom's east gate to the
   Hollow Wood. Only chance scatter is ever cleared, never anything built. */
{
  const _gen=genTile;
  const NAT=new Set([T.TREE,T.DARK,T.ROCK,T.BUSH,T.STUMP,T.HAY,T.MUSH]);
  let roadKey=null, road=null, busy=false;
  const rk=(x,y)=>x+','+y;
  function carve(set,pts,seedN){
    for(let s=0;s<pts.length-1;s++){
      const [ax,ay]=pts[s], [bx,by]=pts[s+1], n=Math.max(Math.abs(bx-ax),Math.abs(by-ay))*2;
      for(let i=0;i<=n;i++){
        const u=i/n, x=ax+(bx-ax)*u, y=ay+(by-ay)*u;
        const nx=-(by-ay), ny=(bx-ax), L=Math.hypot(nx,ny)||1;
        const w=Math.sin(u*Math.PI*3+seedN+s)*2.2*Math.sin(Math.PI*Math.min(1,u*8)*Math.min(1,(1-u)*8));   /* a gentle wind, straight at both ends */
        const cx=Math.round(x+nx/L*w), cy=Math.round(y+ny/L*w);
        for(let dx=-1;dx<=1;dx++) for(let dy=-1;dy<=1;dy++) set.add(rk(cx+dx,cy+dy));
      }
    }
  }
  function ensure(){
    const k=String(SEED_TEXT)+'|'+SEED;
    if(roadKey===k&&road) return road;
    if(busy) return null;
    busy=true; roadKey=k; road=new Set();
    try{
      const p=getTown(2,0);
      if(p){
        carve(road,[[0,3],[22,7],[44,1],[p.cx-24,p.cy+1],[p.cx-8,p.cy+1]],1);
      }
      const K=(lx,ly)=>[KX+lx,KY+ly];
      carve(road,[K(59,0),K(72,-12),K(84,-34),K(96,-62),K(112,-88),K(126,-100),K(127,-104)],5);
      /* the march route, the swans, the graves, the watchers: every place the story visits outside the walls */
      carve(road,[K(59,0),K(63,-2),K(63,-52),K(71,-56)],7);
      carve(road,[K(63,-52),K(64,-60),K(63,-66)],9);
      carve(road,[K(70,-10),K(76,-18),K(80,-25)],11);
      carve(road,[K(-59,0),K(-66,12),K(-71,30)],13);
      carve(road,[K(-66,12),K(-70,25)],15);
      carve(road,[K(-59,0),K(-72,-14),K(-79,-30)],17);
      for(const c of [[-73,34],[80,-25],[63,-66],[-80,-30],[-70,25],[-71,30],[71,-56],[70,-54]]) for(let dx=-2;dx<=2;dx++) for(let dy=-2;dy<=2;dy++) road.add(rk(KX+c[0]+dx,KY+c[1]+dy));
      for(const c of CAMPS) for(let dx=-1;dx<=1;dx++) for(let dy=-1;dy<=1;dy++) road.add(rk(KX+c[0]+dx,KY+c[1]+dy));
    }catch(e){ road=new Set(); }
    busy=false; return road;
  }
  genTile=function(x,y){
    const t=_gen(x,y);
    if(NAT.has(t)){
      const r=ensure();
      if(r&&r.has(rk(x,y))&&!inWood(x,y)&&!(g.story&&g.story.redOpen&&inRed(x,y))) return T.GRASS;
    }
    return t;
  };
}
