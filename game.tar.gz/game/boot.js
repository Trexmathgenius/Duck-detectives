/* Loaded first. If any later script throws while the page is starting, say so on screen
   (with the file and line) instead of leaving a blank window. */
(function(){
  const errs=[];
  function show(){
    let b=document.getElementById('bootfail');
    if(!b){ b=document.createElement('div'); b.id='bootfail'; (document.body||document.documentElement).appendChild(b); }
    b.innerHTML='<b>Duck Detectives could not start.</b><br>Something in the game files failed to load. Your save is safe.<br><br><code></code><br><small>Close this window and open it again. If it keeps happening, copy the line above when you report it.</small>';
    b.querySelector('code').textContent=errs.slice(0,3).join('\n');
  }
  window.__boot={ok:false,errs};
  window.addEventListener('error',function(e){
    if(window.__boot.ok) return;
    errs.push((e.message||'error')+'  ('+String(e.filename||'').split('/').pop()+':'+(e.lineno||'?')+')');
    show();
  });
  window.addEventListener('load',function(){ setTimeout(function(){ if(!errs.length) window.__boot.ok=true; },0); });
})();
