'use strict';
/* ===== BRAND, THE QUIET CHAIR, AND THE COSTS ON THE ASH ROAD (v1.19) ===== */
const S4npc=id=>S2.npcs.find(d=>d.id===id);

rc(['Elder Cinder','Captain Halbeak'],'rbrand',()=>!!k3('brandFate'),['(They have both heard what became of Brand. Neither says it directly.) "A man was given back his own name today. It is a heavy thing, to be given that."']);

/* --- the Ash Road costs --- */
{
  const hask=S4npc('hask');
  if(hask){ const _t=hask.talk; hask.talk=function(n,done){
    const k=K3();
    if(k.fence||swChNum()<16) return _t.call(this,n,done);
    say('Fence-Warden Hask',['Hask is hammering a post into the ash. The fence runs on to the horizon, one post for every soldier.','"It is cold in the next valley. The Hollow-side villages burn wood they bring from far off. My posts are dry, and standing, and doing nothing. I know it. I cannot be the one to say burn them."'],()=>{
      choose('Fence-Warden Hask','"What do you say?"',['"Burn them. The living are cold."','"Keep them. Some things are not for burning."','"Burn half. Number them first."'],q=>{
        k.fence=['burned','kept','half'][q]; S4st().h[['gentle','proud','steady'][q]]++;
        if(q===0) { s2led('mercy',1); g.crumbs+=25; } if(q===1){ s2led('pride',1); } if(q===2){ s2led('trust',1); }
        S4.setcx('hask',k.fence,['told a fence-warden what to do with a hundred posts','told a fence-warden to keep the fence','numbered a fence before burning half'][q]);
        say('Fence-Warden Hask',[['"Burn them. Yes. I will do it tonight. I will do the first one myself."','"Keep. Yes. Cold, then. We have been cold before."','"Half. By number. I will write each name down first. It will take all winter."'][q]],()=>{ coin(); done(); });
      },2);
    });
  }; }
  const pim=S4npc('pim');
  if(pim){ const _t=pim.talk; pim.talk=function(n,done){
    const k=K3();
    if(!k.bridged||k.candles) return _t.call(this,n,done);
    say('Ferrier Pim',['(Across the water, in the dusk, a figure kneels on the old stub with a taper. She has seen the new deck. She is not looking at it.)','"That is Rue. The old stub is where the candles are, for the walkers. A hundred years of them. The new deck sits right over it."','"I did not think. I mended it so people could cross. I did not think what it would cover."'],()=>{
      choose('Ferrier Pim','Pim looks at you. "You started this. What do I do?"',['"Leave the candles. Build the deck beside them."  (30 crumbs)','"Move the candles to the new deck. People should see them."','"Close the deck at night. Open it by day."'],q=>{
        if(q===0){ if(g.crumbs<30) { say('Ferrier Pim',['"You have not the crumbs for that, and I have not the planks."'],done); return; } g.crumbs-=30; }
        k.candles=['kept','lost','ferry'][q]; S4st().h[['tender','guarded','steady'][q]]++; s2led(['mercy','pride','trust'][q],1);
        S4.setcx('pim',k.candles,['paid to keep a vigil beside a bridge','moved a vigil to make room for traffic','shut a bridge at night for a row of candles'][q]);
        say('Ferrier Pim',[['"Beside. Yes. A narrower deck. Rue will not forgive me, but she will light the candles."','"The deck. Yes. Rue will light them there. She will say nothing for a year."','"By day. By night, the candles. We shall be the only ferry in the world that keeps hours for the dead."'][q]],()=>{ coin(); done(); });
      },2);
    });
  }; }
}

/* --- the last page of the epilogue: who you became (never a number, never a name) --- */
{
  const _ec=epiCard;
  epiCard=function(label,title,sub,pages,theme,cb){
    try{
      if(label==='EPILOGUE'&&Array.isArray(pages)){
        const k=S4.self(), s=S4st(), out=[];
        if(k){ out.push({candid:'You became someone who says the true thing even when it would be easier not to.',gentle:'You became someone who gives people the benefit of the doubt before they ask.',proud:'You became someone who holds their ground, and, mostly, was right to.',guarded:'You became someone who keeps a door on the latch, and knows exactly why.',steady:'You became someone people lean on without noticing, and you let them.',tender:'You became someone who notices the small ones first.'}[k]||TRAIT[k].line); }
        const m=s.mem.slice(-3); if(m.length) out.push('Somewhere, someone remembers that you '+m.join(', and that you ')+'.');
        const f=K3().brandFate; if(f) out.push({shelter:'Brand tends a lamp at the Tree, and has begun, slowly, to speak.',trial:'Brand answered to the Hearth, and the Hearth, to everyone\'s surprise, was merciful.',exile:'Brand walks the Ash Road, counting posts, and some mornings someone leaves him bread.',witness:'Brand stood before both towns and said it all, and was listened to. It is the thing he wanted most, and he did not know it.'}[f]);
        if(out.length) pages=pages.concat([out.join('  ')]);
      }
    }catch(e){ console.error(e); }
    return _ec(label,title,sub,pages,theme,cb);
  };
}
