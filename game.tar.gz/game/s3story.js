'use strict';
/* ===== STORY II, EXPANDED (v1.18) =====
   - Prologue side stories that plant seeds for Story II (the Hands, the court's quiet faction).
   - Chapter 13k-15k, THE KEEPER'S ROAD: a third route. Stay with the hermit, hold a table instead of picking a side.
   - Chapter 16.5, THE ASH ROAD: the long way round, through the new lands, to the Sealing Stones and the Hall of Names.
   - Chapters 21-24, ACT VI: AFTER THE DOOR. The sleepers wake, the two towns learn to share a road, the wood is replanted.
   - Character scenes: each person who mattered has more to say, and what you ask is remembered. */

ACTS[21]='ACT VI  -  AFTER THE DOOR';
const K3=()=>{ const q=s2(); return q.k3||(q.k3={}); };
const k3=(k,v)=>{ const o=K3(); if(v===undefined) return o[k]; o[k]=v; return v; };
const ENDING=()=>s2().ending||'';
const eiderLives=()=>!(ENDING()==='wake'&&s2red());
const S3PAL={pell:{body:'#4a6a9a',wing:'#34507a',bill:'#e6c441'},thistle:{body:'#c0392b',wing:'#962d22',bill:'#ff9d2e'},wrenna:{body:'#8a8a90',wing:'#5a5a62',bill:'#c9a24a'},pim:{body:'#6a7a5a',wing:'#4a5a3a',bill:'#c9a24a'},
  hob:{body:'#a8793f',wing:'#7a5a2a',bill:'#e0b84a'},orla:{body:'#b5524a',wing:'#8a3a34',bill:'#e6c441'},tam:{body:'#4a6a9a',wing:'#34507a',bill:'#e6c441'},bree:{body:'#8a4a4a',wing:'#6a3434',bill:'#c9a24a'},eider:{body:'#e0ddd0',wing:'#b0ab9a',bill:'#c9b27a'}};
const lineP=(who,lines,done)=>say(who,lines,done);
function npc3(id,name,pos,pal,head,when,talk,mark,neck){ const d=Object.assign({id,name,pal,head:head||null,neck:neck||null,still:true,when,talk,mark},pos); return S2.npc(d); }

/* ---------------------------------------------------------
   Who is in the clearing, and what each of them will tell you once the war is over.
   Every topic can be asked once. Asking is how you get to know someone; it is remembered.
   --------------------------------------------------------- */
const DEEP={
 'Hermit Mallow':{open:'Mallow is sitting on the roots of the Old Tree with his back against the bark, and his mother\'s hand in both of his.',
  topics:[
   {k:'m1',t:'"You are older than your mother."',lines:['He laughs, and it cracks halfway. "I am. I am eighty-one years older than my mother, by the reckoning of the calendar, and about nine by the reckoning of the part of me that is still on that road."','"I used to rehearse what I would say to her. A speech. It was very good. I have forgotten every line of it. It turns out that when she wakes, the first thing she does is ask if I have eaten."'],led:{trust:1}},
   {k:'m2',t:'"Why did you not follow?"',lines:['The question lands somewhere soft. "Because I was seven, and she told me to light the hearth, and I did what I was told. It is the only thing I have ever been sure I was good at."','"For eighty years I thought obedience was cowardice. Now she is asking if I have eaten, and I think perhaps it was the only way I could love her from that far away."'],led:{trust:1,truth:1}},
   {k:'m3',t:'"What will you do now?"',lines:['"I do not know. That is new. I have always known. I would get up, I would walk, I would keep the lantern lit, I would not be asked."','"I think I would like to be asked. I think that is what I am going to do. I am going to be asked things, and be bad at answering, and be allowed."'],led:{trust:1}}]},
 'Little Poppy':{open:'Poppy has found a pair of boots three sizes too big for her, and is walking the whole ring of the sleepers in them, very solemnly.',
  topics:[
   {k:'p1',t:'"Was it the right word?"',lines:['She thinks about it with her whole face. "I think there are two kinds of right. The kind where nobody is sad. And the kind where everyone is a bit sad, but together."','"Mama says the second kind is mostly what there is. I thought it was a bad deal, but I am starting to think it is the only one that is actually for sale."'],led:{kin:1}},
   {k:'p2',t:'"Are you afraid of the Hearth?"',lines:['"Every day. It is very big, and I am very small, and it does not care." She considers. "But it is warm. I think being afraid and being warm are the same thing, a bit, if you stand close enough."'],led:{kin:1}},
   {k:'p3',t:'"What do you want to be?"',lines:['"A Keeper. Mama says it is a boring job. You light a thing, and you keep it lit, and nobody says thank you."','"But I think I would like to be the one nobody says thank you to. That sounds like it is how you know it worked."'],led:{kin:1,mercy:1}}]},
 'Elder Cinder':{open:'Cinder is standing very straight, with a blanket over one wing that someone has put there and that she has not yet noticed.',
  topics:[
   {k:'c1',t:'"Were you careful at the Hearth?"',lines:['Her beak tightens. Then, slowly, it does not. "Orla told you. Orla told everyone, in her sleep, for a hundred years. I heard it as a hum. I did not know it was a sentence."','"Yes. I was careful. I was careful the way a woman is careful with a thing she cannot bear to lose, and so I never took it anywhere dangerous. That is what the Elders were, that night. Careful. It looks very like cowardice in a good light."'],led:{truth:1}},
   {k:'c2',t:'"What would you like to say to her?"',lines:['"I would like to say I am sorry. I would like to say it so that it cost me something. Everything I have ever said has been so very reasonable."','"Perhaps I will say it badly. Perhaps that is the point."'],led:{mercy:1,ember:1}},
   {k:'c3',t:'"Do you trust Halbeak?"',lines:['"No. And I trust him more than anyone in the kingdom. Those are both true. I have learned this year that they were always going to be both true."'],led:{crown:1,ember:1}}]},
 'Captain Halbeak':{open:'Halbeak has taken off his helmet and set it on a root, and does not seem to know what to do with his hands.',
  topics:[
   {k:'h1',t:'"Are you afraid of what peace does to a soldier?"',lines:['"Every day since the door opened." He says it the way a man puts down a heavy parcel. "I know the wall. I know the shift, the line, the roll. I do not know what I am if nobody is trying to get over it."','"Tam laughed at me, when he woke. Called me a rabbit in a helmet. I think it was the nicest thing a soldier has said to me."'],led:{trust:1,crown:1}},
   {k:'h2',t:'"What did the king ask of you?"',lines:['"To be useful after I was no longer necessary. He said it was the hardest order a captain gets. He said he had given it to himself, and failed, and would like to see someone else try."'],led:{crown:1,truth:1}},
   {k:'h3',t:'"Who will you be?"',lines:['"Someone who is good with a spade, I am told. Ruddock says there are a great many things that want holding up, if you stop looking for the thing that wants knocking down."'],led:{trust:1}}]},
 'Warden Ruddock':{open:'Ruddock is standing guard at nothing in particular, which is the first time in his life that he has been allowed.',
  topics:[
   {k:'r1',t:'"Your grandfather was on the Siege Field."',lines:['A pause long enough to be a door. "He was. A foot soldier. He died at the second ditch. My father told me so, and he told me who did it, and he told me I should not forget."','"I did not forget. I held it so carefully that I forgot everything else. Tam says he knew him. Tam says he was funny."'],led:{truth:1,ember:1}},
   {k:'r2',t:'"What did Tam tell you?"',lines:['"That my grandfather could not stop whistling. That it was the only thing that got the company through the first night. That he was whistling when he died, and that the man on the other side of the ditch stopped, and listened, and did not strike."','"I have to decide what to do with that. I have a hundred years of grudge and one tune."'],led:{mercy:1,ember:1}}]},
 'Gordamom':{open:'A voice from the Tree, warm and slow. It is not a hum any more. It is a man, speaking, for the first time in a century, with no one to answer to.',
  topics:[
   {k:'g1',t:'"Did you mean the word?"',lines:['"Shelter. Yes. I meant it so much that it left. A word that is meant that much cannot stay in one mouth. I think that is what a promise is, small one: a word you meant too much to keep."'],led:{truth:1}},
   {k:'g2',t:'"Are you still angry?"',lines:['"Not at them. At the hundred years. At the part of me that thought lying down was the same as keeping watch." A leaf, high in the crown, unfolds with a very small sound. "I would like to try the other thing now. Standing up."'],led:{mercy:1}}]}
};
function deepTalk(n,done,who){
  const D=DEEP[who]; if(!D) return say(who,['...'],done);
  const open=D.topics.filter(t=>!k3(t.k));
  const opts=open.map(t=>t.t).concat(['Just keep them company']);
  choose(who,D.open,opts,k=>{
    if(k>=open.length) return say(who,[['We do not have to say anything. It is good to have someone not saying it with me.','Thank you for staying.','I will remember who sat down.'][Math.floor(Math.random()*3)]],done);
    const t=open[k]; k3(t.k,1);
    say(who,t.lines,()=>{ for(const key in (t.led||{})) s2led(key,t.led[key]); coin(); if(done) done(); });
  },opts.length-1);
}
const deepLeft=who=>DEEP[who]?DEEP[who].topics.filter(t=>!k3(t.k)).length:0;

/* =========================================================
   PROLOGUE SIDE STORIES  (you may find these before Chapter 5)
   ========================================================= */
const S3P=()=>{ const st=g.story; return st.s3||(st.s3={}); };
const inPrologue=()=>{ const q=g.story&&g.story.s2; return !q||!q.ch; };
npc3('pro_hands','Stranger in a Grey Cloak',{red:[22,31]},3,'hood',()=>inPrologue()&&!!g.story&&!S3P().handsGone,(n,done)=>{
  const P=S3P();
  if(!P.hands){
    say('Stranger in a Grey Cloak',['(The cloak is the colour of old candle-smoke. Under the hood there is a beak, and very tired eyes, and a smell of tallow.)','"You are the one who asks things. Do not ask me. I am only passing through, and I should like to continue to do that."','"But if you were to find, some day, a note sealed in tallow, addressed to the Hands, and you wondered what it meant... know that we are not wicked. We are afraid. It looks very like it, from outside."'],()=>{
      choose('Stranger in a Grey Cloak','The stranger waits.',['"Afraid of what?"','"I will keep that in mind."','Say nothing, and offer them a seat.'],k=>{
        P.hands=1+k; if(k===0){ s2ledPre('truth'); say('Stranger in a Grey Cloak',['"Of the quiet. Of what is under it. Of the day it stops being quiet."','"Go on. If you hear four notes at night, do not tell yourself it is the wind. Tell yourself it is the first one."'],()=>{ P.handsGone=1; done(); }); }
        else if(k===1){ say('Stranger in a Grey Cloak',['A nod. A small one, like a latch.'],()=>{ P.handsGone=1; done(); }); }
        else { s2ledPre('mercy'); say('Stranger in a Grey Cloak',['A long, slow breath. They sit. Neither of you says anything for the length of a candle.','"Thank you," they say, and go.'],()=>{ P.handsGone=1; done(); }); }
      },2); }); return; }
  say('Stranger in a Grey Cloak',['...'],done);
},()=>S3P().hands?null:'!');
npc3('pro_court','Clerk Whistle',{k:[2,22]},5,'bow',()=>inPrologue()&&!!g.story,(n,done)=>{
  const P=S3P();
  if(!P.court){
    say('Clerk Whistle',['"Mind the ink. The Crown\'s clerks are not allowed to be seen, so I am being stationary, very quietly, by a pillar."','"There are two courts in Kingsbill. The one with the guards, and the one with the chairs. The one with the guards says the wall holds. The one with the chairs says nobody has gone to see if the wall is holding."','"I carry the minutes between them. It is, I find, a very interesting thing to carry. You learn what each of them is careful not to say."'],()=>{
      choose('Clerk Whistle','Whistle straightens a stack of paper that was already straight.',['"What does the Quiet Chair want?"','"Whose side are you on?"','"Show me the minutes."'],k=>{
        P.court=1+k;
        if(k===0){ s2ledPre('truth'); say('Clerk Whistle',['"To read the Wall. It has not been read in a hundred years, because reading it would mean admitting it is a wall."','"Look for the Chair when the trouble starts. They will not be loud. They will be there."'],()=>{ P.courtDone=1; done(); }); }
        else if(k===1){ s2ledPre('mercy'); say('Clerk Whistle',['"Mine? Nobody has ever asked. I think I am on the side of whoever has to carry the paper afterwards."','"That is a lonelier side than it sounds. Thank you for asking."'],()=>{ P.courtDone=1; done(); }); }
        else { say('Clerk Whistle',['"No. No, I cannot. But I can tell you the date of the last entry about the sleepers. It was one hundred years ago next month, and the entry is one word."','"The word is \'later\'."'],()=>{ P.courtDone=1; done(); }); }
      },2); }); return; }
  say('Clerk Whistle',['"If you have a question, ask it somewhere with fewer pillars."'],done);
},()=>S3P().court?null:'!');
function s2ledPre(k){ const q=s2(); q.led[k]=(q.led[k]||0)+1; }
/* the seeds pay off: the grey stranger and the clerk both turn up again, in the aftermath */

/* =========================================================
   THE KEEPER'S ROAD  (third route)
   After the failed summit, if Mallow trusts you, he offers a third way.
   ========================================================= */
Object.assign(NEXT,{c16r:'c16x',c16c:'c16x',c16x:'c17',c13k:'c14k',c14k:'c15k',c15k:'c16x',c21:'c22',c22:'c23',c23:'c24'});
{
  const _sn=s2next;
  s2next=function(id){
    if(id==='c12'&&s2().keeper) return 'c13k';
    return _sn(id);
  };
  const _fin=S2.finish;
  S2.finish=function(id,msg){
    const q=s2();
    if(id==='c12'&&!q.keeperAsked&&s2led('trust')>=2){
      q.keeperAsked=1;
      seq([['Hermit Mallow',['Wait. Before you pick a road.','There is a third one. It is not clever, and it is not fast, and it does not end in a victory. I have walked it alone for eighty years.','It runs between the two roads. It is a table, with two chairs, and a book of days in the middle, and a kettle. It asks only that both sides sit down.','I will not ask you to take it. I will ask you to know it is there.']]],()=>{
        choose('Hermit Mallow','Mallow waits.',['"Teach me the Keeper\'s Road."','"I will take the side I chose."'],k=>{
          if(k===0){ q.keeper=1; s2led('trust',1); toast('A third road opens: the Keeper\'s Road.',4200); }
          _fin(id,msg);
        },1);
      });
      return;
    }
    _fin(id,msg);
  };
}
/* Mallow's house and the two envoys wait at the edge of the Burnt Wood */
const KEEP=()=>s2().keeper;
npc3('mallow_k','Hermit Mallow',{k:[-44,-52]},RED_PALS[0],'hood',()=>(s2at('c13k')||s2at('c14k')||s2at('c15k')),(n,done)=>done&&done());
npc3('pell','Envoy Pell',{k:[-41,-50]},S3PAL.pell,'helm',()=>(s2at('c13k')||s2at('c15k')),(n,done)=>done&&done(),()=>(s2at('c13k',1)&&!k3('lPell'))?'!':null);
npc3('thistle','Envoy Thistle',{k:[-47,-50]},S3PAL.thistle,'cap',()=>(s2at('c13k')||s2at('c15k')),(n,done)=>done&&done(),()=>(s2at('c13k',1)&&!k3('lThistle'))?'!':null);
function done_(n){ return ()=>{ n.talking=false; n.t=1; }; }

S2.ch.c13k={route:'both',theme:'dark',title:'The Hermit\'s Table',sub:'Not every road runs between two towns.',
  intro:['The path to Mallow\'s house is the same path, but nobody walks it. Smoke rises from a chimney that has been rebuilt more times than anyone has counted.','Inside there is a table, and two chairs, and a third that has never been sat in. There is a kettle on the fire. There is a book of days, open, with a quill in the fold.'],
  recap:'You sat down at the hermit\'s table and listened to both sides without choosing one.',
  start(){ s2set(0); },
  obj(s){ return ['Go to <b>Mallow\'s house</b> at the edge of the Burnt Wood and sit down.','Hear out both envoys at the table: <b>Envoy Pell</b> from the Crown, and <b>Envoy Thistle</b> from the Hearth.','Tell <b>Mallow</b> how the grievances should be written down.'][s]; },
  mtalk(done){
    const s=s2().step;
    if(s===0){ seq([['Hermit Mallow',['Sit. No, that one. The third chair is for whoever has not arrived yet.','The Keeper\'s Road is not a road. It is a habit. You sit down with the people who will not sit down with each other. You do not tell them what to feel. You write down what they say, in their words, and you read it back.','Two envoys came this morning. They arrived within an hour of each other, from opposite doors of the same wood, and did not look at one another. Pell is from the Chancery. Thistle is from the Hearth. Hear them out. Do not argue. Do not solve.']]],()=>{ s2set(1); done(); }); return true; }
    if(s===2){ choose('Hermit Mallow','Mallow dips the quill. "How shall I write it down?"',['"In their words. Exactly."','"In kinder words than they used."','"In mine. I will tell the story."'],k=>{
        if(k===0) s2led('truth',2); else if(k===1) s2led('mercy',2); else s2led('pride',1);
        k3('rec',k);
        say('Hermit Mallow',[['It is the harder way. It will look rude on the page. It will be the first honest page in the book.','It is a gentle way. It will not be quite true, and that is a kind of mercy, and I will not pretend otherwise.','Ah. You mean to be the one who tells it. I have done that. It is lonely at the top of a story.'][k],'Good. Sit with it a moment. Then we will see what the book itself has to say.'],()=>{ S2.finish('c13k'); done(); }); },2); return true; }
    return false;
  },
  ptalk(n,done){ if(s2().step!==1) return false;
    if(k3('lPell')){ say('Envoy Pell',['I have said what I came to say. I notice I feel lighter. I do not trust it.'],done); return true; }
    seq([['Envoy Pell',['The Chancery asks one thing: that the Hollow stop calling the sleepers by their names. It makes them people. It makes the wall a crime.','I am a clerk. I do not decide what a thing is. But I have read the minutes, and I think the Chancery is afraid of being right, which is worse than being wrong.']]],()=>{ k3('lPell',1); coin(); if(k3('lThistle')){ toast('Both envoys heard.',2600); } done(); }); return true; },
  ttalk(n,done){ if(s2().step!==1) return false;
    if(k3('lThistle')){ say('Envoy Thistle',['I told you what the Hearth wants. I did not tell you what I want. I want to go home and put my feet in a bucket.'],done); return true; }
    seq([['Envoy Thistle',['The Hearth asks one thing: that the Crown say the word \'exile\' aloud. Not apologise. Just say it. For a hundred years they have called it a \'relocation\'.','I am a lamplighter\'s daughter. I do not decide what a thing is either. But I have carried the same lantern since I was nine, and I know what it is to be told the dark is a kind of home.']]],()=>{ k3('lThistle',1); coin(); if(k3('lPell')){ toast('Both envoys heard.',2600); s2set(2); } done(); }); return true; }
};
/* the first envoy to be heard should not be able to skip the second */
{
  const _c13=S2.ch.c13k; const _p=_c13.ptalk, _t=_c13.ttalk;
  _c13.ptalk=function(n,done){ const r=_p(n,()=>{ if(k3('lPell')&&k3('lThistle')) s2set(2); done(); }); return r; };
}

S2.ch.c14k={route:'both',theme:'dark',title:'The Book of Days',sub:'A book is a kind of road. Someone has to walk it.',
  intro:['Mallow keeps a book of days. Not a record of what happened: a record of what people were like. He says everyone has a back page, where the writer puts down what they could not bring themselves to say aloud.','He asks for three small things before he will read yours. Anything lost. Anything someone dropped on the Ash Road and did not come back for.'],
  recap:'You brought Mallow three lost things, and he read you back to yourself. You decided what to carry and what to set down.',
  start(){ s2set(0); },
  obj(s){ return ['Bring Mallow three <b>lost things</b> from the Ash Road: one from the <b>Cinder Fields</b>, one from <b>Weeping Ridge</b>, and one from the <b>Ashen Fen</b>. ('+['d1','d2','d3'].filter(k=>k3(k)).length+'/3)','Return to <b>Mallow</b>. He will read you the page he has written about you.'][s]; },
  mtalk(done){
    const s=s2().step;
    if(s===0){ say('Hermit Mallow',['Three things. Anything lost. A mitten, a stone, a pipe. The Ash Road is full of them.','('+['d1','d2','d3'].filter(k=>k3(k)).length+' of 3.)'],done); return true; }
    if(s===1){
      const P=S4.portrait();
      seq([['Hermit Mallow',['(He turns the book toward himself. He reads it the way some people read a letter: quietly, with a finger under each line.)','"This is the page I wrote about you. I wrote it a little at a time, while you were not looking. It is not a verdict. It is only what I noticed."'].concat(P.lines).concat(['"I am going to ask you three things about it. For each, you may carry it, or you may set it down. Setting down does not erase. It only means you will not be handed it again on the road."'])]],()=>{
        choose('Hermit Mallow',P.q1,['Carry it. It is part of me.','Set it down.'],a=>{
          S4.shift(P.k1,a===1?-1:1);
          choose('Hermit Mallow',P.q2,['Carry it. I will not hide it.','Set it down. I am done with it.'],b=>{
            S4.shift(P.k2,b===1?-1:1);
            choose('Hermit Mallow','And last: the kindness you have shown. Someone else needs it more than you do. Will you spend it?',['Spend it. They need it.','Keep it. I earned it.'],c=>{
              if(c===0){ S4.shift('gentle',-1); s2led('trust',1); } else { S4.shift('proud',1); }
              k3('bal',[a,b,c].join(''));
              say('Hermit Mallow',['Then it is written. You have just done what most people spend a lifetime avoiding: you read yourself, and did not argue.','Thank you for the things you brought. Come back tomorrow. I have asked both envoys to sit at the table again. This time you will not be the only one in the room who has said something true.'],()=>{ S2.finish('c14k'); done(); });
            },1);
          },1);
        },1);
      }); return true; }
    return false;
  }
};
/* the three lost things */
const LOST=[
  {id:'d1',k:'cinder',wx:84,wy:-1108,item:'c_mitten',glyph:'scroll',col:'#c0392b',name:'a red mitten',txt:['A child\'s mitten, red wool, burnt at the cuff. It is lying on the grey road with the thumb pointing north-west, as if it had been trying to hold something.','You put it in your pack, gently. It weighs nothing, and you can feel it.']},
  {id:'d2',k:'ridge',wx:52,wy:-1206,item:'w_cairnstone',glyph:'stone',col:'#9a9aa0',name:'a cairn-stone',txt:['The top stone of a waymark, knocked to the ground. Turn it over: somebody scratched a name into the underside, and under that, "come home".','You do not read the name. You put it in your pack, and you mean to bring it back.']},
  {id:'d3',k:'fen',wx:-44,wy:-1146,item:'f_reedpipe',glyph:'candle',col:'#8a9a5a',name:'a reed pipe',txt:['A pipe cut from a fen reed, snagged on a stalk. It has four holes. When you lift it, it plays, without you blowing, the first four notes of a lullaby.','You put it in your pack, quickly, as if it might finish.']}];
for(const d of LOST){ S2.prop({id:'lost_'+d.id,wx:d.wx,wy:d.wy,glyph:d.glyph,col:d.col,when:()=>s2at('c14k',0)&&!k3(d.id),mark:'!',use(){ say('',d.txt,()=>{ k3(d.id,1); addItem(d.item); coin(); const n=['d1','d2','d3'].filter(k=>k3(k)).length; toast('Lost things: '+n+'/3.',2800); hudCache.obj=null; if(n>=3){ s2set(1); } }); }}); }

S2.ch.c15k={route:'both',theme:'dark',title:'The Quiet Road',sub:'A table, a kettle, two chairs, and a third.',
  intro:['The envoys return at noon, together this time. They have walked the whole way in step, and have not once looked sideways.','Mallow has put out three cups. Nobody has asked who the third is for.'],
  recap:'You held the table. Whether it held was up to the people at it.',
  start(){ s2set(0); },
  obj(s){ return ['Sit down at the table with <b>Envoy Pell</b> and <b>Envoy Thistle</b>. Hear them out again, and then <b>speak</b>.','Speak with <b>Mallow</b>, and take his leave.'][s]||''; },
  ptalk(n,done){ if(s2().step!==0) return false; return this.__sit(done); },
  ttalk(n,done){ if(s2().step!==0) return false; return this.__sit(done); },
  __sit(done){
    if(k3('tbl')){ say('',['The table is finished with. The kettle is on.'],done); return true; }
    S2.persuade({who:'The Table',intro:['Pell is on one side, Thistle on the other. Between them, the book of days, open to the page you dictated.','Pell reads the Hearth\'s grievance aloud. Thistle reads the Crown\'s. Each of them stops, once, in the wrong place, as if the page had grown a stair.','Mallow looks at you. The third chair is empty. It is yours, if you want it.'],
      rounds:[{q:'Pell says: "The Chancery will say \'exile\' aloud. If the Hearth says \'siege\'." Thistle: "The Hearth will say \'siege\'. If the Crown says it was fear." Who goes first?',opts:[
          {t:'"I will. I was afraid, too. Everyone in this room has been."',p:2,req:()=>s2led('truth')>=2,led:{truth:1},say:['Pell\'s hand goes still on the page. "...That is the first thing anyone has said to me this year that I could not file."']},
          {t:'"Whoever is more tired."',p:1,say:['A pause. Thistle laughs, briefly, in spite of herself. "That is me. I will say it."']},
          {t:'"The one who started it."',p:0,led:{pride:1},say:['Silence. "Which one," says Pell, "would that be?"']}]},
        {q:'Thistle asks: "And when we have said these words, what do we do the next morning?"',opts:[
          {t:'"Light the same lantern. Walk the same road, from both ends."',p:2,req:()=>!!g.inv.keeperlantern||!!g.inv.hearthcoal,say:['Thistle looks at your lantern. "A lamp, for each of us. I had not thought of two."']},
          {t:'"Eat something. Together, if you can."',p:1,say:['Pell\'s beak twitches. "The Chancery has never, to my knowledge, eaten with the Hearth." "Then it will be a first."']},
          {t:'"Draw up a treaty."',p:0,say:['Both envoys wince, in the identical way of people who have read many.']}]},
        {q:'Mallow says, very quietly: "What is the third chair for?"',opts:[
          {t:'"For the one who is not here. The sleepers."',p:2,say:['The three of them look at the empty chair. Nobody says anything. Thistle sets her cup in front of it.']},
          {t:'"For whoever arrives late."',p:1,say:['"That has always been the Keeper\'s answer," says Mallow. "It is a good one. It is not the only one."']},
          {t:'"I do not know."',p:1,led:{truth:1},say:['"Good," says Mallow. "That is the honest one."']}]}],
      need:4,
      win:sc=>{ k3('tbl','agreed'); coin(); s2led('trust',1); s2led('mercy',1); say('Hermit Mallow',['It held. I did not think it would. I thought it would last as far as the second round and then somebody would remember a grievance.','Pell has asked to stay for the night. Thistle has asked to stay for the night. They have asked, in the same sentence, for the same room. I am going to say it is a misunderstanding and give them the same room.'],()=>{ s2set(1); }); },
      lose:sc=>{ k3('tbl','strained'); say('Hermit Mallow',['It did not hold. Not all the way. They are sitting at opposite ends of the table, and the kettle is cold.','But they are sitting. That is not nothing. That has not happened in a hundred years.'],()=>{ s2set(1); }); }});
    return true;
  },
  mtalk(done){
    if(s2().step!==1) return false;
    seq([['Hermit Mallow',['The Keeper\'s Road does not end in a victory. It ends when someone else is willing to sit in your chair.','I will stay here. I will keep the kettle on and the table clear. You, little detective, have the Burnt Wood to walk, and the long way round to do it. I am not going to tell you which way to go. I am going to tell you the Ash Road is the way my mother went.','Take the lantern. Hold it. It leans toward the north-west. It leans, I have decided, toward people.']]],()=>{ S2.finish('c15k'); done(); }); return true; }
};
/* the generic chapter-routed talk for the hermit and the envoys */
{
  for(const d of S2.npcs.filter(d=>d.id==='pell'||d.id==='thistle')){
    const key=d.id==='pell'?'ptalk':'ttalk';
    d.talk=function(n,done){ const c=S2.ch[s2cur()]; if(c&&c[key]&&c[key].call(c,n,done)) return; say(d.name,[d.id==='pell'?'The Chancery has not yet instructed me to be moved.':'The Hearth has not yet instructed me to be moved.'],done); };
  }
  const m=S2.npcs.find(d=>d.id==='mallow_k');
  m.talk=function(n,done){ const c=S2.ch[s2cur()]; if(c&&c.mtalk&&c.mtalk.call(c,done)) return; say('Hermit Mallow',['The kettle is on.'],done); };
  m.mark=()=>{ const c=S2.ch[s2cur()]; if(!c) return null; if(s2at('c13k',0)||s2at('c13k',2)||s2at('c14k',1)||s2at('c15k',1)) return '!'; return null; };
}

/* =========================================================
   CHAPTER 16.5: THE ASH ROAD
   ========================================================= */
S2.ch.c16x={route:'both',numLabel:'CHAPTER 16.5',theme:'dark',title:'The Ash Road',sub:'The long way round, because the short way is a wall.',
  intro:['North of the Burnt Wood the land turns grey and keeps going. There is a road there, the Ash Road, that the old maps call the Mile of Sorrow and the new ones do not call anything.','The three hundred did not march straight into the quiet. They went round: up through the Cinder Fields, over Weeping Ridge, across the Ashen Fen, and then, a long way later, south. It is the road a person walks when they are not yet ready to arrive.','Mallow says you will understand the Wood better if you take it slowly. He says it is the only fair way to be shown it.'],
  recap:'You walked the Ash Road, lit the beacon on the Ridge, mended the crossing, stood at the Sealing Stones and read the Hall of Names.',
  start(){ s2set(0); K3().ashDone=0; },
  obj(s){ return ['Walk the <b>Ash Road</b> north to the <b>Cinder Mile-Stone</b>, in the Cinder Fields.','Climb <b>Weeping Ridge</b> and speak to the <b>Cairn-Keeper</b>. Carry the lantern in your hand.','Gather <b>3 reed bundles</b> from the river\'s edge below the Ridge ('+(k3('reeds')||0)+'/3), and bring them to <b>Ferrier Pim</b> at the crossing.','Follow the cold road north from Emberwick to the <b>Sealing Stones</b>.','Enter the ruins of the first Emberwick and read the <b>Hall of Names</b>.','Return to the north rim of the Burnt Wood. <b>Mallow</b> is waiting.'][s]||''; }
};
S2.zone({id:'ash_mile',wx:SW_WP.mile.x,wy:SW_WP.mile.y,r:5,when:()=>s2at('c16x',0),fn(){ say('',['The Mile-Stone is the height of a duck, grey as bread, and cut with notches in rows of ten. Three hundred and twelve rows. The last row is incomplete.','Someone has laid a small posy at the foot of it. The flowers are Ash Poppies, which means someone came here in the last year. Someone walks this road, and does not talk about it.'],()=>{ s2set(1); }); }});
npc3('wrenna','Cairn-Keeper Wrenna',{wx:SW_WP.ridge.x+2,wy:SW_WP.ridge.y+1},S3PAL.wrenna,'cap',()=>s2at('c16x',1)||k3('wrennaMet'),n=>{
  if(s2at('c16x',1)){
    if(!(g.inv.keeperlantern||g.inv.hearthcoal)){ addItem('keeperlantern'); say('Cairn-Keeper Wrenna',['(She looks at your empty paws.)','"You walked the Ash Road with nothing in your hand? Mallow\'s an optimist. I keep a spare. Here. It leans, you will find. All of them lean."'],()=>{ toast('Received: the Keeper\'s Lantern.',3200); done_(n)(); }); return; }
    if(g.inv.keeperlantern&&!isHeld('keeperlantern')){ say('Cairn-Keeper Wrenna',['"That is a lantern, in your pack. That is not a lantern. A lantern is in your hand."','(Put the Keeper\'s Lantern on your hotbar and hold it.)'],done_(n)); return; }
    seq([['Cairn-Keeper Wrenna',['"There. Now you look like someone going somewhere. I am the fourth Wrenna, in case you are wondering. My great-great-grandmother was the scout. She wore a feather for every night she did not light a fire. When the three hundred came through, she gave it up."','"This ridge weeps because it is thinking of her. I do not say that to be poetic. The streams come out of the cracks cold, and they taste of salt."','"There is a beacon at the top, a cairn with a hollow in it. Nobody has lit it since the march. Hold the lantern to it. Slowly. It will know you."']]],()=>{
      k3('wrennaMet',1); k3('beacon',0); done_(n)(); }); return; }
  say('Cairn-Keeper Wrenna',[k3('beaconLit')?'"It burns. You can see it from the fen, if the air is clear. I think of it as her, saying: you are all right. Keep walking."':'"The beacon is on the top. Hold the lantern to it."'],done_(n));
},()=>s2at('c16x',1)&&!k3('wrennaMet')?'!':null);
S2.prop({id:'ridge_beacon',wx:SW_WP.ridge.x-3,wy:SW_WP.ridge.y-2,glyph:'stone',col:'#9a9aa0',when:()=>s2at('c16x',1)&&k3('wrennaMet'),mark:'?',use(){
  if(g.inv.keeperlantern&&!isHeld('keeperlantern')){ say('',['The cairn has a hollow in it the size of a lantern. You will need the lantern in your hand, not in your pack.'],()=>{}); return; }
  if(!g.inv.keeperlantern&&!g.inv.hearthcoal){ say('',['You have nothing to light it with.']); return; }
  k3('beaconLit',1); coin();
  seq([['',['You lift the lantern to the hollow. The flame leans toward the cairn, and stays, as if drinking.','A second flame, small and white, climbs the cairn like a bird. It is a quiet fire, and it does not burn the stone. It lights a path of other cairns, one after another, down the whole length of the ridge, each a little smaller than the last.','Somewhere very far away, in a house that has had no visitors in a long while, a woman sits up and puts down her tea.']]],()=>{ s2led('trust',1); s2led('mercy',1); s2set(2); });
}});
const REEDS=[[-16,-1170],[-14,-1148],[-12,-1192]];
REEDS.forEach((p,i)=>S2.prop({id:'reed_'+i,wx:swRiverX(p[1])+5+i,wy:p[1],glyph:'candle',col:'#8a9a5a',when:()=>s2at('c16x',2)&&!k3('reed'+i),mark:'!',use(){ say('',['A bed of ash-reeds at the water\'s edge, tall as a duck, bound at the head with red thread. Somebody has been keeping them. The thread is new.','You cut a bundle, as the Ferrier showed, and tie it with a twist of the same thread.'],()=>{ k3('reed'+i,1); k3('reeds',(k3('reeds')||0)+1); addItem('s_reedbundle'); coin(); hudCache.obj=null; toast('Reed bundles: '+k3('reeds')+'/3.',2600); }); }}));
ITEMS.s_reedbundle={name:'Ash-Reed Bundle',desc:'A bundle of ash-reeds tied with red thread. Fen ducks lay them across the water when the bridge is down.',use:'note',note:'It smells of rain and smoke.',nogift:true,glyph:'bundle',gc:['#8a9a5a','#6a4a2a'],cat:'quest'};
npc3('pim','Ferrier Pim',{wx:SW_FERRY.x+6,wy:SW_FERRY.y},S3PAL.pim,'cap',()=>s2at('c16x',2)||s2at('c16x',3)||k3('pimMet'),n=>{
  k3('pimMet',1);
  if(!s2at('c16x',2)){ say('Ferrier Pim',[k3('bridged')?'"It holds. It sings a bit in the wind. I think that is the reeds, letting you know they are there."':'"Bridge or no bridge, the river will do as it likes."'],done_(n)); return; }
  const have=g.inv.s_reedbundle||0;
  if(have<3){ say('Ferrier Pim',['"The bridge broke in the second spring after the march. A flood. The fen ducks said: leave it, it\'s a good river, it\'s only trying to get home."','"I\'ve been the ferrier for forty years and never once ferried anyone. If you can bring me three reed bundles from the bank, tied with red, I\'ll lay a new deck. It won\'t be fancy. It\'ll be crossable."','('+have+' of 3 bundles in your pack.)'],done_(n)); return; }
  for(let i=0;i<3;i++) delInv('s_reedbundle');
  seq([['Ferrier Pim',['"Red thread. Good. The old kind."','(He lays the reeds across the broken stub, one by one, tying each with a knot you do not recognise. It takes a quarter of an hour, and the whole time he hums three notes.)','"There. There. If you tell anyone I did it myself I shall say it was the fen. The fen likes to be thanked."']]],()=>{
    s2().fl.fenBridge=1; k3('bridged',1); s2led('mercy',1); g.crumbs+=60; coin(); toast('The Ashen Fen crossing is mended. +60 crumbs.',4200); s2set(3); done_(n)(); });
},()=>s2at('c16x',2)&&(g.inv.s_reedbundle||0)>=3?'?':(s2at('c16x',2)?'!':null));
S2.prop({id:'seal_stones',wx:SW_STONES.x,wy:SW_STONES.y,glyph:'stone',col:'#8a9aa8',when:()=>s2at('c16x',3),mark:'!',use(){
  seq([['',['A ring of nine stones, taller than a duck, standing in snow. Between them a crystal, dim, with a frost-ring around its base. Each stone has a name cut in the lee: three Elders, three Captains, three Keepers.','They signed this place shut. Not with magic. With ink, and then with stone, which is what ink wants to be.']]],()=>{
    choose('The Sealing Stones','The crystal in the middle hums, very faintly. The snow around it is slightly warmer.',['Touch the crystal. It is sealed, and you are not afraid of it.','Walk round the ring and read the names, all nine.','Leave the seal alone and go in by the gate.'],k=>{
      if(k===0){ s2led('pride',1); say('',['The crystal flares, white, and shows you a hall, a long way off, full of ducks in cloaks. Then it shows you your own face, very small, as if from a long way up.','It goes dark. You are standing in the snow, and you feel as if you were just shown the size of something.'],()=>{ s2set(4); }); }
      else if(k===1){ s2led('truth',1); say('',['The names: Cinder\'s grandmother. Halbeak\'s grandfather. Brand\'s great-uncle. Six more. Each one carved by a hand that did not want to.','At the last stone, small, under all the others, a tenth hand has cut: "we were all afraid".'],()=>{ s2set(4); }); }
      else { s2led('mercy',1); say('',['You do not touch the stones. You nod to them, as to old people, and walk through the gap in the ring toward the ruins.'],()=>{ s2set(4); }); }
    },2);
  });
}});
const HALL=[
  {k:'alder',t:'Alder, son of Orla. Aged six. "He held on to the cart for forty miles."',after:'Orla\'s son. You will remember this name. You will, at some point, be asked for it.'},
  {k:'sedge',t:'Sedge, a weaver. "She made a doll for every child in the wagon and never kept one."',after:'The rag doll in the cold room is hers. Somebody should say that aloud.'},
  {k:'tam',t:'Tam, a soldier. "He walked in, he said, to see that they got there."',after:'Tam. He walked in with them. He is one of the three hundred, and nobody will tell him that he chose it.'},
  {k:'blank',t:'(A blank brick, between Alder and Sedge. It is clean. Someone has chalked a circle on it, and left the chalk.)',after:'A name is wanted here.'}
];
S2.prop({id:'hall_names',wx:SW_WP.hall.x,wy:SW_WP.hall.y,glyph:'grave',col:'#8a8e98',when:()=>s2at('c16x',4),mark:'!',use(){
  const read=HALL.filter(h=>k3('hn_'+h.k)).length;
  const opts=HALL.map(h=>h.t.split('.')[0]+(k3('hn_'+h.k)?' (read)':''));
  opts.push('Leave the Hall');
  seq([['',read===0?['You step through a gate in a ring of tumbled houses. Rows of bricks stand in the snow, each cut with one name, in a small hand, in a cold wind. This was the first Emberwick, and this was the last room in it.','Gordamom kept the names here. He wrote them one at a time on the nights he could not sleep. He wrote them until they were all done. There are three hundred and twelve. The last row is still unfinished.']:['The Hall of Names. The snow has stopped. The bricks have the dull shine of old paper.']]],()=>{
    choose('The Hall of Names','Which will you read?',opts,k=>{
      if(k>=HALL.length){ if(read>=3||k3('hn_blank')){ k3('hallDone',1); s2set(5); } else say('',['You have not read enough yet. Read at least three, and decide what to do about the blank brick.']); return; }
      const h=HALL[k]; k3('hn_'+h.k,1);
      if(h.k==='blank'){
        choose('The Hall of Names','A blank brick, a circle of chalk. A name is wanted. Whose?',['Bree. She is not dead, but she will be remembered on the road.','Gordamom. He is the one who kept the book.','King Eider. His name is not here, and should be.','Leave it blank. It is not mine to fill.'],w=>{
          k3('wrote',w); if(w===0) s2led('kin',1); if(w===1) s2led('trust',1); if(w===2) s2led('mercy',1); if(w===3) s2led('truth',1);
          say('',['You chalk '+['Bree','Gordamom','Eider',''][w]+(w<3?' on the brick, in your own hand.':'nothing on it, and leave the chalk where it was.'),'The wind catches the dust, and carries a little of it off over the roofs.'],()=>{ hudCache.obj=null; if(k3('hn_alder')&&k3('hn_sedge')&&k3('hn_tam')) { k3('hallDone',1); s2set(5); } });
        },3);
        return;
      }
      say('',[h.t,h.after],()=>{ s2led('truth',1); coin(); hudCache.obj=null; if(k3('hn_alder')&&k3('hn_sedge')&&k3('hn_tam')&&k3('hn_blank')){ k3('hallDone',1); s2set(5); } });
    },opts.length-1);
  });
}});
npc3('mallow_rim','Hermit Mallow',{wx:SW_WP.rim.x+3,wy:SW_WP.rim.y+3},RED_PALS[0],'hood',()=>s2at('c16x',5),n=>{
  seq([['Hermit Mallow',['You are quiet. Good. It has that effect.','Wrenna lit the beacon behind you, did she not? I felt it from here. A warmth, on the back of the neck, like someone saying your name in the next room.','I walked this road once, a long time ago, in the dark, holding the hand of someone older than I was. I was seven. I did not know it was the last time I would be held.','The Burnt Wood is behind that wall. It is the quietest thing in the world. I have been afraid of it all my life, and today, because of you, I think I might be able to go in.']]],()=>{
    g.crumbs+=80; addItem('w_whistle'); coin(); S2.finish('c16x','The Ash Road is walked. +80 crumbs. Received: Scout\'s Whistle.'); done_(n)(); });
},()=>s2at('c16x',5)?'!':null);

/* =========================================================
   ENDING 4 (STILL BEING DECIDED): THE KEEPER, and the re-ask for those who let it stay
   ========================================================= */
S2.prop({id:'restay',k:[-66,-60],glyph:'star',col:'#c9a6ff',when:()=>{ const q=s2(); return q.ch==='end'&&q.ending==='stay'; },mark:'!',use(){
  const q=s2();
  say('The Old Tree',['The humming has not changed. It is waiting, the way a tree waits, for the weather to come round again.',q.reasked?'You have already asked twice. The Tree does not mind.':'It will answer once more, if you ask.'],()=>{
    if(q.reasked){ return; }
    choose('The Old Tree','Ask again?',['Ask again. "Is it safe?"','Leave it.'],k=>{ if(k===0){ q.reasked=1; q.ending=''; q.ch='c20'; q.step=0; revealScene({fl:{}}); } },1);
  });
}});

/* =========================================================
   ACT VI: AFTER THE DOOR (chapters 21 to 24)
   The ward is gone or changed. The war is not exactly over: it has become a harder kind of problem, which is two towns.
   ========================================================= */
{
  const _w=s2ward;
  s2ward=function(){ const id=s2cur(); if(id&&/^c2[1-9]/.test(id)) return 0; return _w(); };
}
const WK=()=>({wake:'wake',door:'door',keeper:'keeper'})[ENDING()]||'door';
S2.ch.c21={route:'both',theme:'both',title:'What the Sleepers Dreamt',sub:'Waking is the slowest thing a person does.',
  intro:['Three hundred ducks sit up in the ash, one at a time, like lamps being lit down a long street. They are not fully awake. They are not fully asleep. They are in the long, unlit hour between, which lasts, in a body that has slept a century, about a week.','Nobody tells you what to do. Nobody tells anybody. A cook finds his hands. A mother finds her son. A soldier finds, to his considerable embarrassment, that he is still holding a spear.'],
  recap:'You sat with the sleepers as they woke: Hob, Orla and Tam. You stayed.',
  start(){ s2set(0); },
  obj(s){ return ['Sit with the waking: <b>Hob the cook</b>, <b>Orla</b>, and <b>Tam the soldier</b>, in the clearing by the <b>Old Tree</b>, in the Burnt Wood (north-west of Kingsbill). ('+['hob','orla','tam'].filter(k=>k3('w_'+k)).length+'/3)','Return to <b>Mallow</b> and <b>Bree</b> at the foot of the Old Tree.'][s]; }
};
S2.prop({id:'wake_in',k:[-66,-63],glyph:'oldtree',when:()=>false});
npc3('hob','Hob, a cook',{k:[-70,-60]},S3PAL.hob,'cap',()=>s2at('c21')||s2at('c22')||s2at('c23')||s2at('c24'),n=>{
  if(s2at('c21')&&!k3('w_hob')){
    const jug=!!g.inv.b_hobjug;
    say('Hob',['(A big duck, sitting on the ground, patting his apron as if it might have a pocket. He looks up at you with great care.)','"Is there... was there any bread? I made the bread. I made it for all of them. I never got to see if they liked it."'],()=>{
      const opts=['"There is bread. They ate it. They said it was good."'].concat(jug?['Give him his water-jug.']:[]).concat(['"Rest. I will see to the bread."']);
      choose('Hob','He waits.',opts,k=>{
        let m;
        if(k===0){ s2led('truth',1); m=['His eyes fill. "You are lying a bit. It is the nicest thing a stranger has done for me."']; }
        else if(jug&&k===1){ delInv('b_hobjug'); s2led('mercy',1); s2led('kin',1); m=['He takes it in both wings. He turns it over. He finds the crude H on the base with his thumb.','"I never put my name on anything. I never thought anyone would notice. It was only the jug." He is crying, a bit, in the way of a large man who has not been awake.']; }
        else { s2led('mercy',1); m=['"Yes. Yes, that would be fine. Thank you. I will rest. Do not let them burn it."']; }
        say('Hob',m,()=>{ k3('w_hob',1); coin(); toast('Sat with: '+['hob','orla','tam'].filter(k=>k3('w_'+k)).length+' of 3.',2600); if(['hob','orla','tam'].every(k=>k3('w_'+k))) s2set(1); done_(n)(); }); },opts.length-1);
    }); return;
  }
  say('Hob',['"They have found a kitchen. A real one. Four walls. I am going to cry on the stove."'],done_(n));
},()=>s2at('c21',0)&&!k3('w_hob')?'!':null);
npc3('orla','Orla, a mother',{k:[-62,-60]},S3PAL.orla,null,()=>s2at('c21')||s2at('c22')||s2at('c23')||s2at('c24'),n=>{
  if(s2at('c21')&&!k3('w_orla')){
    const knows=!!k3('hn_alder');
    seq([['Orla',['(She is standing, which seems to have cost her. Her eyes go round the ring, looking at each face, and past them.)','"I am looking for a boy. About this high. Brown. Holding a cart."','"He is not here. Is he. I came back from the Rise and he was gone, and they dragged me on. I stood on the road for forty miles and I knew it. I just wanted to hear someone say."']]],()=>{
      const opts=knows?['"His name is on the wall in the north. Alder. Aged six. He held on to the cart for forty miles."','"I am so sorry."']:['"I am so sorry."','"I do not know. I can find out."'];
      choose('Orla','She waits for the answer.',opts,k=>{
        let m;
        if(knows&&k===0){ s2led('truth',2); s2led('kin',1); m=['She sits down, slowly, where she is standing.','"Forty miles. He always did hold on. It was what he was for." She laughs, a little, wrongly. "Thank you. Someone wrote it down. That is all I wanted. That someone wrote it down."']; }
        else if(!knows&&k===1){ s2led('mercy',1); m=['"Yes. Yes, please. If it can be found out. I would rather have the knowing than the hope." She is looking at the horizon, the way a person looks at a gate.','(You will remember the north. There is a hall there.)']; }
        else { s2led('mercy',1); m=['"Yes," says Orla. "So am I." And they both stay exactly where they are, which is the kindest thing available.']; }
        say('Orla',m,()=>{ k3('w_orla',1); coin(); toast('Sat with: '+['hob','orla','tam'].filter(k=>k3('w_'+k)).length+' of 3.',2600); if(['hob','orla','tam'].every(k=>k3('w_'+k))) s2set(1); done_(n)(); }); },opts.length-1);
    }); return;
  }
  say('Orla',['"I am told I may stay. I am told there is a house. I am going to sit in it and see what it is like to be a person with a door."'],done_(n));
},()=>s2at('c21',0)&&!k3('w_orla')?'!':null);
npc3('tam','Tam, a soldier',{k:[-66,-57]},S3PAL.tam,'helm',()=>s2at('c21')||s2at('c22')||s2at('c23')||s2at('c24'),n=>{
  if(s2at('c21')&&!k3('w_tam')){
    seq([['Tam',['(He has lain down his spear in the ash and is looking at it as if it were a stranger\'s coat.)','"I was told to hold the line at the Reeds. I held it. I was told to hold it until I was relieved. No one relieved me. I am a very patient man."','"Is there anyone I should salute? Is there a king? Is there a king and is he cross?"']]],()=>{
      choose('Tam','He looks at the spear.',['"You are relieved, Tam. I relieve you."','"Pick it up. It is a good spear. Hold it until you can put it down on your own."','"The king is not cross. He is alive."'],k=>{
        let m;
        if(k===0){ s2led('mercy',1); s2led('trust',1); m=['He stands very straight, and salutes with his whole body, and then, because he cannot help it, breaks into a laugh.','"Relieved! By a duck with no rank. I shall write to my mother. ... Oh. I shall not write to my mother."']; }
        else if(k===1){ s2led('truth',1); m=['He turns the spear in his wings. "Aye. Aye, that is the right thing to say. A man should put things down on his own."','He leans it against the Old Tree, very gently, as if it might sleep.']; }
        else { s2led(s2red()?'ember':'crown',1); m=[eiderLives()?'"Alive." He says it as if it were a word in a language he used to speak. "He cried on the wall. Did you know? I never told. He was crying. I have been carrying that a hundred years."':'"...Was alive." He nods slowly. "He cried, on the wall, that night. I never told. I should like it recorded that he did."']; }
        say('Tam',m,()=>{ k3('w_tam',1); coin(); toast('Sat with: '+['hob','orla','tam'].filter(k=>k3('w_'+k)).length+' of 3.',2600); if(['hob','orla','tam'].every(k=>k3('w_'+k))) s2set(1); done_(n)(); }); },2);
    }); return;
  }
  say('Tam',[ k3('w_tam')?'"Halbeak is a good man. He does not know it. I have informed him."':'...'],done_(n));
},()=>s2at('c21',0)&&!k3('w_tam')?'!':null);
npc3('bree','Bree',{k:[-63,-62]},S3PAL.bree,'hood',()=>s2at('c21')||s2at('c22')||s2at('c23')||s2at('c24'),n=>{
  if(s2at('c21',1)){
    seq([['Bree',['(She is sitting up, with a blanket around her shoulders that is not hers. Mallow is next to her, with his hand in hers, and neither of them seems in a hurry to let go.)','"I told him to light the hearth. And I told him to eat something. I told him not to follow. I thought a woman who says three things to a child on a road is allowed to have one of them obeyed."','"He did all three. I am so proud of him, and I cannot find the words, because the words I had were for a boy of seven. He is an old man. He is the oldest man I have ever met, and he is my son."']],
      ['Hermit Mallow',['She asked if I had eaten. That is the whole conversation. We have been having it for an hour. It is the best conversation of my life.','Little detective. Thank you. Whatever is next, I would like to do it in the same room as her.']]],()=>{ S2.finish('c21'); done_(n)(); });
    return; }
  deepTalk(n,done_(n),'Hermit Mallow');
},()=>s2at('c21',1)?'!':null);

S2.ch.c22={route:'both',theme:'both',title:'Two Towns, One Road',sub:'A road is only a promise that two places will keep answering each other.',
  intro:['It takes a season, and then it takes another. Nobody is cruel. Nobody is kind in the easy way. They are kind the way people are kind who are very, very careful of each other: with long silences, and the occasional gift of a pear.','Halbeak and Cinder arrive at the Old Tree on the same morning, with maps. They have drawn the Lantern Road in different colours. Neither will say which line is whose.'],
  recap:'You sat the Crown and the Hearth down together, and the road was agreed on, or nearly.',
  start(){ s2set(0); },
  obj(s){ return ['Hear <b>Captain Halbeak</b> and <b>Elder Cinder</b> about the road. ('+['hal','cin'].filter(k=>k3('r_'+k)).length+'/2)','Bring them together at the <b>Council Stone</b> beside the Old Tree.'][s]; }
};
const AF=()=>s2at('c22')||s2at('c23')||s2at('c24');
npc3('halbeak','Captain Halbeak',{k:[-59,-62]},BLUE_PAL,'helm',()=>AF(),n=>{
  if(s2at('c22',0)&&!k3('r_hal')){
    seq([['Captain Halbeak',['The Crown\'s map is the blue one. It runs straight, from the south gate to the Old Tree, in a line. A line is quick, and a line can be guarded.','The Hearth\'s map is the red one. It winds. It passes the three villages that have always been missed. It is longer, and it is, I admit, kinder.','I am a straight-line man, Detective. I have been for sixty years. I am trying very hard to be a person who can look at a curve without wanting to correct it.']]],()=>{ k3('r_hal',1); coin(); if(k3('r_cin')) s2set(1); done_(n)(); }); return; }
  if(deepLeft('Captain Halbeak')>0) { deepTalk(n,done_(n),'Captain Halbeak'); return; }
  say('Captain Halbeak',['A good morning for building. I have discovered I like it.'],done_(n));
},()=>s2at('c22',0)&&!k3('r_hal')?'!':null);
npc3('cinder_a','Elder Cinder',{k:[-70,-62]},RED_PALS[2],'wizard',()=>AF(),n=>{
  if(s2at('c22',0)&&!k3('r_cin')){
    seq([['Elder Cinder',['The Hearth\'s map winds because the people it serves do. The three villages on the bend have been dark for a hundred years. Nobody wrote to them. Nobody was told.','Halbeak\'s line is quick. I will grant him that. A line can bring the first cart. It cannot bring the second, and the second is the one that matters.','I have been very reasonable for a very long time. I should like to be unreasonable on behalf of three villages.']]],()=>{ k3('r_cin',1); coin(); if(k3('r_hal')) s2set(1); done_(n)(); }); return; }
  if(deepLeft('Elder Cinder')>0) { deepTalk(n,done_(n),'Elder Cinder'); return; }
  say('Elder Cinder',['It is quiet. I find I am listening to it, in case it is a trick.'],done_(n));
},()=>s2at('c22',0)&&!k3('r_cin')?'!':null);
S2.prop({id:'council',k:[-65,-61],glyph:'stone',col:'#8a7a5a',when:()=>s2at('c22',1),mark:'!',use(){
  S2.persuade({who:'The Council Stone',intro:['A flat stone beside the Old Tree, with two chairs and a third. Halbeak and Cinder sit, and look at the maps, and at one another, and at the maps.','Behind them, on the roots, Ruddock leans on a spade he has not yet used, and pretends not to listen.'],
    rounds:[{q:'Who will keep the keys of the road?',opts:[
        {t:'"Both. One key, two locks. Nobody can open it alone."',p:2,req:()=>s2led('trust')>=3,say:['Halbeak laughs, once, helplessly. "A door with two locks. We invented it ourselves a hundred years ago, and then we put it in a wall."']},
        {t:'"Whoever lives on the road."',p:2,req:()=>!!k3('r_cin'),say:['Cinder looks at Halbeak. "The three villages." "The three villages." "I shall draw a chair."']},
        {t:'"The Crown, for now."',p:0,led:{crown:1},say:['Cinder\'s beak thins. "For now," she says, in the tone of a woman who has been told that before.']}]},
      {q:'Where does the curve go?',opts:[
        {t:'"Through the villages. The curve was always kinder."',p:2,led:{mercy:1},say:['Halbeak looks at the red line, and then, for the first time, at the third village on it. "...It is a good village. I have eaten its apples."']},
        {t:'"A straight road, with a spur to each village."',p:1,say:['Both elders think about this. "A compromise," says Halbeak. "A map is nothing but compromises," says Cinder.']},
        {t:'"Whatever the cartographer says."',p:0,say:['A silence, in which two elders realise they have both been outflanked by a surveyor.']}]},
      {q:'Who lights the first lantern?',opts:[
        {t:'"Poppy. She is neither."',p:2,say:['A pause. Then, from the roots, a very small voice: "...me?" Everyone has forgotten she was there. Everyone is delighted.']},
        {t:'"The two of you, together."',p:2,req:()=>!!s2fl('breeMet'),say:['They look at each other. The first lantern goes to Mallow\'s mother, in the end, who is a century old and sleeping in a chair. It is a good choice.']},
        {t:'"Whoever is nearest."',p:1,say:['Ruddock raises a hand, slowly. Nobody objects.']}]}],
    need:4,
    win:sc=>{ k3('road','shared'); coin(); s2led('trust',1); s2led('crown',1); s2led('ember',1); g.crumbs+=120; say('Captain Halbeak',['It is agreed. A road with two locks, a bend where the villages are, and a lantern at every mile. It will take a year to build.','I confess I am a little frightened. I am glad.'],()=>{ S2.finish('c22'); }); },
    lose:sc=>{ k3('road','split'); coin(); g.crumbs+=60; say('Elder Cinder',['It is half agreed. There will be a road. There will be two roads, a hand apart, for the first year, until they get used to the idea of one.','It is a start. It is nearly always a start.'],()=>{ S2.finish('c22'); }); }});
}});

/* the red-feather question: the grey stranger and the clerk come back, if you met them */
npc3('hands_back','Stranger in a Grey Cloak',{k:[-60,-56]},3,'hood',()=>AF()&&!!S3P().hands,n=>{
  const P=S3P();
  if(!k3('handsSaid')){ k3('handsSaid',1);
    say('Stranger in a Grey Cloak',[P.hands===1?'"You asked what we were afraid of. I do not have to tell you now. You were there."':'"You offered me a seat once. I have not forgotten. We have disbanded, the Hands. There is nothing left to guard."','"I am going to keep the Archive instead. Somebody should know where everything is. If the Hearth ever asks, I should like to say I do."','(They lay a grey scrap of cloth on the root of the Tree, folded square, and go.)'],()=>{ s2led('trust',1); coin(); done_(n)(); });
  } else say('Stranger in a Grey Cloak',['...'],done_(n));
},()=>(!k3('handsSaid')&&S3P().hands)?'!':null);
npc3('clerk_back','Clerk Whistle',{k:[-61,-60]},5,'bow',()=>AF()&&!!S3P().court,n=>{
  if(!k3('clerkSaid')){ k3('clerkSaid',1);
    say('Clerk Whistle',['"I have a new entry for the minutes. It is the first in a hundred years. It says: \'Sleepers woken. All present. Tea.\' It is, I think, the best minute I have ever taken."','"The Quiet Chair is going to meet in daylight from now on. We have opened a window. A clerk is allowed to enjoy a window."'],()=>{ s2led('truth',1); coin(); done_(n)(); });
  } else say('Clerk Whistle',['"Mind the ink."'],done_(n));
},()=>(!k3('clerkSaid')&&S3P().court)?'!':null);

S2.ch.c23={route:'both',theme:'both',title:'Green',sub:'It takes a long time. It takes a long time for good reasons.',
  intro:['The Burnt Wood is grey in the places where it was always going to be grey, and in the others it is thinking about it.','Poppy has found a trowel. She has also found the three bare patches where the Elders\' sleepers used to lie. She has decided, with her whole small face, that something should grow there.'],
  recap:'You planted three Hearthblooms in the Wood, and waited for them. They bloomed.',
  start(){ s2set(0); if(!g.inv.shovel){ addItem('shovel'); toast('Poppy lends you a shovel.',3000); } k3('plantAt',0); },
  obj(s){ return ['Plant <b>three Hearthblooms</b> in the bare patches around the Old Tree. ('+['p0','p1','p2'].filter(k=>k3(k)).length+'/3)','Wait for the plots to bloom (about half a day), and tell <b>Poppy</b>.','Speak with <b>Mallow</b> about the house, and <b>Poppy</b> about the Keeper\'s work.'][s]||''; }
};
const PLOTS=[[-69,-66],[-63,-66],[-66,-57]];
PLOTS.forEach((p,i)=>S2.prop({id:'plot_'+i,k:p,glyph:'box',col:'#4a3a2a',when:()=>s2at('c23',0)&&!k3('p'+i),mark:'!',use(){
  if(!g.inv.shovel){ say('',['You will want a shovel for this.']); return; }
  say('',['A bare patch of ash, grey and soft, with a ring of stones around it that Poppy has laid out. You scrape a shallow bed, and put in a Hearthbloom bulb that Poppy gave you for the purpose, and cover it with the warm ash.','"Say something to it," says Poppy, from nearby. "Mama says they like to be told."'],()=>{
    choose('The Hearthbloom bed','What do you tell it?',['"Grow."','"We are sorry. Please grow anyway."','"This is for the one who is sleeping."'],k=>{
      if(k===1) s2led('mercy',1); else if(k===2) s2led('kin',1); else s2led('truth',1);
      k3('p'+i,1); coin(); hudCache.obj=null; const n=['p0','p1','p2'].filter(x=>k3(x)).length; toast('Planted: '+n+'/3.',2400);
      if(n>=3){ k3('plantAt',s2now()); s2set(1); }
    },2);
  }); }}));
S2.prop({id:'bloom_check',k:[-66,-60],glyph:'star',col:'#ffb347',when:()=>s2at('c23',1),mark:()=>(s2now()-(k3('plantAt')||0)>=12)?'!':null,use(){
  const dt=s2now()-(k3('plantAt')||0);
  if(dt<12){ say('',['The beds are still grey. A single green hook is pushing through the ash at the middle one. ('+Math.max(1,Math.ceil(12-dt))+' hours to bloom, roughly.)']); return; }
  seq([['',['Overnight, or what felt like overnight, the beds have changed. Three clumps of Hearthbloom stand knee-high in the ash, each opening a single warm flower, the colour of a lit window.','They are not magic. They are only flowers that decided to be somewhere. The air around them is five degrees kinder.']]],()=>{ coin(); toast('The Hearthblooms are open. Tell Poppy.',3600); s2set(2); });
}});
npc3('poppy_a','Little Poppy',{k:[-64,-59]},3,null,()=>AF(),n=>{
  if(s2at('c23',2)&&!k3('poppyKeeper')){
    k3('poppyKeeper',1);
    seq([['Little Poppy',['(She is kneeling in the new bed, with her nose almost on a flower.)','"It smells like a Hearth. But a quiet one. The kind you do not have to carry anywhere."','"Is this what a Keeper does? Does she make a place that is warm and then step back?"']]],()=>{
      choose('Little Poppy','Poppy waits.',['"Yes. And she never gets thanked, because it worked."','"No. The Keeper stays. That is the whole job."','"There is no one answer. You will decide."'],k=>{
        let m; if(k===0){ m=['She sits back on her heels. "That is lonely."  "It can be." "I think I can do lonely. If there is a flower at the end."']; s2led('truth',1); }
        else if(k===1){ m=['"Stay," she says, trying it. "That is what Gordamom said." "Yes." "Then it\'s a family word."']; s2led('kin',2); }
        else { m=['"That is the grown-up answer," she says, severely. "I will have it, but I will not like it."','She smiles, suddenly, the whole of her face.']; s2led('mercy',1); }
        say('Little Poppy',m,()=>{ coin(); hudCache.obj=null; done_(n)(); });
      },2);
    }); return; }
  if(deepLeft('Little Poppy')>0){ deepTalk(n,done_(n),'Little Poppy'); return; }
  say('Little Poppy',['Everything is a bit more green than yesterday!'],done_(n));
},()=>(s2at('c23',2)&&!k3('poppyKeeper'))?'!':null);
npc3('mallow_a','Hermit Mallow',{k:[-62,-64]},RED_PALS[0],'hood',()=>AF(),n=>{
  if(s2at('c23',2)&&k3('poppyKeeper')&&!k3('mallowHouse')){
    seq([['Hermit Mallow',['I have been thinking about the house. The hermit\'s house, at the edge of the wood. Eighty years of kettle and one chair, and the table with a third place that nobody has sat at.','Bree says I should sell it. She says it with the gentle contempt of a woman who has slept through a century of my cooking.']]],()=>{
      choose('Hermit Mallow','He waits.',['"Keep it. Someone should be there for the next person."','"Sell it. You deserve a hearth with other people in it."','"Give it to Poppy, for when she is a Keeper."'],k=>{
        k3('mallowHouse',1+k); let m;
        if(k===0){ s2led('trust',1); m=['"Keep it," he says, slowly, "as an inn. A small one. For envoys, and lost ducks, and anyone with something to put on a table." He is starting to smile.']; }
        else if(k===1){ s2led('kin',1); m=['"Sell it," he says. "Move into the house at the edge of Emberwick, with my mother and a window." He closes his eyes. "I did not know I was allowed to want a window."']; }
        else { s2led('mercy',1); s2led('kin',1); m=['"For the Keeper." He nods several times. "The first Keeper of the Lantern Road will have a place to sleep. That is the best use I have had of anything."']; }
        say('Hermit Mallow',m.concat(['Little detective. I have been your friend for a very short while, and I think of you as the only person who has ever asked me what I wanted. Go and finish this. I will see you at the lighting.']),()=>{ coin(); hudCache.obj=null; S2.finish('c23'); done_(n)(); });
      },2);
    }); return; }
  if(deepLeft('Hermit Mallow')>0){ deepTalk(n,done_(n),'Hermit Mallow'); return; }
  say('Hermit Mallow',['It is a good day to be somebody\'s son.'],done_(n));
},()=>(s2at('c23',2)&&k3('poppyKeeper')&&!k3('mallowHouse'))?'!':null);

S2.ch.c24={route:'both',theme:'both',title:'The Lantern Road',sub:'The road is not finished. It is lit.',
  intro:['They light the first lantern at dusk, at the Old Tree, which has put out new leaves for the occasion and looks faintly embarrassed about it.','Every duck who could walk here is here. Some of them are not speaking to each other. They are standing near each other, which is, as it turns out, the first stage of the other thing.'],
  recap:'You lit the first lantern of the Lantern Road.',
  start(){ s2set(0); },
  obj(s){ return ['Say goodbye to the people who matter. Speak with at least <b>four</b> of them, around the <b>Old Tree</b> in the Burnt Wood (north-west of Kingsbill). ('+(k3('good')||0)+'/4)','Light the <b>first lantern</b> of the Lantern Road.'][s]||''; }
};
function goodbyeCount(){ return k3('good')||0; }
function goodbye(key,done_cb){ if(!k3('gb_'+key)){ k3('gb_'+key,1); k3('good',goodbyeCount()+1); toast('Spoken to: '+goodbyeCount()+'.',2200); if(goodbyeCount()>=4&&s2at('c24',0)) s2set(1); } done_cb(); }
const FEST=['Hermit Mallow','Little Poppy','Elder Cinder','Captain Halbeak','Warden Ruddock'];
npc3('ruddock_a','Warden Ruddock',{k:[-60,-60]},WARDEN_PAL,'helm',()=>AF(),n=>{
  if(s2at('c24')&&!k3('gb_rud')){
    seq([['Warden Ruddock',['I did something strange yesterday. I laid down the spear, and I went to see the third village on the bend. I walked all the way.','There is an old man there who whistles while he works. I asked what the tune was. He said he did not know. It has been in the family for a hundred years. It was my grandfather\'s.','I did not tell him. I let him whistle. I think that is what Tam meant. You do not give people the weight. You give them the tune.']]],()=>{ s2led('trust',1); s2led('ember',1); goodbye('rud',done_(n)); }); return; }
  if(deepLeft('Warden Ruddock')>0){ deepTalk(n,done_(n),'Warden Ruddock'); return; }
  say('Warden Ruddock',['The watch is posted. Nobody is watching. It is lovely.'],done_(n));
},()=>(s2at('c24')&&!k3('gb_rud'))?'!':null);
S2.npc(Object.assign({},{id:'eider_a',name:'King Eider',pal:S3PAL.eider,head:'royal',still:true,k:[-65,-56],when:()=>AF()&&eiderLives(),mark:()=>(s2at('c24')&&!k3('gb_eid'))?'!':null,talk(n,done){
  if(s2at('c24')&&!k3('gb_eid')){
    seq([['King Eider',[ENDING()==='keeper'?'I have sat at your hermit\'s table. I have eaten his soup. It is very bad. It is the best soup I have ever had.':'I am told I am to be a retired king. It seems an odd thing to be, like a retired tide.','You asked me, once, what my word was. I never said. It was \'stay\'. I thought it was a command. I think now it was a request. I was asking someone to stay with me. I did not know who.','Thank you for staying with me. I am sorry that it took a century.']]],()=>{ s2led('crown',1); s2led('mercy',1); goodbye('eid',done); }); return; }
  say('King Eider',['I find I like being a guest. Nobody has ever asked me to help with the washing up.'],done);
}}));
/* farewells: each of them gets one last word with you before the lantern is lit */
{
  const FW={
   halbeak:['Captain Halbeak',['I have been a wall all my life. It was a good wall, and I am not ashamed of it.','I should like to be a gate now. A gate is only a wall that has decided to trust somebody. It is much more work, and I find I am looking forward to the work.'],{crown:1,trust:1}],
   cinder_a:['Elder Cinder',['I used to think peace was the absence of risk. It is not. It is the presence of a kettle, and someone who will come when it whistles.','Thank you for letting me learn that late. I would rather learn it late than never. It is a very small difference, and I find I am holding on to it with both wings.'],{ember:1,mercy:1}],
   poppy_a:['Little Poppy',['Are you going away? Everyone goes away at the end of things.','Will you come back when the flowers are tall? Mama says nobody should promise that. I think you can.'],null],
   mallow_a:['Hermit Mallow',['I thought the hermit was who I was. It was only who I had to be, for a while.','Thank you for the difference. I shall keep the kettle on, in either house.'],{trust:1,kin:1}]
  };
  for(const id in FW){
    const d=S2.npcs.find(x=>x.id===id), _t=d.talk, _m=d.mark;
    d.talk=function(n,done){
      if(!(s2at('c24',0)&&!k3('gb_'+id))) return _t.call(this,n,done);
      const [who,lines,led]=FW[id];
      say(who,lines,()=>{
        if(id==='poppy_a'){ choose('Little Poppy','Poppy waits.',['"I promise."','"I will try, truly."'],k=>{ if(k===0) s2led('kin',2); else s2led('truth',1); say('Little Poppy',[k===0?'Then I shall water them every day. Especially when it rains.':'That is a better promise. It has room in it.'],()=>goodbye(id,done)); },1); }
        else { for(const key in led) s2led(key,led[key]); coin(); goodbye(id,done); }
      });
    };
    d.mark=function(){ return (s2at('c24',0)&&!k3('gb_'+id))?'!':(typeof _m==='function'?_m():_m); };
  }
}
S2.prop({id:'first_lantern',k:[-66,-61],glyph:'lantern',col:'#ffd166',when:()=>s2at('c24',1),mark:'!',use(){
  const eiderPart=eiderLives()?'King Eider and the Elder of the Hearth hold the lantern between them, and look at each other over the top of it, and do not say anything, and it is a great deal.':'Elder Cinder holds the lantern, and Captain Halbeak holds the pole, and between them, on the roots of the Old Tree, there is an empty place where a king would have stood.';
  seq([['',['You lift the lantern. It is warm. It leans, as it always has, a little to the north-west, and then, for the first time, it does not. It stands straight up.','A single light. A single road. '+eiderPart,'Poppy lights the wick from the Hearth coal. Her hand shakes. Mallow puts his over hers. Bree puts hers over his. Three hands and one flame.','Somewhere under the roots, a note drops by half a step, and rises, and holds. It is not four notes. It is not five. It is a song.']]],()=>{
    coin(); s2led('trust',1); S2.finish('c24');
    const kind=ENDING();
    epiCard('EPILOGUE',({wake:'The Road Was Lit',door:'The Door Stood Open',keeper:'The Table Held'})[kind]||'The Road Was Lit','The Lantern Road',[
      kind==='keeper'?'The Keeper\'s Table became a kind of institution, which would have mortified Mallow. Envoys arrived. Treaties did not. Tea did.':'The Lantern Road was finished in three years, and not quite finished for another thirty.',
      'The three villages on the bend got their post. Ruddock carried it on foot for the first six months, and is said to have whistled.',
      'Orla became the Warden of Names. She keeps the Hall in the north. A brick in it reads: "Alder, who held on." Under it, in a small hand, is a second line: "We held on to you."',
      'You, little detective, were a duck who found a mystery, and a mystery that found its feathers. You asked the question, and then you stayed for the answer.',
      'The lantern is lit. Nobody has been told to put it out.'],'both',()=>{ q_end3(); });
  });
}});
function q_end3(){ const q=s2(); q.ch='end'; hudCache.obj=null; toast('The story is told. The world goes on.',5200); }
/* every aftermath NPC must remain available once the chapter is over */
{
  const _so=storyObjective;
  storyObjective=function(){
    const q=g.story&&g.story.s2;
    if(q&&q.ch==='end'&&q.ending&&q.ending!=='stay'&&q.done&&q.done.c24){ return 'The Lantern Road is lit. Visit the Old Tree, the Hall of Names in the north, and the Keeper\'s table. (Thank you for playing.)'; }
    return _so();
  };
  const _je=journalExtra;
  journalExtra=function(sec,line){
    _je(sec,line);
    const q=g.story&&g.story.s2; if(!q) return;
    if(q.keeper||k3('rec')!==undefined){ sec('The Keeper\'s Road'); if(q.keeper) line('You took the third road, and sat down at Mallow\'s table.','jdim'); if(k3('tbl')) line('The table: '+k3('tbl')+'.','jdim'); }
    if(k3('road')) { sec('After the Door'); line('The Lantern Road: '+(k3('road')==='shared'?'one road, two keys.':'two roads, a hand apart.'),'jdim'); if(k3('mallowHouse')) line('Mallow\'s house: '+['kept as an inn','sold for a window','given to Poppy'][k3('mallowHouse')-1]+'.','jdim'); }
  };
}
