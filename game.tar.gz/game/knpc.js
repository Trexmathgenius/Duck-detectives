'use strict';
/* ===== Duck Kingdom: citizens, chests, signs and secrets ===== */
const RED_PAL=[{body:'#c0392b',wing:'#962d22',bill:'#ff9d2e'},{body:'#d9503f',wing:'#a83a2d',bill:'#e6c441'}];
let kNpcs=null;
function spearDeco(c,n){ const x=n.x+(n.dir==='left'?-11:11), y=n.y; rect(c,x-1,y-40,2,40,'#8a5a2b'); c.fillStyle='#c3ccd6'; c.beginPath(); c.moveTo(x-3,y-40); c.lineTo(x,y-50); c.lineTo(x+3,y-40); c.fill(); }
function K(name,lx,ly,pal,head,neck,lines,o){
  const wx=KX+lx, wy=KY+ly;
  return Object.assign({special:'kingdom',kn:true,idx:900+(kNpcs?kNpcs.length:0),name,pal:typeof pal==='number'?PALS[pal]:pal,acc:{head,neck},persona:0,owl:true,
    x:(wx+0.5)*TS,y:(wy+0.95)*TS,hx:(wx+0.5)*TS,hy:(wy+0.95)*TS,dir:'down',moving:false,t:Math.random()*2,phase:0,talking:false,lines,cycle:0},o||{});
}
function kNpcList(){
  if(kNpcs) return kNpcs;
  kNpcs=[];
  const A=(...a)=>kNpcs.push(K(...a));
  const guard=(n,lx,ly,l,dir)=>A(n,lx,ly,2,'helm',null,l,{still:true,dir:dir||'down',deco:spearDeco});
  guard('Castle Guard Drake',-3,10,[['Halt. Not really. Welcome to Castle Quackenhold.','The gate is closed to all visitors. King\'s orders. Do not ask me why. I do not know why.'],['Closed. Still closed. Come back when the kingdom is ready.']]);
  guard('Castle Guard Teal',3,10,[['I have stood here for forty days. My feet have opinions.','The king has not shown himself in weeks. We bring meals to the door. They are taken in by something that is not a hand.'],['Do not stare at the windows. Some nights they are lit blue.']]);
  guard('Gate Guard Pintail',-5,40,[['Welcome to Kingsbill, traveler! Mind the Royal Fountain. It bites.','(It does not bite. But it soaks the unwary.)']],{});
  guard('Gate Guard Gadwall',5,40,[['Come from Puddlewick? A long waddle! Go on in. Market is west, training yard east, castle straight ahead.']]);
  guard('Guard Wigeon',-56,-2,[['West Gate. Nothing but hills, old stones and an old watchtower beyond. And ghosts, they say.']],{dir:'right'});
  guard('Guard Shoveler',56,-2,[['East Gate. Farms and the lake out there. Peaceful. Mostly.']],{dir:'left'});
  A('Captain Halbeak',-8,13,2,'helm','scarf',[['I am Captain Halbeak. A century ago my great-great-great-grandfather stood on these very walls when the red army came.','He held the south tower with twelve ducks and a broom. The broom is in the barracks. We do not mention the broom.'],['The king was a warlock then. King Eider the First, they say, though he is the only one. He ended the siege with one word.']]);
  A('Herald Fanfare',-3,30,5,'royal','bowtie',[['Hear ye! Hear ye! The Castle is closed! Hear ye further: it is closed!'],['Anything else? No? Then hear ye, enjoy the kingdom!']]);
  A('Mother Mallow',-37,29,4,null,'scarf',[['Pears! Plums! Perfectly priced. Eat first, ask later.','The best pears come from the orchard south of the walls. Mind the tree that hums.']],{still:true});
  A('Barnaby Bill',-31,35,6,'cap',null,[['Tools! Rope! Rope that looks like tools! Take a look.','Pick up a lantern if you go into the Burnt Wood. Not that I would go. I would not go.']],{still:true});
  A('Quillfeather',-19,29,1,null,'bowtie',[['Scrolls and maps. A map of the kingdom, you ask? Look at your own. It draws itself, I see. Show-off.','The best secrets are not on a map. They are under the standing stones in the north.']],{still:true});
  A('Old Crumb',-13,35,0,'cap',null,[['Bread! Day-old, century-old, whichever. A duck cannot be too choosy.','They say the first loaf in Mallardia was baked the day the red ducks left. A hundred years ago. It is still in the temple. It is a rock now.']],{still:true});
  A('Lyric Lark',12,20,5,'bow',null,[['Gather round! The Ballad of the Red Rebellion, in nine hundred verses.','"A duck was born in crimson dress, in Mallardia\'s green. The crown said, \'Red is bad, not seen\'..." Ah, I forget the rest. I always do.'],['There is a tune the old ducks hum when they think no one hears it. Do you know it? Neither do I. It makes my feathers rise.']]);
  A('Archivist Penna',40,-20,3,'wizard','scarf',[['I keep the records of the Royal Library. Would you like to hear about the Red Edict?','A hundred years ago, red feathers were thought unlucky. A law cast out every duck who bore them. Families split. Villages emptied.','Among the cast out: a young drake named Gordamom. Clever. Angry. A fine tactician, by every account.'],['He gathered the outcasts in the northern hills. A hungry, bitter army, sewn together by one cause. And then came the siege.','The records stop there. A page is torn out. By who? That is the question I think about at night.']]);
  A('Sister Dove',-44,-20,0,'hood','scarf',[['Welcome to the Temple of Feathers. We bless every feather. Even the red ones. Especially the red ones, these days.','The church once said red ducks were cursed. We were wrong. We say so now. A century late, but it is said.'],['Gordamom\'s army was cruel in the end. But it began with cruelty done to them. Both things are true.']]);
  A('Pip Ember',30,-19,6,'wizard',null,[['I am the king\'s apprentice. Well. I was. He has not called for me since the new moon.','The tower crystal hums when someone says Gordamom. Try it. Do not try it. I mean it.'],['I swept up the stairs yesterday. Behind the door at the top, someone was whispering a name. Not the king\'s voice. Older.']]);
  A('Tuft',6,-20,4,'bow',null,[['We are playing hide and seek. Do not look in the maze. I am in the maze.','(The chest in the middle is real. Hubert says so.)']],{});
  A('Tiny',10,-18,0,'cap',null,[['The big hedge is a maze. You go in the bottom and it gets confusing. Keep turning left. Or right. Or both.']]);
  A('Gardener Hubert',-9,-24,3,'cap','scarf',[['This is my maze. Eighty years I have trimmed it. I got lost in it twice and found a chest once.','Enter at the bottom. In the middle there is a chest. I have never opened it. It is not for me. You may.']],{still:true});
  A('Farmer Oats',72,24,4,'hat',null,[['Wheat as far as you can see! That is not far, but it is nice wheat.','Strange thing: my crows will not fly toward the north-west woods. Not for corn. Not for bread. They shake their heads and go the other way.']]);
  A('Millie the Miller',80,39,5,'cap','scarf',[['The sails turn all day. In the night they turn on their own, I swear. Slowly. Toward the north-west.'],['The wind blows from the Burnt Wood sometimes. It smells like smoke, a hundred years old.']]);
  A('Skipper Reed',65,-23,6,'cap',null,[['Swan Lake! Fish, swans and the odd ghost fish. I stand here, I fish, I sing.','There is a little island in the middle. A chest on it, they say. I cannot swim. Ducks that cannot swim are called Skipper Reed.']],{still:true,dir:'right'});
  A('Hermit Mallow',72,-55,RED_PAL[0],'hood',null,[['A visitor! Oh, how long since I had a visitor.','Yes, I am red. The red is right under the soot. Do not be afraid. Most of us were never soldiers.'],['I was a child when they cast us out. I did not follow Gordamom. I came here, and I have been tending flowers since.','I still hear him sometimes. In the forest. Not the army. Just a whisper that says, "I remember". Go carefully near the Burnt Wood.']]);
  A('Warden Thistle',-80,12,3,'helm','scarf',[['This is the Siege Field. A hundred years old. The ground still will not grow grass in places.','The graves are the red army\'s, mostly. Soldiers who were someone\'s child. The king had them buried. He was not heartless.'],['Beyond the north-west ridge is the Burnt Wood. That is where the king\'s spell changed Gordamom. Do not go at night. The old tree has eyes.']]);
  A('Old Rue',-71,35,0,'hood',null,[['I tend these graves. Nobody asked me to. Somebody has to.','When the wind is right, they all hum the same tune. A lullaby, I think.']],{still:true});
  A('Scout Wick',-86,-35,2,'cap',null,[['I scout the old watchtower for the king. It is quiet here. Too quiet.','There is a chest in the ruined tower. Nobody takes it. Nobody dares. I am too polite.']]);
  /* roadside travellers */
  const r1=roadX(-250), r2=roadX(-562), r3=roadX(-790);
  A('Wanda Wanderer',r1+8-KX,-250+0-KY,6,'hat','scarf',[['Mallard\'s Rest! Sit by the fire. Share the bread. Or don\'t. I won\'t make you.','You are going north to the kingdom? Mind the river. And mind the bridge-troll. He charges one compliment.']],{road:true});
  A('Toll-duck Boris',r2+3-KX,-560-KY,4,'cap','bowtie',[['Toll bridge. The fee is one compliment. Go on.','... Very nice. Pass, friend.']],{road:true,still:true});
  A('Brother Tuck',r3-6-KX,-790+1-KY,0,'hood',null,[['Pilgrim\'s Rest. We walk to the kingdom for the Feather Festival. The road is long. The road is long.','A mysterious stranger passed here recently. Spoke of a tree that remembers. He did not stay for tea.']],{road:true});
  return kNpcs;
}
function extraNpcs(list){
  if(g.scene==='world'){
    const px=g.px/TS, py=g.py/TS;
    for(const n of kNpcList()){
      if(Math.abs(n.x/TS-px)<40&&Math.abs(n.y/TS-py)<30) list.push(n);
    }
    strangerNpcs(list);
  }
}
function specialMark(n){ if(n.special==='stranger') return strangerMark(n); return null; }
function specialTalk(n){
  if(n.special==='stranger'){ strangerTalk(n); return; }
  n.dir=OPP[g.dir]; n.moving=false; n.talking=true;
  g.story.met=g.story.met||{}; g.story.met[n.name]=1;
  const done=()=>{ n.talking=false; n.t=1; };
  const pages=n.lines[n.cycle%n.lines.length]; n.cycle++;
  say(n.name,pages,done);
}

/* ---- chests, discoveries, signs ---- */
function chestOpen(x,y){ return !!(g.story.chests&&g.story.chests[x+','+y]); }
const CHEST_LOOT={'-10,-32':['crown',30],'-80,-30':['lantern',25],'80,-25':['feather',20],'63,-66':['key',20],'-73,34':['pebble',15]};
function openChest(tx,ty){
  g.story.chests=g.story.chests||{};
  if(chestOpen(tx,ty)){ say('',['The chest is empty. A single feather floats up and drifts away.']); return; }
  g.story.chests[tx+','+ty]=1;
  const lx=tx-KX, ly=ty-KY;
  let loot=CHEST_LOOT[lx+','+ly]||['pebble',10];
  if(lx===1&&ly===-33) loot=CHEST_LOOT['-10,-32'];
  g.crumbs+=loot[1]; addItem(loot[0]); coin();
  say('',['The lid creaks open.','Inside: '+loot[1]+' crumbs and a '+ITEMS[loot[0]].name+'.']);
  kDiscover('chest'+lx+','+ly,null,0);
}
function kDiscover(id,msg,reward){
  g.story.disc=g.story.disc||{};
  if(g.story.disc[id]) return false;
  g.story.disc[id]=1;
  if(reward){ g.crumbs+=reward; coin(); }
  if(msg) toast(msg,3200);
  return true;
}
function kStatue(tx,ty){
  const lx=tx-KX, ly=ty-KY;
  if(Math.abs(lx)===14&&ly===12) say('',['A golden duck in a regal pose. The plaque reads: "KING EIDER THE WISE. He who saved Mallardia with a single word."','Below, in smaller letters: "And paid for it."']);
  else say('',['A weathered duck carved in pale stone, wings spread over the garden. The plaque is chipped: "In memory of those who were lost on both sides."']);
}
const GRAVES=['Here lies a soldier. The stone is marked only: RED.','"Sorrel, aged 17. She wanted to be a baker."','"Unknown. He carried a flag bigger than himself."','Here lies a drummer. The stone is carved with a tiny drum.','"We were hungry. We were angry. We were ducks."','"For the one who was never invited back."'];
function kingdomInteract(t,tx,ty){
  const lx=tx-KX, ly=ty-KY;
  switch(t){
    case KPORT:
      g.story.castleSeen=1;
      say('Castle Gate',['The great gate of Castle Quackenhold is sealed. A heavy portcullis, gold-trimmed, locked from the inside.','A notice nailed to the post reads: "CLOSED BY ORDER OF HIS MAJESTY KING EIDER. NO VISITORS UNTIL FURTHER NOTICE."','Behind the bars the corridor is dark. But from deep inside, faint and steady, you hear chanting.']);
      break;
    case KWALL: case KSTONE: say('',[pick(['Cold, ancient stone. Several hundred ducks have leaned here and sighed.','The mortar is crumbly in places. Somebody has scratched "DAISY WAS HERE" very, very high up.','You rest a wing on the stone. It hums, softly. Not like the dark trees. Warmer.'])]); break;
    case KCWIN: say('',[pick(['A narrow castle window. Something blue flickers behind it.','You stand on tiptoes. A shadow in the glass looks right back. It is your shadow. Probably.'])]); break;
    case KTORCH: say('',['A bright royal torch. It never burns down. The guards say that is the one spell the king still lets them keep.']); break;
    case KFOUNT: wish(); break;
    case KFLAG:
      if(lx===-70&&ly===25) { if(kDiscover('memorial','Secret found: the red memorial',4)) {} say('',['A faded banner, deep red, tied to a post at the field\'s edge. Someone has stitched on it, very carefully: "FOR THE ONES WHO WERE NOT LISTENED TO."']); }
      else say('',[pick(['A royal banner: a golden duck on blue. It flaps proudly.','The banner snaps in the wind. The embroidered duck seems to wink.'])]);
      break;
    case KHEDGE: say('',[pick(['Tightly trimmed. Eighty years of gardening in one wall of leaves.','A faint scuttle inside the hedge. A beetle with a map.','You peer through the leaves. Another hedge. Naturally.'])]); break;
    case KCHEST: openChest(tx,ty); break;
    case KGRAVE: kDiscover('graves','Secret found: the red graves',4); say('',[GRAVES[Math.floor(hash(tx,ty,5800)*GRAVES.length)]]); break;
    case KTENT: kDiscover('tent','Secret found: a burned tent',3); say('',['A scorched red tent, half collapsed. Inside: a rusty helmet, a stitched doll, and a letter. The ink has run, but you can read: "Mama, we are winning, I think."']); break;
    case KRUIN: say('',[pick(['Broken stone and old iron. A siege ladder, snapped in two.','A shattered piece of battlement. A tiny sprout grows from it. Life finds a way.','Rubble. Beneath it, the shape of an old red banner.'])]); break;
    case KCHAR:
      if(lx===-66&&ly===-64){
        const first=kDiscover('gordamom',null,12);
        g.story.gordamom=1;
        say('The Old Tree',first?['A blackened tree stands alone in a ring of ash. Its bark is split and scorched. It looks nothing like the others.','You step close. The ground is warm. Not hot. Warm, like a sleeping creature.','Somewhere deep in the wood, something hums a single low note. The tree does not move. And yet you are sure it listens.','Burned to the ground, they said. But the roots remain.','You have a strong feeling that you are not the first to visit this tree. And that it knows your name.']:['The ash around the tree is faintly warm. Two knots in the bark seem to follow you.','Gordamom? you whisper. The tree does not answer. The wind stops for a moment. Then it starts again.']);
      }
      else say('',[pick(['A charred trunk, black and brittle. It crumbles at your touch.','A burned tree. Even the ash feels old.','The bark is scorched in the shape of claws. Or maybe flame.'])]);
      break;
    case KPOST: kSign(tx,ty); break;
    case KMILL: say('',['A big windmill, its sails turning slowly. Inside, the grindstones are still. Somebody is baking bread upstairs.']); break;
    case KSTONES: kDiscover('stones','Secret found: the Warlock\'s Stones',5); say('',[pick(['A tall standing stone etched with runes. They glow faintly blue, a gentle, steady light.','The rune-light pulses in time with your heartbeat. Soft, calm. The opposite of the dark trees.'])]); break;
    case KCRYSTAL:
      if(lx===0&&ly===-66){ kDiscover('crystal','Secret found: the warding crystal',8); say('Warding Crystal',['A crystal as big as a duck, humming with a warm blue light. Runes ring the base.','You can feel it pushing against something far away. Something in the north-west. Something that pushes back.','King Eider\'s ward. It holds the Burnt Wood still. For now.']); }
      else say('',['The tower crystal throbs softly, like a heart.']);
      break;
    case KSCARE: say('',['A scarecrow in a blue coat. Its hat is on crooked. It has a small, determined smile.']); break;
    case KBOAT: kDiscover('boat','Secret found: the old boat',2); say('',['A little rowing boat, moored at the dock. It leaks. Ducks do not mind. Swim out to the island instead.']); break;
    case KMSTALL: say('',[pick(['A stall of pears, plums and exactly one cabbage. The vendor refuses to explain.','Scrolls, charms, and a jar labelled "SUNSHINE (OPENED)". You decide not to ask.','Beautiful rugs. Every single one is covered in tiny ducks.'])]); break;
    case KDUMMY: quack(); say('',[pick(['You peck the practice dummy. Thwack. It does not mind.','The training dummy is stuffed with straw and old grievances.'])]); break;
    case KRACK: say('',['Spears, swords and one very large fork. The fork is for "emergencies".']); break;
    case KHDOOR: {
      const b=kBuilding(lx,ly);
      if(b&&b.type==='temple') say('',['The great temple doors are closed. A sign: "Blessing in progress. Please quack quietly."']);
      else if(b&&b.type==='library') say('',['The library doors are shut. A note: "Closed for inventory. Nobody has found the Red Edict. We are very sorry."']);
      else if(b&&b.type==='barracks') say('',['The barracks door is bolted. From inside: snoring. Possibly sharpening.']);
      else if(b&&b.type==='barn') say('',['The barn is locked. Inside, something moos. It is not a cow.']);
      else if(b&&b.type==='cottage') say('',['A tiny cottage, covered in flowers. The door is shut, but the chimney smokes. Someone is home.']);
      else say('',[pick(['Nobody answers. A cat in the window pretends not to see you.','A cheerful note: "Gone to the market. Back for tea."','The door is locked. You hear someone humming. Not the dark-tree hum. A lullaby.'])]);
      break; }
    case KHWALL: case KHWIN: say('',[pick(['Whitewashed walls and window boxes. A very pleasant house.','Through the window: a table laid for tea. Nobody sits there.'])]); break;
  }
}
function kSign(tx,ty){
  if(tx===99&&ty===-12){ g.story.northSign=1; say('North Road',['NORTH ROAD  >>  Duck Kingdom of Mallardia.','Below, in neat letters: "About three days\' waddle. Bring bread. Mind the river."']); return; }
  const lx=tx-KX, ly=ty-KY;
  if(Math.abs(ty+250)<=4) say('Wooden Sign',['MALLARD\'S REST. Benches, a fire, free hot water. Wolves welcome to beg, not to bite.']);
  else if(Math.abs(ty+790)<=6) say('Wooden Sign',['PILGRIM\'S REST. The kingdom is just ahead. Wash your feet. Straighten your feathers.']);
  else { const d=Math.max(0,ty-(KY+46)); say('Milestone',['MALLARDIA  -  '+d+' waddles north.',d>600?'Keep going. The road is long.':d>250?'More than halfway. Keep your head up.':'Almost there. You can smell the kingdom.']); }
}
function journalExtra(sec,line){
  const ev=Object.keys(g.ev).length;
  sec('Village events');
  line('Events attended: '+ev+'  (see the calendar on any notice board)');
  if(g.story.ghostHeard||g.story.kingdomFound||g.story.met){
    sec('The Duck Kingdom');
    if(g.story.ghostHeard) line('The stranger\'s tale: Gordamom, a red duck cast out a century ago, laid siege to the Duck Kingdom. The warlock king turned him into a tree and burned it. Some say he still lurks in the forest.');
    if(g.story.kingdomFound) line('Mallardia found. The castle is sealed by order of King Eider. Why?');
    const d=g.story.disc?Object.keys(g.story.disc).length:0, m=g.story.met?Object.keys(g.story.met).length:0;
    line('Secrets and chests found: '+d+'   Kingdom folk met: '+m);
  }
}
