/* ===== PRESENTATION (v1.25) =====
   Faces, atmosphere, and weight for the moments that need it.
   - a portrait of whoever is speaking, in their own colours and hat, beside the text
   - drifting embers, dust, ash and fireflies in the story's rooms, and    - a letterbox that closes in on the scenes the writing means most (readmission, atonement, endings, the first lesson)
   - the music follows cut-scenes, and the weighty scenes get a stinger
   Wrapped in a function; adds D10.cinema, D10.portrait. */
(function(){
'use strict';
const D10=window.D10=window.D10||{};
const stage=document.getElementById('stage');

/* ---------------- portraits ---------------- */
const dlg=document.getElementById('dialog');
const port=document.createElement('canvas'); port.width=84; port.height=84; port.className='dport'; port.hidden=true; dlg.appendChild(port);
const pc=port.getContext('2d');
const NOT_PEOPLE=/^(cast|paused|settings|task\b|lesson|notice|sign|journal|menu|you|narrator|bench|wish|the (king's )?(door|gate|map|board))/i;
const OVERRIDE={
  'Hermit Mallow':{pal:{body:'#9aa4ad',wing:'#7d8791',bill:'#e6c441'},head:'hood'},
  'Little Poppy':{pal:{body:'#fff1a8',wing:'#e8d27a',bill:'#ff9d2e'},head:null,small:true},
  'Thread-Mother Tansy':{pal:{body:'#e9b7c8',wing:'#c993a8',bill:'#ff9d2e'},head:'hood'},
  'Old Rue':{pal:{body:'#9aa4ad',wing:'#7d8791',bill:'#e6c441'},head:'hood'}
};
const hashN=s=>{ let h=0; for(const ch of String(s)) h=(h*31+ch.charCodeAt(0))|0; return Math.abs(h); };
function lookup(name){
  if(OVERRIDE[name]) return OVERRIDE[name];
  try{
    for(const n of (g.npcs||[])) if(n.name===name&&n.pal) return {pal:n.pal,head:n.acc&&n.acc.head};
    if(typeof SX!=='undefined'&&SX.S){ for(const n of SX.S.npcs) if(n.name===name&&n.pal) return {pal:n.pal,head:n.acc&&n.acc.head}; for(const n of SX.S.guards) if(n.name===name) return {pal:n.pal,head:n.head}; }
  }catch(e){}
  const h=hashN(name);
  if(/Mistress|Elder|Archivist|Sorrel|Vesper|Cinder|Pyre|Keeper/i.test(name)) return {pal:RED_PALS[h%RED_PALS.length],head:'wizard'};
  if(/Warden|Captain|Guard|Proctor|Porter|Halbeak|Ruddock|Sergeant/i.test(name)) return {pal:{body:'#b5322a',wing:'#8a2620',bill:'#ff9d2e'},head:'helm'};
  if(/King|Queen|Royal|Eider/i.test(name)) return {pal:PALS[0],head:'royal'};
  if(/Hermit|Old |Mother|Father|Grandd/i.test(name)) return {pal:PALS[2],head:'hood'};
  if(/\s/.test(name)||/^[A-Z][a-z]+$/.test(name)) return {pal:PALS[h%PALS.length],head:null};
  return null;
}
let lastName=null;
function drawPortrait(name){
  const L=(name&&name.length<30&&!NOT_PEOPLE.test(name))?lookup(name):null;
  if(!L){ port.hidden=true; return; }
  port.hidden=false;
  pc.setTransform(1,0,0,1,0,0); pc.clearRect(0,0,84,84);
  const gr=pc.createLinearGradient(0,0,0,84); gr.addColorStop(0,'#2a463a'); gr.addColorStop(1,'#14231d'); pc.fillStyle=gr; pc.fillRect(0,0,84,84);
  pc.imageSmoothingEnabled=false;
  pc.save(); const sc=L.small?3.0:3.5; pc.translate(42,50+(L.small?10:0)); pc.scale(sc,sc);
  try{ drawDuck(pc,0,16,'down',0,false,L.pal,{head:L.head||null,neck:null}); }catch(e){ console.warn('portrait',e); }
  pc.restore();
}
D10.portrait=drawPortrait;
{
  const _uh=updateHud;
  updateHud=function(){
    _uh();
    const nm=dlg.hidden?'':(document.getElementById('dWho').textContent||'');
    if(nm!==lastName){ lastName=nm; drawPortrait(nm); }
  };
}

/* ---------------- ambience in the story's rooms ---------------- */
const SEEDS=[]; for(let i=0;i<40;i++){ const h=hashN('p'+i); SEEDS.push({x:(h%997)/997,y:((h>>3)%991)/991,s:0.4+((h>>5)%100)/160,p:((h>>7)%628)/100}); }
function ambient(c,W,H,time,kind,n){
  c.save(); c.setTransform(1,0,0,1,0,0);
  for(let i=0;i<n;i++){
    const q=SEEDS[i%SEEDS.length];
    if(kind==='ember'){
      const t=(time*0.07*q.s+q.y)%1, x=((q.x+Math.sin(time*0.6+q.p)*0.02)%1)*W, y=H*(1-t);
      c.globalAlpha=(1-t)*(0.5+0.4*Math.sin(time*9+q.p)); c.fillStyle=t<0.5?'#ffb347':'#ff6a3a'; c.fillRect(x,y,2,2);
    } else if(kind==='ash'){
      const t=(time*0.03*q.s+q.y)%1, x=((q.x-t*0.1+1)%1)*W, y=H*t;
      c.globalAlpha=0.35*(0.4+q.s*0.5); c.fillStyle='#cfc8c0'; c.fillRect(x,y,2,2);
    } else if(kind==='mote'){
      const t=(time*0.015*q.s+q.y)%1, x=((q.x+Math.sin(time*0.3+q.p)*0.03)%1)*W, y=H*(1-t*0.6)-H*0.1;
      c.globalAlpha=0.22+0.15*Math.sin(time*1.4+q.p); c.fillStyle='#ffe9b0'; c.beginPath(); c.arc(x,y,1.6,0,6.283); c.fill();
    } else if(kind==='fly'){
      const x=((q.x+Math.sin(time*0.25*q.s+q.p)*0.08)%1)*W, y=((q.y*0.7+0.15+Math.cos(time*0.31*q.s+q.p)*0.05))*H;
      const a=0.5+0.5*Math.sin(time*2.1+q.p*3); c.globalAlpha=a*0.85; c.fillStyle='#d8ff7a'; c.beginPath(); c.arc(x,y,2,0,6.283); c.fill();
      c.globalAlpha=a*0.25; c.beginPath(); c.arc(x,y,7,0,6.283); c.fill();
    }
  }
  c.restore();
}
function vignette(c,W,H,strength){
  c.save(); c.setTransform(1,0,0,1,0,0);
  const gr=c.createRadialGradient(W/2,H/2,Math.min(W,H)*0.35,W/2,H/2,Math.max(W,H)*0.75);
  gr.addColorStop(0,'rgba(0,0,0,0)'); gr.addColorStop(1,'rgba(0,0,10,'+strength+')'); c.fillStyle=gr; c.fillRect(0,0,W,H); c.restore();
}
{
  const _sx=sxDraw;
  sxDraw=function(c,W,H,kd,time){
    _sx(c,W,H,kd,time);
    try{
      const S=SX.S; if(!S) return;
      const th=S.def.theme||'stone';
      const kind=({hearth:'ember',stone:'ember',crypt:'ash',ash:'ash',archive:'mote',tower:'mote',castle:'mote',grove:'fly',wood:'fly'})[th];
      if(kind) ambient(c,W,H,time,kind,kind==='fly'?16:26);
      vignette(c,W,H,S.def.dark?0.25:0.38);
    }catch(e){}
  };
}
/* ---------------- the letterbox ---------------- */
const bars=document.createElement('div'); bars.className='cinebars'; bars.innerHTML='<i></i><i></i>'; stage.appendChild(bars);
let cineOn=false, cineT=0, calm=0;
D10.cinema=function(on){
  cineOn=!!on; stage.classList.toggle('cine',cineOn); cineT=performance.now(); calm=0;
};
setInterval(()=>{
  if(!cineOn) return;
  if(performance.now()-cineT<5000) return;
  if(g.mode==='play'){ calm++; if(calm>=3) D10.cinema(false); } else calm=0;
},1000);
/* function declarations are globals, so assigning through a bare name is what the rest of the game does */
{
  const w=(get,set,sting,mood)=>{ try{ const f=get(); if(typeof f!=='function') return; set(function(){ D10.cinema(true); if(sting) D10.sting(sting); if(mood) D10.setMood(mood,40); return f.apply(this,arguments); }); }catch(e){ console.warn('weighty',e); } };
  w(()=>readmitScene,f=>{ readmitScene=f; },'reveal','tender');
  w(()=>atone,f=>{ atone=f; },'tender','tender');
  w(()=>theoryScene,f=>{ theoryScene=f; },'tender','academy');
  w(()=>epiCard,f=>{ epiCard=f; },'reveal','tender');
}
})();
