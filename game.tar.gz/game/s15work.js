'use strict';
/* ===== SIDE QUESTS: THE ONES YOU WALK OUT AND DO =====
   dig: patches of turned earth around the person. Every dig costs game time and tells you how warm you are. The thing is under one of them.
   shuttle: fill something at a source, carry it back, again, until it is done.
   gather: pick everything from a handful of patches.
   See s15quest.js for the engine. */
(function(){
const SQ=window.SQ; if(!SQ) return;

const RING_JUNK=[
 'A bottle-top. Then another. Somebody once had a very good evening in this field.',
 'A horseshoe, a very old one, and no horse in sight.',
 'A clay pipe-stem, snapped in the middle, and nothing else.',
 'A clod of root, shaped like a wing, which gives you a start.',
 'A button that is not a ring. It would like very much to be.',
 'A small round pebble, perfectly smooth. You hold it up to the light. It is a pebble.',
 'Forty years of ploughing have turned this soil over so often it has forgotten what it is hiding.',
 'A fork, bent into a question mark.'
];
const DIG_HINT={
 hot:'The soil here is dark and loose, turned by a hand not long ago in earth-time. You are very close. Look {dir}, and not far.',
 warm:'The ground has a different grain here, as if something once pressed it. Warmer. Try {dir}.',
 cold:'Plain field. Nothing has been asked of this soil in years. Cold. The better ground is {dir}.'
};

/* ---- Tamsin's ring (honest dig, and the dig where you keep what it is worth) ---- */
SQ.def('tamsin.dug',{kind:'dig',title:'search Alder\'s old field for the ring',start:'A task: search the field for Tamsin\'s ring. Turn over the patches of earth around her (Z).',spots:10,cost:0.5,
 intro:['"Here. The whole field. Alder said he turned it nine times that autumn and never once thought to look where he had stood to ask me."','"Dig where the earth is loose and dark. It will be a small thing. It will feel like nothing at all in the wing, and then it will not."'],
 junk:RING_JUNK,hot:DIG_HINT.hot,warm:DIG_HINT.warm,cold:DIG_HINT.cold,
 found:['The spade turns up something small and round, a thumb\'s width under the dark earth, with a ridge round the inside.','It is almost certainly not a ring. It is almost certainly a washer from a plough, and it is very nearly the right size.','You decide, on the spot, that it will do.'],
 remind:s=>'"Anything yet?" ('+s.n+' dug.) She is standing exactly where you left her, with the empty box in her wings.',
 back:[['@',['Tamsin takes it in both wings and holds it up to the light for a long time.']]],
 giveup:['"It is all right. It was always a long shot. Thank you for the afternoon, anyway."']});

SQ.def('tamsin.kept',{kind:'dig',title:'search the field, and decide what to do with what you find',start:'A task: search the field for Tamsin\'s ring. Turn over the patches of earth around her (Z).',spots:10,cost:0.5,
 intro:['"Here. The whole field. I shall wait at the gate. I have waited forty years. I am good at it."','(She hands you the empty ring-box. It weighs nothing, and it is surprisingly hard to hold.)'],
 junk:RING_JUNK,hot:DIG_HINT.hot,warm:DIG_HINT.warm,cold:DIG_HINT.cold,
 found:['Under a flat stone, in the third furrow, where a hurried man would have turned the plough: a thin ring of old gold, black with forty years of dirt.','You rub it on your sleeve. Under the black it is plain and warm and very good. A jeweller in any market would give you something for it.','You have, you realise, a decision, and nobody watching.'],
 remind:s=>'"Anything?" ('+s.n+' dug.) She has not moved from the gate.',
 back:[['@',['She looks at your wings, and then at your face, and then at the field.']],['',['You have the ring in your pocket. You have not yet said which story you are about to tell.']]],
 giveup:['"It is all right. Thank you for looking."']});

/* ---- Rudge's grandfather's takings, on the sandbar ---- */
SQ.def('pell.dug',{kind:'dig',title:'dig the sandbar for the buried takings',start:'A task: dig the sandbar for the old family takings (Z on the loose patches).',spots:10,cost:0.5,
 intro:['"My grandfather buried the season\'s takings on the bar every winter, against hard times. Hard times never came, so he never dug it up. He told my father. My father told me, once, when he was drunk."','"The bar shifts every spring. It will be somewhere. Take the shovel. I will stay with the boat. If I leave it the clerk will say I abandoned it."'],
 junk:['Wet sand, and a shell with the shape of a small face on it.','A rusted ferry-bell clapper, and no bell.','A fishing hook, still sharp, and a length of line that has gone to lace.','Silt, silt, and an eel who takes it personally.','A boot, left foot, much loved.','A broken pole, the same colour as the ones on Rudge\'s boat.','A clay jug with a crack, and in the crack, a very small crab.','Bones. Fish, you decide. Almost certainly fish.'],
 hot:'The sand is packed hard and dry here, though it ought to be wet. Someone put something heavy under it. Very close; look {dir}.',
 warm:'The sand has a seam in it, a line where it was once cut and filled. Warmer. Try {dir}.',
 cold:'Loose river sand, deep and wet. Nothing has ever been buried here. Try {dir}.',
 found:['Your shovel rings against metal, and the whole bar seems to hold its breath.','A tin box, black with age, wired shut. Inside, in rolls of cloth, a century of ferry-fares: pennies, and a single silver bit, and a note in a hand like a fence: "FOR THE HARD TIMES. DO NOT SPEND ON BOATS."','You cannot, in all honesty, say that these are not hard times.'],
 remind:s=>'"Anything?" ('+s.n+' dug.) He is sitting in the boat with the paper, reading it again as if it might have changed.',
 back:[['@',['He sees the box and stops with his mouth open, like a fish. Then he starts to laugh, a thin, strange, relieved noise.']]],
 giveup:['"No. No, it is all right. I will think of something. Thank you for trying."']});

/* ---- Gil's well: dig where the spring is ---- */
SQ.def('gil.dug',{kind:'dig',title:'dig for the spring, around the dry well',start:'A task: dig around the well until the spring breaks (Z on the dark patches).',spots:10,cost:0.65,
 intro:['"Four hours of digging, if the spring is where I think it is. The trouble is, I do not know where I think it is. It went down that way. It will be up here somewhere, wanting to come out."','"Dig where the ground is cold under your wing. Where it sweats. Water lies under the places that sweat."'],
 junk:['Dry clay, hard as a plate. A worm sits in it, annoyed.','Shale, in sheets, grey as rain.','A seam of grit. A little damp, but not enough to boast about.','Gravel and a single root, which has gone looking for water and failed.','Stone, then more stone. Gil would have a name for it.','A dry hollow, where water has been but is not any longer. It smells faintly of mushrooms.','Hardpan. Your shovel rings.'],
 hot:'The ground under your wing is cold and clammy, and the clay is dark. Water is near; very. Look {dir}.',
 warm:'The soil is a shade darker here and holds your footprint. Warmer. Try {dir}.',
 cold:'Dry as a bone. The water went the other way. Try {dir}.',
 found:['Your shovel goes in, and the earth goes dark, and then the hole is full of a sound like somebody pouring a cup.','Water. Cold, clean, loud. It comes up round your feet and runs off into the field as if it had been late for something.','Behind you, at the old well, Gil begins to shout.'],
 remind:s=>'"Any luck, my friend?" ('+s.n+' dug.) Gil is standing at the lip of his hole, looking at the sky, which does not help.',
 back:[['@',['Gil climbs out, covered to the knees, and looks at the water running through the field. He takes his hat off, which you did not know he had.']]],
 giveup:['"Aye. It will wait. Water always does. Thank you."']});

/* ---- Rook's iron ---- */
SQ.def('ember.both',{kind:'dig',title:'dig the old forge-pit for iron, so she can make both',start:'A task: dig the old forge-pit for iron (Z on the patches of black earth).',spots:10,cost:0.65,
 intro:['"There was a smithy here once, before the Hollow. My master says there is a pit behind it where they dumped the clinker, and a lot of old iron with it. Bog iron, bar-ends, nails."','"It will be black earth. It will ring when you hit it. Dig for ringing."'],
 junk:['Clinker. A lot of clinker. The black kind that looks like something.','A handful of rusted nails fused into a single angry hand.','A horseshoe that has been horseshoe-shaped for a long time.','Ash, then more ash, with a faint warm smell from the old days.','A broken hinge. You think about it.','Slag, glassy and green, with a twist in it like a candy.','A rusted bucket with a hole in it that looks like it was on purpose.'],
 hot:'The earth is black and gritty and your shovel rings. You are right on top of the old pit. Look {dir}.',
 warm:'Flecks of rust in the soil, orange as a fox. Warmer. Try {dir}.',
 cold:'Plain brown earth. No iron here. Try {dir}.',
 found:['The shovel rings like a bell. Under a layer of slag, a heap of bar-ends and rails, orange with rust and sound all through.','You haul it out in three trips. It is more iron than Rook has had in a year.','At the bottom of the heap, wrapped in sacking, a smith\'s hammer, handle gone, head sound. You take that, too.'],
 remind:s=>'"Hear anything?" ('+s.n+' dug.) Rook is at the anvil, looking at the same piece of iron she was looking at before.',
 back:[['@',['She sees the heap, and the hammer, and sits down heavily on the anvil. "Both," she says, to nobody. "I can make both."']]],
 giveup:['"No. Never mind. I will work out what to melt. Thank you."']});

/* ---- Shuttle quests ---- */
SQ.def('gil.carried',{kind:'shuttle',water:true,glyph:'bucketspot',title:'carry water to the well-diggers',srcName:'the water',trips:5,cost:0.6,
 start:'A task: carry water from the pond or stream to Gil, again and again (Z at the water, then Z on Gil).',
 intro:['"Eleven families, and the ditch is fouling. There is a pond a good walk off, or a stream. I need water, anything clean. Carry it here and I will see it gets to the houses."','"It is a lot of walking. I will not say it is anything but."'],
 take:'You fill the pails at the water. They are heavier than they have any right to be. The way back is mostly looking at your own feet.',
 drop:['You pour it into Gil\'s tub. A small child takes a cup to the next house, spilling most of it.','Second load. Your wings are starting to sing. Gil says nothing, and holds the rope.','Third. You find a rhythm, and the walk becomes a kind of thinking.','Fourth. Somebody has put a bench by the tub. It is the nicest thing anyone has done all day.'],
 last:['The fifth tub is full. Gil stands over it, looking at it as if it had said something kind.'],
 remind:s=>'"Another load?" ('+s.n+' of 5 carried.)',
 back:[['@',['"That will do. That will do, friend. Get some sleep."']]],
 giveup:['"No harm. We will manage with the ditch a bit longer. Thank you for what you did."']});

SQ.def('corvin.work',{kind:'shuttle',glyph:'sandbags',title:'haul sandbags for the Crown checkpoint',srcName:'the sandbag pile',trips:5,cost:0.6,
 start:'A task: haul sandbags from the pile to Garrick at the checkpoint, again and again (Z at the pile, then Z on Garrick).',
 intro:['"Five loads of sandbags, from the pile to the barrier. The Crown thanks you for your service. Do not make conversation; the sergeant is watching."','(He stamps a slip with the date and the word PENITENT, which you are fairly sure is not an official word.)'],
 take:'You heave a bag onto your back. It is heavier than it looks, and it looks heavy. Sand finds its way into everything.',
 drop:['The first bag goes on the barrier. Garrick marks a tally with a pencil that has seen better days.','Second. A passing soldier looks at you with something between pity and professional interest.','Third. Your wings ache in a way that will be a subject of conversation tomorrow.','Fourth. Garrick, without looking up, passes you a cup of water. Neither of you mentions it.'],
 last:['The fifth bag goes on. The barrier is solid, if not pretty. Garrick, for the first time, looks at you directly.'],
 remind:s=>'"Next." ('+s.n+' of 5 hauled.) He does not look up from the ledger.',
 back:[['@',['He takes the slip, and writes a small, formal tick. "The Crown is satisfied," he says. "The Crown, for once, is right."']]],
 giveup:['"As you wish. The record will show the effort. The record is also very short."']});

/* ---- Gather ---- */
SQ.def('ivy.gathered',{kind:'gather',title:'gather steepwort from the patches around the ward',spots:6,cost:0.3,
 start:'A task: pick steepwort from the green patches near the ward (Z on each).',
 intro:['"Steepwort, if you can find it. It grows where the ground is a little damp, and it smells of rain and old bread. Six good bunches, and then I will show you how to steep it."','"It is slow, and it is not strong, but it does not come with a cost I cannot pay."'],
 glyph:'herb',
 pick:['You cut the bunch low, where the stem is sweetest. It smells exactly as she said.','Damp ground, cold wings, a good bunch.','This one has gone to seed. You take what is green and leave the rest.','A small spider moves out. You apologise.','The leaves are curled with dew. You roll them into your satchel.','The last one grows in the lee of a stone, as if somebody were keeping it.'],
 done:'That is all six. Time to take them back and steep.',
 remind:s=>'"Any luck?" ('+s.n+'/6 gathered.)',
 back:[['@',['She smells the bundle and, for the first time since you met her, smiles.']],['',['You steep it together, as she shows you, with a lid, and a slow count. She hums while it draws. It is not a tune you know.']]],
 giveup:['"Of course. Thank you for trying."']});

})();
