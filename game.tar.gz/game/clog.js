'use strict';
/* ===== A PACK WITHOUT LIMITS, and the Collection Log ===== */
const WL_COLS=6;
function wlInvOrder(){
  /* newest kinds last would jump around, so keep a stable order: tools & gear first, then food, then finds by value */
  const rank=id=>{ const it=ITEMS[id]; return it.cat==='find'?3:it.use==='eat'?2:it.sell?3:1; };
  return Object.keys(g.inv).filter(id=>ITEMS[id]&&g.inv[id]>0).sort((a,b)=>rank(a)-rank(b)||(rank(a)===3?(ITEMS[b].sell||0)-(ITEMS[a].sell||0):0)||ITEMS[a].name.localeCompare(ITEMS[b].name));
}
invIds=wlInvOrder;
renderInv=function(){
  const ids=invIds(), n=ids.length;
  if(g.invSel>=Math.max(1,n)) g.invSel=Math.max(0,n-1);
  const total=Math.max(18,Math.ceil(n/WL_COLS)*WL_COLS);
  el.slots.innerHTML='';
  for(let i=0;i<total;i++){
    const sl=document.createElement('div');
    sl.className='slot'+(i===g.invSel?' sel':'');
    if(ids[i]){
      sl.appendChild(iconCanvas(ids[i]));
      if(g.inv[ids[i]]>1){ const ct=document.createElement('span'); ct.className='ct'; ct.textContent=g.inv[ids[i]]; sl.appendChild(ct); }
      const it=ITEMS[ids[i]]; if(it.rar) sl.style.borderBottomColor=WL_RARCOL[it.rar];
    }
    sl.addEventListener('click',()=>{ if(g.invSel===i&&ids[i]) useItem(ids[i]); else { g.invSel=i; el.dNote.textContent=''; renderInv(); } });
    el.slots.appendChild(sl);
  }
  const sel=el.slots.children[g.invSel]; if(sel&&sel.scrollIntoView) sel.scrollIntoView({block:'nearest'});
  const id=ids[g.invSel];
  if(id){
    const it=ITEMS[id], isW=it.use==='equip'&&g.worn[it.slot]===it.wear;
    el.dName.textContent=it.name+(isW?' (worn)':'')+(g.inv[id]>1?'  x'+g.inv[id]:'');
    el.dDesc.textContent=it.desc+(it.sell?'  Sells for about '+it.sell+' crumbs'+(it.rar?'  ('+WL_RAR[it.rar]+')':'')+'.':'');
    el.dUse.hidden=false;
    el.dUse.textContent=it.use==='map'?'Unfold (Z)':it.use==='tmap'?'Unfold map (Z)':it.use==='clog'?'Open (Z)':it.use==='eat'?'Eat (Z)':it.use==='equip'?(isW?'Take off (Z)':'Wear (Z)'):'Examine (Z)';
  } else { el.dName.textContent='Empty slot'; el.dDesc.textContent='Nothing here yet. Shops, the forest floor and the far reaches are good places to look.'; el.dUse.hidden=true; }
  const towns=[...g.towns.values()].map(t=>t.name+' ('+RANKS[rankOf(g.rep[t.key]||0)].n+')').join(', ')||'none yet';
  let units=0; for(const k in g.inv) units+=g.inv[k];
  el.notes.innerHTML='<b>CASE NOTES</b><br>Pack: '+n+' kinds, '+units+' items (no limit)<br>Dark trees studied: '+g.clues+'<br>Towns found: <span id="nTowns"></span><br>Tiles explored: '+g.explored.toLocaleString()+'<br>Crumbs: '+g.crumbs;
  document.getElementById('nTowns').textContent=towns;
};
{
  const _press3=press;
  press=function(k){
    if(g.mode==='inv'){
      const n=invIds().length, total=Math.max(18,Math.ceil(n/WL_COLS)*WL_COLS); let s=g.invSel;
      if(k==='left') s=Math.max(0,s-1); else if(k==='right') s=Math.min(total-1,s+1);
      else if(k==='up') s=Math.max(0,s-WL_COLS); else if(k==='down') s=Math.min(total-1,s+WL_COLS);
      else if(k==='z'){ const ids=invIds(); if(ids[s]) useItem(ids[s]); return; }
      else if(k==='x'||k==='i'){ closeInv(); return; }
      else return;
      if(s!==g.invSel){ g.invSel=s; el.dNote.textContent=''; blip(); renderInv(); }
      return;
    }
    if(g.mode==='clog'){ wlLogKey(k); return; }
    _press3(k);
  };
}
/* gifts: every kind of item, paged */
giftMenu=function(n,done){
  const ids=invIds().filter(id=>!ITEMS[id].nogift);
  if(!ids.length){ say(n.name,['You do not have anything to give right now. That is okay.'],done); return; }
  const labels=ids.map(id=>ITEMS[id].name+(g.inv[id]>1?' x'+g.inv[id]:''));
  pagedChoose(n.name,'What would you like to give?',labels,i=>giveGift(n,ids[i],done),6);
};

/* ---------------- the Collection Log ---------------- */
const WL_TABS=['Plants','Finds','Places'];
const wlLog={tab:0,biome:-1,sel:0,tier:-1,show:0};
const WL_SHOW=['All','Found','Missing'];
const wlLogEl=document.getElementById('clog');
function wlOpenLog(){
  if(!g.inv.clog&&g.mode==='play'){ toast('You need a Collection Log. Bookshops and curio shops sell them.',2600); return; }
  if(g.mode!=='play') return;
  g.mode='clog'; wlLogEl.hidden=false; wlLog.sel=0; wlRenderLog(); blip();
}
function wlCloseLog(){ if(g.mode!=='clog') return; g.mode='play'; wlLogEl.hidden=true; blip(); }
function wlLogItems(){
  const w=WD(), bs=wlLog.biome>=0?WL_BIOMES[wlLog.biome]:null, out=[];
  if(wlLog.tab===0){
    for(const sp of (bs?bs.sps:WL_SPLIST)){ if(wlLog.tier>=0&&sp.tier!==wlLog.tier) continue; const got=!!w.seen[sp.id]; if(!got) continue; out.push({sp:sp,got:got,n:w.seen[sp.id]||0}); }
    return out;
  } else if(wlLog.tab===1){
    const ids=bs?WL_FINDS_BY[bs.id].concat(wlLog.biome>=0?[]:[]):Object.keys(WL_FIND);
    const order=['trail','dig','treasure','any'].concat(WL_BIOMES.map(b=>b.id));
    const list=bs?ids:Object.keys(WL_FIND).sort((a,b)=>order.indexOf(WL_FIND[a].src)-order.indexOf(WL_FIND[b].src));
    for(const id of list){ const got=!!w.got[id]; if(!got) continue; out.push({id:id,got:got,n:w.got[id]||0}); }
  } else {
    for(const b of WL_BIOMES) if(w.biomes[b.id]) out.push({b:b,got:true,n:w.biomes[b.id]});
  }
  return out;
}
function wlLogCount(){
  const w=WD();
  return [[Object.keys(w.seen).length,WL_SPLIST.length],[Object.keys(w.got).filter(id=>WL_FIND[id]).length,Object.keys(WL_FIND).length],[Object.keys(w.biomes).length,WL_BIOMES.length]];
}
function wlLogItems0(){ /* totals for the current place and rarity filter, ignoring Found/Missing */
  const w=WD(); let got=0, tot=0;
  if(wlLog.tab===0){ const bs=wlLog.biome>=0?WL_BIOMES[wlLog.biome]:null; for(const sp of (bs?bs.sps:WL_SPLIST)){ if(wlLog.tier>=0&&sp.tier!==wlLog.tier) continue; tot++; if(w.seen[sp.id]) got++; } }
  else if(wlLog.tab===1){ for(const id in WL_FIND){ tot++; if(w.got[id]) got++; } } else { tot=WL_BIOMES.length; got=Object.keys(w.biomes).length; }
  return {got:got,tot:tot};
}
function wlSilhouette(cv){ cv.className='unk'; return cv; }
function wlRenderLog(){
  const w=WD(), items=wlLogItems(), cnt=wlLogCount();
  if(wlLog.sel>=items.length) wlLog.sel=Math.max(0,items.length-1);
  const tabs=document.getElementById('clTabs'); tabs.innerHTML='';
  WL_TABS.forEach((t,i)=>{
    const b=document.createElement('button'); b.type='button'; b.className='hb'+(i===wlLog.tab?' on':''); b.textContent=t+' '+cnt[i][0]+'/'+cnt[i][1];
    b.addEventListener('click',()=>{ wlLog.tab=i; wlLog.sel=0; wlRenderLog(); }); tabs.appendChild(b);
  });
  const tr=document.getElementById('clTiers'); tr.innerHTML=''; tr.hidden=wlLog.tab!==0;
  if(wlLog.tab===0){
    const bs=wlLog.biome>=0?WL_BIOMES[wlLog.biome]:null, pool=bs?bs.sps:WL_SPLIST, tot=[0,0,0,0,0,0,0], got=[0,0,0,0,0,0,0];
    for(const sp of pool){ tot[sp.tier]++; if(w.seen[sp.id]) got[sp.tier]++; }
    const mk=(label,gv,tv,col,i)=>{ const b=document.createElement('button'); b.type='button'; b.className='tchip'+(wlLog.tier===i?' on':'')+(i===6?' chroma':''); b.style.borderColor=col; b.innerHTML='<b></b> <span></span>'; b.firstChild.textContent=label; b.lastChild.textContent=gv+'/'+tv; b.addEventListener('click',()=>{ wlLog.tier=wlLog.tier===i?-1:i; wlLog.sel=0; wlRenderLog(); }); tr.appendChild(b); };
    for(let i=0;i<7;i++) mk(WL_PTIER[i],got[i],tot[i],WL_PCOL[i],i);
  }
  
  const bsel=document.getElementById('clBiome'); bsel.hidden=wlLog.tab>=2;
  bsel.textContent=wlLog.biome<0?'All places':WL_BIOMES[wlLog.biome].name;
  const done=items.filter(i=>i.got).length;
  const pa=wlLogItems0(); document.getElementById('clBar').style.width=(pa.tot?100*pa.got/pa.tot:0)+'%';
  const poolAll=wlLogItems0(); document.getElementById('clProg').textContent=(wlLog.tab===0?'Plants collected in this view: '+poolAll.got+' of '+poolAll.tot+(poolAll.got===poolAll.tot&&poolAll.tot?'  -  complete!':''):done+' of '+items.length+' found');
  const grid=document.getElementById('clGrid'); grid.innerHTML='';
  items.forEach((it,i)=>{
    const d=document.createElement('div'); d.className='cl'+(i===wlLog.sel?' sel':'')+(it.got?'':' miss');
    let cv, rar=0;
    if(it.sp){ const src=wlSpeciesIcon(it.sp,it.got); cv=document.createElement('canvas'); cv.width=src.width; cv.height=src.height; cv.getContext('2d').drawImage(src,0,0); if(!it.got) wlSilhouette(cv); rar=0; d.style.borderBottomColor=WL_PCOL[it.sp.tier]; if(it.got&&it.sp.tier===6) d.classList.add('chroma'); }
    else if(it.id){ cv=iconCanvas(it.id); if(!it.got) wlSilhouette(cv); rar=ITEMS[it.id].rar; }
    else { cv=document.createElement('canvas'); cv.width=48; cv.height=48; const c=cv.getContext('2d'); const b=it.b; c.fillStyle=it.got?(b.mapGrass||'#5a8a4a'):'#2a3a34'; c.fillRect(2,2,44,44); if(it.got){ c.fillStyle='rgba(255,255,255,0.18)'; c.fillRect(2,2,44,10); c.fillStyle=b.grass&&b.grass[0]||'#3a6a3a'; c.fillRect(2,34,44,12); } else { c.fillStyle='#51665c'; c.font='bold 26px monospace'; c.textAlign='center'; c.fillText('?',24,34); } }
    d.appendChild(cv);
    if(rar&&it.got) d.style.borderBottomColor=WL_RARCOL[rar]; if(it.sp&&!it.got) d.style.borderBottomColor='';
    if(it.sp?it.got:(it.n>1&&!it.b)){ const ct=document.createElement('span'); ct.className='ct'; ct.textContent=it.n; d.appendChild(ct); }
    d.addEventListener('click',()=>{ wlLog.sel=i; wlRenderLog(); });
    grid.appendChild(d);
  });
  const s=items[wlLog.sel], dn=document.getElementById('clName'), dd=document.getElementById('clDesc');
  if(!s){ dn.textContent='Nothing here yet'; dd.textContent=wlLog.tab===0?'Walk up to plants and press Z to forage them. Every new kind you find is added to this page.':wlLog.tab===1?'Forage, dig and follow trails to turn up finds.':wlLog.tab===3?'The things the Long Road gives you will be kept here.':'Explore to discover new places.'; }
  else if(s.sp){
    const b=WL_BY[s.sp.biome];
    dn.textContent=s.got?s.sp.name+'  ('+WL_PTIER[s.sp.tier]+')':'Unknown '+WL_CATS1[s.sp.cat]+'  ('+WL_PTIER[s.sp.tier]+')';
    dd.textContent=s.got?'A '+WL_CATS1[s.sp.cat]+' of the '+b.name+'. '+WL_PTIER[s.sp.tier]+' - '+WL_TIER_DESC[s.sp.tier]+'. '+'You have foraged it '+s.n+' time'+(s.n===1?'':'s')+'.':'Grows somewhere in the '+b.name+'. Walk up to one and press Z to find it.';
  } else if(s.story){
    const it=ITEMS[s.id];
    dn.textContent=s.got?it.name:'Not yet found';
    dd.textContent=s.got?it.desc+'  '+(s.where||''):(s.where||'Somewhere along the Long Road.');
  } else if(s.id){
    const it=ITEMS[s.id], src=it.src;
    const where=src==='trail'?'Turns up on the trails between towns.':src==='dig'?'Buried at glinting dig spots. Bring a shovel.':src==='treasure'?'Found in treasure chests.':src==='any'?'Can turn up while foraging anywhere.':'A rare find while foraging in the '+(WL_BY[src]?WL_BY[src].name:'wild')+'.';
    dn.textContent=s.got?it.name+'  ('+WL_RAR[it.rar]+')':'Unknown find';
    dd.textContent=(s.got?it.desc+'  Worth about '+it.sell+' crumbs. You have found '+s.n+'.  ':'')+where+(it.night?' Only after dark.':it.day?' Only by day.':'');
  } else {
    const b=s.b, sp=b.sps, seen=sp.filter(x=>w.seen[x.id]).length;
    dn.textContent=s.got?b.name:'Unexplored place';
    dd.textContent=s.got?'First visited on day '+s.n+'. Plants found here: '+seen+' of '+sp.length+'.  Rare finds: '+b.finds.map(id=>w.got[id]?ITEMS[id].name:'???').join(', ')+'.':'Somewhere in the world there is a place like this. Keep exploring, and check the explorer\'s map.';
  }
}
function wlLogKey(k){
  const items=wlLogItems(), cols=wlLog.tab===2?4:8;
  if(k==='x'||k==='l'){ wlCloseLog(); return; }
  let s=wlLog.sel;
  if(k==='left') s=Math.max(0,s-1); else if(k==='right') s=Math.min(items.length-1,s+1);
  else if(k==='up') s=Math.max(0,s-cols); else if(k==='down') s=Math.min(items.length-1,s+cols);
  else if(k==='z'){ wlLog.tab=(wlLog.tab+1)%WL_TABS.length; wlLog.sel=0; blip(); wlRenderLog(); return; }
  else if(k==='c'){ if(wlLog.tab===0){ wlLog.tier=wlLog.tier>=6?-1:wlLog.tier+1; wlLog.sel=0; blip(); wlRenderLog(); } return; }
  else if(k==='plus'){ wlLog.biome=wlLog.biome>=WL_BIOMES.length-1?-1:wlLog.biome+1; wlLog.sel=0; blip(); wlRenderLog(); return; }
  else if(k==='minus'){ wlLog.biome=wlLog.biome<0?WL_BIOMES.length-1:wlLog.biome-1; wlLog.sel=0; blip(); wlRenderLog(); return; }
  else return;
  if(s!==wlLog.sel){ wlLog.sel=s; blip(); wlRenderLog(); }
}
document.getElementById('clClose').addEventListener('click',wlCloseLog);
document.getElementById('clBiome').addEventListener('click',()=>{ wlLog.biome=wlLog.biome>=WL_BIOMES.length-1?-1:wlLog.biome+1; wlLog.sel=0; wlRenderLog(); });

/* every duck starts with a Collection Log (new games and older saves alike) */
{
  const _upd=updateHud;
  updateHud=function(){
    _upd();
    const w=g.story&&g.story.wd; if(w&&w.logGiven) return;
    const s=WD(); if(!s.logGiven){ s.logGiven=1; if(!g.inv.clog){ addItem('clog'); toast('Your Collection Log is in your pack. Press L to open it.',4200); } }
  };
}
