'use strict';
/* ===== v1.27: A MONEY SYSTEM WITH SOMETHING TO SPEND IT ON =====
   Pay went up in 1.26 but nearly everything in the shops still cost a few crumbs. This file re-prices the world so that
   crumbs matter, and gives them worthwhile places to go:
   - food, trinkets and tools cost real money; potions cost about twice what they did;
   - every town now prices things a little differently (shop around, and rank discounts matter more);
   - three "tools of the trade" you carry for permanent perks (Tackle Box, Forager's Satchel, Merchant's Ledger);
   - two more Nest projects (Herb Garden, Study Nook), added in s10nest.js.
   Prices live in one table below. Change a number and it changes everywhere. Exposes D10.carry, D10.prices. */
(function(){
'use strict';
const D10=window.D10=window.D10||{};

/* ---------- the price table (id: crumbs) ---------- */
const PRICE={
  /* everyday food: cheap enough to buy without thinking, dear enough to notice */
  seeds:3,crust:5,peas:5,muffin:8,tea:7,scone:7,cocoa:9,soup:11,honey:18,cake:26,worms:6,
  beetloaf:7,emberroll:9,ashbread:5,pepcocoa:9,cinderstew:13,embertea:7,roastnut:5,warmtonic:12,spiceseed:5,healleaf:7,
  hardtack:5,driedberries:7,t_mix:7,trailsand:11,waterskin:12,teablend:10,
  /* small things */
  daisy:5,bulb:7,bouquet:14,clover:11,socks:12,ducky:12,kite:18,marbles:9,top:8,pebble:9,feather:14,
  novel:18,guide:16,cookbook:14,notebook:16,vigil:6,redthread:8,flint:8,lure:12,baittin:16,tmap:22,clog:28,
  /* gear */
  hat:55,scarf:34,bowtie:30,crown:70,glass:40,specs:38,lantern:32,compass:48,key:60,
  shovel:48,axe:64,pickaxe:80,fishrod:38,tinderbox:14,lumenorb:36,
  wardcharm:40,emberwand:46,runestone:58,tinkerbeetle:20,seekerbeetle:52,gustcharm:30,
  /* the apothecary */
  tonic_luck:34,tonic_forage:28,tonic_angler:28,tonic_haggle:34,tonic_glow:24,tonic_speed:22,
  recipebook:140
};
for(const id in PRICE){ if(ITEMS[id]) ITEMS[id].price=PRICE[id]; }
D10.prices=PRICE;

/* potions cost nearly twice what they did: they are the strongest thing in the game */
try{ for(const r of BR_RECIPES) r.cost=Math.round(r.cost*1.8); }catch(e){}

/* every town prices a little differently: -13% to +13% */
itemBase=function(id,town){
  const b=ITEMS[id].price;
  return Math.max(1,Math.round(b*(0.87+hash(town.rx,town.ry,id.charCodeAt(0)*7+id.length)*0.26)));
};

/* favors pay in step with the new prices */
{ const _fr=favorReward; favorReward=function(t,def){ return Math.round(_fr(t,def)*1.4); }; }

/* ---------- tools of the trade: carried, permanent ---------- */
const carry=id=>{ try{ return !!(g.inv&&g.inv[id]>0); }catch(e){ return false; } };
D10.carry=carry;
ITEMS.tacklebox={name:'Angler\'s Tackle Box',price:140,use:'note',nogift:true,
  desc:'Carry it and your line lasts 20 casts longer, the fish tire a little more kindly, and rare fish bite more often.',
  note:'Neat little compartments. Everything smells faintly of pond.'};
RICON.tacklebox=(R,C,E)=>{ R(2,6,12,8,'#3a6a5a'); R(2,6,12,2,'#5a9a82'); R(6,4,4,2,'#2a4a3e'); R(7,9,2,3,'#e0b84a'); R(3,11,3,1,'#ff9d2e'); R(10,11,3,1,'#e0452f'); };
ITEMS.foragerbag={name:'Forager\'s Satchel',price:130,use:'note',nogift:true,
  desc:'Carry it and finds turn up a quarter more often, and every plant has a little more chance of a crumb.',
  note:'Pockets inside pockets, every one of them smelling of moss.'};
RICON.foragerbag=(R,C,E)=>{ R(3,6,10,8,'#8a6a3a'); R(3,6,10,3,'#a5855a'); R(5,3,6,3,'#6b4a2f'); R(7,9,2,2,'#e0b84a'); R(4,12,8,1,'#6b4a2f'); };
ITEMS.ledger={name:'Merchant\'s Ledger',price:130,use:'note',nogift:true,
  desc:'Carry it and shops pay 12% more for your finds, and every favor and job pays 8% more. Numbers that add up do you favors.',
  note:'Columns of neat figures. Several of them are now yours.'};
RICON.ledger=(R,C,E)=>{ R(3,3,10,11,'#7a2a2a'); R(4,4,8,9,'#e8d9b5'); R(5,6,6,1,'#8a6a3a'); R(5,8,6,1,'#8a6a3a'); R(5,10,4,1,'#8a6a3a'); R(3,3,2,11,'#5a1a1a'); };
STOCK.tackle.push('tacklebox');
STOCK.naturalist.push('foragerbag'); STOCK.provision.push('foragerbag');
STOCK.books.push('ledger'); STOCK.supply.push('ledger'); STOCK.cartog.push('ledger');
{ const o=wlItemMul; wlItemMul=function(){ return o()*(carry('foragerbag')?1.25:1); }; }
{ const o=wlCrumbP; wlCrumbP=function(){ return o()+(carry('foragerbag')?0.05:0); }; }
{ const o=wlHaggle; wlHaggle=function(){ return o()+(carry('ledger')?0.12:0); }; }
{ const o=payMul;   payMul=function(t){ return o(t)+(carry('ledger')?0.08:0); }; }
{ const o=rodMax;   rodMax=function(){ return o()+(carry('tacklebox')?20:0); }; }
})();
