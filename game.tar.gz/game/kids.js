'use strict';
/* ===== DUCKLINGS =====
   Small ducks live everywhere: two or three in every village, a handful in the kingdom, and eight in Emberwick, where they
   are the only ones who do not mind your feathers. They sleep early, wander near home, and mostly want to talk. */

const KID_NAMES=['Pip','Dot','Bean','Wren','Tilly','Fuzz','Moss','Nib','Pebble','Button','Sprout','Tuck','Daisy','Mabel','Otto','Fig','Plum','Biscuit','Clover','Wob'];
const KID_BIT=['cap','bow',null,'bow','cap',null];
const KID_SCALE=0.62;
const kidMade={};
function kidAwake(){ return g.clock>=7&&g.clock<20; }
function kidHash(s){ let h=7; for(let i=0;i<s.length;i++) h=(h*31+s.charCodeAt(i))|0; return Math.abs(h); }
function mkKid(id,name,wx,wy,pal,head,town,o){
  const p=snapFree(wx,wy,5);
  return Object.assign(K(name,p[0]-KX,p[1]-KY,pal,head,null,[['Hi!']],{special:'kid',kid:true,scale:KID_SCALE,still:false,owl:true,kidId:id,townRef:town||null,idx:2000+kidHash(id)%9000}),o||{});
}

/* ---------- what kids say in ordinary villages ---------- */
const KID_TALK=[
  ['I found a really good stick. It is the best stick. Want to see it? Okay, you looked. Great.','Mama says I can keep it as long as it stays outside. It is outside right now. Look.'],
  ['Are you a real detective? I am going to solve a mystery. It is going to be about who ate my bread.','(It was me. I know it was me. But I want a second opinion.)'],
  ['I can hold my breath for ten whole seconds. Count with me! One. Two. Three... Hold on, I forgot to start.'],
  ['The big ducks say the dark trees hum. I put my head against one. It hums a bit like Granddad.','I am not going back. It was a little bit scary and a little bit nice.'],
  ['Do you want to play a game? You hide. I count. I will count to a hundred. I only know up to nineteen.','Nineteen, nineteen-one, nineteen-two...'],
  ['I am practicing being tall. Look. I put a hat on and everything.','Mama says tall is an attitude. I think tall is a hat.'],
  ['What is your favourite bread? Mine is the one with the seeds. And the other one with the seeds. And the third one.'],
  ['I am saving up for a kite. I have four crumbs. Kites cost, um, a number bigger than four.','Maybe you could help? No. I should do it myself. But maybe a little.'],
  ['I told my mama a joke: why did the duck cross the road? She said "to get to the other side". I said "no, to be a duck". She did not laugh. She will, later.'],
  ['The puddle by the well is a lake today. I have decided. It is an ocean on Tuesdays.'],
  ['My brother says there is a town of red ducks in a forest that moves. I said that is silly. He said that is why it is true.','Is it true? You look like you might know.'],
  ['I drew you! See? That is you, that is your hat, that is the sun. The sun is also you.']
];
const KID_ASK=[
  {q:'Do you like bread or berries better?',o:['Bread, always','Berries!','Both, in one bite'],r:['BREAD. Same! We are friends now.','Berries are the best. Bread has no little pop.','Both at once?! You are a genius or a monster.']},
  {q:'Can you quack really loud?',o:['QUACK!','A little one','Not today'],r:['Wow. A bird looked at us. Do it again later.','That is okay. Small ones count too.','Nobody has to. Quiet days are good too.']},
  {q:'Do you think the moon follows us around?',o:['Absolutely','Only when you are good','It is just very far away'],r:['I KNEW IT. Nobody believes me.','I have been very good. Very, very good. Mostly.','Far away is also following, if you think about it.']}
];
const KID_KING=[
  ['My da is on guard duty at the castle. He says nobody has seen the king in weeks. He says the king is sad.','I asked what a sad king looks like. He said, "Like a king, but with the windows shut."'],
  ['Are red ducks real? Gran says they are a story. Sister Dove at the Temple says they were real and we were wrong.','I think both can be true. Gran says I think too much.'],
  ['I went to the Royal Library once. It is so quiet, you can hear the books thinking.','I did not touch anything. Except one. It smelt of cedar.'],
  ['The fountain in the square? Do not fall in. Last year somebody fell in and the guards fished him out with a net.','They called it "a rescue". We called it fishing.'],
  ['The maze is too hard. I went in the bottom and came out the top and I was somewhere else. Hubert says that is the point.'],
  ['The tower crystal makes a noise when someone says a name. I have heard it. It goes "mmmm". I said it back and it stopped.'],
  ['The Feather Festival is coming. Everyone gets a feather. Mine is going to be the biggest feather in the history of feathers.'],
  ['I want to be a guard when I grow up. Or the baker. Or the person who tells the guards what to do. That is a captain. I want to be a baker captain.']
];
function kidTalkNormal(n){
  const st=g.story; st.kidDay=st.kidDay||{};
  n.dir=OPP[g.dir]; n.moving=false; n.talking=true;
  const done=()=>{ n.talking=false; n.t=1; };
  const pool=n.kidKingdom?KID_KING:KID_TALK;
  const i=(kidHash(n.kidId)+(n.cycle||0))%pool.length; n.cycle=(n.cycle||0)+1;
  const give=()=>{
    if(st.kidDay[n.kidId]!==g.day&&n.townRef){ st.kidDay[n.kidId]=g.day; addRep(n.townRef,1); toast(n.name+' likes you. (+1 reputation)',2200); }
    st.kidMet=st.kidMet||{}; st.kidMet[n.kidId]=1;
  };
  if(n.cycle%3===0&&!n.kidKingdom){
    const a=KID_ASK[(kidHash(n.kidId)+g.day)%KID_ASK.length];
    choose(n.name,a.q,a.o,k=>say(n.name,[a.r[k]],()=>{ give(); done(); }),0);
    return;
  }
  say(n.name,pool[i],()=>{ give(); done(); });
}

/* ---------- Emberwick's eight ---------- */
/* {name,x,y,pal,head, q1 (everyone is asked where you come from), q2 (a different question for each child)} */
const RKIDS=[
 {name:'Little Poppy',x:34,y:35,pal:1,head:'bow',
  q2:{q:'Do yellow ducks have a mama? Mine says yours must miss you.',o:['She does','I do not remember her','I would rather not say'],
   r:['Then you should send her a letter. I will draw the picture on it.','That is sad. You can borrow mine. A little. Not on Wednesdays.','Okay. Mama says some questions are too heavy to carry around.']}},
 {name:'Ember',x:38,y:36,pal:0,head:'wizard',
  q2:{q:'My grandfather says yellow ones put out the fires. Is that true? You do not look like you put out fires.',o:['I have never put out a fire','Some of us did, long ago','Say nothing'],
   r:['I knew it. He is just grumpy. His knees hurt.','...Then some of you are sorry, probably. Sorry is a start. That is what Mama says.','Okay. I will ask him again. Louder.']}},
 {name:'Ash',x:31,y:33,pal:2,head:null,
  q2:{q:'If you take off your feathers, are you red underneath? Will you show me?',o:['No, ducks do not work that way','I am yellow all the way down','Say nothing'],
   r:['Ducks do not work that way? Then what do they work like? Slowly? Like soup?','All the way down? Wow. That is a lot of yellow.','I will keep looking. When you are not looking.']}},
 {name:'Rowan',x:40,y:33,pal:3,head:'wizard',
  q2:{q:'Are you scared of us? Because we are scared of you. A bit. Not me. My mama.',o:['A little','No, not of you','Say nothing'],
   r:['Okay. Me too, a little. At the same time is fair.','Good. Then you can sit with us. Do not tell Mama I said that.','That is okay. You are allowed to be quiet. I am, sometimes.']}},
 {name:'Tansy',x:36,y:42,pal:4,head:'bow',
  q2:{q:'What does the sky look like out there? All of it? With nothing on top?',o:['Enormous, and blue','Gray, and then sudden gold','Say nothing'],
   r:['Enormous. I am going to draw it. I only have a corner of paper, so it will be a small enormous.','Sudden gold! Like the Hearth when it catches! I think I would like that.','Okay. I will look at the bit I have. It is a nice bit.']}},
 {name:'Brindle',x:29,y:38,pal:0,head:'cap',
  q2:{q:'Do the kingdom ducks have fires? A big one, like ours? Do they say the Great Saying?',o:['They have fires. Not like yours','I do not think they say anything','Say nothing'],
   r:['Not like ours, hm. Ours is the biggest. I am very proud, but quietly.','Nothing at all? How do they remember each other? We say names!','Okay. I will ask the next one.']}},
 {name:'Kit',x:42,y:38,pal:1,head:null,
  q2:{q:'Will you stay? Not forever. Just a bit. Until I am tall.',o:['I will stay a while','I might have to go','Say nothing'],
   r:['A while is good. I will start growing right now. Watch.','Then go carefully. And come back. That is the rule with the Wood.','Okay. I will assume yes and be happy.']}},
 {name:'Marigold',x:33,y:39,pal:4,head:'bow',
  q2:{q:'Why do the grown-ups whisper when you walk by? Do you know? I am going to find out.',o:['I think they are worried','I think they are keeping something from me','Say nothing'],
   r:['Worried is a silly way to act. I will tell them to stop. In a nice voice.','Something. Something! I KNEW it. We are going to be detectives together.','Okay. I will do it by myself. Quietly. With a stick.']}}
];
const RK_Q1={
  q:'Where do you come from? Is it far? Is it yellow?',
  o:['From the Duck Kingdom of Mallardia','I woke up in a quiet forest and I am not sure where I come from','From a long way south, past the river','I would rather not say'],
  r:['Mallardia! Mama says the king there is scary. Is he? Are YOU scary? (You do not look scary. You look like a lemon.)','You do not know? That is so sad and also so exciting. I want to not-know where I am from. No. Wait. I do not.','South! Past the river! I have never been past the river. I have not been past the Wood. Tell me all about it, some day.','That is okay. Mama says that is also an answer. A quiet one.']
};
function rKidMark(n){
  const st=g.story, a=(st.kidA||{})[n.name]||[]; const d=st.kidDay&&st.kidDay[n.name];
  if(n.talking) return null;
  if(a.length>=2) return null;
  if(d===g.day) return null;
  return {ch:'?',col:'#ff9d6b'};
}
function rKidTalk(n){
  const st=g.story; st.kidA=st.kidA||{}; st.kidDay=st.kidDay||{}; st.kidTold=st.kidTold||{}; st.kidTrust=st.kidTrust||0;
  const rk=RKIDS.find(k=>k.name===n.name); const a=st.kidA[n.name]=(st.kidA[n.name]||[]);
  n.dir=OPP[g.dir]; n.moving=false; n.talking=true;
  const done=()=>{ n.talking=false; n.t=1; };
  const N=n.name;
  const asked=(qa,resp)=>{
    choose(N,qa.q,qa.o,k=>{
      const silent=(k===qa.o.length-1);
      a.push(k);
      if(!silent){ st.kidTrust++; st.kidTold[N]=1; }
      st.kidDay[N]=g.day;
      say(N,[qa.r[k]],()=>{
        const maybeGift=()=>{
          if(a.length>=2&&!st.kidGift&&st.kidTrust>=4&&N==='Little Poppy'){
            st.kidGift=1; addItem('redbraid'); coin();
            say(N,['I made you a braid. Eight knots, because eight of us. Mama says to give it away only if it matters.','It matters. Here.'],()=>{ toast('Received: Children\'s Braid',3200); done(); });
          } else done();
        };
        maybeGift();
      });
    },qa.o.length-1);
  };
  if(a.length===0){
    say(N,pick([['You are the yellow one! You are SO yellow. Can I look? I am looking.','I have questions. Mama says no questions. I have them anyway.']]),()=>asked(RK_Q1,0));
    return;
  }
  if(a.length===1){
    if(st.kidDay[N]===g.day){ say(N,[pick(['I am thinking up the next question. It is a big one. Come back tomorrow.','My head is full of questions. One at a time, Mama says.','Shh. I am being patient. It is very hard.'])],done); return; }
    say(N,['You came back! I thought of another one.'],()=>asked(rk.q2,1));
    return;
  }
  const idle=[
    ['Mama says not to talk to you. I told her I was practicing my questions.','She said "on whom"? I said "on the yellow one". She said, "that is not who". I am still thinking.'],
    ['The big ducks go quiet when you walk past. I am practicing quiet. I am not good at it.'],
    ['I told the Elders what you said. Not all of it. The good parts. They asked a lot of questions. They asked who taught you to be kind.','I said, "no one, he is just like that". They did not write that down. I think they should have.'],
    ['Our Banking is at six. Everyone sits. It is the best part of the day, and the quietest. I get to hold the ash-shovel. It is almost as big as me.','Sit at the back if you come. I will save you a place. It is a very small place.']
  ];
  say(N,idle[(kidHash(N)+g.day)%idle.length],done);
}

/* ---------- kids in the kingdom ---------- */
const KINGDOM_KIDS=[[-22,31],[-9,33],[8,27],[14,22],[-30,31],[1,29],[20,32],[-5,18]];
let kingKids=null;
function kingdomKids(){
  if(kingKids) return kingKids;
  kingKids=KINGDOM_KIDS.map((p,i)=>{
    const nm=KID_NAMES[(i*3+5)%KID_NAMES.length];
    const k=mkKid('K'+i,nm,KX+p[0],KY+p[1],PALS[i%PALS.length],KID_BIT[i%KID_BIT.length],null,{kidKingdom:true});
    return k;
  });
  return kingKids;
}
/* ---------- kids in ordinary villages ---------- */
function townKids(t){
  if(kidMade[t.key]) return kidMade[t.key];
  const h=kidHash(t.key), cnt=2+(h%2);
  const offs=[[-5,4],[5,-4],[-4,-5],[6,3]];
  const list=[];
  for(let i=0;i<cnt;i++){
    const nm=KID_NAMES[(h+i*7)%KID_NAMES.length];
    list.push(mkKid(t.key+':'+i,nm,t.cx+offs[i][0],t.cy+offs[i][1],PALS[(h+i)%PALS.length],KID_BIT[(h+i)%KID_BIT.length],t));
  }
  return (kidMade[t.key]=list);
}
let redKids=null;
function redKidList(){
  if(redKids) return redKids;
  redKids=RKIDS.map((k,i)=>mkKid('R'+i,k.name,RX0+k.x,RY0+k.y,RED_PALS[k.pal%RED_PALS.length],k.head,getRed(),{redKid:true}));
  return redKids;
}

/* ---------- wiring ---------- */
{
  const _extraNpcs=extraNpcs;
  extraNpcs=function(list){
    _extraNpcs(list);
    if(g.scene!=='world'||!kidAwake()) return;
    const px=g.px/TS, py=g.py/TS;
    const prx=Math.floor((px+24)/REG), pry=Math.floor((py+24)/REG);
    for(let dy=-1;dy<=1;dy++) for(let dx=-1;dx<=1;dx++){
      const t=getTown(prx+dx,pry+dy);
      if(t&&!t.isRed) for(const k of townKids(t)) list.push(k);
    }
    if(Math.abs(px-(KX))<80&&Math.abs(py-(KY))<80) for(const k of kingdomKids()) list.push(k);
    if(g.story.redOpen&&inRed(Math.floor(px),Math.floor(py))) for(const k of redKidList()) list.push(k);
  };
  const _specialTalk=specialTalk;
  specialTalk=function(n){
    if(n.redKid){ rKidTalk(n); return; }
    if(n.kid){ kidTalkNormal(n); return; }
    _specialTalk(n);
  };
  const _specialMark=specialMark;
  specialMark=function(n){
    if(n.redKid) return rKidMark(n);
    if(n.kid) return null;
    return _specialMark(n);
  };
  const _journalExtra=journalExtra;
  journalExtra=function(sec,line){
    _journalExtra(sec,line);
    const st=g.story, km=st.kidMet?Object.keys(st.kidMet).length:0;
    if(km) { sec('Ducklings'); line('Little ones you have talked to: '+km+'. Each is good for a bit of reputation in their own village, once a day.'); }
    if(st.kidA&&Object.keys(st.kidA).length){
      sec('Emberwick\'s children');
      line('The red duck children ask where you come from. You answer or you do not. They tell what they hear.');
      for(const k of RKIDS){ const a=st.kidA[k.name]; if(a) line(k.name+': '+a.length+' of 2 questions answered.','jdim'); }
    }
  };
}
