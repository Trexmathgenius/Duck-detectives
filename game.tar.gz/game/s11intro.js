'use strict';
/* ===== v1.28.1: A SHORT WAY IN =====
   The game already had a stepped objective bar and a Field Guide. This file closes the gaps the newer systems left:
   - the Aims panel (K) and the Controls panel (?) are tracked, so the Field Guide and tip cards know whether you have seen them;
   - three tip cards: what ? and K are, and what a person with a ! on the road is asking for;
   - nothing here is a lecture or a gate. Tips show once, at least 30 seconds apart, never over a conversation, and can be
     switched off in Settings. */
(function(){
'use strict';
const D10=window.D10=window.D10||{};
const wrap=(name,key)=>{ const o=D10[name]; if(typeof o!=='function') return; D10[name]=function(){ const r=o.apply(this,arguments); try{ if(g.mode==='aims'||g.mode==='help') D10.mark(key); }catch(e){} return r; }; };
wrap('openAims','aims'); wrap('openHelp','helpPanel');
const TIPS=D10.tips; if(!Array.isArray(TIPS)) return;
const waiting=()=>{ try{ const S=D10.reqState(); return Object.keys(S).some(k=>S[k]&&S[k].st==='open'&&S[k].xy); }catch(e){ return false; } };
const idx=TIPS.findIndex(t=>t.id==='t_more');
const add=[
 {id:'t_road',when:()=>waiting()&&!D10.has('road'),title:'Someone needs you',text:'A duck with a ! is asking for help. You can bring fish, plants, a potion, crumbs, your time, or just an honest word. Nothing is required, and every answer is remembered.'},
 {id:'t_aims',when:()=>performance.now()>70000&&!D10.has('aims')&&!!g.flags.talked,title:'Aims',text:'Press K for today\'s commissions and your long-term aims. They pay crumbs, and some give perks.'},
 {id:'t_help',when:()=>performance.now()>45000&&!D10.has('helpPanel'),title:'Controls',text:'Press ? to see every key in one place. Settings can switch to WASD, tap-to-reel and an on-screen pad.'}
];
TIPS.splice(idx>=0?idx:TIPS.length,0,...add);
})();
