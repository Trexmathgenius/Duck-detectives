'use strict';
/* ===== TURNS 10-19: a promise, what you ask for, a failure, a wall, a fire, a road, a gate, a mirror, a first name, a king's last words ===== */

/* 10. A PROMISE TO A KING. Silence is an answer with weight. */
turnDef(10,{
 '*':{who:'King Eider',fmt:'choice',
  pre:['The dark in the throne room is not empty. It has a shape, and the shape is breathing. King Eider has told you what he is: not a ruler, but a ward, the door that holds the Burnt Wood shut. A hundred years of keeping a door closed with his own body.','"I am going to ask something of you. It is not a command. A ward cannot command. It is a request from a thing that is tired."','"When this ward breaks, and it will, I will not be able to choose what comes through. Promise me that the sleepers will not be woken as a weapon. Not by the Crown. Not by the Hearth. Not by anyone who tells you it is the only way."'],
  q:'The dark waits. It has waited a hundred years. It can wait for this.',
  opts:[
   T6o('"I promise. They will never be anyone\'s weapon."',{cap:{sleepers:2,crown:1},led:{trust:1},h:'steady',flag:'promised',mem:'promised a king the sleepers would never be a weapon',say:['The dark seems, for a moment, to lean toward you.','"Thank you. I will remember it. It is the one thing I will still be able to do when I cannot do anything else."','You will be tested on it. You know that already. It is a promise you made with your eyes open.']}),
   T6o('"I promise to try. I cannot promise to win."',{cap:{sleepers:1,crown:1},led:{truth:1},h:'candid',flag:'tried',mem:'told a king you could only promise to try',say:['The king is quiet. "That is an honest answer. I have been given so many dishonest ones."','"Try. That is what a promise is, I think, when it is not a lie."']}),
   T6o('"I cannot promise that. It depends on what comes."',{cap:{sleepers:-1,crown:-1},led:{pride:1},h:'guarded',flag:'refused',mem:'would not promise a ward anything',say:['"Of course," says the king. "Of course. You are wise not to." It is the most disappointed sentence you have ever heard.','He does not ask again. In the dark, something that might be his hand moves on the arm of the chair.']}),
   T6o('Say nothing. Sit with him in the dark.',{cost:{hours:1},cap:{sleepers:2},led:{kin:1},h:'tender',flag:'sat',mem:'sat in the dark with a king and did not answer',say:['You sit. You do not say yes, and you do not say no. You sit at the foot of the chair, in the dark, with an old man who has not been sat with in a hundred years.','Hours go. When you stand, he says "That was a better answer than words." You think so too.']})]}
});

/* 11. WHAT YOU ASK THE TREE FOR. */
turnDef(11,{
 '*':{who:'The Old Tree',fmt:'choice',
  pre:['The Tree showed you the night of the siege. You were asked whose child you are. You did not know the answer, and the Tree let you not know.','The hollow in its trunk is humming the lullaby, and it has gone quiet, the way a person goes quiet before they say something. It is waiting.','Then a voice that is not a voice says: "You may ask me for one thing. Not forever. Once. I am old and I give small gifts. What will you ask for?"'],
  q:'The hollow waits. The ash does not move.',
  opts:[
   T6o('"Show me all of it. Both sides of the siege."',{cap:{sleepers:1,crown:1,hearth:1},led:{truth:1},h:'candid',flag:'truth',mem:'asked the Tree for the whole truth about the siege',say:['It shows you. Not the glory, not the grief, the arithmetic: how many were afraid, and of what, and who was sent. You see a boy in blue and a boy in red dropping the same spear, at the same moment, for the same reason.','You come out of it older. You do not unsee it. The Tree says "Good," very softly. "That is the whole gift."']}),
   T6o('"Stop the humming for one night. They are so tired."',{cap:{sleepers:-1,hearth:1},led:{mercy:1},h:'gentle',flag:'silence',mem:'asked the Tree to be quiet for one night',say:['The hum stops. For the first time in a hundred years, the Burnt Wood is silent.','It is the loudest thing you have ever heard. Somewhere deep in the ash, three hundred sleepers shift, all at once. The Tree begins again, apologetically, after a minute.']}),
   T6o('"Nothing. I do not need anything. Thank you for asking."',{cap:{sleepers:2},led:{trust:1,kin:1},h:'tender',flag:'nothing',mem:'asked the Tree for nothing',say:['The humming changes key. For a moment it is something like laughter, the dry creak of something that has not laughed since before there were ducks.','"Nobody has ever asked for nothing," the Tree says. "I do not know what to do with it. I will keep it. It is small and it is warm."']})]}
});

/* 12. A FAILURE, AND WHO OWNS IT. */
turnDef(12,{
 '*':{who:'Captain Halbeak',fmt:'choice',
  pre:()=>{
    const q=s2(), liar=s2led('lie')>=4&&!q.keeperAsked;
    if(liar){ q.keeperAsked=1; q.keeperClosed=1; }
    const out=['The summit has failed. Tents are coming down in the rain. Cinder and Halbeak stand on opposite sides of a table with nothing left on it, and everyone else has gone very quiet.','Halbeak says what everybody is thinking, not unkindly. "You were the only one who could have done this. We were told you had seen what the Tree remembers. You did not tell us. I cannot make that fit into anything but a failure."','Cinder says, at the same moment, "The Crown did not come in good faith. We all saw it."','Both of them turn to you. This is the moment each of them has been waiting for, to find out whose failure it was.'];
    if(liar) out.push('(Far back in the crowd, a small hooded figure turns his face away. Mallow had meant to offer you a third road today. He has weighed what you have said, one thing and then another, and found the weights do not match. He does not come forward. The offer is not made.)');
    return out;
  },
  q:'Rain on the canvas. Nobody breathing.',
  opts:[
   T6o('"It was mine. I should have said what I knew."',{cap:{crown:1,hearth:1,mallow:1},led:{truth:1},h:'candid',flag:'owned',mem:'stood in the rain and said the failure was yours',say:['The silence changes. It does not lift, but it is the sort of silence that has room in it now.','Halbeak takes off his helmet. Cinder, on the other side of the table, puts down her staff. Neither says "it is all right." Both say, in the same breath, "Thank you."']}),
   T6o('"The Crown did not come in good faith." (Blame Halbeak\'s side.)',{cap:{hearth:2,crown:-2},led:{pride:1},h:'proud',flag:'blamedcrown',mem:'named the other side as the failure',say:['Cinder does not smile. She nods, once, with the exhausted satisfaction of someone who has been right and wishes she had not been.','Halbeak says nothing. He turns and goes into the rain, and the lords go after him. You will meet the Crown\'s coldness again.']}),
   T6o('"The Hearth would not hear it." (Blame Cinder\'s side.)',{cap:{crown:2,hearth:-2},led:{pride:1},h:'proud',flag:'blamedhearth',mem:'named the other side as the failure',say:['Halbeak does not smile. He nods, tersely, and sits, and begins writing a report that will be read very differently by very different people.','Cinder goes out into the rain without her staff. Ruddock goes after her with it. You will meet the Hearth\'s coldness again.']}),
   T6o('"It belongs to the room. All of us brought it."',{cap:{crown:0,hearth:0,mallow:2},led:{trust:1},h:'steady',flag:'room',mem:'refused to name a culprit for the failed summit',say:['It does not satisfy anyone. It is the most unsatisfying thing you could have said.','But no one is quite able to argue with it. They go home angry, and slightly less certain, and that is the beginning of something.']})]}
});

/* 13. A WALL. */
turnDef(13,{
 r:{who:'Archivist Sorrel',fmt:'choice',
  pre:['Forty-one plaques on the Wall of Lost. You and Sorrel have read them all. The three hundred are listed as "taken" on the oldest one, and "marching" on the next. Neither is true. They were searching.','Sorrel turns the little chisel in her hands. "I can cut it right. It would take an afternoon. And then the whole town would know that the sleepers did not march on us, and that the story we have told our children for a hundred years was wrong."','"Brand\'s people will not like it. Nobody likes to learn they have been afraid of the wrong thing."'],
  q:'The chisel is cold. The plaques are very old.',
  opts:[
   T6o('Cut it right, in public, tomorrow.',{cap:{hearth:1,sleepers:1},led:{truth:1},h:'candid',flag:'public',mem:'cut the truth into the Wall for everyone to read',say:['By noon the whole town has read it. Some stand a long time. Some leave without a word. A few spit.','The Hands do not forget. The fires come sooner for it. But the sleepers have a name now, and the name is: searching.']}),
   T6o('Tell the Elders. Let them decide how.',{cap:{hearth:1},led:{trust:1},h:'steady',flag:'elders',mem:'trusted the Elders with a hard truth',say:['The Elders take a week. When the plaques are cut, they are cut gently, one at a time, at night.','It is less honest than a morning. It is more survivable. Sorrel says "I would have done it your way" and then, because she is honest, "I think they were right."']}),
   T6o('"Leave it. They are not ready."',{cap:{hearth:0,sleepers:-1},led:{lie:1},h:'guarded',flag:'hid',mem:'left a false plaque on a wall because the town was not ready',say:['Sorrel puts the chisel down. "You are probably right," she says, in the voice of a person who is not sure.','The plaques stay as they were. The children keep learning the old story. You find that the old story gets a little harder to hear.']})]},
 c:{who:'Treasurer Mink',fmt:'choice',
  pre:['You have the names: Gander, Plume, Teal, Mink. A war chest filled by a faction that wanted the sleepers kept asleep by the old methods. Lady Teal and the Chancellor stood down. The lords have split, shouting, into three camps.','Treasurer Mink finds you in the arcade, grey-faced, wringing his gloves. "I opened the chest. I never asked what it was for. If it comes out, I am finished, and so is my family\'s name."','"I will open the books, every page, if you let me do it quietly. Or I will hide them, and you will never find the rest."'],
  q:'Mink is not a brave man. He is an honest one, which is rarer.',
  opts:[
   T6o('Expose it, in the open, today.',{cap:{crown:-1,sleepers:1},led:{truth:1},h:'candid',flag:'exposed',mem:'exposed the Court\'s war chest before the whole plaza',say:['By noon the plaza is a river of paper. Lords who were friends yesterday cannot look at each other.','Mink is dismissed that night. He bows to you, as he leaves, and it is a bow of surprising dignity.']}),
   T6o('Take the books quietly, and open the chest to the Watch.',{cap:{crown:2},led:{trust:1},h:'steady',flag:'quiet',mem:'let a frightened treasurer open the books in secret',say:['It is done in three days, in a back room, with a candle. Every page is copied. Mink weeps, once, and then works until dawn.','The Court survives. It is smaller. It is, for the first time in a long while, honest in its bookkeeping.']}),
   T6o('Take the offer, and keep what you learn in reserve.',{cap:{crown:1,mallow:-1},led:{lie:1},h:'guarded',flag:'reserve',mem:'kept a frightened treasurer\'s secrets in a drawer',say:['"It will be useful to have," you say. Mink goes grey, and then very still.','You are not sure why you said it. You are not sure you did not mean it. The drawer is small, and it will fill.']})]}
});

/* 14. A FIRE, AND AN OATH. */
turnDef(14,{
 r:{who:'Warden Ruddock',fmt:'choice',
  pre:['The five fires are out. The palisade smells of char and wet rope. The Hands who set them were mostly villagers: frightened, loyal to Brand\'s fear more than to Brand. Six were caught, two crying, and four sitting in a row with their hands folded, looking at their feet.','Ruddock stands beside you, covered in soot, holding a bucket he forgot to put down. "I could name them all. I know most of them. A baker. A girl who cleans the bell. A boy of twelve."','"I told you my grandfather died on the Siege Field. I am not here to make the same mistake he did. Tell me what you want done with them."'],
  q:'The bucket drips on his boots.',
  opts:[
   T6o('Give the names to Cinder. Let the Hearth decide.',{cap:{hearth:1,sleepers:0},led:{truth:1},h:'steady',flag:'named',mem:'handed six frightened people to the Hearth\'s court',say:['Cinder takes the list and holds it as though it were wet. Six people are brought into the square the next day. One of them is the boy.','The Hearth is stern and not cruel. But the town does not forget who gave the names, and your name goes on the list of people it does not quite trust.']}),
   T6o('Give none. Put them to work rebuilding the wall.',{cap:{hearth:0,sleepers:1},led:{mercy:1},h:'gentle',flag:'work',mem:'put the people who set the fires to work mending the wall',say:['The wall is rebuilt in four days. The baker lays the first stone. The girl who cleans the bell carries the water.','Ruddock does not smile. He puts down the bucket, at last. "It is the right thing and I am going to have to defend it every day for a year."']}),
   T6o('Give the ringleader\'s name only. Spare the rest.',{cap:{hearth:1,mallow:1},led:{trust:1},h:'steady',flag:'ringleader',mem:'named one man and spared six',say:['The ringleader is a grey-cloaked quartermaster, Carrow, who confesses before dawn. He is not Brand. He is the man Brand trusted most.','The six go home. Carrow is bound over. The Hands lose their most useful hands. In the days ahead you hear the word "Brand" spoken more quietly.']})]},
 c:{who:'Captain Halbeak',fmt:'choice',
  pre:['The march order is swapped for a recall. Halbeak has sworn a new oath: not to the seal but to the king. He is sitting on the edge of his cot with the old page across his knees, unburnt, creased in four.','"I have been asking myself something for six days. Did the king sign it? I know the hand. I know the seal. And I know the king has not spoken to a living soul in a hundred years, and so the question is: who signed?"','"You know something. I can see it in the way you do not look at me. Tell me what you know, or tell me what is kind. I will take either. I do not promise to forgive both."'],
  q:'Halbeak folds the page, along the old crease, and waits.',
  opts:[
   T6o('Tell him everything: Eider is a ward. The hand was a sleeper\'s.',{cap:{crown:1,sleepers:1},led:{truth:1},h:'candid',flag:'told',mem:'told Halbeak the truth about the king\'s hand',say:['Halbeak listens without moving. When you finish, he says only: "A hundred years. And I have been signing my life to a ghost."','Then, slowly: "No. To a man who stayed. I can swear to that." He folds the page and puts it in the fire. It does not burn quickly. It burns completely.']}),
   T6o('"The king chose peace. That is all you need."',{cap:{crown:0},led:{lie:1,mercy:1},h:'gentle',flag:'kinder',mem:'let Halbeak believe the king had chosen peace',say:['Halbeak looks at you for a long time. "That is a kind answer."','"It is not the whole answer." "No." He nods, and puts the page away, and you both pretend not to know what that nod meant.']}),
   T6o('"Ask him yourself. You will meet him."',{cap:{crown:1,mallow:1},led:{trust:1},h:'steady',flag:'ask',mem:'told Halbeak he would meet the king and could ask him',say:['Halbeak laughs once, mirthless, surprised. "I have not met the king in thirty years. And now I am to be introduced?"','"You are." "Then I shall have to polish my boots." He does. It takes an hour, and he does it very well.']})]}
});

/* 15. A ROAD, AND THE ONE WHO CAME. */
turnDef(15,{
 r:{who:'Warden Ruddock',fmt:'choice',
  pre:['Poppy has asked three questions on the Lantern Road. You answered. Now she is asleep against a tree, small as a shoe, with her bag open and a sandwich fallen out of it.','Ruddock stands beside you in the lantern light, whispering. "She should be home. This is a road for grown fools. I will carry her back myself, with an honest escort and a bad temper. Or you can ask her what she wants, and risk her saying the wrong thing."','"I would carry her. I have buried people for being brave. But it is your road."'],
  q:'Poppy mutters in her sleep. It sounds like a name.',
  opts:[
   T6o('Ask her, in the morning. It is her road too.',{cap:{sleepers:1},led:{kin:1,trust:1},h:'tender',flag:'asked',mem:'let a small girl decide whether to come',say:['In the morning she says "I am coming" before you finish asking. She says it with such certainty that Ruddock puts the sandwich back in her bag without a word.','She walks the rest of the way a pace ahead of you, taking the road personally.']}),
   T6o('Send her home with Ruddock. She is a child.',{cap:{hearth:1},led:{mercy:1},h:'proud',flag:'sent',mem:'sent a child home from the road',say:['Poppy wakes at the edge of the wood. She does not shout. She looks at you with a clear, cold, unbearable maturity and says "You decided for me."','Ruddock walks her home. She does not speak to you for days. When she does, it is precise and polite, and the warmth has gone out of it.'],set:()=>{ A5().poppyHome=1; }}),
   T6o('Let her stay without asking. You need the lantern held.',{cap:{sleepers:-1},led:{lie:1},h:'guarded',flag:'used',mem:'let a child carry a lantern because you needed it carried',say:['You hand her the lantern, saying it is a job. It is. It is also the most useful thing a child can do on a road like this, and you both know it.','Ruddock watches. He says nothing. But he moves closer to her, and stays there.']})]},
 c:{who:'Captain Halbeak',fmt:'choice',
  pre:['The five watch-fires are lit with the coal of the First Hearth. The Crown\'s line holds through the night. The coal sits in its iron cup beside you, glowing the colour of a held breath, leaning north-west.','Halbeak\'s sergeant comes at midnight, hat in hand. "Sir. The men would like to keep the coal. For the night. They have never seen a fire that does not go out."','Halbeak looks at you. "It is yours. I will not ask. But they are frightened, and it is the only thing in the camp that is not."'],
  q:'The coal glows. It does not warm anything that is not already warm.',
  opts:[
   T6o('Lend it to the line for the night.',{cap:{crown:2,hearth:-1},led:{mercy:1},h:'gentle',flag:'lent',mem:'lent the First Hearth\'s coal to frightened soldiers',say:['The coal sits in the middle of the camp, and men come in ones and twos to stand near it. Nobody talks. At dawn the cup is still warm, and the line is still standing.','When you take it back, its glow is a little dimmer. The Hearth will notice. You know it already.']}),
   T6o('Keep it. It is not for the Crown.',{cap:{crown:-1,hearth:1},led:{pride:1},h:'proud',flag:'kept',mem:'kept the coal from soldiers who were afraid',say:['Halbeak nods. He relays your refusal to the sergeant in plain words, without comment.','The camp spends a dark night. Nobody goes missing. But in the morning there is a notch of resentment in the way the sergeant salutes you.']}),
   T6o('Give a spark of it to the sentry, and ask him to carry it home.',{cap:{crown:1,hearth:1},led:{kin:1},h:'tender',flag:'spark',mem:'sent a spark of the First Hearth home with a frightened sentry',say:['You touch a lantern wick to the coal and hand the lantern to the youngest man on the line. "Carry it home," you say. "When the war is over."','He holds it like a baby. The coal is a little smaller, and every fire it will light in his village will be, in some small way, yours.']})]}
});

/* 16. SOMEONE LOOKED AWAY. */
turnDef(16,{
 r:{who:'Spearman Orrel',fmt:'choice',
  pre:['You are past the Gate of Ash, whether by argument or by shadow. Behind you the Crown\'s line stands exactly as it did, spears planted, faces set.','But one of the spearmen, a lanky young man named Orrel, looked at his boots at the right moment. You saw him do it. He will be asked how a duck got past his post, and he will say he did not see.','He is not behind you any more. He is at your elbow, whispering. "Sergeant will have my stripe. I do not mind. But my mother is in the town and she does not know I am on this line."'],
  q:'Orrel is already shaking. He has not decided yet whether to be afraid.',
  opts:[
   T6o('Go back with him and take the blame yourself.',{cost:{hours:2},cap:{crown:1,hearth:0},led:{trust:1,truth:1},h:'steady',flag:'blamed',mem:'went back to take the blame for a soldier who looked away',say:['The sergeant is not impressed. He is, however, a fair man in an unfair week, and he writes it down as "duck got past, cause unknown."','Orrel keeps his stripe. He writes to his mother that night. In the letter, you are a person who stood in a doorway.']}),
   T6o('Press a letter into his hand for his mother, with thanks.',{cap:{crown:1},led:{mercy:1},h:'gentle',flag:'letter',mem:'sent a soldier\'s mother a letter of thanks',say:['You write it on your knee, on the back of a map. It is not long. It says her son did a brave and quiet thing.','He tucks it into his belt. He does not lose his stripe, as it turns out. A letter from a person like you can do a surprising amount, and you did not know it could.']}),
   T6o('Say nothing. Go on. He chose.',{cap:{crown:-1},h:'guarded',flag:'silent',mem:'let a soldier shoulder a choice alone',say:['You nod to him. It is a courteous nod. It is also, you know, a goodbye.','You do not find out what happened to Orrel. For some time afterward, when you pass a line of spears, you look at the boots.']})]},
 c:{who:'Warden Ruddock',fmt:'choice',
  pre:['You are past the Hollow\'s line at the Gate of Gold, whether by argument or by shadow. Behind you the wardens stand in a row, arms folded, flame on a staff in the middle of them.','Ruddock looked away. You saw him do it. He is at your side now, not looking at you, whispering to the wind. "I will be asked. I have been asked many things. I do not lie well."','"If they ask whether I let you through, I shall say yes. I am telling you so you will not be surprised when you hear it."'],
  q:'Ruddock has decided already. He is telling you so you can stop him.',
  opts:[
   T6o('"Say I forced my way. Do not take the blame."',{cap:{hearth:0},led:{lie:1,mercy:1},h:'gentle',flag:'shielded',mem:'asked a warden to lie to protect himself',say:['He is silent. "I do not lie well." "Then say nothing, and I will say it for you."','He agrees, in the end, because you are asking. He is a little ashamed of how much he wanted to be asked.']}),
   T6o('Stand beside him when he tells them.',{cost:{hours:2},cap:{hearth:1},led:{trust:1,truth:1},h:'steady',flag:'stood',mem:'stood beside a warden while he told his elders the truth',say:['You go back. You stand in the line. Ruddock tells them, in four plain sentences, what he did and why.','They are not pleased. But they are impressed against their will, and you see in their faces the first thaw of a very old frost.']}),
   T6o('"Tell them what you must."',{cap:{hearth:-1},h:'guarded',flag:'left',mem:'told a warden to tell the elders what he must',say:['He nods, once. It is a bleak nod.','He is demoted for a season. He does not complain. He does not forget, either.']})]}
});

/* 17. A MIRROR: you choose what you carry. */
turnDef(17,{
 skip:()=>!!s2().done.c14k,
 '*':{who:'The Burnt Wood',fmt:'choice',
  pre:()=>{ const P=S4.portrait(); return ['The Burnt Wood showed you your own deeds, in the order you did them, and asked, of each, if you meant it. You answered. It did not tell you whether you were right.'].concat(P.lines.map(l=>l.replace(/^"|"$/g,''))).concat(['Then, at the last, the wood says: "You may keep this. Or you may leave some of it here, with the ash. Which part is heavy?"']); },
  q:'A thought for the end of the road. The wood waits.',
  opts:(()=>{
    const P=()=>S4.portrait();
    return [
      T6o('Keep all of it. It is mine.',{cap:{sleepers:0},led:{trust:1},h:null,flag:'kept',mem:'chose to carry all of who you had been',say:['The Wood is quiet. "Brave," it says, "or stubborn. In a hundred years I have not learned the difference."']}),
      T6o('Set down what you are proudest of.',{req:()=>S4.total()>=3,cap:{},flag:'setpride',mem:'set down the part of yourself you were proudest of',set:()=>{ const P=S4.portrait(); S4.shift(P.k1,-2); },say:['It is surprisingly heavy to put down. When it is gone, you feel cooler, and a little lost, and very light.','The Wood takes it without ceremony. You will miss it. You will also, at times, be grateful.']}),
      T6o('Set down what has cost you the most.',{req:()=>S4.total()>=3,cap:{},flag:'setcost',mem:'set down the part of yourself that cost the most',set:()=>{ const P=S4.portrait(); S4.shift(P.k2,-2); },say:['You expect it to hurt. It does not. It leaves a space the exact shape of what you have put down, and the space is quiet.','Whatever comes to fill it will be new. You do not know what yet.']})
    ];
  })()}
});

/* 18. A FIRST NAME. Timed: who do you wake first? */
turnDef(18,{
 '*':{who:'Gordamom',fmt:'timed',sec:16,
  pre:['You have heard the sleepers, found Bree, and spoken to Gordamom. What you said decided whether the grudge could be put down.','Gordamom\'s voice is the dry rustle of something very old trying to be kind. "They will wake. I cannot stop it any more. But I can choose the order, if someone tells me. A name said first is a name that wakes with a friend beside it."','"Bree\'s boy is among them. The oldest, Tam, has a daughter in the kingdom. And the youngest, a girl, does not know that her mother is gone. I can say one first. The ward will not give me longer than a breath."'],
  q:'Gordamom is waiting for a name. The ward is listening, too.',
  opts:[
   T6o('"Bree\'s boy."',{cap:{sleepers:1,hearth:1},led:{kin:1},h:'tender',flag:'boy',mem:'asked for a mother\'s son to be woken first',say:['The name goes out through the ring like a stone through still water. Somewhere under the Tree, a boy turns over and says "Mama?" and for the first time in a hundred years someone answers.','Bree is crying so hard she has to be held up by Poppy.']}),
   T6o('"The oldest. Tam. He will know what to say to the others."',{cap:{sleepers:2,crown:1},led:{trust:1},h:'steady',flag:'tam',mem:'asked for the oldest sleeper to be woken first, to lead',say:['Tam wakes slowly, like a man putting on armour. He sees you, and the gathered faces, and says in an old rough voice: "Who is in charge here?" "Nobody," you say. "Good," he says. "I never liked it."','He is a rock for the rest of the morning. It is a relief to everyone, including you.']}),
   T6o('"The youngest."',{cap:{sleepers:1},led:{mercy:1},h:'gentle',flag:'girl',mem:'asked for the youngest sleeper to be woken first',say:['The little girl wakes up and looks at everyone with enormous eyes and says "Is it morning?" Nobody can speak.','Bree takes her hand. She is not hers. She is nobody\'s, and then, for a long time afterward, she is Bree\'s.']}),
   T6o('(Say nothing.)',{silent:true,cap:{sleepers:-1},flag:'silent',mem:'could not choose, and let the ward choose',say:['You hesitate. The ward does not.','The names come in the wrong order, all at once, and for a minute there is a great deal of confused shouting. It sorts itself out. But it was not gentle, and it did not have to be.']})]}
});

/* 19. A KING'S LAST WORDS. Listen only. */
turnDef(19,{
 '*':{who:'King Eider',fmt:'listen',afterWho:'',
  pre:['The ward is broken. The litter is set down, gently, at the foot of the Old Tree. The king is awake, with his eyes open and his crown a little crooked. He cannot move his hands. He moves his eyes.','"Do not answer," he says, in a voice like paper being slowly unfolded. "There is not much of me left. I would like to say it while I still have the order of it."','"I did not keep this door because I was brave. I kept it because no one else was in the room when it needed keeping. That is all courage is, mostly. It is being the one who is left."','"If you are going to open the door, open it gently. If you are going to leave it shut, do not call it safe. Whichever you do, do it where they can see you."','"And whatever you do, be a person that someone could write a letter to."'],
  result:{cap:{sleepers:1,crown:1,hearth:1},led:{trust:1,kin:1},h:'steady',flag:'listened',mem:'listened to a king\'s last words, and did not answer'},
  after:['The king closes his eyes. He does not die. He sleeps, which is a different thing, and the first sleep he has had in a century.','You sit beside him until Mallow touches your shoulder. It is evening. The light through the burnt trees is gold.']}
});
