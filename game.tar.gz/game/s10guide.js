/* ===== ONBOARDING (v1.25) =====
   The game has a lot in it. Three things make sure a player finds it:
   1. The Field Guide (G): a checklist of everything the game offers, each with how to do it, ticked off from what you have really done.
   2. Tip cards: one small, dismissible card the first time you stand where a system is relevant (never more than one per half minute).
   3. The objective bar never goes blank: after the opening steps it points at the next unticked item in the Guide.
   Wrapped in a function; adds D10.openGuide, D10.guideItems, D10.mark. */
(function(){
'use strict';
const D10=window.D10=window.D10||{};
const ST=D10.settings||{seen:{}};

const mark=id=>{ try{ const f=g.flags.d10||(g.flags.d10={}); if(!f[id]){ f[id]=1; } }catch(e){} };
const has=id=>{ try{ return !!(g.flags.d10&&g.flags.d10[id]); }catch(e){ return false; } };
D10.mark=mark; D10.has=has;

/* ---------- what the player has done ---------- */
const hook=(name,fn)=>{ try{ fn(); }catch(e){ console.warn('guide hook',name,e); } };
hook('inv',()=>{ const o=openInv; openInv=function(){ o(); if(g.mode==='inv') mark('pack'); }; });
hook('jr',()=>{ const o=openJournal; openJournal=function(){ o(); if(g.mode==='journal') mark('journal'); }; });
hook('map',()=>{ const o=openMap; openMap=function(){ o(); if(g.mode==='map') mark('map'); }; });
hook('log',()=>{ const o=wlOpenLog; wlOpenLog=function(){ o(); if(g.mode==='clog') mark('log'); }; });
hook('brew',()=>{ const o=openBrew; openBrew=function(){ o(); if(g.mode==='brew') mark('brewOpen'); }; });
hook('fish',()=>{ const o=startFishing; startFishing=function(){ mark('fish'); return o(); }; });
hook('forage',()=>{ const o=wlForage; wlForage=function(tg){ const r=o(tg); mark('forage'); return r; }; });
hook('dig',()=>{ const o=wlDig; wlDig=function(){ const r=o(); if(g.mode==='mini'||g.mode==='dialog') mark('dig'); return r; }; });
hook('sell',()=>{ const o=sellFish; sellFish=function(b,t){ const r=o(b,t); mark('sold'); return r; }; });
hook('home',()=>{ const o=setHomeHere; setHomeHere=function(){ const r=o(); mark('home'); return r; }; });
hook('cal',()=>{ const o=openCalendar; openCalendar=function(t){ const r=o(t); mark('cal'); return r; }; });
hook('cast',()=>{ const o=spellCast; spellCast=function(n){ try{ if(spKnown().indexOf(n)>=0) mark('cast'); }catch(e){} return o(n); }; });
hook('led',()=>{ if(typeof s2led==='function'){ const o=s2led; s2led=function(k,n){ if(n>0) mark('ledger'); return o.apply(this,arguments); }; } });

/* ---------- the checklist ---------- */
const brewed=()=>{ try{ return Object.keys(BS().made).reduce((n,k)=>n+BS().made[k],0)>0; }catch(e){ return false; } };
const ranked=()=>{ try{ return Object.keys(g.rep).some(k=>rankOf(g.rep[k]||0)>=1); }catch(e){ return false; } };
const storyOn=()=>{ try{ return !!(g.story&&g.story.s2&&g.story.s2.ch); }catch(e){ return false; } };
const GUIDE=[
 ['Getting started',[
  ['move','Walk around','Arrow keys. The forest is bigger than it looks.',()=>!!g.flags.moved],
  ['talk','Talk to a townduck','Face them and press Z.',()=>!!g.flags.talked],
  ['shop','Go into a shop','Face a door and press Z.',()=>!!g.flags.shop],
  ['buy','Buy something','At a counter, press Z and spend crumbs.',()=>!!g.flags.bought],
  ['pack','Open your Pack','Press I. Number keys 1-0 hold an item, Z uses it.',()=>has('pack')],
  ['map','Open the Map','Press M. Towns you find are drawn on it.',()=>has('map')],
  ['journal','Read the Journal','Press J. Tabs sort it; click a heading to open it.',()=>has('journal')],
  ['controls','See the controls','Press ?. Every key in one place, and the settings that change them.',()=>has('helpPanel')]]],
 ['Town life',[
  ['favor','Do a favor','Townducks with a ! over their head need a hand.',()=>!!g.flags.favor],
  ['work','Take an odd job','Ask at a counter for work, or use the notice board.',()=>!!g.flags.worked],
  ['aims','Check your aims','Press K. Daily commissions and long-term aims pay crumbs, and some give perks.',()=>has('aims')],
  ['rank','Earn a reputation rank','Favors and jobs raise your standing in a town. Ranks pay out.',ranked],
  ['cal','Check a town calendar','Notice boards list events; some are mini-games.',()=>has('cal')]]],
 ['The wild',[
  ['forage','Gather a plant','Face a plant, mushroom or bush and press Z.',()=>has('forage')],
  ['log','Open the Collection Log','Press L. Everything you find is recorded; completing tiers pays.',()=>has('log')],
  ['fish','Go fishing','Hold a rod (from a shop) and press Z facing water.',()=>has('fish')],
  ['dig','Dig for treasure','Hold a shovel and press D. The ground tells you warm or cold.',()=>has('dig')],
  ['home','Set a home','On the Map press H. A compass then points you back.',()=>has('home')],
  ['nest','Build up your Nest','Beside home, press N. Crumbs buy upgrades that pay you back.',()=>has('nest')]]],
 ['Craft and trade',[
  ['brew','Brew a potion','Get a Recipe Book from a brewery, gather plants, press B.',brewed],
  ['sold','Sell a fish','Fishmongers and shops pay crumbs for your catch.',()=>has('sold')]]],
 ['Magic',[
  ['spell','Learn your first spell','The Academy in Emberwick teaches the Red path, a day at a time.',()=>{ try{ return magicDays()>=1; }catch(e){ return false; } }],
  ['cast','Cast a spell','Q and E choose, C casts. Face what you mean to cast at.',()=>has('cast')],
  ['verse','Learn a verse of the Deep Art','After the Academy: the Second Course. Verses are noticed, not given.',()=>{ try{ return verseKnown().length>0; }catch(e){ return false; } }]]],
 ['The story',[
  ['story','Follow the story','The objective bar under the window says where it is waiting.',storyOn],
  ['road','Help someone on the road','Ducks with a ! on the road ask for fish, plants, potions, crumbs, time or an honest word. Nothing is required.',()=>has('road')],
  ['ledger','Make a choice the story remembers','Kindness, honesty, pride and trust all count. Journal > Story shows how you are known.',()=>has('ledger')]]]
];
const ITEMS_FLAT=[]; GUIDE.forEach(g0=>g0[1].forEach(it=>ITEMS_FLAT.push(it)));
D10.guideItems=()=>ITEMS_FLAT.map(it=>({id:it[0],title:it[1],how:it[2],done:!!safe(it[3])}));
function safe(f){ try{ return f(); }catch(e){ return false; } }
const nextItem=()=>ITEMS_FLAT.find(it=>!safe(it[3]));
D10.nextGuide=()=>{ const n=nextItem(); return n?{id:n[0],title:n[1],how:n[2]}:null; };

/* ---------- the panel ---------- */
const stage=document.getElementById('stage');
const pan=document.createElement('div'); pan.className='panel'; pan.id='guidepan'; pan.hidden=true;
pan.innerHTML='<div class="ph"><div><h2>Field Guide</h2><div class="say" id="gdSay"></div></div><button class="hb" id="gdClose" type="button">Close (G)</button></div><div class="gdbar"><div id="gdFill"></div></div><div id="gdBody"></div><div class="pf"><span>Ticks come from what you have really done</span><span>Up/Down scroll &middot; G or X close</span></div>';
stage.appendChild(pan);
const gdBody=pan.querySelector('#gdBody'), gdSay=pan.querySelector('#gdSay'), gdFill=pan.querySelector('#gdFill');
function render(){
  gdBody.innerHTML=''; let done=0, tot=0;
  for(const [title,items] of GUIDE){
    const h=document.createElement('h3'); h.textContent=title; gdBody.appendChild(h);
    for(const it of items){
      tot++; const ok=!!safe(it[3]); if(ok) done++;
      const row=document.createElement('div'); row.className='gdrow'+(ok?' ok':'');
      const b=document.createElement('span'); b.className='gdbox'; b.textContent=ok?'✓':'○';
      const t=document.createElement('div'); const n=document.createElement('b'); n.textContent=it[1]; t.appendChild(n);
      if(!ok){ const d=document.createElement('div'); d.className='ds'; d.textContent=it[2]; t.appendChild(d); }
      row.append(b,t); gdBody.appendChild(row);
    }
  }
  gdSay.textContent=done+' of '+tot+' tried'+(done===tot?'. You have seen everything this game offers, detective.':'');
  gdFill.style.width=(tot?done/tot*100:0)+'%';
}
D10.openGuide=function(){ if(g.mode!=='play') return; g.mode='guide'; pan.hidden=false; render(); gdBody.scrollTop=0; blip(); };
function closeGuide(){ if(g.mode!=='guide') return; g.mode='play'; pan.hidden=true; blip(); }
pan.querySelector('#gdClose').addEventListener('click',closeGuide);
{
  const _p=press;
  press=function(k){
    if(g.mode==='guide'){
      if(k==='x'||k==='guide') closeGuide();
      else if(k==='down') gdBody.scrollTop+=60; else if(k==='up') gdBody.scrollTop-=60;
      return;
    }
    _p(k);
  };
}

/* ---------- the objective bar never goes blank ---------- */
{
  const _obj=objective;
  objective=function(){
    const o=_obj();
    if(/^The world never ends/.test(o)){
      const n=nextItem();
      if(n) return 'Try next: <b>'+n[1]+'</b>. '+n[2]+' <span style="opacity:.7">(G: Field Guide)</span>';
    }
    return o;
  };
}

/* ---------- tip cards ---------- */
const card=document.createElement('div'); card.className='tipcard'; card.hidden=true;
card.innerHTML='<b class="tt"></b><span class="tb"></span><small>click to dismiss</small>';
stage.appendChild(card);
let cardTimer=0, lastTip=-1e9;
card.addEventListener('click',()=>{ card.hidden=true; clearTimeout(cardTimer); });
/* a tip never sits on top of a conversation */
setInterval(()=>{ try{ if(!card.hidden&&(g.mode==='dialog'||g.mode==='choice')){ card.hidden=true; clearTimeout(cardTimer); } }catch(e){} },150);
function showTip(id,title,text){
  ST.seen[id]=1; try{ D10.saveSettings(); }catch(e){}
  card.querySelector('.tt').textContent=title; card.querySelector('.tb').textContent=text;
  card.hidden=false; lastTip=performance.now(); clearTimeout(cardTimer); cardTimer=setTimeout(()=>{ card.hidden=true; },7000);
}
const nearTile=(pred,r)=>{
  try{ const px=Math.floor(g.px/TS), py=Math.floor((g.py-2)/TS);
    for(let dy=-r;dy<=r;dy++) for(let dx=-r;dx<=r;dx++) if(pred(tileAt(px+dx,py+dy))) return true; }catch(e){}
  return false;
};
const rodHeld=()=>{ try{ return !!g.inv.rod||!!g.inv.fishingrod||Object.keys(g.inv).some(k=>/rod/i.test(k)); }catch(e){ return false; } };
const TIPS=[
 {id:'t_guide',when:()=>!!g.flags.shop,title:'Field Guide',text:'Press G any time for a checklist of everything you can do, and how.'},
 {id:'t_water',when:()=>g.scene==='world'&&nearTile(t=>t===T.WATER,2)&&!has('fish'),title:'Fishing',text:()=>rodHeld()?'Hold your rod (number keys), face the water, press Z.':'Fish live here. Shops sell rods; face water and press Z while holding one.'},
 {id:'t_plant',when:()=>g.scene==='world'&&nearTile(t=>t===T.FLOWER||t===T.BUSH||t===T.MUSH,2)&&!has('forage'),title:'Foraging',text:'Face a plant and press Z to gather it. Everything you find is logged (L) and can be brewed (B).'},
 {id:'t_brew',when:()=>{ try{ const s=BS(); return g.inv.recipebook&&Object.values(s.ing).reduce((a,b)=>a+b,0)>=3&&!has('brewOpen'); }catch(e){ return false; } },title:'Brewing',text:'You are carrying ingredients and a recipe book. Press B to brew.'},
 {id:'t_spell',when:()=>{ try{ return spKnown().length>0; }catch(e){ return false; } },title:'Spells',text:'Q and E choose a spell, C casts it. Face what you want it to touch. Tab shows every spell you know.'},
 {id:'t_verse',when:()=>{ try{ return verseKnown().length>0; }catch(e){ return false; } },title:'The Deep Art',text:'Verses act on the world in their own way: face a duck, a plant, a rock, the water. Some are quiet buffs lasting hours. One of them has a cost.'},
 {id:'t_ledger',when:()=>has('ledger'),title:'The ledger',text:'The story is keeping count of what you do: truth, mercy, pride, trust. Journal > Story shows how you are becoming known.'},
 {id:'t_night',when:()=>g.clock>=21&&g.scene==='world',title:'Night',text:'Ducks sleep late. Sit on a bench to rest or nap until morning; shops and the Academy are shut.'},
 {id:'t_more',when:()=>performance.now()>150000,title:'Menus',text:'Esc opens the pause menu. More under the top bar holds Seed, Sound, Log, Dig and Brew.'}
];
D10.tips=TIPS;
setInterval(()=>{
  if(!ST.tips||g.mode!=='play'||!card.hidden||performance.now()-lastTip<30000) return;
  for(const t of TIPS){
    if(ST.seen[t.id]) continue;
    let ok=false; try{ ok=t.when(); }catch(e){}
    if(ok){ showTip(t.id,t.title,typeof t.text==='function'?t.text():t.text); return; }
  }
},1500);
})();
