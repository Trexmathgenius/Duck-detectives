/* ===== LOOSE ENDS, TIED (v1.25) =====
   Threads the game opened and never closed, now closed:
   1. THE STRANGER'S FIRE.  The hooded storyteller in Puddlewick who sends you north. After the ending he is at the fountain again, after dark,
      and tells you who he was and why he told it wrong.
   2. THE FOUR RUMOURS (side quest, after chapter 11).  The things townsfolk whisper about from the first day:
        the violet light under the pond      -> where you began (also answers where you came from)
        the first tree behind the old mill   -> the first seam in the ward
        the parcel someone signed for        -> Mallow's letters, and who signed
        the lights that blink 3 short, 1 long -> the king's pulse
      Solving all four closes the case file and makes the Magnifying Glass mean something.
   3. LITTLE POPPY ON THE CROWN ROAD.  She is on the Red road from chapter 7; Crown road players now meet her at the barracks on the Long Night.
   Saved in g.story.x.loose. Wraps journalExtra. Adds D10.loose. */
(function(){
'use strict';
const D10=window.D10=window.D10||{};
const L=()=>{ const x=XS(); return x.loose||(x.loose={}); };
D10.loose=L;
const known=()=>{ try{ return D10.trees.stage()!=='unknown'; }catch(e){ return false; } };
const q2=()=>{ try{ return s2(); }catch(e){ return {done:{},fl:{},led:{}}; } };
const hasGlass=()=>{ try{ return isHeld('glass'); }catch(e){ return false; } };
const GL='(Through the glass, the grain of it makes a ring.)';

/* ================= 1. THE STRANGER'S FIRE ================= */
const night=()=>g.clock>=19||g.clock<5;
const ready=()=>{ const q=q2(); return !!q.ending&&(q.ending==='stay'||(q.done&&q.done.c24)); };
{
  const o={ id:'stranger_rev', name:'Hooded Duck', wx:0, wy:0, pal:{body:'#5b5470',wing:'#3f3a52',head:'#5b5470',bill:'#c9a24a'}, head:'hood', still:true, snap:2,
    when(){ if(!o._set){ try{ const t=getTown(2,0); o.wx=Math.floor(t.cx+3); o.wy=Math.floor(t.cy+2); o._set=1; }catch(e){ return false; } } return ready()&&night()&&!L().stranger; },
    mark:()=>(ready()&&night()&&!L().stranger)?'!':false,
    talk(n,done){ strangerReveal(done); } };
  S2.npc(o);
}
const TALE2=[
 {k:'teller',pages:['Sit, little one. I told you a story once, at this fountain. I told it wrong on purpose. Let me tell it right.','A hundred years ago, in the Duck Kingdom of Mallardia, there was a law: the Red Edict.']},
 {k:'anim',scene:'edict',dur:8,cap:'The Red Edict, as first written'},
 {k:'teller',pages:['The first draft said shelter. The king wrote it himself, on a wall, in the fifth fire of the war. His Council changed it to exile before the ink was dry.','Three hundred red ducks walked north to look for somewhere to be, not to fight. A boy of seven was told to light the hearth and wait for his mother. He waited eighty years.']},
 {k:'anim',scene:'gather',dur:8,cap:'Gordamom gathers the walkers'},
 {k:'teller',pages:['There was a siege. There was a wall. On the last night, a king and a drake each spoke a word. His was stay. Hers was shelter.','The king\'s word held three hundred ducks like wood. It held a door shut. It has hummed in every dark tree since.']},
 {k:'anim',scene:'tree',dur:8,cap:'Two words'},
 {k:'teller',pages:['Her word went south, over the river, to a pond the Edict could not reach. It lay there a hundred years, under the water, violet and patient.','Then one morning something woke at the edge of that pond with no past at all, and a question it did not yet know it carried.','That was you. I only had to tell the wrong story at the right fountain until you came to correct me.']}
];
function strangerReveal(done){
  const q=q2();
  seq([['Hooded Duck',['(The hood comes down. It is Mallow, in a grey cloak, with a very small fire at his feet and the look of a duck who has rehearsed this for a long time.)','"Yes. It was me. I am sorry about the cloak. It was the only way I could be a stranger in a town that had never seen a red duck."']],
    ['Hermit Mallow',['"Every few years, for longer than I like to say, I felt it: a word going out of the north, over the river, looking for somewhere to land. Gordamom\'s word. Shelter. I could not follow it. A hermit cannot leave the ward."','"But I could walk to the place it had gone. I could sit at a fountain, and tell the kingdom\'s version of the story, the wrong one, with the wrong villain, loudly, to anyone who would listen. The right ears, I thought, would not be able to stand it."']],
    ['Hermit Mallow',['"And you could not stand it. You came north to correct me."','"I did not know what you would be. I did not know you would be a detective, or yellow, or kind to a hermit on a hill. I only knew somebody would come, if I told it wrong enough."']]],
    ()=>startCutscene(TALE2,()=>{
      L().stranger=1; g.crumbs+=100; coin(); try{ q.ending&&0; }catch(e){}
      say('Hermit Mallow',['"There. That is the true one. It is not any shorter. It is only truer."','"Thank you for coming north. I have not said that to you plainly, and I wanted to say it at the place where it began."','(A hundred crumbs are tucked into your pack, wrapped in a page torn from the Book of Days.)'],()=>{ toast('The Stranger\'s Fire is closed. +100 crumbs.',4200); if(done) done(); });
    },{hint:'Press X again to skip the story'}));
}
/* a note, once, so the player knows */
setInterval(()=>{
  try{
    if(!ready()||g.mode!=='play'||g.scene!=='world') return;
    const l=L(); if(l.strangerNote) return; l.strangerNote=1;
    toast('A note in your pack, in Mallow\'s hand: "Puddlewick fountain, after dark. I owe you a story."',6500);
  }catch(e){}
},3000);

/* ================= 2. THE FOUR RUMOURS ================= */
const RUMOURS=[
 {id:'pond',title:'The violet light under the pond',hint:'the first pond, where you began'},
 {id:'mill',title:'The first tree behind the old mill',hint:'the old mill, east of Kingsbill'},
 {id:'parcel',title:'The parcel someone signed for',hint:'the edge of the Burnt Wood (after you have met Bree)'},
 {id:'blink',title:'The lights that blink three short, one long',hint:'the Siege Field, south-west of Kingsbill'}
];
const solved=id=>!!L()['r_'+id];
const nSolved=()=>RUMOURS.filter(r=>solved(r.id)).length;
function finish(id){
  const l=L(); l['r_'+id]=1; coin();
  const n=nSolved();
  if(n<4){ toast('Rumour closed ('+n+'/4): '+RUMOURS.find(r=>r.id===id).title+'.',3800); return; }
  l.rumoursDone=1; g.crumbs+=150;
  try{ ITEMS.glass.desc='Makes small clues big. Etched, now, with a ring: it shows you where the ward is thin.'; }catch(e){}
  say('Hermit Mallow',['(A note arrives, folded very small, from a hermit who has clearly been following you at a distance.)','"Four rumours. You have heard all four out. Most people let a whisper be a whisper. I have kept that list for a hundred years and never had the nerve to cross a line off."','"You have the seam-reader\'s eye now. Take this, for the glass: the next time you hold it up, you will see the thin places. Be gentle with them."','(+150 crumbs. The Magnifying Glass is etched with a ring.)'],()=>{ toast('The Four Rumours: closed.',4200); });
}
/* A: the pond */
S2.prop({id:'rum_pond',wx:0,wy:-2,glyph:'star',col:'#b388ff',mark:'!',snap:0,
  when:()=>known()&&!solved('pond'),
  use(){
    const pages=['The first pond is exactly where you left it. Under the water, a violet light, small and slow, like a coal that has stopped trying to be fire.','You kneel. It does not go out. It hums one word, and the word is in your own voice.'];
    if(hasGlass()) pages.push(GL+' It is the same ring, at the smallest size there is.');
    say('',pages,()=>seq([['',['You remember it. Not the way you remember a day. The way you remember a floor you have always stood on.','You woke here. There was no egg and no nest and no one calling. There was a pond that Puddlewick says was always there, and was not, and a word in the water that had been looking for somewhere to land for a hundred years.','The baker came down at dawn and left a scone on the bank without asking a single question. It was the first kindness anyone ever did you, and it is why you are a duck of nobody and everybody.']],
      ['',['The light brightens, once, as if it had been waiting to be recognised, and goes out.','It is not gone. It is only done. The word is in you now, and not in the water.']]],()=>{ finish('pond'); }));
  }});
/* B: the mill */
S2.prop({id:'rum_mill',wx:KX+84,wy:KY+38,glyph:'oldtree',col:'#4a3a6a',mark:'!',snap:2,
  when:()=>known()&&!solved('mill'),
  use(){
    const pages=['Behind the old mill, a single dark tree stands apart from the rest, much older than the ones in the ring. The wheel beside it is still. The water goes round it, and does not turn it.','It hums the same low note as the others, but lower, and slower, as if it were the first to learn it.'];
    if(hasGlass()) pages.push(GL+' Pale threads run from its roots under the mill and off in every direction. All of them are older than the town.');
    say('',pages,()=>seq([['',['You put your wing against the bark. You see it, the way the Old Tree showed you the siege: the night the wheel stopped.','A hundred years ago, on the seventh night, at the moment a king on a wall spoke one word, the water went still in this mill-race. The word reached here first, a long way from the wall, and this was the first tree to take it.','Every dark tree since has grown from this one\'s hum. It is not the worst of the seams. It is the first. It is the one all the others are listening to.']],
      ['',['You leave a crumb at its foot. It is the kind of gesture that is not for the tree. The wheel gives, very slightly, and does one slow turn, and stops.']]],()=>{ finish('mill'); }));
  }});
/* C: the parcel */
S2.prop({id:'rum_parcel',k:[-46,-51],glyph:'box',col:'#8a6a45',mark:'!',snap:2,
  when:()=>known()&&!!(q2().done&&q2().done.c18)&&!solved('parcel'),
  use(){
    const pages=['A small wooden post-box stands at the edge of the Burnt Wood, so old that moss has grown over the slot. It has a flag, and the flag is up.','Inside, bundled in oilcloth, are letters. Every one is addressed in the same careful hand: To Bree, at home.'];
    if(hasGlass()) pages.push(GL+' Under the address on each, a second line has been pressed into the paper, very faintly, from the other side.');
    say('',pages,()=>seq([['',['You do not open them. You do not need to. Mallow has been sending one a year, through the Kingsbill post, to the one address the post would take them to: the last place anyone had seen his mother walking.','The post-duck always said nobody lived there. She said it kindly, and delivered them anyway, and one year, she told a gossip, "someone signed for it."']],
      ['',['On the oilcloth, on the receipt, in ash: a single letter. B.','She was asleep. She was humming. In her sleep, a hundred times, she had put out a wing and signed for what her son sent, and gone back to the lullaby.','You put the flag down. It is not that the post is finished. It is that, for the first time in a hundred years, somebody has read the receipts.']]],()=>{ finish('parcel'); }));
  }});
/* D: the blinking lights */
S2.prop({id:'rum_blink',k:[-84,17],glyph:'crystal',col:'#b388ff',mark:'!',snap:2,
  when:()=>known()&&!solved('blink'),
  use(){
    const pages=['In a hollow on the edge of the Siege Field, a violet light blinks. Three short. One long. A pause. Three short. One long.','It is not a lamp. It does not flicker the way a flame does. It is regular as a pulse, and slower than yours.'];
    if(hasGlass()) pages.push(GL+' The light is not in the air at all. It is under the ground, a long way down, and it is following something.');
    say('',pages,()=>seq([['',['You sit down beside it and count. Three, one. Three, one. After a while you notice that you are breathing in time.','Somewhere a long way north, in a castle, an old king sits very still in the dark, and his heart does the same thing, because a ward is a body, and a body keeps time.']],
      ['',['Every blinking light in the forest, every one the townsfolk swear is a firefly and is not, is the king\'s pulse showing through. It is not a threat. It is the oldest lullaby there is, the one a heart sings to itself, all night, when it has been asked to hold something that is too heavy.','You tap, three short, one long, on the ground. The light misses one beat, and then, very carefully, answers.']]],()=>{ finish('blink'); }));
  }});

/* ================= 3. POPPY ON THE CROWN ROAD ================= */
{
  const P={ id:'poppy_crown', name:'Little Poppy', k:[28,33], pal:RED_PALS[3], head:null, still:true, snap:2,
    when:()=>{ const q=q2(); return !q.ending&&!L().poppy&&!s2red()&&(s2at('c15c')||s2at('c16c')||!!(q.done&&q.done.c15c)); },
    mark:'!',
    talk(n,done){
      seq([['Little Poppy',['(A very small red duck is sitting on the barracks step, with a basket of sandwiches in her lap and an expression of terrible determination. Nobody has asked her to leave. Nobody knows what to do with her.)','"I walked with the Hollow\'s envoys. They said I could come as far as the gate. I did not say which gate."','"Hermit Mallow said you would be lighting fires tonight. I brought sandwiches. Soldiers get hungry. That is also in the Book of Days."']]],()=>{
        choose('Little Poppy','Poppy holds out the basket.',['"Thank you. Sit with me while I light them."','"You should not be here. It is dangerous."','"What did Mallow tell you about me?"'],k=>{
          const l=L();
          if(k===0){ s2led('kin',1); say('Little Poppy',['She sits so close to the first fire that her feathers smell of smoke. She hands sandwiches along the line, one at a time, to men twice her height, and says "from the Hollow" each time, quite loudly.','By the fifth fire, nobody is looking at her as an enemy. A man with a spear is trying not to cry into his bread.'],()=>{ l.poppy=1; toast('Poppy is with you on the Long Night.',3200); if(done) done(); }); }
          else if(k===1){ s2led('truth',1); say('Little Poppy',['"Yes," she says, in a small clear voice. "That is why I came. Everyone is so afraid of the thing that is dangerous that nobody thinks to feed anyone."','She does not go home. She goes down the line with the basket, looking neither left nor right, and the line, one soldier at a time, takes a sandwich.'],()=>{ l.poppy=1; if(done) done(); }); }
          else { s2led('trust',1); say('Little Poppy',['"He said you ask questions that are really other questions. He said you would not tell me to go home. He said that was how he knew you were the right kind of detective."','"He did not say you would be yellow. I like it. You look like a lamp."'],()=>{ l.poppy=1; if(done) done(); }); }
        },2);
      });
    } };
  S2.npc(P);
}

/* ================= journal ================= */
{
  const _je=journalExtra;
  journalExtra=function(sec,line){
    _je(sec,line);
    try{
      if(known()){
        sec('Side quest: The Four Rumours');
        RUMOURS.forEach(r=>line((solved(r.id)?'[x] ':'[ ] ')+r.title+(solved(r.id)?'.':'  -  '+r.hint+'.')));
        if(L().rumoursDone) line('Closed. Mallow has etched the Magnifying Glass.');
      }
      if(ready()&&!L().stranger){ sec('Side quest: The Stranger\'s Fire'); line('Mallow left a note: Puddlewick fountain, after dark.'); }
      else if(L().stranger){ sec('The Stranger\'s Fire'); line('The stranger in Puddlewick was Mallow, telling the story wrong on purpose until the second word came to correct it. It was you.'); }
    }catch(e){}
  };
}
})();
