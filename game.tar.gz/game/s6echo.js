'use strict';
/* ===== ECHOES: word that reaches you a chapter or two after the choice, so you can feel the line between what you did and what it did ===== */
const e_tr=(n)=>S4.cx('t'+n);
const e_red=()=>s2red();

/* 5 - the oath */
echo('e5a',7,()=>e_tr(5)==='sworn'&&e_red(),'Warden Ruddock',['(A note is pinned to the inn board in Ruddock\'s square hand.)','"Heard the Crown knows you took the Hearth\'s thread. A rider from Kingsbill asked the gate your name twice. I told him I had never heard it. I am a poor liar. He believed me anyway, which says something about riders."']);
echo('e5b',7,()=>e_tr(5)==='sworn'&&!e_red(),'Warden Thistle',['"The Chancellor has had your signature framed. It hangs in the east passage. I walked past it twice and thought: that is a person who is about to be very sorry or very clever."','"I have not decided which. I am rooting for the second."']);
echo('e5c',7,()=>e_tr(5)==='conditional','Hermit Mallow',['(Someone has left a message for you, written on a leaf in a hand like a spider\'s.)','"A little bird says you added a line to an oath. I used to do that. It cost me my seat at the table. It was worth it. I would add it again, if I still had the pen."']);
echo('e5d',7,()=>e_tr(5)==='unsworn','Elder Cinder',['"No one claims you. Everyone watches you. I have decided that is not a coincidence."','"A person with no oath is a person nobody can threaten with its breaking. That is rarer than you think, and more dangerous, and I rather admire it."']);

/* 6 - evidence and a person */
echo('e6a',8,()=>e_tr(6)==='took'&&e_red(),'Thread-Mother Tansy',['(A red thread is tied round the gatepost in the night: three loops, and a knot.)','Three loops is for the dead. You do not know who it is for. You suspect it is for a light.']);
echo('e6b',8,()=>e_tr(6)==='left'&&e_red(),'Thread-Mother Tansy',['(Travellers on the shrine road have begun leaving crumbs at the foot of a small lamp. Someone has begun trimming its wick, nightly. Nobody has been seen doing it.)','"One for the keeping," says a thread on the gatepost, in a hand you do not know.']);
echo('e6c',8,()=>e_tr(6)==='returned'&&e_red(),'Elder Cinder',['"There was a debate about you, last night. I spoke for a quarter of an hour. I am told it was not my best speech. I am told it was the only one that mattered."','"You put it back. I would have been furious, if I were not so tired. The Wood knows what it did to deserve you, and I do not."']);
echo('e6d',8,()=>e_tr(6)==='silent'&&e_red(),'Thread-Mother Tansy',['"It asked, and you did not say. I have been turning it over. I do not think it is a bad answer. I think it is a very honest one, for someone who did not know."','"Nobody ever tells you the Wood will ask. Nobody ever says it will not wait."']);
echo('e6e',8,()=>e_tr(6)==='sheltered'&&!e_red(),'Lark',['(A folded note is slipped under your door at the inn. It smells of woodsmoke.)','"I am in a farmhouse, far east. A woman gives me soup. I have learned to milk a goat. I have a new name and I will not tell it to you. I wanted you to know the coach got there."']);
echo('e6f',8,()=>e_tr(6)==='processed'&&!e_red(),'Archivist Penna',['"Lark was let out. Thin, silent, hardly looked at me. They are working in the laundry now, under the Chancellor\'s eye. I told them you trusted the process."','"They said: I know. That is why I did not say anything."']);
echo('e6g',8,()=>e_tr(6)==='blamed'&&!e_red(),'Warden Thistle',['"There is a young man who has been trailing you for three days, and is bad at it. I am going to let him. It would be rude to pick him up."','"It is what happens when you say \'I copied it.\' I was not sure you would do it. I think I am glad."']);
echo('e6h',8,()=>e_tr(6)==='silent'&&!e_red(),'Archivist Penna',['"Lark is in the cells. For three weeks, they say. I thought you should hear it from me and not the soup-cook."','"I am not blaming you. I am not not blaming you. I am just telling you, so it is real."']);

/* 7 - home / the stopped march */
echo('e7a',9,()=>e_tr(7)==='forced'&&e_red(),'Little Poppy',['"Mallow has been very quiet. He took the letter out last night and read it again, alone, and then he put it away and did not speak till dawn."','"I do not think you meant it badly. But I think a letter is not a thing you read fast."']);
echo('e7b',9,()=>e_tr(7)==='waited'&&e_red(),'Little Poppy',['(Poppy, at the door of the inn, with a cup of tea she is holding out at arm\'s length.)','"Mallow made this for you. He does not know I know. He said it was an accident. He made it three times."']);
echo('e7c',9,()=>e_tr(7)==='paid'&&!e_red(),'Captain Halbeak',['(A parcel arrives, wrapped in a soldier\'s neckerchief. Inside is a carved wooden goose, very badly carved.)','"The men made it. It is a joke, and also a thank you. Nobody has been stealing geese. They have been carving them, which I am told is a lesser crime."']);
echo('e7d',9,()=>e_tr(7)==='refused'&&!e_red(),'Captain Halbeak',['"A soldier took a goose from a stall in Kingsbill last night. A small thing. I paid for it from my own pocket."','"I am telling you not to shame you. I am telling you because I think you will want to know that this is how it begins."']);

/* 8 - Brand and Mallow */
echo('e8a',10,()=>e_tr(8)==='court'&&e_red(),'Warden Ruddock',['"The Hearth\'s court sat on Brand today. Four hours. He said very little. At the end he stood and said: I would do it again, and I wish I had not had to."','"Cinder wept in the corridor. I did not know she could."']);
echo('e8b',10,()=>e_tr(8)==='free'&&e_red(),'Warden Ruddock',['"Someone saw Brand at the east gate three weeks ago, carrying water for a woman with a bad hip. He did not see them see him."','"I do not know what that means. I have decided to let it mean something good."']);
echo('e8c',10,()=>e_tr(8)==='kept'&&e_red(),'Warden Ruddock',['"Brand asks for nothing. He eats what you bring and says thank you. I watched him last night. He was reading the grain-sacks, just reading them, as if the words were a comfort."','"I would not trust him with a match. I would trust him with a book."']);
echo('e8d',10,()=>e_tr(8)==='kept'&&!e_red(),'Captain Halbeak',['"I have been told by a very polite patrol that no hermit has been seen in the west hills. They could not have been told anything more suspicious if they tried."','"I am not asking. I am noting that you are loyal to someone, and it is not me."']);
echo('e8e',10,()=>e_tr(8)==='told'&&!e_red(),'Hermit Mallow',['(Mallow is sitting very straight, not quite looking at you.)','"I came. I said I would. I want you to know I understand why. That is not the same as forgiving it. It is only the first half."']);

/* 10 - the promise */
echo('e10a',12,()=>e_tr(10)==='promised','Hermit Mallow',['"A man in grey asked me yesterday whether a sleeper could be woken for a purpose. A small purpose. I did not know what to say. I thought of what you told the king."','"I said no. It was the easiest no of my life. That is what a promise does. It makes the answer short."']);
echo('e10b',12,()=>e_tr(10)==='sat','Hermit Mallow',['"The king asked after you. The dark, I mean. Whatever of him is left. It said: the one who sat. It said it as a title."']);

/* 11 - what you asked the Tree for */
echo('e11a',13,()=>e_tr(11)==='nothing','Little Poppy',['"What did you ask the Tree for?" Poppy has been waiting to ask since the Burnt Wood.','"Nothing?" she says. "You asked for nothing?" She considers this with her whole face. "That is the most wasteful thing I have ever heard. I would have asked for a pony."']);
echo('e11b',13,()=>e_tr(11)==='truth','Archivist Sorrel',['"You have the look of someone who knows how it ends," Sorrel says, kindly. "I have seen it on the faces of the very old and the very recently bereaved."','"If you want to tell someone, I am here. If you do not, I will pretend I said nothing about your face."']);

/* 12 - the failed summit */
echo('e12a',13,()=>e_tr(12)==='owned','Archivist Sorrel',['"Both camps are quoting your sentence. In my square, children are playing at being you, saying: it was mine, I should have said."','"I do not think you intended to be a game. But it has made the blame lighter in the telling, and that is rarer than I thought."']);
echo('e12b',14,()=>e_tr(12)==='blamedcrown'&&e_red(),'Elder Cinder',['"The Hearth is calling you honest. It is a word that has gone a bit warm in the mouth. I would be careful of it."','"Halbeak read your sentence aloud to the lords. They did not take it well."']);
echo('e12c',14,()=>e_tr(12)==='blamedhearth'&&!e_red(),'Captain Halbeak',['"I read your sentence aloud to the lords. They took it very well, which worried me. When people take a thing well, it is because it suits them."','"I have a notion we have been used. I am not blaming you for being useful. I am noting it."']);
echo('e12d',14,()=>e_tr(12)==='room','Hermit Mallow',['"I heard what you said. About the room. I wrote it on the inside of my hat. It is the best sentence of the year."','"It was also the least satisfying. I find the two go together oftener than I would like."']);

/* 13 - the wall and the chest */
echo('e13a',15,()=>e_tr(13)==='public'&&e_red(),'Archivist Sorrel',['"Someone chalked LIAR across the new plaques overnight. I scrubbed it off at dawn. By noon someone else had chalked HONEST under it."','"It is going to be a long season of chalk."']);
echo('e13b',15,()=>e_tr(13)==='hid'&&e_red(),'Archivist Sorrel',['"The children are still reciting the old story. I stood outside the school and listened to them. They are very good. They know every word of it."','"I think of the chisel in my drawer. I take it out, sometimes, and put it back."']);
echo('e13c',15,()=>e_tr(13)==='exposed'&&!e_red(),'Lord Plume',['"The plaza was a river of paper for three days. I have never seen the Court so wet with truth."','"Mink has a position as a clerk in a smaller office. He sent me a note thanking you. I did not think he knew how."']);
echo('e13d',15,()=>e_tr(13)==='reserve'&&!e_red(),'Treasurer Mink',['(Mink, in the arcade, goes grey when he sees you. He bows, too low, and passes, too quickly.)','You are carrying something you did not mean to carry. You say nothing. It is the heaviest thing in your pocket.']);

/* 14 - fires and oaths */
echo('e14a',16,()=>e_tr(14)==='work'&&e_red(),'Warden Ruddock',['"The baker who laid the first stone brings bread every morning at six. He says nothing. He leaves it on the wall and goes."','"I have stopped trying to say thank you. He would find it embarrassing. I eat the bread."']);
echo('e14b',16,()=>e_tr(14)==='named'&&e_red(),'Elder Cinder',['"The boy from the list came to see me. He is twelve. He said: you did not make me say it twice. I do not know what he meant."','"I think he meant: thank you. I think he meant: I hate you. I think he meant both. I think that is what twelve is."']);
echo('e14c',16,()=>e_tr(14)==='told'&&!e_red(),'Captain Halbeak',['"I burned the page. It took longer than I expected. When it was done, I felt as though I had finished a long argument with a ghost, and won, and the ghost was kind about it."','"You were right to tell me. I would have been slower to forgive a lie."']);
echo('e14d',16,()=>e_tr(14)==='ask'&&!e_red(),'Captain Halbeak',['"I have polished my boots. Twice. I have rehearsed what I would say to a king. I have decided to say good morning."','"If it goes badly, I will say it was your idea."']);

/* 15 - the road */
echo('e15a',17,()=>e_tr(15)==='sent'&&e_red(),'Little Poppy',['(Poppy passes you in the lane. She says "Good afternoon," exactly, with a little nod, and does not stop.)','She is nine and a half. She has never been so formal in her life.']);
echo('e15b',17,()=>e_tr(15)==='lent'&&!e_red(),'Captain Halbeak',['"The coal came back dimmer. I noticed, and the Hearth\'s scouts noticed, and the sergeant noticed and said nothing."','"I have thought of apologising. I think you did not lend it as a favour. I think you lent it as a kindness. I shall not insult it with an apology."']);
echo('e15c',17,()=>e_tr(15)==='spark','Private Fenn',['(A letter, in clumsy handwriting, forwarded from a village you have never heard of.)','"My sergeant gave me your spark to carry home. I lit the lamp in our kitchen with it. It is still burning. My mother cried. I have not told her what it was."']);

/* 16 - someone looked away */
echo('e16a',18,()=>e_tr(16)==='letter'&&e_red(),'Spearman Orrel',['(A pie arrives at the inn, in a cloth, with a note that says only "Orrel\'s mother. For the letter.")','It is a very good pie. It has a pastry lantern on top, and the lantern has a flame, and the flame is pastry too.']);
echo('e16b',18,()=>e_tr(16)==='stood'&&!e_red(),'Warden Ruddock',['"Cinder said: she told the Hollow\'s line the truth about Ruddock, and Ruddock was there. We spent a quarter of an hour in silence. It was the longest quarter of an hour of my life."','"I think I am no longer the man who is afraid of being known."']);

/* 17, 18 - the mirror, the name */
echo('e17a',19,()=>e_tr(17)==='setpride','Hermit Mallow',['"You are quieter, since the wood. Not worse. Different. I think you left something there, and I think it will turn out to have been the right thing to leave."','"I used to be proud of a great many things. It took the wood to teach me which ones were load-bearing."']);
echo('e18a',20,()=>e_tr(18)==='boy','Bree',['(Bree, at the foot of the Old Tree, holding a boy\'s hand and not letting go.)','"He said \'Mama.\' He said it to me. I am not his mother. I am no one\'s mother. I have decided to be his anyway."']);
echo('e18b',20,()=>e_tr(18)==='silent','Gordamom',['"The ward chose the order. It is not a criticism. I want you to know that I would have understood either way."','"But I hope, next time, that someone says a name."']);
