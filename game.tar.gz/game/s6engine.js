'use strict';
/* ===== TURNS (v1.20) =====
   Every big chapter now ends with a TURN: a want, an obstacle, a cost, and a consequence that is written down.
   What the turns add up to is called STANDING: how much each of four parties trusts you. Standing decides which endings
   the Tree will let you speak. Nothing here is shown as a number. */

const S6st=()=>{ const s=S4st(); if(!s.s6) s.s6={cap:{crown:0,hearth:0,mallow:0,sleepers:0},lost:{},stand:{},echoed:{},q:[],turn:{}}; return s.s6; };
const S6={
  cap(k,n){ const c=S6st().cap; c[k]=(c[k]||0)+n; },
  get(k){ return S6st().cap[k]||0; },
  lose(n){ S6st().lost[n]=1; },
  lost(n){ return !!S6st().lost[n]; },
  flag(tag){ return S4.cx(tag); }
};

/* ---------- the machinery that runs a turn ---------- */
const TURNS={};
const turnDef=(num,d)=>{ TURNS[num]=d; };
const turnRoute=id=>{ const m=/^c\d+([rc])$/.exec(id); return m?m[1]:'*'; };
const turnEligible=id=>{ const m=/^c(\d+)([rc]?)$/.exec(id); if(!m) return false; const n=+m[1]; return n>=5&&n<=19&&!!TURNS[n]&&!(TURNS[n].skip&&TURNS[n].skip()); };

function timedChoose(who,text,texts,cb,sec,defIdx){
  let iv=0;
  choose(who,text,texts,i=>{ clearInterval(iv); cb(i); },texts.length-1);
  const gc=g.choice; let n=sec;
  iv=setInterval(()=>{
    if(g.choice!==gc||g.mode!=='choice'){ clearInterval(iv); return; }
    n--; try{ el.dText.textContent=text+'   [ '+n+' ]'; }catch(e){}
    if(n<=0){ clearInterval(iv); pickChoice(defIdx); }
  },1000);
}

function turnApply(tag,o){
  if(o.cost){ if(o.cost.crumbs) g.crumbs=Math.max(0,g.crumbs-o.cost.crumbs); if(o.cost.hours) advanceClock(o.cost.hours); }
  if(o.item) delInv(o.item);
  if(o.gain&&o.gain.crumbs) g.crumbs+=o.gain.crumbs;
  const hb=Object.assign({},S4st().h);
  for(const k in (o.cap||{})) S6.cap(k,o.cap[k]);
  for(const k in (o.led||{})) s2led(k,o.led[k]);
  if(o.h&&S4st().h[o.h]===hb[o.h]) S4st().h[o.h]++;
  if(o.lost) S6.lose(o.lost);
  if(o.set) o.set();
  S4.setcx(tag,o.flag,o.mem);
}
const turnOK=o=>{
  const c=o.cost||{};
  if(c.crumbs&&g.crumbs<c.crumbs) return false;
  if(o.item&&!g.inv[o.item]) return false;
  if(o.req&&!o.req()) return false;
  return true;
};
const turnLabel=o=>o.t+(o.cost&&o.cost.crumbs?'  ('+o.cost.crumbs+' crumbs)':'')+(o.cost&&o.cost.hours?'  (about '+o.cost.hours+(o.cost.hours===1?' hour)':' hours)'):'');

function runTurn(id,done){
  const num=s2num(id), d=TURNS[num]; if(!d){ done(); return; }
  const rt=turnRoute(id), v=d[rt]||d['*']; if(!v){ done(); return; }
  const tag='t'+num, who=v.who||d.who||'';
  const pre=typeof v.pre==='function'?v.pre():v.pre;
  if(v.fmt==='listen'){
    say(who,pre,()=>{
      turnApply(tag,v.result);
      say(v.afterWho===undefined?who:v.afterWho,v.after,()=>{ coin(); done(); });
    });
    return;
  }
  const all=(typeof v.opts==='function'?v.opts():v.opts).filter(turnOK);
  say(who,pre,()=>{
    const pick=k=>{
      const o=all[k]; turnApply(tag,o);
      say(o.who||who,o.say,()=>{ coin(); done(); });
    };
    const texts=all.map(turnLabel), q=v.q||d.q;
    if(v.fmt==='timed'){
      const di=all.findIndex(o=>o.silent);
      timedChoose(who,q,texts,pick,v.sec||12,di<0?all.length-1:di);
    } else choose(who,q,texts,pick,all.length-1);
  });
}
{
  const _fin=S2.finish;
  S2.finish=function(id,msg){
    const q=s2(); q.turn=q.turn||{};
    if(turnEligible(id)&&!q.turn[id]){ q.turn[id]=1; try{ runTurn(id,()=>_fin(id,msg)); }catch(e){ console.error(e); _fin(id,msg); } return; }
    _fin(id,msg);
  };
}

/* ---------- echoes: word that arrives a chapter or two after the choice ---------- */
const ECHOES=[];
const echo=(id,at,when,who,pages)=>ECHOES.push({id,at,when,who,pages});
const echoCool={t:0};
function echoDue(){
  const s=S6st(), cur=s2cur(); if(!cur) return null;
  const n=s2num(cur);
  for(const e of ECHOES){
    if(s.echoed[e.id]||n<e.at) continue;
    let ok=false; try{ ok=e.when(); }catch(err){}
    if(ok) return e;
    if(n>=e.at+3) s.echoed[e.id]=-1;
  }
  return null;
}
function echoDeliver(force){
  const e=echoDue(); if(!e) return false;
  const s=S6st(); s.echoed[e.id]=1; s.log=s.log||[]; s.log.push({who:e.who,t:e.pages.join(' ')}); if(s.log.length>8) s.log.shift();
  echoCool.t=45; say(e.who,e.pages); return true;
}
{
  const _su=storyUpdate;
  storyUpdate=function(dt){
    _su(dt);
    if(echoCool.t>0){ echoCool.t-=dt; return; }
    if(g.mode!=='play'||g.scene!=='world'||!g.story||!g.story.s2) return;
    echoDeliver();
  };
  /* word also arrives the moment a chapter opens, and always at the quiet hours */
  const _b=S2.begin;
  S2.begin=function(id,skip){
    _b(id,skip);
    let tries=0; const go=()=>{ if(g.mode!=='play'||g.scene!=='world'){ if(++tries<30) setTimeout(go,2000); return; } echoCool.t=0; echoDeliver(); };
    setTimeout(go,7000);
  };
  const _journalX=journalExtra;
  journalExtra=function(sec,line){
    _journalX(sec,line);
    try{ const L=(S6st().log||[]).slice(-3); if(L.length){ sec('Word on the Road'); L.forEach(e=>line(e.who+': '+e.t.replace(/[()]/g,'').slice(0,150),'jdim')); } }catch(e){}
  };
}

/* ---------- endings the Tree will let you speak ---------- */
function endingsOpen(){
  const keeper=!!s2().keeper;
  const cr=S6.get('crown'), he=S6.get('hearth'), ma=S6.get('mallow'), sl=S6.get('sleepers');
  const o={wake:sl>=5, door:Math.min(cr,he)>=2&&cr+he>=6, keep:keeper&&ma>=3, stay:true};
  const n=['wake','door','keep'].filter(k=>o[k]).length;
  if(n===0){ const best=[['wake',sl],['door',cr+he]].sort((a,b)=>b[1]-a[1])[0][0]; o[best]=true; o.mercy=best; }
  return o;
}
const CLOSED={
  wake:'The sleepers do not trust you to wake them. Nobody asked them, and they remember who did not.',
  door:'Neither town will hold a door for you. You made promises to one of them, and the other has not forgotten.',
  keep:'The table is not set for you. Mallow has stopped expecting a third chair to be filled.'
};
{
  const _fc=finalChoice;
  finalChoice=function(S){
    const open=endingsOpen(), keeper=!!s2().keeper;
    const opts=[], fn=[];
    if(open.wake){ opts.push('"It is safe now." Wake them all, at once.'); fn.push(()=>endWake(S)); }
    if(open.door){ opts.push('"It will be safe." Rewrite the ward as a door, and keep it.'); fn.push(()=>endDoor(S)); }
    if(keeper&&open.keep){ opts.push('"It will be tended." Stay, and keep the table.'); fn.push(()=>endKeep(S)); }
    opts.push('"Let it stay." Leave it as it is.'); fn.push(()=>endStay(S));
    const closed=['wake','door'].concat(keeper?['keep']:[]).filter(k=>!open[k]);
    const hint=closed.length?[closed.map(k=>CLOSED[k]).join(' ')]:[];
    const ask=()=>choose('The Old Tree','The Tree waits. All of them wait. "Is it safe?"',opts,k=>fn[k](),opts.length-1);
    const al=(typeof S5allies==='function')?S5allies():[];
    const first=al.length?['(Before it asks, the clearing seems to take a breath, and the people in it step a little nearer.)','Close enough to hear you breathe: '+al.slice(0,6).map(a=>a.n).join(', ')+(al.length>6?', and others.':'.')]:['(The clearing is wide, and the only footsteps in it are yours.)'];
    const pre=hint.length?['(There were ways to ask it that you did not earn.)'].concat(hint):null;
    S6st().closedNow=closed;
    say('The Old Tree',first,()=>{ if(pre) say('The Old Tree',pre,ask); else ask(); });
  };
}
