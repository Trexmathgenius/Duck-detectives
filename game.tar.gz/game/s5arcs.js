'use strict';
/* ===== ARCS (v1.19.1) =====
   Three people who change because of you: Poppy, Brand, Halbeak.
   Who you are opens and closes doors. Complications come back. The ending is the people who stand with you. */
const A5=()=>{ const s=S4st(); return s.arc||(s.arc={}); };
const cxo=ids=>{ for(const i of ids){ const v=S4.cx(i); if(v!==undefined) return v; } return undefined; };
const B7=()=>S4.cx('b7'), B9=()=>S4.cx('b9'), B11=()=>S4.cx('b11'), B15=()=>S4.cx('b15'), B17=()=>S4.cx('b17'), B19=()=>S4.cx('b19');
const c13v=()=>cxo(['c13r','c13c','c13k']), c14v=()=>cxo(['c14r','c14c','c14k']), c15v=()=>cxo(['c15r','c15c','c15k']), c16v=()=>cxo(['c16r','c16c']);
const s5gate=(k,n)=>(S4st().h[k]||0)>=(n||2);

/* ---------- the breath fire, rebuilt: visitors first, then the hour, then what the hour left behind ---------- */
const BX={};
BREATH.x16={title:'The Banked Fire',sub:'The wrongest person you know is standing at the edge of the light.',who:'Keeper Brand',
  intro:['The fire has burned low. Someone has been standing at the edge of its light for some time.','It is Keeper Brand. His hood is down. In one hand he holds a lantern, in the other a flask of lamp-oil, and he has the look of a man who has already decided.'],
  scene:[['Keeper Brand',['"Do not speak yet. Let me say it, and then say what you like."','"The Tree is waking. I can feel it in my teeth. Three hundred people who have been dreaming for a century are about to be told it was a dream. And behind them, the Hollow is waiting to ask for its price."','"I mean to put out the lantern line tonight. The ten along the road, one by one. A road in the dark is a road nobody walks. It buys the sleepers another year. It buys me time to find a way to make it safe."','"I know what it sounds like. I know what I am. I am asking you to look at me for a minute before you decide."']]],
  q:'Brand does not lower the flask. His hand is shaking.',
  opts:[['"Tell me. All of it. I will not interrupt."','tender','candid','He sits, heavily, on the log across the fire. He tells you about the ash coming up around his sister\'s hand, and the eleven years he has spent making sure it would not happen again, and how it has made him into something that frightens even him.\n\nWhen he is done he looks lighter and older. "Thank you," he says. "Nobody has ever let me finish."'],
         ['"Put the flask down, Brand."','proud','steady','He does, slowly, as if setting down a child. "You are right to stop me," he says, and then, quietly, "and you are the third person who has said so. None of you said why I wanted to."'],
         ['"You may be right. Show me where to begin."','guarded','proud','He stares at you. Then he nods, and the two of you walk the line together and put out the first four lamps. It is very quiet work.\n\nAt the fifth you stop. Neither of you says why. "I am glad," he says, "not to have done this alone."']],
  tail:['He leaves with the lantern, and the flask, and a different set to his shoulders.','Whatever he does tomorrow, you will not be able to say you did not know who he was.']};
S2.ch.x16={route:'both',theme:'dark',numLabel:'A QUIET HOUR',title:BREATH.x16.title,sub:BREATH.x16.sub,intro:BREATH.x16.intro,recap:'Brand, at the edge of the light.',start(){ s2set(0); },
  obj(s){ return ['Meet <b>Keeper Brand</b> at the campfire near the road.'][s]||''; }};
BX.x16=(k,next)=>{ A5().brand=['heard','stopped','helped'][k]; next(); };

/* b9: the seed. Ruddock's list has a name on it that you will meet again */
BX.b9=(k,next)=>{
  say('Warden Ruddock',['(After a long while:) "The first name on the list is Brand\'s sister. Ilse. She went up to the ward-stone on a bad night to hold it by hand. I was the one on watch. I let her go."','"He has never once blamed me. I would almost rather he had."'],()=>{
    A5().ilse=1; next(); });
};
/* b7/b17: Halbeak, twice */
BX.b17=(k,next)=>{
  const h1=B7();
  say('Captain Halbeak',h1==='2'?['"At the first fire I asked whether you would have followed the order. You said you would ask. I have been asking, all season. It has not got easier. It has got truer."']
    :h1==='1'?['"At the first fire you said you would have refused. I told myself I envied it. I think, tonight, that I was afraid of it."']
    :['"You said everyone would. I wanted to believe that. I am no longer sure it is kind to."'],()=>{ A5().hal=(k===0?'back':k===1?'front':'needed'); next(); });
};
/* b11 -> b15 -> b19: Poppy */
BX.b11=(k,next)=>{ A5().p1=k; next(); };
BX.b15=(k,next)=>{
  const p1=B11();
  if(p1==='1'){ say('Little Poppy',['(She is quiet for a while. The drawing of the duck-or-potato is in her lap.)','"I was going to tell you something. Then I thought: you said it depends on the thing. So I decided it does not depend on you."','"Do not look sad. It is a good decision. I made it myself."'],()=>{ A5().p2='alone'; next(); }); return; }
  const warm=p1==='2';
  say('Little Poppy',(A5().poppyHome?['(She is more formal with you than she used to be. She has not forgotten who decided for her.)']:[]).concat(warm?['(She has been waiting to say it. She says it fast, looking at the fire.)','"Papa did not leave in a hurry. He left in a grey cloak. He is one of the Hands. I saw him carry ash to the Archive, the night before Brand\'s rite. He took his boot off to carry it, in case it left a mark. That is why it was by the door."','"I mended it so he would have something to come back for. I know that is stupid."']
    :['(She does not look up from the fire.)','"You said tell someone. So I am telling you. Papa is in the Hands. I saw him with the ash. I have not told Mama and I will not."','"Please do not say it is not my fault. Everyone says that. It makes it sound like I thought it was."']),()=>{
    choose('Little Poppy','She looks at you for the first time. "What do I do?"',['"We tell Halbeak. Together, tonight."','"It stays between us. For now."','"Write to him. Tell him you know, and that you are not angry."'],q=>{
      A5().p2=['tell','keep','write'][q]; S4st().h[['candid','guarded','tender'][q]]++;
      say('Little Poppy',[['"Tonight? Okay. Okay. You hold my hand and I will say the words."','"Okay. A secret is heavy when there are two of you. It is lighter. It is a different kind of heavy."','"I will write it. I will not send it until I mean it. That is allowed."'][q]],()=>{ coin(); next(); });
    },2);
  });
};
BX.b19=(k,next)=>{
  const p2=A5().p2, p1=B11();
  const end=p2==='write'?'letter':p2==='tell'?'told':p2==='keep'?'carry':'alone';
  A5().poppyEnd=end;
  const L={letter:['(Poppy finds you at the foot of the Tree. She has a scrap of paper, folded very small.)','"He wrote back. One line. It says: Tell her the boot was always hers. I do not understand it. I understand it completely."'],
    told:['(Poppy is holding Halbeak\'s hand, which Halbeak is clearly not used to.)','"They have a plan for Papa. Not a punishment. A room, and a lamp, and someone to ask him questions. Halbeak says that is how it begins, with a room."'],
    carry:['(Poppy sits against the Tree with her knees up.)','"I have not told anyone. I am carrying it, the way you do a full cup. Do not bump me. Walk beside me, if you want."'],
    alone:['(Poppy is not at the fire. She is at the far edge of the clearing, small, facing the other way.)','You sit a little way off. Neither of you speaks. After a time she shifts, a few inches nearer, and then does not move again.']}[end];
  say('Little Poppy',L,()=>{ next(); });
};

/* ---------- visitors: the things you left behind come back ---------- */
const S5V=(key,who,intro,q,opts,ign)=>({key,who,intro,q,opts,ignore:ign});
const o_=(t,o)=>Object.assign({t},o);
function visitorFor(id){
  if(id==='b13'){
    const v=c13v();
    if(v==='bribed') return S5V('v13','Trader Bellis'.split('|').concat([cxP('#b09a4a','#7a6a2a'),'hat']),['(Bellis again, a crate under his arm, as pleased as a cat.)','"My dear detective. The arrangement has been so convenient. There is a little more grain, you see. Forty crumbs more, and the first sixty are a matter between friends."'],'Bellis smiles. The smile has teeth behind it now.',[
      o_('Pay the forty. Keep it quiet.',{cost:{crumbs:40},habit:'guarded',led:{lie:1},flag:'paid',mem:'paid a man to keep your first mistake quiet',say:['"Always a pleasure." He tips the crate. You walk away with the feeling of a hook in your sleeve.']}),
      o_('Give back the sixty. End it.',{cost:{crumbs:60},habit:'candid',led:{truth:1},flag:'ended',mem:'handed back a bribe and told the man to do his worst',say:['He weighs the purse. "Foolish," he says. "Honourable. I always mix those up." He leaves you alone, which is not the same as leaving you well.']}),
      o_('Tell the Watch about both of you.',{habit:'proud',led:{pride:1},flag:'both',mem:'turned in yourself and the man who bribed you',say:['The captain looks at you for a long time. "Most people would have kept the sixty." You do not argue. You are fined, and so is he.']})]);
    if(v==='fair') return S5V('v13','Trader Bellis'.split('|').concat([cxP('#b09a4a','#7a6a2a'),'hat']),['(Bellis is sitting on an empty crate. The crate has nothing in it.)','"You were right. I sold at a fair price and the whole street kissed my hand. I have never made so little in my life and slept so well. I do not understand it."','"I need a loan. Thirty crumbs. I have a plan for a bakery. Do not laugh."'],'Bellis looks astonishingly young.',[
      o_('Lend him thirty.',{cost:{crumbs:30},habit:'gentle',led:{mercy:1},flag:'lent',mem:'lent a former profiteer the price of a bakery',say:['"A bakery. I will call it Fair Price." He winces. "I will call it something better."']}),
      o_('Offer to bake the first batch with him.',{cost:{hours:2},habit:'tender',led:{kin:1},flag:'baked',mem:'burnt a first batch of bread with a reformed trader',say:['It is terrible bread. You eat the whole loaf. He watches you do it, and cries a little, and pretends it was the smoke.']}),
      o_('"No. You can earn it."',{habit:'proud',led:{pride:1},flag:'refused',mem:'told a reformed trader to earn it himself',say:['"Of course," he says. "Of course. That is fair." It is the first time the word has sounded like a punishment.']})]);
    return null;
  }
  if(id==='b15'){
    const v=c14v();
    if(v==='promised') return S5V('v15','Pip, a lantern-lighter'.split('|').concat([cxP('#c9a24a','#8a6a2a'),null]),['(Pip is holding the taper but not lighting anything.)','"You said he would be back. It has been a month. Mama says you should not have said it. I told her you meant it."','"Did you mean it?"'],'Pip is trying very hard to be fair.',[
      o_('"No. I should not have said it. I am sorry."',{habit:'candid',led:{truth:1},flag:'owned',mem:'told a child the promise had been a lie, and was sorry',say:['She nods, slowly. "Thank you." She lights the last lantern, fast, the way she was going to anyway. "I will not tell Mama you said it. She would say I told you so."']}),
      o_('"Soon. I am sure of it."',{habit:'guarded',led:{lie:1},flag:'doubled',mem:'promised a child again, knowing',say:['Her whole face lights, and it is the worst thing you have seen all year. "Soon," she says. "I will put it on the lantern."']}),
      o_('Sit with her and wait for him.',{cost:{hours:2},habit:'tender',led:{kin:1},flag:'waited',mem:'sat on a ladder with a child, waiting for someone who was not coming',say:['You sit. You do not say anything. At the end of two hours she leans on your arm and says "He is not coming, is he?" and you say "I do not know," and that is the best you have.']})]);
    if(v==='lit'||v==='told') return S5V('v15','Pip, a lantern-lighter'.split('|').concat([cxP('#c9a24a','#8a6a2a'),null]),['(Pip has come up the road with a taper and a small clay lamp.)','"I made this. It is for the fire. It is not for anything. I thought you would like to have a lantern that is only yours."'],'Pip holds it out in both wings.',[
      o_('Take it, and light it with her.',{habit:'tender',led:{kin:1},flag:'lit',mem:'lit a small lamp with the child who lights the street lanterns',say:['The lamp is lopsided. It burns very well. She says it will go with you, whatever you do next. You say it will.']}),
      o_('Take it, and tell her it is the best gift you have had.',{habit:'gentle',led:{mercy:1},flag:'kind',mem:'told a child her gift was the best you had had',say:['It is true. You are not sure why.']})]);
    if(v==='ignored') return S5V('v15','Pip, a lantern-lighter'.split('|').concat([cxP('#c9a24a','#8a6a2a'),null]),['(Pip is on her ladder at the far end of the street. She is lighting the last lantern fast. She is not looking for anyone.)','You think of the evening you walked past her.'],'She has not seen you. You could still say something.',[
      o_('Walk down and apologise.',{cost:{hours:1},habit:'candid',led:{truth:1},flag:'apologised',mem:'went back to apologise to a child you had walked past',say:['She does not say it is all right. She says "I know." Then she hands you the taper, and the last lantern is yours.']}),
      o_('Let it be.',{habit:'guarded',flag:'let',mem:'saw a child alone on a ladder and did not go down',say:['You stand a while. Then you go. It is one of the quieter cowardices, and it will come to you at night.']})]);
    return null;
  }
  if(id==='b17'){
    if(s5gate('proud')&&cxo(['c9r','c9c'])!=='x') return S5V('v17','Warden Ruddock'.split('|').concat([cxP('#7a6a5a','#4a3a2a'),'helm']),['(Ruddock is standing in the road with his arms crossed, between you and the sentry post.)','"You have given three orders this week. In a voice you did not use in the spring. I have followed two. I will not follow the third."','"I am telling you to your face because I have lost enough to politeness."'],'Ruddock does not move. He is not angry. He is afraid, and so is clear.',[
      o_('"I am giving the order. Stand aside."',{habit:'proud',led:{pride:1},flag:'pulled',mem:'pulled rank on a man who had lost eleven people',say:['He stands aside. He is very correct about it. He does not look at you for the rest of the night, and by morning you are certain you will not see his face again at the Tree.']}),
      o_('"Tell me why."',{habit:'candid',led:{truth:1},flag:'asked',mem:'asked a stubborn man why, and listened',say:['He tells you. It is not about the order. It is about the voice. "The last person who spoke to me like that sent my brother up the wall," he says. You have not been talking to him as a friend. You begin again.']}),
      o_('"You are right. I will ask, not tell."',{cost:{hours:1},habit:'steady',led:{trust:1},flag:'yielded',mem:'let a hard friend tell you that you were wrong',say:['He exhales, and for the first time all season the wall in his shoulders comes down. "Thank you," he says. "I will take the third order. Now that it is a request."']})]);
    if(s5gate('gentle')) return S5V('v17','Captain Halbeak'.split('|').concat([BLUE_PAL,'helm']),['(Halbeak is waiting at the edge of the firelight, hands behind his back.)','"A word. I have watched you be kind to a great many people this season. I have not once watched you refuse anyone."','"Tomorrow someone will ask you for something that costs more than you can pay. I need to know you will be able to say no."'],'Halbeak is not accusing you. He is asking you to be ready.',[
      o_('"Teach me how."',{cost:{hours:2},habit:'steady',led:{trust:1},flag:'taught',mem:'asked a soldier to teach you how to refuse',say:['It takes two hours and is mostly silence. He teaches you one sentence. "No. And I am still here." You practise it on the dark until it stops sounding like a lie.']}),
      o_('"Kindness is the plan."',{habit:'proud',led:{pride:1},flag:'held',mem:'told a soldier that kindness was a plan',say:['"It is a great deal of faith," he says. "I will keep the sword nearby, in case it turns out to be a dream." He means it kindly, which is the hardest way he could have meant it.']}),
      o_('"I have refused before. You were not watching."',{habit:'candid',led:{truth:1},flag:'claimed',mem:'told a captain you could say no',say:['He thinks about this. "Then I am glad to have been inattentive." He gives you a salute. It is half a joke, and entirely sincere.']})]);
    const f=c15v();
    if(f==='freed'||f==='stood') return S5V('v17','Private Fenn'.split('|').concat([cxP('#7a8a9a','#5a6a7a'),'helm']),['(A young soldier comes out of the dark, helmet under his arm, a little thinner than you remember.)',f==='freed'?'"I went home. I ploughed the field. I buried my helmet and dug it up again. I came back because I could not stop thinking: someone let me go, and I do not know their name."':'"The kitchens are warm. The captain is not unkind. I wrote to my mother that a stranger stood beside me. She wants to meet you. She is bringing a cake."','"I am going to stand at the back tomorrow. I thought you should know there is one more of us."'],'Fenn is trying not to cry, again.',[
      o_('"Stand with me, then."',{habit:'steady',led:{trust:1},flag:'stands',mem:'asked a soldier to stand with you at the Tree',say:['He salutes, badly. It is the best salute you have ever seen.']}),
      o_('"Go home. You have done enough."',{habit:'gentle',led:{mercy:1},flag:'home',mem:'sent a soldier home before the last morning',say:['"Yes," he says. "Yes, I think I would like that." He goes down the road, lighter, and you are left with the feeling of having done something small and very right.']})]);
    return null;
  }
  if(id==='b19'){
    if(s5gate('steady')) return S5V('v19','Tam, a soldier'.split('|').concat([cxP('#6a7a8a','#4a5a6a'),'helm']),['(Tam sits at one side of the fire, and Bree at the other. They have both come to you at once, and neither knows the other has.)','Tam: "I cannot sleep. I keep seeing the Reeds. Sit with me?"','Bree: "I cannot sleep. I keep seeing my boy\'s face. Sit with me?"'],'You are the one people lean on. You can only lean one way tonight.',[
      o_('Sit with Tam.',{cost:{hours:2},habit:'steady',led:{trust:1},flag:'tam',mem:'sat up with a soldier who could not sleep, and let a mother wait',say:['You sit with Tam. Across the fire, Bree watches for a while, and then lies down. She does not say anything. In the morning you notice she has not slept.']}),
      o_('Sit with Bree.',{cost:{hours:2},habit:'tender',led:{kin:1},flag:'bree',mem:'sat up with a mother who could not sleep, and let a soldier wait',say:['You sit with Bree. Across the fire, Tam turns his back, and the line of his shoulders says what he does not. In the morning he is polite, and no more.']}),
      o_('Ask them to sit together.',{habit:'candid',led:{truth:1},flag:'both',mem:'asked two tired people to sit with each other',say:['They look at each other. Neither moves. Then Bree says "Come here, soldier," and Tam does, stiffly. They do not talk. It is not your hour any more.']})]);
    const o=c16v();
    if(o==='river') return S5V('v19','Baker Orrin'.split('|').concat([cxP('#c9a06a','#8a6a3a'),'cap']),['(Orrin stands at the edge of the light with an empty apron.)','"I threw the loaf. Half the queue stopped talking to me. The other half said it was the bravest thing they had seen. I do not know which half to believe."','"Tell me I did the right thing. I cannot ask the river."'],'Orrin has come a long way to ask.',[
      o_('"No. But you did what I told you."',{habit:'candid',led:{truth:1},flag:'owned',mem:'told a baker the loaf in the river was your mistake',say:['"Thank you," he says. "I think I needed to be told it was somebody\'s." He looks lighter.']}),
      o_('"You did the right thing."',{habit:'gentle',led:{mercy:1,lie:1},flag:'soothed',mem:'told a baker he had done right when you were not sure',say:['He nods and nods. "Good. I will say that." He goes. He does not look sure either.']}),
      o_('Buy a loaf from him for the queue.',{cost:{crumbs:40},habit:'steady',led:{trust:1},flag:'bought',mem:'bought a loaf for a queue that never got one',say:['You buy forty crumbs of bread. It is shared out at dawn, all down the line, one piece at a time, counted aloud. No one is turned away.']})]);
    return null;
  }
  return null;
}
/* the fire, rebuilt */
S2.prop({id:'breath_fire',k:[-76,-26],glyph:'candle',col:'#ff9d2e',when:()=>/^[bx]\d+$/.test(s2cur())&&!!BREATH[s2cur()],mark:'!',use(){
  const id=s2cur(), b=BREATH[id]; if(!b) return;
  const q=s2(); q.vis=q.vis||{};
  if(b.prep) b.prep();
  if(!q.vis[id+'e']&&typeof echoDeliver==='function'&&echoDeliver()){ q.vis[id+'e']=1; setTimeout(()=>{ const t=setInterval(()=>{ if(g.mode==='play'){ clearInterval(t); S2.props.get('breath_fire').use(); } },300); },100); return; }
  const run=b.run?(()=>b.run(()=>{ coin(); S2.finish(id,'A quiet hour, kept.'); })):()=>{
    seq(b.scene,()=>{
      choose(b.who,b.q,b.opts.map(o=>o[0]),k=>{
        const o=b.opts[k]; const h=S4st().h; h[o[1]]++; if(o[2]) h[o[2]]++;
        S4.setcx(id,String(k),null);
        const fin=()=>{ coin(); S2.finish(id,'A quiet hour, kept.'); };
        say(b.who,[o[3]].concat(b.tail),()=>{ if(BX[id]) BX[id](k,fin); else fin(); });
      },b.opts.length-1);
    });
  };
  const v=!q.vis[id]?visitorFor(id):null;
  q.vis[id]=1;
  if(v) cxTalk(v,run); else run();
}});
{
  const _sn=s2next;
  s2next=function(id){
    const q=s2();
    if(id==='b15'&&!q.done.x16){ q.xnext=_sn(id); return 'x16'; }
    if(id==='x16') return q.xnext||null;
    return _sn(id);
  };
}

/* ---------- Brand, wrong in a way you understand, and what happens to him ---------- */
const brandNow=()=>s2at('c22')||s2at('c23')||s2at('c24');
const BFATE={shelter:'tend the lamps',trial:'answer to the Hearth',exile:'walk the Ash Road',witness:'speak at the council'};
npc3('brand_a','Keeper Brand',{k:[-62,-58]},cxP('#7a2a22','#4a1a14'),'wizard',()=>brandNow()&&!!s2().route,n=>{
  const f=k3('brandFate'), bd=A5().brand;
  if(f){ say('Keeper Brand',[{shelter:'"I tend the lamps at the Tree now. Nobody asks me to speak. I find I do not have much to say that is not already in the flame."',trial:'"The Hearth is deciding. I wait. It is strange to wait for others to say what I am."',exile:'"I walk the road, the long one, the one I tried to stop. It is much longer than I thought."',witness:'"I said it. All of it. In front of them. I thought I would be struck dumb. I was only very tired."'}[f]],done_(n)); return; }
  const intro=bd==='heard'?['(He is sitting on the same root he sat on at the fire. He looks up, and does not look away.)','"You are the only one who let me finish. I have not known what to do with that."']
    :bd==='helped'?['(He does not look up. He is holding a lamp, unlit.)','"We put out four lamps. I have thought about the fifth every night since. I think the only reason I stopped was you. I do not know whether to thank you or to be afraid of what I might have done alone."']
    :bd==='stopped'?['(He turns his back as you approach. He is angry, in the way of a man who knows he was wrong.)','"You stopped me. I was grateful for about an hour. Now I am only ashamed. Say what you came to say."']
    :['(He has aged ten years in a season. He is sitting on a root with his hood down, and does not stand.)','"I will tell you why, once. My sister was one of the ones the ward took before the three hundred. I held her hand while the ash came up. I decided no one would pay it again. It was not hatred. It was a hand I could not hold twice."'];
  seq([['Keeper Brand',intro]],()=>{
    const opts=[], fates=[];
    if(bd!=='stopped'){ opts.push('"Stay. Tend the lamps. That is the sentence."'); fates.push('shelter'); }
    opts.push('"Let the Hearth hear it, and decide."'); fates.push('trial');
    opts.push('"Walk the Ash Road. See what you tried to stop."'); fates.push('exile');
    if(bd==='heard'){ opts.push('"Stand at the council. Say what you told me."'); fates.push('witness'); }
    choose('Keeper Brand','Brand waits, not looking up. "What happens to me is not mine to ask."',opts,k=>{
      const fate=fates[k]; k3('brandFate',fate);
      const hk={shelter:'gentle',trial:'steady',exile:'proud',witness:'candid'}[fate], lk={shelter:'mercy',trial:'trust',exile:'pride',witness:'truth'}[fate];
      S4st().h[hk]++; s2led(lk,1);
      S4.setcx('brand',fate,{shelter:'gave a grieving man a lamp to tend',trial:'let a man answer for himself',exile:'sent a man to walk his own mistake',witness:'asked a man to say his reasons aloud'}[fate]);
      say('Keeper Brand',[{shelter:'"A lamp. Yes. I know how to keep one."',trial:'"Yes. That is fair. I was never sure I had the right to be fair to myself."',exile:'"Long. Yes. I will count the posts."',witness:'"Yes. I will say it. Whatever they do after, I will have said it."'}[fate]],()=>{ coin(); done_(n)(); });
    },opts.length-1);
  });
},()=>!k3('brandFate')?'!':null);
npc3('whistle_a','Clerk Whistle',{k:[-57,-58]},cxP('#8a8a9a','#5a5a6a'),'cap',()=>brandNow()&&!!s2().route,n=>{
  const f=k3('whistle'), bd=A5().brand;
  if(f){ say('Clerk Whistle',[f==='agreed'?'"The Chair is quiet, then. I will write it as a mercy. It is, in its way."':f==='sat'?'"I have not signed. I have also not stopped being afraid. It turns out those are different things."':'"The Chair is not quiet. It will not like that. I will make a note that it is the right thing, and unwelcome."'],done_(n)); return; }
  const lines=['(A thin clerk in an even thinner coat, holding a ledger he does not open.)','"The Quiet Chair does not want the sleepers harmed. We want them asleep. A quiet town is a safe town, and a safe town is the thing I keep for my daughter."'];
  if(bd==='helped') lines.push('"I hear you were with Brand at the fire. He was doing with oil what I do with paper. I was glad, for an hour. I thought: at last, a person who understands."');
  lines.push('"Brand does it with fire. I would do it with a form, a stamp, a signature. Nobody cries. Everyone is relieved. It is the same wish. Tell me where I am wrong."');
  say('Clerk Whistle',lines,()=>{
    const opts=['"You are wrong. They are people, and they are awake."','"You are not wrong to be afraid. You are wrong to hide it."','"Sign it, then. If you can look at them while you do."'], tags=['refused','refused','agreed'];
    if(s5gate('steady')){ opts.push('Say nothing. Sit with him until he has finished being afraid.'); tags.push('sat'); }
    if(s5gate('proud',3)&&!s5gate('tender')){ opts.push('"The Chair will be dissolved. I will see to it."'); tags.push('dissolved'); }
    choose('Clerk Whistle','He has asked honestly.',opts,k=>{
      const t=tags[k]; k3('whistle',t);
      S4st().h[['candid','tender','guarded','steady','proud'][Math.min(k,4)]]++;
      if(t==='refused') s2led('truth',1); if(t==='sat'||t==='dissolved'){ s2led(t==='sat'?'trust':'pride',1); }
      S4.setcx('whistle',t,{refused:'told a clerk his quiet was a kind of fire',agreed:'dared a clerk to sign away the sleepers',sat:'sat with a frightened clerk until the fear passed',dissolved:'declared a clerk\'s whole faction finished'}[t]);
      say('Clerk Whistle',[[ '"I do not enjoy being told. I would enjoy being wrong more."','"Afraid. Yes. That is the word. I have not said it in front of anyone."','"Look at them. Yes. That is a different form entirely. I did not know there was one."','(He is silent a long while. When he speaks, his voice is wet.) "Nobody has ever stayed. They always want me to be argued out of it."','(He stares at you.) "You cannot. Not alone. You have made an enemy, and I am the polite one."'][k] ],()=>{ coin(); done_(n)(); });
    },opts.length-1);
  });
},()=>!k3('whistle')?'!':null);

/* ---------- who you are changes what the council costs ---------- */
{
  const _p=S2.persuade;
  S2.persuade=function(d){
    try{
      if(d&&d.who==='The Council Stone'&&!d.__s5){
        d.__s5=1;
        if(s5gate('proud',3)) d.need=(d.need||4)+1;
        if(A5().hal==='back'||A5().hal==='needed') d.need=Math.max(2,(d.need||4)-1);
        if(k3('brandFate')==='witness') d.rounds[0].opts.push({t:'"Brand will speak for the sleepers, and for himself."',p:2,say:['Halbeak and Cinder look at the man by the roots. Brand rises, and says it, plainly. When he sits, there is a silence of a different kind.']});
        if(k3('whistle')==='refused'||k3('whistle')==='sat') d.rounds[1].opts.push({t:'"Whistle has agreed the Chair will not stand in the way."',p:2,say:['A thin man in a thin coat stands, and nods once. "The Chair will not stand in the way," he says. It is the bravest sentence of his career.']});
        if(A5().poppyEnd==='told'||A5().poppyEnd==='letter') d.rounds[2].opts.push({t:'"Poppy, who knows what it is to wait for someone, should light it."',p:2,say:['Poppy looks up, appalled, and thrilled. "Me? Both of them? At once?" She does. It takes two tries.']});
      }
    }catch(e){ console.error(e); }
    return _p(d);
  };
}

/* ---------- the ending is who stands with you ---------- */
const S5allies=()=>{
  const out=[], a=A5();
  const add=(n,w,on)=>{ if(on) out.push({n,w}); };
  add('Halbeak',{wake:'put his sword in the ash and held a cup with both hands',door:'went through the door first, and called it a poor strategic decision',keep:'sat on the third chair, and was bad at it',stay:'stood at the gate until you were out of sight'},a.hal==='back'||a.hal==='needed');
  add('Ruddock',{wake:'stood the last watch with his lantern lowered',door:'closed the door behind you, gently, with both hands',keep:'brought a spade and planted something',stay:'put his hand on the Tree, once, and took it away'},B9()!==undefined&&cxo(['v17'])!=='pulled'&&S4.cx('v17')!=='pulled');
  add('Poppy',{wake:'lit the first lantern, twice',door:'walked in first, holding her father\'s boot',keep:'kept a chair for him',stay:'did not say goodbye, and did not need to'},a.poppyEnd==='letter'||a.poppyEnd==='told');
  add('Brand',{wake:'held the lantern steady while the sleepers woke',door:'kept the lamp at the door lit through every night',keep:'tended the lamps in the ring of chairs',stay:'watched from the edge of the wood, as he always has'},['shelter','witness'].indexOf(k3('brandFate'))>=0);
          return out.concat(typeof S6extra==='function'?S6extra():[]);
};
{
  const _ec=epiCard;
  epiCard=function(label,title,sub,pages,theme,cb){
    try{
      if(label==='EPILOGUE'&&Array.isArray(pages)){
        const kind={'It is safe now.':'wake','It will be safe.':'door','It will be tended.':'keep','Let it stay.':'stay'}[title];
        const al=kind?S5allies():[];
        let page;
        if(!kind) page=null;
        else if(al.length===0) page='Nobody stood beside you at the end. You did what you chose, and it was yours entirely, and the clearing was very large.';
        else if(al.length===1) page='One person stood beside you, and it was enough, and it was never going to be a crowd. '+al[0].n+' '+al[0].w[kind]+'.';
        else page='Those who stood with you: '+al.slice(0,4).map(a=>a.n+' '+a.w[kind]).join('; ')+'. '+(al.length>4?'And others, whom there is not room to name.':'');
        if(page) pages=pages.concat([page]);
        const pe=A5().poppyEnd, pl={letter:'Poppy keeps her father\'s one-line letter in the boot. She has stopped squinting.',told:'Poppy\'s father sleeps in a room with a lamp, and asks questions of the ceiling, and she visits on Sundays.',carry:'Poppy still carries what she told only you. She is lighter than she was, though she would never say so.',alone:'Poppy did not tell anyone. Some secrets are a cup, some are a stone. She holds hers carefully.'}[pe];
        if(pl) pages=pages.concat([pl]);
      }
    }catch(e){ console.error(e); }
    return _ec(label,title,sub,pages,theme,cb);
  };
}
/* the Tree asks who is with you */
{
  const _fc=finalChoice;
  finalChoice=function(S){
    try{
      const al=S5allies();
      if(al.length){
        say('The Old Tree',['(Before it asks, the clearing seems to take a breath, and the people in it step a little nearer.)','Behind you: '+al.slice(0,5).map(a=>a.n).join(', ')+'.'],()=>_fc(S));
        return;
      }
      say('The Old Tree',['(The clearing is wide, and the only footsteps in it are yours.)'],()=>_fc(S));
      return;
    }catch(e){ console.error(e); }
    _fc(S);
  };
}
/* recall lines for the new arcs */
rc(['Captain Halbeak'],'rh1',()=>B7()==='2'&&B17()===undefined,['"I keep thinking about what you said at the fire. Ask. I have started asking. I am a poor beginner."']);
rc(['Elder Cinder','Captain Halbeak'],'rpoppy',()=>A5().poppyEnd==='told',['(Halbeak is holding a small hand, awkwardly. He lets go when he sees you.) "She told me. It was her idea. She was braver than I have been."']);
rc(['Warden Ruddock'],'rilse',()=>!!A5().ilse&&!!k3('brandFate'),['"Brand sent me a note. One line. It said: I should have forgiven you first. I have it in my pocket. I do not know what to do with it."']);
