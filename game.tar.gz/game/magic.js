'use strict';
/* ===== THE EMBER ART =====
   Every red duck is a witch or a wizard. It is not a secret; it is their culture, taught to every child.
   Charms and wands are sold in Emberwick's shops, but are only trinkets until you have been trained.
   You become one of them the slow way: twelve days at the Academy, the Umbral Wood, a blind elder with a recipe,
   and a potion that does not wash off. Or you walk away, and carry a secret to the king. */

/* ---------- items ---------- */
const MAGIC={
  emberwand:{day:2,name:'Ember Wand',price:18,desc:'A wand of blackened oak with a glowing tip. It remembers fire.',untrained:'The wand hums in your wing and does nothing.'},
  lumenorb:{day:3,name:'Lumen Orb',price:14,desc:'A glass orb with a captive glimmer inside. It lights a circle, never through walls.',untrained:'The orb flickers and goes dark again.'},
  gustcharm:{day:4,name:'Gust Charm',price:12,desc:'A feather tied with silver thread. Fog and smoke obey it. Stone does not.',untrained:'The feather twitches and goes limp.'},
  wardcharm:{day:5,name:'Ward Charm',price:16,desc:'A small red knot of thread and ash. It turns curses, never swords.',untrained:'The knot is warm, and entirely silent.'},
  runestone:{day:7,name:'Rune Stone',price:22,desc:'A flat grey stone with a single mark. A word the stone already knows.',untrained:'The mark glows briefly, as if puzzled by you.'},
  seekerbeetle:{day:8,name:'Seeker Beetle',price:20,desc:'A brass clockwork beetle with a glowing eye. It points to what you seek, if you know what you seek.',untrained:'The beetle spins and spins and will not settle.'}
};
for(const id in MAGIC){ const m=MAGIC[id]; ITEMS[id]={name:m.name,price:m.price,desc:m.desc,use:'magic',nogift:true}; }
ITEMS.grimoire={name:'Apprentice Grimoire',desc:'A slim book bound in red. It fills in as you learn. Examine it to read.',use:'grimoire',nogift:true};
ITEMS.colorbook={name:'The Chromatic Recipe',desc:'The blind elder\'s recipe for the potion that changes a duck\'s colour. Examine it to read.',use:'colorbook',nogift:true};
Object.assign(RICON,{
  emberwand:(R,C,E)=>{ R(3,11,9,2,'#4a2c18'); R(10,9,2,2,'#4a2c18'); R(11,6,2,3,'#ff9d2e'); R(11,4,2,2,'#fff3c4'); R(5,5,1,1,'#ffd166'); R(8,3,1,1,'#ffd166'); },
  lumenorb:(R,C,E)=>{ C(8,8,6.5,'rgba(255,230,160,0.35)'); C(8,8,5,'#e8f4ff'); C(8,8,3,'#ffe9a8'); C(8,8,1.4,'#fff'); },
  gustcharm:(R,C,E)=>{ R(7,2,2,3,'#c0c8d0'); E(8,9,3,6,'#e8f0ff'); R(8,4,1,10,'#8a96a4'); R(5,8,2,1,'#a8b6c8'); R(10,10,2,1,'#a8b6c8'); },
  wardcharm:(R,C,E)=>{ C(8,8,5.5,'#7a1f1f'); C(8,8,3.6,'#c0392b'); R(7,3,2,10,'#ffb347'); R(3,7,10,2,'#ffb347'); C(8,8,1.2,'#fff3c4'); },
  runestone:(R,C,E)=>{ E(8,9,6.5,5,'#6a6e78'); E(8,8,5.5,4,'#8a8e98'); R(7,5,2,7,'#7affc8'); R(5,7,6,2,'#7affc8'); },
  seekerbeetle:(R,C,E)=>{ E(8,9,5,3.5,'#c9a24a'); R(3,7,2,1,'#6a5a2a'); R(11,7,2,1,'#6a5a2a'); R(3,11,2,1,'#6a5a2a'); R(11,11,2,1,'#6a5a2a'); C(8,5,2,'#6a5a2a'); C(8,5,1,'#7affc8'); R(7,8,2,2,'#ffd166'); },
  grimoire:(R,C,E)=>{ R(3,2,10,12,'#7a2a4a'); R(3,2,2,12,'#4a1430'); R(6,5,6,1,'#e8d8ff'); R(6,8,5,1,'#e8d8ff'); R(8,10,2,3,'#a98aff'); R(8,9,2,1,'#fff'); },
  colorbook:(R,C,E)=>{ R(3,2,10,12,'#3a2a5a'); R(3,2,2,12,'#1c1230'); R(7,4,4,2,'#c0392b'); R(7,7,4,2,'#ffd84a'); R(7,10,4,2,'#3a9ad9'); }
});
STOCK.rcandle=['vigil','lumenorb','tinderbox','lantern'];
STOCK.rforge=['lantern','emberwand','runestone','flint'];
STOCK.rloom=['scarf','redthread','wardcharm','bowtie'];
STOCK.rtoy=['tinkerbeetle','seekerbeetle','marbles','ducky'];
STOCK.rherb=['warmtonic','spiceseed','healleaf','gustcharm'];
function magicDays(){ return (g.story.school&&g.story.school.days)||0; }
function magicTrained(id){ return magicDays()>=MAGIC[id].day; }

/* ---------- outcasts ---------- */
{
  const _addRep=addRep;
  addRep=function(t,n){
    const st=g.story;
    if(st&&st.isRed&&t&&!t.isRed&&n>0){ n=Math.random()<0.2?1:0; if(!n) return; }
    _addRep(t,n);
  };
  const _drawDuck=drawDuck;
  drawDuck=function(c,x,y,dir,phase,moving,pal,o){
    if(g.story&&g.story.isRed&&pal&&pal.body==='#ffd84a') pal=RED_PALS[0];
    return _drawDuck(c,x,y,dir,phase,moving,pal,o);
  };
}

/* ---------- red adults: wizards all ---------- */
{
  const M=[
    [['Warden is a title. Wizard is a trade. I am a very good wizard and an extremely tired warden.','My ward on the palisade is older than the palisade.']],
    [['I light the dawn lamps with a word. When I was small I lit my own tail. We do not discuss this.']],
    [['I do not run. I step between two moments. It is quicker. It is also illegal, if the Warden is looking.']],
    [['The Hearth is fed by the Art, not by wood. A log an hour is a ritual. The fire is the one that burns itself.']],
    [['At nine I could light a candle at the other end of the March. Now I can barely light my pipe. Magic is a muscle, and mine has sat down.']],
    [['I mended my husband\'s coat with a word, the day he did not come home. The coat still hangs there. Whole.']],
    [['I want to learn the Gust. Not for the Wood. For the sky. They say a good gust can lift a duck. I would like to be lifted.']],
    [['Beets, you ask? A growth charm. Half the beets in the town are charmed. The other half are too proud to admit it.']],
    [['Night-watch needs a good Lumen. Mine has a flaw: it does not light the places I am afraid to look.']],
    [['They say you can buy charms at the forge. Do not use them yet. A charm in untrained wings is a sneeze with sparks.']]
  ];
  for(let i=0;i<M.length;i++) PERSONAS[RP0+i].push(M[i][0]);
  const _extraNpcs=extraNpcs;
  extraNpcs=function(list){ _extraNpcs(list); };
}
const MAGIC_TOASTS=['A red duck lights her lantern with a snap of her fingers.','Somewhere a broom sweeps a doorstep by itself. Nobody is holding it.','A child makes a spark in her wing, looks at it proudly, and drops it in the water barrel.','A shopkeeper mends a torn awning with a whisper and a twirl of the wing.','A kettle on a windowsill whistles, and is told to stop, and does.','Two red ducks argue about a spell. The argument is conducted entirely in small flames.'];
{
  const _drawWorld=drawWorld;
  drawWorld=function(c,W,H,kd,camX,camY,time){
    _drawWorld(c,W,H,kd,camX,camY,time);
    if(g.scene!=='world') return;
    const vw=W/kd, vh=H/kd, ox=Math.round((camX-vw/2)*kd)/kd, oy=Math.round((camY-vh/2)*kd)/kd;
    const px=Math.floor(g.px/TS), py=Math.floor((g.py-2)/TS);
    let did=false;
    const begin=()=>{ if(!did){ c.setTransform(kd,0,0,kd,-ox*kd,-oy*kd); did=true; } };
    for(const n of g.npcs){
      if(!(n.red||n.redKid)) continue;
      const k=(n.idx||0)*1.7+time*1.3, s=Math.sin(k);
      if(s<0.3) continue;
      begin();
      const sc=n.scale||1, x=n.x+Math.cos(k*2)*9*sc, y=n.y-(26+(s-0.3)*14)*sc;
      c.fillStyle='rgba(255,226,150,'+(0.5+0.5*s).toFixed(2)+')'; c.fillRect(x-1.5,y-0.5,3,1); c.fillRect(x-0.5,y-1.5,1,3);
    }
    if(uwIn(px,py)){
      begin();
      const lumen=g.time<lumenUntil, r=lumen?230:78;
      const cx=g.px, cy=g.py-14;
      const gr=c.createRadialGradient(cx,cy,r*0.2,cx,cy,r*2.6);
      gr.addColorStop(0,'rgba(8,4,24,0)'); gr.addColorStop(0.4,'rgba(8,4,24,'+(lumen?0.1:0.45)+')'); gr.addColorStop(1,'rgba(8,4,24,0.86)');
      c.fillStyle=gr; c.fillRect(ox,oy,vw,vh);
      if(lumen){ circ(c,cx,cy,r*0.9,'rgba(255,236,170,0.07)'); }
      else circ(c,cx,cy,34,'rgba(122,255,200,0.05)');
    }
    if(did) c.setTransform(1,0,0,1,0,0);
  };
}
let lumenUntil=0;

/* ---------- the Academy of the Ember Arts ---------- */
function schoolOpen(){ return !!(g.story&&g.story.ch3Met)&&g.clock>=8&&g.clock<17; }
INTLAYOUT.rschool=[
  'WWWWWWWWWWWWW',
  'WBBB.....BBBW',
  'W.....V.....W',
  'W.SS.....SS.W',
  'W.SS.....SS.W',
  'W.....O.....W',
  'W.SS.....SS.W',
  'W.SS.....SS.W',
  'W...........W',
  'WWWWWWDWWWWWW'
];
LIBINT.rschool='VBSO';
function enterRSchool(){
  const st=g.story;
  if(!st.ch3Met){ say('',['The Academy doors are barred. A card on the door: "STUDENTS OF THE EMBER ONLY." Through a window, a classroom of very small wizards stops mid-spell to stare at you.']); return; }
  if(!schoolOpen()){ say('',['The Academy is shut. A card: "LESSONS FROM 8 IN THE MORNING UNTIL 5 IN THE EVENING. NO FIREBALLS IN THE CORRIDOR."']); return; }
  const sc=getRed().specials.find(b=>b.type==='school');
  LIBEXIT.rschool=[sc.doorX-KX,sc.doorY-KY];
  enterInterior('rschool');
  toast('The Academy of the Ember Arts. Chalk, candle wax, and faint static.',3200);
}
const SPELLS=[
  ['Spark','Ask for warmth, and wait quietly.'],['Kindle','The Ember Wand: remember fire, do not command it.'],['Lumen','The Lumen Orb: light that never lies about walls.'],
  ['Gust','The Gust Charm: push fog and smoke; stone does not listen.'],['Ward','The Ward Charm: turn curses, never swords.'],['Mend','Mend what is broken, not what is gone.'],
  ['Stone','The Rune Stone: break a boulder along its own seams.'],['Seek','The Seeker Beetle: it points to what you truly seek.'],['Bind','Hold loosely, like a ribbon on a wrist.'],
  ['Frost','Cold is the other half of warmth.'],['Veil','A veil does not hide you. It makes you uninteresting.'],['Hearthsong','Every spell is a verse. Sing the whole song.']
];
const LESSONS=[
  ['Magic is not shouting. It is asking, and then being quiet enough to hear the answer.','Warmth first; light follows. Snap your wing, think "warm", and wait. Do not blow on it. Do not quack at it. Wait.'],
  ['The wand does not make fire. It remembers fire. Point it at what is meant to burn: a wick, a thorn, a tangle of dead wood. Never at what you love.','"Kindle" is the word. Say it as a question.'],
  ['Light is a promise that the dark is not empty. Hold the Lumen Orb in the open wing, and say "show".','It lights a circle around you. It will not light through a wall. It will light a shadow that should not be there.'],
  ['Wind is a shy animal. Face the thing you want gone, the charm in your wing, and say "away" softly.','Fog and smoke obey a gust. Stone and iron do not. Do not be the duck who gusts a boulder.'],
  ['A ward is a door that only opens inward. Hold the charm to your heart, breathe out, think of home.','It turns curses. It does not turn sticks, or swords, or thrown bread.'],
  ['Mend what is broken, not what is gone. Match the thread to the cloth. Match the cloth to the person.','Slowly. A mend done quickly is a tear, waiting.'],
  ['The rune is a word the stone already knows. Press it to the face of the boulder, and ask.','A stone that is asked breaks along its own seams. A stone that is struck breaks your wing.'],
  ['The beetle remembers where light comes from. Ask it "where is the heart of this place", and it turns.','It points to what you seek only if you know what you seek. Do not ask it two things at once.'],
  ['To bind is to hold, not to hurt. Loosely, like a ribbon on a wrist.','A binding made in anger slips. A binding made in care stays until it is thanked.'],
  ['Cold is the other half of warmth. It slows, it stills, it lets you cross water.','Never freeze what you cannot thaw. Always know how you will bring it back.'],
  ['A veil does not make you vanish. It makes you uninteresting. Think: nothing here to see.','It fails the moment you look at someone to check if it worked.'],
  ['Every spell you have learned is a verse. Today, we sing the whole song: show the way, kindle the flame, ward the door, ask the stone.','Above all, remember the Great Saying: Keep. Kindle. Bank. A fire shared does not shrink.']
];
function shuf(opts,cI){
  const idx=opts.map((_,i)=>i);
  for(let i=idx.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [idx[i],idx[j]]=[idx[j],idx[i]]; }
  return {o:idx.map(i=>opts[i]),c:idx.indexOf(cI)};
}
const V='Mistress Vesper';
function schoolProgress(){ const st=g.story; st.school=st.school||{days:0,last:0}; return st.school; }
/* each lesson is a problem the teacher conjures, solved with the spell itself (see s9acad.js) */
function runTask(n,after){ pracStartStd(n,after); }
function schoolLesson(){
  const st=g.story, sp=schoolProgress(), n=sp.days+1;
  if(n>12){ say(V,['You have finished. Go and find the old elder in the Umbral Wood.']); return; }
  if(sp.last===g.day){ say(V,['One lesson a day. The Art is not a feast. Come back tomorrow.']); return; }
  if(g.clock>=12.5){ say(V,['Lessons begin at eight and must begin by noon. It is too late for today. Come back tomorrow, early.']); return; }
  if(n===1&&!g.inv.grimoire){ addItem('grimoire'); }
  const sc=SPELLS[n-1];
  seq([['',['Lesson '+n+' of 12: '+sc[0]+'.']],[V,LESSONS[n-1]]],()=>{
    fade(1.0); advanceClock(3);
    const attempt=()=>{
      runTask(n,ok=>{
        if(ok){
          sp.days=n; sp.last=g.day; coin(); advanceClock(0.5);
          const learned=[];
          for(const id in MAGIC) if(MAGIC[id].day===n) learned.push(MAGIC[id].name);
          const tail=learned.length?'You can now use the '+learned.join(' and ')+'.':'';
          if(n<12){
            say(V,['Passed. '+sc[0]+' is yours. '+(12-n)+' lessons remain.',tail||'Well done.'],()=>{ toast('Lesson '+n+' of 12 complete. '+(tail||'New spell: '+sc[0]),4200); });
          } else graduate();
        } else {
          choose(V,'Try the task again?',['Try again','Leave it for now'],k=>{ if(k===0){ advanceClock(0.5); attempt(); } },1);
        }
      });
    };
    attempt();
  });
}
function graduate(){
  const st=g.story; st.magicTrained=1; st.umbral=1;
  seq([
    [V,['Twelve days. Twelve spells. Twelve small humiliations, I hope, and several large pleasures.','You have done what a duckling does in twelve years. I will not say you did it as well. I will say you did it as hard.']],
    [V,['Take this. It is not a degree. It is a hat. Wear it, or not; the hat does not mind.','You are, in the way the Art cares about, one of us. The rest is only feathers.']],
    [V,['The old elder lives in the heart of the Umbral Wood, north-east of the town. The trail leaves the Ember Road at the east end. Take everything you have bought. The wood will ask you to use it.','He keeps the recipe of the Chromatic Potion. He does not enjoy visitors. Ask him anyway.']]
  ],()=>{ toast('You have completed the twelve days. The Umbral Wood awaits.',5200); });
}
function schoolTalk(){
  const st=g.story, sp=schoolProgress();
  const menu=()=>{
    const opts=['Attend today\'s lesson ('+Math.min(12,sp.days+1)+' of 12)','What have I learned?','About the Academy','Leave'];
    choose(V,sp.days>=12?'You have graduated. What can I do for you?':'Welcome back to the Academy. What would you like?',opts,k=>{
      if(k===0) schoolLesson();
      else if(k===1){ if(!sp.days) say(V,['Nothing, yet. That is the proper way to begin.']); else say(V,SPELLS.slice(0,sp.days).map(s=>s[0]+': '+s[1])); }
      else if(k===2) say(V,['The Academy of the Ember Arts. Founded the first winter, in a tent. Twelve years of schooling for a red duckling; twelve days for an outsider, because the Elders have decided to find out if the Art is a thing of blood or of heart.','I have a theory. I shall not share it before you have passed.']);
    },3);
  };
  if(!sp.days&&!st.schoolMet){
    st.schoolMet=1;
    seq([[V,['So. You are the yellow one. I have been told you will be my student. I have also been told to treat you exactly like the others.','I shall treat you exactly like the others, and then a little harder, so they do not talk.']],[V,['Twelve days. One lesson a day, from eight until noon. A task at the end of each: easy on the first, moderately difficult on the last. Pass them, and the Elders will think better of you.']]],()=>{ if(st.path!=='red'){ st.path='red'; } menu(); });
  } else menu();
}
function schoolInteract(tg){
  const ch=tg.ch;
  if(ch==='V'){ schoolTalk(); return; }
  if(ch==='B'){ say('',[pick(['Shelves of slim grimoires, each with a small child\'s name on the spine. One has a burn mark in the shape of a very small beak.','"Sixty Charms for Cold Mornings." "Sparks and Their Consequences." "An Introduction to Hats."','A row of practice wands, labelled by age. The youngest is the size of a toothpick and has been bitten.'])]); return; }
  if(ch==='S'){ say('',[pick(['A desk carved with initials. One set reads "P + F", burned with a tiny flame.','A desk with a small, shy fire still smoking in the inkwell. It will be put out by somebody.','Someone has doodled a very large hat on the blotter. The hat is winking.'])]); return; }
  if(ch==='O'){
    const sp=schoolProgress();
    say('',[sp.days?'A pedestal with a crystal orb, humming softly. It shows you something: a spiral of tiny lights, one for each spell you have learned ('+sp.days+' of 12).':'A pedestal with a crystal orb. It is dark. It seems to be waiting for you to be somebody.']);
  }
}
{
  const _libInteract=libInteract;
  libInteract=function(tg){ if(g.libKind==='rschool'){ schoolInteract(tg); return; } _libInteract(tg); };
  const _areaName=areaName;
  areaName=function(){ if(g.scene==='lib'&&g.libKind==='rschool') return 'Academy of the Ember Arts'; return _areaName(); };
  const _drawInterior=drawInterior;
  drawInterior=function(c,W,H,kd,time){ if(g.scene==='lib'&&g.libKind==='rschool'){ drawRSchool(c,W,H,kd,time); return; } _drawInterior(c,W,H,kd,time); };
}
function drawRSchool(c,W,H,kd,time){
  const vw=W/kd, vh=H/kd, RWp=LIBW*TS, RHp=LIBH*TS;
  const fx=vw>=RWp?(RWp/2-vw/2):Math.max(0,Math.min(RWp-vw,g.px-vw/2)), fy=vh>=RHp?(RHp/2-vh/2):Math.max(-30,Math.min(RHp-vh+10,g.py-14-vh/2));
  const ox=Math.round(fx*kd)/kd, oy=Math.round(fy*kd)/kd;
  c.setTransform(kd,0,0,kd,-ox*kd,-oy*kd);
  for(let ty=0;ty<LIBH;ty++) for(let tx=0;tx<LIBW;tx++){
    const ch=libCh(tx,ty), px=tx*TS, py=ty*TS;
    if(ch==='W'){ rect(c,px,py,TS,TS,'#4a3a68'); rect(c,px,py+TS-4,TS,4,'#2a2040'); rect(c,px+4,py+4,TS-8,2,'rgba(255,255,255,0.08)'); continue; }
    rect(c,px,py,TS,TS,((tx+ty)&1)?'#6a5a7c':'#605070'); rect(c,px,py+15,TS,1,'rgba(0,0,0,0.14)');
    if(ch==='D') rect(c,px+2,py+4,TS-4,TS-4,'#7b4a22');
  }
  rect(c,3.5*TS,2.6*TS,6*TS,5.8*TS,'rgba(122,90,214,0.20)');
  c.strokeStyle='rgba(216,200,255,0.35)'; c.lineWidth=1.5; c.beginPath(); c.arc(6.5*TS,5.5*TS,2.3*TS,0,6.283); c.stroke();
  for(let k=0;k<6;k++){ const a=k*1.047+time*0.15; spark(c,6.5*TS+Math.cos(a)*2.3*TS,5.5*TS+Math.sin(a)*2.3*TS,2.5,'rgba(216,200,255,0.8)'); }
  for(const wx of [2.2,10.2]){ rect(c,wx*TS,5,28,34,'#2a2040'); rect(c,wx*TS+3,8,22,28,'#1a1038'); for(let k=0;k<4;k++) spark(c,wx*TS+6+((k*11)%16),12+((k*7)%20),1+((k+Math.floor(time*2))%2),'#fff3c4'); }
  for(let ty=0;ty<LIBH;ty++) for(let tx=0;tx<LIBW;tx++){
    const ch=libCh(tx,ty), px=tx*TS, py=ty*TS;
    if(ch==='B'){ rect(c,px,py,TS,TS,'#5b4430'); rect(c,px+2,py+2,TS-4,TS-4,'#3b2b1e'); const sp=['#7a5ad6','#c0392b','#e8d8ff','#d9b84a','#4a8a6a']; for(let r=0;r<3;r++){ rect(c,px+2,py+3+r*9+8,TS-4,1.5,'#8a6a45'); for(let k=0,x=px+3;k<6;k++){ const w=3+((r*3+k)%3); rect(c,x,py+3+r*9,w,8,sp[(r*2+k)%5]); x+=w+0.5; } } }
    else if(ch==='S'){ rect(c,px+2,py+8,TS-4,TS-8,'#7a5a38'); rect(c,px+2,py+8,TS-4,4,'#a8804e'); rect(c,px+2,py+TS-3,TS-4,3,'#3a2012'); rect(c,px+8,py+3,16,6,'#e8d8ff'); }
    else if(ch==='V'){ rect(c,px-16,py+6,TS+32,TS-4,'#5a3a6a'); rect(c,px-16,py+6,TS+32,4,'#8a6aa0'); miniDuck(c,px+16,py+14,'#a82a2a','#4a3a7a'); rect(c,px+9,py-6,14,10,'#4a3a7a'); rect(c,px+13,py-14,6,10,'#4a3a7a'); circ(c,px+16,py-15,2,'#ffd166'); }
    else if(ch==='O'){ rect(c,px+8,py+14,16,16,'#6a6e78'); rect(c,px+6,py+28,20,4,'#4a4e58'); const f=0.6+0.4*Math.sin(time*3); circ(c,px+16,py+10,12,'rgba(160,130,255,'+(0.2*f).toFixed(2)+')'); circ(c,px+16,py+10,8,'#a98aff'); circ(c,px+14,py+8,3,'rgba(255,255,255,0.7)'); }
  }
  /* a couple of small students, practising */
  for(const [dx,dy,col] of [[2.9,3.8,'#c0392b'],[10.2,6.8,'#d9503f']]){ miniDuck(c,dx*TS+14,dy*TS+4,col,'#4a3a7a'); spark(c,dx*TS+10+Math.sin(time*2+dx)*6,dy*TS-12-Math.abs(Math.sin(time*3+dx))*8,2,'#fff3c4'); }
  drawMe(c,time);
  if(g.target&&g.mode==='play') drawBubble(c,g.target.x,g.target.y,time,'Z');
  const a2=ambient(g.clock);
  if(a2[3]>0.1){ c.fillStyle='rgba(20,18,50,'+(a2[3]*0.12).toFixed(2)+')'; c.fillRect(ox,oy,vw,vh); }
  c.setTransform(1,0,0,1,0,0);
}

/* ---------- using charms ---------- */
function readGrimoire(){
  const sp=schoolProgress();
  if(!sp.days){ say('',['The pages are blank, waiting.']); return; }
  const pages=['Apprentice Grimoire. Lessons learned: '+sp.days+' of 12.'];
  SPELLS.slice(0,sp.days).forEach(s=>pages.push(s[0]+'. '+s[1]));
  say('',pages);
}
const COLOR_RECIPE=[
  'THE CHROMATIC RECIPE, as dictated by Elder Umber, who cannot see colours, and has made it a lifelong study.',
  'A duck does not become a colour. It puts a colour on, and the colour accepts, or does not. The potion must be asked, not forced.',
  'You will need: two bundles of Hearthleaf (to soften the old colour), a Vigil Candle (to hold the new), a braid of red thread (to knot it in), a bottle of Warming Tonic (to carry it), and an Ember Token from the Banking, so the Hearth knows you.',
  'Lay them at the lip of the Great Hearth in Emberwick, at any hour. Speak the Great Saying. The Hearth will do the rest.',
  'WARNING, in the margin, in shaky capitals: IT DOES NOT WASH OFF. NOT EVER. THINK ABOUT THE KINGDOM BEFORE YOU DRINK.'
];
const BREW=[['healleaf',2,'Hearthleaf Bundle'],['vigil',1,'Vigil Candle'],['redthread',1,'Red Thread Braid'],['warmtonic',1,'Warming Tonic'],['embertoken',1,'Ember Token']];
function brewHave(){ return BREW.every(b=>(g.inv[b[0]]||0)>=b[1]); }
function brewList(){ return BREW.map(b=>b[2]+(b[1]>1?' x'+b[1]:'')+' ('+Math.min(b[1],g.inv[b[0]]||0)+'/'+b[1]+')').join(', '); }
let uwTarget=null;
function seekDirection(){
  const px=g.px/TS, py=g.py/TS;
  let best=null, bd=1e9;
  for(let i=0;i<UWROUTE.length-1;i++){
    const a=UWROUTE[i], b=UWROUTE[i+1];
    const dx=Math.max(Math.min(a[0],b[0])-px,0,px-Math.max(a[0],b[0])), dy=Math.max(Math.min(a[1],b[1])-py,0,py-Math.max(a[1],b[1]));
    const d=Math.hypot(dx,dy); if(d<bd){ bd=d; best=i; }
  }
  const nxt=UWROUTE[Math.min(UWROUTE.length-1,best+1)];
  const gx=nxt[0]-px, gy=nxt[1]-py;
  const ang=Math.atan2(gy,gx), names=['east','south-east','south','south-west','west','north-west','north','north-east'];
  return {name:names[((Math.round(ang/(Math.PI/4))%8)+8)%8],dist:Math.round(Math.hypot(gx,gy))};
}
{
  const _useItem=useItem;
  useItem=function(id){
    const it=ITEMS[id];
    if(it&&it.use==='magic'){
      closeInv();
      const m=MAGIC[id], st=g.story;
      if(!magicTrained(id)){ say('',[m.untrained,'You do not know how to use it. Perhaps the Academy could teach you.']); return; }
      if(id==='lumenorb'){ lumenUntil=g.time+240; toast('Show. A circle of light blooms around you, and holds for a while.',3600); return; }
      if(id==='seekerbeetle'){
        const px=Math.floor(g.px/TS), py=Math.floor((g.py-2)/TS);
        if(uwIn(px,py)){ const d=seekDirection(); say('',['The Seeker Beetle\'s eye glows green. It turns slowly, then points: '+d.name+', about '+d.dist+' steps.','It does not say how the path gets there. It only knows where the heart is.']); }
        else say('',['The beetle spins lazily, ticking. It has nothing in particular to seek. It looks at you hopefully.']);
        return;
      }
      if(id==='emberwand'){ say('',['You point the wand at nothing and ask, softly. A single orange flame blinks on the tip, looks around, and goes out. It seems satisfied.']); return; }
      if(id==='gustcharm'){ say('',['You hold the feather out and whisper "away". A small wind curls out of it, rearranges your tail feathers, and leaves.']); return; }
      if(id==='wardcharm'){ say('',['You hold the knot to your heart and think of home. For a moment, the world is warmer than the room.']); return; }
      if(id==='runestone'){ say('',['The mark glows. Somewhere, a small rock shivers in anticipation.']); return; }
    }
    if(it&&it.use==='grimoire'){ closeInv(); readGrimoire(); return; }
    if(it&&it.use==='colorbook'){ closeInv(); say('',COLOR_RECIPE); return; }
    _useItem(id);
  };
}

/* ---------- the Umbral Wood ---------- */
const UTHORN=90, UFOG=91, UBOULD=92, USHADE=93, UCURSE=94;
[UTHORN,UFOG,UBOULD,USHADE,UCURSE].forEach(c=>{ SOLID.add(c); INTERACTIVE.add(c); KTALL.add(c); });
Object.assign(MAPCOL,{90:'#3a1a14',91:'#8a7ac0',92:'#6a6e78',93:'#1a1030',94:'#7a2aa0'});
const ZX0=290, ZX1=420, ZY0=-1330, ZY1=-1225;
const UWROUTE=[[310,-1225],[310,-1245],[326,-1245],[326,-1262],[344,-1262],[344,-1276],[362,-1276],[362,-1290],[380,-1290],[380,-1312]];
const UWBR=[[[310,-1238],[298,-1238]],[[326,-1253],[338,-1253]],[[344,-1268],[334,-1268]],[[362,-1283],[372,-1283]],[[380,-1298],[370,-1298]]];
const UOBS=[[310,-1232,UTHORN,'emberwand'],[326,-1258,UFOG,'gustcharm'],[344,-1272,UBOULD,'runestone'],[362,-1286,USHADE,'lumenorb'],[380,-1305,UCURSE,'wardcharm']];
const UWSEGS=[];
for(let i=0;i<UWROUTE.length-1;i++) UWSEGS.push([UWROUTE[i],UWROUTE[i+1]]);
UWBR.forEach(b=>UWSEGS.push(b));
function uwIn(x,y){ return !!(g.story&&g.story.redOpen)&&x>=ZX0&&x<=ZX1&&y>=ZY0&&y<=ZY1; }
function uwDist(x,y){
  let d=1e9;
  for(const s of UWSEGS){
    const a=s[0], b=s[1];
    const dx=Math.max(Math.min(a[0],b[0])-x,0,x-Math.max(a[0],b[0])), dy=Math.max(Math.min(a[1],b[1])-y,0,y-Math.max(a[1],b[1]));
    const m=Math.max(dx,dy); if(m<d) d=m;
  }
  return d;
}
function uwTile(x,y){
  if(x<ZX0||x>ZX1||y<ZY0||y>ZY1) return null;
  if(x<ZX0+3||x>ZX1-3||y<ZY0+3) return T.DARK;
  const st=g.story;
  if(Math.abs(x-380)<=4&&Math.abs(y+1312)<=4){
    if(x===378&&y===-1312) return T.FIRE;
    if(x===382&&y===-1311) return T.STUMP;
    if((x*7+y*3)%9===0) return T.MUSH;
    return T.GRASS;
  }
  for(let i=0;i<UOBS.length;i++){
    const o=UOBS[i];
    if(y===o[1]&&Math.abs(x-o[0])<=1) return (st.uw&&st.uw[i])?T.PATH:o[2];
  }
  const d=uwDist(x,y);
  if(d<=1) return T.PATH;
  if(d<=3) return T.DARK;
  const h=hash(x,y,9010);
  if(h<0.55) return T.DARK;
  if(h<0.82) return T.TREE;
  return h<0.92?T.MUSH:T.GRASS;
}
{
  const _kt=kingdomTile;
  kingdomTile=function(x,y){ if(g.story&&g.story.redOpen){ const u=uwTile(x,y); if(u!==null) return u; } return _kt(x,y); };
  const _blocks=kingdomBlocksTown;
  kingdomBlocksTown=function(rx,ry){
    const a=Math.floor((ZX0+24)/REG), b=Math.floor((ZX1+24)/REG), c2=Math.floor((ZY0+24)/REG), d=Math.floor((ZY1+24)/REG);
    return _blocks(rx,ry)||(rx>=a&&rx<=b&&ry>=c2&&ry<=d);
  };
  const _kArea=kingdomArea;
  kingdomArea=function(tx,ty){ if(uwIn(tx,ty)) return 'The Umbral Wood'; return _kArea(tx,ty); };
}
function drawUObs(c,x,y,t,px,py,time,objs){
  rect(c,px,py,TS,TS,'#2a2430'); rect(c,px+4,py+4,10,2,'rgba(255,255,255,0.04)');
  objs.push({y:py+TS,k:'fn',f:()=>{
    if(t===UTHORN){
      c.strokeStyle='#3a1a10'; c.lineWidth=3; for(let i=0;i<4;i++){ c.beginPath(); c.moveTo(px+2+i*8,py+TS); c.bezierCurveTo(px+i*8-4,py+16,px+10+i*8,py+6,px+4+i*8,py-8); c.stroke(); }
      c.fillStyle='#8a1f1a'; for(let i=0;i<9;i++){ const tx=px+2+(i*11)%28, ty=py+2+(i*7)%26; c.beginPath(); c.moveTo(tx,ty); c.lineTo(tx+3,ty-4); c.lineTo(tx+5,ty+1); c.fill(); }
    } else if(t===UFOG){
      for(let i=0;i<5;i++){ const a=0.28+0.12*Math.sin(time*0.8+i+x); ell(c,px+16+Math.sin(time*0.5+i*2)*8,py+8+i*5,16,9,'rgba(200,190,240,'+a.toFixed(2)+')'); }
    } else if(t===UBOULD){
      ell(c,px+16,py+22,17,11,'rgba(0,0,0,0.3)'); ell(c,px+16,py+14,16,13,'#6a6e78'); ell(c,px+12,py+10,9,6,'#8a8e98'); c.strokeStyle='#4a4e58'; c.lineWidth=1.5; c.beginPath(); c.moveTo(px+18,py+4); c.lineTo(px+14,py+14); c.lineTo(px+20,py+22); c.stroke();
    } else if(t===USHADE){
      for(let i=0;i<4;i++){ const a=0.5+0.2*Math.sin(time*1.4+i*2); ell(c,px+16+Math.sin(time*0.9+i)*6,py+8+i*6,14,8,'rgba(14,6,34,'+a.toFixed(2)+')'); }
      circ(c,px+11,py+12,1.6,'#a98aff'); circ(c,px+21,py+12,1.6,'#a98aff');
    } else if(t===UCURSE){
      const f=0.6+0.4*Math.sin(time*3+x);
      c.strokeStyle='rgba(160,60,220,'+f.toFixed(2)+')'; c.lineWidth=2; c.beginPath(); c.arc(px+16,py+16,12,0,6.283); c.stroke(); c.beginPath(); c.moveTo(px+6,py+22); c.lineTo(px+16,py+4); c.lineTo(px+26,py+22); c.closePath(); c.stroke();
      circ(c,px+16,py+16,15,'rgba(122,42,160,'+(0.16*f).toFixed(2)+')');
    }
  }});
  if(t===UCURSE||t===USHADE) lights.push({x:px+16,y:py+16,r:60,s:0.4,w:0.8});
}
{
  const _drawKTile=drawKTile;
  drawKTile=function(c,x,y,t,px,py,time,objs,night){
    if(t>=UTHORN&&t<=UCURSE){ drawUObs(c,x,y,t,px,py,time,objs); return; }
    _drawKTile(c,x,y,t,px,py,time,objs,night);
  };
}
function uwObstacle(tx,ty){
  for(let i=0;i<UOBS.length;i++){ const o=UOBS[i]; if(ty===o[1]&&Math.abs(tx-o[0])<=1) return i; }
  return -1;
}
const UTXT={
  [UTHORN]:{need:'emberwand',blk:'A wall of black thorns, thick as your wing, spans the trail. Every thorn is sharp, and every thorn looks at you.',how:'Point the Ember Wand at it and ask "kindle".',ok:'You point the wand and ask. The thorns hesitate, glow red at the tips, and curl into ash, which lies down tidily on the path.'},
  [UFOG]:{need:'gustcharm',blk:'A wall of grey-violet fog stands across the trail, perfectly still. When you step toward it, it steps toward you.',how:'Hold out the Gust Charm and say "away".',ok:'You hold out the feather and whisper "away". The fog tears into ribbons and flows off between the trees, offended.'},
  [UBOULD]:{need:'runestone',blk:'A boulder the size of a cottage blocks the trail. It has been there a very long time. It has moss on its opinions.',how:'Press the Rune Stone to its face and ask.',ok:'You press the rune to the stone and ask. A crack runs from edge to edge. The boulder sighs, and falls into three tidy pieces that roll apart.'},
  [USHADE]:{need:'lumenorb',blk:'A curtain of living shadow hangs across the trail, rippling. Something behind it is looking back with two small violet lights.',how:'Hold up the Lumen Orb and say "show".',ok:'You raise the orb and say "show". The shadow unfurls, finds it has nothing to hide, and slips off the trail like ink in water.'},
  [UCURSE]:{need:'wardcharm',blk:'A circle of violet glyphs glows across the trail. The air above it tastes of old anger. A curse, set to guard the heart of the wood.',how:'Hold the Ward Charm to your heart and think of home.',ok:'You hold the knot to your heart and think of home. The glyphs flicker, turn inward and go out, one by one, like windows at the end of a long day.'}
};
function uwInteract(t,tx,ty){
  const st=g.story, i=uwObstacle(tx,ty), u=UTXT[t], need=u.need, m=MAGIC[need];
  if(!g.inv[need]){ say('',[u.blk,'You have nothing that would answer it. Something from the shops of Emberwick, perhaps. ('+u.how.split(' ')[1]+'...)']); return; }
  if(!isHeld(need)){ say('',[u.blk,'You carry the '+m.name+', but it is not in your hand. '+holdText(need)]); return; }
  if(!magicTrained(need)){ say('',[u.blk,'You hold the '+m.name+'. It hums, hopefully. You do not know how to use it. The Academy teaches it on day '+m.day+'.']); return; }
  spUwBlast(t,tx,ty,i,need);
}
let umber=null;
function umberNpc(){
  if(umber) return umber;
  umber=K('Elder Umber',381-KX,-1313-KY,RED_PALS[4],'wizard','scarf',[['...']],{special:'umber',still:true,dir:'down',owl:true,idx:3999});
  return umber;
}
function umberTalk(n){
  const st=g.story; n.dir='down'; n.talking=true; n.moving=false;
  const done=()=>{ n.talking=false; n.t=1; };
  const U='Elder Umber';
  if(st.colorBook){
    if(st.isRed) say(U,['Red as a coal. I cannot see it. I can hear it. The colour hums.'],done);
    else say(U,['You have the recipe. Gather: '+brewList()+'. Then the Great Hearth, and the Great Saying.','And think, little one. Think about the kingdom before you drink.'],done);
    return;
  }
  const first=!st.umberMet; st.umberMet=1;
  const give=()=>{
    addItem('colorbook'); st.colorBook=1; coin(); st.umbral=0;
    seq([
      [U,['Take it. It is the only copy. I dictated it once, forty years ago, to a scribe who is now dust.','You will need: '+brewList().replace(/ \(\d\/\d\)/g,'')+'. All of it sold in Emberwick, or given at the Banking.']],
      [U,['Lay them at the lip of the Great Hearth. Say the Great Saying. Then, if you still wish to, drink.','It does not wash off. I do not say it to frighten you. I say it because no one said it to me.']]
    ],()=>{ toast('Received: The Chromatic Recipe',4200); done(); });
  };
  if(first){
    seq([
      ['',['In the heart of the wood, in a ring of pale mushrooms, an old red duck sits beside a small fire. His eyes are milk-white. He does not turn his head as you step into the clearing.']],
      [U,['Stop. Do not come nearer. I can hear you. Yellow. I have not smelt yellow in sixty years: sunflowers, and fresh bread, and a very great deal of nerve.','You came through the thorn, the fog, the stone, the shadow, and the ward. All five. Mm. The Wood let you through. It does not let anyone through.']],
      [U,['I am Umber. I have no sight, and have kept a recipe for sixty years, waiting for someone to ask for it for a good reason.','Tell me why you want to become red.']]
    ],()=>{
      choose(U,'Why do you want to become red?',['The Elders will only trust me if I do','I want to know what it is to be hunted, and then be at home','I am not sure I do. I came to see','To spy for the king'],k=>{
        const r=['That is a reason. Not a good one. A real one. Real ones are rarer.','That is a better reason than most who ask. You will find the second half harder than the first.','Honest. Honest is the best reason of all, for a duck who cannot see.','Mm. A lie, or a fool. I will give you the recipe regardless. You will have to carry the weight of it yourself.'];
        say(U,[r[k]],give);
      },3);
    });
  } else give();
}
{
  const _kInteract=kingdomInteract;
  kingdomInteract=function(t,tx,ty){
    if(t>=UTHORN&&t<=UCURSE){ uwInteract(t,tx,ty); return; }
    _kInteract(t,tx,ty);
  };
}

/* ---------- the Chromatic Potion ---------- */
{
  const _hearth=redHearthInteract;
  redHearthInteract=function(){
    const st=g.story;
    if(st.colorBook&&!st.isRed){
      if(!brewHave()){ _hearth(); toast('Chromatic Potion: still needed: '+BREW.filter(b=>(g.inv[b[0]]||0)<b[1]).map(b=>b[2]).join(', '),4600); return; }
      choose('The Great Hearth','You have everything the recipe asks for. Lay it at the lip of the Hearth?',['Lay it out','Not yet'],k=>{ if(k===0) brewPotion(); },1);
      return;
    }
    _hearth();
  };
}
function brewPotion(){
  const st=g.story;
  seq([
    ['',['You lay them out in a row at the lip of the Great Hearth: the leaves, the candle, the braid, the bottle, the token. The fire leans toward them like a friend.','"A fire shared does not shrink," you say. It is the first time you have said it aloud. Nobody asked you to.']],
    ['',['The Hearth takes the leaves first, and the smoke turns red. Then the candle lights itself. The braid unknots. The tonic uncorks. The token melts into the bottle like wax into a name.','A small glass of something the colour of embers sits where the fire was. It is warm. It is waiting.']]
  ],()=>{
    choose('','Drink the Chromatic Potion? It does not wash off. In the kingdom, you would be an outcast.',['Drink it','Not yet, put it back'],k=>{
      if(k===0) becomeRed(); else say('',['You set the glass down. The fire does not mind. It has all the time in the world.']);
    },1);
  });
}
function becomeRed(){
  const st=g.story;
  for(const id of ['healleaf','healleaf','vigil','redthread','warmtonic','embertoken']) delInv(id);
  fade(2.2);
  seq([
    ['',['It tastes of smoke and cinnamon, and a little of home. For a moment nothing happens.','Then the warmth runs out along your wings and into every feather, one by one, like lamps being lit down a long street.']],
    ['',['You look down at your wings. They are red. Not a costume red. The real red, the red of coals and berries and the banners the Crown once feared.','The Hearth roars, once, softly. Across the square, a dozen heads turn. Nobody says a word. Then an old duck, somewhere, begins to hum.']],
    ['Hermit Mallow',['Little detective.','Oh, little detective. You look like you belong. I hope that is true.']]
  ],()=>{
    st.isRed=1; st.path='red';
    for(const k in g.rep) if(k!==RKEY) g.rep[k]=0;
    g.rep[RKEY]=0; tileCache.clear();
    toast('You are red now. Your standing in the kingdom\'s towns is gone. In Emberwick, your deeds will count.',6400);
  });
}

/* ---------- the other road: report to the king ---------- */
function crownGuardTalk(n){
  const st=g.story;
  n.talking=true; n.dir='down';
  const done=()=>{ n.talking=false; n.t=1; };
  const G=n.name;
  if(st.isRed){ say(G,['Red feathers. The king receives no one this week. Nor next. Move along, and keep your hands where I can see them. Not because of the colour, you understand. It is procedure.'],done); return; }
  if(st.dinnerDone){ say(G,['The king dined well, they say. He has asked that nobody speak of it. So I shall not.'],done); return; }
  if(st.dinnerAt){
    const t=absT();
    if(t<st.dinnerAt-2){ say(G,['The king dines with you at seven this evening. Come then. Do not be late.'],done); return; }
    if(t<=st.dinnerAt+0.5){ kingDinner(G,done); return; }
    st.dinnerAt=0; st.reportAt=0;
    say(G,['You are late. The king dined alone. He asked me to say: "Time is the one thing I cannot give twice."','If you still have something to report, say so, and we shall begin again. He is not an unkind man. He is a punctual one.'],done);
    return;
  }
  if(st.ch3Met){
    choose(G,'Halt. Welcome to Castle Quackenhold, which is closed. Is there something?',['Chat','I have something to report to the king about the red ducks','Leave'],k=>{
      if(k===0){ n.talking=false; n.cycle=(n.cycle||0); say(G,pick([['Closed. Still closed. Come back when the kingdom is ready.'],['The king has not shown himself in weeks. I have stopped counting. I count anyway.']]),done); }
      else if(k===1) crownReport(n,done);
      else done();
    },2);
    return;
  }
  say(G,pick([['Closed. Still closed. Come back when the kingdom is ready.'],['The king has not shown himself in weeks. We bring meals to the door. They are taken in by something that is not a hand.']]),done);
}
function crownReport(n,done){
  const st=g.story;
  seq([
    [P3,['I have something to report to the king. About the red ducks.']],
    [n.name,['About... red ducks. The king has not said that word in a long time. It is not a word he has permitted.','I will take it in. Both of us will. Stay close to the town. It will take a day. Perhaps less. Do not wander off.','And yes, the notice on the walls. Three hundred crumbs, paid at the king\'s own table, if your information holds.']],
    ['',['The two guards at the gate exchange a look, nod, and walk into Castle Quackenhold together. The great doors close behind them with a quiet and expensive sound.']]
  ],()=>{
    st.reportAt=absT(); st.path='crown';
    toast('The guards have taken your report inside. A day should do it.',4600);
    done();
  });
}
function kingDinner(G,done){
  const st=g.story;
  seq([
    [G,['You are on time. Good. The king dislikes the other kind.','Follow me. Do not speak until you are spoken to.']],
    ['',['The gate opens just wide enough for one duck. The hall beyond is cold, blue-lit and very long. A single table is laid for two. Behind the far chair, a window shows nothing but dark.','At the head of the table: an empty chair, and a place set before it with great care, as if for a guest who has not been invited in a hundred years.']],
    ['',['Footsteps. Slow ones. A candle flickers, and a shape stands up from the dark at the far end of the hall.','"Detective Duck," says a voice you have heard, in your dreams, at the castle gate. "Please. Sit. We have so much to discuss."']],
    ['',['At the end of the evening a servant slides a heavy purse across the table. "The reward on the notices," says the voice from the dark. "Three hundred crumbs, as promised. Information is the one thing this kingdom still buys without question."']],
    ['',['- To be continued -']]
  ],()=>{
    g.crumbs+=300; coin(); st.kingReward=300;
    st.dinnerDone=1; st.banished=1; tileCache.clear(); fade(1.6); advanceClock(3);
    done();
  });
}
{
  const _specialTalk=specialTalk;
  specialTalk=function(n){
    const st=g.story;
    if(n.special==='umber'){ umberTalk(n); return; }
    if(n.name&&n.name.indexOf('Castle Guard')===0&&(st.ch3Met||st.isRed||st.dinnerAt||st.dinnerDone)){ crownGuardTalk(n); return; }
    if(n.name==='Hermit Mallow'&&st.isRed&&!st.hermitHold){
      n.dir=OPP[g.dir]; n.talking=true; n.moving=false;
      say('Hermit Mallow',[pick(['Red suits you. I did not think it would. I am glad to have been wrong.','I always told Ruddock yellow could learn. He told me not to say that out loud. I said it very loud.','Whatever the king wants, little detective, I shall be at your wing.'])],()=>{ n.talking=false; n.t=1; });
      return;
    }
    _specialTalk(n);
  };
  const _specialMark=specialMark;
  specialMark=function(n){
    if(n.special==='umber') return st_umberMark(n);
    return _specialMark(n);
  };
  const _extraNpcs=extraNpcs;
  extraNpcs=function(list){
    _extraNpcs(list);
    const st=g.story;
    if(g.scene!=='world'||!st) return;
    const px=Math.floor(g.px/TS), py=Math.floor((g.py-2)/TS);
    if(uwIn(px,py)&&Math.abs(px-380)<30&&Math.abs(py+1312)<24) list.push(umberNpc());
    if(st.reportAt&&!st.dinnerAt){
      for(let i=list.length-1;i>=0;i--) if(list[i].name&&list[i].name.indexOf('Castle Guard')===0) list.splice(i,1);
    }
  };
}
function st_umberMark(n){ return n.talking?null:{ch:'?',col:'#ffd166'}; }

/* ---------- per-frame ---------- */
let lastTownKey=null, remindedAt=0;
function magicUpdate(dt){
  const st=g.story;
  if(!st||g.scene!=='world'||g.mode==='title'||g.mode==='cut') return;
  const tx=Math.floor(g.px/TS), ty=Math.floor((g.py-2)/TS);
  /* the king's answer arrives a day after the report, in the morning or afternoon, never at night */
  if(st.reportAt&&!st.dinnerAt&&g.mode==='play'&&absT()>=st.reportAt+24&&g.clock>=7&&g.clock<16&&!inRed(tx,ty)&&!uwIn(tx,ty)){
    st.dinnerAt=g.day*24+19;
    say('Castle Guard',['(A guard in royal blue jogs up, out of breath, a scroll under one wing.)','Detective Duck. The king has accepted your request. He asks you to dine with him this evening, at seven o\'clock.','At the castle gate. Do not be late.'],()=>toast('Dinner with the king, tonight, at 7:00 pm. Do not be late.',6000));
  }
  if(st.dinnerAt&&!st.dinnerDone&&g.mode==='play'){
    const t=absT();
    if(t>=st.dinnerAt-1&&t<st.dinnerAt&&remindedAt!==st.dinnerAt){ remindedAt=st.dinnerAt; toast('One hour until dinner with the king, at 7:00 pm. Castle gate. Do not be late.',5000); }
  }
  /* word of the dinner travels fast: the red town casts you out and seals its gate for good */
  if(st.banished&&!st.castOutSeen&&g.mode==='play'&&Math.hypot(g.px/TS-(RX0+36),g.py/TS-(RY0+RH))<9){
    st.castOutSeen=1;
    seq([
      ['',['A horn sounds from the palisade. Along the wall, red ducks appear one after another, lanterns in their wings. Nobody speaks.']],
      ['Warden Ruddock',['You dined with him. You sat at the king\'s table, after all we told you.','I said no. I voted no, and I was right.']],
      ['Elder Cinder',['We let you in once because Mallow trusted you. We will not be made fools of twice.','You are cast out of Emberwick, Detective Duck. The Wood will not move for you. The gate will not open. You may never enter this town again.']],
      ['Hermit Mallow',['Cinder. Please.','...No. I see. Then I am sorry, little detective. I cannot follow you past this gate. I should have, once. I am too old to be turned away twice.']],
      ['',['Red runes flare across the gate, one by one, like windows closing. The lanterns on the wall go out together.']]
    ],()=>{ toast('Emberwick is closed to you forever.',5200); });
  }
  /* the kingdom does not forget a red feather */
  const tw=townAtTile(tx,ty), key=tw&&!tw.isRed?tw.key:null;
  if(key!==lastTownKey){
    lastTownKey=key;
    if(key&&st.isRed) toast('Heads turn. A shutter closes. Somebody pulls a child indoors.',3800);
  }
}
{
  const _storyUpdate=storyUpdate;
  storyUpdate=function(dt){ _storyUpdate(dt); magicUpdate(dt); };
}

/* ---------- objective and journal ---------- */
function ch4Objective(){
  const st=g.story;
  if(!st.redOpen||!st.ch3Met) return null;
  if(st.dinnerDone) return 'You dined with the king. Emberwick has cast you out for good. (The story continues...)';
  if(st.isRed) return 'You are one of them now. Reputation is yours to earn in Emberwick. The kingdom\'s doors have closed. (The story continues...)';
  if(st.dinnerAt) return 'The king has invited you to dine at <b>Castle Quackenhold</b> at <b>7:00 pm</b> on Day '+Math.floor(st.dinnerAt/24)+'. Do not be late. The reward on the notices (300 crumbs) is paid at the table.';
  if(st.reportAt) return 'You reported to the guards at the castle gate. The king\'s answer will take about a day. Stay in the kingdom.';
  if(st.colorBook) return brewHave()?'You have everything. Lay it at the <b>Great Hearth</b> in Emberwick and speak the Great Saying.':'Brew the <b>Chromatic Potion</b> at the Great Hearth. Needed: '+brewList()+'.';
  if(st.umbral){
    const n=st.uw?Object.keys(st.uw).length:0;
    return 'Travel through the <b>Umbral Wood</b>, north-east of Emberwick (the trail leaves the Ember Road at its east end). Use your charms on what blocks the way ('+n+'/5). Find the blind elder.';
  }
  const sp=schoolProgress();
  if(st.path==='red'||sp.days>0) return 'Attend the <b>Academy of the Ember Arts</b> (north-west of Emberwick): lesson '+Math.min(12,sp.days+1)+' of 12. One a day, 8:00 to noon. Buy charms in the town\'s shops.';
  if(st.path==='crown') return 'Take your report to the castle guards at <b>Quackenhold</b>. Or return to Emberwick and the Academy if you change your mind.';
  return null;
}
function ch4Journal(sec,line){
  const st=g.story; if(!st.ch3Met) return;
  sec('The Elders\' Offer');
  line('Every red duck in Emberwick is a witch or a wizard; it is their culture, taught to every child. The charms in their shops are trinkets until you have been trained.');
  line('The Elders will trust you only if you become one of them: twelve days at the Academy (one lesson a day, tasks easy to moderately hard), then the Umbral Wood and a blind elder who keeps the recipe of the Chromatic Potion.');
  line('Becoming red would make you an outcast in the kingdom: all your standing there lost, and new standing very hard to earn. In Emberwick, your deeds would at last count.');
  const sp=schoolProgress();
  if(sp.days) line('Academy: lesson '+sp.days+' of 12 complete. Spells: '+SPELLS.slice(0,sp.days).map(s=>s[0]).join(', ')+'.','jdim');
  if(st.uw) line('Umbral Wood obstacles cleared: '+Object.keys(st.uw).length+' of 5.','jdim');
  if(st.umberMet) line('Elder Umber, blind, in the heart of the Umbral Wood, gave you the Chromatic Recipe.');
  if(st.colorBook&&!st.isRed) line('Recipe: Hearthleaf Bundle x2, Vigil Candle, Red Thread Braid, Warming Tonic, Ember Token. Lay them at the Great Hearth.','jdim');
  if(st.isRed) line('You drank the Chromatic Potion. You are red. In the kingdom, you are an outcast. In Emberwick, you may at last earn standing.');
  if(st.reportAt&&!st.isRed) line('You told the castle guards you have something to report about the red ducks.'+(st.dinnerAt?' The king invited you to dine with him at 7:00 pm on Day '+Math.floor(st.dinnerAt/24)+'. Do not be late.':' The king\'s answer is expected in a day.'));
  if(st.dinnerDone) line('You dined with the king at Castle Quackenhold. Emberwick learned of it, and cast you out. Its gate is sealed against you forever.');
}
{
  const _storyObjective=storyObjective;
  storyObjective=function(){ const o=ch4Objective(); if(o) return o; return _storyObjective(); };
  const _journalExtra=journalExtra;
  journalExtra=function(sec,line){ _journalExtra(sec,line); ch4Journal(sec,line); };
}
