'use strict';
/* ===== MAGIC, REWORKED =====
   - No more question menus. A SPELL BAR shows every spell you have learned. Q / E choose, C casts (or click an icon;
     click the chosen one again to cast it). Hold a magic item and press Z to cast its spell.
   - Spells are AIMED: they fly in the direction you face and hit the first thing in the way: a plant, tree, rock, pond,
     lamp, wall, a duck, an Umbral Wood obstacle... and everything reacts. Some reactions do real things (see SPI below).
   - Every spell is drawn: charge-up, bolts, wind, ice, runes, auras, glowing light on top of the night. */

/* ---------------- data ---------------- */
const SP_COL={
  Spark:['#ffe94a','#fff7b0','#ffffff'], Kindle:['#ff6a14','#ffc23a','#fff0b0'], Lumen:['#cfe4ff','#fff6c8','#ffffff'],
  Gust:['#d8f0ff','#9ad0e8','#ffffff'], Ward:['#ff6a7a','#ffc8a0','#fff0e0'], Mend:['#5affa0','#c8ffe0','#ffffff'],
  Stone:['#8aa0b8','#7affc8','#e8f4ff'], Seek:['#7affc8','#ffd166','#ffffff'], Bind:['#ff8ac8','#ffd0ec','#ffffff'],
  Frost:['#8ad0ff','#e0f6ff','#ffffff'], Veil:['#a890ff','#e0d8ff','#ffffff'], Hearthsong:['#ffd24a','#ff9ad0','#fff6d0']
};
const SP_AIMED=new Set(['Spark','Kindle','Gust','Stone','Mend','Frost']);
const SP_BY_ITEM={}; for(const n in SPNEED) SP_BY_ITEM[SPNEED[n]]=n;
const SP_RANGE=190;
const spKnown=()=>{ const k=SPELLS.slice(0,Math.min(12,magicDays())).map(s=>s[0]); if(typeof swStorySpell==='function'&&swStorySpell()) k.push('Emberlight'); if(typeof verseKnown==='function') for(const v of verseKnown()) k.push(v); return k; };

/* what each spell says to each kind of thing it hits */
const SP_TXT={
  Spark:{plant:'The leaves crackle and curl toward the warmth.',rock:'The rock hums, then pretends it did not.',water:'Ripples chase the spark across the water.',light:'The light flares, delighted.',npc:'{n}\'s feathers all stand on end.',air:'A little bolt fizzles out in the air.',crumbs:'The crumbs hop. Just once.'},
  Kindle:{plant:'The fire catches and the plant glows away to ash.',rock:'The rock goes warm. It was not planning to burn.',water:'Steam, a hiss, and the pond is entirely unimpressed.',light:'The flame leaps and the light burns brighter.',npc:'{n} jumps. You aimed to the side. Mostly.',air:'The fireball dies in a handful of embers.',crumbs:'Toasted crumbs. Smells good.'},
  Lumen:{}, Ward:{}, Seek:{}, Bind:{}, Veil:{}, Hearthsong:{},
  Gust:{plant:'Leaves and petals swirl away on the wind.',rock:'The wind goes around the rock. Stone does not listen.',water:'The pond wrinkles and whitecaps for a moment.',light:'The flame leans over, then stands back up.',npc:'{n} holds on to their hat. They are not wearing a hat.',air:'A tidy little whirlwind spins off into nothing.',crumbs:'The crumbs roll off to find a new home.'},
  Stone:{plant:'A rune glows on the bark, then fades politely.',rock:'The rune lights up and the rock splits along its seams.',water:'The rune sinks, glows green, and sinks further.',light:'The rune glows beside the lamp. They get on.',npc:'{n} reads the rune. They look worried.',air:'The rune hangs in the air, finds no stone, and goes out.',crumbs:'The rune settles on the crumbs. Nothing happens. Crumbs are not stone.'},
  Mend:{plant:'Green light settles on the plant. It looks a little healthier.',rock:'The rock has nothing broken. It looks smug.',water:'The ripples smooth out. The pond is pleased.',light:'The lamp stops flickering.',npc:'{n} feels a little better. A little warmer. A little seen.',air:'Healing light drifts off, hoping to find something broken.',crumbs:'The crumbs are fine. Crumbs are always fine.'},
  Frost:{plant:'A lace of frost spreads over the plant, then melts.',rock:'The rock turns white and sparkles.',water:'A skin of ice spreads over the water, then lets go.',light:'The flame shrinks and shivers. It keeps burning.',npc:'{n} shivers. A quiet, polite shiver.',air:'A burst of frost glitters and drifts down.',crumbs:'Frosted crumbs. Fancy.'}
};
const SP_BUILD={Spark:'The wall ticks like a cooling stove.',Kindle:'The wall goes warm. You will not be asked back.',Gust:'The wind finds a draught and whistles into it.',Stone:'A rune glows on the wall and stays there, faintly.',Mend:'A crack closes. It was a very small crack.',Frost:'Frost ferns grow across the wall.'};
const spNpcName=n=>(n&&n.name)||'The duck';

/* ---------------- particles, bolts and projectiles ---------------- */
const SPF={p:[],proj:[],bolts:[],decals:[],busy:0,windup:null,t:0};
function spP(o){ if(SPF.p.length>800) SPF.p.shift(); o.max=o.life; SPF.p.push(o); return o; }
function spBurst(x,y,cols,n,spd,o){
  o=o||{};
  for(let i=0;i<n;i++){
    const a=Math.random()*6.283, v=spd*(0.3+Math.random()*0.7);
    spP({k:o.k||'dot',x:x,y:y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-(o.up||0),ay:o.g||0,drag:o.drag===undefined?2.2:o.drag,life:(o.life||0.6)*(0.6+Math.random()*0.7),r:(o.r||2.3)*(0.6+Math.random()*0.8),col:cols[i%cols.length],rot:Math.random()*6.28,vr:(Math.random()-0.5)*8});
  }
}
function spRing(x,y,col,r0,r1,life,w){ spP({k:'ring',x:x,y:y,vx:0,vy:0,drag:0,r:r0,r1:r1,life:life,col:col,w:w||2}); }
function spHand(){ const v=DIRV[g.dir]; return {x:g.px+v.x*11,y:g.py-15+v.y*4}; }
function spWorldToTile(x,y){ return {tx:Math.floor(x/TS),ty:Math.floor(y/TS)}; }
function spLight(x,y,r,col,a){ SPF.proj.push({k:'glow',x:x,y:y,r:r,col:col,life:0.35,max:0.35,a:a||0.5}); }

function spUpdate(dt){
  SPF.t+=dt;
  for(let i=SPF.p.length-1;i>=0;i--){
    const p=SPF.p[i]; p.life-=dt;
    if(p.life<=0){ SPF.p.splice(i,1); continue; }
    if(p.drag){ const d=Math.max(0,1-p.drag*dt); p.vx*=d; p.vy*=d; }
    p.vy+=(p.ay||0)*dt; p.x+=p.vx*dt; p.y+=p.vy*dt; if(p.vr) p.rot+=p.vr*dt;
  }
  for(let i=SPF.bolts.length-1;i>=0;i--){ SPF.bolts[i].life-=dt; if(SPF.bolts[i].life<=0) SPF.bolts.splice(i,1); }
  for(let i=SPF.decals.length-1;i>=0;i--){ SPF.decals[i].life-=dt; if(SPF.decals[i].life<=0) SPF.decals.splice(i,1); }
  for(let i=SPF.proj.length-1;i>=0;i--){
    const q=SPF.proj[i];
    if(q.k==='glow'){ q.life-=dt; if(q.life<=0) SPF.proj.splice(i,1); continue; }
    if(q.k==='fly'){
      const dx=q.tx-q.x, dy=q.ty-q.y, d=Math.hypot(dx,dy), step=q.spd*dt;
      q.age=(q.age||0)+dt;
      if(d<=step||q.age>2){ SPF.proj.splice(i,1); if(q.hit) q.hit(); continue; }
      q.x+=dx/d*step; q.y+=dy/d*step;
      if(q.wob){ q.x+=-dy/d*Math.sin(q.age*q.wob)*q.wa*dt*60*0.1; q.y+=dx/d*Math.sin(q.age*q.wob)*q.wa*dt*60*0.1; }
      const cols=SP_COL[q.n];
      for(let j=0;j<2;j++) spP({k:q.trail||'dot',x:q.x+(Math.random()-0.5)*4,y:q.y+(Math.random()-0.5)*4,vx:(Math.random()-0.5)*18,vy:(Math.random()-0.5)*18-(q.n==='Kindle'?14:0),drag:1.5,life:0.35+Math.random()*0.25,r:(q.size||3)*(0.5+Math.random()*0.6),col:cols[(Math.random()*cols.length)|0],rot:Math.random()*6,vr:3});
    }
    if(q.k==='orbit'){ q.life-=dt; if(q.life<=0) SPF.proj.splice(i,1); }
  }
  /* the windup finishes and the spell is released */
  if(SPF.windup){
    const w=SPF.windup; w.t-=dt;
    const h=spHand(), cols=SP_COL[w.n];
    if(Math.random()<0.8) spP({k:'dot',x:h.x+(Math.random()-0.5)*24,y:h.y+(Math.random()-0.5)*24,vx:0,vy:0,drag:0,life:0.22,r:2.2,col:cols[(Math.random()*cols.length)|0]});
    if(w.t<=0){ SPF.windup=null; w.go(); }
  }
}

/* ---------------- drawing (on top of the night, in glowing light) ---------------- */
function spDraw(c,kd){
  if(g.scene!=='world') return;
  const x=XS(), hasLumen=x.lumenUntil>xAbs()||g.time<lumenUntil, hasWard=g.story&&g.story.luckDay===g.day, hasBind=!!x.bind;
  if(!SPF.p.length&&!SPF.proj.length&&!SPF.bolts.length&&!SPF.decals.length&&!SPF.windup&&!hasLumen&&!hasWard&&!hasBind) return;
  c.save();
  c.setTransform(kd,0,0,kd,-view.ox*kd,-view.oy*kd);
  /* decals: frost on the ground and the like */
  for(const d of SPF.decals){
    const a=Math.min(1,d.life/d.max*1.6);
    c.globalAlpha=a*0.55; c.fillStyle=d.col; c.beginPath(); c.ellipse(d.x,d.y,d.r,d.r*0.55,0,0,6.283); c.fill();
    c.globalAlpha=a*0.8; c.strokeStyle='#ffffff'; c.lineWidth=1; for(let i=0;i<6;i++){ const aa=i*1.047+d.x; c.beginPath(); c.moveTo(d.x,d.y); c.lineTo(d.x+Math.cos(aa)*d.r*0.9,d.y+Math.sin(aa)*d.r*0.5); c.stroke(); }
  }
  c.globalAlpha=1; c.globalCompositeOperation='lighter';
  /* persistent auras */
  const t=SPF.t;
  if(hasLumen){
    const ox=g.px+Math.cos(t*1.7)*15, oy=g.py-38+Math.sin(t*2.3)*4;
    const gr=c.createRadialGradient(ox,oy,0,ox,oy,34); gr.addColorStop(0,'rgba(220,235,255,0.55)'); gr.addColorStop(1,'rgba(220,235,255,0)'); c.fillStyle=gr; c.beginPath(); c.arc(ox,oy,34,0,6.283); c.fill();
    c.fillStyle='#ffffff'; c.beginPath(); c.arc(ox,oy,3.2,0,6.283); c.fill();
    c.fillStyle='rgba(255,246,200,0.9)'; c.beginPath(); c.arc(ox,oy,5,0,6.283); c.globalAlpha=0.5; c.fill(); c.globalAlpha=1;
    if(Math.random()<0.25) spP({k:'dot',x:ox,y:oy,vx:(Math.random()-0.5)*16,vy:8+Math.random()*10,drag:1,life:0.5,r:1.4,col:'#fff6c8'});
  }
  if(hasWard){
    c.globalAlpha=0.3+0.12*Math.sin(t*2); c.strokeStyle='#ff9a8a'; c.lineWidth=1.4;
    c.beginPath(); c.ellipse(g.px,g.py-4,17,7,0,0,6.283); c.stroke();
    for(let i=0;i<4;i++){ const a=t*0.9+i*1.571; c.globalAlpha=0.55; c.fillStyle='#ffd0a0'; c.beginPath(); c.arc(g.px+Math.cos(a)*17,g.py-4+Math.sin(a)*7,1.6,0,6.283); c.fill(); }
    c.globalAlpha=1;
  }
  if(hasBind){
    c.globalAlpha=0.6; c.strokeStyle='#ff9ad0'; c.lineWidth=1.6; c.beginPath();
    for(let a=0;a<6.3;a+=0.2){ const px=g.px+Math.cos(a+t*1.5)*13, py=g.py-14+a*2.6-8+Math.sin(a*2+t*3)*1.4; if(a===0) c.moveTo(px,py); else c.lineTo(px,py); }
    c.stroke(); c.globalAlpha=1;
  }
  /* the windup: a ring of light gathering at the wand */
  if(SPF.windup){
    const w=SPF.windup, h=spHand(), a=Math.max(0,w.t/w.max), cols=SP_COL[w.n];
    const gr=c.createRadialGradient(h.x,h.y,0,h.x,h.y,6+16*(1-a)); gr.addColorStop(0,cols[2]); gr.addColorStop(0.4,cols[0]); gr.addColorStop(1,'rgba(0,0,0,0)');
    c.globalAlpha=0.9; c.fillStyle=gr; c.beginPath(); c.arc(h.x,h.y,6+16*(1-a),0,6.283); c.fill(); c.globalAlpha=1;
  }
  /* bolts */
  for(const b of SPF.bolts){
    const a=Math.max(0,b.life/b.max);
    c.lineJoin='round'; c.lineCap='round';
    c.globalAlpha=a*0.45; c.strokeStyle=b.col[0]; c.lineWidth=7; c.beginPath(); b.pts.forEach((p,i)=>i?c.lineTo(p[0],p[1]):c.moveTo(p[0],p[1])); c.stroke();
    c.globalAlpha=a; c.strokeStyle=b.col[2]; c.lineWidth=2; c.beginPath(); b.pts.forEach((p,i)=>i?c.lineTo(p[0],p[1]):c.moveTo(p[0],p[1])); c.stroke();
  }
  /* projectile heads and glows */
  for(const q of SPF.proj){
    if(q.k==='glow'){
      const a=q.life/q.max, gr=c.createRadialGradient(q.x,q.y,0,q.x,q.y,q.r); gr.addColorStop(0,q.col); gr.addColorStop(1,'rgba(0,0,0,0)');
      c.globalAlpha=a*q.a; c.fillStyle=gr; c.beginPath(); c.arc(q.x,q.y,q.r,0,6.283); c.fill(); c.globalAlpha=1; continue;
    }
    if(q.k==='fly'){
      const cols=SP_COL[q.n], r=(q.size||3)*3.4;
      const gr=c.createRadialGradient(q.x,q.y,0,q.x,q.y,r*2.2); gr.addColorStop(0,cols[2]); gr.addColorStop(0.35,cols[0]); gr.addColorStop(1,'rgba(0,0,0,0)');
      c.fillStyle=gr; c.beginPath(); c.arc(q.x,q.y,r*2.2,0,6.283); c.fill();
      if(q.draw) q.draw(c,q);
    }
  }
  /* particles */
  for(const p of SPF.p){
    const a=Math.max(0,p.life/p.max);
    switch(p.k){
      case 'ring': { const r=p.r+(p.r1-p.r)*(1-a); c.globalAlpha=a; c.strokeStyle=p.col; c.lineWidth=p.w*(0.5+a); c.beginPath(); c.ellipse(p.x,p.y,r,r*0.6,0,0,6.283); c.stroke(); break; }
      case 'flake': { c.globalAlpha=a; c.strokeStyle=p.col; c.lineWidth=1; const r=p.r*1.5; c.save(); c.translate(p.x,p.y); c.rotate(p.rot); for(let i=0;i<3;i++){ c.rotate(1.047); c.beginPath(); c.moveTo(-r,0); c.lineTo(r,0); c.stroke(); } c.restore(); break; }
      case 'leaf': { c.globalCompositeOperation='source-over'; c.globalAlpha=Math.min(1,a*1.5); c.fillStyle=p.col; c.save(); c.translate(p.x,p.y); c.rotate(p.rot); c.fillRect(-p.r,-p.r*0.5,p.r*2,p.r); c.restore(); c.globalCompositeOperation='lighter'; break; }
      case 'note': { c.globalAlpha=a; c.fillStyle=p.col; c.strokeStyle=p.col; c.lineWidth=1.3; c.beginPath(); c.ellipse(p.x,p.y,3,2.2,-0.4,0,6.283); c.fill(); c.beginPath(); c.moveTo(p.x+2.6,p.y-0.6); c.lineTo(p.x+2.6,p.y-9); c.lineTo(p.x+6,p.y-7); c.stroke(); break; }
      case 'rune': { c.globalAlpha=a; c.strokeStyle=p.col; c.lineWidth=1.4; c.save(); c.translate(p.x,p.y); c.rotate(p.rot*0.2); const r=p.r*3; c.beginPath(); c.moveTo(0,-r); c.lineTo(r*0.7,0); c.lineTo(0,r); c.lineTo(-r*0.7,0); c.closePath(); c.moveTo(0,-r*0.6); c.lineTo(0,r*0.6); c.moveTo(-r*0.35,-r*0.1); c.lineTo(r*0.35,r*0.2); c.stroke(); c.restore(); break; }
      case 'smoke': { c.globalCompositeOperation='source-over'; c.globalAlpha=a*0.35; c.fillStyle='#4a4a52'; c.beginPath(); c.arc(p.x,p.y,p.r*(2-a),0,6.283); c.fill(); c.globalCompositeOperation='lighter'; break; }
      case 'line': { c.globalAlpha=a*0.8; c.strokeStyle=p.col; c.lineWidth=1.2; c.beginPath(); c.moveTo(p.x,p.y); c.lineTo(p.x-p.vx*0.06,p.y-p.vy*0.06); c.stroke(); break; }
      default: { c.globalAlpha=a; c.fillStyle=p.col; c.beginPath(); c.arc(p.x,p.y,p.r*(0.4+a*0.6),0,6.283); c.fill(); if(p.r>2){ c.globalAlpha=a*0.25; c.beginPath(); c.arc(p.x,p.y,p.r*2.2,0,6.283); c.fill(); } }
    }
  }
  c.restore();
}

/* ---------------- aiming ---------------- */
function spCat(t,tx,ty,n){
  if(typeof UTHORN!=='undefined'&&t>=UTHORN&&t<=UCURSE) return 'uobs';
  if(t===T.FLOWER||t===T.BUSH||t===T.MUSH) return 'plant';
  if(t===T.TREE||t===T.DARK||t===T.STUMP) return 'tree';
  if(t===T.ROCK) return 'rock';
  if(t===T.WATER) return 'water';
  if(t===T.LAMP||t===T.FIRE) return 'light';
  if(t===T.CRUMBS) return 'crumbs';
  if(SOLID.has(t)) return 'build';
  if(n==='Mend'&&t===T.GRASS){ const w=WD(); if(w.gone&&w.gone[tx+','+ty]) return 'gone'; }
  return null;
}
function spScan(n,range){
  const v=DIRV[g.dir], hx=g.px, hy=g.py-12;
  for(let d=12;d<=range;d+=6){
    const x=hx+v.x*d, y=hy+v.y*d;
    for(const m of g.npcs){ if(Math.abs(m.x-x)<13&&Math.abs((m.y-12)-y)<17) return {k:'npc',n:m,x:m.x,y:m.y-14}; }
    const tx=Math.floor(x/TS), ty=Math.floor(y/TS), t=tileAt(tx,ty), cat=spCat(t,tx,ty,n);
    if(cat) return {k:'tile',cat:cat,t:t,tx:tx,ty:ty,x:(tx+0.5)*TS,y:(ty+0.5)*TS-(cat==='tree'?10:4)};
  }
  const e={x:hx+v.x*range,y:hy+v.y*range+8};
  return {k:'air',x:e.x,y:e.y};
}

/* ---------------- real effects when a spell lands ---------------- */
function spCollect(tg,how){
  window.WL_MAGIC=true; window.WL_QUIET=true; window.WL_VERB=(cat,sp)=>how+' the '+(sp?sp.name:wlGenericName(tg.t))+'.';
  try{ wlForage(tg); } finally{ window.WL_MAGIC=false; window.WL_QUIET=false; window.WL_VERB=null; }
}
function spReact(n,tg){          /* flavour for anything that has nothing special to do */
  const T_=SP_TXT[n]||{};
  if(tg.k==='npc') return (T_.npc||'').replace('{n}',spNpcName(tg.n));
  if(tg.k==='air') return T_.air||'';
  const c=tg.cat;
  if(c==='plant'||c==='tree'||c==='gone') return T_.plant||'';
  if(c==='rock') return T_.rock||'';
  if(c==='water') return T_.water||'';
  if(c==='light') return T_.light||'';
  if(c==='crumbs') return T_.crumbs||'';
  return SP_BUILD[n]||'';
}
function spUwClear(i,t,tx,ty){
  const st=g.story, u=UTXT[t]; st.uw=st.uw||{}; st.uw[i]=1; tileCache.clear(); coin();
  const x=(tx+0.5)*TS, y=(ty+0.5)*TS-6;
  spBurst(x,y,['#ffffff','#ffd166','#7affc8'],46,150,{life:0.9,r:2.6}); spRing(x,y,'#ffffff',6,70,0.8,3); spRing(x,y,'#ffd166',3,44,0.6,2);
  tone('triangle',420,880,0.5,0.07);
  say('',[u.ok],()=>{ const n=Object.keys(st.uw).length; toast('Obstacle cleared ('+n+'/5).',3000); });
}
const SPI={
  Spark(tg){
    g.boost=Math.min(150,g.boost+30); setCd('Spark',SPCD.Spark);
    return spReact('Spark',tg)+' (You feel quick.)';
  },
  Kindle(tg){
    const x=XS();
    if(tg.k==='tile'){
      const cat=tg.cat, tt=tg.t;
      if(cat==='plant'||(cat==='tree'&&tt!==T.DARK)){
        spBurst(tg.x,tg.y,['#ff6a14','#ffc23a','#fff0b0'],34,110,{life:0.8,up:50,g:-30});
        for(let i=0;i<10;i++) spP({k:'smoke',x:tg.x+(Math.random()-0.5)*16,y:tg.y+(Math.random()-0.5)*8,vx:(Math.random()-0.5)*10,vy:-18-Math.random()*20,drag:0.6,life:1.1,r:4+Math.random()*3,col:'#555'});
        spCollect({tx:tg.tx,ty:tg.ty,t:tt},'You burn');
        return '';
      }
      if(cat==='light'){
        spBurst(tg.x,tg.y-8,['#ff9a2a','#ffd23a'],18,70,{up:40,g:-20}); spLight(tg.x,tg.y-8,90,'#ffb24a',0.7);
        if(tt===T.FIRE){
          const fid=FISHIDS.find(id=>g.inv['fish_'+id]&&id!=='oldboot');
          if(fid){ delInv('fish_'+fid); addItem('roastfish'); return 'The fire takes the '+FISHBY[fid].n+' and hands back a golden, crackling Roast Fish. (Added to your pack.)'; }
          return SP_TXT.Kindle.light+' (A fish in your pack would be roasted.)';
        }
        return SP_TXT.Kindle.light;
      }
      if(cat==='uobs') return null;
    }
    if(tg.k==='air'||tg.cat==='water'||tg.cat==='crumbs'||tg.cat==='rock'||tg.cat==='build') spBurst(tg.x,tg.y,['#ff9a2a','#ffd23a'],14,60,{up:30,g:-10});
    if(tg.k==='npc') spBurst(tg.x,tg.y,['#ffd23a','#ff9a2a'],12,50,{up:20});
    if(tg.cat==='water'){ for(let i=0;i<8;i++) spP({k:'smoke',x:tg.x+(Math.random()-0.5)*14,y:tg.y,vx:(Math.random()-0.5)*8,vy:-16-Math.random()*14,drag:0.5,life:0.9,r:3+Math.random()*2,col:'#fff'}); }
    return spReact('Kindle',tg);
  },
  Gust(tg){
    const x=XS(); let msg='';
    let did=false;
    if(wxKind(g.day)==='fog'&&wxAmt()>0.05){ x.fogUntil=xAbs()+6; msg='The fog tears apart and blows away. It will stay thin for a while.'; did=true; }
    else if(wxNow()==='rain'||wxNow()==='storm'){ x.rainStop=xAbs(); msg='The rain hesitates. It is still raining. The wind is impressed, anyway.'; did=true; }
    if(tg.k==='tile'&&(tg.cat==='plant'||tg.cat==='tree')&&tg.t!==T.DARK){
      const key=tg.tx+','+tg.ty; x.shk=x.shk||{};
      for(let i=0;i<14;i++) spP({k:'leaf',x:tg.x+(Math.random()-0.5)*20,y:tg.y-10+Math.random()*10,vx:60+Math.random()*70,vy:-10+Math.random()*30,ay:20,drag:0.5,life:1.1,r:1.8,col:['#7fca6e','#e8b13a','#f6d55c','#f4a6c3'][i%4]});
      if(x.shk[key]===g.day) return msg||'The wind shakes the last few leaves loose. Nothing more falls today.';
      x.shk[key]=g.day;
      const cat=WL_TILECAT[tg.t], sp=wlSpeciesAt(tg.tx,tg.ty,tg.t), b=wlBiomeAt(tg.tx,tg.ty);
      let txt=typeof brewDrop==='function'?brewDrop(sp,cat,b&&b.id):'';
      if(Math.random()<0.4){ const n=1+(Math.random()<0.3?1:0); g.crumbs+=n; coin(); txt+=' +'+n+' crumb'+(n>1?'s':'')+' shaken loose.'; }
      return (msg?msg+' ':'')+'The wind shakes the '+(sp?sp.name:'plant')+'. '+txt;
    }
    if(tg.k==='tile'&&tg.cat==='uobs') return null;
    return msg||spReact('Gust',tg);
  },
  Stone(tg){
    const x=XS();
    if(tg.k==='tile'&&tg.cat==='rock'){
      const key=tg.tx+','+tg.ty; x.rocks=x.rocks||{};
      spRing(tg.x,tg.y,'#7affc8',4,36,0.6,2);
      if(x.rocks[key]&&x.rocks[key]+3>g.day){ setCd('Stone',0); return 'This rock has been asked already. Give it a few days to think.'; }
      x.rocks[key]=g.day; const n=2+Math.floor(Math.random()*4); g.crumbs+=n; addItem('pebble'); coin();
      spBurst(tg.x,tg.y,['#8a8f98','#c3c8cf','#7affc8'],26,120,{k:'dot',life:0.7,g:200,r:2.4});
      return 'The rune lights up and the rock splits along its own seams. A Shiny Pebble and '+n+' crumbs.';
    }
    if(tg.k==='tile'&&tg.cat==='uobs') return null;
    spBurst(tg.x,tg.y,['#7affc8','#e8f4ff'],10,40,{k:'rune',life:0.9,r:2});
    return spReact('Stone',tg);
  },
  Mend(tg){
    const x=XS(); let msgs=[];
    if((x.rodWear||0)>0){ x.rodWear=0; msgs.push('The frayed line knits itself whole. Your fishing rod is as good as new.'); spBurst(g.px,g.py-14,['#5affa0','#c8ffe0'],16,50,{up:30,g:-20}); }
    if(tg.k==='tile'&&tg.cat==='gone'){
      const w=WD(); delete w.gone[tg.tx+','+tg.ty]; tileCache.delete(tkey(tg.tx,tg.ty));
      const t2=tileAt(tg.tx,tg.ty), sp=wlSpeciesAt(tg.tx,tg.ty,t2);
      spBurst(tg.x,tg.y,['#5affa0','#c8ffe0','#f6f1e6'],30,70,{up:50,g:-20,life:0.9}); spRing(tg.x,tg.y,'#5affa0',4,34,0.7,2);
      setCd('Mend',1.5);
      return 'Green light sinks into the bare ground, and a '+(sp?sp.name:'plant')+' grows back.';
    }
    if(tg.k==='tile'&&tg.cat==='uobs') return null;
    spBurst(tg.x,tg.y,['#5affa0','#c8ffe0'],14,40,{up:30,g:-20});
    if(msgs.length) return msgs.join(' ');
    setCd('Mend',0);
    return spReact('Mend',tg)+(tg.k==='air'?'  (Mend also regrows a plant you have gathered: face the bare ground.)':'');
  },
  Frost(tg){
    const x=XS(); x.frostDay=g.day; setCd('Frost',SPCD.Frost);
    if(tg.k==='tile'||tg.k==='npc'){
      spBurst(tg.x,tg.y,['#e0f6ff','#8ad0ff'],24,80,{k:'flake',life:1.1,g:40,r:2.2});
      SPF.decals.push({x:tg.x,y:tg.y+(tg.k==='npc'?14:6),r:tg.cat==='water'?20:13,life:6,max:6,col:'#bfe8ff'});
    } else spBurst(tg.x,tg.y,['#e0f6ff','#8ad0ff'],14,60,{k:'flake',life:1,g:30});
    return spReact('Frost',tg)+' (Fish sell for a quarter more today.)';
  }
};

/* ---------------- casting ---------------- */
function spFizzle(n,msg){
  const h=spHand(); spBurst(h.x,h.y,['#8a8f98','#c3c8cf'],8,40,{life:0.4}); tone('square',240,120,0.15,0.05); toast(msg,2800);
}
function spFly(n,from,to,hit,o){
  o=o||{};
  SPF.proj.push({k:'fly',n:n,x:from.x,y:from.y,tx:to.x,ty:to.y,spd:o.spd||360,size:o.size||3,hit:hit,trail:o.trail,wob:o.wob,wa:o.wa,draw:o.draw});
}
function spellCast(n){
  if(g.mode==='play'&&typeof sxIn==='function'&&sxIn()&&typeof sxCastNamed==='function'){ sxCastNamed(n); return; }
  if(g.mode!=='play'||g.scene!=='world') return;
  const known=spKnown();
  if(!known.length){ toast('You know no spells yet. The Academy in Emberwick teaches them, one a day.',3400); return; }
  if(known.indexOf(n)<0){ toast('You have not learned '+n+' yet.',2200); return; }
  const need=SPNEED[n];
  if(need&&!isHeld(need)){ spFizzle(n,g.inv[need]?'Hold the '+ITEMS[need].name+' to cast '+n+': select it on your hotbar.':n+' needs the '+ITEMS[need].name+'. The shops of Emberwick sell it.'); return; }
  if(!spellReady(n)){ toast(n+' is still settling: ready in '+xIn(XS().cd[n]-xAbs())+'.',2200); return; }
  if(g.time<SPF.busy||SPF.windup) return;
  SPF.busy=g.time+0.5;
  spSetSel(n); setCd(n,SPCD[n]);
  const cols=SP_COL[n], h=spHand(), x=XS();
  const w={n:n,t:0.16,max:0.16,go:null};
  const finish=(msg)=>{ if(msg) toast(msg,msg.length>110?5200:3600); };
  if(SP_AIMED.has(n)){
    tone('triangle',380+known.indexOf(n)*30,700,0.14,0.05);
    w.go=()=>{
      const tg=spScan(n,SP_RANGE);
      const to={x:tg.x,y:tg.y};
      const land=()=>{
        spRing(tg.x,tg.y,cols[0],3,26,0.45,2.5); spLight(tg.x,tg.y,70,cols[0],0.6);
        let msg;
        if(tg.k==='tile'&&tg.cat==='uobs'){ msg=spUobs(n,tg); }
        else msg=SPI[n](tg);
        finish(msg);
      };
      if(n==='Spark'){
        const pts=[[h.x,h.y]], N=7; for(let i=1;i<N;i++){ const u=i/N; pts.push([h.x+(to.x-h.x)*u+(Math.random()-0.5)*14,h.y+(to.y-h.y)*u+(Math.random()-0.5)*14]); } pts.push([to.x,to.y]);
        SPF.bolts.push({pts:pts,col:cols,life:0.28,max:0.28}); spBurst(to.x,to.y,cols,16,110,{k:'line',life:0.35}); tone('sawtooth',900,200,0.18,0.06);
        setTimeout(land,60);
      } else if(n==='Gust'){
        const dx=to.x-h.x, dy=to.y-h.y, d=Math.hypot(dx,dy)||1, ux=dx/d, uy=dy/d;
        for(let i=0;i<46;i++){ const s=Math.random(); spP({k:'line',x:h.x+(Math.random()-0.5)*8,y:h.y+(Math.random()-0.5)*18,vx:ux*(220+Math.random()*180)+(-uy)*(Math.random()-0.5)*60,vy:uy*(220+Math.random()*180)+(ux)*(Math.random()-0.5)*60,drag:0.6,life:0.3+s*0.45,r:1,col:cols[i%2]}); }
        for(let i=0;i<10;i++) spP({k:'leaf',x:h.x+ux*20,y:h.y+uy*20+(Math.random()-0.5)*16,vx:ux*(120+Math.random()*120),vy:uy*(120+Math.random()*120)-10,ay:10,drag:0.5,life:0.9,r:1.6,col:['#7fca6e','#e8b13a','#f6f1e6'][i%3]});
        tone('sawtooth',160,60,0.4,0.05);
        setTimeout(land,Math.min(420,d*2.2));
      } else if(n==='Stone'){
        spFly(n,h,to,land,{spd:300,size:2.6,trail:'rune',draw:(c,q)=>{ c.strokeStyle='#e8f4ff'; c.lineWidth=1.5; c.save(); c.translate(q.x,q.y); c.rotate(SPF.t*4); c.beginPath(); c.moveTo(0,-7); c.lineTo(5,0); c.lineTo(0,7); c.lineTo(-5,0); c.closePath(); c.stroke(); c.restore(); }});
        tone('triangle',200,300,0.3,0.05);
      } else if(n==='Kindle'){
        spFly(n,h,to,land,{spd:330,size:3.6}); tone('sawtooth',140,90,0.4,0.05);
      } else if(n==='Frost'){
        spFly(n,h,to,land,{spd:300,size:3,trail:'flake'}); tone('sine',900,500,0.35,0.05);
      } else {   /* Mend */
        spFly(n,h,to,land,{spd:240,size:2.8,wob:12,wa:2.2}); tone('sine',500,900,0.4,0.05);
      }
    };
  } else {
    w.go=()=>{
      let msg='';
      if(n==='Lumen'){
        x.lumenUntil=xAbs()+4; setCd('Lumen',SPCD.Lumen);
        spRing(g.px,g.py-14,cols[0],4,60,0.9,3); spBurst(g.px,g.py-20,cols,36,90,{up:40,g:-20,life:1}); spLight(g.px,g.py-20,150,'#dff0ff',0.7);
        tone('sine',500,1100,0.6,0.06); msg='A soft orb of light drifts up to your shoulder and stays there for four hours.';
      } else if(n==='Ward'){
        g.story.luckDay=g.day; setCd('Ward',SPCD.Ward);
        for(let i=0;i<3;i++) spRing(g.px,g.py-4,i?cols[1]:cols[0],8,52+i*8,0.8+i*0.15,2.5);
        for(let i=0;i<10;i++){ const a=i*0.628; spP({k:'rune',x:g.px+Math.cos(a)*30,y:g.py-4+Math.sin(a)*14,vx:Math.cos(a)*10,vy:-18,drag:0.5,life:1.1,r:2.4,col:cols[i%2],rot:a,vr:1}); }
        tone('triangle',330,660,0.5,0.06); msg='A quiet knot of luck settles over you for the rest of the day. Crumb rewards come a little richer.';
      } else if(n==='Seek'){
        setCd('Seek',SPCD.Seek);
        const tl=xPlayerTile(); let best=null; const rx0=Math.floor((tl.x+24)/REG), ry0=Math.floor((tl.y+24)/REG);
        for(let dy=-6;dy<=6;dy++) for(let dx=-6;dx<=6;dx++){ const t=getTown(rx0+dx,ry0+dy); if(!t||g.towns.has(t.key)) continue; const d=Math.hypot(t.cx-tl.x,t.cy-tl.y); if(!best||d<best.d) best={t:t,d:d}; }
        spRing(g.px,g.py-14,cols[0],4,46,0.7,2);
        if(!best){ spBurst(g.px,g.py-14,cols,12,40,{life:0.6}); msg='The beetle spins, then settles. No unfound town within a long walk. You have been thorough.'; }
        else {
          const ang=Math.atan2(best.t.cy-tl.y,best.t.cx-tl.x), i=((Math.round(ang/(Math.PI/4))%8)+8)%8;
          const to={x:g.px+Math.cos(ang)*230,y:g.py-14+Math.sin(ang)*230};
          spFly(n,{x:g.px,y:g.py-20},to,()=>{ spRing(to.x,to.y,cols[1],2,30,0.8,2); spBurst(to.x,to.y,cols,14,60,{life:0.8}); },{spd:200,size:2.2,wob:10,wa:1.8,draw:(c,q)=>{ c.fillStyle='#ffd166'; c.beginPath(); c.ellipse(q.x,q.y,4,2.8,Math.atan2(q.ty-q.y,q.tx-q.x),0,6.283); c.fill(); c.fillStyle='#7affc8'; c.beginPath(); c.arc(q.x+Math.cos(Math.atan2(q.ty-q.y,q.tx-q.x))*3,q.y+Math.sin(Math.atan2(q.ty-q.y,q.tx-q.x))*3,1.6,0,6.283); c.fill(); }});
          msg='The beetle points '+['east','south-east','south','south-west','west','north-west','north','north-east'][i]+' '+ARROWS[i]+'. About '+Math.round(best.d/5)*5+' waddles to a town you have not found.';
        }
        tone('sine',700,1000,0.3,0.05);
      } else if(n==='Bind'){
        x.bind=1; setCd('Bind',SPCD.Bind);
        for(let i=0;i<40;i++){ const a=i*0.4; spP({k:'dot',x:g.px+Math.cos(a)*14,y:g.py-6-i*0.7,vx:Math.cos(a+1.57)*30,vy:-8,drag:1,life:0.9,r:2,col:cols[i%2]}); }
        spRing(g.px,g.py-4,cols[0],6,30,0.7,2); tone('triangle',300,500,0.4,0.05);
        msg='A ribbon of light ties itself loosely round your next cast. The fish will be easier to hold.';
      } else if(n==='Veil'){
        x.veilUntil=xAbs()+3; setCd('Veil',SPCD.Veil);
        for(let i=0;i<30;i++){ const a=Math.random()*6.28, r=40+Math.random()*20; spP({k:'smoke',x:g.px+Math.cos(a)*r,y:g.py-10+Math.sin(a)*r*0.6,vx:-Math.cos(a)*r*1.4,vy:-Math.sin(a)*r*0.8,drag:1.2,life:0.8,r:5,col:'#a890ff'}); }
        spBurst(g.px,g.py-14,cols,22,50,{life:0.9}); tone('sine',600,200,0.7,0.05);
        msg='You become wonderfully uninteresting for three hours. Fish will not notice you either.';
      } else if(n==='Hearthsong'){
        x.cd={}; g.boost=150; setCd('Hearthsong',SPCD.Hearthsong);
        for(let i=0;i<4;i++) setTimeout(()=>{ spRing(g.px,g.py-4,cols[i%3],6,70+i*10,1,2.5); },i*160);
        for(let i=0;i<22;i++) spP({k:'note',x:g.px+(Math.random()-0.5)*40,y:g.py-10,vx:(Math.random()-0.5)*30,vy:-40-Math.random()*50,drag:0.4,life:1.4+Math.random()*0.6,r:3,col:cols[i%3]});
        [523,659,784,1047].forEach((f,i)=>setTimeout(()=>tone('sine',f,f,0.3,0.06),i*130));
        msg='You sing the whole song, and every spell is ready again.';
      }
      finish(msg);
    };
  }
  SPF.windup=w;
}

/* an Umbral Wood obstacle was hit: only the right spell clears it */
function spUobs(n,tg){
  const t=tg.t, u=UTXT[t], i=uwObstacle(tg.tx,tg.ty);
  if(SPNEED[n]===u.need&&i>=0){ spUwClear(i,t,tg.tx,tg.ty); return ''; }
  spBurst(tg.x,tg.y,SP_COL[n],12,50,{life:0.5});
  return 'The '+({[UTHORN]:'thorns',[UFOG]:'fog',[UBOULD]:'boulder',[USHADE]:'shadow',[UCURSE]:'curse'}[t]||'obstacle')+' does not care about '+n+'. '+({[UTHORN]:'It wants fire.',[UFOG]:'It wants wind.',[UBOULD]:'It wants a rune.',[USHADE]:'It wants light.',[UCURSE]:'It wants a ward.'}[t]||'');
}
/* the Z-key route into an obstacle: with the right item in hand, just cast it, no questions */
function spUwBlast(t,tx,ty,i,need){
  const n=SP_BY_ITEM[need]; if(!n) return;
  const h=spHand(), cols=SP_COL[n], to={x:(tx+0.5)*TS,y:(ty+0.5)*TS-6};
  g.time<SPF.busy||(SPF.busy=g.time+0.8);
  tone('triangle',300,700,0.25,0.06);
  spFly(n,h,to,()=>spUwClear(i,t,tx,ty),{spd:300,size:3.4,trail:n==='Stone'?'rune':n==='Frost'?'flake':'dot'});
}

/* ---------------- the spell bar ---------------- */
const spBar=document.createElement('div'); spBar.className='spellbar'; spBar.id='spellbar'; spBar.hidden=true;
document.getElementById('stage').appendChild(spBar);
const SP_ICON={
  Spark:c=>{ c.beginPath(); c.moveTo(9.5,1.5); c.lineTo(4,9); c.lineTo(7.6,9); c.lineTo(6,14.5); c.lineTo(12,6.5); c.lineTo(8.4,6.5); c.closePath(); c.fill(); },
  Kindle:c=>{ c.beginPath(); c.moveTo(8,1.5); c.quadraticCurveTo(13.5,7,11.6,11.5); c.quadraticCurveTo(10.5,14.5,8,14.5); c.quadraticCurveTo(4.5,14.5,4.3,10.6); c.quadraticCurveTo(4.3,8,6.2,6.4); c.quadraticCurveTo(6.2,8.2,7.3,8.4); c.quadraticCurveTo(6.6,5,8,1.5); c.fill(); },
  Lumen:c=>{ c.beginPath(); c.arc(8,8,3.4,0,6.283); c.fill(); c.lineWidth=1.4; for(let i=0;i<8;i++){ const a=i*0.785; c.beginPath(); c.moveTo(8+Math.cos(a)*5.2,8+Math.sin(a)*5.2); c.lineTo(8+Math.cos(a)*7.4,8+Math.sin(a)*7.4); c.stroke(); } },
  Gust:c=>{ c.lineWidth=1.6; c.lineCap='round'; c.beginPath(); c.moveTo(2,5); c.lineTo(9.5,5); c.arc(9.5,3.2,1.8,1.57,-1.8,true); c.stroke(); c.beginPath(); c.moveTo(2,8.4); c.lineTo(12,8.4); c.arc(12,10.4,2,-1.57,1.2); c.stroke(); c.beginPath(); c.moveTo(2,12); c.lineTo(7,12); c.stroke(); },
  Ward:c=>{ c.beginPath(); c.moveTo(8,1.5); c.lineTo(13.5,3.6); c.quadraticCurveTo(13.5,10.5,8,14.5); c.quadraticCurveTo(2.5,10.5,2.5,3.6); c.closePath(); c.fill(); c.fillStyle='rgba(0,0,0,0.45)'; c.fillRect(7.3,4,1.4,7); c.fillRect(5,6.4,6,1.4); },
  Mend:c=>{ c.fillRect(6.6,2.5,2.8,11); c.fillRect(2.5,6.6,11,2.8); c.fillStyle='rgba(0,0,0,0.35)'; c.fillRect(7.4,3.5,1.2,9); },
  Stone:c=>{ c.lineWidth=1.6; c.beginPath(); c.moveTo(8,1.5); c.lineTo(13,8); c.lineTo(8,14.5); c.lineTo(3,8); c.closePath(); c.stroke(); c.beginPath(); c.moveTo(8,4.5); c.lineTo(8,11.5); c.moveTo(5.6,7); c.lineTo(10.4,9.4); c.stroke(); },
  Seek:c=>{ c.beginPath(); c.ellipse(8,9.4,3.6,4.6,0,0,6.283); c.fill(); c.beginPath(); c.arc(8,4.2,1.9,0,6.283); c.fill(); c.lineWidth=1.2; for(const y of [7.4,10,12.4]){ c.beginPath(); c.moveTo(4.4,y); c.lineTo(2.2,y+1); c.moveTo(11.6,y); c.lineTo(13.8,y+1); c.stroke(); } },
  Bind:c=>{ c.lineWidth=1.8; c.beginPath(); c.arc(5.2,6.5,3,0,6.283); c.stroke(); c.beginPath(); c.arc(10.8,6.5,3,0,6.283); c.stroke(); c.beginPath(); c.moveTo(7,9); c.lineTo(4.4,14.5); c.moveTo(9,9); c.lineTo(11.6,14.5); c.stroke(); },
  Frost:c=>{ c.lineWidth=1.5; c.lineCap='round'; for(let i=0;i<3;i++){ const a=i*1.047; c.beginPath(); c.moveTo(8+Math.cos(a)*6.6,8+Math.sin(a)*6.6); c.lineTo(8-Math.cos(a)*6.6,8-Math.sin(a)*6.6); c.stroke(); } },
  Veil:c=>{ c.beginPath(); c.moveTo(1.5,8); c.quadraticCurveTo(8,1,14.5,8); c.quadraticCurveTo(8,15,1.5,8); c.closePath(); c.lineWidth=1.5; c.stroke(); c.beginPath(); c.arc(8,8,2.4,0,6.283); c.fill(); },
  Hearthsong:c=>{ c.beginPath(); c.ellipse(5.4,12,3,2.3,-0.4,0,6.283); c.fill(); c.lineWidth=1.6; c.beginPath(); c.moveTo(8,11.4); c.lineTo(8,2.5); c.lineTo(12.5,4.5); c.stroke(); }
};
function spIconCanvas(n){
  const cv2=document.createElement('canvas'); cv2.width=32; cv2.height=32; const c=cv2.getContext('2d'), col=SP_COL[n];
  const gr=c.createRadialGradient(16,16,2,16,16,17); gr.addColorStop(0,'#33473f'); gr.addColorStop(1,'#16231e'); c.fillStyle=gr; c.fillRect(0,0,32,32);
  c.save(); c.translate(0,0); c.scale(2,2); c.fillStyle=col[0]; c.strokeStyle=col[0]; c.shadowColor=col[0]; c.shadowBlur=3; SP_ICON[n](c); c.restore();
  return cv2;
}
const spSlots={}; let spSig='', spLastHeld=null;
for(const s of SPELLS){
  const n=s[0], d=document.createElement('div'); d.className='spb'; d.dataset.n=n; d.hidden=true;
  d.appendChild(spIconCanvas(n));
  const cd=document.createElement('div'); cd.className='spcd'; d.appendChild(cd);
  const lk=document.createElement('div'); lk.className='splk'; d.appendChild(lk);
  d.style.setProperty('--sc',SP_COL[n][0]);
  d.addEventListener('click',e=>{ e.stopPropagation(); if(g.mode!=='play') return; if(spGetSel()===n) spellCast(n); else { spSetSel(n); blip(); spSig=''; } });
  spBar.appendChild(d); spSlots[n]={d:d,cd:cd,lk:lk};
}
const spHint=document.createElement('div'); spHint.className='sphint'; spHint.textContent='Q E choose  C cast'; spBar.appendChild(spHint);
function spGetSel(){ const x=XS(); return x.spSel||'Spark'; }
function spSetSel(n){ XS().spSel=n; spSig=''; }
function spBarUpdate(){
  const vis=g.mode==='play'&&(g.scene==='world'||g.scene==='sx')&&(magicDays()>=1||(typeof swStorySpell==='function'&&swStorySpell()));
  if(spBar.hidden===vis) spBar.hidden=!vis;
  if(!vis) return;
  const known=spKnown(), sel=spGetSel(), x=XS();
  let sig=known.length+'|'+sel+'|';
  const st={};
  for(const n of known){
    const need=SPNEED[n], locked=!!(need&&!isHeld(need)), rem=spellReady(n)?0:(x.cd[n]-xAbs()), tot=Math.max(0.5,SPCD[n]||0.5), frac=Math.min(1,rem/tot);
    st[n]={locked:locked,frac:Math.round(frac*20)/20};
    sig+=n+(locked?'L':'')+st[n].frac+',';
  }
  if(sig===spSig) return; spSig=sig;
  for(const s of SPELLS){
    const n=s[0], sl=spSlots[n], k=known.indexOf(n)>=0;
    sl.d.hidden=!k; if(!k) continue;
    sl.d.classList.toggle('sel',n===sel); sl.d.classList.toggle('lock',st[n].locked);
    sl.cd.style.height=(st[n].frac*100)+'%';
    const need=SPNEED[n];
    sl.d.title=n+'  -  '+s[1]+(need?(st[n].locked?'   (hold the '+ITEMS[need].name+' to cast)':'   (using the '+ITEMS[need].name+')'):'');
  }
}
{
  const _upd=updateHud;
  updateHud=function(){ _upd(); spBarUpdate(); };
}

/* ---------------- wiring: keys, the per-frame update, drawing ---------------- */
KEYMAP.q='sp_prev'; KEYMAP.Q='sp_prev'; KEYMAP.e='sp_next'; KEYMAP.E='sp_next';
function spCycle(d){
  const known=spKnown(); if(!known.length) return;
  let i=known.indexOf(spGetSel()); if(i<0) i=0; i=(i+d+known.length)%known.length;
  spSetSel(known[i]); blip(); toast(known[i],700);
}
openCast=function(){ spellCast(spGetSel()); };
castSpell=function(n){ spellCast(n); };
{
  const _press=press;
  press=function(k){
    if(g.mode==='play'&&g.scene==='world'){
      if(k==='sp_prev'){ spCycle(-1); return; }
      if(k==='sp_next'){ spCycle(1); return; }
      if(k==='z'&&!g.target){
        const hid=heldId(), n=hid&&SP_BY_ITEM[hid];
        if(n&&magicDays()>=1){ spellCast(n); return; }
      }
    }
    _press(k);
  };
  const _update=update;
  update=function(dt){
    _update(dt); spUpdate(dt);
    /* holding a magic item picks its spell */
    const hid=g.mode==='play'?heldId():null;
    if(hid!==spLastHeld){ spLastHeld=hid; if(hid&&SP_BY_ITEM[hid]&&spKnown().indexOf(SP_BY_ITEM[hid])>=0) spSetSel(SP_BY_ITEM[hid]); }
  };
  const _dp=drawParts;
  drawParts=function(c,kind,kd){ _dp(c,kind,kd); spDraw(c,kd); };
  const _dm=drawMe;
  drawMe=function(c,time){
    const veil=XS().veilUntil>xAbs();
    if(veil){ c.save(); c.globalAlpha=0.45+0.1*Math.sin(g.time*3); }
    _dm(c,time);
    if(veil) c.restore();
  };
}
