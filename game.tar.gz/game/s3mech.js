'use strict';
/* ===== THE LONG ROAD, IN YOUR HANDS (v1.18) =====
   More of the 1.16 systems now answer to the story:
   - EMBERLIGHT, a thirteenth spell, taught by the story at chapter 11. Older spells react to Ember plants.
   - More herbalist work (side commissions), and brews that open side scenes in the new lands.
   - Story-aware stock in the toolshed, tackle shop, surveyor, naturalist, apothecary and provisions stall.
   - A STORY page in the Collection Log (press L, then Z until you reach it).
   - The Ash Carp (a fish for the ward-pot) and the Sleeper's Lily (a flower that blooms only near the sleepers). */

const SW_SPELL='Emberlight';
const swStorySpell=()=>{ if(!swStarted()) return false; const q=s2(); return swChNum()>=11||!!q.ending||!!(q.done&&q.done.c11); };
const SW_EMBERB=new Set(['ashwood','cinder','ridge','fen','sealed','hollow']);

/* ---------------- 1. EMBERLIGHT ---------------- */
SPELLS.push([SW_SPELL,'A Keeper\'s flame: it burns without fuel and without argument. Calms the ward-hum, lights the dark, and wakes Ember plants.']);
SPCD[SW_SPELL]=6;
SP_COL[SW_SPELL]=['#ff9d2e','#ffd166','#fff0b0'];
SP_ICON[SW_SPELL]=c=>{ c.beginPath(); c.moveTo(8,1.5); c.quadraticCurveTo(13,6,11.6,10.6); c.quadraticCurveTo(10.6,14.5,8,14.5); c.quadraticCurveTo(5,14.5,4.4,10.6); c.quadraticCurveTo(4,7.5,6.4,5.6); c.quadraticCurveTo(6.6,7.6,7.8,7.4); c.quadraticCurveTo(9,5,8,1.5); c.fill(); c.fillStyle='rgba(255,255,255,0.55)'; c.beginPath(); c.ellipse(8,11.4,1.6,2.4,0,0,6.283); c.fill(); };
{
  const n=SW_SPELL, d=document.createElement('div'); d.className='spb'; d.dataset.n=n; d.hidden=true;
  d.appendChild(spIconCanvas(n));
  const cd=document.createElement('div'); cd.className='spcd'; d.appendChild(cd);
  const lk=document.createElement('div'); lk.className='splk'; d.appendChild(lk);
  d.style.setProperty('--sc',SP_COL[n][0]);
  d.addEventListener('click',e=>{ e.stopPropagation(); if(g.mode!=='play') return; if(spGetSel()===n) spellCast(n); else { spSetSel(n); blip(); spSig=''; } });
  spBar.insertBefore(d,spBar.querySelector('.sphint')); spSlots[n]={d:d,cd:cd,lk:lk};
}
function swEmberNear(r){
  const p=s2tile(), w=WD(); let found=[];
  for(let dy=-r;dy<=r;dy++) for(let dx=-r;dx<=r;dx++){
    const x=p.x+dx, y=p.y+dy, t=tileAt(x,y), cat=WL_TILECAT[t];
    if(cat!=='flower'&&cat!=='mush'&&cat!=='bush') continue;
    if(w.gone[x+','+y]) continue;
    const sp=wlSpeciesAt(x,y,t); if(sp&&SW_EMBERB.has(sp.biome)) found.push([x,y,sp]);
  }
  return found;
}
{
  const _sc=spellCast;
  spellCast=function(n){
    if(n!==SW_SPELL) return _sc(n);
    if(g.mode!=='play'||g.scene!=='world') return;
    const known=spKnown();
    if(known.indexOf(n)<0){ toast('You have not learned '+n+' yet.',2200); return; }
    if(!spellReady(n)){ toast(n+' is still settling: ready in '+xIn(XS().cd[n]-xAbs())+'.',2200); return; }
    if(g.time<SPF.busy||SPF.windup) return;
    SPF.busy=g.time+0.5; spSetSel(n); setCd(n,SPCD[n]);
    const cols=SP_COL[n], x=XS();
    SPF.windup={n:n,t:0.16,max:0.16,go:()=>{
      x.lumenUntil=Math.max(x.lumenUntil||0,xAbs()+3); fxGive('ward',5);
      for(let i=0;i<3;i++) spRing(g.px,g.py-4,cols[i%3],8,48+i*10,0.9+i*0.12,2.5);
      spBurst(g.px,g.py-20,cols,40,100,{up:50,g:-30,life:1}); spLight(g.px,g.py-20,170,'#ffd9a0',0.8);
      tone('triangle',360,900,0.5,0.06); tone('sine',540,540,0.3,0.04);
      const near=swEmberNear(5); let msg='A steady flame settles on your shoulder for three hours, and the ward-hum goes quiet for five.';
      if(near.length){
        BS().ess.ember=(BS().ess.ember||0)+1; if(swStarted()) SWS().ember++;
        const sp=near[0][2];
        for(const q of near.slice(0,3)) spBurst((q[0]+0.5)*TS,(q[1]+0.5)*TS-6,['#ff9d2e','#ffd166','#fff0b0'],14,60,{up:30,g:-20,life:0.8});
        msg+=' '+(near.length>1?near.length+' Ember plants':'A '+sp.name)+' nearby lean toward it, and a drop of Ember Essence gathers. (Ember: '+BS().ess.ember+')';
      }
      const where=swStarted()&&swZone()===2?' The Burnt Wood hums a fifth note, and, for a moment, leaves it unresolved.':'';
      toast(msg+where,msg.length>150?6200:4600);
    }};
  };
  const _sxc=sxCan;
  sxCan=function(sp){ if(sp===SW_SPELL) return swStorySpell(); return _sxc(sp); };
  const _sxcast=sxCast;
  sxCast=function(sp){
    if(sp!==SW_SPELL) return _sxcast(sp);
    const S=SX.S; if(!S) return;
    S.lumen=Math.max(S.lumen||0,50); toast('Emberlight: a small, steady flame. The dark makes room for it.',2600);
    const v=DIRV[g.dir], tx=Math.floor((g.px+v.x*16)/TS), ty=Math.floor((g.py-6+v.y*16)/TS);
    const o=sxObjAt(S,tx,ty); if(o&&o.cast&&o.cast[sp]) o.cast[sp](S,o,tx,ty);
  };
}
/* the spell is taught the moment chapter 11 begins */
{
  const _begin=S2.begin;
  S2.begin=function(id,skip){
    const first=!swStorySpell();
    _begin(id,skip);
    if(first&&swStorySpell()&&!K3().spellTold){ K3().spellTold=1; let tries=0; const tell=()=>{ if(g.mode!=='play'){ if(++tries<60) setTimeout(tell,1000); return; } say('Hermit Mallow',['(Something warm, behind your eyes. A flame the colour of the Hearth, steady as a held note.)','Mallow used to say a Keeper has one spell, and it is not for fighting. It is for the long dark. I think you have just been given it.','Emberlight. Press Q or E to find it on the spell bar, then C. It lights the dark, and the ward-hum quietens. Ember plants lean toward it, and give a little up.']); }; setTimeout(tell,1500); }
  };
}

/* older spells react to the Ember plants */
const SW_RX={
  Kindle:{'Hearthbloom':'ess','Winter Hearthbloom':'ess','Ember Thistle':'ess','Hearthwood':'ess','Ember Berry':'ess'},
  Frost:{'Ember Thistle':'ess','Hearthbloom':'ess','Fireweed':'ess','Winter Hearthbloom':'ess'},
  Mend:{'Ash Poppy':'mercy','Keeper\'s Lily':'mercy','Emberwick Rose':'mercy','Weeping Bellflower':'mercy'},
  Gust:{'Hum-Cap':'roll','Wisp-Heather':'roll','Cotton-Ash':'roll','Ash Reed':'roll'},
  Spark:{'Marsh Lantern':'luck','Lantern Cap':'luck','Lantern Morel':'luck','Fen Glimmer':'luck','Lantern Alder':'luck'},
  Stone:{'Ashglass Crystal':'glass','Rime Crystal':'glass','Hearthstone Geode':'glass','Ember-Veined Rock':'glass'}
};
const SW_RXTXT={
  Kindle:'The Ember plant drinks the flame like a compliment and hands it back brighter. A bead of Ember Essence gathers on the ash.',
  Frost:'Frost walks up the stem and stops at the bloom. The bloom stays warm. Ember Essence beads in the cold.',
  Mend:'The plant stands up, straight, and for a moment the whole bed is the colour of the Hearth. Somewhere, a small mercy is noted.',
  Gust:'The spores lift, all together, and drift off in a long grey ribbon. Something in the ribbon is glowing.',
  Spark:'The lantern-plant flares in answer. You feel quick, and slightly lucky, and watched in a friendly way.',
  Stone:'The rune finds the crystal and the crystal hums back, four notes. A shard breaks off and lands in your wing.'
};
for(const n in SW_RX){
  const _f=SPI[n];
  SPI[n]=function(tg){
    let sp=null;
    if(tg&&tg.k==='tile'&&(tg.cat==='plant'||tg.cat==='rock'||tg.cat==='tree')){ try{ sp=wlSpeciesAt(tg.tx,tg.ty,tg.t); }catch(e){} }
    const key=sp&&SW_RX[n][sp.name];
    const base=_f.call(this,tg);
    if(!key) return base;
    let extra=SW_RXTXT[n];
    if(key==='ess'){ BS().ess.ember=(BS().ess.ember||0)+1; if(swStarted()) SWS().ember++; }
    else if(key==='mercy'){ if(swStarted()) s2led('mercy',1); }
    else if(key==='roll'){ const p=swEmberChance; if(swStarted()){ BS().ess.ember=(BS().ess.ember||0)+1; SWS().ember++; } }
    else if(key==='luck'){ fxGive('luck',1); g.boost=Math.min(150,(g.boost||0)+25); }
    else if(key==='glass'){ addItem('s_ashglass'); }
    coin();
    return (base===null?'':(base||''))+(base?' ':'')+extra;
  };
}

/* the lands the ward leans on now count as the Burnt Wood for foraging luck */
{
  const _z=swZone;
  swZone=function(){
    const z=_z(); if(z) return z;
    if(!swStarted()||g.scene!=='world') return 0;
    const p=s2tile();
    if(swIn(SWR.ash,p.x,p.y)||swIn(SWR.seal,p.x,p.y)) return 2;
    return 0;
  };
  const _ec=swEmberChance;
  swEmberChance=function(){ let p=_ec(); if(p>0&&isHeld('s_ashrake')) p=Math.min(0.6,p*1.3); if(p>0&&fxLeft('glow')>0) p=Math.min(0.6,p*1.1); return p; };
}

/* ---------------- 2. NEW ITEMS, AND WHAT THE SHOPS SELL ---------------- */
const SW_NEWITEMS={
  s_ashrake:{name:'Ash-Rake',price:22,desc:'A wide wooden rake. Hold it in the Burnt Wood or the Ashlands and the ash gives up its Ember a little more readily.',use:'note',note:'You rake the air. The air is not impressed.',glyph:'shovel',gc:['#6a5a4a','#9a8a7a','#ffb347'],cat:'tool'},
  s_fenlure:{name:'Fen-Candle Lure',price:9,desc:'A lure with a green glow-bead for an eye. Carp in the Ashen Fen cannot leave it alone. Keep it in your pack when you fish there.',use:'note',note:'The bead glows green, patiently.',glyph:'lure',gc:['#9ad8c0','#3a7a66','#e8fff4'],cat:'tool'},
  s_ashmap:{name:'Ash Road Survey',price:12,desc:'A surveyor\'s sketch of the Ash Road, from the Ward Wall to the Sealing Stones. Read it for directions to wherever the story needs you next.',use:'ashmap',glyph:'tmap',gc:['#c9b48a','#6a5a4a','#c0392b'],cat:'tool'},
  s_emberguide:{name:'Field Guide to Ember Plants',price:14,desc:'A thin book of pressed Ember plants, in a naturalist\'s cramped hand. Open it to read where each grows.',use:'emberguide',glyph:'clog',gc:['#7a3a1a','#f4efe0','#ffb347'],cat:'tool'},
  s_wardsalve:{name:'Ward-Salve',price:18,desc:'A warm salve in a tin. Rub it on your temples and the ward\'s whisper goes quiet for two hours.',use:'note',note:'',glyph:'tin',gc:['#a8aeb8','#ff9d2e','#ffe0b0'],cat:'potion'},
  s_lrration:{name:'Lantern Road Rations',price:8,desc:'Bread, pear, a wedge of Hollow cheese. Baked in Emberwick, packed in Kingsbill, eaten wherever the road goes.',use:'eat',boost:60,quip:'Warm bread, firm pear, sharp cheese. You feel exactly as well fed as the road is long.',glyph:'sandwich',gc:['#d9a05b','#86b36a','#f6d55c'],cat:'food'},
  s_hobstew:{name:'Hob\'s Stew',price:10,desc:'A stew made by a cook who fed three hundred ducks along a hundred miles and never once put his name on it.',use:'eat',boost:90,quip:'It tastes of onions, time and being looked after.',glyph:'tea',gc:['#a8793f','#7a5a2a','#e0b84a'],cat:'food'}
};
for(const id in SW_NEWITEMS){ ITEMS[id]=Object.assign({nogift:false},SW_NEWITEMS[id]); }
FXD.s_wardsalve='ward3 glow300'; FXP.s_wardsalve=brFxParse(FXD.s_wardsalve);
ITEMS.s_wardsalve.desc+=' Use it: '+fxSummary(FXP.s_wardsalve)+'.';
const SW_STOCK=[
  ['hardware','s_ashrake',()=>swChNum()>=9||!!s2().ending],
  ['tackle','s_fenlure',()=>swChNum()>=16||!!s2().ending],
  ['cartog','s_ashmap',()=>swChNum()>=13||!!s2().ending],
  ['naturalist','s_emberguide',()=>swChNum()>=5||!!s2().ending],
  ['apoth','s_wardsalve',()=>swChNum()>=9||!!s2().ending],
  ['provision','s_lrration',()=>!!K3().road||(s2().done&&!!s2().done.c22)],
  ['provision','s_hobstew',()=>!!K3().w_hob]
];
{
  const _ss=shopStock;
  shopStock=function(b,town){
    const a=_ss(b,town);
    if(swStarted()) for(const r of SW_STOCK){ let ok=false; try{ ok=r[0]===b.kind&&r[2](); }catch(e){} if(ok&&!a.includes(r[1])) a.push(r[1]); }
    return a;
  };
}
{
  const _u=useItem;
  useItem=function(id){
    if(id==='ashmap'||id==='emberguide'){ return; }
    const it=ITEMS[id];
    if(it&&it.use==='ashmap'){
      const q=s2(), p=s2tile(); let tgt=null, nm='';
      if(q.ch==='c16x'){ const k=['mile','ridge','ferry','seal','hall','rim'][Math.min(5,q.step)]; if(k) { tgt=SW_WP[k]; nm=tgt.name; } }
      if(!tgt){ tgt=SW_WP.rim; nm='the Ash Road, from '+tgt.name; }
      const dx=tgt.x-p.x, dy=tgt.y-p.y, d=Math.round(Math.hypot(dx,dy)/5)*5;
      say('',['The survey is hand-inked, with little notes in the margin: "mind the ferry", "snow here", "do not look at the names too long".','It points '+wlDir(dx,dy)+' '+wlArrow(dx,dy)+' toward '+nm+'. About '+d+' waddles.']); return;
    }
    if(it&&it.use==='emberguide'){
      say('',['FIELD GUIDE TO EMBER PLANTS (a naturalist\'s notes)','Hearthbloom: found only in the Burnt Wood. Brew it with Ember into a Quiet Draught for a Prime result.','Ember Thistle: the Burnt Wood and the Cinder Fields. Kindle it or Frost it and it gives up Ember.','Marsh Lantern, Fen Glimmer: the Ashen Fen. Spark them and you will feel lucky.','Ash Poppy, Keeper\'s Lily, Emberwick Rose: Mend them and something kind happens somewhere.','Hum-Cap, Wisp-Heather: Gust them and the spores carry Ember.','Sleeper\'s Lily: blooms only near the sleepers, and only while they sleep.']); return;
    }
    _u(id);
  };
}

/* ---------------- 3. THE HERBALISTS' SIDE WORK, AND CHARACTER ---------------- */
Object.assign(DEEP,{
 'Herbalist Yarrow':{open:'Yarrow is grinding something that smells of thyme and woodsmoke, and has not looked up for some time.',
  topics:[
   {k:'y1',t:'"Why herbs?"',lines:['"My mother was a Warden, and I was not going to be. The Wardens fix things with force. I wanted to fix things slowly, with weeds."','"Slow is a very rude word in Emberwick. I find I like being rude."'],led:{trust:1}},
   {k:'y2',t:'"Do you believe in the Hearth?"',lines:['"I believe in the thing it does to a room. I am not sure that is the same as believing in the Hearth. I stopped being sure at about the time I stopped being afraid."'],led:{truth:1}},
   {k:'y3',t:'"What would you brew for yourself?"',lines:['She laughs. "A thing that tastes of the day before. Not the day before a disaster. The ordinary day. The day nobody wrote down. Do you know how rarely anyone asks for that one?"'],led:{mercy:1}}]},
 'Herbalist Marjoram':{open:'Marjoram is tying bundles of dried rosemary with the particular care of a woman who used to tie bandages for a living.',
  topics:[
   {k:'j1',t:'"You were a court physician."',lines:['"I was. Eleven years in the king\'s wing. I treated the ward-sickness before anyone knew what to call it. I prescribed rest, and fresh air, and silence. I was the best in the kingdom at silence."','"That was the cure, you see. Nobody was ever told what the disease was."'],led:{truth:1,crown:1}},
   {k:'j2',t:'"Why did you leave?"',lines:['"Because a physician who is not allowed to say what the illness is is a florist. So I became a florist. A herbalist, forgive me. It is the same job with fewer lies in it."'],led:{trust:1}},
   {k:'j3',t:'"What do you hope for?"',lines:['"That someone will make a recipe for what the king has, and that it will taste of nothing, and that he will drink it. And that I will be asked."'],led:{mercy:1,crown:1}}]}
});
SWC.push(
 {n:5,at:11,opt:true,title:'A Taste of the Wood',
  offer(N){ return ['I have been drinking nettle tea for a year. I am told there is a tea that tastes of the Burnt Wood: bark, smoke and a little courage. I should like to know what courage tastes like.','Brew an Ashwood Ember-Tea. It needs one drop of Burnt Wood Essence, which you will get from foraging in the Wood itself, and three of anything else. The Recipe Book will tell you the rest.']; },
  need:'p_ess_ashwood',count:1,label:'1 Ashwood Ember-Tea',hint:'Forage plants inside the Burnt Wood for Burnt Wood Essence, then open the Recipe Book (B).',
  thanks(N){ return ['It is smoky. It is warm. It is, I notice, slightly brave.','I have tasted it. I can now say it. It tastes of a hand on your shoulder.']; },
  pay(){ g.crumbs+=70; swBoost(2); coin(); return '+70 crumbs and a little standing.'; }},
 {n:6,at:16,opt:true,title:'A Candle for the Fen',
  offer(N){ return ['There is a lamp in the Ashen Fen that burns without fuel. The fen ducks call it a Marsh Candle. I want to drink the light, and I want to know what that means.','Brew a Fen-Candle Draught. It needs Fen Essence: forage in the Ashen Fen, along the river, and the reeds will oblige. The draught lets you see the candles. Do not drink it and then ask me what you saw.']; },
  need:'p_ess_fen',count:1,label:'1 Fen-Candle Draught',hint:'Forage in the Ashen Fen, west of the river, for Fen Essence, then brew at the Recipe Book (B).',
  thanks(N){ return ['Green. Of course it is green. Like pond-light in a teacup.','I shall not drink this one. I shall put it on the shelf and look at it on bad days. Somebody has to keep one.']; },
  pay(){ g.crumbs+=90; s2led('trust',1); swBoost(2); coin(); return '+90 crumbs. A small trust, quietly given.'; }},
 {n:7,at:21,opt:true,title:'For the Cold Room',
  offer(N){ return ['The waking are cold. Not in the body. In the place where they were kept. I have heard of a tonic made from Winter Essence, from the Sealed North, that warms a person from the inside of their memory.','Brew a Winter-Hearth Tonic. You will need Winter Essence, which means foraging in the snow near the Sealing Stones. Bring one back, and I will give a cup to every one of them.']; },
  need:'p_ess_sealed',count:1,label:'1 Winter-Hearth Tonic',hint:'Forage plants in the Sealed North, north of Emberwick, for Winter Essence, then brew it.',
  thanks(N){ return ['It is a lot of warmth for a very small cup.','I shall bring it to Orla first. She asked, once, if anyone knew how to make a person warm without a fire.']; },
  pay(){ g.crumbs+=120; s2led('mercy',1); swBoost(2); coin(); return '+120 crumbs, and a mercy.'; }},
 {n:8,at:22,opt:true,title:'A Wine for the Road',
  offer(N){ return ['The Lantern Road will have an opening, and an opening wants a toast. I am told the Hollow Wood makes a wine the colour of the red thread on every door.','Two Hollow Lantern-Wines. They need Hollow Essence, from foraging in the Hollow Wood, and three of anything. The road will be opened with something better than water.']; },
  need:'p_ess_hollow',count:2,label:'2 Hollow Lantern-Wines',hint:'Forage in the Hollow Wood, west of Emberwick, for Hollow Essence, then brew two.',
  thanks(N){ return ['Red. Oh, that is red. That is the colour the thread is.','It will not last a week. I do not think it needs to.']; },
  pay(){ g.crumbs+=200; addItem('s_lrration',3); s2led('mercy',1); swBoost(3); coin(); return '+200 crumbs, and three Lantern Road Rations.'; }}
);

/* ---------------- 4. BREWS OPEN SIDE SCENES IN THE NEW LANDS ---------------- */
{
  const _fa=fxApply;
  fxApply=function(id,list){
    const ok=_fa(id,list);
    if(ok&&id&&/^p_ess_/.test(id)){ const d=K3().drunk||(K3().drunk={}); d[id]=s2now(); }
    return ok;
  };
}
const swRecent=(id,h)=>{ const d=(K3().drunk||{})[id]; return d!==undefined&&s2now()-d<=(h||6); };
const swLate=()=>swStarted()&&(swChNum()>=17||!!s2().ending);
S2.prop({id:'fen_candles',wx:-46,wy:-1160,glyph:'candle',col:'#9ad8c0',when:()=>swLate()&&!K3().sc_fen,mark:()=>swRecent('p_ess_fen')?'!':null,use(){
  if(!swRecent('p_ess_fen',8)){ say('',['Something moves among the reeds, very faint, green, too thin to look at directly. You hear a small sound, almost a hum, that stops when you look.','(A Fen-Candle Draught would help you see it.)']); return; }
  seq([['',['The draught works. The reeds are full of lights: small, green, steady, each set on a flat stone at the water\'s edge, each in front of an empty place where someone sat.','They are candles. There are hundreds. They are lit by the fen ducks, every night, for the walkers of the Ash Road, in case any of them are still walking. They have been doing it for a hundred years, and no one has ever come.']]],()=>{
    choose('The Marsh Candles','There is a stone, and no candle on it yet.',['Light one for Bree.','Light one for Alder, who held on.','Light one for the king on the wall.','Light one for everyone.'],k=>{
      K3().sc_fen=1+k; addItem('f_marshcandle'); s2led(['kin','mercy','trust','truth'][k],1); coin();
      say('',['You set the candle on the stone. It lights itself from the reed-light, the same quiet green.','Along the water, a hundred candles bend, together, toward the new one. Something in the fen, very small, says thank you.','(Received: Marsh Candle.)'],()=>{ hudCache.obj=null; });
    },3);
  });
}});
S2.prop({id:'hollow_notebook',wx:WX0+12,wy:WY0+12,glyph:'scroll',col:'#e0603f',when:()=>swLate()&&!K3().sc_hollow,mark:()=>swRecent('p_ess_hollow')?'!':null,use(){
  if(!swRecent('p_ess_hollow',8)){ say('',['A notebook, pinned open on a stump with a red-thread knot. The ink is faded until it is only dents in the paper. Every page has a pressed tulip.','(A Hollow Lantern-Wine would help you read the dents.)']); return; }
  seq([['',['The wine warms the back of your eyes. The dents on the page turn to ink: tidy, tired, round hand, a Keeper\'s.','"Day 1. Counted the lanterns. 40." "Day 2. Counted the lanterns. 40." The entries go on, for thirty years. Nothing else. Then one day: "Day 10,847. Counted the lanterns. 41. One more. I do not know whose."','The last line: "I was not counting lanterns. I was counting how many of us were still afraid. One fewer today."']]],()=>{
    K3().sc_hollow=1; addItem('h_keepertulip'); s2led('truth',1); s2led('mercy',1); coin(); say('',['You press the tulip back into the page where you found it, and close the book gently, and leave the red thread on the stump. (Received: Pressed Keeper\'s Tulip.)'],()=>{ hudCache.obj=null; });
  });
}});
S2.prop({id:'cold_room',wx:SW_RUIN.x+6,wy:SW_RUIN.y-4,glyph:'grave',col:'#cfe0ff',when:()=>swLate()&&!K3().sc_cold,mark:()=>swRecent('p_ess_sealed')?'!':null,use(){
  if(!swRecent('p_ess_sealed',8)){ say('',['A room with three walls and a roof of snow. There is a small bundle on a shelf, and the cold around it is the kind that has been waiting.','(A Winter-Hearth Tonic would warm you enough to go closer.)']); return; }
  seq([['',['The tonic holds. The cold stops being a wall and becomes a weather. You go closer.','A rag doll, with a button for one eye, sitting on a shelf that has been swept. Someone sweeps it. Someone has been sweeping it for a hundred years.','On the shelf below, a card, in a weaver\'s square hand: "For whoever is cold. She is loved. Please say so."']]],()=>{
    choose('The Cold Room','The doll waits.',['"She is loved."','"Sedge made you. You were good."','Say nothing, and sit with her.'],k=>{
      K3().sc_cold=1+k; addItem('n_sedgedoll'); s2led(['kin','mercy','trust'][k],1); coin();
      say('',[['Your voice is the first one in the room for a century. It is a plain sentence. The doll does not move, but the cold, very slightly, lets go.','You say it twice, to be sure. The button eye catches a light that is not in the room.','You sit. Snow falls on the roof. When you stand up, you have been there a long time, and you are warm. (Received: Sedge\'s Rag Doll.)'][k]],()=>{ hudCache.obj=null; });
    },2);
  });
}});

/* ---------------- 5. FISHING AND FORAGING BEATS ---------------- */
FISH.push({id:'ashcarp',n:'Ash Carp',v:20,w:0,col:'#9a9aa8',rare:1});
FISHIDS.push('ashcarp'); FISHBY.ashcarp=FISH[FISH.length-1];
ITEMS.fish_ashcarp={name:'Ash Carp',price:20,nogift:true,use:'note',desc:'A grey carp with an ember-orange eye. They live in the Ashen Fen and, the old ferriers say, they keep the water honest. A rare catch.',note:'It flops once, and glows.'};
RICON.fish_ashcarp=(R,C,E)=>{ E(7,8,5.5,3.4,'#9a9aa8'); R(11,5,2,6,'#7a7a88'); R(12,6,2,4,'#7a7a88'); R(3,7,1,1,'#ff9d2e'); R(5,10,4,1,'rgba(255,255,255,0.35)'); };
{
  const _pf=pickFish;
  pickFish=function(S){
    if(swStarted()&&g.scene==='world'){
      const p=s2tile(), z=swZoneOf(p.x,p.y);
      if(z==='fen'||z==='ridge'||inBW(p.x,p.y)){
        const dusk=g.clock>=17||g.clock<6;
        let c=0.07+(dusk?0.08:0)+S/10*0.12+(g.inv.s_fenlure?0.14:0)+(fxLeft('angler')>0?0.06:0);
        if(z==='fen') c+=0.06;
        if(rnd()<c) return FISHBY.ashcarp;
      }
    }
    return _pf(S);
  };
  BUY.curio.only=(BUY.curio.only||[]).concat(['ashcarp']);
}
{
  const d=S2.npcs.find(x=>x.id==='pim'), _t=d.talk;
  d.when=()=>s2at('c16x',2)||s2at('c16x',3)||!!K3().pimMet;
  d.talk=function(n,done){
    const k=K3();
    if(k.bridged&&swChNum()>=17||s2().ending){
      if(!k.carp){
        if(!k.carpAsk){ k.carpAsk=1;
          seq([['Ferrier Pim',['Now that it holds, I have a favour, and I am embarrassed to ask. It is an old thing.','The ferriers of the Fen kept a ward-pot at the crossing: a clay pot, with a carp in it, one grey ash-carp from the water. The carp is not eaten. It is looked at. It keeps the water honest. It died the year of the flood, and I never replaced it.','If you catch an Ash Carp, put the rod in at dusk, and keep a Fen-Candle Lure in your pack: bring it to me and I will set it in the pot.']]],()=>{ done(); }); return; }
        if((g.inv.fish_ashcarp||0)>0){
          delInv('fish_ashcarp'); k.carp=1; g.crumbs+=100; addItem('f_fenshell'); s2led('mercy',1); s2led('kin',1); coin();
          seq([['Ferrier Pim',['(He lifts the carp in both wings, and does not say anything for a moment. Its eye is an ember.)','"Oh. Oh, there you are. They are never very large, are they."','He sets it in the pot, which he has scrubbed. It floats, and turns, and looks at the fen the way a clerk looks at a ledger. The water around the crossing clears.','"That is the sound of it being honest," says Pim, quietly. "It is not a loud sound."']],['',['+100 crumbs. (Received: Fen-Pearl Shell.)']]],done); return; }
        say('Ferrier Pim',['The pot is empty. An Ash Carp bites at dusk, in the fen, and likes a lure with a green eye. (Keep a Fen-Candle Lure in your pack.)'],done); return;
      }
      say('Ferrier Pim',['The carp is well. It looks at me, in the evenings, with the expression of a carp who knows precisely how much I owe the river.'],done); return;
    }
    _t.call(this,n,done);
  };
}
/* the Sleeper's Lily blooms only near the sleepers, and only while they sleep */
{
  const b=WL_BY.ashwood;
  const sp=swP('flower',['Sleeper\'s Lily','lily',['#e8e0ff','#9a8ac8','#4a5a3a'],{glow:'168,140,230'},4,0.0001]);
  sp.id='ashwood:flower:99'; sp.cat='flower'; sp.biome='ashwood'; sp.rank=99; sp.hand=true; sp.rare=true;
  WL_SPECIES[sp.id]=sp; WL_SPLIST.push(sp); b.sps.push(sp);
  window.SW_LILY=sp;
  const CX=KX-66, CY=KY-63;
  const near=(x,y)=>Math.hypot(x-CX,y-CY)<=11;
  const _wsa=wlSpeciesAt;
  wlSpeciesAt=function(x,y,t){
    const s=_wsa(x,y,t);
    if(WL_TILECAT[t]==='flower'&&near(x,y)&&g.story&&g.story.s2&&!s2().ending&&hash(x,y,3301)<0.4) return SW_LILY;
    return s;
  };
}

/* ---------------- 6. THE COLLECTION LOG GETS A STORY PAGE ---------------- */
WL_TABS.push('Story');
const SW_STORYLOG=[
  ['keeperlantern','Mallow gives it to you, early in the long road.'],
  ['hearthcoal','Given on the crown road, in the dark, by someone who trusts you.'],
  ['wardlens','The reward for the second herbalist commission: the Ember finds.'],
  ['s_kettle','The reward for the last herbalist commission: The Last Kettle.'],
  ['w_whistle','Mallow gives it to you at the end of the Ash Road.'],
  ['c_mitten','A lost thing on the Cinder Fields. The Keeper\'s Road asks for it.'],
  ['w_cairnstone','A lost thing on Weeping Ridge. The Keeper\'s Road asks for it.'],
  ['f_reedpipe','A lost thing in the Ashen Fen. The Keeper\'s Road asks for it.'],
  ['b_hobjug','A cook\'s water-jug. It turns up in the Burnt Wood. A cook will want it.'],
  ['f_marshcandle','Light a candle in the fen, with a Fen-Candle Draught in you.'],
  ['h_keepertulip','Read the Keeper\'s notebook in the Hollow Wood, with a Hollow Lantern-Wine in you.'],
  ['n_sedgedoll','Sit with the doll in the Sealed North, with a Winter-Hearth Tonic in you.'],
  ['f_fenshell','Set an Ash Carp in the ward-pot for the Ferrier.'],
  ['fish_ashcarp','An Ash Carp, from the Ashen Fen at dusk.'],
  ['s_ashglass','Ashglass, from the Burnt Wood, or from a Stone spell cast at a crystal.'],
  ['s_hobstew','Hob\'s Stew, sold in provisions stalls once the cook has been found.']
];
const swEver=()=>{ const s=g.story.s3||(g.story.s3={}); return s.ever||(s.ever={}); };
{
  const _hud=updateHud;
  updateHud=function(){ _hud(); if(!g.story) return; const e=swEver(); for(const r of SW_STORYLOG) if(g.inv[r[0]]>0&&!e[r[0]]) e[r[0]]=1; };
  const _li=wlLogItems;
  wlLogItems=function(){ if(wlLog.tab!==3) return _li(); const e=swEver(); return SW_STORYLOG.filter(r=>ITEMS[r[0]]).map(r=>({id:r[0],story:true,got:!!e[r[0]],n:1,where:r[1]})); };
  const _l0=wlLogItems0;
  wlLogItems0=function(){ if(wlLog.tab!==3) return _l0(); const e=swEver(); const r=SW_STORYLOG.filter(x=>ITEMS[x[0]]); return {got:r.filter(x=>e[x[0]]).length,tot:r.length}; };
  const _lc=wlLogCount;
  wlLogCount=function(){ const c=_lc(), e=swEver(), r=SW_STORYLOG.filter(x=>ITEMS[x[0]]); c.push([r.filter(x=>e[x[0]]).length,r.length]); return c; };
}

/* ---------------- 7. JOURNAL ---------------- */
{
  const _je=journalExtra;
  journalExtra=function(sec,line){
    _je(sec,line);
    if(!swStarted()) return;
    const k=K3(), has=[];
    if(k.sc_fen) has.push('a Marsh Candle in the fen'); if(k.sc_hollow) has.push('the Keeper\'s notebook'); if(k.sc_cold) has.push('the doll in the cold room'); if(k.carp) has.push('an Ash Carp for the ward-pot');
    if(has.length){ sec('Side Scenes'); line('You have seen: '+has.join(', ')+'.','jdim'); }
    if(swStorySpell()) { sec('Spells'); line('Emberlight: the Keeper\'s flame. Press Q or E, then C.','jdim'); }
  };
}
