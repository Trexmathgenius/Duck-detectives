'use strict';
/* ===== THE DUCK KINGDOM OF MALLARDIA: world generation =====
   Fixed place in every world: a long North Road runs from Puddlewick to the kingdom, 1000 waddles north.
   Local coordinates: lx = x-KX, ly = y-KY, castle centre is (0,0), +ly is south. */
const KX=96, KY=-1000, KW=96, KH=84;
const KWALL=28,KSTONE=29,KSLATE=30,KCWIN=31,KPORT=32,KHEDGE=33,KCARPET=34,KFLAG=35,KBRIDGE=36,KFLOOR=37,KFOUNT=38,KCHEST=39,KGRAVE=40,KTENT=41,KRUIN=42,KCHAR=43,
  KPOST=44,KMILL=45,KSTONES=46,KCROP=47,KROOF=48,KHWALL=49,KHWIN=50,KHDOOR=51,KDOCK=52,KBOAT=53,KCRYSTAL=54,KSCARE=55,KTORCH=56,KMSTALL=57,KDUMMY=58,KRACK=59,KASH=60,KSAND=61,KBRDG2=62;
const KSOLID=[KWALL,KSTONE,KSLATE,KCWIN,KPORT,KHEDGE,KFLAG,KFOUNT,KCHEST,KGRAVE,KTENT,KRUIN,KCHAR,KPOST,KMILL,KSTONES,KROOF,KHWALL,KHWIN,KHDOOR,KBOAT,KCRYSTAL,KSCARE,KTORCH,KMSTALL,KDUMMY,KRACK];
KSOLID.forEach(c=>SOLID.add(c));
const KTALL=new Set([KFLAG,KCHAR,KMILL,KSTONES,KCRYSTAL,KTORCH,KPOST,KMSTALL,KTENT,KSCARE]);
const KINTER=[KPORT,KCHEST,KGRAVE,KTENT,KRUIN,KCHAR,KPOST,KMILL,KSTONES,KHDOOR,KBOAT,KCRYSTAL,KSCARE,KMSTALL,KDUMMY,KRACK,KFLAG,KHEDGE,KHWALL,KHWIN,KFOUNT,KWALL,KSTONE,KCWIN,KTORCH];
KINTER.forEach(c=>INTERACTIVE.add(c));
const KCOL={28:'#9aa1ad',29:'#8a919e',30:'#46608f',31:'#d9a85a',32:'#4a3a2a',33:'#2d6a35',34:'#a8232f',35:'#c0392b',36:'#a8793f',37:'#c9c2b0',38:'#58aee6',39:'#e0b84a',40:'#8d939c',41:'#b5352b',42:'#7d838c',43:'#2a2420',44:'#a8793f',45:'#e8d9b5',46:'#7b8ba8',47:'#d9b84a',48:'#c0584a',49:'#e8d9b5',50:'#8ecae6',51:'#5c3d7a',52:'#a8793f',53:'#8a5a2b',54:'#6fd0ff',55:'#c9a24a',56:'#ff9d2e',57:'#d9482b',58:'#c9a06a',59:'#8a6238',60:'#3a3330',61:'#d8c58a'};
for(const k in KCOL) MAPCOL[k]=KCOL[k];

function inK(x,y){ return Math.abs(x-KX)<=KW&&Math.abs(y-KY)<=KH; }
function inCityL(lx,ly){ return Math.abs(lx)<=58&&Math.abs(ly)<=42; }
function inCity(x,y){ return inCityL(x-KX,y-KY); }
/* the North Road wanders between Puddlewick and the kingdom, but runs dead straight at both ends */
function roadX(y){
  const a=Math.max(0,Math.min(1,(y-(KY+KH+8))/60)), b=Math.max(0,Math.min(1,(-14-y)/50));
  return KX+Math.round(7*Math.sin(y*0.021)*a*b+3*Math.sin(y*0.057+1)*a*b);
}
function kingdomBlocksTown(rx,ry){
  const cx=rx*REG, cy=ry*REG;
  if(Math.abs(cx-KX)<KW+40&&Math.abs(cy-KY)<KH+40) return true;
  if(rx===2&&ry<0&&ry>-24) return true;      /* keep the North Road clear */
  return false;
}
function resetKingdom(){ kMaze=null; kBuildCache.clear(); kNpcs=null; }

/* ---- hedge maze in the Royal Gardens ---- */
let kMaze=null;
function kMazeGrid(){
  if(kMaze) return kMaze;
  const C=10,R=6,W=2*C+1,H=2*R+1, grid=[]; for(let j=0;j<H;j++) grid.push(new Array(W).fill(1));
  let s=20251015; const rnd=()=>{ s=(Math.imul(s,1103515245)+12345)&0x7fffffff; return s/0x7fffffff; };
  const seen=new Set(), st=[[0,R-1]]; seen.add((R-1)*C); grid[2*(R-1)+1][1]=0;
  while(st.length){
    const [cx,cy]=st[st.length-1], dirs=[[1,0],[-1,0],[0,1],[0,-1]].filter(d=>{ const nx=cx+d[0], ny=cy+d[1]; return nx>=0&&nx<C&&ny>=0&&ny<R&&!seen.has(ny*C+nx); });
    if(!dirs.length){ st.pop(); continue; }
    const d=dirs[Math.floor(rnd()*dirs.length)], nx=cx+d[0], ny=cy+d[1];
    seen.add(ny*C+nx); grid[2*ny+1][2*nx+1]=0; grid[cy*2+1+d[1]][cx*2+1+d[0]]=0; st.push([nx,ny]);
  }
  grid[H-1][1]=0;    /* entrance on the south side */
  kMaze=grid; return grid;
}
const MAZE_X=-10, MAZE_Y=-38, CHEST_L=[[0,-32],[-80,-30],[80,-25],[63,-66],[-73,34],[0,-66]];   /* (lx,ly) of chests; the first sits in the maze heart */
function mazeChestL(){ return [-10+11,-38+5]; }

/* ---- building rectangles ---- */
const kBuildCache=new Map();
const HOUSE_ROOFS=['#b5483a','#3a7ca5','#7a5195','#4c8c4a','#c9822b','#2f8f8a','#8e5a3a'];
const HOUSE_WALLS=['#e8d9b5','#d9e2c9','#d6d0e8','#f0cfc0','#cfe2e8'];
const KSPECIAL=[
  {x:-52,y:-30,w:18,h:7,type:'temple',name:'Temple of Feathers',roof:'#d4a73a',wall:'#f4efe0'},
  {x:34,y:-30,w:18,h:7,type:'library',name:'Royal Library',roof:'#2f6f7a',wall:'#d9e2c9'},
  {x:30,y:26,w:14,h:5,type:'barracks',name:'Barracks',roof:'#5a6270',wall:'#c9c2b0'},
  {x:-4,y:-8,w:0,h:0,type:'none'},
  {x:68,y:34,w:10,h:5,type:'barn',name:'Eider Farm Barn',roof:'#a8432b',wall:'#c9503a'},
  {x:68,y:-66,w:6,h:4,type:'cottage',name:'Hermit Cottage',roof:'#4c8c4a',wall:'#e8d9b5'},
  {x:-66,y:-6,w:0,h:0,type:'none'}
];
function kBuilding(lx,ly){
  for(const b of KSPECIAL) if(b.w&&lx>=b.x&&lx<b.x+b.w&&ly>=b.y&&ly<b.y+b.h) return b;
  /* townhouse grid inside the walls: 4 columns either side, 4 rows */
  if(ly>=-6&&ly<=21){
    const ay=Math.abs(lx);
    if(ay>=24&&ay<=55){
      const ox=lx<0?-54:24, c=Math.floor((lx-ox)/8), r=Math.floor((ly+6)/8);
      if(c>=0&&c<4&&r>=0&&r<4){
        const bx=ox+c*8, by=-6+r*8;
        if(lx<bx+6&&ly<by+4){
          const k=bx+','+by; let b=kBuildCache.get(k);
          if(!b){ b={x:bx,y:by,w:6,h:4,type:'house',name:'',roof:HOUSE_ROOFS[Math.floor(hash(bx,by,5100)*HOUSE_ROOFS.length)],wall:HOUSE_WALLS[Math.floor(hash(bx,by,5101)*HOUSE_WALLS.length)]}; kBuildCache.set(k,b); }
          return b;
        }
      }
    }
  }
  return null;
}
function kBuildTile(b,lx,ly){
  const col=lx-b.x, row=ly-b.y, roofRows=b.h-2;
  if(row<roofRows) return KROOF;
  const door=Math.floor(b.w/2);
  if(row===b.h-1&&col===door) return KHDOOR;
  if(row===b.h-2&&(b.w<=6?(col===1||col===4):(col%4===1&&col!==door))) return KHWIN;
  return KHWALL;
}

/* ---- the castle (inaccessible for now) ---- */
function castleCode(lx,ly){
  if(lx<-15||lx>15||ly<-12||ly>8) return 0;
  const ax=Math.abs(lx);
  if(ax>=11&&(ly<=-8||ly>=4)){ const tp=ly<=-8?ly+12:ly-4; if(tp<=1) return KSLATE; return (tp===3&&ax===13)?KCWIN:KSTONE; }
  if(ly>=6){ if(ax<=1) return KPORT; if(ly===6) return KWALL; return (ly===7&&(ax===5||ax===8))?KCWIN:KSTONE; }
  if(ly===5) return KSLATE;
  if(ax<=7){
    if(ly<=-10) return KSLATE;
    if(ly===-9) return KWALL;
    return ((ly===-6||ly===-1)&&(ax===2||ax===5))||(ly===3&&ax===4)?KCWIN:KSTONE;
  }
  if(ly<=-4) return KSLATE;
  if(ly===-3) return KWALL;
  return (ly===0&&(ax===9||ax===13))?KCWIN:KSTONE;
}

/* ---- zones ---- */
function kZone(lx,ly){
  if(Math.abs(lx)<=15&&ly>=-12&&ly<=8) return 'Castle Quackenhold';
  if(inCityL(lx,ly)){
    if(ly>=-40&&ly<=-14&&Math.abs(lx)<=24) return 'Royal Gardens';
    if(ly>=9&&ly<=24&&Math.abs(lx)<=22) return 'Castle Plaza';
    if(ly>=26&&ly<=38&&lx>=-44&&lx<=-6) return 'Market Row';
    if(ly>=26&&ly<=38&&lx>=8&&lx<=46) return 'Training Yard';
    if(lx>=28&&lx<=32&&ly>=-30&&ly<=-23) return "Warlock's Tower";
    return 'Kingsbill';
  }
  if(Math.abs(lx)<=62&&Math.abs(ly)<=46) return 'The Moat';
  if(lx>=-92&&lx<=-62&&ly>=4&&ly<=46) return "Gordamom's Siege Field";
  if(lx>=-92&&lx<=-40&&ly>=-82&&ly<=-47) return 'The Burnt Wood';
  if(lx>=62&&lx<=92&&ly>=-46&&ly<=-8) return 'Swan Lake';
  if(lx>=-24&&lx<=24&&ly>=-82&&ly<=-50) return "Warlock's Stones";
  if(lx>=50&&lx<=92&&ly>=-82&&ly<=-50) return "Hermit's Hollow";
  if(lx>=62&&ly>=8) return 'Eider Farms';
  if(lx>=-92&&lx<=-64&&ly>=-46&&ly<=-8) return 'Old Watchtower Hills';
  if(lx>=-52&&lx<=-12&&ly>=48) return 'Pear Orchard';
  if(ly>=48) return 'The Royal Road';
  return 'Mallardia';
}
function kingdomArea(tx,ty){
  if(!inK(tx,ty)){
    if(tx>=KX-30&&tx<=KX+30&&ty<-12&&ty>KY+KH){
      const y=ty, rx=roadX(y);
      if(Math.abs(tx-rx)<=14){
        if(Math.abs(y+250)<=8) return "Mallard's Rest";
        if(Math.abs(y+560)<=8) return 'Cattail Crossing';
        if(Math.abs(y+790)<=8) return "Pilgrim's Rest";
        return 'The North Road';
      }
    }
    return null;
  }
  return kZone(tx-KX,ty-KY);
}
/* tiles that count as paved when props stand on them (benches, lamps...) */
function kingdomPaved(x,y){
  const lx=x-KX, ly=y-KY;
  if(inK(x,y)){
    if(inCityL(lx,ly)){
      if(ly>=-40&&ly<=-14&&Math.abs(lx)<=24) return false;
      return true;
    }
    return false;
  }
  return false;
}
function inKingdomTile(x,y){ return inK(x,y); }

/* ---- the world itself ---- */
function kForest(x,y,lx,ly,p){
  if(hash(x,y,5200)<p) return hash(x,y,5201)<0.12?T.STUMP:T.TREE;
  const q=hash(x,y,5202);
  if(q<0.008) return T.ROCK;
  if(q<0.05) return T.FLOWER;
  if(q<0.07) return T.BUSH;
  if(q<0.075&&!taken.has(x+','+y)) return T.CRUMBS;
  return T.GRASS;
}
function roadFeatures(x,y){
  const rx=roadX(y), dx=x-rx;
  /* roadside signposts every ~150 steps, a rest stop, a river, a well */
  if(y%150===0&&dx===2) return KPOST;
  const R1=-250, R3=-790;
  if(Math.abs(y-R1)<=4&&dx>=3&&dx<=12){
    const fx=dx-3, fy=y-R1;
    if(fx===2&&fy===0) return T.BENCH;
    if(fx===5&&fy===-1) return T.FIRE;
    if(fx===8&&fy===2) return T.LAMP;
    if(fx===0&&fy===-3) return KPOST;
    if(fx===7&&fy===1) return T.BENCH;
    return hash(x,y,5300)<0.08?T.FLOWER:T.GRASS;
  }
  if(Math.abs(y-R3)<=4&&dx<=-3&&dx>=-12){
    const fx=-dx-3, fy=y-R3;
    if(fx===3&&fy===0) return T.WELL;
    if(fx===6&&fy===-1) return T.FIRE;
    if(fx===1&&fy===2) return T.BENCH;
    if(fx===8&&fy===1) return T.LAMP;
    if(fx===5&&fy===3) return KMSTALL;
    return hash(x,y,5301)<0.08?T.FLOWER:T.GRASS;
  }
  /* the river */
  const ry0=-562, wv=Math.round(1.6*Math.sin(x*0.09));
  if(Math.abs(dx)<=70&&y>=ry0-2+wv&&y<=ry0+2+wv){
    if(Math.abs(dx)<=1) return KBRIDGE;
    if(Math.abs(dx)===2&&y===ry0-2+wv) return T.LAMP;
    return T.WATER;
  }
  if(Math.abs(dx)<=1) return T.PATH;
  if(Math.abs(dx)<=2) return hash(x,y,5302)<0.18?T.FLOWER:T.GRASS;
  return null;
}
function kingdomTile(x,y){
  /* the first stretch of road runs through the north edge of Puddlewick */
  if(x>=95&&x<=97&&y>=-12&&y<=-6) return T.PATH;
  if(x===99&&y===-12) return KPOST;
  if(!inK(x,y)){
    if(y<-12&&y>KY+KH&&Math.abs(x-KX)<=90) return roadFeatures(x,y);
    return null;
  }
  const lx=x-KX, ly=y-KY, ax=Math.abs(lx), ay=Math.abs(ly);
  /* 1. the castle */
  const cc=castleCode(lx,ly); if(cc) return cc;
  /* 2. walls, towers, gates, moat */
  if(ay<=46&&ax<=62){
    const inWall=ax<=58&&ay<=42;
    if(!inWall){
      /* moat ring, bridges at the three gates */
      if(ly>=43&&ax<=3) return KBRIDGE;
      if(ax>=59&&ay<=3) return KBRIDGE;
      return T.WATER;
    }
    /* corner towers and gate towers (5 wide) */
    const cornerT=(ax>=54&&ay>=38);
    const sgateT=(ly>=38&&ax>=4&&ax<=8);
    const egateT=(ax>=54&&ay>=4&&ay<=8);
    if(cornerT||sgateT||egateT){
      const isTop=cornerT?(ly<0?ay>=41:ay<=39):sgateT?(ly<=39):(ly<0?ay>=7:ay<=5);
      if(isTop) return KSLATE;
      const mid=cornerT?(ly<0?ay===40:ay===40):sgateT?ly===41:ay===6;
      return mid&&((ax%2===0))?KCWIN:KSTONE;
    }
    if(ax>=57||ay>=41){
      if(ly>=41&&ax<=3) return T.COBBLE;
      if(ax>=57&&ay<=3) return T.COBBLE;
      return KWALL;
    }
  }
  /* 3. inside the walls */
  if(inCityL(lx,ly)){
    const b=kBuilding(lx,ly); if(b) return kBuildTile(b,lx,ly);
    /* royal fountains, statues, flags, lamps on the castle plaza */
    if(ly>=9&&ly<=24&&ax<=22){
      if(ax<=1) return KCARPET;
      if((ax===9||ax===10||ax===8)&&ly>=15&&ly<=17&&ax<=10&&ax>=8){ return KFOUNT; }
      if(ax===3&&(ly%4===1)&&ly>=11&&ly<=23) return KFLAG;
      if(ax===14&&ly===12) return T.STATUE;
      if(ax===20&&(ly===12||ly===21)) return T.LAMP;
      if(ax===16&&ly===22) return T.BENCH;
      if(ax===4&&ly===9) return KTORCH;
      return KFLOOR;
    }
    /* main avenue */
    if(ly>=25&&ly<=41&&ax<=3){ if(ax===3&&ly%6===0) return T.LAMP; return T.COBBLE; }
    /* east and west gate streets */
    if(ay<=3&&(ax>=24||true)&&ax>=16) return T.COBBLE;
    /* cross streets to keep the house blocks apart */
    if(ly>=-8&&ly<=24&&ax>=16&&ax<=23) return (ax===16&&ly%7===0)?T.LAMP:T.COBBLE;
    if(ly>=-7&&ly<=23&&(ly+6)%8>=4&&ax>=24) return T.COBBLE;
    /* gardens */
    if(ly>=-40&&ly<=-14&&ax<=24){
      /* hedge maze */
      if(lx>=MAZE_X&&lx<=MAZE_X+20&&ly>=MAZE_Y&&ly<=MAZE_Y+12){
        const mx=lx-MAZE_X, my=ly-MAZE_Y, cl=mazeChestL();
        if(mx===cl[0]-MAZE_X-0&&my===cl[1]-MAZE_Y) return KCHEST;
        return kMazeGrid()[my][mx]?KHEDGE:T.COBBLE;
      }
      if(ly===-13||ly===-14){ return ax<=2?T.COBBLE:KHEDGE; }
      if(lx===0&&ly>=-25&&ly<=-15) return T.COBBLE;
      if(ly===-24&&ax<=12) return T.COBBLE;
      if(ax===12&&ly>=-39&&ly<=-24&&false) return KHEDGE;
      if(ax===18&&ly>=-36&&ly<=-17) return KHEDGE;
      if(ly===-39&&ax<=24) return KHEDGE;
      if((ax===16||ax===22)&&(ly===-20||ly===-30)) return T.STATUE;
      if((ax===14||ax===20)&&ly===-18) return T.BENCH;
      if(ax===6&&ly===-20) return T.LAMP;
      if(ax===0&&ly===-20) return T.WELL;
      return hash(x,y,5410)<0.35?T.FLOWER:T.GRASS;
    }
    /* market row, training yard */
    if(ly>=26&&ly<=38){
      if(lx>=-44&&lx<=-6){
        if((ly===28||ly===34)&&(lx+44)%6===2&&lx<=-8) return KMSTALL;
        if(lx===-25&&ly===31) return T.WELL;
        if(lx%12===0&&ly===26) return T.LAMP;
        return T.COBBLE;
      }
      if(lx>=8&&lx<=46){
        if(lx===8||lx===28||lx===46) return (ly===32)?T.COBBLE:KHEDGE;
        if(ly===26||ly===38){ if(lx>=8&&lx<=28&&!(lx===18)) return KHEDGE; }
        if(lx>=8&&lx<=28){
          if((lx===12||lx===16||lx===20||lx===24)&&ly===30) return KDUMMY;
          if((lx===11||lx===25)&&ly===35) return KRACK;
          if(lx===18&&ly===33) return T.FIRE;
          return KSAND;
        }
      }
    }
    /* the warlock's tower */
    if(lx>=28&&lx<=32&&ly>=-30&&ly<=-23){
      if(ly<=-29) return KSLATE;
      if(lx===30&&(ly===-27||ly===-25)) return KCWIN;
      return KSTONE;
    }
    if(lx===26&&ly===-26) return KCRYSTAL;
    /* tree-lined streets, lawns */
    if(ly>=-29&&ly<=-7&&ax>=26){ if(hash(x,y,5420)<0.1) return T.TREE; return hash(x,y,5421)<0.12?T.FLOWER:T.GRASS; }
    if(ay>=39&&ax>=10&&ax<=56){ if(hash(x,y,5430)<0.08) return T.TREE; return T.GRASS; }
    if(ly>=-41&&ly<=-40) return T.GRASS;
    return (hash(x,y,5440)<0.04)?T.FLOWER:T.COBBLE;
  }
  /* 4. outside the walls */
  const zone=kZone(lx,ly);
  /* roads: the Royal Road to the south gate, side tracks east and west */
  if(ly>46&&ax<=1) return T.PATH;
  if(ly>46&&ax===2) return hash(x,y,5450)<0.2?T.FLOWER:T.GRASS;
  if(ay<=1&&ax>62&&ax<=92&&zone!=='Swan Lake') return T.PATH;
  /* the siege field */
  if(zone==="Gordamom's Siege Field"){
    if(lx===-73&&ly===34) return KCHEST;
    if(lx>=-77&&lx<=-65&&ly>=27&&ly<=41){          /* graves */
      if((lx%2===0)&&(ly%3===1)) return KGRAVE;
      return KASH;
    }
    if(lx===-70&&ly===25) return KFLAG;
    const r=hash(x,y,5460);
    if(r<0.03) return KTENT;
    if(r<0.06) return KRUIN;
    if(r<0.07) return KCHAR;
    if(r<0.10) return T.ROCK;
    return vnoise(x*0.16,y*0.16,5901)>0.47?KASH:T.GRASS;
  }
  /* the burnt wood: Gordamom's grove */
  if(zone==='The Burnt Wood'){
    const dx=lx+66, dy=ly+64, d=Math.hypot(dx,dy);
    if(dx===0&&dy===0) return KCHAR;
    if(d<=3.2) return KASH;
    if(d<=11){
      if(d>=6.5&&d<=9.5&&hash(x,y,5470)<0.34) return KCHAR;
      return vnoise(x*0.2,y*0.2,5902)>0.32?KASH:T.GRASS;
    }
    if(hash(x,y,5472)<0.1) return KCHAR;
    return kForest(x,y,lx,ly,0.42);
  }
  /* swan lake */
  if(zone==='Swan Lake'){
    const dx=(lx-78)/15, dy=(ly+27)/11, dd=dx*dx+dy*dy;
    if(Math.hypot(lx-80,ly+25)<=2.6) return (lx===80&&ly===-25)?KCHEST:(hash(x,y,5480)<0.3?T.FLOWER:T.GRASS);
    if(lx>=62&&lx<=69&&ly===-25) return KDOCK;
    if(lx===70&&ly===-26) return KBOAT;
    if(dd<=1) return T.WATER;
    return kForest(x,y,lx,ly,0.2);
  }
  /* warlock's stones */
  if(zone==="Warlock's Stones"){
    const d=Math.hypot(lx,ly+66);
    if(lx===0&&ly===-66) return KCRYSTAL;
    if(Math.abs(d-7)<0.6){ const a=Math.atan2(ly+66,lx); if(Math.abs(((a/(Math.PI/4))%1+1)%1)<0.2||Math.abs(((a/(Math.PI/4))%1+1)%1)>0.8){ return KSTONES; } }
    if(d<7.5) return hash(x,y,5490)<0.25?T.FLOWER:T.GRASS;
    return kForest(x,y,lx,ly,0.13);
  }
  /* the hermit's hollow */
  if(zone==="Hermit's Hollow"){
    const b=kBuilding(lx,ly); if(b) return kBuildTile(b,lx,ly);
    if(lx>=65&&lx<=76&&ly>=-61&&ly<=-57) return hash(x,y,5500)<0.7?T.FLOWER:T.GRASS;
    if(lx===71&&ly===-56) return T.PATH;
    if(lx===63&&ly===-66) return KCHEST;
    if(lx===66&&ly===-62) return T.BENCH;
    return kForest(x,y,lx,ly,0.3);
  }
  /* farms */
  if(zone==='Eider Farms'){
    const b=kBuilding(lx,ly); if(b) return kBuildTile(b,lx,ly);
    if(lx>=83&&lx<=85&&ly>=34&&ly<=36) return KMILL;
    if(lx===76&&ly===24) return KSCARE;
    if(lx>=66&&lx<=90&&((ly>=14&&ly<=30)||(ly>=44&&ly<=64))){
      if(lx===78&&ly>=14&&ly<=30) return T.PATH;
      return KCROP;
    }
    return kForest(x,y,lx,ly,0.06);
  }
  /* old watchtower in the west hills */
  if(zone==='Old Watchtower Hills'){
    if(lx>=-82&&lx<=-78&&ly>=-32&&ly<=-28){
      if(lx===-80&&ly===-30) return KCHEST;
      const edge=(lx===-82||lx===-78||ly===-32||ly===-28);
      if(edge) return (ly===-28&&lx===-80)?T.GRASS:(hash(x,y,5510)<0.6?KRUIN:T.GRASS);
      return T.GRASS;
    }
    if(hash(x,y,5511)<0.03) return KRUIN;
    return kForest(x,y,lx,ly,0.15);
  }
  /* pear orchard */
  if(zone==='Pear Orchard'){
    if(ax<=2) return T.PATH;
    if((lx%4===0)&&(ly%4===0)&&hash(x,y,5520)<0.9) return T.TREE;
    if(lx===-30&&ly===60) return T.BENCH;
    if(hash(x,y,5521)<0.025) return T.CRUMBS;
    return hash(x,y,5522)<0.05?T.FLOWER:T.GRASS;
  }
  /* the open country, dense forest on the rim */
  const rim=Math.min(KW-ax,KH-ay);
  const p=rim<10?0.4-rim*0.015:0.07+0.05*Math.sin(lx*0.2)*Math.sin(ly*0.2);
  return kForest(x,y,lx,ly,Math.max(0.05,p));
}
