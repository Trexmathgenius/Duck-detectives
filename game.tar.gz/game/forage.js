'use strict';
/* ===== FORAGING, TRAIL ITEMS, DIGGING, TREASURE MAPS, DAILY CASES, SELLING FINDS, TOWNDUCK REQUESTS ===== */
const WL_NIGHT=()=>g.clock>=20||g.clock<5.5;
const wlTile=()=>({x:Math.floor(g.px/TS),y:Math.floor((g.py-2)/TS)});
const wlFront=()=>{ const v=DIRV[g.dir]; return {x:Math.floor((g.px+v.x*14)/TS),y:Math.floor((g.py-6+v.y*14)/TS)}; };
const WL_DIR8=['east','south-east','south','south-west','west','north-west','north','north-east'];
function wlDir(dx,dy){ const a=Math.atan2(dy,dx); return WL_DIR8[((Math.round(a/(Math.PI/4))%8)+8)%8]; }
function wlArrow(dx,dy){ const a=Math.atan2(dy,dx); return ARROWS[((Math.round(a/(Math.PI/4))%8)+8)%8]; }
const wlCap=s=>s.charAt(0).toUpperCase()+s.slice(1);
function wlPlace(id,n,quiet){
  const w=WD(); n=n||1;
  addItem(id,n);
  const first=!w.got[id];
  w.got[id]=(w.got[id]||0)+n;
  if(first&&!quiet&&g.inv.clog) toast('New for your Collection Log: '+ITEMS[id].name,2800);
  return first;
}
function wlPickW(ids,weights){
  let tot=0; for(let i=0;i<ids.length;i++) tot+=weights[Math.min(i,weights.length-1)];
  let a=rnd()*tot;
  for(let i=0;i<ids.length;i++){ a-=weights[Math.min(i,weights.length-1)]; if(a<=0) return ids[i]; }
  return ids[ids.length-1];
}
function wlFitsTime(id){ const it=ITEMS[id]; if(it.night&&!WL_NIGHT()) return false; if(it.day&&WL_NIGHT()) return false; return true; }
function wlRareFind(b){
  for(let tries=0;tries<6;tries++){
    const useB=b&&b.finds&&rnd()<0.8;
    const id=useB?wlPickW(b.finds,[4,2.6,1.6,1]):wlPickW(WL_ANY,[4,3,3,2,2,0.5]);
    if(wlFitsTime(id)) return id;
  }
  return WL_ANY[0];
}

/* ---------------- foraging ---------------- */
const WL_GENERIC={tree:'Tree',flower:'Wildflower',bush:'Bush',mush:'Mushroom',rock:'Rock',stump:'Stump'};
const WL_FLAV={
 tree:['Bark, leaves, and a beetle with strong opinions.','You find a few fallen bits at the roots. One is a crumb.','Something rustles overhead. It is only wind. Probably.','You scratch at the bark and a crumb tumbles out of a crevice.'],
 flower:['You sniff it. Sneeze. Find a crumb tangled in the petals.','Pollen on your bill. A crumb under the leaves.','It leans toward you like it wants to be noticed.','The stem has a crumb caught in it. Lucky.'],
 bush:['You push through the leaves and find a crumb in the twigs.','A rustle, a squeak, a crumb.','Something small has been hoarding here. You borrow a crumb.','Leaves, thorns, and one lonely crumb.'],
 mush:['It smells earthy. A crumb lies at its base, mushroom-damp.','You do not eat it. Ducks are not that brave. But you find a crumb.','Cool, damp, and strangely friendly.','A little beetle shares a crumb with you. Politely.'],
 rock:['You flip it over with your bill. Pale grubs, one crumb.','A crumb is wedged in a crack in the rock.','Cold, solid, quietly proud of itself.','Under the rock: bugs, a feather, and a crumb.'],
 stump:['Rings and moss, and a crumb tucked in the grain.','You count the rings and lose track. You find a crumb.','A woodpecker left a crumb behind. Probably by accident.','Home to a beetle. He lets you have a crumb.']
};
function wlRarity(sp){ return sp.tier; }
function wlGenericName(t){ return WL_GENERIC[WL_TILECAT[t]]||'Thing'; }
const WL_NEED={tree:'axe',stump:'axe',rock:'pickaxe'};
const WL_NEEDTXT={axe:['an axe','cut it down'],pickaxe:['a pickaxe','break it up']};
function wlGoneMark(x,y){ const w=WD(); w.gone[x+','+y]=1; tileCache.delete(tkey(x,y)); }
function wlForage(tg){
  const tx=tg.tx, ty=tg.ty, t=tg.t, cat=WL_TILECAT[t], sp=wlSpeciesAt(tx,ty,t), b=wlBiomeAt(tx,ty), w=WD();
  const name=sp?sp.name+' ('+WL_PTIER[sp.tier]+')':wlGenericName(t);
  const need=WL_NEED[cat];
  if(need&&!isHeld(need)&&!window.WL_MAGIC){
    const nt=WL_NEEDTXT[need];
    toast(g.inv[need]?holdText(need):(sp?sp.name:wlGenericName(t))+'  -  you need '+nt[0]+' to '+nt[1]+'. Supply shops and markets sell them.',3200); tone('square',300,260,0.08,0.04);
    return;
  }
  /* collecting a plant uses it up: it is gone from the world for good */
  wlGoneMark(tx,ty);
  if(need){ tone('sawtooth',140,70,0.2,0.08); }
  w.stats.forage=(w.stats.forage||0)+1;
  let firstSeen=false;
  if(sp){ firstSeen=!w.seen[sp.id]; w.seen[sp.id]=(w.seen[sp.id]||0)+1; }
  const crumb=rnd()<wlCrumbP(); if(crumb){ g.crumbs+=1; coin(); }
  let p=0.01*wlItemMul(); if(luckBonus()) p*=1.6;
  let rare=null;
  if(rnd()<p) rare=wlRareFind(b);
  const pages=[];
  let verb=cat==='tree'?'You chop down the '+(sp?sp.name:'tree')+'.':cat==='stump'?'You chop up the '+(sp?sp.name:'stump')+'.':cat==='rock'?'You break up the '+(sp?sp.name:'rock')+'.':'You gather the '+(sp?sp.name:wlGenericName(t))+'.';
  if(window.WL_VERB) verb=window.WL_VERB(cat,sp);
  if(firstSeen) pages.push((sp.tier>=4?(sp.tier===6?'CHROMATIC! ':sp.tier===5?'MYTHIC! ':'LEGENDARY! '):'')+'New species: '+name+'!',(sp&&wlFlavor(sp))||'');
  if(rare){
    const first=wlPlace(rare,1,true);
    pages.push((cat==='rock'?'Something glints in the rubble':cat==='stump'?'There was something in the hollow':cat==='tree'?'Something falls out of the branches':'Something glints among the leaves')+': a '+ITEMS[rare].name+'!',
      ITEMS[rare].desc+(first&&g.inv.clog?'  (New in your Collection Log!)':''));
    w.stats.rare=(w.stats.rare||0)+1;
  }
  if(crumb) pages.push('+1 crumb.');
  const dropTxt=typeof brewDrop==='function'?brewDrop(sp,cat,b&&b.id):'';
  if(pages.length){ if(dropTxt) pages.push(dropTxt); const all=[verb].concat(pages.filter(Boolean)); if(window.WL_QUIET) toast(all.filter(p=>!/^It grows in/.test(p)).join('  '),5200); else say('',all); }
  else toast(verb+(sp?'  Added to your log.':'')+'  '+(dropTxt||'Nothing else this time.'),dropTxt?3200:2000);
}
function wlNewSpecies(sp,quiet){
  if(quiet) return;
  toast('New species: '+sp.name,2200);
}
function wlFlavor(sp){
  const L=WL_FLAV[sp.cat], b=WL_BY[sp.biome];
  return 'It grows in the '+b.name+'. '+L[(sp.name.length*3+sp.rank)%L.length]+(g.inv.clog?'':' (A Collection Log, sold in bookshops, would remember it for you.)');
}

/* ---------------- trail items and dig spots, marks on the ground ---------------- */
function wlTrailSpot(x,y){
  if(hash(x,y,g.day*37+501)>=0.017) return false;
  if(townAtTile(x,y)) return false;
  const w=g.story&&g.story.wd; if(w&&w.picked&&w.picked['t'+x+','+y]===g.day&&w.day===g.day) return false;
  return true;
}
function wlDigSpot(x,y){
  if(hash(x,y,g.day*17+800)>=0.0011) return false;
  if(tileAt(x,y)!==T.GRASS) return false;
  if(!wlBiomeAt(x,y)||nearTown(x,y,3)) return false;
  const w=g.story&&g.story.wd; if(w&&w.dug&&w.dug[x+','+y]===g.day&&w.day===g.day) return false;
  return true;
}
function wlSpark(c,px,py,col){
  const s=(Math.sin(g.time*4+px*0.07+py*0.05)+1)/2;
  c.fillStyle=col||'rgba(255,247,194,'+(0.45+0.55*s).toFixed(2)+')';
  c.fillRect(px+21,py+8-s*2,2,2); c.fillRect(px+22,py+5-s*2,0.8,8);
}
function wlGroundMarks(c,x,y,px,py){
  const w=g.story&&g.story.wd;
  if(w&&w.day===g.day&&w.dug&&w.dug[x+','+y]===g.day){
    ell(c,px+16,py+19,9,4.5,'#6b4a2f'); ell(c,px+16,py+17.5,7,3,'#8a6238'); rect(c,px+11,py+16,2,1,'#a97c50'); rect(c,px+17,py+18,3,1,'#5a3d22');
    return;
  }
  if(hash(x,y,g.day*17+800)<0.0011&&wlDigSpot(x,y)){
    ell(c,px+16,py+20,8,4,'rgba(60,40,20,0.55)'); wlLine(c,px+9,py+17,px+14,py+21,1.2,'#5a3d22'); wlLine(c,px+22,py+18,px+17,py+22,1.2,'#5a3d22'); wlLine(c,px+16,py+15,px+16,py+22,1.2,'#5a3d22');
    wlSpark(c,px,py);
  }
  if(w&&w.hunts&&w.hunts.length){
    for(const h of w.hunts) if(h.x===x&&h.y===y&&Math.hypot(h.x-g.px/TS,h.y-g.py/TS)<7){
      wlLine(c,px+8,py+9,px+24,py+25,2.4,'rgba(200,50,40,0.55)'); wlLine(c,px+24,py+9,px+8,py+25,2.4,'rgba(200,50,40,0.55)'); wlSpark(c,px,py,'rgba(255,215,150,0.9)');
    }
  }
  if(w){
    for(const k in w.cases){ const cs=w.cases[k]; if(cs.state===1&&cs.day===g.day&&cs.x===x&&cs.y===y&&Math.hypot(cs.x-g.px/TS,cs.y-g.py/TS)<6){ ell(c,px+16,py+22,8,3.5,'rgba(255,230,120,0.35)'); wlSpark(c,px,py,'rgba(255,240,170,0.95)'); } }
  }
}
{
  const _drawPath2=drawPath;
  drawPath=function(c,x,y,px,py){
    _drawPath2(c,x,y,px,py);
    if(hash(x,y,g.day*37+501)<0.017&&wlTrailSpot(x,y)){
      ell(c,px+16,py+20,6,3,'rgba(0,0,0,0.2)'); circ(c,px+15,py+17,4,'#a8793f'); circ(c,px+15,py+16,2.6,'#c79a5a'); rect(c,px+14,py+12,3,1,'#e8d3a0');
      wlSpark(c,px,py);
    }
  };
}
/* the Z bubble appears over trail items and dig spots */
{
  const _findTarget2=findTarget;
  findTarget=function(){
    _findTarget2();
    if(g.target||g.mode!=='play'||g.scene!=='world') return;
    const f=wlFront(), o=wlTile();
    for(const p of [f,o]){
      const t=tileAt(p.x,p.y);
      if(t===T.PATH&&wlTrailSpot(p.x,p.y)){ g.target={k:'wild',kind:'trail',tx:p.x,ty:p.y,x:(p.x+0.5)*TS,y:p.y*TS-2}; return; }
      if(t===T.GRASS&&wlDigSpot(p.x,p.y)){ g.target={k:'wild',kind:'dig',tx:p.x,ty:p.y,x:(p.x+0.5)*TS,y:p.y*TS+2}; return; }
    }
  };
  const _interact4=interact;
  interact=function(){
    const tg=g.target;
    if(tg&&g.scene==='world'){
      if(tg.k==='tile'&&WL_TILECAT[tg.t]&&wlProtected(tg.tx,tg.ty)!==2&&!townAtTile(tg.tx,tg.ty)){ quack(); wlForage(tg); return; }
      if(tg.k==='wild'){ quack(); if(tg.kind==='trail') wlTrailPick(tg.tx,tg.ty); else wlDigAt(tg.tx,tg.ty,true); return; }
    }
    _interact4();
  };
}
function wlTrailPick(x,y){
  const w=WD(); w.picked['t'+x+','+y]=g.day; w.stats.trail=(w.stats.trail||0)+1;
  const r=hash(x,y,g.day*41+503), b=wlBiomeAt(x,y);
  if(r<0.18){ const n=2+Math.floor(hash(x,y,g.day*43+504)*5); g.crumbs+=n; coin(); say('',['A little coin purse, dropped on the trail. Inside: '+n+' crumbs.','Finders keepers, as long as you say it fast.']); return; }
  let id;
  if(r<0.92) id=WL_TRAIL[Math.floor(hash(x,y,g.day*47+505)*WL_TRAIL.length)];
  else id=wlRareFind(b);
  const first=wlPlace(id,1,true); coin();
  say('',['Something glints beside the trail: a '+ITEMS[id].name+'!',ITEMS[id].desc+(first&&g.inv.clog?'  (New in your Collection Log!)':'')]);
}

/* ---------------- digging ---------------- */
function wlDig(){
  if(g.scene!=='world'||g.mode!=='play') return;
  if(!isHeld('shovel')){ toast(g.inv.shovel?holdText('shovel'):'You need a shovel to dig. Supply shops and markets sell them.',3200); tone('square',300,200,0.1,0.05); return; }
  const f=wlFront(), t=tileAt(f.x,f.y);
  if(t!==T.GRASS&&!(t===T.FLOWER)){ toast('Nothing to dig here. Face a patch of open ground.',2000); return; }
  if(townAtTile(f.x,f.y)||nearTown(f.x,f.y,2)){ toast('Not in the town square, please.',1800); return; }
  quack();
  wlDigAt(f.x,f.y,false);
}
function wlDigAt(x,y,spotKnown){
  const w=WD(), key=x+','+y;
  if(!isHeld('shovel')){ toast(g.inv.shovel?holdText('shovel'):'Something is buried here. You need a shovel (supply shops and markets sell them).',3200); return; }
  if(w.dug[key]===g.day){ toast('You already dug here today.',1800); return; }
  w.dug[key]=g.day; tone('sawtooth',160,90,0.16,0.07);
  /* an open treasure map */
  const hi=w.hunts.findIndex(h=>h.x===x&&h.y===y);
  if(hi>=0){ wlTreasure(w.hunts.splice(hi,1)[0]); return; }
  /* today's case */
  for(const k in w.cases){ const cs=w.cases[k]; if(cs.state===1&&cs.day===g.day&&cs.x===x&&cs.y===y){ wlSolveCase(cs); return; } }
  /* a glinting dig spot */
  if(spotKnown||wlDigSpotWas(x,y)){ wlDigRelic(x,y); return; }
  /* warm hints when you are close */
  for(const h of w.hunts){ const d=Math.hypot(h.x-x,h.y-y); if(d<=3.5){ say('',['Thunk. The ground sounds hollow, nearby.','The treasure is very close. '+wlCap(wlDir(h.x-x,h.y-y))+' of here.']); return; } }
  for(const k in w.cases){ const cs=w.cases[k]; if(cs.state!==1||cs.day!==g.day) continue; const d=Math.hypot(cs.x-x,cs.y-y); if(d<=3.5){ say('',['Thunk. The ground sounds hollow, nearby.','You are very close. Try the soil to the '+wlDir(cs.x-x,cs.y-y)+'.']); return; } }
  if(rnd()<0.07){ g.crumbs+=1; coin(); toast('You dig up a buried crumb!  +1 crumb',1800); return; }
  toast(pick(['Just dirt.','A worm waves. Just dirt.','Nothing but roots and good soil.','You dig a neat little hole. Nothing in it.']),1600);
}
function wlDigSpotWas(x,y){ return hash(x,y,g.day*17+800)<0.0011&&tileAt(x,y)===T.GRASS&&!!wlBiomeAt(x,y)&&!nearTown(x,y,3); }
function wlDigRelic(x,y){
  const w=WD(); w.stats.dug=(w.stats.dug||0)+1;
  const r=rnd(), b=wlBiomeAt(x,y);
  if(r<0.22){ const n=4+Math.floor(rnd()*9); g.crumbs+=n; coin(); say('',['You dig down and hit a clay pot.','Crumbs! An old cache, '+n+' of them. Still crunchy.']); return; }
  const id=r<0.9?WL_DIG[Math.floor(rnd()*WL_DIG.length)]:wlRareFind(b);
  const first=wlPlace(id,1,true); coin();
  say('',['Your shovel clinks on something. You brush the dirt away.','A '+ITEMS[id].name+'!',ITEMS[id].desc+(first&&g.inv.clog?'  (New in your Collection Log!)':'')]);
}

/* ---------------- treasure maps ---------------- */
const WL_TIERS=[
  {n:'Tattered',min:35,max:80,crumbs:[18,34],items:1,rare:0.15,col:'#c9a468'},
  {n:'Weathered',min:70,max:140,crumbs:[40,70],items:2,rare:0.3,col:'#e8d3a0'},
  {n:'Gilded',min:130,max:260,crumbs:[90,150],items:3,rare:0.55,col:'#ffd166'}
];
function wlSpotOK(x,y){
  if(tileAt(x,y)!==T.GRASS) return false;
  if(wlProtected(x,y)===2) return false;
  if(nearTown(x,y,6)||darkAt(x,y)>0.05) return false;
  return !!wlBiomeAt(x,y);
}
function wlFindSpot(cx,cy,r){
  for(let rr=0;rr<=r;rr++) for(let dy=-rr;dy<=rr;dy++) for(let dx=-rr;dx<=rr;dx++){
    if(Math.max(Math.abs(dx),Math.abs(dy))!==rr) continue;
    if(wlSpotOK(cx+dx,cy+dy)) return [cx+dx,cy+dy];
  }
  return null;
}
function wlLandmark(x,y){
  for(let r=1;r<=3;r++) for(let dy=-r;dy<=r;dy++) for(let dx=-r;dx<=r;dx++){
    if(Math.max(Math.abs(dx),Math.abs(dy))!==r) continue;
    const t=tileAt(x+dx,y+dy), sp=wlSpeciesAt(x+dx,y+dy,t);
    if(sp&&(sp.cat==='tree'||sp.cat==='rock'||sp.cat==='stump'||sp.cat==='flower')) return sp;
  }
  return null;
}
function wlUnfoldMap(){
  const w=WD(), p=wlTile();
  if(!wlBiomeAt(p.x,p.y)&&wlProtected(p.x,p.y)===2){ say('',['The map curls up and refuses. It does not like this part of the world. Try somewhere wilder.']); return false; }
  const r=rnd(), tier=r<0.6?0:r<0.9?1:2, T0=WL_TIERS[tier];
  let spot=null;
  for(let i=0;i<40&&!spot;i++){
    const a=rnd()*6.2832, d=T0.min+rnd()*(T0.max-T0.min);
    spot=wlFindSpot(Math.round(p.x+Math.cos(a)*d),Math.round(p.y+Math.sin(a)*d),8);
  }
  if(!spot){ say('',['The ink swims and will not settle. Try again somewhere else.']); return false; }
  const b=wlBiomeAt(spot[0],spot[1]), lm=wlLandmark(spot[0],spot[1]);
  const h={id:Date.now()+':'+Math.floor(rnd()*1e6),x:spot[0],y:spot[1],tier:tier,day:g.day,biome:b?b.id:'forest',lm:lm?lm.name:null,ox:p.x,oy:p.y};
  w.hunts.push(h); w.stats.maps=(w.stats.maps||0)+1;
  delInv('tmap'); coin();
  const dx=h.x-p.x, dy=h.y-p.y, d=Math.round(Math.hypot(dx,dy)/5)*5;
  const lines=[T0.n+' map! A red X appears on the paper, and then on your explorer\'s map (M).',
    'The X is in the '+(b?b.name:'wild')+', about '+d+' waddles '+wlDir(dx,dy)+' of where you stand.'+(lm?' A '+lm.name+' grows beside it.':'')];
  if(!g.inv.shovel) lines.push('You will need a shovel to dig it up. Supply shops and markets sell them.');
  else lines.push('Walk there, face the ground, and press D to dig. The ground shimmers when you are close.');
  say('',lines);
  return true;
}
function wlTreasure(h){
  const w=WD(), T0=WL_TIERS[h.tier], r=rnd;
  const crumbs=T0.crumbs[0]+Math.floor(r()*(T0.crumbs[1]-T0.crumbs[0]+1));
  g.crumbs+=crumbs; coin(); w.stats.treasure=(w.stats.treasure||0)+1;
  const lines=['The shovel hits wood. A chest!','Inside: '+crumbs+' crumbs'+(T0.items?' and':'.')];
  const got=[];
  for(let i=0;i<T0.items;i++){
    const hi=h.tier===2&&i===0?WL_TREAS.slice(4):WL_TREAS.slice(0,h.tier===0?4:6);
    const id=hi[Math.floor(r()*hi.length)]; wlPlace(id,1,true); got.push(ITEMS[id].name);
  }
  if(r()<T0.rare){ const id=wlRareFind(WL_BY[h.biome]); wlPlace(id,1,true); got.push(ITEMS[id].name); }
  if(got.length) lines[1]+=' '+got.join(', ')+'.';
  lines.push('You shut the lid, very pleased with yourself.');
  say('',lines);
}

/* ---------------- daily cases ---------------- */
const WL_ADJ=['Missing','Buried','Forgotten','Whispering','Golden','Crooked','Sleepy','Mysterious','Vanishing','Grumpy'];
const WL_NOUN=['Locket','Teapot','Ledger','Acorn Hoard','Mallard Medal','Lantern','Recipe Box','Garden Gnome','Pocket Watch','Silver Spoon','Pie Tin','Music Box'];
function wlCaseFor(t){
  const w=WD(); let c=w.cases[t.key];
  if(c&&c.day===g.day) return c;
  const rn=i=>hash(t.rx*7+g.day,t.ry*13+i,8100+i);
  let spot=null, dist=0;
  for(let i=0;i<14&&!spot;i++){
    const a=(rn(1)+i*0.41)*6.2832; dist=24+rn(2+i)*44;
    spot=wlFindSpot(Math.round(t.cx+Math.cos(a)*dist),Math.round(t.cy+Math.sin(a)*dist),10);
  }
  if(!spot) return null;
  const b=wlBiomeAt(spot[0],spot[1]), lm=wlLandmark(spot[0],spot[1]);
  const dx=spot[0]-t.cx, dy=spot[1]-t.cy, d=Math.hypot(dx,dy);
  const client=t.npcs.length?t.npcs[Math.floor(rn(3)*t.npcs.length)].name:'A worried duck';
  c={day:g.day,tk:t.key,x:spot[0],y:spot[1],state:0,client:client,
     title:'The Case of the '+WL_ADJ[Math.floor(rn(4)*WL_ADJ.length)]+' '+WL_NOUN[Math.floor(rn(5)*WL_NOUN.length)],
     reward:Math.round((16+d*0.45+4*townRank(t))*payMul(t)),biome:b?b.id:'forest',lm:lm?lm.name:null,
     dist:Math.round(d/5)*5,dir:wlDir(dx,dy),jx:Math.round((rn(6)-0.5)*7),jy:Math.round((rn(7)-0.5)*7),town:t.name,c3:false};
  w.cases[t.key]=c;
  return c;
}
function wlCaseLines(c){
  const b=WL_BY[c.biome];
  const l=['Clue 1: the trail leads into the '+(b?b.name:'wild')+'.','Clue 2: from '+c.town+', head '+c.dir+', about '+c.dist+' waddles.'];
  l.push(c.c3?'Clue 3: '+(c.lm?'a '+c.lm+' grows right beside the spot.':'the spot is open ground. Follow the shimmer.'):'Clue 3: shows up when you get close.');
  return l;
}
function wlOpenCase(t){
  const c=wlCaseFor(t);
  if(!c){ say('Notice Board',['No case is posted today. Check back tomorrow.']); return; }
  if(c.state===2){ say('Notice Board',['Today\'s case, '+c.title+', is closed. '+c.client+' sends thanks. A new case is posted tomorrow.']); return; }
  const lines=[c.title+'.', c.client+' asks you to find it. It was buried somewhere out in the wild, and nobody remembers where.', 'Reward: '+c.reward+' crumbs and a bit of standing in '+t.name+'.'].concat(wlCaseLines(c).slice(0,2));
  if(!g.inv.shovel) lines.push('You will need a shovel to dig it up. Supply shops and markets sell them.');
  if(c.state===1){ say('Notice Board',wlCaseLines(c).concat(['Face the ground and press D to dig. The HUD shows how warm you are.'])); return; }
  say('Notice Board',lines,()=>{
    choose('Notice Board','Take the case?',['Take the case','Not now'],k=>{
      if(k===0){ c.state=1; coin(); toast('Case taken. Details are in your journal (J). Press D with a shovel to dig.',3600); }
    },1);
  });
}
function wlSolveCase(c){
  const t=townByKey(c.tk), w=WD(); c.state=2; w.stats.cases=(w.stats.cases||0)+1;
  g.crumbs+=c.reward; coin();
  const id=rnd()<0.5?WL_DIG[Math.floor(rnd()*WL_DIG.length)]:wlRareFind(WL_BY[c.biome]);
  wlPlace(id,1,true);
  say('',['Your shovel strikes something solid. There it is!','Case closed: '+c.title+'. +'+c.reward+' crumbs, and a '+ITEMS[id].name+' that was buried alongside it.','You will tell '+c.client+' the good news the next time you pass through '+c.town+'.'],()=>{ if(t) addRep(t,2); });
}
function wlCaseNear(){
  const w=g.story&&g.story.wd; if(!w) return null;
  const p=wlTile(); let best=null;
  for(const k in w.cases){ const c=w.cases[k]; if(c.state!==1||c.day!==g.day) continue; const d=Math.hypot(c.x-p.x,c.y-p.y); if(!best||d<best.d) best={c:c,d:d}; }
  return best;
}
function wlWarm(d){ return d<5?'Burning':d<10?'Hot':d<20?'Warm':d<40?'Cool':d<80?'Cold':'Freezing'; }

/* the notice board gets a daily case and a map shop tip */
{
  const _choose2=choose;
  choose=function(who,text,opts,cb,cancel){
    if(who==='Notice Board'&&/^TOWN NOTICES/.test(text)&&opts.length>1){
      const tw=wlTile(), t=townAtTile(tw.x,tw.y);
      if(t){
        const c=wlCaseFor(t);
        const label=c?(c.state===2?'Daily case: solved ('+c.title.replace('The Case of the ','')+')':c.state===1?'Daily case: in progress':'Daily case: '+c.title.replace('The Case of the ','')+' (+'+c.reward+')'):'Daily case: none today';
        const base=opts.slice(0,-1), nopts=base.concat([label],[opts[opts.length-1]]);
        const ncb=k=>{ if(k<base.length) cb(k); else if(k===base.length) wlOpenCase(t); else cb(opts.length-1); };
        return _choose2(who,text,nopts,ncb,nopts.length-1);
      }
    }
    return _choose2(who,text,opts,cb,cancel);
  };
}

/* ---------------- selling finds at any shop counter ---------------- */
const wlSellable=()=>Object.keys(g.inv).filter(id=>ITEMS[id]&&ITEMS[id].sell&&g.inv[id]>0).sort((a,b)=>ITEMS[b].sell-ITEMS[a].sell);
function wlFindCount(){ let n=0; for(const id of wlSellable()) n+=g.inv[id]; return n; }
function wlSellPrice(id,b,t){
  const base=({curio:1.3,books:1.05,supply:1.0,market:0.85,bakery:0.8,cafe:0.8})[b.kind]||0.85;
  const dem=0.9+0.2*hash(b.x+g.day,b.y,8300);
  return Math.max(1,Math.round(ITEMS[id].sell*base*dem*(1+0.04*townRank(t))*wlHaggle()));
}
function wlSellMenu(b,t){
  const nm=b.keeper.name, ids=wlSellable();
  if(!ids.length){ say(nm,['You have nothing I would buy right now.']); return; }
  let total=0, units=0; for(const id of ids){ total+=wlSellPrice(id,b,t)*g.inv[id]; units+=g.inv[id]; }
  const labels=['Sell everything ('+units+' for '+total+' crumbs)','Pick what to sell...','Never mind'];
  choose(nm,'I will take finds off your hands. '+(b.kind==='curio'?'Curios are my favourite.':'Everything has a price.'),labels,k=>{
    if(k===0){ for(const id of ids){ const n=g.inv[id]; for(let i=0;i<n;i++) delInv(id); } g.crumbs+=total; coin(); toast('Sold '+units+' find'+(units===1?'':'s')+' for '+total+' crumbs.',2800); wlStat('sold',units); return; }
    if(k===1) wlSellPick(b,t,ids);
  },2);
}
function wlStat(k,n){ const s=WD().stats; s[k]=(s[k]||0)+(n||1); }
function wlSellPick(b,t,ids){
  const nm=b.keeper.name;
  const labels=ids.map(id=>ITEMS[id].name+' x'+g.inv[id]+'  ('+wlSellPrice(id,b,t)+' each)');
  pagedChoose(nm,'What would you like to sell?',labels,i=>{
    const id=ids[i], p=wlSellPrice(id,b,t), n=g.inv[id];
    const opts=['Sell 1 ('+p+')'].concat(n>1?['Sell all '+n+' ('+p*n+')']:[],['Back']);
    choose(nm,ITEMS[id].name+' - '+p+' crumbs each.',opts,k=>{
      if(k>=opts.length-1){ wlSellPick(b,t,wlSellable()); return; }
      const cnt=k===0?1:n; for(let j=0;j<cnt;j++) delInv(id);
      g.crumbs+=p*cnt; coin(); wlStat('sold',cnt); toast('Sold '+cnt+' for '+p*cnt+' crumbs.',2200);
      const left=wlSellable(); if(left.length) wlSellPick(b,t,left);
    },opts.length-1);
  },5);
}
openCounter=function(){
  const b=g.shop.b, t=g.shop.town, left=SHIFTS_PER_DAY-workCount(wkey(b));
  const labels=['Browse the shelves','Ask for work ('+Math.max(0,left)+' shift'+(left===1?'':'s')+' left today)','Chat'];
  const fns=[()=>openShop(),()=>askWork(b,t),()=>chatKeeper(b,t)];
  if(fishBuyer(b)&&FISHIDS.some(id=>g.inv['fish_'+id]&&fishOK(b,id))){ labels.push('Sell fish ('+fishCount()+')'); fns.push(()=>sellFish(b,t)); }
  if(wlFindCount()>0){ labels.push('Sell finds ('+wlFindCount()+')'); fns.push(()=>wlSellMenu(b,t)); }
  labels.push('Leave'); fns.push(()=>{});
  const gr=RANK_GREET[townRank(t)];
  choose(b.keeper.name,gr[(b.idx+g.day)%gr.length]+' What can I do for you?',labels,k=>fns[k](),labels.length-1);
};
{
  const _renderShop=renderShop;
  renderShop=function(){ _renderShop(); const s=el.shList.querySelector('li.sel'); if(s&&s.scrollIntoView) s.scrollIntoView({block:'nearest'}); };
}

/* ---------------- townduck requests for finds ---------------- */
{
  const _favorDef=favorDef;
  favorDef=function(t,i){
    const def=_favorDef(t,i);
    if(def) return def;
    const key='w'+g.day+':'+i;
    if(t.favCache[key]!==undefined) return t.favCache[key];
    let out=null;
    if(hash(t.rx*29+i,t.ry*19+g.day,950+i)<0.4){
      const r=hash(t.rx+i*3,t.ry+g.day,960+i);
      const pool=r<0.4?WL_TRAIL:r<0.7?WL_DIG:Object.keys(WL_FIND).filter(id=>WL_FIND[id].src!=='trail'&&WL_FIND[id].src!=='dig'&&WL_FIND[id].src!=='treasure'&&WL_FIND[id].sell<=14&&!WL_FIND[id].night);
      out={type:'fetch',item:pool[Math.floor(hash(t.rx,t.ry+i,970+g.day)*pool.length)],wild:1};
    }
    t.favCache[key]=out;
    return out;
  };
  const _favorReward=favorReward;
  favorReward=function(t,def){
    if(def&&def.wild) return Math.max(5,Math.round((ITEMS[def.item].sell*1.8+6)*payMul(t)));
    return _favorReward(t,def);
  };
  const _favorPitch=favorPitch;
  favorPitch=function(t,i,def){
    if(def&&def.wild){
      const it=ITEMS[def.item], rw=favorReward(t,def), late='No rush. A few days is fine.';
      const by=it.src==='trail'?['I dropped a '+it.name+' somewhere out on the trails, and I miss it terribly.','If you come across one on your travels, bring it to me. I will pay '+rw+' crumbs. '+late]
        :it.src==='dig'?['I collect old things, and I am missing a '+it.name+' for my shelf.','They turn up at glinting dig spots, if you have a shovel. I will pay '+rw+' crumbs. '+late]
        :['I am looking for a '+it.name+'. They turn up when you forage out in the '+(WL_BY[it.src]?WL_BY[it.src].name:'wild')+'.','Bring me one and I will pay '+rw+' crumbs. '+late];
      return by;
    }
    return _favorPitch(t,i,def);
  };
  const _acceptFavor=acceptFavor;
  acceptFavor=function(t,i,def){
    const q=_acceptFavor(t,i,def);
    if(def&&def.wild) q.due=g.day+3;
    return q;
  };
}

/* ---------------- using the new items from the pack ---------------- */
{
  const _useItem2=useItem;
  useItem=function(id){
    const it=ITEMS[id];
    if(it&&it.use==='tmap'){
      if(g.scene!=='world'){ el.dNote.textContent='Unfold it outside, where the wild is.'; blip(); return; }
      closeInv(); if(wlUnfoldMap()) return; return;
    }
    if(it&&it.use==='clog'){ closeInv(); wlOpenLog(); return; }
    if(id==='shovel'){ el.dNote.textContent='Face open ground and press D to dig. (Treasure maps, dig spots and daily cases all need it.)'; blip(); return; }
    _useItem2(id);
  };
}

/* ---------------- keys: D digs, L opens the log ---------------- */
KEYMAP.d='d'; KEYMAP.D='d'; KEYMAP.l='l'; KEYMAP.L='l';
{
  const _press2=press;
  press=function(k){
    if(g.mode==='play'&&g.scene==='world'){
      if(k==='d'){ wlDig(); return; }
      if(k==='l'){ if(g.inv.clog) wlOpenLog(); else toast('You need a Collection Log to open. Bookshops and curio shops sell them.',3000); return; }
    }
    _press2(k);
  };
}

/* ---------------- the explored map shows buried treasure and the search area of today's cases ---------------- */
{
  const _drawMap2=drawMap;
  drawMap=function(){
    _drawMap2();
    const w=g.story&&g.story.wd; if(!w) return;
    const c=mctx, z=m.z, tx0=m.cx-mapW/2/z, ty0=m.cy-mapH/2/z;
    c.setTransform(dpr,0,0,dpr,0,0);
    for(const h of w.hunts){
      const sx=(h.x+0.5-tx0)*z, sy=(h.y+0.5-ty0)*z;
      if(sx<-20||sy<-20||sx>mapW+20||sy>mapH+20) continue;
      c.strokeStyle='#0d1613'; c.lineWidth=6; c.beginPath(); c.moveTo(sx-7,sy-7); c.lineTo(sx+7,sy+7); c.moveTo(sx+7,sy-7); c.lineTo(sx-7,sy+7); c.stroke();
      c.strokeStyle='#ff4a3a'; c.lineWidth=3; c.beginPath(); c.moveTo(sx-7,sy-7); c.lineTo(sx+7,sy+7); c.moveTo(sx+7,sy-7); c.lineTo(sx-7,sy+7); c.stroke();
      c.font='600 13px ui-monospace,"Courier New",monospace'; c.textAlign='left'; c.textBaseline='middle'; c.lineWidth=3; c.strokeStyle='#0d1613'; c.strokeText(WL_TIERS[h.tier].n+' treasure',sx+11,sy+1); c.fillStyle='#ffd7a0'; c.fillText(WL_TIERS[h.tier].n+' treasure',sx+11,sy+1);
    }
    for(const k in w.cases){
      const cs=w.cases[k]; if(cs.state!==1||cs.day!==g.day) continue;
      const sx=(cs.x+cs.jx+0.5-tx0)*z, sy=(cs.y+cs.jy+0.5-ty0)*z, r=8*z;
      c.strokeStyle='rgba(255,230,120,0.9)'; c.lineWidth=2; c.setLineDash([6,5]); c.beginPath(); c.arc(sx,sy,r,0,6.2832); c.stroke(); c.setLineDash([]);
      c.fillStyle='rgba(255,230,120,0.12)'; c.beginPath(); c.arc(sx,sy,r,0,6.2832); c.fill();
      c.font='600 13px ui-monospace,"Courier New",monospace'; c.textAlign='center'; c.textBaseline='middle'; c.lineWidth=3; c.strokeStyle='#0d1613'; c.strokeText('Case area',sx,sy); c.fillStyle='#ffe99a'; c.fillText('Case area',sx,sy);
    }
  };
}

/* ---------------- the journal ---------------- */
{
  const _journalExtra2=journalExtra;
  journalExtra=function(sec,line){
    _journalExtra2(sec,line);
    const w=WD(), p=wlTile();
    sec('The wild');
    const seen=Object.keys(w.seen).length, finds=Object.keys(w.got).filter(id=>WL_FIND[id]).length;
    line('Plants found: '+seen+' / '+WL_SPLIST.length+'   Finds: '+finds+' / '+Object.keys(WL_FIND).length+'   Places: '+Object.keys(w.biomes).length+' / '+WL_BIOMES.length,'jdim');
    line('Plants collected so far: '+(w.stats.forage||0));
    if(w.hunts.length){
      line('Treasure maps ('+w.hunts.length+'):');
      for(const h of w.hunts){ const dx=h.x-p.x, dy=h.y-p.y; line('  '+WL_TIERS[h.tier].n+' map: '+Math.round(Math.hypot(dx,dy))+' waddles '+wlDir(dx,dy)+' '+wlArrow(dx,dy)+', in the '+WL_BY[h.biome].name+(h.lm?' (look for a '+h.lm+')':'')); }
    } else line('No open treasure maps. Curio shops and bookshops sell them.','jdim');
    const open=Object.keys(w.cases).map(k=>w.cases[k]).filter(c=>c.day===g.day&&c.state===1);
    if(open.length) for(const c of open){ line(c.title+' ('+c.town+', +'+c.reward+' crumbs)'); for(const l of wlCaseLines(c)) line('  '+l); }
    else line('No case in progress. Notice boards post a new one every day.','jdim');
  };
}

/* ---------------- HUD: warmth for cases, shortcut buttons, objective ---------------- */
{
  const chips=document.querySelector('#hud .chips'), btns=document.querySelector('#hud .btns');
  const chip=document.createElement('span'); chip.className='chip'; chip.id='caseChip'; chip.hidden=true; chip.innerHTML='Case <b id="caseTxt"></b>'; chips.appendChild(chip);
  const mk=(id,txt,fn)=>{ const b=document.createElement('button'); b.className='hb'; b.id=id; b.type='button'; b.textContent=txt; b.hidden=true; b.addEventListener('click',e=>{ e.currentTarget.blur(); if(g.mode==='play') fn(); }); btns.insertBefore(b,document.getElementById('bSnd')); return b; };
  const bLog=mk('bLog','Log (L)',()=>wlOpenLog()), bDig=mk('bDig','Dig (D)',()=>wlDig());
  const _updateHud2=updateHud;
  let lastC='', cTick=0;
  updateHud=function(){
    _updateHud2();
    if(g.scene!=='world'){ if(!chip.hidden) chip.hidden=true; return; }
    const cn=wlCaseNear(), want=cn?wlWarm(cn.d):'';
    if(want!==lastC){ lastC=want; chip.hidden=!want; if(want) document.getElementById('caseTxt').textContent=want; }
    if(cn&&!cn.c.c3&&cn.d<14){ cn.c.c3=true; toast('Something feels near. Clue 3 is in your journal.',3200); }
    if(bLog.hidden===!!g.inv.clog) bLog.hidden=!g.inv.clog;
    if(bDig.hidden===!!g.inv.shovel) bDig.hidden=!g.inv.shovel;
  };
}
{
  const _tip=document.getElementById('keysTip');
  if(_tip) _tip.innerHTML='Arrows move &middot; Z interact &middot; I pack &middot; 1-0 hotbar &middot; Z use &middot; J journal &middot; M map &middot; D dig &middot; L log';
}
/* a fresh world starts a fresh biome cache */
{
  const _resetWorld=resetWorld;
  resetWorld=function(){ _resetWorld(); wlCache.clear(); };
}

/* a plant you have collected stays gone */
{
  const _gen=genTile;
  genTile=function(x,y){
    const v=_gen(x,y);
    if(WL_TILECAT[v]){ const w=g.story&&g.story.wd; if(w&&w.gone&&w.gone[x+','+y]) return T.GRASS; }
    return v;
  };
}
