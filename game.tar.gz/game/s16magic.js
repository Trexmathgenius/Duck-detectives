'use strict';
/* ===== THE SPELL BAR, INSIDE ROOMS TOO =====
   Outside, Q / E choose a spell on the spell bar and C casts it at what you face. Inside rooms the same bar now works:
   no menu, no scrolling. Things in rooms only tell you what they are; which spell (if any) answers them is for you to decide.
   - the bar shows in rooms (spells.js), Q / E choose, C casts the chosen spell at whatever you are facing (s2sx.js)
   - holding a magic item picks its spell; Z with nothing in front of you casts it
   - no spell is ever suggested by the thing you are looking at */
(function(){
{
  const _press=press;
  press=function(k){
    if(g.mode==='play'&&g.scene==='sx'&&SX.S){
      if(k==='sp_prev'){ spCycle(-1); return; }
      if(k==='sp_next'){ spCycle(1); return; }
      if(k==='z'&&!g.target){
        let hid=null; try{ hid=heldId(); }catch(e){}
        const n=hid&&SP_BY_ITEM[hid];
        if(n){ sxCastNamed(n); return; }
      }
    }
    _press(k);
  };
}
/* say how it works the first time you are in a room with spells */
{
  const _enter=sxEnter;
  sxEnter=function(id,tx,ty,dir){
    _enter(id,tx,ty,dir);
    try{
      const st=g.story; if(!st||!st.isRed||magicDays()<1) return;
      const x=XS(); if(x.roomHint) return; x.roomHint=1;
      setTimeout(()=>{ if(g.mode==='play') toast('Spells work in here too: Q and E choose one, C casts it at whatever you are facing.',5200); },1200);
    }catch(e){}
  };
}
})();
