'use strict';
/* ===== THE SPELL BAR, INSIDE ROOMS TOO =====
   Outside, Q / E choose a spell on the spell bar and C casts it at what you face. Inside rooms the same bar now works:
   no menu, no scrolling. Things in rooms only tell you what they are; which spell (if any) answers them is for you to decide.
   - the bar shows in rooms (spells.js), Q / E choose, C casts the chosen spell at whatever you are facing (s2sx.js)
   - holding a magic item picks its spell; Z with nothing in front of you casts it
   - no spell is ever suggested by the thing you are looking at */
(function(){
{
  const _press=press;
  press=function(k){
    if(g.mode==='play'&&g.scene==='sx'&&SX.S){
      if(k==='sp_prev'){ spCycle(-1); return; }
      if(k==='sp_next'){ spCycle(1); return; }
      if(k==='z'&&!g.target){
        let hid=null; try{ hid=heldId(); }catch(e){}
        const n=hid&&SP_BY_ITEM[hid];
        if(n){ sxCastNamed(n); return; }
      }
    }
    _press(k);
  };
}
/* say how it works the first time you are in a room with spells */
{
  const _enter=sxEnter;
  sxEnter=function(id,tx,ty,dir){
    _enter(id,tx,ty,dir);
    try{
      const st=g.story; if(!st||!st.isRed||magicDays()<1) return;
      const x=XS(); if(x.roomHint) return; x.roomHint=1;
      setTimeout(()=>{ if(g.mode==='play') toast('Spells work in here too: Q and E choose one, C casts it at whatever you are facing.',5200); },1200);
    }catch(e){}
  };
}
})();

/* ===== SPELLS AT THINGS OUT IN THE WORLD (story props: lanterns, fires...) =====
   A story prop may carry a `cast` table. Face it, choose a spell on the bar (Q / E), press C.
   Z only ever tells you what the thing is. */
(function(){
const _sc=spellCast;
spellCast=function(n){
  if(g.mode==='play'&&g.scene==='world'&&!(typeof sxIn==='function'&&sxIn())){
    const tg=g.target, p=tg&&tg.k==='s2p'&&tg.p;
    if(p&&p.cast){
      let known=[]; try{ known=spKnown(); }catch(e){}
      if(known.indexOf(n)<0){ toast('You have not learned '+n+' yet.',2200); return; }
      const need=SPNEED[n];
      if(need&&!isHeld(need)){ toast(g.inv[need]?holdText(need):'You have no '+ITEMS[need].name+'. '+n+' needs it.',3200); return; }
      try{ spSetSel(n); }catch(e){}
      if(p.cast[n]){
        try{ spRing((p.wx+0.5)*TS,p.wy*TS-6,SP_COL[n][0],3,34,0.5,2.5); }catch(e){}
        p.cast[n](p);
      } else toast('Nothing here answers to '+n+'.',2400);
      return;
    }
  }
  _sc(n);
};
})();

/* one of each named character: when a story-placed copy (S2) is on the map, the old follower or
   wanderer of the same name is dropped, and any repeated copy is dropped as well */
{
  const _en=extraNpcs;
  extraNpcs=function(list){
    _en(list);
    const by={};
    for(const n of list){ if(n&&n.name&&!n.guard) (by[n.name]=by[n.name]||[]).push(n); }
    for(const nm in by){
      const a=by[nm]; if(a.length<2) continue;
      const keep=a.find(n=>n.special==='s2'); if(!keep) continue;
      for(const n of a){ if(n===keep) continue; const i=list.indexOf(n); if(i>=0) list.splice(i,1); }
    }
  };
}
