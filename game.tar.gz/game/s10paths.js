/* ===== FORKS IN THE ROAD (v1.25.3) =====
   Until now most choices changed a line. Here the middle of the story splits on what you did:
     1. Mallow turns you away twice at the watchtower  -> no Hollow Token. You break into the Hearth Vault alone:
        no guide, an extra warden, and Cinder lends the coal on terms (a debt the Crown gate remembers).
     2. A trail of lies reaches the summit             -> you are held. Wait for Mallow (if he still vouches), confess, or break out.
     3. Your deeds lean toward the other side          -> at the end of the summit you may cross the road.
     4. The Gate of Ash / Gold reads your record       -> the leader refuses to talk (the wanted, the in-debt, the liars),
                                                          or friends on the line step aside (kin, mercy).
     5. The Burnt Wood knows you                       -> no guide without trust; the wisps spare the merciful.
     6. The Tree's endings close on the paths you took -> Wake, Door and Keep each get a reason you can read.
   A toast says what changed and why, and the Journal carries "Your Path".
   State lives in the save (g.story.s2.path). Adds D10.path. */
(function(){
'use strict';
const D10=window.D10=window.D10||{};
const P=()=>{ const q=s2(); return q.path||(q.path={}); };
D10.path=()=>P();
const MAL=()=>(typeof H3!=='undefined'?H3:'Hermit Mallow');
const lean=()=>{ let a=0,b=0; try{ a=(s2led('crown')-s2led('ember')); }catch(e){} try{ b=(S6.get('crown')-S6.get('hearth')); }catch(e){} return a+b; };
D10.lean=lean;
const later=(fn,ms)=>setTimeout(()=>{ try{ fn(); }catch(e){ console.warn('paths',e); } },ms);
const note=(t,ms)=>later(()=>{ if(g.mode==='play'||g.mode==='dialog') toast(t,ms||6500); },2400);

/* ---------------- 1. Mallow turns you away ---------------- */
{
  const _p=S2.persuade;
  S2.persuade=function(d){
    try{
      if(d&&d.who===MAL()&&s2at('c8c',1)&&d.lose&&!d.__path){
        d.__path=1; const lose=d.lose;
        d.lose=function(){
          const p=P(); p.mLoss=(p.mLoss||0)+1;
          if(p.mLoss>=2&&!p.cold){
            p.cold=1; s2led('trust',-1);
            seq([[MAL(),['(He has been holding the mug for a long time. He puts it down.)','Twice, now. I asked you what you would do with it, and twice you have said the sentence that is easiest to say.','I am not angry. I am very tired of being hopeful. Go home, little detective. I cannot give you the token. I will not be at the door.']],
              ['',['He turns his back, kindly, the way one turns from a fire one cannot feed. The tower lamp that you mended goes on burning behind him.','There is still a door under the Hearth. There is just no one to hold it for you.']]],()=>{ toast('Mallow will not meet you. The Hollow Door is yours alone.',5200); S2.finish('c8c'); });
            return;
          }
          lose.apply(this,arguments);
          if(p.mLoss===1) toast('Mallow is not convinced. One more miss and he will turn you away.',4200);
        };
      }
    }catch(e){ console.warn('paths persuade',e); }
    return _p.apply(this,arguments);
  };
}
try{
  const hd=S2.props.get('hollowdoor'), ou=hd&&hd.use;
  if(hd&&ou) hd.use=function(){
    if(!P().cold) return ou.apply(this,arguments);
    const night=g.clock>=23.5||g.clock<3;
    const go=()=>seq([['',['There is a hollow in the stone the size of a disc. You have no disc. You do not have Mallow either.','But the south wall was built by ducks who loved a back way. Beside the door, a drain the width of a duck runs under the sill. It smells of a hundred years.']]],()=>sxEnter('vault1'));
    if(night) go();
    else choose('The Hollow Door','No token. No guide. The drain is dark, and the wardens change at midnight.',['Wait until midnight','Come back later'],k=>{ if(k===0){ fade(1.2); advanceClock(((23.6-g.clock)+24)%24); setTimeout(go,300); } },1);
  };
}catch(e){ console.warn('paths hollowdoor',e); }
try{
  const d=SX.defs.vault1, oe=d.onEnter;
  d.onEnter=function(S){
    if(!P().cold) return oe.call(this,S);
    S.follow=null; S.trail=[]; S.fl.hint=1;
    if(!S.__cold){ S.__cold=1; S.guards.push(sxGuard({name:'Hearthwarden',path:[[13,2],[13,6],[16,6],[16,2]],speed:30,range:5,fov:60,pal:WARDEN_PAL,head:'helm'})); }
    sxSay(S,'',['(You came through the drain alone. Nobody is going to whisper which pillar to hide behind.)','There are three wardens tonight. The lever for the portcullis is where Poppy said it would be, if you remember what Poppy said.']);
  };
}catch(e){ console.warn('paths vault1',e); }
try{
  const d=SX.defs.vault2, n0=d.npcs&&d.npcs[0], ot=n0&&n0.talk;
  if(n0&&ot) n0.talk=function(S,n){
    if(!P().cold||S.fl.done) return ot.call(this,S,n);
    const give=(debt)=>{
      S.fl.done=1; addItem('hearthcoal'); coin(); hudCache.obj=null; toast('Received: the Coal of the First Hearth.'+(debt?' (On loan.)':''),4600);
      if(debt) P().debt=1;
      sxSay(S,'Warden Ruddock',['(Ruddock stands in the vault door. He has been there a while.)','I did not see you. I did not see how you got in, either, which is a worse thing not to have seen.','Go. And apprentice: you owe this house now.']);
    };
    S2.persuade({who:'Elder Cinder',intro:['Cinder does not look up. "Mallow said you would come with a token. There is no token. There is a duck who came through the drain."','"Either you are very good, or you are very desperate. I would like to know which."'],
      rounds:[{q:'"Why should the Hearth give you its first fire?"',opts:[
        {t:'"Because the king\'s crystal is failing and I am the only one who has seen it."',p:2,led:{truth:1},say:['She looks at you, then. Properly.']},
        {t:'"Because Mallow believed in me once."',p:1,say:['"Once. He has told me why not twice."']},
        {t:'"Because I got in."',p:0,led:{pride:1},say:['"So would a rat."']}]}],need:2,
      win:()=>seq([['Elder Cinder',['Then I will give it without terms. You came through the dark and still told me the truth, and that is the whole of what the token was for.']]],()=>give(false)),
      lose:()=>seq([['Elder Cinder',['I do not like you yet. But the Hearth is failing, and I like that less. Take it. It is a loan, not a gift.','The Hearth remembers its loans.']]],()=>give(true))});
  };
}catch(e){ console.warn('paths vault2',e); }

/* ---------------- 2 & 3. the end of the summit: held, then crossing the road ---------------- */
sxDef('held',{name:'The Holding Cells',theme:'stone',indoor:true,dark:0.6,lightR:86,start:[1,4,'right'],
  hint:'A loose stone in your cell. The wardens turn their lanterns slowly. Pillars block their sight.',
  caughtLines:['"Back in your cell." A lantern is held up to your face. Nobody is cruel about it. They are tired, and you are the reason they are tired.'],
  rows:sxGrid(24,9,[[0,4,'D'],[23,4,'E'],[5,1,1,3,'#'],[5,5,1,3,'#'],[5,4,'G'],[1,1,'S'],[12,2,'P'],[12,6,'P'],[16,3,'P'],[16,5,'P'],[9,0,'t'],[9,8,'t'],[19,0,'t'],[19,8,'t']]),
  exits:{D:{fn:S=>{ say('',['The cell door is locked, and watched.']); }},E:{fn:S=>{ if(!S.fl.pc){ say('',['Not from here.']); return; } sxLeave(KX-76,KY-24); s2led('pride',1); toast('Out. They will remember.',3600); later(()=>heldAfter('escaped'),500); }}},
  objs:{
    S:{name:'Loose stone',glyph:'rock',col:'#6a6a70',desc:'A stone in the wall that is a little less square than the rest.',use:(S)=>{ if(S.fl.pc){ say('',['The gap is open.']); return; } S.fl.pc=1; sxSet(S,5,4,'.'); sxSay(S,'',['The stone comes away. Behind it, someone, many years ago, scratched a very small map of the cell block. You follow it with one wing.','The pin in the bars rattles loose. You are out of the cell.']); }},
    P:{name:'Pillar',glyph:'pillar',block:true,col:'#7a5a52'},
    G:{name:'Cell bars',glyph:'gate',solid:true,when:S=>!S.fl.pc,desc:'Iron bars.'},
    t:{name:'Wall torch',glyph:'torch',light:true,lightR:80,solid:true}
  },
  guards:[{name:'Warden',path:[[7,1],[22,1],[22,7],[7,7]],speed:32,range:5,fov:62,pal:WARDEN_PAL,head:'helm'},
          {name:'Warden',path:[[8,4],[19,4]],speed:26,range:5,fov:60,pal:WARDEN_PAL,head:'helm',pause:0.9,scan:true}],
  onEnter(S){ if(!S.fl.hint){ S.fl.hint=1; sxSay(S,'',['A cell the size of a pantry. One high window. A stone in the wall that is a little less square than the rest.']); } }
});
function lieHeld(){ const L=s2().led||{}; return (L.lie||0)>=3||((L.lie||0)>=2&&(L.pride||0)>=3); }
let heldCont=null;
function heldAfter(how){ const c=heldCont; heldCont=null; P().held=how; if(c) c(); }
function heldScene(cont){
  heldCont=cont; P().held='held';
  const vouch=!P().cold&&s2led('trust')>=1;
  seq([['The Clerk',['(The clerk reads, from a long slip of paper, in the voice of someone who has hoped not to.)','"...and on the fourth, that the detective said one thing to the Crown and another to the Hollow, and on the ninth, that the detective said a third thing to both."','"The two sides have, for the first time in a hundred years, agreed on something. It is that you are not to be believed."']],
    ['',['They do not strike you. They take your satchel and shut a door that is surprisingly well oiled.','You have until the morning. The war will not wait that long. You are going to have to decide how you leave.']]],()=>{
    const opts=[vouch?'Wait. Mallow will speak for me.':'(Wait. Nobody is coming.)','Confess, plainly, to all of it.','Find the way out yourself.'];
    choose('The Holding Cells','What do you do?',opts,k=>{
      if(k===0){
        if(!vouch){ seq([['',['You wait. The night goes by, and the lantern goes by, and nobody comes.','By the small hours you understand that the person who would have come is the one you stopped giving a reason to.']],
            ['',['At dawn a warden you never saw before opens the cell and says, without looking at you: "Go. The Captain says you are more use outside."','You do not take it as mercy. You take it as a warning.']]],()=>{ s2led('trust',-1); heldAfter('released'); }); return; }
        seq([[MAL(),['(Mallow is at the door, in his smallest coat, holding a letter.)','I told them I have been wrong about you once and it cost me my Elders. I told them I would rather be wrong about you twice than right about you never.','That cost me something. It was the right price. Come.']]],()=>{ try{ S6.cap('mallow',-1); }catch(e){} s2led('trust',-1); heldAfter('vouched'); });
      } else if(k===1){
        seq([['The Clerk',['(She sets down the pen.)','"In eleven years, no one has ever said it before I read it out."','"I am going to write that down, too."']]],()=>{ s2led('truth',2); s2().led.lie=Math.max(0,(s2().led.lie||0)-2); s2led('pride',-1); heldAfter('confessed'); });
      } else sxEnter('held');
    },2);
  });
}
function cross(to){
  const q=s2(), p=P(); p.defected=to; q.route=(to==='red')?'red':'crown';
  try{ if(to==='red'&&g.story.banished){ g.story.banished=0; try{ ART().readmit=1; }catch(e){} try{ tileCache.clear(); }catch(e){} } }catch(e){}
  try{ if(!g.inv.hearthcoal) addItem('hearthcoal'); }catch(e){}
  q.fl.defected=to;
}
function defectScene(next){
  const red=s2red(), to=red?'crown':'red';
  const lines=red?
    [['Captain Halbeak',['(A rider in blue has been waiting at the edge of the broken tent for some time.)','"Detective. I watched you at the table. Every deed in the clerk\'s hand pointed toward us, and you did not seem to notice."','"I am not asking you to change sides. I am asking you whose road you have been walking."']]]:
    [['Elder Cinder',['(Cinder has come down the hill alone, without Ruddock, which is how you know how bad it is.)','"I read your record in the clerk\'s hand. You have done more for us, Detective, than for the king you were sent to serve."','"They cast you out. I did not stop them. I should like to unsay that. Walk with us. Not as a prisoner. As someone who has already been walking."']]];
  seq(lines,()=>{
    choose('The Summit','Whose road?',[red?'Cross to the Crown. Walk with Halbeak.':'Cross to the Hollow. Walk with Cinder.','Stay on the road you chose.'],k=>{
      if(k===0){ cross(to); toast(to==='red'?'You have crossed to the Hollow. The road ahead is theirs.':'You have crossed to the Crown. The road ahead is theirs.',5600);
        seq([['',[to==='red'?'Cinder takes your wing. It is warm, and she does not say it was inevitable.':'Halbeak does not salute. He holds the flap of the tent open for you, which is the same thing, in his language.']]],next); }
      else { P().stayed=1; s2led('pride',1); next(); }
    },1);
  });
}
{
  const _fin=S2.finish;
  S2.finish=function(id,msg){
    if(id!=='c12') return _fin.apply(this,arguments);
    const args=arguments, p=P();
    const cont=()=>{
      const q=s2(), L=lean(), red=s2red();
      const canCross=!q.keeper&&s2led('trust')<2&&!p.defected&&!p.stayed;
      if(canCross&&((red&&L>=3)||(!red&&L<=-3))){ defectScene(()=>_fin.apply(null,args)); return; }
      _fin.apply(null,args);
    };
    if(lieHeld()&&!p.held){ heldScene(cont); return; }
    cont();
  };
}

/* ---------------- 4 & 5. the Gate and the Wood read your record ---------------- */
{
  const _en=sxEnter;
  sxEnter=function(id){
    const r=_en.apply(this,arguments);
    try{
      const S=SX.S, p=P(), L=s2().led||{}, why=[];
      if(S&&(id==='bgR'||id==='bgC')&&!S.__paths){
        S.__paths=1;
        const red=id==='bgR';
        let force=false;
        if(p.held==='escaped'){ force=true; why.push('You broke out of a cell. The line has your description.'); }
        if(!red&&p.debt){ force=true; S.guards.push(sxGuard({name:'Hollow Warden',path:[[10,3],[10,7],[14,7],[14,3]],speed:30,range:5,fov:60,pal:WARDEN_PAL,head:'helm'})); why.push('The Hearth remembers its loan. Ruddock has set another man on the road.'); }
        if(p.defected){ S.guards.forEach(q=>{ if(typeof q.range==='number') q.range+=1; }); why.push('They know you crossed. Nobody on this line is sure whose side you are on.'); }
        if((L.lie||0)>=2&&(L.pride||0)>=2){ force=true; why.push('Word of your lies has reached the line.'); }
        if((L.kin||0)>=3){ const i=S.guards.findIndex(q=>q.scan); if(i>=0){ S.guards.splice(i,1); why.push('A child you helped waves from the line. One guard has found a reason to look elsewhere.'); } }
        if((L.mercy||0)>=4&&S.guards[0]&&typeof S.guards[0].range==='number'){ S.guards[0].range=Math.max(3,S.guards[0].range-2); why.push('The ones you spared have been talking. The line is calmer than it should be.'); }
        if(force){
          const n=S.npcs[0];
          if(n){ const ot=n.talk; n.talk=function(S2_,nn){ if(S2_.fl.pass) return ot.call(this,S2_,nn); say(n.name,['I have orders about you. No talking. No bargaining.','(He does not look at you. He looks at the wood behind you, and the way round.)'],null); }; }
          S.fl.hint=1; why.push('The leader will not talk to you. Go round.');
        }
        S.fork2=why;
        if(why.length) note(why.join('  '),why.length>2?9500:7000);
      }
      if(S&&id==='bw1'&&!S.__paths){
        S.__paths=1;
        if(p.cold&&s2led('trust')<2){ S.follow=null; S.trail=[]; S.fl.hint=1; why.push('Mallow is not here to hold your wing. The Wood remembers that you were turned away.'); S.guards.forEach(q=>{ if(typeof q.range==='number') q.range+=1; }); }
        if(s2led('mercy')>=4&&S.guards.length>2){ S.guards.pop(); why.push('One of the wisps knows you. It drifts away from the path.'); }
        S.fork2=why;
        if(why.length) note(why.join('  '),8000);
      }
    }catch(e){ console.warn('paths gate',e); }
    return r;
  };
}

/* ---------------- 6. the endings close for reasons you can name ---------------- */
{
  const _eo=endingsOpen;
  endingsOpen=function(){
    const o=_eo.apply(this,arguments), p=P(), L=s2().led||{};
    try{
      if(p.cold&&(L.trust||0)<3) o.wake=false;
      if(p.defected&&(L.kin||0)<2&&(L.mercy||0)<3) o.door=false;
      if(p.held==='escaped'&&(L.truth||0)<4) o.keep=false;
      if(p.debt&&(L.kin||0)<1) o.door=false;
      if(!o.wake&&!o.door&&!(s2().keeper&&o.keep)&&!o.mercy){ const best=(S6.get('sleepers')>=S6.get('crown')+S6.get('hearth'))?'wake':'door'; o[best]=true; o.mercy=best; }
    }catch(e){ console.warn('paths endings',e); }
    return o;
  };
  const _fc=finalChoice, base={};
  finalChoice=function(S){
    try{
      const p=P();
      for(const k of ['wake','door','keep']) if(base[k]===undefined) base[k]=CLOSED[k];
      CLOSED.wake=p.cold?'Mallow turned you away at the tower, and the Wood remembers who was not at the door.':base.wake;
      CLOSED.door=p.defected?'You crossed the road once already. Neither town will trust a door held from both sides by someone who changed sides.':p.debt?'The Hearth lent you a coal and has not been repaid. A door cannot be hung on a debt.':base.door;
      CLOSED.keep=p.held==='escaped'?'You broke out of a cell. A table is not laid for someone who has run from one.':base.keep;
    }catch(e){}
    return _fc.apply(this,arguments);
  };
}

/* ---------------- 7. the record of your path ---------------- */
{
  const _je=journalExtra;
  journalExtra=function(sec,line){
    _je(sec,line);
    try{
      const p=P(), out=[];
      if(p.cold) out.push('Mallow turned you away at the tower. You entered the Hearth Vault alone, through the drain.');
      if(p.debt) out.push('The Hearth lent you its coal on terms. It has not forgotten.');
      if(p.held==='vouched') out.push('You were held at the summit. Mallow vouched for you, and it cost him.');
      if(p.held==='confessed') out.push('You were held at the summit. You confessed to all of it, and the clerk wrote it down.');
      if(p.held==='escaped') out.push('You were held at the summit. You broke out. The lines have your description.');
      if(p.held==='released') out.push('You were held at the summit. Nobody came. A warden let you go at dawn.');
      if(p.defected==='red') out.push('At the summit you crossed to the Hollow. The road ahead was theirs.');
      if(p.defected==='crown') out.push('At the summit you crossed to the Crown. The road ahead was theirs.');
      if(p.stayed) out.push('At the summit you were offered the other road, and stayed on your own.');
      if(out.length){ sec('Your Path'); out.forEach(t=>line(t,'jdim')); }
    }catch(e){}
  };
}
})();
