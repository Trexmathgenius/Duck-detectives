'use strict';
/* ===== v1.27: MORE TO DO WITH YOUR WINGS =====
   Until now every odd job was the same timing bar and every shop offered one job. Now:
   - the five odd jobs each have a game of their own (sweeping, watering, balancing on a ladder, polishing, stacking);
   - three new shop jobs (icing, weighing, taking orders) join the old ones;
   - every shop kind offers TWO jobs at the counter and you choose, so the games you know are a choice, not a rut.
   Games follow the minigames.js contract: MG.id={hint,keys,how,hud,init,update,press,draw}. Score is 0 to 10.
   Exposes D10.altJobs and D10.altTitles. */
(function(){
'use strict';
const D10=window.D10=window.D10||{};
const K=()=>keys;
const clampN=mgClamp;
const label=(c,s,x,y,sz,col,al)=>mgT(c,s,x,y,sz||12,col||'#fff',al);

/* ---------- Sweep the Plaza ---------- */
MG.sweep={cap:30,hint:'Sweep every leaf into a pile before time runs out.',keys:'Arrows move the broom',
 how:['Walk the broom over the leaves to sweep them up.','Puddles slow you down.','Clear all of them in 30 seconds for full marks.'],
 hud:s=>'Swept '+s.got+'/'+s.total+'  |  '+Math.max(0,Math.ceil(30-s.time))+'s',
 init(s){
  s.x=60; s.y=150; s.got=0; s.total=16; s.score=0; s.leaves=[]; s.pud=[];
  const cols=['#d9852b','#c0502a','#e0b84a','#8a5a2a'];
  for(let i=0;i<s.total;i++) s.leaves.push({x:50+Math.random()*380,y:70+Math.random()*170,c:cols[i%4],got:0,r:Math.random()*6});
  for(let i=0;i<3;i++) s.pud.push({x:90+Math.random()*300,y:90+Math.random()*130,r:22+Math.random()*10});
 },
 update(s,dt){
  const k=K(); let dx=(k.right?1:0)-(k.left?1:0), dy=(k.down?1:0)-(k.up?1:0);
  if(dx&&dy){ dx*=0.7071; dy*=0.7071; }
  const slow=s.pud.some(p=>Math.hypot(p.x-s.x,p.y-s.y)<p.r);
  const sp=slow?70:150;
  s.x=clampN(s.x+dx*sp*dt,16,464); s.y=clampN(s.y+dy*sp*dt,60,250); s.moving=!!(dx||dy);
  for(const l of s.leaves){ if(!l.got&&Math.hypot(l.x-s.x,l.y-s.y)<20){ l.got=1; s.got++; mgTone(1); } }
  s.score=Math.round(10*s.got/s.total);
  if(s.got>=s.total){ s.done=1; s.score=10; }
 },
 press(){},
 draw(s,c,t){
  mgSky(c,'#b9d6c4','#9ec2a8'); rect(c,0,50,MGW,220,'#c9c2ad');
  for(let x=0;x<MGW;x+=40) for(let y=50;y<MGH;y+=40) if(((x+y)/40)%2===0) rect(c,x,y,40,40,'#d3ccb8');
  for(const p of s.pud){ ell(c,p.x,p.y,p.r,p.r*0.6,'#7fa8c8'); ell(c,p.x-4,p.y-3,p.r*0.6,p.r*0.3,'#a8c8e0'); }
  for(const l of s.leaves) if(!l.got){ c.save(); c.translate(l.x,l.y); c.rotate(l.r); rect(c,-5,-3,10,6,l.c); rect(c,-5,-1,10,1,'rgba(0,0,0,0.25)'); c.restore(); }
  const bob=s.moving?Math.sin(t*20)*2:0;
  mgDuck(c,s.x,s.y+bob,1.1,'#ffd84a');
  rect(c,s.x+10,s.y-6,3,18,'#8a5a2b'); rect(c,s.x+6,s.y+10,12,5,'#c9a24a');
 }
};

/* ---------- Water the Flowerbeds ---------- */
MG.water={cap:30,hint:'Keep every flower watered, but do not drown them.',keys:'Left / Right choose  -  hold Z pour',
 how:['Left and Right move the can between flowers.','Hold Z to pour. A thirsty flower droops; a drowned one wilts.','Keep all six healthy for 30 seconds.'],
 hud:s=>'Health '+Math.round(s.avg*100)+'%  |  '+Math.max(0,Math.ceil(30-s.time))+'s',
 init(s){ s.sel=0; s.avg=1; s.score=10; s.fl=[]; for(let i=0;i<6;i++) s.fl.push({w:0.35+Math.random()*0.45,h:1,d:0.035+Math.random()*0.04}); },
 update(s,dt){
  let tot=0;
  s.fl.forEach((f,i)=>{
   f.w=Math.max(0,f.w-f.d*dt);
   if(K().z&&i===s.sel) f.w=Math.min(1.15,f.w+0.5*dt);
   if(f.w<0.15) f.h-=0.07*dt; else if(f.w>0.95) f.h-=0.13*dt; else f.h=Math.min(1,f.h+0.015*dt);
   f.h=clampN(f.h,0,1); tot+=f.h;
  });
  s.avg=tot/s.fl.length; s.score=Math.round(10*s.avg);
  s.pour=!!K().z;
 },
 press(s,k){ if(k==='left') s.sel=Math.max(0,s.sel-1); else if(k==='right') s.sel=Math.min(5,s.sel+1); },
 draw(s,c,t){
  mgSky(c,'#bfe0f4','#e6f2d8'); rect(c,0,170,MGW,100,'#6b4a2f'); rect(c,0,170,MGW,5,'#4f3820');
  s.fl.forEach((f,i)=>{
   const x=50+i*76, hgt=20+f.h*70, droop=(f.w<0.15||f.h<0.5)?0.5:0;
   rect(c,x-1,170-hgt,3,hgt,'#3f8a3a');
   const col=f.h>0.6?['#f090b8','#f0d070','#9fd0f4','#f4f4ee','#c8a8e0','#ff9d6a'][i]:'#8a7a5a';
   for(let a=0;a<6;a++){ const an=a*1.047+(droop?0.4:0); circ(c,x+Math.cos(an)*7,170-hgt+Math.sin(an)*7+(droop?6:0),5,col); }
   circ(c,x,170-hgt+(droop?6:0),4,'#e0b84a');
   rect(c,x-14,176,28,5,'#241a10'); rect(c,x-14,176,28*clampN(f.w,0,1),5,f.w>0.95?'#7fa8ff':'#5ab0e8');
   if(i===s.sel){ rect(c,x-18,184,36,3,'#ffd166'); }
  });
  const cx=50+s.sel*76;
  rect(c,cx-8,92,30,20,'#6a7a8a'); rect(c,cx+20,98,12,4,'#6a7a8a'); rect(c,cx-14,96,6,10,'#6a7a8a');
  if(s.pour) for(let i=0;i<6;i++) rect(c,cx+30+Math.sin(t*30+i)*2,104+((t*140+i*14)%60),2,6,'#8ac8f4');
  mgDuck(c,cx-28,150,1,'#ffd84a');
 }
};

/* ---------- Hang the Bunting (balance on the ladder) ---------- */
MG.ladder={cap:36,hint:'Stay balanced on the ladder while you string the bunting.',keys:'Left / Right lean',
 how:['The ladder wobbles in the wind.','Lean Left or Right to keep it upright.','Stay steady and the bunting goes up.'],
 hud:s=>'Bunting '+Math.round(s.prog*100)+'%  |  '+Math.max(0,Math.ceil(36-s.time))+'s',
 init(s){ s.tilt=0; s.v=0; s.prog=0; s.score=0; s.flash=0; s.falls=0; },
 update(s,dt){
  const t=s.time, gust=Math.sin(t*1.7)*0.55+Math.sin(t*3.3+1)*0.35+Math.sin(t*0.6)*0.3;
  s.v+=gust*0.9*dt+s.tilt*1.5*dt;
  if(K().left) s.v-=3.1*dt; if(K().right) s.v+=3.1*dt;
  s.v*=Math.pow(0.25,dt); s.tilt+=s.v*dt;
  if(Math.abs(s.tilt)<0.5) s.prog+=dt*0.043*(1-Math.abs(s.tilt)); else s.prog=Math.max(0,s.prog-dt*0.02);
  if(Math.abs(s.tilt)>=1){ s.tilt=0; s.v=0; s.prog=Math.max(0,s.prog-0.08); s.flash=0.5; s.falls++; mgTone(0); }
  s.flash=Math.max(0,s.flash-dt);
  s.prog=clampN(s.prog,0,1); s.score=Math.round(10*s.prog);
  if(s.prog>=1){ s.done=1; s.score=10; }
 },
 press(){},
 draw(s,c,t){
  mgSky(c,'#cfe6f5','#f3e8d0'); rect(c,0,60,MGW,210,'#b8a47e'); rect(c,0,60,MGW,6,'#8a7650');
  for(let x=0;x<MGW;x+=48) rect(c,x,66,2,204,'rgba(0,0,0,0.08)');
  const n=Math.floor(s.prog*14);
  c.strokeStyle='#6b4a2f'; c.lineWidth=2; c.beginPath(); c.moveTo(20,80); c.quadraticCurveTo(240,120,460,80); c.stroke();
  const cols=['#e0452f','#ffd166','#4aa8e0','#6ac060'];
  for(let i=0;i<n;i++){ const u=(i+0.5)/14, x=20+u*440, y=80+Math.sin(u*Math.PI)*20+2; c.fillStyle=cols[i%4]; c.beginPath(); c.moveTo(x-8,y); c.lineTo(x+8,y); c.lineTo(x,y+16); c.fill(); }
  c.save(); c.translate(240,262); c.rotate(s.tilt*0.45+(s.flash>0?Math.sin(t*50)*0.05:0));
  rect(c,-22,-170,4,170,'#8a5a2b'); rect(c,18,-170,4,170,'#8a5a2b');
  for(let y=-150;y<0;y+=26) rect(c,-20,y,40,4,'#a5703a');
  mgDuck(c,0,-150,1.2,'#ffd84a'); rect(c,10,-166,16,3,'#ff9d2e');
  c.restore();
  mgBar(c,150,248,180,8,0.5+s.tilt*0.5,Math.abs(s.tilt)<0.5?'#7fd37a':'#e0452f');
  rect(c,238,244,4,16,'#fff');
 }
};

/* ---------- Polish the Lamps ---------- */
MG.lamps={cap:35,hint:'Polish each lamp until it shines.',keys:'Left / Right rub  -  Z wipe the smudge',
 how:['Alternate Left and Right to rub the lamp.','When a SMUDGE flashes, press Z quickly to wipe it.','Make all four lamps shine.'],
 hud:s=>'Lamp '+Math.min(4,s.i+1)+'/4  |  '+Math.max(0,Math.ceil(35-s.time))+'s',
 init(s){ s.i=0; s.g=[1,1,1,1]; s.last=''; s.gl=2.5+Math.random()*2; s.gw=0; s.msg=''; s.score=0; },
 update(s,dt){
  s.gl-=dt;
  if(s.gl<=0&&s.gw<=0){ s.gw=0.8; s.gl=3+Math.random()*2.5; blip(); }
  if(s.gw>0){ s.gw-=dt; if(s.gw<=0){ s.g[s.i]=Math.min(1,s.g[s.i]+0.12); s.msg='Smudged!'; mgTone(0); } }
  const sum=s.g.reduce((a,b)=>a+(1-b),0); s.score=Math.round(10*sum/4);
  if(s.i>=4){ s.done=1; s.score=10; }
 },
 press(s,k){
  if(s.i>=4) return;
  if(k==='left'||k==='right'){ if(k!==s.last){ s.g[s.i]=Math.max(0,s.g[s.i]-0.075); s.last=k; if(s.g[s.i]<=0.02){ s.g[s.i]=0; s.i++; s.msg=s.i<4?'Next lamp!':''; mgTone(1); } } }
  else if(k==='z'&&s.gw>0){ s.g[s.i]=Math.max(0,s.g[s.i]-0.3); s.gw=0; s.msg='Wiped!'; mgTone(1); if(s.g[s.i]<=0.02){ s.g[s.i]=0; s.i++; } }
 },
 draw(s,c,t){
  mgSky(c,'#27304a','#3a4468'); rect(c,0,214,MGW,56,'#4a4a52'); rect(c,0,214,MGW,4,'#6a6a74');
  for(let i=0;i<4;i++){
   const x=70+i*113, d=s.g[i];
   rect(c,x-3,110,6,104,'#2a2a30'); rect(c,x-12,206,24,8,'#2a2a30');
   circ(c,x,96,36*(1-d)+10,'rgba(255,214,120,'+(0.18*(1-d)).toFixed(2)+')');
   rect(c,x-16,72,32,40,'#e6d8a8'); rect(c,x-16,72,32,40,'rgba(70,60,40,'+(0.78*d).toFixed(2)+')');
   rect(c,x-18,66,36,8,'#3a3a40'); rect(c,x-6,60,12,6,'#3a3a40');
   if(i===s.i&&s.i<4){ rect(c,x-22,64,44,52,'rgba(255,255,255,0.0)'); c.strokeStyle='#ffd166'; c.lineWidth=2; c.strokeRect(x-22,62,44,52); }
   if(i===s.i&&s.gw>0){ circ(c,x+Math.sin(t*20)*3,92,7,'#2a2118'); }
  }
  if(s.gw>0) mgT(c,'SMUDGE! Z!',240,36,18,'#ffd166');
  else if(s.msg) mgT(c,s.msg,240,36,13,'#bcd');
  if(s.i<4){ const x=70+s.i*113+(s.last==='left'?-10:10); mgDuck(c,x,170,0.9,'#ffd84a'); }
 }
};

/* ---------- Stack the Crates ---------- */
MG.crates={cap:50,hint:'Drop each crate squarely on the stack.',keys:'Z drop the crate',
 how:['A crate swings back and forth on the crane.','Press Z to drop it on the stack.','Any overhang is trimmed off. Eight crates, and the stack grows narrower with every miss.'],
 hud:s=>'Stacked '+s.n+'/8',
 init(s){ s.n=0; s.w0=120; s.st=[{x:240,w:120}]; s.sp=150; s.cx=60; s.dir=1; s.cw=120; s.score=0; s.msg=''; s.fallen=[]; },
 update(s,dt){
  s.cx+=s.dir*s.sp*dt; if(s.cx>420){ s.cx=420; s.dir=-1; } if(s.cx<60){ s.cx=60; s.dir=1; }
  for(const f of s.fallen){ f.y+=dt*260; f.r+=dt*2; } s.fallen=s.fallen.filter(f=>f.y<330);
  s.score=Math.round(9*s.n/8);
 },
 press(s,k){
  if(k!=='z') return;
  const top=s.st[s.st.length-1];
  const L=Math.max(top.x-top.w/2,s.cx-s.cw/2), R=Math.min(top.x+top.w/2,s.cx+s.cw/2), ov=R-L;
  if(ov<=4){ s.fallen.push({x:s.cx,w:s.cw,y:60,r:0}); s.done=1; s.msg='Missed!'; s.score=Math.round(9*s.n/8); mgTone(0); return; }
  let nx=(L+R)/2, nw=ov;
  if(Math.abs(s.cx-top.x)<=5){ nx=top.x; nw=top.w; s.msg='Perfect!'; } else s.msg='';
  const cut=s.cw-nw; if(cut>1){ s.fallen.push({x:s.cx<top.x?L-cut/2:R+cut/2,w:cut,y:60,r:0}); }
  s.st.push({x:nx,w:nw}); s.n++; s.cw=nw; s.sp+=14; s.cx=s.dir>0?60:420; mgTone(1);
  if(s.n>=8){ s.done=1; s.score=10; s.msg='Tall and tidy!'; }
 },
 draw(s,c,t){
  mgSky(c,'#cfe4f0','#e8dcc0'); rect(c,0,250,MGW,20,'#6a5a3a');
  const h=22, off=Math.max(0,(s.st.length-6)*h);
  s.st.forEach((b,i)=>{ const y=250-(i+1)*h+off; rect(c,b.x-b.w/2,y,b.w,h-1,'#b07a3a'); rect(c,b.x-b.w/2,y,b.w,3,'#d09a56'); rect(c,b.x-b.w/2,y+h/2-1,b.w,2,'rgba(0,0,0,0.2)'); });
  for(const f of s.fallen){ c.save(); c.translate(f.x,f.y); c.rotate(f.r); rect(c,-f.w/2,-h/2,f.w,h-1,'#b07a3a'); c.restore(); }
  if(!s.done){ rect(c,s.cx-1,0,2,52,'#555'); rect(c,s.cx-s.cw/2,52,s.cw,h-1,'#b07a3a'); rect(c,s.cx-s.cw/2,52,s.cw,3,'#d09a56'); }
  if(s.msg) mgT(c,s.msg,240,24,16,'#6a3a12');
 }
};

/* ---------- Ice the Cakes (bakery) ---------- */
MG.ice={cap:45,hint:'Drop the icing exactly when each cake is under the nozzle.',keys:'Z drop icing',
 how:['Cakes ride along the belt.','Press Z when a cake is right under the nozzle.','Eight cakes, and the belt speeds up.'],
 hud:s=>'Cake '+Math.min(8,s.i+1)+'/8',
 init(s){ s.i=0; s.pts=0; s.x=-30; s.sp=120; s.ph='run'; s.w=0; s.iced=0; s.msg=''; s.score=0; },
 update(s,dt){
  if(s.ph==='run'){ s.x+=s.sp*dt; if(s.x>MGW+40){ s.msg='Missed!'; mgTone(0); this.next(s); } }
  else { s.w-=dt; if(s.w<=0) this.next(s); }
  s.score=Math.round(10*s.pts/16);
 },
 next(s){ s.i++; if(s.i>=8){ s.done=1; s.score=Math.round(10*s.pts/16); return; } s.x=-30; s.sp=120+s.i*18; s.ph='run'; s.iced=0; },
 press(s,k){
  if(k!=='z'||s.ph!=='run') return;
  const e=Math.abs(s.x-240), r=e<10?2:e<26?1:0; s.pts+=r; s.iced=r+1; s.off=s.x-240; s.msg=['Splat!','Nearly!','Perfect!'][r]; mgTone(r); s.ph='res'; s.w=0.6;
 },
 draw(s,c,t){
  mgSky(c,'#f6e4cc','#e8c9a2'); rect(c,0,196,MGW,16,'#4a4a52'); for(let x=-((t*s.sp)%24);x<MGW;x+=24) rect(c,x,198,12,2,'#6a6a74');
  rect(c,226,40,28,40,'#8a8a96'); rect(c,236,80,8,34,'#b8b8c4'); rect(c,232,108,16,8,'#f4f4ee');
  const x=s.x; rect(c,x-26,168,52,28,'#d9a066'); rect(c,x-26,168,52,6,'#8a5a2a');
  if(s.iced){ const o=s.ph==='res'?s.off:0; ell(c,x+(s.ph==='res'?0:0),166,22,7,s.iced===3?'#ffd1e8':s.iced===2?'#ffb8d8':'#f4c6e0'); circ(c,x+(o*0)+0,158,4,'#e0452f'); }
  if(s.ph==='res'){ const o=s.off; rect(c,240-1,116,2,s.iced>0?44:44,'rgba(255,255,255,0.8)'); }
  if(s.msg) mgT(c,s.msg,240,24,16,'#6a3a12');
  for(let i=0;i<8;i++) circ(c,150+i*26,240,5,i<s.i?'#6ac060':'#c8b090');
 }
};

/* ---------- Weigh the Produce (market) ---------- */
MG.weigh={cap:60,hint:'Add weights to the scale until it matches the sack.',keys:'Left / Right choose  -  Z add  -  Up undo  -  Down done',
 how:['The sack has a weight. Choose weights and press Z to add them.','Up takes the last one off. Down says you are done.','Five sacks. Exact is best.'],
 hud:s=>'Sack '+Math.min(5,s.r+1)+'/5',
 init(s){ s.r=0; s.pts=0; s.opts=[1,2,3,5,8]; s.sel=0; s.on=[]; s.target=this.roll(); s.msg=''; s.res=0; s.score=0; },
 roll(){ return 7+Math.floor(Math.random()*12); },
 total(s){ return s.on.reduce((a,b)=>a+b,0); },
 update(s,dt){ if(s.res>0){ s.res-=dt; if(s.res<=0){ s.r++; if(s.r>=5){ s.done=1; s.score=Math.min(10,s.pts); } else { s.on=[]; s.target=this.roll(); s.msg=''; } } } s.score=Math.min(10,s.pts); },
 press(s,k){
  if(s.res>0) return;
  if(k==='left') s.sel=Math.max(0,s.sel-1); else if(k==='right') s.sel=Math.min(4,s.sel+1);
  else if(k==='z'){ if(s.on.length<8) s.on.push(s.opts[s.sel]); blip(); }
  else if(k==='up') s.on.pop();
  else if(k==='down'){ const d=Math.abs(this.total(s)-s.target), r=d===0?2:d===1?1:0; s.pts+=r; s.msg=['Wrong!','Close enough!','Exact!'][r]; mgTone(r); s.res=0.9; }
 },
 draw(s,c,t){
  mgSky(c,'#f2e6c8','#e0cfa4'); rect(c,0,210,MGW,60,'#a5855a');
  rect(c,150,60,6,150,'#555'); rect(c,100,200,106,10,'#555'); rect(c,40,70,220,4,'#555');
  rect(c,40,70,2,30,'#555'); rect(c,258,70,2,30,'#555');
  const tot=this.total(s), diff=clampN((tot-s.target)*3,-14,14);
  ell(c,40,104+diff,34,6,'#c9a24a'); ell(c,258,104-diff,34,6,'#c9a24a');
  ell(c,40,132-0,14,12,'#8a5a2a'); c.fillStyle='#e8d9b5'; circ(c,40,96+diff,10,'#c98a3c'); mgT(c,'sack',40,84+diff,10,'#fff');
  mgT(c,'Sack weighs '+s.target,380,60,16,'#4a3418');
  mgT(c,'On the scale: '+tot,380,86,14,tot===s.target?'#2a7a2a':'#4a3418');
  s.on.forEach((w,i)=>{ rect(c,258-12+((i%4)-1.5)*16-6,98-diff-Math.floor(i/4)*10-8,12,8,'#555'); mgT(c,String(w),258+((i%4)-1.5)*16-12+6,98-diff-Math.floor(i/4)*10-4,9,'#fff'); });
  s.opts.forEach((w,i)=>{ const x=80+i*64; rect(c,x-16,224,32,28,i===s.sel?'#ffd166':'#7a7a86'); rect(c,x-16,224,32,4,'rgba(255,255,255,0.3)'); mgT(c,String(w),x,240,16,i===s.sel?'#3a2a08':'#fff'); });
  if(s.msg) mgT(c,s.msg,380,120,18,'#6a3a12');
 }
};

/* ---------- Take the Orders (cafe) ---------- */
MG.orders={cap:70,hint:'Watch the orders, then repeat them in the same order.',keys:'Arrows repeat the order',
 how:['Watch the order slip: up, down, left and right are four different treats.','Then press the arrows in the same order.','Five tables. Each order is longer than the last.'],
 hud:s=>'Table '+Math.min(5,s.r+1)+'/5',
 init(s){ s.r=0; s.pts=0; s.score=0; this.start(s); },
 start(s){ s.seq=[]; const L=2+s.r; for(let i=0;i<L;i++) s.seq.push(['up','right','down','left'][Math.floor(Math.random()*4)]); s.ph='show'; s.i=0; s.t=0.6; s.inp=0; s.msg=''; s.lit=''; },
 update(s,dt){
  s.t-=dt;
  if(s.ph==='show'){ if(s.t<=0){ if(s.i<s.seq.length){ s.lit=s.seq[s.i]; s.i++; s.t=0.55; blip(); } else { s.ph='in'; s.lit=''; s.inp=0; } } else if(s.t<0.18) s.lit=''; }
  else if(s.ph==='res'){ if(s.t<=0){ s.r++; if(s.r>=5){ s.done=1; s.score=Math.min(10,s.pts); } else this.start(s); } }
  s.score=Math.min(10,s.pts);
 },
 press(s,k){
  if(s.ph!=='in') return;
  if(!['up','down','left','right'].includes(k)) return;
  s.lit=k; setTimeout(()=>{ if(mgs&&mgs.s===s) s.lit=''; },180);
  if(k===s.seq[s.inp]){ s.inp++; blip(); if(s.inp>=s.seq.length){ s.pts+=2; s.msg='Perfect order!'; mgTone(1); s.ph='res'; s.t=0.8; } }
  else { s.msg='Wrong order!'; mgTone(0); s.ph='res'; s.t=0.9; }
 },
 draw(s,c,t){
  mgSky(c,'#f4dcc0','#e6c49c'); rect(c,0,200,MGW,70,'#8a5a3a'); rect(c,0,200,MGW,6,'#6b4423');
  const spots={up:[240,70],right:[350,130],down:[240,190],left:[130,130]}, names={up:'tea',right:'cake',down:'cookie',left:'jug'}, cols={up:'#7ab8d8',right:'#f4a8c8',down:'#d9a066',left:'#c8d878'};
  for(const k in spots){ const [x,y]=spots[k], on=s.lit===k; circ(c,x,y,on?34:28,on?'#fff6c8':'rgba(0,0,0,0.12)'); circ(c,x,y,22,cols[k]); mgT(c,names[k],x,y+40,11,'#4a3418'); mgT(c,{up:'▲',down:'▼',left:'◀',right:'▶'}[k],x,y,16,'#fff'); }
  mgDuck(c,240,150,1.1,'#f4f4ee');
  mgT(c,s.ph==='show'?'Watch the order...':s.ph==='in'?'Your turn: '+s.inp+'/'+s.seq.length:s.msg,240,24,14,'#4a3418');
 }
};

/* ---------- wire them to jobs ---------- */
Object.assign(MG_BY_TITLE,{
  'Sweep the Plaza':'sweep','Water the Flowerbeds':'water','Hang the Bunting':'ladder','Polish the Lamps':'lamps','Stack the Crates':'crates',
  'Ice the Cakes':'ice','Weigh the Produce':'weigh','Take the Orders':'orders',
  'Splice the Rope':'flies','Match the Curios':'specimen','Brew the Tea Blends':'tonic','Copy the Manuscripts':'ink','Weave the Ribbons':'loom','Paint the Toys':'dip'
});
const ALT={
  bakery:['Ice the Cakes','Press Z when each cake is under the nozzle.'],
  market:['Weigh the Produce','Add weights until the scale matches the sack.'],
  cafe:['Take the Orders','Watch the orders, then repeat them.'],
  supply:['Splice the Rope','Copy the splice: repeat the arrow pattern.'],
  curio:['Match the Curios','Find the matching pairs.'],
  florist:['Brew the Tea Blends','Add the herbs in the order on the recipe.'],
  books:['Copy the Manuscripts','Steer the pen along the line with Up and Down.'],
  tailor:['Weave the Ribbons','Pull the thread when the marker is in the zone.'],
  toys:['Paint the Toys','Dip and lift at just the right moment.']
};
D10.altJobs=ALT; D10.altTitles=new Set(Object.values(ALT).map(a=>a[0]));
const BASE={}; for(const k in ALT) BASE[k]=JOBS[k];
{
  const _aw=askWork;
  askWork=function(b,t){
    const alt=ALT[b.kind];
    if(!alt||!BASE[b.kind]) return _aw(b,t);
    const left=SHIFTS_PER_DAY-workCount(wkey(b)), close=HOURS[b.kind][1];
    if(left<=0||close-g.clock<1.6){ JOBS[b.kind]=BASE[b.kind]; return _aw(b,t); }
    choose(b.keeper.name,'I have two jobs that need doing. Which would you rather?',[BASE[b.kind][0],alt[0],'Never mind'],k=>{
      if(k===2) return;
      JOBS[b.kind]=k===0?BASE[b.kind]:alt;
      _aw(b,t);
    },2);
  };
}
})();
