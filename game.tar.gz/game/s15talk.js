'use strict';
/* ===== SIDE QUESTS: THE ONES YOU SIT DOWN AND TALK THROUGH =====
   Each is a few beats. A beat is some lines, then a question with things you can say. What you say is remembered by the
   same ledger as everything else (truth, lie, mercy, pride, trust, kin; hearth/crown/mallow/sleepers), and then the
   original answer is applied at the end exactly as before.
   '@' is whoever asked. '' is narration. fx: {led:{...},cap:{...},habit:'...'}.
   See s15quest.js for the engine. */
(function(){
const SQ=window.SQ; if(!SQ) return;
const B=(l,q,o)=>({l,q,o});

/* ---------- Nell's eldest learns to cast (2 h) ---------- */
SQ.def('bree.taught',{kind:'talk',hours:2,
 open:['"Pond\'s a short walk. Tully, bring the string. And the other string."'],
 beats:[
  B([['',['At the pond, Tully holds the rod like a snake she has been asked to be polite to.']],['@',['"Pike said you hold it still. Then he said you hold it loose. He also said you talk to it. I am not sure he had caught anything for years."']]],
    'How do you start her off?',
    [['Show her the grip, and let her feel the weight.',[['',['You put her wing under yours and let the rod do the explaining. She goes quiet, the way people do when something starts to make sense.']]],{led:{trust:1},habit:'steady'}],
     ['Tell her about patience: the fish decide, not you.',[['@',['"What if they decide no?" You tell her that is also an answer, and a good one to learn young.']]],{led:{truth:1},habit:'candid'}],
     ['Let her fumble it first. People remember what they fix themselves.',[['',['She casts the hook into a bush, then her own hat. The second hat is Nell\'s, who is not pleased, and does not stop watching.']]],{led:{pride:1},habit:'proud'}]]),
  B([['',['An hour in, the line bends hard. Tully hauls with her whole body, shrieking.']],['',['It is a boot. A fine boot, left foot, with a small crab in it.']],['@',['Tully looks at you with real despair. "Is that a fish?"']]],
    'What do you say?',
    [['"It is a start. The boot is a kind of fish."',[['@',['"It is NOT." But she is laughing, and the crab is already named.']]],{led:{mercy:1},habit:'gentle'}],
     ['"No. But you did everything right to catch it, and that matters."',[['@',['She turns this over for a long moment. "Then I can do it again."']]],{led:{truth:1,trust:1},habit:'candid'}],
     ['Say nothing, take the boot, and bait her hook again.',[['',['She watches you hang the boot on a branch, as if it were a trophy. She recasts without a word.']]],{led:{kin:1},habit:'tender'}]]),
  B([['',['The sun is leaning westward. Tully has caught a reed, a bootlace, and, at the very end, a perch the length of her wing. She is too astonished to shout.']],['@',['"Mam will not believe me. She will think I bought it. Should I tell her I did not?"']]],
    'What do you tell her?',
    [['"Give it to her whole, and tell her how it went."',[['@',['"The whole way? Even the boot?" "Especially the boot."']]],{led:{truth:1,kin:1},habit:'candid'}],
     ['"Say you got it with your own wing, and be proud."',[['@',['She stands very straight. Over her shoulder, the crab is a long way from home and entirely at peace.']]],{led:{pride:1,trust:1},habit:'proud'}],
     ['"Keep the first one for yourself. You earned it."',[['@',['"Not Mam?" "Mam gets the next one."']]],{led:{kin:1},habit:'tender'}]])
 ]});

/* ---------- Tamsin: sit with her (1 h) ---------- */
SQ.def('tamsin.sat',{kind:'talk',hours:1,
 open:['"It is a kind thing to say it is gone. Nobody else will."'],
 beats:[
  B([['',['You sit on the wall beside her. For a while neither of you says anything.']],['@',['"He had very large hands. I used to think they would not fit through a ring, any ring. And then there was a ring."']]],
    'What do you ask?',
    [['"What was he like, on the day?"',[['@',['"Nervous. He wore his good coat inside out. I did not tell him until the third hour."']]],{led:{kin:1},habit:'tender'}],
     ['"What would you say to him, if you found it?"',[['@',['A long pause. "That I am sorry I took it off to knead bread. That it was only bread."']]],{led:{mercy:1},habit:'gentle'}],
     ['"Did he ever say he minded about the ring?"',[['@',['"No. That is what I cannot forgive. He said it was waiting."']]],{led:{truth:1},habit:'candid'}]]),
  B([['@',['She turns the empty box over. "They tell me a ring is a small thing. I am not sure that anyone who says so has ever had one."']]],
    'And now?',
    [['Tell her gently that the ring may not matter as much as she thinks.',[['@',['"No," she says. "It does not. I knew that. I wanted someone else to say it first."']]],{led:{truth:1,mercy:1},habit:'candid'}],
     ['Tell her you will remember Alder, if she tells you.',[['@',['She tells you, with her eyes shut. You hold it all in your head like water in a wing.']]],{led:{kin:1,trust:1},habit:'tender'}],
     ['Sit with her without saying anything else.',[['',['The light moves across the field. By the end of the hour you could have drawn his hands.']]],{led:{mercy:1},habit:'steady'}]])
 ]});

/* ---------- Cook Bram's dying woman (2 h) ---------- */
SQ.def('bram.sat',{kind:'talk',hours:2,
 open:['"She is in the back tent. Please do not tell her about the trout. She has been very clear about the trout."'],
 beats:[
  B([['',['The back tent smells of broth and lavender. The old woman on the cot is very small. She opens one eye and shuts it again.']],['@',['"Sergeant\'s mother," Bram whispers, from the door. "Name\'s Orrel."']]],
    'How do you begin?',
    [['"I hear you wanted a trout."',[['',['"I did. Is it a good one?" You say you are afraid it is not here yet. She nods, as if she expected that, and is not hurt.']]],{led:{truth:1},habit:'candid'}],
     ['"Tell me about the river you grew up on."',[['',['"It was not a river. It was a ditch. But the trout in it were my father\'s." And she begins, a little slowly, and then not slowly at all.']]],{led:{kin:1},habit:'tender'}],
     ['Just sit, and take her wing.',[['',['Her wing is paper. She squeezes yours, once, as if checking you are real.']]],{led:{mercy:1},habit:'gentle'}]]),
  B([['',['She is a long time between sentences now. Her husband, she says, put a bay leaf in the butter, and never once said what it was for.']]],
    'She asks if she is going to be afraid. What do you tell her?',
    [['"I do not think so. I think it will be like the end of a long day."',[['',['"That is a nice thing to say, even if you made it up." "I did not make it up." "Then I will believe you."']]],{led:{mercy:1,lie:1},habit:'gentle'}],
     ['"I do not know. Nobody who knows has told me."',[['',['She almost laughs. "Honest. Good. I have had enough of the other kind."']]],{led:{truth:1},habit:'candid'}],
     ['"Whatever it is, you will not be on your own."',[['',['"No," she says. "Tuck the blanket in, would you? The left side."']]],{led:{kin:1,trust:1},habit:'tender'}]]),
  B([['',['An hour more. Her breath goes slow and even. At the door, Bram is pretending to stir an empty pot.']],['@',['"Does she need anything?"']]],
    'What do you say to Bram?',
    [['"Only the broth. She does not need the trout. She needed the telling."',[['@',['Bram sits down hard on a crate. "I have been cooking at the wrong thing all week."']]],{led:{truth:1,kin:1},habit:'candid'}],
     ['"Make the trout anyway. Cook it as her husband did. She will smell it."',[['@',['"There is no trout." "Make the smell." Bram nods, slowly, and goes.']]],{led:{mercy:1},habit:'tender'}]])
 ]});

/* ---------- Brock's table of names (2 h) ---------- */
SQ.def('brock.told',{kind:'talk',hours:2,
 open:['"Sit anywhere. They will sit near you. They will not say why."'],
 beats:[
  B([['',['Eleven children, of various sizes, look at you with the grave, interested hostility of the very young.']],['@',['The eldest, a girl with chalk on her cuffs, says: "Is it true they are asleep because of something that happened?"']]],
    'How much do you tell them?',
    [['The truth, in plain words.',[['',['You tell it as it was, without dressing it. A small boy puts his hands over his ears, then takes them off again.']]],{led:{truth:1},habit:'candid'}],
     ['A gentler version, with some of the sharp edges off.',[['',['You say they are sleeping, and being looked after, and that this is true. It is true. It is not the whole of it.']]],{led:{mercy:1},habit:'gentle'}],
     ['Ask them what they have been told, first.',[['',['A long, strange list. One of them has been told the sleepers are trees. Another that they are ghosts that have lost their way.']]],{led:{trust:1},habit:'steady'}]]),
  B([['@',['The eldest again, very carefully: "Will they know us? When they wake?"']]],
    'What do you say?',
    [['"I do not know. But the chalk on your cuffs says you will be remembered."',[['',['She looks at her sleeve, and, slowly, closes her fist round it.']]],{led:{truth:1,kin:1},habit:'candid'}],
     ['"Yes. Of course they will."',[['',['The smallest sighs with her whole body. The eldest looks at you for a moment too long, and does not argue.']]],{led:{lie:1,mercy:1},habit:'gentle'}],
     ['"Tell me what you would want them to know, and I will carry it."',[['',['They all start at once. You get most of it. It involves, mainly, a dog, and the correct way to hold a spoon.']]],{led:{kin:1,trust:1},habit:'tender'}]]),
  B([['',['The light has gone yellow. The smallest is on your lap, asleep, and no one has told you when that happened.']],['@',['"You\'ll want to be off," says Brock. "No rush."']]],
    'Before you go:',
    [['Promise to come back, and mean it.',[['',['Brock makes a mark on the wall with chalk. "I keep a count," he says. "I will see."']]],{led:{trust:1,kin:1},habit:'steady'}],
     ['Slip out quietly, leaving the smallest asleep.',[['',['You hand the child over like a tray. She does not wake. Several pairs of eyes follow you to the door.']]],{led:{mercy:1},habit:'gentle'}]])
 ]});

/* ---------- Ivy's night watch (4 h) ---------- */
SQ.def('ivy.watched',{kind:'talk',hours:4,night:true,
 open:['"There is a stool at the end. The worst of them is the third cot. I will be at the other end, trying to look like I am asleep."'],
 beats:[
  B([['',['The ward is long and dim. A hundred cots, and one candle. Someone mutters a name, over and over. It is not clear that it is a name.']],['',['The third cot shakes. A pale old duck, eyes tight shut, is saying something that sounds like a count.']]],
    'How do you sit with the one who shakes?',
    [['Take their wing and say nothing.',[['',['The wing is cold. It does not settle. But the count slows, a little.']]],{led:{mercy:1},habit:'gentle'}],
     ['Hum low, whatever comes.',[['',['You are not sure where the tune comes from. It seems to be one of Tamsin\'s. The count stumbles, and loses its place.']]],{led:{kin:1},habit:'tender'}],
     ['Speak to them, steadily, about where they are.',[['',['"It is night. You are in a hall. You are safe." You say it for what feels like an hour. The count stops, and starts again.']]],{led:{truth:1,trust:1},habit:'steady'}]]),
  B([['',['Past midnight. The mutterers have grown quieter. In the third cot, a name comes clear for the first time: "Hedda."']],['@',['Ivy appears silently at your elbow. "That is her daughter," she whispers. "She died in the first winter. I did not know she remembered."']]],
    'What do you do with this?',
    [['"Hedda is here. She is fine."',[['',['The old wing finds yours, and holds it. You are not sure it is true. You are sure it is the right thing to say.']]],{led:{lie:1,mercy:1},habit:'gentle'}],
     ['"I do not know where Hedda is. But somebody is here."',[['',['A long, ragged breath. The wing does not let go.']]],{led:{truth:1,kin:1},habit:'candid'}],
     ['Say nothing. Let the name be a name.',[['',['The ward holds it, the way a hall holds an echo. Ivy, behind you, sits down slowly on the floor.']]],{led:{trust:1},habit:'steady'}]]),
  B([['',['The small hours. A draught under the door. Ivy has fallen asleep sitting up, which she would deny if she were awake.']],['',['The third cot has stopped shaking. Beside it a dreamer in the fourth stirs, and says, quite clearly, "Is it morning yet?"']]],
    'What do you say?',
    [['"Not yet. Go back to sleep."',[['',['She does. She sleeps like a person who was only waiting to be told.']]],{led:{mercy:1},habit:'gentle'}],
     ['"Nearly. Hold on a little longer."',[['',['She smiles with her eyes shut. The candle gutters and holds.']]],{led:{kin:1,trust:1},habit:'tender'}]])
 ]});

/* ---------- Bryony's hives (4 h) ---------- */
SQ.def('mim.vigil',{kind:'talk',hours:4,night:true,
 open:['"Sit down here. Do not talk to the hives. They do not like being talked to. Talk to me."'],
 beats:[
  B([['',['The hives sit in a row, silent, pale under the moon. Bryony puts her ear to one and holds it there.']],['@',['"This one is Margery. She is the oldest. She was queen when my husband still had his teeth."']]],
    'What do you ask?',
    [['"What was it like, the first time they went quiet?"',[['@',['"I was twenty. I thought I had killed them. I had not. It was only the cold. It is a mercy to be wrong."']]],{led:{kin:1},habit:'tender'}],
     ['"Do you think it is the other kind of quiet?"',[['@',['A very long pause. "Yes," she says. "I have been telling myself otherwise since Tuesday."']]],{led:{truth:1},habit:'candid'}],
     ['"Tell me their names."',[['@',['She does: Margery, Doll, Old Nan, the Duchess, the one she calls Trouble. It takes longer than you expect, and you are glad of it.']]],{led:{trust:1},habit:'steady'}]]),
  B([['',['The deep of the night. Somewhere past the orchard a night-bird calls and stops. Bryony has not blinked in a very long time.']],['@',['"If they go, they go. It is only bees. I have no right to feel this."']]],
    'What do you say?',
    [['"It is not only bees."',[['@',['She nods once, shortly, and her shoulders come down.']]],{led:{mercy:1,kin:1},habit:'gentle'}],
     ['"If they go, what will you do with the hives?"',[['@',['"Keep them. Keep them clean. In case." You say that sounds like hope. "It is stubbornness," she says. "It is much the same."']]],{led:{truth:1},habit:'candid'}],
     ['Sit, and let her be as sad as she wants to be.',[['',['The stars wheel. She cries a little, neatly, as she does everything.']]],{led:{mercy:1},habit:'steady'}]]),
  B([['',['Before dawn. The air smells of wet leaves. The hive nearest to you gives a long, slow hum, a single note, as if clearing its throat.']],['@',['Bryony grips your wing. "Did you hear that?"']]],
    'What do you tell her?',
    [['"I heard it. Margery."',[['@',['"Margery," she whispers, and laughs, once, like a hiccup.']]],{led:{trust:1,kin:1},habit:'tender'}],
     ['"I heard something. It may be the wind."',[['@',['"It may. It may. Do not say it again." She is smiling like a girl.']]],{led:{truth:1},habit:'candid'}]])
 ]});

/* ---------- Tessel and the sleeping woman (2 h) ---------- */
SQ.def('tessel.sat',{kind:'talk',hours:2,
 open:['"Please sit. I have never had anyone to tell her about me."'],
 beats:[
  B([['',['The old woman on the cot is perfectly still. A faint breath. Her hands are folded exactly as they were placed.']],['@',['"Her name is Orsolya. Granny says she sang while she did the washing. I do not know the song."']]],
    'How do you start?',
    [['Introduce Tessel to her, by name, as if she were awake.',[['',['You say it plainly: "This is your great-granddaughter, Tessel. She came a long way." The breath on the cot does not change. Tessel\'s does.']]],{led:{kin:1},habit:'tender'}],
     ['Ask Tessel what she wants Orsolya to know first.',[['@',['A long pause. "That I kept her recipe book. That I did not burn it, even in the cold winter."']]],{led:{trust:1},habit:'steady'}],
     ['Tell the old woman about what she has missed.',[['',['You tell it all: the road, the bell, the ward. You are surprised how much there is.']]],{led:{truth:1},habit:'candid'}]]),
  B([['',['Tessel finds a folded cloth under the cot. It is a baby\'s cap, yellowed, with initials in the hem. Hers.']],['@',['"Her great-granddaughter," she says, slowly. "They made it before I was born."']]],
    'What do you say?',
    [['"She knew you before you were born."',[['@',['Tessel presses the cap to her mouth. She says nothing for a long time.']]],{led:{kin:1,mercy:1},habit:'tender'}],
     ['"She may not wake as she remembers. You should be ready for that."',[['@',['"I know." She breathes. "I know. Say it again, so I am sure I heard."']]],{led:{truth:1},habit:'candid'}],
     ['Put the cap on the pillow, near the old woman\'s hand.',[['',['The fingers do not move. But it feels, somehow, like an answer.']]],{led:{trust:1},habit:'steady'}]]),
  B([['',['The candle burns down a finger. Tessel leans over the cot.']],['@',['"Orsolya," she says, very clearly. "It is Tessel. I have your recipe book."']]],
    'Do you say anything?',
    [['Say her name, too, once, as a witness.',[['',['"Tessel," you say, "who kept the book." The cot creaks, as if something turned toward the sound.']]],{led:{kin:1},habit:'tender'}],
     ['Let her say it alone.',[['',['You sit very still. It is a private thing, and you leave it private.']]],{led:{mercy:1},habit:'gentle'}]])
 ]});

/* ---------- Moth on the last night ---------- */
SQ.def('moth.stayed',{kind:'talk',hours:4,night:true,
 open:['"You can have the other bucket. It is wetter. I am sorry."'],
 beats:[
  B([['',['The road runs away into dark. Behind you the camp is a handful of low fires. Moth grips the horn.']],['@',['"What if it is the Crown, and I blow it, and then it is NOT the Crown? Or it is, and nobody comes?"']]],
    'What do you tell him?',
    [['"Then you blow it anyway. That is what a horn is for."',[['@',['He thinks about it. "That is a very simple thing to be told." "It is the only thing."']]],{led:{trust:1},habit:'steady'}],
     ['"It is all right to be afraid. Everyone out here is, tonight."',[['@',['"Even you?" "Especially me." He lets out a breath he has been holding since sundown.']]],{led:{kin:1,truth:1},habit:'candid'}],
     ['"Nobody is coming. Not tonight."',[['@',['"You cannot know that." "No. But it is a good guess, and I would rather you rested."']]],{led:{lie:1,mercy:1},habit:'gentle'}]]),
  B([['',['Middle of the night. A fox crosses the road, stares at you both, and is entirely unimpressed.']],['@',['Moth is whispering now. "My brother is in the Royal Guard. If it is him, coming up this road, what do I do?"']]],
    'What do you say?',
    [['"You blow the horn. And you tell him you did. And you tell him why."',[['@',['"That is a hard thing." "It is."']]],{led:{truth:1,pride:1},habit:'candid'}],
     ['"You do not have to decide tonight. Tonight you only have to watch."',[['@',['He nods slowly, relieved to be allowed.']]],{led:{mercy:1},habit:'gentle'}],
     ['"Tell me about him."',[['@',['He does: a wooden sword, a kite, a bad habit of singing in the privy. By the end, the dark is a little less large.']]],{led:{kin:1,trust:1},habit:'tender'}]]),
  B([['',['The dark is paling at the edges. The horn has been in his lap for an hour.']],['@',['"I think I could do it. If it came to it."']]],
    'And you:',
    [['"I know you could."',[['@',['It sits on him like a clean cloak.']]],{led:{trust:1},habit:'steady'}],
     ['"I hope it never comes to it."',[['@',['"Me too." He leans on your shoulder. It is the first time he has stopped holding himself up.']]],{led:{kin:1,mercy:1},habit:'tender'}]])
 ]});

SQ.def('moth.took',{kind:'talk',hours:2,night:true,
 open:['"You are sure? It is heavier than it looks. Everything is."'],
 beats:[
  B([['',['He hands you the horn. He does not let go at first, and then he does, and the horn tips your wing down.']],['@',['"Right. Now what do I do?" "You sleep." "That is impossible."']]],
    'How do you help him rest?',
    [['Tell him a story, however dull.',[['',['You tell him one about a goose who became mayor. Halfway through the second paragraph, his head tilts.']]],{led:{kin:1},habit:'tender'}],
     ['Tell him exactly what you will do if the Crown comes.',[['',['You walk him through it: horn, wake the camp, stand your ground. He repeats it under his breath. It is nearly a lullaby.']]],{led:{trust:1,pride:1},habit:'steady'}],
     ['Just tell him it is all right to stop.',[['',['"Stop what?" "Everything. For a little."']]],{led:{mercy:1},habit:'gentle'}]]),
  B([['',['The road is quiet. The boy is asleep against the bucket with his helmet over one eye.']],['',['You turn the horn over. It is old, brass, and has someone\'s initials scratched into the mouthpiece: M.']]],
    'What do you do while he sleeps?',
    [['Watch the road, and do it properly.',[['',['Nothing comes. You keep watch anyway. It is oddly restful.']]],{led:{trust:1},habit:'steady'}],
     ['Wake him at the end and say he did well.',[['',['"I did not do anything." "That is exactly what a watch is."']]],{led:{kin:1,truth:1},habit:'candid'}]])
 ]});

/* ---------- Tully ate (1 h) ---------- */
SQ.def('tully.ate',{kind:'talk',hours:1,
 open:[],
 beats:[
  B([['',['Nell\'s fire is small and well-tended. The fish sits in the middle of the pan, looking sorry for itself.']],['@',['"I cleaned it myself," says Tully. "I got most of the scales. Some of them are in the fire."']]],
    'How do you eat it?',
    [['Make a fuss over it, as if it were a feast.',[['',['Tully glows. Nell, behind the net, hides a smile she does not want to be caught having.']]],{led:{kin:1},habit:'tender'}],
     ['Tell her honestly it is a bit burnt.',[['@',['"I KNOW." She doubles over laughing. "Mam says it is a learning fish."']]],{led:{truth:1},habit:'candid'}],
     ['Ask how she caught it.',[['',['It takes ten minutes, three stories, and an unfortunate frog. You are glad you asked.']]],{led:{trust:1},habit:'steady'}]]),
  B([['@',['Nell, quietly, over the fire: "Is she good? At it? Be honest. I can take it."']]],
    'What do you say?',
    [['"She will be. She has the right kind of stubborn."',[['@',['Nell looks at her daughter for a moment longer than needed. "Yes," she says. "She does."']]],{led:{truth:1,kin:1},habit:'candid'}],
     ['"She is very good. She is going to be better than you."',[['@',['"Good," says Nell, a bit thickly. "That is what I wanted."']]],{led:{mercy:1},habit:'gentle'}]])
 ]});

/* ---------- The soldier from the cot: ask (1 h) ---------- */
SQ.def('fennel2.ask',{kind:'talk',hours:1,
 open:['"If you are going to ask a hard question, please sit. I have only just learned how."'],
 beats:[
  B([['',['You sit on the post-side, in the shade. He is quieter than the others in the camp. He talks to the ground.']],['@',['"I was in the line at the south road. I do not remember anything of the last week."']]],
    'You ask what he was fighting for:',
    [['"What did they tell you, when you signed up?"',[['@',['"That the Hollow was a nest of smugglers. That if we did not stop them they would burn the barley. I believed it. It was quite a clear story."']]],{led:{truth:1},habit:'candid'}],
     ['"What did you want, before all of it?"',[['@',['"To be a miller. I have a small mill in my head, a good one. It has a wheel that turns the right way."']]],{led:{kin:1},habit:'tender'}],
     ['"Do you think you would do it again?"',[['@',['A long silence. "I do not know. That is the first honest thing I have said all week."']]],{led:{trust:1},habit:'steady'}]]),
  B([['@',['"It is a strange thing to wake up and find you were wrong. Not about the war. About what you thought you were."']]],
    'What do you say?',
    [['"You were doing what you were told. That is not nothing, and not everything."',[['@',['He weighs it. "Yes. That sounds right, and it hurts a little."']]],{led:{truth:1,mercy:1},habit:'candid'}],
     ['"The camp would like to have a miller."',[['@',['"They would?" He looks, for the first time, hopeful and slightly ill. "I would have to learn to mill."']]],{led:{kin:1},habit:'tender'}],
     ['"What you do next is what counts."',[['@',['"Yes. That. I think I can do that."']]],{led:{trust:1,pride:1},habit:'steady'}]])
 ]});

/* ---------- Madder at the grave (2 h) ---------- */
SQ.def('fennel2h.stay',{kind:'talk',hours:2,
 open:['"Thank you for coming. I did not think I would ask, and then I did."'],
 beats:[
  B([['',['The mound is small and neat. A sprig of feverfew rests on it, and two stones, one for each of his boots.']],['@',['"I did not know his name when he came to me. He told me, on the second night. Pell. Corporal Pell."']]],
    'What do you ask?',
    [['"What was he like, when he was awake?"',[['@',['"Polite. He apologised for coughing. He apologised for the bed. I told him it was not his."']]],{led:{kin:1},habit:'tender'}],
     ['"Do you wish you had told him the odds?"',[['@',['"No. He knew. He had the look. It was kinder to say it than to pretend."']]],{led:{truth:1},habit:'candid'}],
     ['"Was anyone with him, at the end?"',[['@',['"I was. He did not say anything. He held my wing. It was warm for a long time, and then it was just a wing."']]],{led:{mercy:1},habit:'gentle'}]]),
  B([['',['Madder weeds a patch the size of a hat. Her hands are quicker than her face.']],['@',['"I have buried a good many. I thought it would get easier. It gets quicker. That is a different thing."']]],
    'What do you say?',
    [['"It is not meant to get easier."',[['@',['"No." She pats the earth. "No. Thank you."']]],{led:{truth:1},habit:'candid'}],
     ['"Will you plant something for all of them?"',[['@',['"A hedge," she says slowly. "Marshroot, feverfew, a bit of lavender. A hedge that is nobody\'s, and that heals things."']]],{led:{kin:1,trust:1},habit:'tender'}],
     ['Say the corporal\'s name aloud, once, for the grass.',[['',['"Corporal Pell," you say. The wind moves the feverfew. Madder closes her eyes.']]],{led:{mercy:1},habit:'steady'}]]),
  B([['@',['"I think I can go in now," says Madder. "Would you say a few plain words? You have the voice for it."']]],
    'You say:',
    [['That he was a polite man who was cared for to the end.',[['',['It is true. It is quite enough.']]],{led:{truth:1,mercy:1},habit:'candid'}],
     ['That the war took a good deal and gave very little back.',[['',['Madder nods once. It is what she would have said, if she had had the heart.']]],{led:{truth:1,pride:1},habit:'proud'}]])
 ]});

/* ---------- Pask and the camp (1 h) ---------- */
SQ.def('dill2.stand',{kind:'talk',hours:1,
 open:['"They are loud. I will go first, if you would like. I would prefer you went first."'],
 beats:[
  B([['',['The camp is a wall of faces. A woman with a baby at the front shouts a question you cannot hear.']],['@',['"Say something," Pask hisses. "Anything. Preferably something true."']]],
    'You step forward and say:',
    [['"The half rations were my call. I made it because I thought we would run out."',[['',['Silence, and then a ripple. Someone near the front mutters: "At least she says."']]],{led:{truth:1,pride:1},habit:'candid'}],
     ['"I made a mistake. I did not know it was one."',[['',['They look at you with open, unguarded faces. It is not forgiveness, but it is the room it would need.']]],{led:{truth:1,mercy:1},habit:'gentle'}],
     ['"Hear Pask. He has been standing between us all day."',[['',['A small, uncomfortable shuffling. Pask looks at his own boots.']]],{led:{trust:1},habit:'steady'}]]),
  B([['',['A big duck near the back, with flour to the elbow, calls: "And what are you going to do about it?"']]],
    'You answer:',
    [['"I am going to fix it. And I am going to stay till it is fixed."',[['',['A few nods. Pask lets out a long, shaky breath.']]],{led:{trust:1,pride:1},habit:'steady'}],
     ['"I do not know yet. I will not tell you something I cannot do."',[['',['Several faces change. It is not what they wanted to hear. It is, perhaps, what they needed.']]],{led:{truth:1},habit:'candid'}]])
 ]});

/* ---------- Tamsin's charm (1 h) ---------- */
SQ.def('tamsin2.charm',{kind:'talk',hours:1,
 open:[],
 beats:[
  B([['',['She sits on the step with the ring on its ribbon in her wing, and does not need prompting.']],['@',['"It was a Tuesday. He had been to the market and he had a smell about him, of onions and horse. He knelt in a furrow and I said, \'Alder, get up, you will ruin your good trousers.\'"']]],
    'What do you ask?',
    [['"What did he say?"',[['@',['"He said he had never in his life done a thing he was less afraid of."']]],{led:{kin:1},habit:'tender'}],
     ['"And what did you say, when you said yes?"',[['@',['"I said the trousers were already ruined. He laughed so hard he dropped the ring."']]],{led:{trust:1},habit:'steady'}],
     ['"Do you miss him?"',[['@',['"Every day. In a small, regular way, like a clock."']]],{led:{mercy:1},habit:'gentle'}]]),
  B([['@',['"I have talked a great deal. You have been very patient. Is there anything you would like to tell me?"']]],
    'You say:',
    [['That she has given you more than the ring ever could.',[['@',['"That is a kind lie," she says. "I will take it."']]],{led:{mercy:1,lie:1},habit:'gentle'}],
     ['That you will remember the story, and tell it when it matters.',[['@',['"Yes. That is the right sort of thing to do with a story."']]],{led:{kin:1,truth:1},habit:'tender'}]])
 ]});

/* ---------- Granny Pease's table (1 h) ---------- */
SQ.def('oats1.table',{kind:'talk',hours:1,
 open:['"Sit, sit. It is a long table. You will have to elbow."'],
 beats:[
  B([['',['The camp sits down to eat. Everyone is slightly too formal. A child under the table gives you a firm kick.']],['@',['Granny Pease, passing you a bowl: "We do not know what you want, so we have made everything."']]],
    'What do you reach for?',
    [['The plainest bowl.',[['@',['"Good. That is the one I made."']]],{led:{trust:1},habit:'steady'}],
     ['A bit of everything, and ask what each one is.',[['',['It takes twenty minutes. Every dish has a story. By the end, three people are arguing amiably over a stew.']]],{led:{kin:1},habit:'tender'}],
     ['Offer your bowl to someone who has none.',[['',['The kicking child receives it with grave dignity.']]],{led:{mercy:1},habit:'gentle'}]]),
  B([['@',['An old duck across the table, carefully: "They say you are the one who is going to the Tree. Is it true? Will it be all right?"']]],
    'What do you tell the table?',
    [['"I do not know. But I will tell you the truth when I find out."',[['',['A murmur. Several heads nod, as if this were the one thing they had been hoping for.']]],{led:{truth:1},habit:'candid'}],
     ['"It will be all right."',[['',['The table brightens. Granny Pease, at the head, looks at you without expression, and passes the bread.']]],{led:{lie:1,mercy:1},habit:'gentle'}],
     ['"Ask me again when I am back."',[['',['A quiet laugh goes round the table. It is the right answer to a question like that.']]],{led:{trust:1},habit:'steady'}]])
 ]});

/* ---------- Granny Pease and the first recipe (2 h) ---------- */
SQ.def('oats2.teach',{kind:'talk',hours:2,
 open:['"Sleeves up. This is not hard. It is only slow."'],
 beats:[
  B([['',['The big pot sits on the coals. Granny Pease hands you a spoon the size of an oar.']],['@',['"The first rule: nobody tastes it till it is ready. The second rule: everybody tastes it, when it is."']]],
    'What do you ask first?',
    [['"Who taught you?"',[['@',['"My mother. And her mother. And, for a while, a very rude goat."']]],{led:{kin:1},habit:'tender'}],
     ['"Why this recipe, and not another?"',[['@',['"Because it is the one that stretches. It is made from what is there. Nothing else works in a hard year."']]],{led:{truth:1},habit:'candid'}],
     ['Stir, and keep quiet.',[['',['She watches your spoon-arm and nods once. "Good. You have the wrist."']]],{led:{trust:1},habit:'steady'}]]),
  B([['@',['An hour in. The smell has changed. It is deeper now, and a little sweet. "Here is the part nobody tells you. At some point you have to add the thing you do not have."']]],
    'What do you offer?',
    [['Something from your pack, whatever is to hand.',[['@',['"Yes," she says. "That is the whole recipe, really. Whatever is to hand."']]],{led:{kin:1,trust:1},habit:'tender'}],
     ['"I have nothing to add."',[['@',['"Then add a minute of being here." She slides the spoon back into your wing.']]],{led:{truth:1},habit:'candid'}],
     ['Ask her what she would add.',[['@',['She goes quiet. "Salt, I think. And somebody\'s name. The second is not optional."']]],{led:{mercy:1},habit:'gentle'}]]),
  B([['',['The stew is dark and glossy, and it smells of every kitchen you have ever loved.']],['@',['"Taste," she says. "And tell me what is missing. Do not be polite."']]],
    'You taste it. What do you say?',
    [['"Nothing. It is exactly right."',[['@',['She nods once, hard. "I know. I wanted to hear someone else say it."']]],{led:{kin:1},habit:'tender'}],
     ['"A little more salt."',[['@',['"Ha. Yes." She adds it. "That is why I asked."']]],{led:{truth:1,trust:1},habit:'candid'}]])
 ]});

/* ---------- The Clerk of Debts, discussed (1 h) ---------- */
SQ.def('notice.discuss',{kind:'talk',hours:1,
 open:['"Take a seat. I shall ask in order, and I should like you to answer in order."'],
 beats:[
  B([['',['He opens the ledger and runs a finger down a column of dates.']],['@',['"On the fourth, a Crown courier reports that you declined to produce documents at a checkpoint. On the sixth, an officer notes that you \'argued with a sergeant.\' Are these accurate?"']]],
    'How do you answer?',
    [['"Yes. And I would do it again."',[['@',['His pen pauses. "The ledger has a column for \'unrepentant.\' I will use it sparingly."']]],{led:{pride:1,truth:1},habit:'proud'}],
     ['"Yes, but it was not as it sounds."',[['@',['"Few things are. Go on."']]],{led:{truth:1},habit:'candid'}],
     ['"No. Those reports are slanted."',[['@',['He writes something long. You cannot read upside down, but you can tell it is not favourable.']]],{led:{lie:1},habit:'guarded'}]]),
  B([['@',['He closes the ledger on his finger. "I do not generally explain myself. I shall, once. The Crown is not malicious. It is merely very large, and very slow, and it believes in its own paperwork."']]],
    'You say:',
    [['"Then let me be your paperwork, for a moment. This is what happened."',[['',['You walk him through it, date by date. He takes notes, and, once, almost smiles.']]],{led:{truth:1,trust:1},habit:'candid'}],
     ['"The Crown is large enough to forgive a few arguments."',[['@',['"It is. It is also large enough to forget it did."']]],{led:{pride:1},habit:'proud'}],
     ['"What would help?"',[['@',['A long silence. "No one has ever asked that. I shall have to think."']]],{led:{mercy:1},habit:'steady'}]])
 ]});

/* ---------- Teasel: sit with Mallow (2 h) ---------- */
SQ.def('teasel1.visit',{kind:'talk',hours:2,
 open:['"He is on his bench. He is pretending not to wait."'],
 beats:[
  B([['',['Mallow is on his bench at the edge of the Burnt Wood, with a kettle that has been boiling for some time and a cup that has not been touched.']],['@',['"You came. I told Teasel you would not. I am a poor judge of people. It is a great comfort."']]],
    'What do you say?',
    [['"I could not take a recipe from you without seeing you."',[['@',['"That is the most sensible thing anyone has said this week."']]],{led:{trust:1},habit:'steady'}],
     ['"You wrote it down. That is a thing."',[['@',['"It was. I did it at three in the morning, with the shutters closed. I felt like a man robbing his own house."']]],{led:{truth:1},habit:'candid'}],
     ['Just sit down.',[['',['The bench is not wide. You make room, and he makes room. The kettle settles.']]],{led:{kin:1},habit:'tender'}]]),
  B([['@',['"I have been thinking about my mother. About the song in the graves. About the three hundred. I have been thinking: what if it was not my fault?"']]],
    'What do you tell him?',
    [['"It was not your fault. You were a child."',[['@',['"I know. I know. But I would like it said by somebody who is not me."']]],{led:{mercy:1,kin:1},habit:'gentle'}],
     ['"Fault is not the right word. But it is yours to carry, if you choose."',[['@',['A long breath. "That is the first kind thing that sounds like truth."']]],{led:{truth:1},habit:'candid'}],
     ['"What would you do, if it was not?"',[['@',['"Go home," he says, with an odd little wonder. "I would go home. Now why have I not been?"']]],{led:{trust:1},habit:'steady'}]]),
  B([['',['The sun comes down on the wood. The kettle has boiled dry twice. He pours you the tea he has just made.']],['@',['"You have been patient with an old fool. I would like to give you something that is not a recipe."']]],
    'You say:',
    [['"The recipe will do. It is enough."',[['@',['"Good. Because it is the only thing I had written."']]],{led:{trust:1},habit:'steady'}],
     ['"What is it?"',[['@',['"A promise. That I will go back to Bree\'s, when this is over. And that you may come to tea."']]],{led:{kin:1,mercy:1},habit:'tender'}]])
 ]});

/* ---------- Teasel and the boots (1 h) ---------- */
SQ.def('teasel2.story',{kind:'talk',hours:1,
 open:[],
 beats:[
  B([['',['Teasel sets the boots down on the grass between you, and sits next to them, as if they might fall over.']],['@',['"I will tell it as he told me. If I get it wrong, you must correct me; I have not told it before."']]],
    'You nod. He begins:',
    [['Listen, without interrupting.',[['@',['"The pair were made for a bride, in a village that is not there any more. They are the colour of a good plum. They were never worn to the wedding, because the wedding was not held."']]],{led:{trust:1},habit:'steady'}],
     ['Ask who the bride was.',[['@',['"I do not know. Mallow did not say. I think he did not like to."']]],{led:{kin:1},habit:'tender'}],
     ['Ask why Mallow is giving them away.',[['@',['"He says they were never meant to be kept. They were meant to be walked a long way in."']]],{led:{truth:1},habit:'candid'}]]),
  B([['@',['"He said one other thing. That a boot, if it is a good one, remembers the road. And that the road, in turn, forgives a lot."']]],
    'What do you say?',
    [['"Tell him I will wear them well."',[['@',['"He will like that. He will pretend he did not."']]],{led:{trust:1,kin:1},habit:'steady'}],
     ['"Tell him I will bring them back."',[['@',['A long pause. "I will not tell him that. He would stop sleeping."']]],{led:{truth:1},habit:'candid'}]])
 ]});

/* ---------- Linden's dream (1 h) ---------- */
SQ.def('thistle1.dream',{kind:'talk',hours:1,
 open:['"Sit with me on the end of the cot. I get dizzy if I stand."'],
 beats:[
  B([['',['Linden pulls her feet up. She is thin, still, and slightly translucent at the edges, like someone not quite finished being poured.']],['@',['"It started in a long corridor. There was a table with four hollows. And a stone that hummed."']]],
    'You ask:',
    [['"Who was holding the lantern?"',[['@',['"I could not see. But they knew the way. I followed them, because I was not afraid."']]],{led:{trust:1},habit:'steady'}],
     ['"How did it end?"',[['@',['"It did not. It stopped, as if somebody had put a hand on the page."']]],{led:{truth:1},habit:'candid'}],
     ['"Were you afraid?"',[['@',['"Not at all. That is the strangest thing. I should have been."']]],{led:{kin:1},habit:'tender'}]]),
  B([['@',['"I think I was dreaming forward," she says. "Is that possible? Or have I been asleep so long that now and then are the same?"']]],
    'What do you say?',
    [['"I do not know. But I will keep the lantern, and I will check."',[['@',['She laughs, the way people do when relieved. "Oh good. A practical one."']]],{led:{trust:1,kin:1},habit:'steady'}],
     ['"Maybe the ones who sleep long see further."',[['@',['"That is a better answer than the nurse gave me. She said I was overtired."']]],{led:{mercy:1},habit:'gentle'}],
     ['"It does not matter. It was a good dream."',[['@',['She considers it. "It was. I would like to have it again."']]],{led:{kin:1},habit:'tender'}]])
 ]});

})();
