'use strict';
/* ===== FISHING, SELLING THE CATCH, THE COLLECTIONS ALBUM AND THE RUMOUR OF THE DAY ===== */
Object.assign(MG_BY_TITLE,{'Go Fishing':'fish'});

/* ---------- the fish ---------- */
const FISH=[
  {id:'minnow',n:'Minnow',v:3,w:30,col:'#9fc4d8'},
  {id:'perch',n:'Perch',v:6,w:24,col:'#8aa34a'},
  {id:'carp',n:'Carp',v:8,w:18,col:'#c9803a'},
  {id:'trout',n:'Speckled Trout',v:12,w:10,col:'#c58aa0',rare:1},
  {id:'catfish',n:'Whiskered Catfish',v:15,w:7,col:'#6a5a4a',rare:1},
  {id:'goldkoi',n:'Golden Koi',v:33,w:2.2,col:'#ffb52e',rare:1},
  {id:'mooneel',n:'Moon Eel',v:27,w:0,col:'#b8a8ff',rare:1,night:1},
  {id:'oldboot',n:'Old Boot',v:1,w:5,col:'#5a3a22',junk:1},
  /* v1.26: each biome has its own fish, found nowhere else. bio = the biome it lives in */
  {id:'icechar',n:'Icefin Char',v:14,w:8,col:'#bfe6f5',rare:1,bio:'tundra'},
  {id:'sandfin',n:'Sandfin Darter',v:12,w:8,col:'#e0c07a',rare:1,bio:'desert'},
  {id:'arowana',n:'Rainbow Arowana',v:20,w:7,col:'#5ad0a0',rare:1,bio:'jungle'},
  {id:'mudskip',n:'Mistmarsh Mudskipper',v:13,w:8,col:'#7a8a5a',rare:1,bio:'swamp'},
  {id:'bamboofin',n:'Bamboo Reedfish',v:12,w:8,col:'#a8d060',rare:1,bio:'bamboo'},
  {id:'petalcarp',n:'Petal Carp',v:16,w:7,col:'#f4a8c8',rare:1,bio:'cherry'},
  {id:'glowtetra',n:'Glowcap Tetra',v:17,w:7,col:'#b890ff',rare:1,bio:'glowcap'},
  {id:'lavbarb',n:'Lavender Barb',v:12,w:8,col:'#b8a8e8',rare:1,bio:'lavender'},
  {id:'saltflat',n:'Shore Flatfish',v:13,w:8,col:'#8ad8d0',rare:1,bio:'shore'},
  {id:'sunperch',n:'Savanna Sunperch',v:14,w:8,col:'#f0a040',rare:1,bio:'savanna'},
  {id:'stonebass',n:'Highland Stone Bass',v:14,w:8,col:'#9aa6b8',rare:1,bio:'highlands'},
  {id:'amberpike',n:'Amber Pike',v:15,w:8,col:'#d8883a',rare:1,bio:'autumn'},
  {id:'meadowshiner',n:'Meadow Shiner',v:11,w:8,col:'#f0d870',rare:1,bio:'meadow'}
];
const FISHIDS=FISH.map(f=>f.id), FISHBY={}; FISH.forEach(f=>FISHBY[f.id]=f);
for(const f of FISH){
  ITEMS['fish_'+f.id]={name:f.n,price:f.v,nogift:true,use:'note',
    desc:f.junk?'It was somebody\'s once. Now it is yours. Curio shops are rumoured to take anything.':'Fresh from the water. Sells best to markets and cafes. '+(f.rare?'A rare catch.':''),
    note:f.junk?'It smells of pond and regret.':'It flops once, in protest, and then gives in.'};
  RICON['fish_'+f.id]=f.junk
    ? (R,C,E)=>{ R(5,3,4,8,'#5a3a22'); R(5,10,8,3,'#4a2e1a'); R(5,3,4,1,'#7a5a3a'); R(6,5,2,1,'#c9a06a'); }
    : (R,C,E)=>{ E(7,8,5.5,3.4,f.col); R(11,5,2,6,f.col); R(12,6,2,4,f.col); R(3,7,1,1,'#111'); R(5,10,4,1,'rgba(255,255,255,0.35)'); R(6,6,3,1,'rgba(255,255,255,0.28)'); };
}
ITEMS.roastfish={name:'Roast Fish',price:5,use:'eat',boost:80,nogift:true,desc:'Kindled to a golden crisp. A very big boost of speed.',quip:'Crisp skin, soft inside, a little smoky. You feel unstoppable for a while.'};
RICON.roastfish=(R,C,E)=>{ E(7,8,5.5,3.4,'#c98a3a'); R(11,5,2,6,'#b07a30'); R(12,6,2,4,'#b07a30'); R(3,7,1,1,'#111'); R(5,6,1,4,'#6a3a1a'); R(8,6,1,4,'#6a3a1a'); };
ITEMS.fishrod={name:'Fishing Rod',price:18,nogift:true,use:'note',desc:'Face any water and press Z to cast. The line frays after about forty casts. Any town re-strings it for free, or cast Mend.',note:'Face a pond or stream and press Z.'};
RICON.fishrod=(R,C,E)=>{ for(let i=0;i<11;i++) R(2+i,13-i,1.4,1.4,'#8a5a2b'); R(13,2,1,7,'#ddd'); C(13,10,1.6,'#e0452f'); };
STOCK.supply.push('fishrod');
STOCK.curio.push('fishrod');

/* ---------- state ---------- */
function XC(){ const x=XS(); if(!x.coll) x.coll={fish:{},towns:{},ev:{}}; return x.coll; }
function fishCount(){ let n=0; for(const id of FISHIDS) n+=g.inv['fish_'+id]||0; return n; }

/* ---------- the fishing game ---------- */
const CAST_LINES=['You swing the rod back, and let the line fly.','The bobber plops down and floats, entirely unbothered.','You wiggle the rod, cough, and look as casual as a duck can look beside water.'];
MG.fish={
 cap:70,
 hint:'Wait for the bobber to dip, then hook and reel.', keys:'Z hook  /  hold Z to reel (or tap, in Settings)',
 how:['Wait for the bobber to dip. Press Z to hook the fish.','Then hold Z to lift your hook, let go to sink it.','Keep the hook on the fish until the bar is full.'],
 hud:s=>s.ph==='reel'?'Reel '+Math.round(s.prog*100)+'%':s.ph==='bite'?'BITE!':s.ph==='wait'?'Waiting...':' ',
 init(s){
  const x=XS(), wx=wxNow(), veil=xAbs()<(x.veilUntil||0);
  s.ph='wait'; s.wait=mgRnd(1.8,5)*(veil?0.45:1)*(wx==='rain'||wx==='storm'?0.75:1); s.bt=0;
  s.hook=0.5; s.vel=0; s.fish=0.5; s.ft=0.5; s.fT=0; s.prog=0.3; s.rt=0; s.fin=0;
  s.band=x.bind?0.27:0.2; if(x.bind) x.bind=0; s.spd=wx==='storm'?1.35:1; s.caught=0;
 },
 update(s,dt){
  if(s.ph==='wait'){ s.wait-=dt; if(s.wait<=0){ s.ph='bite'; s.bt=0.95; tone('sine',500,880,0.16,0.07); } }
  else if(s.ph==='bite'){ s.bt-=dt; if(s.bt<=0){ s.ph='end'; s.fin=1; s.msg='It got away...'; mgTone(0); } }
  else if(s.ph==='reel'){
   s.rt+=dt; s.fT-=dt; if(s.fT<=0){ s.fT=mgRnd(0.6,1.3)/s.spd; s.ft=0.08+Math.random()*0.84; }
   s.fish+=(s.ft-s.fish)*Math.min(1,dt*2.2*s.spd);
   s.vel+=(((keys.z||s.lift)?2.6:-2.1))*dt; s.vel*=Math.pow(0.04,dt); s.hook=mgClamp(s.hook+s.vel*dt,0,1); if(s.hook<=0||s.hook>=1) s.vel=0;
   const on=Math.abs(s.hook-s.fish)<s.band/2+0.02;
   s.prog+=(on?0.2:-0.13)*dt; s.on=on;
   if(s.prog>=1){ s.caught=1; s.ph='end'; s.fin=1; s.msg='Got it!'; mgTone(1); }
   else if(s.prog<=0||s.rt>18){ s.ph='end'; s.fin=1; s.msg='The line goes slack...'; mgTone(0); }
  } else if(s.ph==='end'){ s.fin-=dt; if(s.fin<=0){ s.done=1; s.score=s.caught?mgClamp(Math.round(10-s.rt*0.45),6,10):0; } }
 },
 press(s,k){
  if(k!=='z') return;
  if(s.ph==='reel'){ try{ if(D10.settings.reel==='toggle') s.lift=!s.lift; }catch(e){} return; }
  if(s.ph==='wait'){ s.wait+=1.1; s.msg='Patience...'; }
  else if(s.ph==='bite'){ s.ph='reel'; s.msg='Hooked!'; s.rt=0; blip(); }
 },
 draw(s,c,t){
  mgSky(c,'#9fd0ee','#cfe8f4'); rect(c,0,95,MGW,175,'#2f78a8'); rect(c,0,95,MGW,3,'#5aa3cf');
  for(let i=0;i<8;i++) rect(c,((i*70+t*14)%MGW),130+i*14,36,2,'rgba(255,255,255,0.2)');
  rect(c,0,200,140,70,'#6aa84f'); rect(c,0,200,140,4,'#4f8a3a');
  mgDuck(c,70,210,1.5,'#ffd84a');
  c.strokeStyle='#8a5a2b'; c.lineWidth=3; c.beginPath(); c.moveTo(86,184); c.lineTo(190,96); c.stroke();
  const bx=250, dip=s.ph==='bite'?8+Math.sin(t*40)*3:(s.ph==='reel'?14:Math.sin(t*2)*2);
  c.strokeStyle='#eee'; c.lineWidth=1; c.beginPath(); c.moveTo(190,96); c.lineTo(bx,128+dip); c.stroke();
  circ(c,bx,126+dip,5,'#e0452f'); rect(c,bx-5,126+dip,10,2,'#fff');
  if(s.ph==='bite'){ mgT(c,'!',bx,95,26,'#ffd166'); for(let i=0;i<3;i++){ c.strokeStyle='rgba(255,255,255,'+(0.7-i*0.2)+')'; c.beginPath(); c.arc(bx,134,10+i*8+((t*30)%8),0,7); c.stroke(); } }
  if(s.ph==='reel'||(s.ph==='end'&&s.caught)){
   const gx=420, gy=40, gh=200; rect(c,gx-14,gy,28,gh,'rgba(10,30,50,0.85)');
   rect(c,gx-14,gy+gh*(1-s.hook-s.band/2),28,gh*s.band,s.on?'rgba(127,211,122,0.8)':'rgba(255,255,255,0.5)');
   ell(c,gx,gy+gh*(1-s.fish),9,5,'#ffb347'); rect(c,gx+6,gy+gh*(1-s.fish)-3,5,6,'#ffb347');
   mgBar(c,gx-40,gy+gh+8,80,8,s.prog,'#7fd37a');
  }
 }
};
/* v1.26: the line lasts twice as long, the Angler aims make it last longer still, and shops and homes re-string it for free */
function rodMax(){ let n=40; try{ n+=10*(D10.aimTier?D10.aimTier('angler'):0); }catch(e){} return n; }
function rodNote(){ const w=XS().rodWear||0, m=rodMax(); return w>=m?' (frayed)':w>=m*0.7?' (worn)':''; }
function startFishing(){
  const x=XS();
  if((x.rodWear||0)>=rodMax()){
    const labels=['Re-string the line (3 crumbs)']; const fns=[()=>{ if(g.crumbs<3){ say('',['You only have '+g.crumbs+' crumbs. The line stays frayed.']); return; } g.crumbs-=3; x.rodWear=0; coin(); toast('Line re-strung. Good as new.',2200); }];
    if(magicDays()>=6){ labels.push('Cast Mend'); fns.push(()=>castSpell('Mend')); }
    labels.push('Never mind'); fns.push(()=>{});
    choose('','The line on your rod is frayed through.',labels,k=>fns[k](),labels.length-1); return;
  }
  if(g.clock>=23||g.clock<4){ say('',['It is far too dark to see the bobber. Fish at dawn, or when the moon is high enough... which it is not.']); return; }
  say('',[pick(CAST_LINES)],()=>startMini({title:'Go Fishing',say:'Hook the fish, then reel it in.',onDone:S=>fishResult(S)}));
}
const FISH_CTX={tx:0,ty:0,bio:null,hot:false,n:0};
function pickFish(S){
  const night=g.clock>=20||g.clock<5, wx=wxNow(), biting=rumorHere('biting');
  const pool=FISH.map(f=>{
    let w=f.w; if(f.night) w=night?6:0;
    if(f.bio) w=(f.bio===FISH_CTX.bio)?w*(1+S/10*0.8):0;
    if(f.rare&&FISH_CTX.hot) w*=2;
    if(f.rare) w*=(FISH_CTX.rare||1);
    if(f.rare) w*=(1+S/10*1.3)*(biting?2:1)*(wx==='rain'?1.4:1);
    if(f.junk) w*=Math.max(0.1,1-S/11);
    return [f,w];
  });
  let tot=0; pool.forEach(p=>tot+=p[1]); let r=rnd()*tot;
  for(const p of pool){ r-=p[1]; if(r<=0) return p[0]; }
  return pool[0][0];
}
function fishResult(S){
  const x=XS(); x.rodWear=(x.rodWear||0)+1; advanceClock(0.4);
  if(S<=0){ toast('It got away. The water settles, smug.',2400); return; }
  const f=pickFish(S), c=XC(), isNew=!c.fish[f.id];
  c.fish[f.id]=(c.fish[f.id]||0)+1; addItem('fish_'+f.id); coin();
  const lines=[f.junk?'You reel in... an Old Boot. It is a very good boot. For a boot.':'You land a '+f.n+'!'+(f.rare?' A rare one!':'')];
  if(isNew) lines.push('New for your Collections album: '+f.n+'.');
  const left=rodMax()-x.rodWear; if(left===5) lines.push('The line is getting worn. A few casts left.');
  say('',lines);
}
{
  const _findTarget=findTarget;
  findTarget=function(){
    _findTarget();
    if(g.target||g.mode!=='play'||g.scene!=='world'||!isHeld('fishrod')) return;
    const v=DIRV[g.dir], tx=Math.floor((g.px+v.x*14)/TS), ty=Math.floor((g.py-6+v.y*14)/TS);
    if(tileAt(tx,ty)===T.WATER) g.target={k:'fish',x:(tx+0.5)*TS,y:ty*TS+2,tx:tx,ty:ty};
  };
  const _interact=interact;
  interact=function(){
    const tg=g.target;
    if(tg&&tg.k==='fish'){ quack(); startFishing(); return; }
    _interact();
  };
}

/* ---------- selling the catch ---------- */
const BUY={
  market:{m:1.0,name:'fresh from the water'}, cafe:{m:1.15,no:['oldboot']}, rcafe:{m:1.1,no:['oldboot']},
  bakery:{m:0.9,only:['minnow','perch','carp']}, curio:{m:1.0,only:['goldkoi','mooneel','oldboot']}, supply:{m:0.8,only:['goldkoi','oldboot']}
};
function fishBuyer(b){ return !!BUY[b.kind]; }
function fishOK(b,id){ const r=BUY[b.kind]; if(!r) return false; if(r.only&&r.only.indexOf(id)<0) return false; if(r.no&&r.no.indexOf(id)>=0) return false; return true; }
function soldKey(b){ return 'sold:'+b.x+','+b.y+':'+g.day; }
function fishQuote(b,t,ids){
  const x=XS(), r=BUY[b.kind]; x.sold=x.sold||{};
  let sold=x.sold[soldKey(b)]||0, total=0, units=0;
  const dem=0.85+0.3*hash(b.x+g.day,b.y,8801);
  for(const id of ids){
    const n=g.inv['fish_'+id]||0, f=FISHBY[id];
    for(let i=0;i<n;i++){
      let p=f.v*r.m*dem*(1+0.04*townRank(t));
      if(x.frostDay===g.day) p*=1.25;
      if(rumorActive('fishprice',t)) p*=1.3;
      p*=Math.max(0.45,1-0.07*(sold+units));
      total+=Math.max(1,Math.round(p)); units++;
    }
  }
  return {total:total,units:units};
}
function sellFish(b,t){
  const x=XS(); x.sold=x.sold||{};
  const refKey='ref:'+b.x+','+b.y+':'+g.day, nm=b.keeper.name;
  if(x.sold[refKey]||hash(b.x+g.day*3,b.y,8802)<0.15){ say(nm,[pick(['I have more fish than I can carry today. Try tomorrow.','The fish stall next door undercut everyone this morning. I am not buying today.','Not today. My shelves smell enough like pond already.'])]); return; }
  const ids=FISHIDS.filter(id=>g.inv['fish_'+id]&&fishOK(b,id));
  if(!ids.length){ say(nm,['I do not buy that sort of thing here. A market or a cafe, perhaps.']); return; }
  const q=fishQuote(b,t,ids);
  const finish=(total)=>{
    for(const id of ids){ const n=g.inv['fish_'+id]||0; for(let i=0;i<n;i++) delInv('fish_'+id); }
    g.crumbs+=total; x.sold[soldKey(b)]=(x.sold[soldKey(b)]||0)+q.units; x.fishSold=(x.fishSold||0)+q.units; coin();
    toast('Sold '+q.units+' fish for '+total+' crumbs.',3000);
    if(q.units>=3&&rnd()<0.3) addRep(t,1);
  };
  const offerLines=[pick(['Hm. Let me see.','Ah, a fisher. Let me look.','Not bad. Not bad at all.'])+' I could give you '+q.total+' crumbs for the lot ('+q.units+' fish).'];
  say(nm,offerLines,()=>{
    choose(nm,'Sell them all for '+q.total+' crumbs?',['Sell it all','Haggle for more','Not now'],k=>{
      if(k===0){ finish(q.total); return; }
      if(k!==1) return;
      const ch=0.42+0.04*townRank(t), roll=rnd();
      if(roll<ch){
        const hi=Math.round(q.total*1.3);
        say(nm,['Hah. You drive a hard bargain. Fine: '+hi+' crumbs.'],()=>choose(nm,'Take '+hi+' crumbs?',['Sell it all','Not now'],k2=>{ if(k2===0) finish(hi); },1));
      } else if(roll<ch+0.28){
        say(nm,['No. '+q.total+' is the price. Take it or leave it.'],()=>choose(nm,'Sell them all for '+q.total+' crumbs?',['Sell it all','Not now'],k2=>{ if(k2===0) finish(q.total); },1));
      } else { x.sold[refKey]=1; say(nm,['You push too hard. I am done buying fish today.']); }
    },2);
  });
}
openCounter=function(){
  const b=g.shop.b, t=g.shop.town, left=SHIFTS_PER_DAY-workCount(wkey(b));
  const labels=['Browse the shelves','Ask for work ('+Math.max(0,left)+' shift'+(left===1?'':'s')+' left today)','Chat'];
  const fns=[()=>openShop(),()=>askWork(b,t),()=>chatKeeper(b,t)];
  if(fishBuyer(b)&&FISHIDS.some(id=>g.inv['fish_'+id]&&fishOK(b,id))){ labels.push('Sell fish ('+fishCount()+')'); fns.push(()=>sellFish(b,t)); }
  labels.push('Leave'); fns.push(()=>{});
  const gr=RANK_GREET[townRank(t)];
  choose(b.keeper.name,gr[(b.idx+g.day)%gr.length]+' What can I do for you?',labels,k=>fns[k](),labels.length-1);
};

/* ---------- rumour of the day ---------- */
function rumorActive(type,t){ const d=(XS().rumData||{})[t.key+':'+g.day]; return !!(d&&d.type===type); }
function rumorHere(type){
  const rd=XS().rumData; if(!rd) return false;
  const p=xPlayerTile();
  for(const k in rd){ if(rd[k].type!==type||k.split(':')[1]!==String(g.day)) continue; const t=townByKey(k.split(':')[0]); if(t&&Math.hypot(t.cx-p.x,t.cy-p.y)<70) return true; }
  return false;
}
function readRumor(t){
  const x=XS(); x.rumData=x.rumData||{};
  const key=t.key+':'+g.day;
  let d=x.rumData[key];
  const who=t.npcs.length?t.npcs[Math.floor(hash(t.rx+g.day,t.ry,9103)*t.npcs.length)].name:'A passing duck';
  if(!d){
    const h=hash(t.rx*5+g.day,t.ry*9+g.day,9100);
    if(h<0.3){
      const b=t.buildings[Math.floor(hash(t.rx+g.day,t.ry,9101)*t.buildings.length)], ids=STOCK[b.kind], id=ids[Math.floor(hash(t.rx,t.ry+g.day,9102)*ids.length)];
      d={type:'bargain',item:id,shop:b.name,keeper:b.keeper.name};
    } else if(h<0.5) d={type:'fishprice'};
    else if(h<0.7) d={type:'biting'};
    else d={type:'event'};
    x.rumData[key]=d;
  }
  let lines;
  if(d.type==='bargain') lines=[who+' leans in. "Psst. '+d.keeper+' at '+d.shop+' is marking down the '+ITEMS[d.item].name+' today. A quarter off. You did not hear it from me."'];
  else if(d.type==='fishprice') lines=[who+' says: "Fish are fetching a third more at the shops today. If you know anyone with a rod, tell them."'];
  else if(d.type==='biting') lines=[who+' says: "The fish are biting around '+t.name+' today. Even the rare ones, if you are patient."'];
  else {
    const e=eventFor(t,g.day+1);
    lines=[who+' says: "'+(e?'I hear tomorrow is '+e.title+', at '+hourLabel(e.h)+'. Bring your appetite. Or your wings.':'Tomorrow is a quiet day here. Good for naps.')+'"'];
  }
  say('Rumour',lines);
}
{
  const _ip=itemPrice;
  itemPrice=function(id,town){
    let p=_ip(id,town);
    const d=(XS().rumData||{})[town.key+':'+g.day];
    if(d&&d.type==='bargain'&&d.item===id) p=Math.max(1,Math.round(p*0.75));
    return p;
  };
}

/* ---------- collections ---------- */
const MILES=[
  {id:'f3',cat:'fish',n:3,r:15},{id:'f5',cat:'fish',n:5,r:30},{id:'f8',cat:'fish',n:8,r:80},
  {id:'t3',cat:'towns',n:3,r:15},{id:'t6',cat:'towns',n:6,r:30},{id:'t12',cat:'towns',n:12,r:60},{id:'t25',cat:'towns',n:25,r:150},
  {id:'e5',cat:'ev',n:5,r:15},{id:'e12',cat:'ev',n:12,r:40},{id:'e25',cat:'ev',n:25,r:100}
];
const CATN={fish:'fish species',towns:'town stamps',ev:'event ribbons'};
function collN(cat){ return Object.keys(XC()[cat]).length; }
function collStamp(name,key){ const c=XC(); if(!c.towns[key]){ c.towns[key]=name; if(g.mode==='play') toast('Town stamp collected: '+name+'.',2600); } }
function collCheck(){
  const x=XS(); x.collRew=x.collRew||{};
  for(const m of MILES){
    if(x.collRew[m.id]||collN(m.cat)<m.n) continue;
    x.collRew[m.id]=1; g.crumbs+=m.r; coin();
    toast('Album milestone: '+m.n+' '+CATN[m.cat]+'!  +'+m.r+' crumbs',4600);
  }
}
{
  const _attend=attendEvent;
  attendEvent=function(t,e){ const c=XC(); c.ev[e.id]=(c.ev[e.id]||0)+1; _attend(t,e); };
}
function nextMile(cat){ const x=XS(), m=MILES.find(m=>m.cat===cat&&!(x.collRew||{})[m.id]); return m?' Next reward at '+m.n+' (+'+m.r+' crumbs).':' All rewards collected.'; }
function albumPages(){
  const c=XC();
  const fish=FISH.map(f=>c.fish[f.id]?f.n+' x'+c.fish[f.id]:'???').join(',  ');
  const towns=Object.keys(c.towns).map(k=>c.towns[k]);
  const days=magicDays();
  return [
    ['Fish ('+collN('fish')+'/'+FISH.length+'):  '+fish+'.'+nextMile('fish')],
    ['Town stamps ('+collN('towns')+'):  '+(towns.length?towns.join(', '):'none yet')+'.'+nextMile('towns')],
    ['Event ribbons ('+collN('ev')+' kinds attended).'+nextMile('ev')],
    ['Spells learned: '+Math.min(12,days)+'/12'+(days?'  ('+SPELLS.slice(0,Math.min(12,days)).map(s=>s[0]).join(', ')+')':'')+'.  Q/E choose, C casts.']
  ].map(p=>p[0]);
}
function openAlbum(){ say('Collections Album',albumPages()); }
function collJournal(sec,line){
  sec('Collections');
  line('Fish '+collN('fish')+'/'+FISH.length+'  |  Town stamps '+collN('towns')+'  |  Event ribbons '+collN('ev')+'  |  Spells '+Math.min(12,magicDays())+'/12');
  line('Fish sold: '+(XS().fishSold||0)+'.  The full album is on any notice board.');
}
