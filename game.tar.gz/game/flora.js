'use strict';
/* ===== FLORA: the painters =====
   Every wild tree, flower, bush, mushroom, rock and stump is drawn by one of these small painters, tuned by a species' colours.
   Painters draw onto a 32px tile at (px,py). Trees reach above the tile. `o` carries the tile's x/y, the time, the sway, a size
   jitter `s`, a 0..1 `h` and `picked` (already foraged today, so berries, blooms and fruit are gone). */
const WL_SH=(c,px,py,rx)=>ell(c,px+16,py+30,rx,5,'rgba(0,0,0,0.24)');
const WL_P={tree:{},flower:{},bush:{},mush:{},rock:{},stump:{}};
const WL_DOTS=[[9,4],[21,2],[15,9],[24,9],[7,10],[17,-4],[12,-7]];
const wlLine=(c,x0,y0,x1,y1,w,col)=>{ c.strokeStyle=col; c.lineWidth=w; c.beginPath(); c.moveTo(x0,y0); c.lineTo(x1,y1); c.stroke(); };
const wlTri=(c,x0,y0,x1,y1,x2,y2,col)=>{ c.fillStyle=col; c.beginPath(); c.moveTo(x0,y0); c.lineTo(x1,y1); c.lineTo(x2,y2); c.closePath(); c.fill(); };
const wlGlowLight=(px,py,r,s)=>{ if(NIGHT>0.12) lights.push({x:px+16,y:py+8,r:r,s:s,w:0}); };

/* ---------------- TREES ---------------- */
/* c: [trunk, crown dark, crown mid, crown light]. extras: bloom (dots), fruit (dots, picked clean), ground (fallen petals), sz */
WL_P.tree.round=(c,px,py,sp,o)=>{
  const k=sp.c, s=o.s*(sp.sz||1), w=o.sway;
  WL_SH(c,px,py,14);
  rect(c,px+12,py+14,8,18,k[0]); rect(c,px+17,py+14,3,18,'rgba(0,0,0,0.22)');
  circ(c,px+16+w,py-2,17*s,k[1]); circ(c,px+7+w,py+7,12*s,k[1]); circ(c,px+25+w,py+7,12*s,k[1]);
  circ(c,px+16+w,py+4,13*s,k[2]); circ(c,px+12+w,py-5,8*s,k[3]);
  if(sp.bloom&&!o.picked) for(let i=0;i<WL_DOTS.length;i++) rect(c,px+WL_DOTS[i][0]+w+(i&1?3:-2),py+WL_DOTS[i][1]+3,2,2,sp.bloom);
  if(sp.fruit&&!o.picked) for(let i=0;i<5;i++) circ(c,px+WL_DOTS[i][0]+w+2,py+WL_DOTS[i][1]+5,2,sp.fruit);
  if(sp.ground&&!o.picked){ for(let i=0;i<6;i++) rect(c,px+4+((i*5+((o.h*20)|0))%24),py+27+(i%3)*2,2,1,sp.ground); }
};
/* c: [trunk, dark, mid, light] a tall column (cypress, poplar, larch) */
WL_P.tree.spire=(c,px,py,sp,o)=>{
  const k=sp.c, s=o.s*(sp.sz||1), w=o.sway*0.5;
  WL_SH(c,px,py,10); rect(c,px+14,py+24,5,8,k[0]);
  ell(c,px+16+w,py+6,10*s,23*s,k[1]); ell(c,px+14+w,py+2,6.5*s,17*s,k[2]); ell(c,px+12+w,py-6,3*s,8*s,k[3]);
  if(sp.fruit&&!o.picked) for(let i=0;i<4;i++) circ(c,px+11+i*3.5+w,py+4+(i%2)*7,1.8,sp.fruit);
};
/* c: [dark, mid, light]; snow: a white cap on every tier */
WL_P.tree.pine=(c,px,py,sp,o)=>{
  const s=o.s*(sp.sz||1);
  drawPine(c,px,py,o.sway,sp.c,s);
  if(sp.snow){
    for(const tr of [[26,3,16],[17,-3,13],[9,-8,10]]){
      const by=py+tr[0]+2, ty=py+tr[1]-12, hw=tr[2]*s, ay=ty+(by-ty)*0.42, hh=hw*0.5;
      wlTri(c,px+16+o.sway*0.4,ty,px+16+hh,ay,px+16-hh,ay,'#f6fbff');
    }
  }
  if(sp.cones&&!o.picked){ circ(c,px+9,py+18,1.6,'#7a5230'); circ(c,px+24,py+12,1.6,'#7a5230'); }
};
/* c: [trunk, frond dark, frond light]; fruit; fr: frond count */
WL_P.tree.palm=(c,px,py,sp,o)=>{
  const k=sp.c, w=o.sway, d=(o.h<0.5?-1:1), fr=sp.fr||7;
  WL_SH(c,px,py,11);
  c.lineCap='round';
  c.strokeStyle=k[0]; c.lineWidth=sp.thick||4; c.beginPath(); c.moveTo(px+16,py+31); c.quadraticCurveTo(px+16+d*4,py+14,px+16+d*7+w*0.5,py-3); c.stroke();
  c.strokeStyle='rgba(0,0,0,0.22)'; c.lineWidth=1;
  for(let i=0;i<5;i++){ const u=i/5, yy=py+29-u*30, xx=px+16+d*(7*u*u*1.1+4*u*(1-u))+w*0.5*u; c.beginPath(); c.moveTo(xx-2,yy); c.lineTo(xx+2,yy); c.stroke(); }
  const tx=px+16+d*7+w*0.5, ty=py-3;
  for(let i=0;i<fr;i++){
    const a=-Math.PI*0.96+(i/(fr-1))*Math.PI*0.92, sw=Math.sin(o.time*1.6+i)*0.8;
    const ex=tx+Math.cos(a)*(sp.len||17), ey=ty+Math.sin(a)*3+(sp.droop||8)+sw;
    c.strokeStyle=k[1]; c.lineWidth=3.2; c.beginPath(); c.moveTo(tx,ty); c.quadraticCurveTo(tx+Math.cos(a)*9,ty+Math.sin(a)*12,ex,ey); c.stroke();
    c.strokeStyle=k[2]; c.lineWidth=1.2; c.beginPath(); c.moveTo(tx,ty-0.5); c.quadraticCurveTo(tx+Math.cos(a)*9,ty+Math.sin(a)*12-0.7,ex,ey-0.5); c.stroke();
  }
  c.lineCap='butt';
  if(sp.fruit&&!o.picked){ circ(c,tx-2,ty+3,2.2,sp.fruit); circ(c,tx+2.5,ty+4,2.2,sp.fruit); circ(c,tx,ty+6,2.2,sp.fruit); }
};
/* c: [body, shade, bloom]; v: saguaro | barrel | joshua */
WL_P.tree.cactus=(c,px,py,sp,o)=>{
  const k=sp.c, v=sp.v||'saguaro';
  if(v==='saguaro'){
    WL_SH(c,px,py,11);
    rect(c,px+12,py+1,8,30,k[0]); rect(c,px+12,py+1,2,30,k[1]); ell(c,px+16,py+1,4,3,k[0]);
    rect(c,px+4,py+14,9,4,k[0]); rect(c,px+4,py+6,4,12,k[0]); ell(c,px+6,py+6,2.5,2,k[0]); rect(c,px+4,py+6,1,12,k[1]);
    rect(c,px+19,py+18,9,4,k[0]); rect(c,px+24,py+10,4,12,k[0]); ell(c,px+26,py+10,2.5,2,k[0]); rect(c,px+24,py+10,1,12,k[1]);
    c.fillStyle='rgba(255,255,255,0.55)'; for(let i=0;i<5;i++) c.fillRect(px+15,py+5+i*5,1,1);
    if(!o.picked&&k[2]){ circ(c,px+16,py-1,2.6,k[2]); circ(c,px+6,py+4,1.8,k[2]); }
  } else if(v==='barrel'){
    WL_SH(c,px,py,11);
    ell(c,px+16,py+22,10,9,k[0]); ell(c,px+13,py+19,5,5,'rgba(255,255,255,0.1)');
    for(let i=-2;i<=2;i++) rect(c,px+16+i*3.2,py+14+Math.abs(i),1,14-Math.abs(i)*1.5,k[1]);
    c.fillStyle='rgba(255,255,255,0.6)'; for(let i=-3;i<=3;i++) c.fillRect(px+15.5+i*2.8,py+17+Math.abs(i),1,1);
    if(!o.picked&&k[2]){ circ(c,px+16,py+13,3,k[2]); circ(c,px+16,py+13,1.2,'#fff3b0'); }
  } else {
    WL_SH(c,px,py,10);
    rect(c,px+14,py+12,5,20,'#7a5a3c'); rect(c,px+14,py+12,1,20,'#5a4028');
    wlLine(c,px+16,py+16,px+6,py+5,3.4,'#7a5a3c'); wlLine(c,px+16,py+14,px+26,py+3,3.4,'#7a5a3c'); wlLine(c,px+16,py+10,px+16,py-3,3.4,'#7a5a3c');
    for(const t of [[6,5],[26,3],[16,-3]]){
      for(let i=0;i<8;i++){ const a=i/8*6.283; wlLine(c,px+t[0],py+t[1],px+t[0]+Math.cos(a)*7,py+t[1]+Math.sin(a)*5,1.6,i&1?k[0]:k[1]); }
      circ(c,px+t[0],py+t[1],2.4,k[0]);
    }
    if(!o.picked&&k[2]){ circ(c,px+6,py+5,1.8,k[2]); circ(c,px+26,py+3,1.8,k[2]); }
  }
};
/* c: [trunk, mark, crown dark, crown mid, crown light] */
WL_P.tree.birch=(c,px,py,sp,o)=>{
  const k=sp.c, s=o.s*(sp.sz||1), w=o.sway;
  WL_SH(c,px,py,12);
  rect(c,px+12,py+12,7,20,k[0]); rect(c,px+17,py+12,2,20,'rgba(0,0,0,0.16)');
  for(let i=0;i<5;i++) rect(c,px+12+((i*3)%4),py+14+i*3.6,3+(i%2),1.4,k[1]);
  ell(c,px+16+w,py-1,13*s,16*s,k[2]); ell(c,px+10+w,py+6,9*s,10*s,k[2]); ell(c,px+23+w,py+5,9*s,10*s,k[2]);
  ell(c,px+16+w,py+1,10*s,12*s,k[3]); ell(c,px+13+w,py-6,6*s,7*s,k[4]);
  if(sp.fruit&&!o.picked) for(let i=0;i<4;i++) circ(c,px+9+i*4+w,py+3+(i%2)*6,1.7,sp.fruit);
};
/* c: [trunk, crown dark, crown light] a drooping curtain of leaves */
WL_P.tree.willow=(c,px,py,sp,o)=>{
  const k=sp.c, s=o.s*(sp.sz||1), w=o.sway;
  WL_SH(c,px,py,14);
  rect(c,px+13,py+10,6,22,k[0]);
  ell(c,px+16+w,py+0,19*s,13*s,k[1]); ell(c,px+14+w,py-3,13*s,8*s,k[2]);
  c.lineWidth=2; c.lineCap='round';
  for(let i=0;i<11;i++){
    const sx=px+16+(i-5)*3.2, len=15+((i*7)%5)*2.2;
    c.strokeStyle=(i&1)?k[1]:k[2];
    const sw=Math.sin(o.time*1.3+i*0.8)*1.2;
    c.beginPath(); c.moveTo(sx+w*0.4,py+3); c.quadraticCurveTo(sx+w*0.8+sw,py+3+len*0.55,sx+w*0.5+sw*1.5,py+3+len); c.stroke();
  }
  c.lineCap='butt';
};
/* c: [stalk, highlight, node, leaf] three tall canes */
WL_P.tree.bamboo=(c,px,py,sp,o)=>{
  const k=sp.c, w=o.sway;
  ell(c,px+16,py+30,13,4,'rgba(0,0,0,0.2)');
  const cane=[[7,-14],[14,-19],[21,-11]];
  for(let i=0;i<3;i++){
    const sx=px+cane[i][0], top=py+cane[i][1]-(((o.h*5+i*2)|0)%4), sway=w*0.6*(1+i*0.2);
    c.fillStyle=k[0]; c.beginPath(); c.moveTo(sx,py+32); c.lineTo(sx+4,py+32); c.lineTo(sx+4+sway,top); c.lineTo(sx+sway,top); c.closePath(); c.fill();
    rect(c,sx+0.5,py+31,1,0,k[1]); wlLine(c,sx+1,py+32,sx+1+sway,top,1,k[1]);
    for(let n=py+26;n>top+3;n-=8){ const u=(py+32-n)/(py+32-top); rect(c,sx-0.5+sway*u,n,5,1.6,k[2]); }
    ell(c,sx+2+sway-4,top+5,5,1.8,k[3]); ell(c,sx+2+sway+4,top+9,5,1.8,k[3]); ell(c,sx+2+sway,top+1,2,4,k[3]);
  }
};
/* c: [trunk, crown dark, crown mid, crown light]; flat umbrella top */
WL_P.tree.acacia=(c,px,py,sp,o)=>{
  const k=sp.c, s=o.s*(sp.sz||1), w=o.sway;
  WL_SH(c,px,py,12);
  c.lineCap='round'; c.strokeStyle=k[0]; c.lineWidth=3.4;
  c.beginPath(); c.moveTo(px+16,py+31); c.lineTo(px+16,py+16); c.stroke();
  c.lineWidth=2.6; c.beginPath(); c.moveTo(px+16,py+17); c.lineTo(px+7,py+5); c.moveTo(px+16,py+17); c.lineTo(px+25,py+4); c.stroke(); c.lineCap='butt';
  ell(c,px+16+w,py+2,20*s,6.5*s,k[1]); ell(c,px+16+w,py-1,17*s,4.8*s,k[2]); ell(c,px+13+w,py-3,9*s,2.6*s,k[3]);
  ell(c,px+5+w,py+6,7*s,3*s,k[1]); ell(c,px+27+w,py+5,7*s,3*s,k[1]);
};
/* c: [trunk, crown dark, crown mid, crown light]; bloom: flower dots; vines hang from the crown */
WL_P.tree.jungle=(c,px,py,sp,o)=>{
  const k=sp.c, s=o.s*(sp.sz||1), w=o.sway;
  WL_SH(c,px,py,15);
  rect(c,px+11,py+10,10,22,k[0]); wlTri(c,px+11,py+32,px+5,py+32,px+11,py+20,k[0]); wlTri(c,px+21,py+32,px+27,py+32,px+21,py+20,k[0]);
  rect(c,px+17,py+10,4,22,'rgba(0,0,0,0.2)');
  circ(c,px+16+w,py-4,19*s,k[1]); circ(c,px+5+w,py+6,13*s,k[1]); circ(c,px+27+w,py+6,13*s,k[1]);
  circ(c,px+16+w,py+2,14*s,k[2]); circ(c,px+10+w,py-8,9*s,k[3]); circ(c,px+23+w,py-6,7*s,k[3]);
  c.lineWidth=1.5;
  for(const v of [[5,12],[14,15],[24,13],[29,11]]){
    const sw=Math.sin(o.time*1.2+v[0])*1.4;
    c.strokeStyle=k[1]; c.beginPath(); c.moveTo(px+v[0]+w,py+v[1]); c.quadraticCurveTo(px+v[0]+sw,py+v[1]+7,px+v[0]+sw*1.4,py+v[1]+13); c.stroke();
    circ(c,px+v[0]+sw*1.4,py+v[1]+13,1.4,k[3]);
  }
  if(sp.bloom&&!o.picked){ for(let i=0;i<4;i++) circ(c,px+WL_DOTS[i][0]+w+2,py+WL_DOTS[i][1]+2,1.9,sp.bloom); }
  if(sp.fruit&&!o.picked){ for(let i=4;i<7;i++) circ(c,px+WL_DOTS[i][0]+w,py+WL_DOTS[i][1]+4,1.9,sp.fruit); }
};
/* c: [roots/trunk, crown dark, crown mid, crown light]; moss: pale hanging strands */
WL_P.tree.mangrove=(c,px,py,sp,o)=>{
  const k=sp.c, s=o.s*(sp.sz||1), w=o.sway;
  WL_SH(c,px,py,14);
  c.lineCap='round'; c.strokeStyle=k[0]; c.lineWidth=2.6;
  for(const r of [[4,31],[16,32],[28,31],[9,32],[23,32]]){ c.beginPath(); c.moveTo(px+16,py+22); c.quadraticCurveTo(px+(16+r[0])/2,py+16,px+r[0],py+r[1]); c.stroke(); }
  c.lineCap='butt';
  rect(c,px+14,py+9,5,15,k[0]);
  circ(c,px+16+w,py-1,14*s,k[1]); circ(c,px+8+w,py+7,9*s,k[1]); circ(c,px+24+w,py+7,9*s,k[1]); circ(c,px+16+w,py+3,10*s,k[2]); circ(c,px+13+w,py-4,6*s,k[3]);
  if(sp.moss){ c.strokeStyle=sp.moss; c.lineWidth=1.3; for(let i=0;i<6;i++){ const sx=px+6+i*4; c.beginPath(); c.moveTo(sx+w*0.5,py+9); c.lineTo(sx+Math.sin(o.time+i)*1.2+w*0.5,py+16+(i%3)*3); c.stroke(); } }
};
/* c: [trunk, crown dark, crown mid, crown light, spark]; glows after dark */
WL_P.tree.glow=(c,px,py,sp,o)=>{
  const k=sp.c, s=o.s*(sp.sz||1), w=o.sway, t=o.time;
  circ(c,px+16,py+6,24,sp.halo||'rgba(60,230,200,0.10)');
  WL_SH(c,px,py,13);
  rect(c,px+12,py+14,8,18,k[0]); rect(c,px+17,py+14,3,18,'rgba(0,0,0,0.25)');
  circ(c,px+16+w,py-2,17*s,k[1]); circ(c,px+7+w,py+7,12*s,k[1]); circ(c,px+25+w,py+7,12*s,k[1]);
  circ(c,px+16+w,py+4,13*s,k[2]); circ(c,px+12+w,py-5,8*s,k[3]);
  for(let i=0;i<WL_DOTS.length;i++){
    const a=0.45+0.55*Math.sin(t*2.1+i*1.7+o.x);
    c.fillStyle=k[4].replace('A',a.toFixed(2)); c.fillRect(px+WL_DOTS[i][0]+w,py+WL_DOTS[i][1]+4,2,2);
  }
  if(!o.picked) wlGlowLight(px,py-6,70,0.45);
};
/* c: [trunk, mark] bare branches */
WL_P.tree.dead=(c,px,py,sp,o)=>{
  const k=sp.c;
  WL_SH(c,px,py,10);
  rect(c,px+13,py+4,6,28,k[0]); rect(c,px+13,py+4,1,28,k[1]);
  c.lineCap='round';
  for(const b of [[16,12,5,-2,3],[16,17,28,3,3],[16,7,11,-12,2.6],[16,9,24,-9,2.4],[5,-2,1,-9,1.6],[28,3,31,-4,1.6],[11,-12,7,-17,1.4],[24,-9,28,-15,1.4]]) wlLine(c,px+b[0],py+b[1],px+b[2],py+b[3],b[4],k[0]);
  c.lineCap='butt';
  if(sp.moss){ rect(c,px+13,py+20,6,3,sp.moss); }
};
/* c: [trunk, crown dark, crown light]; a fat bottle trunk with a tuft of branches */
WL_P.tree.baobab=(c,px,py,sp,o)=>{
  const k=sp.c, w=o.sway;
  WL_SH(c,px,py,14);
  c.fillStyle=k[0]; c.beginPath(); c.moveTo(px+3,py+32); c.quadraticCurveTo(px+9,py+22,px+9,py+7); c.lineTo(px+23,py+7); c.quadraticCurveTo(px+23,py+22,px+29,py+32); c.closePath(); c.fill();
  c.fillStyle='rgba(0,0,0,0.2)'; c.beginPath(); c.moveTo(px+19,py+7); c.lineTo(px+23,py+7); c.quadraticCurveTo(px+23,py+22,px+29,py+32); c.lineTo(px+22,py+32); c.quadraticCurveTo(px+19,py+20,px+19,py+7); c.fill();
  for(let i=0;i<4;i++) rect(c,px+11+i*3,py+14+i*3,1,5,'rgba(0,0,0,0.15)');
  wlLine(c,px+12,py+8,px+5,py-1,3,k[0]); wlLine(c,px+16,py+8,px+16,py-5,3,k[0]); wlLine(c,px+20,py+8,px+27,py-1,3,k[0]);
  for(const t of [[5,-2],[16,-7],[27,-2]]){ circ(c,px+t[0]+w,py+t[1],8,k[1]); circ(c,px+t[0]-2+w,py+t[1]-2,5,k[2]); }
};
/* c: [stalk, cap dark, cap light, spot]; glow: a lit giant mushroom */
WL_P.tree.giantmush=(c,px,py,sp,o)=>{
  const k=sp.c, s=o.s*(sp.sz||1), t=o.time;
  if(sp.glow) circ(c,px+16,py+2,26,'rgba('+sp.glow+',0.12)');
  WL_SH(c,px,py,10);
  c.fillStyle=k[0]; c.beginPath(); c.moveTo(px+12,py+32); c.quadraticCurveTo(px+14,py+18,px+13,py+6); c.lineTo(px+19,py+6); c.quadraticCurveTo(px+18,py+18,px+20,py+32); c.closePath(); c.fill();
  rect(c,px+17,py+8,2,24,'rgba(0,0,0,0.12)');
  ell(c,px+16,py+4,17*s,10*s,k[1]); ell(c,px+14,py+1,13*s,6*s,k[2]);
  c.fillStyle=k[3];
  for(let i=0;i<5;i++){ const a=sp.glow?0.5+0.5*Math.sin(t*2+i*1.6+o.x):1; c.globalAlpha=a; c.fillRect(px+7+i*4.4,py-2+(i%3)*3,3,2); }
  c.globalAlpha=1;
  if(sp.glow&&!o.picked) wlGlowLight(px,py-4,80,0.45);
};

/* ---------------- FLOWERS (each draws one bloom; stem base at fy+6) ---------------- */
const wlStem=(c,fx,fy,h,col)=>rect(c,fx,fy,2,h,col||'#2f6b34');
WL_P.flower.daisy=(c,fx,fy,sp,o,i)=>{
  const k=sp.c; wlStem(c,fx,fy,6,k[2]);
  rect(c,fx-2,fy+4,3,1,k[2]);
  if(o.picked) return;
  for(let j=0;j<6;j++){ const a=j*1.047; circ(c,fx+1+Math.cos(a)*3,fy+Math.sin(a)*3,1.6,k[0]); }
  circ(c,fx+1,fy,1.7,k[1]);
};
WL_P.flower.tulip=(c,fx,fy,sp,o)=>{
  const k=sp.c; wlStem(c,fx,fy+1,6,k[2]); wlTri(c,fx+2,fy+6,fx+6,fy+2,fx+2,fy+3,k[2]||'#2f6b34');
  if(o.picked) return;
  c.fillStyle=k[0]; c.beginPath(); c.moveTo(fx-2,fy-2); c.lineTo(fx-1,fy+3); c.lineTo(fx+3,fy+3); c.lineTo(fx+4,fy-2); c.lineTo(fx+2.5,fy-0.5); c.lineTo(fx+1,fy-3.5); c.lineTo(fx-0.5,fy-0.5); c.closePath(); c.fill();
  rect(c,fx,fy-1,2,3,k[1]);
};
WL_P.flower.bell=(c,fx,fy,sp,o)=>{
  const k=sp.c;
  c.strokeStyle=k[2]; c.lineWidth=1.5; c.beginPath(); c.moveTo(fx+1,fy+8); c.quadraticCurveTo(fx+1,fy-1,fx+5,fy-1); c.stroke();
  if(o.picked) return;
  ell(c,fx+5,fy+1,2,2.6,k[0]); ell(c,fx+2.5,fy+3.5,1.8,2.4,k[0]); ell(c,fx+7.5,fy+4,1.6,2.2,k[0]);
  rect(c,fx+4,fy+3,2,1,k[1]); rect(c,fx+2,fy+5.5,1.6,1,k[1]);
};
WL_P.flower.spike=(c,fx,fy,sp,o)=>{
  const k=sp.c; wlStem(c,fx,fy+2,7,k[2]);
  if(o.picked) return;
  for(let j=0;j<6;j++){ const yy=fy+2-j*1.9; rect(c,fx-1+(j&1?1:0),yy,3,2,j%2?k[0]:k[1]); }
  rect(c,fx,fy-9,1.6,1.6,k[0]);
};
WL_P.flower.lily=(c,fx,fy,sp,o)=>{
  const k=sp.c; wlStem(c,fx,fy+1,6,k[2]); wlTri(c,fx+2,fy+6,fx+6,fy+3,fx+2,fy+4,k[2]);
  if(o.picked) return;
  c.fillStyle=k[0]; c.beginPath();
  for(let j=0;j<10;j++){ const a=-1.57+j*0.628, r=(j&1)?1.8:4.6; const x=fx+1+Math.cos(a)*r, y=fy+Math.sin(a)*r; if(j===0) c.moveTo(x,y); else c.lineTo(x,y); }
  c.closePath(); c.fill();
  circ(c,fx+1,fy,1.4,k[1]);
};
WL_P.flower.poppy=(c,fx,fy,sp,o)=>{
  const k=sp.c; wlStem(c,fx,fy+1,6,k[2]);
  if(o.picked) return;
  circ(c,fx+1,fy,3.8,k[0]); circ(c,fx-1,fy-0.8,2.6,k[0]); circ(c,fx+3,fy-0.6,2.6,k[0]);
  circ(c,fx+1,fy,1.4,k[1]);
};
WL_P.flower.puff=(c,fx,fy,sp,o)=>{
  const k=sp.c; wlStem(c,fx,fy+1,6,k[2]);
  if(o.picked) return;
  circ(c,fx+1,fy,3.5,k[0]); rect(c,fx-1,fy-2,1,1,k[1]); rect(c,fx+2,fy-1,1,1,k[1]); rect(c,fx,fy+1,1,1,k[1]); rect(c,fx+3,fy+1,1,1,k[1]); rect(c,fx+1,fy-3,1,1,k[1]);
};
WL_P.flower.sun=(c,fx,fy,sp,o)=>{
  const k=sp.c; wlStem(c,fx,fy+2,9,k[2]); rect(c,fx-3,fy+7,3,1.5,k[2]);
  if(o.picked) return;
  for(let j=0;j<8;j++){ const a=j*0.785; circ(c,fx+1+Math.cos(a)*4.2,fy+Math.sin(a)*4.2,1.7,k[0]); }
  circ(c,fx+1,fy,3,k[1]);
};
WL_P.flower.cluster=(c,fx,fy,sp,o)=>{
  const k=sp.c; wlStem(c,fx,fy+2,5,k[2]);
  if(o.picked) return;
  const p=[[-2,-1],[2,-2],[4,0],[0,1],[3,2],[-1,-4],[2,-4]];
  for(let j=0;j<p.length;j++) circ(c,fx+1+p[j][0],fy+p[j][1],1.25,j%2?k[1]:k[0]);
};
WL_P.flower.orchid=(c,fx,fy,sp,o)=>{
  const k=sp.c; wlStem(c,fx,fy+2,6,k[2]);
  if(o.picked) return;
  ell(c,fx-2,fy-1,2.8,1.7,k[0]); ell(c,fx+4,fy-1,2.8,1.7,k[0]); ell(c,fx+1,fy-3,1.8,2.6,k[0]); ell(c,fx+1,fy+1.5,2.1,1.7,k[1]);
};
WL_P.flower.succulent=(c,fx,fy,sp,o)=>{
  const k=sp.c;
  for(let j=0;j<7;j++){ const a=-3.14+j*0.52; ell(c,fx+1+Math.cos(a)*3.4,fy+6+Math.sin(a)*2.2,2.4,1.1,j&1?k[2]:k[3]||k[2]); }
  circ(c,fx+1,fy+5,2,k[2]);
  if(!o.picked){ wlStem(c,fx,fy,5,k[2]); circ(c,fx+1,fy-0.5,2.1,k[0]); circ(c,fx+1,fy-0.5,0.8,k[1]); }
};
WL_P.flower.cotton=(c,fx,fy,sp,o)=>{
  const k=sp.c; wlStem(c,fx,fy+2,7,k[2]);
  if(o.picked) return;
  circ(c,fx+1,fy,2.2,k[0]); circ(c,fx-1.5,fy+2.6,2,k[0]); circ(c,fx+3.5,fy+2.4,2,k[0]); rect(c,fx,fy-1,1,1,k[1]);
};
WL_P.flower.rose=(c,fx,fy,sp,o)=>{
  const k=sp.c; wlStem(c,fx,fy+1,6,k[2]); rect(c,fx+2,fy+5,2,2,k[2]);
  if(o.picked) return;
  circ(c,fx+1,fy,3.7,k[0]); circ(c,fx+1,fy,2.4,k[1]); circ(c,fx+1,fy,1.2,k[0]);
};
WL_P.flower.snowdrop=(c,fx,fy,sp,o)=>{
  const k=sp.c;
  c.strokeStyle=k[2]; c.lineWidth=1.4; c.beginPath(); c.moveTo(fx+1,fy+8); c.quadraticCurveTo(fx+1,fy+1,fx+4,fy+1); c.stroke();
  rect(c,fx-2,fy+6,3,1,k[2]); rect(c,fx+3,fy+6,3,1,k[2]);
  if(o.picked) return;
  ell(c,fx+4,fy+3.2,2.1,3,k[0]); rect(c,fx+3.4,fy+5.6,1.4,1,k[1]);
};
WL_P.flower.glowbloom=(c,fx,fy,sp,o)=>{
  const k=sp.c, a=0.5+0.5*Math.sin(o.time*2+fx*0.4);
  wlStem(c,fx,fy+1,6,k[2]);
  if(o.picked) return;
  circ(c,fx+1,fy,6,'rgba('+(sp.glow||'120,255,230')+','+(0.12+0.12*a).toFixed(2)+')');
  c.fillStyle=k[0]; c.beginPath();
  for(let j=0;j<8;j++){ const an=-1.57+j*0.785, r=(j&1)?1.6:4; const x=fx+1+Math.cos(an)*r, y=fy+Math.sin(an)*r; if(j===0) c.moveTo(x,y); else c.lineTo(x,y); }
  c.closePath(); c.fill(); circ(c,fx+1,fy,1.2,k[1]);
  if(NIGHT>0.12&&wlI0(fx,fy)) lights.push({x:fx+1,y:fy,r:34,s:0.3,w:0});
};
const wlI0=(fx,fy)=>((fx*7+fy*3)|0)%3===0;

/* ---------------- BUSHES ---------------- */
/* c: [dark, mid, light]; berry: dots; snow: a white cap; spikes */
WL_P.bush.bush=(c,px,py,sp,o)=>{
  const k=sp.c;
  ell(c,px+16,py+24,12,5,'rgba(0,0,0,0.18)'); ell(c,px+16,py+19,12,8,k[0]); ell(c,px+12,py+17,7,5,k[1]); ell(c,px+21,py+19,6,4,k[2]||k[1]);
  if(sp.snow){ ell(c,px+14,py+14,8,2.6,'#f6fbff'); ell(c,px+22,py+16,4,1.8,'#f6fbff'); }
  if(sp.berry&&!o.picked){ const p=[[9,18],[15,21],[22,17],[19,22],[12,14],[24,21]]; for(const q of p) circ(c,px+q[0],py+q[1],1.8,sp.berry); }
  if(sp.spikes){ for(let i=0;i<7;i++) wlLine(c,px+6+i*3,py+15+(i%2)*2,px+5+i*3.3,py+9+(i%3)*2,1,k[2]||k[1]); }
};
/* c: [stem dark, stem light, tuft]; head: cattail heads */
WL_P.bush.reed=(c,px,py,sp,o)=>{
  const k=sp.c, w=o.sway;
  ell(c,px+16,py+28,12,3,'rgba(0,0,0,0.15)');
  c.lineCap='round';
  for(let i=0;i<5;i++){
    const sx=px+7+i*4.4, len=(sp.tall||16)+((i*5+((o.h*9)|0))%8), sw=Math.sin(o.time*1.5+i)*1.4+w*0.5;
    c.strokeStyle=i&1?k[0]:k[1]; c.lineWidth=1.6; c.beginPath(); c.moveTo(sx,py+29); c.quadraticCurveTo(sx+sw*0.4,py+29-len*0.6,sx+sw+(i-2)*0.9,py+29-len); c.stroke();
    if(sp.head&&!o.picked&&i%2===0){ const hx=sx+sw+(i-2)*0.9, hy=py+29-len; ell(c,hx,hy+2,1.7,4,sp.head); }
  }
  c.lineCap='butt';
  ell(c,px+16,py+28,11,2.4,k[2]||k[0]);
};
/* c: [dark, light]; broad radial fronds; glow tips */
WL_P.bush.fern=(c,px,py,sp,o)=>{
  const k=sp.c, n=sp.n||8;
  ell(c,px+16,py+27,11,3,'rgba(0,0,0,0.16)');
  c.lineCap='round';
  for(let i=0;i<n;i++){
    const a=-3.14+(i/(n-1))*3.14, sw=Math.sin(o.time*1.4+i)*0.5, L=sp.len||13;
    const ex=px+16+Math.cos(a)*L+sw, ey=py+26+Math.sin(a)*L*0.9;
    c.strokeStyle=k[0]; c.lineWidth=3.4; c.beginPath(); c.moveTo(px+16,py+27); c.quadraticCurveTo(px+16+Math.cos(a)*L*0.5,py+27+Math.sin(a)*L*1.05,ex,ey+1.5); c.stroke();
    c.strokeStyle=k[1]; c.lineWidth=1.3; c.beginPath(); c.moveTo(px+16,py+27); c.quadraticCurveTo(px+16+Math.cos(a)*L*0.5,py+27+Math.sin(a)*L*1.05,ex,ey+1.5); c.stroke();
    if(sp.tip&&!o.picked) circ(c,ex,ey+1,1.3,sp.tip);
  }
  c.lineCap='butt';
  if(sp.tip&&!o.picked) wlGlowLight(px,py+8,40,0.25);
};
/* c: [a, b] dry spiky shrub */
WL_P.bush.dry=(c,px,py,sp,o)=>{
  const k=sp.c;
  ell(c,px+16,py+27,11,3,'rgba(0,0,0,0.16)');
  for(let i=0;i<11;i++){
    const a=-3.14+i/10*3.14+0.1, L=9+((i*7)%6);
    wlLine(c,px+16,py+27,px+16+Math.cos(a)*L*1.1,py+27+Math.sin(a)*L,1.4,i&1?k[0]:k[1]);
    if(sp.dot&&!o.picked&&i%3===0) circ(c,px+16+Math.cos(a)*L*1.1,py+27+Math.sin(a)*L,1.3,sp.dot);
  }
};
/* c: [dark, light] low mound dusted with blooms */
WL_P.bush.heath=(c,px,py,sp,o)=>{
  const k=sp.c;
  ell(c,px+16,py+25,14,5,'rgba(0,0,0,0.16)'); ell(c,px+16,py+22,13,7,k[0]); ell(c,px+14,py+19,9,4,k[1]);
  if(sp.berry&&!o.picked) for(let i=0;i<10;i++) rect(c,px+6+((i*7)%19),py+16+((i*5)%9),2,2,sp.berry);
};
WL_P.bush.tumble=(c,px,py,sp,o)=>{
  const k=sp.c, r=7+o.h*1.5;
  ell(c,px+16,py+27,9,3,'rgba(0,0,0,0.15)');
  c.lineWidth=1.2; c.strokeStyle=k[0];
  for(let i=0;i<5;i++){ c.beginPath(); c.ellipse(px+16,py+21,r,r*(0.5+0.1*i),i*0.7,0,6.283); c.stroke(); }
  c.strokeStyle=k[1]; c.beginPath(); c.arc(px+16,py+21,r*0.7,0.3,4.2); c.stroke();
};
/* c: [pad, shade, spine]; berry: fruit on the pads */
WL_P.bush.pear=(c,px,py,sp,o)=>{
  const k=sp.c;
  ell(c,px+16,py+27,12,4,'rgba(0,0,0,0.18)');
  ell(c,px+13,py+21,7,6,k[0]); ell(c,px+22,py+17,6,5,k[0]); ell(c,px+11,py+13,5,4,k[1]); ell(c,px+22,py+10,4,3.5,k[1]);
  c.fillStyle=k[2]; for(let i=0;i<9;i++) c.fillRect(px+7+((i*5)%17),py+9+((i*7)%15),1,1);
  if(sp.berry&&!o.picked){ circ(c,px+11,py+10,1.8,sp.berry); circ(c,px+22,py+8,1.8,sp.berry); circ(c,px+25,py+15,1.7,sp.berry); }
};

/* ---------------- MUSHROOMS ---------------- */
/* c: [cap, spot, stem]; v: cap | tall | cluster | flat; glow: 'r,g,b' halo */
WL_P.mush.cap=(c,px,py,sp,o)=>{
  const k=sp.c, v=sp.v||'cap', x=o.x, y=o.y, t=o.time;
  const mx=px+10+((hash(x,y,70)*10)|0), my=py+16+((hash(x,y,71)*8)|0);
  if(sp.glow) circ(c,mx,my-2,9,'rgba('+sp.glow+','+(0.18+0.1*Math.sin(t*2+x)).toFixed(2)+')');
  ell(c,mx,my+5,5,1.6,'rgba(0,0,0,0.18)');
  if(o.picked){ rect(c,mx-1,my+3,3,2,k[2]||'#e9e2d0'); return; }
  const stem=k[2]||'#e9e2d0';
  if(v==='cluster'){
    for(const q of [[-5,2,3,2.4],[0,-1,4,3],[5,3,3,2.4],[-2,4,2.6,2],[3,-3,2.4,2]]){ rect(c,mx+q[0],my+q[1]+2,1.6,4,stem); ell(c,mx+q[0]+0.8,my+q[1]+2,q[2],q[3],k[0]); }
    rect(c,mx-1,my,1,1,k[1]); rect(c,mx+4,my+3,1,1,k[1]);
  } else if(v==='tall'){
    rect(c,mx-1,my-3,2,9,stem); ell(c,mx,my-3,6,3,k[0]); rect(c,mx-3,my-4,1,1,k[1]); rect(c,mx+1,my-5,1,1,k[1]); rect(c,mx-1,my-2,3,1,'rgba(0,0,0,0.2)');
  } else if(v==='flat'){
    ell(c,mx,my+3,6.5,2.8,k[0]); ell(c,mx,my+2.4,5,1.7,k[1]); rect(c,mx-1,my+4,3,1,stem);
  } else {
    rect(c,mx-1,my,3,5,stem); ell(c,mx,my,5,3.5,k[0]);
    rect(c,mx-2,my-2,1,1,k[1]); rect(c,mx+1,my-1,1,1,k[1]); rect(c,mx+2,my-2,1,1,k[1]);
  }
  if(sp.glow&&NIGHT>0.12) lights.push({x:mx,y:my,r:46,s:0.35,w:0});
};

/* ---------------- ROCKS ---------------- */
/* c: [dark, mid, light]; moss | snow | spot */
WL_P.rock.boulder=(c,px,py,sp,o)=>{
  const k=sp.c;
  ell(c,px+16,py+25,12,5,'rgba(0,0,0,0.2)'); ell(c,px+16,py+19,11,8,k[0]); ell(c,px+14,py+16,7,4,k[1]); ell(c,px+11,py+14,3,1.6,k[2]);
  if(sp.moss) { ell(c,px+14,py+13,7,2.4,sp.moss); ell(c,px+22,py+17,3,2,sp.moss); }
  if(sp.snow) { ell(c,px+14,py+13,8,3,'#f6fbff'); ell(c,px+22,py+16,3.5,2,'#f6fbff'); }
  if(sp.spot){ rect(c,px+19,py+17,2,2,sp.spot); rect(c,px+10,py+19,2,1,sp.spot); rect(c,px+16,py+21,2,2,sp.spot); }
};
WL_P.rock.crystal=(c,px,py,sp,o)=>{
  const k=sp.c, t=o.time;
  if(sp.glow) circ(c,px+16,py+18,16,'rgba('+sp.glow+','+(0.12+0.06*Math.sin(t*2+o.x)).toFixed(2)+')');
  ell(c,px+16,py+26,12,4,'rgba(0,0,0,0.2)');
  wlTri(c,px+16,py+2,px+22,py+26,px+10,py+26,k[0]); wlTri(c,px+16,py+2,px+22,py+26,px+16,py+26,k[1]);
  wlTri(c,px+8,py+10,px+13,py+27,px+3,py+27,k[0]); wlTri(c,px+8,py+10,px+13,py+27,px+8,py+27,k[1]);
  wlTri(c,px+25,py+14,px+29,py+27,px+20,py+27,k[0]); wlTri(c,px+25,py+14,px+29,py+27,px+25,py+27,k[1]);
  rect(c,px+14,py+9,1,8,k[2]); rect(c,px+7,py+15,1,6,k[2]);
  if(sp.glow&&NIGHT>0.12) lights.push({x:px+16,y:py+16,r:56,s:0.4,w:0});
};
WL_P.rock.mesa=(c,px,py,sp,o)=>{
  const k=sp.c;
  ell(c,px+16,py+28,13,4,'rgba(0,0,0,0.2)');
  rect(c,px+9,py+8,14,20,k[0]); rect(c,px+8,py+20,16,8,k[0]); rect(c,px+9,py+12,14,2,k[1]); rect(c,px+9,py+18,14,2,k[1]); rect(c,px+8,py+24,16,2,k[1]);
  rect(c,px+19,py+8,4,20,'rgba(0,0,0,0.18)'); ell(c,px+16,py+8,8,3,k[2]);
};
WL_P.rock.cairn=(c,px,py,sp,o)=>{
  const k=sp.c;
  ell(c,px+16,py+28,11,4,'rgba(0,0,0,0.2)');
  ell(c,px+16,py+24,10,5,k[0]); ell(c,px+16,py+18,7.5,4,k[1]); ell(c,px+16,py+13,5,3,k[2]); ell(c,px+16,py+9,3,2.2,k[0]);
  rect(c,px+12,py+22,3,1,'rgba(255,255,255,0.25)');
};
WL_P.rock.geode=(c,px,py,sp,o)=>{
  const k=sp.c;
  ell(c,px+16,py+25,12,5,'rgba(0,0,0,0.2)'); ell(c,px+16,py+19,11,8,k[0]); ell(c,px+14,py+16,7,4,k[1]);
  ell(c,px+17,py+19,5,3.4,k[2]); ell(c,px+17,py+19,3,1.9,sp.core||'#fff'); rect(c,px+15,py+17,1,1,'#fff');
};
WL_P.rock.ice=(c,px,py,sp,o)=>{
  const k=sp.c;
  ell(c,px+16,py+27,12,4,'rgba(0,0,0,0.16)');
  wlTri(c,px+4,py+27,px+12,py+10,px+19,py+27,k[0]); wlTri(c,px+14,py+27,px+22,py+6,px+29,py+27,k[1]); wlTri(c,px+12,py+10,px+19,py+27,px+14,py+27,k[2]);
  wlTri(c,px+22,py+6,px+29,py+27,px+24,py+27,'rgba(255,255,255,0.35)'); rect(c,px+21,py+11,1,6,'#fff');
};
WL_P.rock.slab=(c,px,py,sp,o)=>{
  const k=sp.c;
  ell(c,px+16,py+26,13,4,'rgba(0,0,0,0.2)');
  c.fillStyle=k[0]; c.beginPath(); c.moveTo(px+3,py+26); c.lineTo(px+7,py+12); c.lineTo(px+25,py+9); c.lineTo(px+29,py+26); c.closePath(); c.fill();
  c.fillStyle=k[1]; c.beginPath(); c.moveTo(px+7,py+12); c.lineTo(px+25,py+9); c.lineTo(px+24,py+14); c.lineTo(px+8,py+16); c.closePath(); c.fill();
  rect(c,px+12,py+19,6,1,k[2]); rect(c,px+17,py+22,5,1,k[2]);
  if(sp.moss) ell(c,px+12,py+11,6,2,sp.moss);
};

/* ---------------- STUMPS ---------------- */
/* c: [bark, ring light, ring dark]; moss | snow | cap (a mushroom on top) | v: log */
WL_P.stump.stump=(c,px,py,sp,o)=>{
  const k=sp.c;
  if(sp.v==='log'){
    ell(c,px+16,py+27,15,4,'rgba(0,0,0,0.2)');
    rect(c,px+3,py+17,26,9,k[0]); rect(c,px+3,py+17,26,2,'rgba(255,255,255,0.12)'); rect(c,px+3,py+24,26,2,'rgba(0,0,0,0.2)');
    ell(c,px+4,py+21.5,2.6,4.6,k[1]); ell(c,px+4,py+21.5,1.3,2.5,k[2]);
    wlLine(c,px+14,py+17,px+17,py+10,2.4,k[0]); wlLine(c,px+22,py+17,px+26,py+12,2,k[0]);
    if(sp.moss) ell(c,px+17,py+17,7,1.8,sp.moss);
    if(sp.snow) ell(c,px+16,py+17,11,2.4,'#f6fbff');
    return;
  }
  ell(c,px+16,py+26,11,4,'rgba(0,0,0,0.2)');
  rect(c,px+8,py+14,16,12,k[0]); rect(c,px+20,py+14,4,12,'rgba(0,0,0,0.2)');
  ell(c,px+16,py+14,8,4,k[1]); ell(c,px+16,py+14,4,2,k[2]);
  if(sp.moss){ ell(c,px+11,py+19,3.4,6,sp.moss); ell(c,px+14,py+14,4,1.6,sp.moss); }
  if(sp.snow) ell(c,px+16,py+13,8,3,'#f6fbff');
  if(sp.cap&&!o.picked){ rect(c,px+18,py+8,2,5,'#e9e2d0'); ell(c,px+19,py+8,3.5,2.4,sp.cap); }
  if(sp.vine) { wlLine(c,px+9,py+14,px+12,py+25,1.4,sp.vine); wlLine(c,px+22,py+14,px+19,py+25,1.4,sp.vine); }
};

/* ---------------- species -> tile painters ---------------- */
function wlTierFX(c,sp,x,y,px,py,time){
  const t=sp.tier; if(!(t>=4)) return;
  for(let i=0;i<t-2;i++){
    const s=(Math.sin(time*2.6+hash(x,y,70+i)*6.28)+1)/2; if(s<0.45) continue;
    const x0=px+5+hash(x,y,80+i)*22, y0=py+2+hash(x,y,90+i)*24-s*3;
    const col=t===4?'rgb(255,222,110)':t===5?'rgb(255,150,225)':wlHex([time*90+i*110,1,0.72]);
    c.globalAlpha=Math.min(1,s*1.1); c.fillStyle=col; c.fillRect(x0-0.5,y0-2,1.4,5); c.fillRect(x0-2,y0-0.5,5,1.4); c.globalAlpha=1;
  }
}
function wlPaintTree(c,x,y,px,py,time,sp,picked){
  const h=hash(x,y,3); const sp0=sp; if(sp.tier===6) sp=wlChroma(sp,time);
  const P=WL_P.tree[sp.k]||WL_P.tree.round;
  P(c,px,py,sp,{x:x,y:y,time:time,sway:Math.sin(time*1.2+x*1.7+y)*1.2,s:0.9+h*0.3,h:h,picked:picked});
  wlTierFX(c,sp0,x,y,px,py,time);
}
function wlPaintFlowerTile(c,x,y,px,py,sp,time,picked){
  const sp0=sp; if(sp.tier===6) sp=wlChroma(sp,time);
  const n=1+((hash(x,y,50)*3)|0), P=WL_P.flower[sp.k]||WL_P.flower.daisy;
  for(let i=0;i<n;i++){
    const fx=px+6+((hash(x,y,51+i)*20)|0), fy=py+10+((hash(x,y,55+i)*16)|0);
    P(c,fx,fy,sp,{x:x,y:y,time:time,picked:picked},i);
  }
  wlTierFX(c,sp0,x,y,px,py,time);
}
function wlPaintTile(c,cat,x,y,px,py,time,sp,picked){
  const sp0=sp; if(sp.tier===6) sp=wlChroma(sp,time);
  const P=WL_P[cat][sp.k]||WL_P[cat][Object.keys(WL_P[cat])[0]];
  P(c,px,py,sp,{x:x,y:y,time:time,sway:0,s:1,h:hash(x,y,3),picked:picked});
  wlTierFX(c,sp0,x,y,px,py,time);
}

/* ---------------- icons for the Collection Log ---------------- */
const wlIconCache={};
function wlSpeciesIcon(sp,known){
  const key=sp.id+(known?'':'?');
  if(wlIconCache[key]) return wlIconCache[key];
  const cv=document.createElement('canvas'); cv.width=64; cv.height=64;
  const c=cv.getContext('2d');
  c.imageSmoothingEnabled=false;
  const o={x:0,y:0,time:0.6,sway:0,s:1,h:0.3,picked:false};
  c.save();
  if(sp.cat==='tree'){
    const s=(sp.k==='cactus'&&sp.v==='barrel')?1.8:1;
    if(s===1) c.setTransform(1,0,0,1,16,23); else c.setTransform(s,0,0,s,32-16*s,40-22*s);
    (WL_P.tree[sp.k]||WL_P.tree.round)(c,0,0,sp,o);
  } else if(sp.cat==='flower'){
    c.setTransform(3.4,0,0,3.4,32-4.2*3.4,38-11*3.4);
    (WL_P.flower[sp.k]||WL_P.flower.daisy)(c,3,6,sp,o,0);
  } else {
    const s=sp.cat==='rock'?1.9:2.0;
    c.setTransform(s,0,0,s,32-16*s,36-19*s);
    (WL_P[sp.cat][sp.k]||WL_P[sp.cat][Object.keys(WL_P[sp.cat])[0]])(c,0,0,sp,o);
  }
  c.restore();
  if(!known){
    const d=c.getImageData(0,0,64,64), a=d.data;
    for(let i=0;i<a.length;i+=4){ if(a[i+3]>0){ a[i]=26; a[i+1]=40; a[i+2]=34; a[i+3]=Math.min(255,a[i+3]); } }
    c.putImageData(d,0,0);
  }
  wlIconCache[key]=cv;
  return cv;
}
