'use strict';
/* ===== A HOTBAR: ten slots you fill from your pack, 1-0 to choose a slot, Z to use what is in it ===== */
const HB=()=>{ const s=g.story||(g.story={}); if(!s.hb) s.hb={slots:new Array(10).fill(null),sel:0,cur:0}; const h=s.hb; for(let i=0;i<10;i++) if(h.slots[i]&&!g.inv[h.slots[i]]) h.slots[i]=null; return h; };
for(let i=0;i<10;i++) KEYMAP[String((i+1)%10)]='n'+((i+1)%10);
const hbIndexOf=k=>k==='n0'?9:(+k.slice(1)-1);
const HB_AUTO=['shovel','axe','pickaxe','fishrod','lantern','glass','compass','emberwand','lumenorb','gustcharm','wardcharm','runestone','seekerbeetle','tmap','specs'];
/* ---- tools only work while they are in your hands: selected in the hotbar ---- */
function heldId(){ const h=HB(); return h.slots[h.sel]||null; }
function isHeld(id){ return !!g.inv[id]&&heldId()===id; }
function holdText(id){ return 'Hold the '+ITEMS[id].name+' first: put it on your hotbar (open your pack, press a number key) and select that slot.'; }
let hbFocus='grid';

/* ---- the bar on the screen ---- */
const hbEl=document.createElement('div'); hbEl.className='hotbar'; hbEl.id='hotbar'; hbEl.hidden=true;
document.getElementById('stage').appendChild(hbEl);
let hbSig='';
function hbFill(box,h,opts){
  box.innerHTML='';
  for(let i=0;i<10;i++){
    const d=document.createElement('div'), id=h.slots[i];
    d.className='hbs'+(opts.sel===i?' sel':'');
    const n=document.createElement('span'); n.className='hbn'; n.textContent=(i+1)%10; d.appendChild(n);
    if(id&&ITEMS[id]){ d.appendChild(iconCanvas(id)); if(g.inv[id]>1){ const c=document.createElement('span'); c.className='hbc'; c.textContent=g.inv[id]; d.appendChild(c); } d.title=ITEMS[id].name; }
    d.addEventListener('click',e=>{ e.stopPropagation(); opts.click(i); });
    box.appendChild(d);
  }
}
function hbRender(){
  const h=HB(), vis=g.mode==='play'&&g.scene!=='none';
  const sig=(vis?1:0)+'|'+h.sel+'|'+h.slots.map(id=>id?id+g.inv[id]:'').join(',');
  if(sig===hbSig) return; hbSig=sig;
  hbEl.hidden=!vis; if(!vis) return;
  hbFill(hbEl,h,{sel:h.sel,click:i=>{ if(g.mode!=='play') return; h.sel=i; hbSig=''; blip(); const id=h.slots[i]; if(id) toast(ITEMS[id].name,900); }});
}
{
  const _upd=updateHud;
  updateHud=function(){
    _upd();
    /* new tools go to the bar by themselves, after the first (empty) slot */
    const h=HB();
    for(const id of HB_AUTO) if(g.inv[id]&&!h.slots.includes(id)&&!(h.auto&&h.auto[id])){
      const free=h.slots.findIndex((v,i)=>i>0&&!v); if(free<0) break;
      h.slots[free]=id; (h.auto||(h.auto={}))[id]=1; hbSig='';
    }
    hbRender();
  };
}
/* ---- using the selected slot ---- */
function hbUse(){
  const h=HB(), id=h.slots[h.sel];
  if(!id){ toast('Empty slot. Open your pack (I) and press a number key on an item to put it here.',2600); return false; }
  if(id==='shovel'){ wlDig(); return true; }
  if((id==='axe'||id==='pickaxe')){ toast(id==='axe'?'Face a tree or stump and press Z to chop it.':'Face a rock and press Z to break it up.',2400); return true; }
  if(id==='fishrod'){ toast('Face water and press Z to cast.',2200); return true; }
  el.dNote.textContent='';
  useItem(id);
  const t=el.dNote.textContent; el.dNote.textContent='';
  if(t&&g.mode==='play') toast(t,3600);
  hbSig=''; return true;
}
{
  const _useHeld=useItem;
  useItem=function(id){
    const it=ITEMS[id];
    if(it&&it.use==='magic'&&!isHeld(id)){ closeInv(); say('',[holdText(id)]); return; }
    _useHeld(id);
  };
}
/* ---- keys ---- */
{
  const _press=press;
  press=function(k){
    const h=HB();
    if(g.mode==='play'){
      if(/^n\d$/.test(k)){ h.sel=hbIndexOf(k); hbSig=''; blip(); const id=h.slots[h.sel]; toast(id?ITEMS[id].name:'Empty slot',900); return; }
      if(k==='z'&&!g.target&&h.slots[h.sel]&&(g.scene==='world'||g.scene==='shop')){ if(hbUse()) return; }
      if(k==='z'&&!g.target&&g.scene==='world'&&g.inv.fishrod&&!isHeld('fishrod')){ const f=wlFront(); if(tileAt(f.x,f.y)===T.WATER){ toast(holdText('fishrod'),3200); return; } }
    }
    if(g.mode==='inv'){ if(hbInvKey(k)) return; }
    _press(k);
  };
}
/* ---- the pack: grid on top, hotbar underneath ---- */
function hbSetFocus(f,idx){
  hbFocus=f; const h=HB();
  if(f==='hb'){ h.cur=Math.max(0,Math.min(9,idx===undefined?h.cur:idx)); const id=h.slots[h.cur]; if(id){ const i=invIds().indexOf(id); if(i>=0) g.invSel=i; } }
}
function hbAssign(slot){
  const h=HB(); let id=null, from=-1;
  if(hbFocus==='hb'){ from=h.cur; id=h.slots[from]; } else id=invIds()[g.invSel];
  if(!id){ blip(); return; }
  const prev=h.slots[slot], at=h.slots.indexOf(id);
  if(from<0&&at>=0&&at!==slot){ h.slots[at]=prev&&prev!==id?prev:null; }
  if(from>=0&&from!==slot) h.slots[from]=prev;
  h.slots[slot]=id; h.cur=slot; if(h.auto) h.auto[id]=1;
  el.dNote.textContent=ITEMS[id].name+' is on your hotbar: slot '+((slot+1)%10)+'.'; blip(); hbSig=''; renderInv();
}
function hbInvKey(k){
  const h=HB(), n=invIds().length, cols=WL_COLS, total=Math.max(18,Math.ceil(n/cols)*cols);
  if(/^n\d$/.test(k)){ hbAssign(hbIndexOf(k)); return true; }
  if(hbFocus==='hb'){
    if(k==='left'||k==='right'){ hbSetFocus('hb',h.cur+(k==='left'?-1:1)); blip(); el.dNote.textContent=''; renderInv(); return true; }
    if(k==='up'){ hbFocus='grid'; blip(); renderInv(); return true; }
    if(k==='down') return true;
    if(k==='c'){ if(h.slots[h.cur]){ h.slots[h.cur]=null; el.dNote.textContent='Slot cleared.'; hbSig=''; blip(); renderInv(); } return true; }
    if(k==='z'){ const id=h.slots[h.cur]; if(id) useItem(id); return true; }
    return false;
  }
  if(k==='down'&&g.invSel+cols>=total){ hbSetFocus('hb'); blip(); renderInv(); return true; }
  if(k==='c'){ const id=invIds()[g.invSel]; if(id){ const free=h.slots.findIndex(v=>!v); if(free>=0) hbAssign(free); else { el.dNote.textContent='The hotbar is full. Press a number key to swap one out.'; blip(); } } return true; }
  return false;
}
{
  const body=document.querySelector('#inv .invbody'), box=document.createElement('div'); box.className='invhb'; box.id='invHb';
  const lab=document.createElement('div'); lab.className='invhbl'; lab.id='invHbL';
  const wrap=document.createElement('div'); wrap.className='invhbw'; wrap.appendChild(lab); wrap.appendChild(box);
  body.parentNode.insertBefore(wrap,document.getElementById('notes'));
  const _ri=renderInv;
  renderInv=function(){
    _ri();
    const h=HB();
    hbFill(box,h,{sel:hbFocus==='hb'?h.cur:-1,click:i=>{
      if(hbFocus==='grid'&&invIds()[g.invSel]&&h.slots[i]!==invIds()[g.invSel]){ hbAssign(i); return; }
      hbSetFocus('hb',i); el.dNote.textContent=''; renderInv();
    }});
    lab.textContent='HOTBAR  -  Z uses the selected slot  -  number keys put the chosen item in a slot (C: first free slot, or clear if in the bar)';
  };
}
{
  const _open=openInv;
  openInv=function(){ hbFocus='grid'; _open(); };
}

/* ---- say so in the item text ---- */
for(const id of ['shovel','axe','pickaxe','fishrod','lantern','glass','compass'].concat(Object.keys(typeof MAGIC!=='undefined'?MAGIC:{}))){
  if(ITEMS[id]&&!ITEMS[id].holdNote){ ITEMS[id].holdNote=1; ITEMS[id].desc+=' Only works while you hold it: select it on your hotbar.'; }
}
