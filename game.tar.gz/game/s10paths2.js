/* ===== MORE FORKS (v1.25.4) =====
   s10paths.js made failure branch the story. This file makes the rest of the road branch too, with forks you walk into
   by choice as well as by ledger. Everything is remembered, and everything is paid back later, in a place you can name:

     early       The Informer's Offer (after the Silent Castle / the Wild Art): sell Mallow, refuse, or play both sides.
                 -> Mallow starts the watchtower talk with a strike against you, or a free pass.
     act II      Ruddock's Night Watch (Red) / Halbeak at the Wall (Crown): a friend on the other side of the road, or a snub.
     the king    Eider's Burden: take the bent crown, carry his words word for word, or ask for the ward's own word.
     the dream   Whom You Tell: Cinder, Halbeak, Mallow, or no one. The summit is built from this.
     the summit  The Parley's price moves by who stands behind you (and who does not).
     the eve     The Vigil: one night, one companion (or none). Plus: repay the Hearth's loan.
     the road    Friends open the Gate of Ash / Gold. The bent crown opens one and shuts the other.
     the Tree    Three endings that only some roads reach: The Ferry, The Witness, The Heir.
   Every fork is recorded in g.story.s2.path.seen and listed in the Journal under "Your Path".
   Adds D10.forks(). */
(function(){
'use strict';
const D10=window.D10=window.D10||{};
const P=()=>{ const q=s2(); const p=q.path||(q.path={}); if(!p.seen) p.seen={}; if(!p.friend) p.friend={}; return p; };
const mark=(id,v)=>{ P().seen[id]=v||'y'; };
const L=()=>s2().led||{};
const later=(fn,ms)=>setTimeout(()=>{ try{ fn(); }catch(e){ console.warn('paths2',e); } },ms);
const note=(t,ms)=>later(()=>{ if(g.mode==='play'||g.mode==='dialog') toast(t,ms||7000); },2600);
const MAL=()=>(typeof H3!=='undefined'?H3:'Hermit Mallow');
const cap=(k,n)=>{ try{ S6.cap(k,n); }catch(e){} };

/* ---------------- an item ---------------- */
ITEMS.bentcrown={name:`King Eider's Bent Crown`,desc:`A crown that has been sat on, and put down, and not picked up for a hundred years. The Crown's soldiers will know it. The Hollow will know it too.`,use:'note',note:`It is lighter than it looks. It is heavier than it should be.`,nogift:true};
RICON.bentcrown=(R,C,E)=>{ R(3,8,10,4,'#c9a24a'); R(3,5,2,4,'#c9a24a'); R(7,4,2,5,'#c9a24a'); R(11,5,2,4,'#c9a24a'); R(5,9,2,1,'#6a4a1a'); R(9,11,2,1,'#6a4a1a'); };

/* ---------------- the interlude runner ----------------
   A fork is a scene that runs when a chapter finishes, before the next one begins. */
const INTER={};
const inter=(chapters,def)=>chapters.forEach(c=>{ (INTER[c]=INTER[c]||[]).push(def); });
const FORKS=[];
const fork=(id,name,chapters,when,run)=>{ FORKS.push({id,name}); inter(chapters,{id,when,run}); };
D10.forks=()=>FORKS.map(f=>({id:f.id,name:f.name,seen:P().seen[f.id]||null}));
{
  const _fin=S2.finish;
  S2.finish=function(id,msg){
    const list=INTER[id], args=arguments;
    if(!list) return _fin.apply(this,args);
    const p=P();
    const todo=list.filter(d=>{ try{ return !p.seen[d.id]&&d.when(); }catch(e){ return false; } });
    const step=()=>{
      const d=todo.shift();
      if(!d) return _fin.apply(null,args);
      p.seen[d.id]='seen';
      try{ d.run(step); }catch(e){ console.warn('fork',d.id,e); step(); }
    };
    step();
  };
}

/* ======================================================
   1. THE INFORMER'S OFFER  (after chapter 6)
   ====================================================== */
fork('informer',`The Informer's Offer`,['c6r','c6c'],()=>true,(next)=>{
  const red=s2red(), who=red?'Mistress Vesper':'The Royal Clerk';
  seq([[who,red?
      [`Sit, Detective. A small matter, and an easy one.`,`The hermit Mallow walks both roads and answers to neither. A duck who goes where he likes is a duck who can carry anything. Tell me when he is seen with the other side, and I will see you advanced.`,`I am not asking you to lie. I am asking you to remember, aloud, to me.`]:
      [`A word, Detective, before you go.`,`The hermit Mallow walks both roads and answers to neither. The Crown would like to know where he goes, and with whom. A report, now and then. A small purse, now and then.`,`I am not asking you to lie. I am asking you to remember, aloud, to us.`]]],()=>{
    choose(who,`What do you say?`,[
      `"Of course. It is only information."`,
      `"No. He is my friend, and that is the end of it."`,
      `"Yes." (And tell Mallow everything, that night.)`],k=>{
      const p=P();
      if(k===0){
        p.informed=1; mark('informer','sold'); g.crumbs+=80; coin(); s2led('trust',-1); s2led('pride',1);
        seq([[who,[`Good. You will find me generous.`,`(She presses a purse into your wing. It is heavier than a favour should be.)`]]],()=>{ toast(`Mallow will hear of this, one way or another.`,4200); next(); });
      } else if(k===1){
        mark('informer','refused'); s2led('trust',1); s2led('truth',1);
        seq([[who,[`I see.`,`(She writes something down anyway. You cannot see what.)`]]],()=>{ toast(`You kept faith with Mallow.`,3600); next(); });
      } else {
        p.warned=1; mark('informer','double'); s2led('trust',1); s2led('lie',1);
        seq([[who,[`Good. You will find me generous.`]],
          [MAL(),[`(He listens to all of it, at the foot of his fire, without moving.)`,`You lied to her for me. I do not love that you had to. I will not forget that you did.`,`I will tell you something I have told no one. If it ever comes to a cell, I will come. I do not need to be asked twice.`]]],()=>{ toast(`Mallow owes you one. You owe a lie to somebody.`,4800); next(); });
      }
    },1);
  });
});

/* Mallow remembers it at the watchtower */
{
  const _p=S2.persuade;
  S2.persuade=function(d){
    try{
      if(d&&d.who===MAL()&&s2at('c8c',1)&&d.lose&&!d.__p2){
        d.__p2=1; const p=P(), lose=d.lose;
        if(p.informed&&!p.warned&&!p.informedUsed){ p.informedUsed=1; p.mLoss=Math.max(p.mLoss||0,1); note(`Someone has been talking to Mallow. He starts with one strike against you.`,6500); }
        d.lose=function(){
          if(p.warned&&p.mLoss===1&&!p.warnedUsed){ p.warnedUsed=1; p.mLoss=0; toast(`Mallow gives you one more chance. He remembers who you lied to.`,4600); return say(MAL(),[`I know why you said that. Again.`],()=>S2.persuade(d)); }
          return lose.apply(this,arguments);
        };
      }
    }catch(e){ console.warn('paths2 mallow',e); }
    return _p.apply(this,arguments);
  };
}

/* ======================================================
   2. A FRIEND ACROSS THE ROAD  (after chapter 7)
   ====================================================== */
fork('watch',`Ruddock's Night Watch`,['c7r'],()=>true,(next)=>{
  const l=L(), p=P();
  if((l.kin||0)>=2){
    seq([['Warden Ruddock',[`(He is on the wall at the end of the day, alone, with a lantern he has not lit.)`,`You went to the houses. Every one. I counted. I have not been that surprised since my wife told me she loved me.`,`There is a watch tonight. It is not an honour. It is cold, and the stew is bad. But nobody has asked to stand it with me in eleven years.`]]],()=>{
      choose('Warden Ruddock',`Stand the watch with him?`,[`Take a lantern and walk the wall with him.`,`Thank him, and decline.`],k=>{
        if(k===0){ p.friend.ruddock=1; mark('watch','stood'); s2led('kin',1); cap('hearth',1); seq([['Warden Ruddock',[`...The stew is bad, isn't it.`,`Nobody tells me. It is a long way to the end of the wall. Come on.`]]],()=>{ toast(`Ruddock will speak for you, on either side of the road.`,5000); next(); }); }
        else { mark('watch','declined'); next(); }
      },1);
    });
  } else if((l.pride||0)>=2){
    seq([['Warden Ruddock',[`(He stops you in the yard, in front of the gate wardens, and does not lower his voice.)`,`You did the kin's work. Every house. In the style of a duck being watched.`,`I have wardens who have never seen a red duck do a kindness without checking who was looking. They watched you. They are not stupid. They saw what it was for.`]]],()=>{
      choose('Warden Ruddock',`In front of everyone.`,[`"You are right. I did it to be seen. I will do it again to be useful."`,`Say nothing, and walk on.`],k=>{
        if(k===0){ s2led('pride',-1); s2led('kin',1); s2led('truth',1); p.friend.ruddock=1; mark('watch','apologised'); seq([['Warden Ruddock',[`(A long silence in the yard.)`,`Hm. That is the first honest thing anyone has said to me this week. Go and eat.`]]],()=>{ toast(`Ruddock respects you for it.`,4200); next(); }); }
        else { p.snub=1; s2led('pride',1); mark('watch','snubbed'); toast(`The wardens will remember. Ruddock will not make it easy.`,4600); next(); }
      },1);
    });
  } else { mark('watch','none'); next(); }
});
fork('wall',`Halbeak at the Wall`,['c7c'],()=>!!s2fl('march'),(next)=>{
  const m=s2fl('march'), p=P();
  if(m==='went'){
    seq([['Captain Halbeak',[`(He is on the south wall at dusk, in the place the horn sounded. He does not turn.)`,`Three hundred and twelve ducks. I gave the order. I will give it again, if they tell me to, and I hate that I know that.`,`There is a Hollow warden I once served with. If a letter could reach him... I cannot write it. I would write it as a captain. I need it written as a man.`]]],()=>{
      choose('Captain Halbeak',`He holds out a folded page.`,[`Take it, and carry it exactly as written.`,`Take it, and soften it where it is proud.`,`Refuse. It is not yours to carry.`],k=>{
        if(k===0){ p.letter='carried'; p.friend.halbeak=1; mark('wall','carried'); s2led('trust',1); s2led('truth',1); cap('crown',1); toast(`The letter is yours to keep faith with.`,3800); next(); }
        else if(k===1){ p.letter='altered'; mark('wall','altered'); s2led('lie',1); s2led('mercy',1); toast(`You changed a captain's words. Somebody will read the difference.`,4800); next(); }
        else { mark('wall','refused'); s2led('pride',1); next(); }
      },2);
    });
  } else {
    seq([['Captain Halbeak',[`(He is on the south wall, where the order was sealed and never carried out.)`,`The lords call it insubordination. I call it the only decision I have made in thirty years that I would make again.`,`I will have to say so, at some point, to their faces. I would like it if somebody who was not a soldier were in the room.`]]],()=>{
      choose('Captain Halbeak',`He is not asking for much.`,[`"I will stand in the room."`,`"Stand down quietly. Do not give them the fight."`],k=>{
        if(k===0){ p.friend.halbeak=1; mark('wall','witness'); s2led('crown',1); s2led('truth',1); cap('crown',1); toast(`Halbeak will remember who stood in the room.`,4600); next(); }
        else { mark('wall','quiet'); s2led('mercy',1); next(); }
      },1);
    });
  }
});

/* ======================================================
   3. EIDER'S BURDEN  (after chapter 10)
   ====================================================== */
fork('burden',`Eider's Burden`,['c10'],()=>true,(next)=>{
  const p=P();
  seq([['King Eider',[`(At the door, the king says, without looking at you:)`,`I have one thing to ask. I have asked it of no one. You may refuse, and you may ask me for something in return.`,`The crown on the floor is mine, and the word I spoke is mine, and the thing I must say to each side is mine. I can give you only one of the three. Choose which you can carry.`]]],()=>{
    choose('King Eider',`Which do you take?`,[
      `The bent crown. (The Crown will know it. The Hollow will know it too.)`,
      `His message, word for word, for both sides to hear.`,
      `"Give me the word of the ward itself."`],k=>{
      if(k===0){
        addItem('bentcrown'); p.bentCrown=1; mark('burden','crown'); s2led('crown',2); s2led('ember',-1); cap('crown',1); cap('hearth',-1);
        seq([['King Eider',[`Take it. I have not been able to lift it in years. If it is light in your wing, you have been truthful with me.`]]],()=>{ toast(`The Crown's line will let you through. The Hollow's line will not.`,5200); next(); });
      } else if(k===1){
        p.eiderMsg=1; mark('burden','message'); s2led('truth',1); s2led('trust',1);
        seq([['King Eider',[`Then hear it exactly. I will say it three times. You will say it back.`,`"I am sorry. I was afraid. I wrote shelter, and I signed what they gave me. I would like to be forgiven, and I do not ask to be."`]]],()=>{ toast(`You carry the king's own words.`,4200); next(); });
      } else {
        p.askedWord=1; mark('burden','word'); s2led('pride',2);
        seq([['King Eider',[`No.`,`(It is the gentlest refusal you have ever heard.)`,`It is a word that cannot be taught by a mouth. The Tree knows it. Ask the Tree, if the Tree will tell you. I would not give it to you if I could.`]]],()=>{ toast(`The Wood will hear that you asked for the word.`,4600); next(); });
      }
    },2);
  });
});

/* ======================================================
   4. WHOM YOU TELL  (after the dream, chapter 11)
   ====================================================== */
fork('told',`Whom You Tell`,['c11'],()=>true,(next)=>{
  const p=P(), ans=s2fl('childAns');
  const open=ans===1?`You came out of the dream with a feather you did not have going in. It is red, and it is an old red.`:ans===3?`You came out of the dream with the kingdom still under your feet, and a question that was not about the kingdom.`:`You came out of the dream knowing something that cannot be unknown.`;
  seq([['',[open,`Everyone will want to know what you saw. You can say it once, tonight, to one person. You do not have the strength to say it twice before the summit.`]]],()=>{
    choose('',`Who hears it first?`,[
      `Elder Cinder, in Emberwick.`,
      `Captain Halbeak, at Kingsbill.`,
      `Hermit Mallow, at his fire.`,
      `No one. Keep it for the Tree.`],k=>{
      if(k===0){ p.told='cinder'; s2led('ember',1); cap('hearth',1); cap('crown',-1); mark('told','cinder'); toast(`Cinder knows first. The Crown will notice.`,4600); }
      else if(k===1){ p.told='halbeak'; s2led('crown',1); cap('crown',1); cap('hearth',-1); mark('told','halbeak'); toast(`Halbeak knows first. The Hollow will notice.`,4600); }
      else if(k===2){ p.told='mallow'; s2led('trust',1); cap('mallow',1); mark('told','mallow'); toast(`Mallow carries it to both sides, as he always has.`,4600); }
      else { p.told='none'; cap('sleepers',2); s2led('truth',1); mark('told','none'); toast(`You keep it. The Wood will remember that you did.`,4600); }
      next();
    },3);
  });
});

/* ======================================================
   5. THE PARLEY'S PRICE
   ====================================================== */
{
  const _p=S2.persuade;
  S2.persuade=function(d){
    try{
      if(d&&d.who==='The Parley'&&!d.__p2){
        d.__p2=1; const p=P(), why=[]; let adj=0;
        if(p.told==='cinder'&&!p.friend.halbeak){ adj++; why.push(`You told Cinder first, and the Crown's lords were not asked: +1 hurdle.`); }
        if(p.told==='halbeak'&&!p.friend.ruddock){ adj++; why.push(`You told Halbeak first, and the Hollow was not asked: +1 hurdle.`); }
        if(p.told==='none'){ adj++; why.push(`You told no one, so no one is prepared: +1 hurdle.`); }
        if(p.told==='mallow'){ adj--; why.push(`Mallow carried what you saw to both sides: -1 hurdle.`); }
        if(p.friend.ruddock&&p.friend.halbeak){ adj--; why.push(`A friend stands behind you on each side of the road: -1 hurdle.`); }
        if(p.eiderMsg){ adj--; why.push(`You carry the king's own words: -1 hurdle.`); }
        if(p.warned&&!p.cold&&!p.informed){ adj--; why.push(`Mallow speaks for you from the back of the tent: -1 hurdle.`); }
        if(p.informed&&s2led('trust')<2){ adj++; why.push(`Word of what you sold has got out: +1 hurdle.`); }
        if(p.letter==='altered'){ adj++; why.push(`The altered letter is read aloud, with the changes marked: +1 hurdle.`); }
        if(p.letter==='carried'){ adj--; why.push(`The letter you carried faithfully is on the table: -1 hurdle.`); }
        if(p.askedWord){ adj++; why.push(`It is known that you asked a dying king for his word: +1 hurdle.`); }
        d.need=Math.max(3,d.need+adj);
        P().parleyAdj=adj;
        if(why.length) note(why.join('  '),why.length>2?11000:8000);
      }
    }catch(e){ console.warn('paths2 parley',e); }
    return _p.apply(this,arguments);
  };
}

/* ======================================================
   6. THE VIGIL  (after chapter 14: the night before the Wood)
   ====================================================== */
fork('vigil',`The Vigil`,['c14r','c14c','c14k'],()=>true,(next)=>{
  const p=P(), red=s2red();
  const night=()=>{
    const opts=[], fn=[];
    opts.push(`Sit with Hermit Mallow, at his fire.`); fn.push(()=>{ p.vigil='mallow'; s2led('trust',1); cap('mallow',1); mark('vigil','mallow'); seq([[MAL(),[`You came and sat. That is the whole of the lesson, and most people never learn it.`,`I will walk in front of you, if the Wood lets me. If it does not, I will walk behind.`]]],()=>{ toast(`Mallow will find you in the Wood, and the Ward will have more time.`,5000); next(); }); });
    if(red||(D10.loose&&D10.loose().poppy)){ opts.push(`Sit with Little Poppy, who has packed too many sandwiches.`); fn.push(()=>{ p.vigil='poppy'; s2led('kin',1); mark('vigil','poppy'); seq([['Little Poppy',[`I made one for the wisps. Do you think they eat?`,`Mama says things that are only sad get less sad if someone sits with them. I think the Wood is only sad.`]]],()=>{ toast(`The wisps will be gentler with a child's sandwich in your pack.`,5000); next(); }); }); }
    if(red){ opts.push(`Send word across the road to Captain Halbeak.`); fn.push(()=>{ p.friend.halbeak=1; p.vigil='across'; s2led('crown',1); mark('vigil','across'); seq([['',[`You write four lines. They are not clever. A rider takes them out into the dark.`,`At dawn there is an answer, in a soldier's careful hand: Halbeak has put your name on his gate list. Not as a prisoner.`]]],()=>{ toast(`The Crown's line will let you through.`,4600); next(); }); }); }
    else { opts.push(`Send word across the road to Warden Ruddock.`); fn.push(()=>{ p.friend.ruddock=1; p.vigil='across'; s2led('ember',1); mark('vigil','across'); seq([['',[`You write four lines. They are not clever. A warden takes them out into the dark.`,`At dawn there is an answer, in a gruff hand: Ruddock says the stew at the Hollow is better than the Crown's, and that you are to be let through.`]]],()=>{ toast(`The Hollow's line will let you through.`,4600); next(); }); }); }
    opts.push(`Sit alone with the fire, and think about all of it.`); fn.push(()=>{ p.vigil='alone'; s2led('truth',1); s2led('pride',-1); mark('vigil','alone'); seq([['',[`You sit until the fire is only a colour. You go through every choice you have made, in order, and you do not look away from the ones you would rather not.`,`It does not make you lighter. It makes you steadier, which is better.`]]],()=>{ toast(`The anchors will steady faster. You are harder to read.`,5000); next(); }); });
    choose('',`It is the last night before the Wood. Where do you spend it?`,opts,k=>fn[k](),opts.length-1);
  };
  if(p.debt&&!p.repaid){
    seq([['',[`There is a letter in your satchel you have not sent. It is addressed to Elder Cinder, and it says what you owe the Hearth for its first fire, and how you mean to pay.`]]],()=>{
      choose('',`The Hearth's loan.`,[`Send it. (It costs you some pride.)`,`Leave it in the satchel for now.`],k=>{
        if(k===0){ p.repaid=1; p.debt=0; s2led('pride',-1); s2led('truth',1); mark('repaid','y'); toast(`The Hearth's loan is repaid. The Gate of Gold will not remember it.`,5000); }
        night();
      },1);
    });
  } else night();
});

/* effects of the vigil, the friends, and the Tree's memory, in the scenes where they matter */
function giveFollow(S){
  const f=S.def&&S.def.follow; if(!f||S.follow) return;
  S.follow={name:f.name,pal:f.pal,head:f.head||null,scale:f.scale,x:g.px,y:g.py+10,dir:'down',phase:0,moving:false};
  S.trail=[]; for(let i=0;i<14;i++) S.trail.push({x:g.px,y:g.py+i});
}
{
  const _tm=sxTimer;
  sxTimer=function(S,secs,label,onEnd){
    if(label==='The Ward'){
      try{
        const p=P(), why=[];
        if(p.vigil==='mallow'){ secs+=15; why.push(`Mallow's fire last night: +15 seconds.`); }
        if(p.vigil==='poppy'){ secs+=10; why.push(`Poppy has told the wisps a story: +10 seconds.`); }
        if(p.vigil==='alone'){ secs+=20; why.push(`You went into the night already knowing the worst of yourself: +20 seconds.`); }
        if(p.vigil==='across'){ secs+=25; why.push(`Both lines are holding the ring: +25 seconds.`); }
        if(p.snub){ secs-=20; why.push(`The wardens you snubbed keep slow time: -20 seconds.`); }
        if(why.length) later(()=>{ if(g.scene==='sx') toast(why.join('  '),7500); },5600);
      }catch(e){}
    }
    return _tm.call(this,S,secs,label,onEnd);
  };
  const _en=sxEnter;
  sxEnter=function(id){
    const r=_en.apply(this,arguments);
    try{
      const S=SX.S, p=P(), why=[];
      if(S&&(id==='bgR'||id==='bgC')&&!S.__p2){
        S.__p2=1;
        const red=id==='bgR';
        const friend=red?(p.friend.halbeak||p.bentCrown):p.friend.ruddock;
        if(friend){
          S.fl.pass=1; S.fl.hint=1;
          why.push(red?(p.friend.halbeak?`Halbeak put your name on his gate list. The line parts without a word.`:`The soldiers see the bent crown in your satchel and stand aside. They do not ask how you came by it.`):`Ruddock's word got here first. The wardens step back from the road.`);
          for(const q of S.guards) q.off=()=>true;
        } else if(!red&&p.bentCrown){
          const n=S.npcs[0];
          if(n&&!S.fl.pass){ const ot=n.talk; n.talk=function(S2_,nn){ if(S2_.fl.pass) return ot.call(this,S2_,nn); say(n.name,[`That is the Crown's crown in your satchel. I can see the shape of it through the cloth.`,`I do not know what you intend to do with it. I will not find out by letting you through.`],null); }; S.fl.hint=1; }
          why.push(`The Hollow can feel the Crown's crown in your satchel. Ruddock will not talk.`);
        }
        if(p.askedWord){ S.guards.forEach(q=>{ if(typeof q.range==='number') q.range+=1; }); why.push(`Word has got round that you asked the king for the word of the ward.`); }
        if(why.length) note(why.join('  '),9000);
      }
      if(S&&id==='bw1'&&!S.__p2){
        S.__p2=1;
        if(p.vigil==='mallow'&&!S.follow){ giveFollow(S); why.push(`Mallow found you at the edge of the Wood after all.`); }
        if(p.vigil==='poppy'){ S.guards.forEach(q=>{ if(typeof q.range==='number') q.range=Math.max(3,q.range-1); }); why.push(`The wisps drift round the child's sandwich.`); }
        if(p.vigil==='alone'){ S.guards.forEach(q=>{ if(typeof q.speed==='number') q.speed=Math.max(18,q.speed-4); }); why.push(`You walk the Maze like someone who has already lost it once.`); }
        if(p.askedWord){ S.guards.forEach(q=>{ if(typeof q.range==='number') q.range+=1; }); why.push(`The Wood heard you ask for the word, and does not forgive it.`); }
        if(p.told==='none'){ S.guards.forEach(q=>{ if(typeof q.range==='number') q.range=Math.max(3,q.range-1); }); why.push(`You kept the dream for the Tree. The wisps know it.`); }
        if(why.length) note(why.join('  '),9500);
      }
    }catch(e){ console.warn('paths2 enter',e); }
    return r;
  };
}

/* ======================================================
   7. THREE ENDINGS ONLY SOME ROADS REACH
   Each is a way of answering the Tree's question that the usual four do not hold.
   They finish through the nearest ordinary ending, so the world after is built the same way.
   ====================================================== */
const VAR={
  ferry:{label:`"It will be crossed." Take no side of the door. Walk it, both ways, every dawn.`,base:'door',
    ok:()=>{ const p=P(), l=L(); return !!p.defected&&(l.truth||0)>=3&&(l.mercy||0)>=2; },
    closedWhy:`The Tree remembers that you changed sides once, and does not yet see what you changed it for.`},
  witness:{label:`"It will be told." Tell the whole of what you saw, to everyone, and let the telling be the door.`,base:'door',
    ok:()=>{ const p=P(), l=L(); return p.told==='none'&&(l.truth||0)>=4; },
    closedWhy:`You kept the dream for the Tree, but you have not yet been truthful enough to be believed when you tell it.`},
  heir:{label:`"It is safe, and I will go with them." Wake them, and carry the first one home.`,base:'wake',
    ok:()=>{ const p=P(), l=L(); return s2fl('childAns')===1&&grudge()!=='held'&&S6.get('sleepers')>=4&&!p.cold&&(l.kin||0)>=2; },
    closedWhy:`Gordamom's feather is in your satchel, but not every door in the Wood has agreed to know you.`}
};
function endVariant(S,key){
  const q=s2(), v=VAR[key];
  const A={
    ferry:[[`You say it: "It will be crossed."`,`The Tree does not hum. It listens, the way a ferryman listens for the far bank.`],
      ['Gordamom',[`Crossed. Not opened. Not kept. A word for a person, and not a place.`,`You have been on both banks. You will be on neither. Small one, that is the loneliest thing I know, and the most useful.`]],
      ['King Eider',[`(He sits up. He is not dying. He is looking at you the way one looks at a stranger who has your handwriting.)`,`I wrote a word that kept two peoples apart. You have chosen to be the thing that goes between them. I do not have the courage to thank you. I will learn.`]],
      ['',[`The Tree opens by one hand's width. In the gap there is nothing but a road. It is a road with a person on it, going one way at dawn, and the other way at dusk, carrying whatever is asked.`,`In a month, nobody will remember who first called you the Ferry. Everybody will use it.`]]],
    witness:[[`You say it: "It will be told."`,`You do not wait for the Tree to answer. You begin.`],
      [`The Tree`,[`(You say it all. The draft and the dream, the dead king and the living one, what Cinder said and what Halbeak did, and the things you did not mean to do and did anyway.)`,`It takes until midnight. Nobody leaves. When you finish, the humming has changed: it is no longer a lullaby. It is a word being said, over and over, by a great many voices that have been given a sentence at last.`]],
      ['Hermit Mallow',[`That is the first time I have heard it said whole. I thought it would be harder to hear.`,`It was only long.`]],
      ['',[`The Tree does not open. It does not stay shut. It becomes a place you can go to say what is true and have it written down. A bench. A book. A line that begins, each morning, with whoever came first.`]]],
    heir:[[`You say it: "It is safe, and I will go with them."`,`The Tree says nothing. But a branch, high up, bends by one finger's width, as though a hand had let go.`],
      ['Gordamom',[`(He is on his feet. He has been on his feet for a hundred years. He looks at his own hands as though he had mislaid them.)`,`Small one. You said "I am yours," in a dream, and I said it was not true, and I wished it were.`,`Take my arm. They will wake slowly. Somebody will have to be the first face they see that is not afraid, and I am afraid.`]],
      ['',[`You walk the first of the three hundred home. It is Bree. She does not speak for a long time. When she does, she says: "I knew your walk. I thought you were someone else."`,`By the end of the week, the lanterns are lit all the way to the Hollow, and the Crown has sent a cart of bread. Nobody asked for it.`]],
      ['Gordamom',[`I am not your father. I am an old duck who was asleep for a hundred years and is going to be very bad at the morning.`,`But I should like to be a bad father to you for a little while. If you will have it.`]]]
  }[key];
  const run=()=>{ q.endVariant=key; if(key==='ferry'||key==='witness') q.doorAt=s2now(); epilogue(v.base); };
  seq(A.map(a=>Array.isArray(a)&&typeof a[0]==='string'&&a.length===2&&Array.isArray(a[1])?a:['',a]),run);
}
{
  const _fc=finalChoice;
  finalChoice=function(S){
    try{
      const open=Object.keys(VAR).filter(k=>VAR[k].ok());
      if(open.length){
        const labels=['Answer as you would (the usual four).'].concat(open.map(k=>VAR[k].label));
        say('The Old Tree',[`(Before it asks, the clearing is quiet in a different way. The Tree seems to be looking, not at the road behind you, but at the shape of it.)`,`It has heard the road you walked. There are ways of answering it that only your road could make.`],()=>{
          choose('The Old Tree',`How do you answer?`,labels,k=>{ if(k===0) _fc.call(null,S); else endVariant(S,open[k-1]); },0);
        });
        return;
      }
    }catch(e){ console.warn('paths2 variants',e); }
    return _fc.apply(this,arguments);
  };
}

/* the epilogue carries the road: variant pages, and a coda for the friends and the debts */
{
  const _ec=epiCard;
  epiCard=function(label,title,sub,pages,theme,cb){
    try{
      if(label==='EPILOGUE'&&Array.isArray(pages)){
        const q=s2(), p=P(), v=q.endVariant;
        const T={ferry:[`Epilogue`,`It will be crossed.`],witness:[`Epilogue`,`It will be told.`],heir:[`Epilogue`,`It is safe, and I will go with them.`]};
        const PG={
          ferry:[`There is a road now between the Hollow and the kingdom. It has a door at neither end, only a person walking, and you are the person.`,`Soldiers on both sides learn the sound of your steps. They do not stop you. They have come to leave a cup out for you on the wall, on whichever side you are due.`,`Poppy asks, once, which side you are on. You tell her the truth, which is that you are on the road. She says that is not an answer. You say it is the only one you have.`],
          witness:[`The telling takes eleven nights. By the third, the lords of the Crown are sitting at the back. By the seventh, Cinder is at the front. By the eleventh, there are three hundred ducks awake in the clearing, and not one has been told what to feel.`,`The Book of Days is kept at the Old Tree, and anyone may add a page. Nobody burns one.`,`Mallow reads the first line aloud each morning. It is always yours.`],
          heir:[`Gordamom is very bad at mornings. He burns the first loaf. He sits on a stump in the Hollow's square and learns, from a child with a sandwich, what a lantern is for.`,`The three hundred wake in the order they fell asleep. The grudge, in the places where there was one, takes a season to go. In the places where there was not, nothing needs to.`,`Somebody, in the winter, asks you whose child you are. You say you are not sure. Gordamom, from the next chair, says: "Mine. For now. Pass the bread."`]
        };
        if(v&&PG[v]){ pages=PG[v]; title=T[v][1]; sub=`Whose child are you?`; }
        const coda=[];
        if(p.friend&&p.friend.ruddock&&!p.snub) coda.push(`Ruddock sends a note, in a hand that has never written a note before. It says the stew is still bad. It says come for it.`);
        if(p.friend&&p.friend.halbeak) coda.push(`Halbeak keeps your name on his gate list for the rest of his life. He has never once had to use it.`);
        if(p.snub) coda.push(`Ruddock never mentions the yard. He never forgets it either. The wardens leave a space for you at the end of every table.`);
        if(p.informed) coda.push(`Mallow never asks what you told them. He never has to. He sets one fewer cup out when he thinks you will not see.`);
        if(p.warned) coda.push(`Mallow tells the story, years on, of the duck who lied to a Mistress for his sake. He tells it badly, on purpose, so that nobody can say whom it was.`);
        if(p.bentCrown) coda.push(`You give the bent crown back to Eider, on the first spring morning. He puts it on a nail by the door and uses it for hanging his hat.`);
        if(p.repaid) coda.push(`The Hearth's coal goes out on the first night of spring, and is lit again from yours.`);
        else if(p.debt) coda.push(`The Hearth's loan is still on the books. Cinder has never asked for it. She keeps the page where she can see it.`);
        if(coda.length) pages=pages.concat(coda.slice(0,3));
      }
    }catch(e){ console.warn('paths2 epilogue',e); }
    return _ec.call(this,label,title,sub,pages,theme,cb);
  };
}

/* ---------------- the record ---------------- */
{
  const TXT={
    informer:{sold:`You sold what you knew of Mallow for a purse. He has heard.`,refused:`You were asked to inform on Mallow, and refused.`,double:`You promised to inform on Mallow, and told him everything instead.`},
    watch:{stood:`You stood the cold watch with Ruddock. He counts you a friend.`,apologised:`Ruddock rebuked you in the yard. You apologised aloud. He respects it.`,snubbed:`Ruddock rebuked you in the yard. You walked on. The wardens remember.`,declined:`Ruddock offered you the watch. You declined.`},
    wall:{carried:`You carried Halbeak's letter to the Hollow exactly as he wrote it.`,altered:`You altered Halbeak's letter before you carried it.`,refused:`You refused to carry Halbeak's letter.`,witness:`You promised to stand in the room when Halbeak faced his lords.`,quiet:`You told Halbeak to stand down quietly.`},
    burden:{crown:`From King Eider you took the bent crown.`,message:`From King Eider you took his message, word for word.`,word:`You asked King Eider for the word of the ward. He refused.`},
    told:{cinder:`After the dream you told Cinder first.`,halbeak:`After the dream you told Halbeak first.`,mallow:`After the dream you told Mallow first.`,none:`After the dream you told no one, and kept it for the Tree.`},
    vigil:{mallow:`The night before the Wood you sat with Mallow.`,poppy:`The night before the Wood you sat with Poppy.`,across:`The night before the Wood you sent word across the road.`,alone:`The night before the Wood you sat alone.`},
    repaid:{y:`You repaid the Hearth's loan.`}
  };
  const _je=journalExtra;
  journalExtra=function(sec,line){
    _je(sec,line);
    try{
      const p=P(), out=[];
      for(const k in TXT){ const v=p.seen[k]; if(v&&TXT[k][v]) out.push(TXT[k][v]); }
      const q=s2(); if(q.endVariant) out.push({ferry:`You answered the Tree: "It will be crossed."`,witness:`You answered the Tree: "It will be told."`,heir:`You answered the Tree: "It is safe, and I will go with them."`}[q.endVariant]);
      if(out.length){ sec('The Roads You Took'); out.forEach(t=>line(t,'jdim')); }
    }catch(e){}
  };
}
})();
