'use strict';
/* ===== EMBERWICK GAMES: a game for every red shop job and every red-town calendar event ===== */
Object.assign(MG_BY_TITLE,{
 'Rake the Ovens':'rake','Stir the Stew':'stew','Dip the Candles':'dip','Thread the Loom':'loom','Wind the Beetles':'beetle','Work the Bellows':'bellows','Grind the Herbs':'herbs',
 'The Banking of the Fires':'bank','Walk of the Cold Fires':'coldwalk','Ember Market':'market','Hearthside Hour':'hearth','Thread-Tying Day':'knots','Banking Song Night':'song'
});
const RGDIR={left:[-1,0],right:[1,0],up:[0,-1],down:[0,1]};
const RGCOL={up:'#e0452f',right:'#f2d45a',down:'#5aa0e0',left:'#6fd08a'};
const RGFREQ={up:262,right:330,down:392,left:523};
function rgRoom(c,top,bot,floor){ mgSky(c,top||'#2a1418',bot||'#4d2222'); rect(c,0,205,MGW,65,floor||'#3a1c1a'); rect(c,0,205,MGW,4,'#6a2e24'); }
function rgArrow(c,x,y,k,sz,col){
  const d=RGDIR[k]; if(!d) return; const px=-d[1], py=d[0];
  c.fillStyle=col; c.beginPath();
  c.moveTo(x+d[0]*sz,y+d[1]*sz); c.lineTo(x-d[0]*sz*0.7+px*sz,y-d[1]*sz*0.7+py*sz); c.lineTo(x-d[0]*sz*0.7-px*sz,y-d[1]*sz*0.7-py*sz); c.fill();
}
function rgFlame(c,x,y,sz,t,a){
  a=a===undefined?1:a; const w=Math.sin(t*14+x)*sz*0.12;
  c.globalAlpha=a; c.fillStyle='#e0452f'; c.beginPath(); c.moveTo(x-sz*0.5,y); c.quadraticCurveTo(x-sz*0.4+w,y-sz*0.9,x+w,y-sz*1.5); c.quadraticCurveTo(x+sz*0.4+w,y-sz*0.9,x+sz*0.5,y); c.fill();
  c.fillStyle='#ffb347'; c.beginPath(); c.moveTo(x-sz*0.28,y); c.quadraticCurveTo(x-sz*0.2+w,y-sz*0.6,x+w,y-sz*0.95); c.quadraticCurveTo(x+sz*0.2+w,y-sz*0.6,x+sz*0.28,y); c.fill();
  c.globalAlpha=1;
}
const RGR=(n)=>mgRnd(0,n)|0;

/* ================= SHOP JOBS ================= */

/* Bakery: rake the coal that flares */
MG.rake={
 hint:'Rake the oven that flares.', keys:'Left / Up / Right = oven',
 how:['A coal flares in one of three ovens.','Press the matching key: Left, Up or Right.','Rake it before it dies down. Ten flares.'],
 hud:s=>'Flare '+Math.min(10,s.n+1)+'/10  |  Raked '+s.hit,
 init(s){ s.n=0; s.hit=0; s.cur=-1; s.wait=0.6; s.life=0; s.dur=1; s.fx=[0,0,0]; },
 nxt(s){ s.n++; s.cur=-1; s.wait=0.3+Math.random()*0.45; s.score=s.hit; if(s.n>=10){ s.done=1; s.score=s.hit; } },
 update(s,dt){
  for(let i=0;i<3;i++) s.fx[i]=Math.max(0,s.fx[i]-dt*3);
  if(s.done) return;
  if(s.cur<0){ s.wait-=dt; if(s.wait<=0){ s.cur=RGR(3); s.life=0; s.dur=Math.max(0.5,1.05-s.n*0.055); s.msg=''; } }
  else { s.life+=dt; if(s.life>=s.dur){ s.msg='Too slow!'; mgTone(0); this.nxt(s); } }
 },
 press(s,k){
  const i={left:0,up:1,right:2}[k]; if(i===undefined||s.cur<0) return;
  if(i===s.cur){ s.hit++; s.fx[i]=1; s.msg='Raked!'; mgTone(1); } else { s.msg='Wrong oven!'; mgTone(0); }
  this.nxt(s);
 },
 draw(s,c,t){
  rgRoom(c,'#2a1814','#4a2a1e','#3a2418');
  for(let i=0;i<3;i++){
   const x=110+i*130, on=i===s.cur, r=on?1-s.life/s.dur:0;
   rect(c,x-48,70,96,120,'#5a4a42'); rect(c,x-40,82,80,92,'#1a0e0a'); c.fillStyle='#1a0e0a'; c.beginPath(); c.arc(x,82,40,Math.PI,0); c.fill();
   ell(c,x,172,34,8,'#2a1612');
   if(on){ rgFlame(c,x,170,26+r*26,t,0.4+r*0.6); c.strokeStyle='rgba(255,179,71,'+(0.25+0.5*r).toFixed(2)+')'; c.lineWidth=3; c.beginPath(); c.arc(x,140,50*(1.4-r*0.6),0,7); c.stroke(); }
   else rect(c,x-14,164,28,5,'#6a2a1a');
   if(s.fx[i]>0) for(let k=0;k<6;k++) circ(c,x+Math.sin(k*2+t)*20,150-s.fx[i]*40-k*4,2,'rgba(255,200,120,'+s.fx[i].toFixed(2)+')');
   rgArrow(c,x,222,['left','up','right'][i],12,on?'#ffd166':'#7a5a4a');
  }
  mgDuck(c,40,200,1.2,'#d9503f');
 }
};

/* Cafe: stir the stew clockwise */
MG.stew={
 hint:'Stir clockwise: Up, Right, Down, Left, over and over.', keys:'Arrows clockwise',
 how:['Stir the stew in a circle.','Press Up, Right, Down, Left in that order.','Round and round. Fast, but never backwards.'],
 hud:s=>Math.max(0,Math.ceil(s.dur-s.t))+'s  |  Stirs '+Math.floor(s.steps/4),
 ORD:['up','right','down','left'],
 init(s){ s.t=0; s.dur=14; s.steps=0; s.ang=0; s.bub=[]; s.shake=0; },
 update(s,dt){
  s.t+=dt; s.shake=Math.max(0,s.shake-dt*4); s.score=Math.min(10,s.steps/5);
  if(Math.random()<dt*6) s.bub.push({x:150+Math.random()*180,y:135,a:1});
  for(const b of s.bub){ b.y-=18*dt; b.a-=dt*0.9; } s.bub=s.bub.filter(b=>b.a>0);
  if(s.t>=s.dur){ s.done=1; s.score=Math.min(10,s.steps/5); }
 },
 press(s,k){
  if(!RGDIR[k]) return;
  if(k===this.ORD[s.steps%4]){ s.steps++; s.ang+=Math.PI/2; blip(); s.msg=''; }
  else { s.msg='Clockwise!'; s.shake=1; mgTone(0); }
 },
 draw(s,c,t){
  rgRoom(c,'#2e1a14','#4a2820','#3a2018');
  rect(c,130,150,220,70,'#222'); ell(c,240,150,110,30,'#3a3a3a'); ell(c,240,150,98,24,'#8a2a1e');
  for(const b of s.bub) circ(c,b.x,b.y+10,3,'rgba(255,170,120,'+b.a.toFixed(2)+')');
  const a=s.ang-Math.PI/2*0, sx=240+Math.cos(a)*62, sy=148+Math.sin(a)*14;
  c.strokeStyle='#c9a06a'; c.lineWidth=5; c.beginPath(); c.moveTo(sx+30+Math.cos(a)*20,40); c.lineTo(sx,sy); c.stroke();
  ell(c,sx,sy,9,5,'#e0b070');
  rect(c,150,215,180,10,'#5a2a1a'); for(let i=0;i<4;i++) rgFlame(c,175+i*43,215,10,t+i,0.9);
  mgDuck(c,60,205,1.3,'#d9503f');
  const nx=this.ORD[s.steps%4]; rgArrow(c,420,110,nx,16,RGCOL[nx]); mgT(c,'next',420,145,11,'#ffd8c0');
  mgBar(c,100,250,280,10,s.steps/50,'#e0782f');
 }
};

/* Candlemaker: dip when the vat slides under the candle */
MG.dip={
 hint:'Drop the candle when the wax vat slides under it.', keys:'Z dip',
 how:['The vat of wax slides back and forth.','Press Z when it is right under the candle.','Five candles. It gets faster.'],
 hud:s=>'Candle '+Math.min(5,s.round+1)+'/5',
 init(s){ s.round=0; s.pts=0; s.ph='swing'; s.px=240; s.y=0; s.w=0; },
 update(s,dt){
  s.t=(s.t||0)+dt;
  if(s.ph==='swing') s.px=240+Math.sin(s.t*(1.5+s.round*0.4))*160;
  else if(s.ph==='drop'){ s.y+=dt/0.3; if(s.y>=1){ s.y=1; const e=Math.abs(s.px-240), r=e<10?2:e<26?1:0; s.pts+=r; s.score=s.pts; s.msg=['Missed the wax!','Good enough','Perfect dip!'][r]; mgTone(r); s.ph='res'; s.w=0.9; } }
  else { s.w-=dt; s.y=Math.max(0,s.y-dt*2); if(s.w<=0){ s.round++; if(s.round>=5){ s.done=1; s.score=s.pts; } else { s.ph='swing'; s.y=0; s.msg=''; } } }
 },
 press(s,k){ if(k==='z'&&s.ph==='swing'){ s.ph='drop'; s.y=0; blip(); } },
 draw(s,c,t){
  rgRoom(c,'#2a1c1c','#432a2a','#33201e');
  rect(c,0,60,MGW,6,'#6a4a3a'); for(let i=0;i<8;i++){ rect(c,30+i*60,66,3,24+(i%3)*8,'#e8d9b5'); rect(c,30+i*60,62,3,6,'#3a2a1a'); }
  const cy=70+s.y*100; rect(c,236,40,8,cy-40+34,'#e8d9b5'); rect(c,238,34,4,8,'#222'); rect(c,226,30,28,6,'#6a4a3a');
  const px=s.px; rect(c,px-34,190,68,26,'#6a3a22'); ell(c,px,190,34,8,'#f2e2b0'); ell(c,px,190,26,5,'#e8cf8a');
  mgDuck(c,60,215,1.3,'#d9503f');
  rect(c,238,196,4,14,'rgba(255,255,255,0.12)');
 }
};

/* Weaver: repeat the colour pattern */
MG.loom={
 hint:'Watch the thread colours, then weave them back.', keys:'Arrows = colours',
 how:['Coloured threads light up in a pattern.','Repeat the pattern with the arrow keys.','Each round is one thread longer.'],
 hud:s=>'Round '+Math.min(5,s.round+1)+'/5',
 init(s){ s.round=0; s.pts=0; this.begin(s); },
 begin(s){ const len=3+s.round, ks=['up','right','down','left']; s.seq=[]; for(let i=0;i<len;i++) s.seq.push(ks[RGR(4)]); s.ph='show'; s.i=0; s.tm=0.7; s.lit=null; s.msg='Watch...'; },
 update(s,dt){
  s.tm-=dt;
  if(s.ph==='show'){
   if(s.tm<=0){
    if(s.lit===null&&s.i<s.seq.length){ s.lit=s.seq[s.i]; s.tm=0.5; tone('sine',RGFREQ[s.lit],RGFREQ[s.lit],0.2,0.08); }
    else if(s.lit!==null){ s.lit=null; s.i++; s.tm=0.18; if(s.i>=s.seq.length){ s.ph='in'; s.i=0; s.msg='Your turn'; } }
   }
  } else if(s.ph==='res'){ if(s.tm<=0){ s.round++; if(s.round>=5){ s.done=1; s.score=s.pts; } else this.begin(s); } }
  else if(s.ph==='in'){ if(s.lit&&s.tm<=0) s.lit=null; }
 },
 press(s,k){
  if(s.ph!=='in'||!RGDIR[k]) return;
  s.lit=k; s.tm=0.25; tone('sine',RGFREQ[k],RGFREQ[k],0.18,0.08);
  if(k===s.seq[s.i]){ s.i++; if(s.i>=s.seq.length){ s.pts+=2; s.score=s.pts; s.msg='Woven!'; mgTone(1); s.ph='res'; s.tm=0.9; } }
  else { const part=s.i/s.seq.length; s.pts+=2*part*part; s.score=s.pts; s.msg='Tangled!'; mgTone(0); s.ph='res'; s.tm=1; }
 },
 draw(s,c,t){
  rgRoom(c,'#2b1a24','#442434','#33202a');
  rect(c,70,40,340,150,'#5a3a2a'); rect(c,78,48,324,134,'#2a1a1a');
  const ks=['left','up','down','right'];
  for(let i=0;i<4;i++){ const k=ks[i], x=130+i*74, on=s.lit===k;
   for(let r=0;r<6;r++) rect(c,x-1,52,3,126,on?RGCOL[k]:'rgba(220,200,180,0.35)');
   ell(c,x,200,22,14,on?RGCOL[k]:'#4a3a3a'); rgArrow(c,x,200,k,10,on?'#fff':RGCOL[k]);
   if(on) ell(c,x,115,18,70,RGCOL[k]+'55'); }
  mgDuck(c,38,215,1.2,'#d9503f');
  if(s.ph==='in') for(let i=0;i<s.seq.length;i++) circ(c,240-(s.seq.length-1)*7+i*14,238,4,i<s.i?'#ffd166':'#7a5a4a');
 }
};

/* Toymaker: wind the spring and hold the tension */
MG.beetle={
 hint:'Mash Z to wind the beetle. Keep the spring in the green.', keys:'Mash Z',
 how:['Press Z again and again to wind the spring.','It unwinds on its own. Keep it in the green.','Wind too far and it snaps!'],
 hud:s=>Math.max(0,Math.ceil(s.dur-s.t))+'s  |  Green '+s.gr.toFixed(1)+'s',
 init(s){ s.t=0; s.dur=12; s.ten=0.2; s.gr=0; s.snap=0; s.turn=0; },
 update(s,dt){
  s.t+=dt; s.ten=Math.max(0,s.ten-dt*(0.3+s.t*0.012)); s.snap=Math.max(0,s.snap-dt*2);
  if(s.ten>=0.5&&s.ten<=0.8) s.gr+=dt;
  s.score=Math.min(10,s.gr/0.75);
  if(s.t>=s.dur){ s.done=1; s.score=Math.min(10,s.gr/0.75); }
 },
 press(s,k){
  if(k!=='z') return; s.ten+=0.09; s.turn+=0.6; blip();
  if(s.ten>=1){ s.ten=0.15; s.snap=1; s.msg='SNAP!'; mgTone(0); }
 },
 draw(s,c,t){
  rgRoom(c,'#2e1c22','#4a2a30','#37212a');
  ell(c,250,150,48,30,'#2a8a4a'); ell(c,250,140,40,20,'#3aa85a'); circ(c,310,140,16,'#2a8a4a');
  for(let i=0;i<3;i++){ rect(c,225+i*22,170,3,14,'#1a5a2a'); }
  c.save(); c.translate(250,142); c.rotate(s.turn); c.fillStyle='#e8c070'; c.fillRect(-4,-30,8,60); c.fillRect(-30,-4,60,8); c.restore();
  rect(c,60,60,24,150,'#1c1c1c'); rect(c,60,60+150*(1-Math.min(1,s.ten)),24,150*Math.min(1,s.ten),'#e0782f');
  rect(c,60,60+150*(1-0.8),24,150*0.3,'rgba(127,211,122,0.55)');
  if(s.snap>0) mgT(c,'SNAP',250,70,26,'rgba(255,100,80,'+s.snap.toFixed(2)+')');
  mgDuck(c,400,210,1.3,'#d9503f');
 }
};

/* Blacksmith: pump the bellows on the beat */
MG.bellows={
 hint:'Pump when the ring closes on the coal.', keys:'Z pump',
 how:['A ring shrinks toward the coal.','Press Z the moment it closes.','Ten pumps. Keep the fire even.'],
 hud:s=>'Heat '+Math.round(s.pts*10)/10,
 init(s){ s.t=0; s.pts=0; s.notes=[]; let x=1.4; for(let i=0;i<10;i++){ s.notes.push({t:x,r:null}); x+=i%3===2?0.7:1.05; } s.heat=0.2; },
 update(s,dt){
  s.t+=dt; s.heat=Math.max(0.15,s.heat-dt*0.25);
  for(const n of s.notes) if(n.r===null&&s.t>n.t+0.28){ n.r=0; s.msg='Missed!'; }
  s.score=s.pts; if(s.t>s.notes[9].t+0.6){ s.done=1; s.score=Math.min(10,s.pts); }
 },
 press(s,k){
  if(k!=='z') return;
  const n=s.notes.find(x=>x.r===null&&Math.abs(x.t-s.t)<0.3);
  if(!n){ s.msg='Too early!'; return; }
  const e=Math.abs(n.t-s.t), v=e<0.07?1:e<0.16?0.65:0.3; n.r=v; s.pts+=v; s.heat=Math.min(1,s.heat+0.2); s.msg=v===1?'Roar!':v>0.5?'Good':'Weak'; mgTone(v>0.5);
 },
 draw(s,c,t){
  rgRoom(c,'#241410','#3e2218','#2e1a12');
  const g1=s.heat; ell(c,240,170,60+g1*40,30+g1*10,'rgba(255,120,40,'+(0.2+g1*0.4).toFixed(2)+')');
  ell(c,240,170,40,20,'#2a1410'); rgFlame(c,240,172,20+g1*34,t,0.5+g1*0.5);
  rect(c,330,90,90,24,'#7a4a32'); c.fillStyle='#a8684a'; c.beginPath(); c.moveTo(330,90); c.lineTo(290,150); c.lineTo(330,114); c.fill();
  for(const n of s.notes){ if(n.r!==null) continue; const d=n.t-s.t; if(d<0.9&&d>-0.3){ const r=18+Math.max(0,d)*110; c.strokeStyle='rgba(255,209,102,'+(0.9-Math.max(0,d)*0.7).toFixed(2)+')'; c.lineWidth=3; c.beginPath(); c.arc(240,170,r,0,7); c.stroke(); } }
  c.strokeStyle='#fff6'; c.lineWidth=2; c.beginPath(); c.arc(240,170,18,0,7); c.stroke();
  mgDuck(c,90,215,1.3,'#d9503f');
 }
};

/* Herbalist: catch the herbs, dodge the thornweed */
MG.herbs={
 hint:'Catch the herbs in the mortar. Not the thorns.', keys:'Left / Right move',
 how:['Herbs and thornweed fall from the shelf.','Move the mortar with Left and Right.','Catch the green herbs. Avoid the purple thorns.'],
 hud:s=>'Herbs '+s.got+'  |  Thorns '+s.thorn,
 init(s){ s.x=240; s.items=[]; s.sp=0.3; s.n=0; s.got=0; s.thorn=0; s.good=0; s.fin=0; },
 update(s,dt){
  if(keys.left) s.x-=260*dt; if(keys.right) s.x+=260*dt; s.x=mgClamp(s.x,50,430);
  s.sp-=dt;
  if(s.sp<=0&&s.n<20){ s.sp=0.55; s.n++; const bad=Math.random()<0.28; if(!bad) s.good++; s.items.push({x:60+Math.random()*360,y:30,bad:bad,v:120+Math.random()*50}); }
  for(const it of s.items){ it.y+=it.v*dt; if(it.y>186&&it.y<206&&Math.abs(it.x-s.x)<30&&!it.gone){ it.gone=1; if(it.bad){ s.thorn++; mgTone(0); s.msg='Ouch!'; } else { s.got++; blip(); } } if(it.y>230) it.gone=1; }
  s.items=s.items.filter(i=>!i.gone);
  s.score=Math.max(0,10*(s.got-0.6*s.thorn)/Math.max(1,s.good));
  if(s.n>=20&&!s.items.length){ s.done=1; s.score=Math.max(0,Math.min(10,10*(s.got-0.6*s.thorn)/Math.max(1,s.good))); }
 },
 press(s,k){},
 draw(s,c,t){
  rgRoom(c,'#1f2a1c','#2f3a26','#2a2418');
  rect(c,0,26,MGW,8,'#6a4a2a');
  for(let i=0;i<7;i++){ rect(c,30+i*68,10,12,16,'#3a2a1a'); circ(c,36+i*68,8,7,i%2?'#4f9a50':'#6fb85a'); }
  for(const it of s.items){ if(it.bad){ c.fillStyle='#7a3aa8'; c.beginPath(); c.moveTo(it.x,it.y-10); c.lineTo(it.x+8,it.y+8); c.lineTo(it.x-8,it.y+8); c.fill(); rect(c,it.x-1,it.y+6,2,6,'#3a1a58'); }
   else { ell(c,it.x,it.y,6,10,'#5fc26a'); ell(c,it.x+7,it.y+4,5,8,'#7fe08a'); } }
  const mx=s.x; ell(c,mx,200,32,10,'#4a3a32'); c.fillStyle='#6a5a52'; c.beginPath(); c.moveTo(mx-34,186); c.lineTo(mx+34,186); c.lineTo(mx+24,214); c.lineTo(mx-24,214); c.fill(); ell(c,mx,186,34,7,'#2a1c18');
  mgDuck(c,mx+50>440?mx-60:mx+54,226,1,'#d9503f');
 }
};

/* ================= EMBERWICK EVENTS ================= */

/* The Banking of the Fires: smother each hearth before it flares */
MG.bank={
 hint:'Cover the hearths with ash before they flare.', keys:'Left / Right move, Z ash',
 how:['Six hearths, each flaring up on its own.','Move with Left and Right. Press Z to cover with ash.','If a flame reaches the top it flares. Don\'t let it.'],
 hud:s=>Math.max(0,Math.ceil(s.dur-s.t))+'s  |  Flare-ups '+s.fl,
 init(s){ s.t=0; s.dur=20; s.c=2; s.fl=0; s.h=[]; for(let i=0;i<6;i++) s.h.push({f:Math.random()*0.5,r:0.16+Math.random()*0.12,cv:0}); s.puff=0; },
 update(s,dt){
  s.t+=dt; s.puff=Math.max(0,s.puff-dt*3);
  for(const h of s.h){ if(h.cv>0){ h.cv-=dt; h.f=Math.max(0,h.f-dt*0.3); } else { h.f+=h.r*dt*(1+s.t*0.025); if(h.f>=1){ h.f=0.25; s.fl++; s.msg='Flare-up!'; mgTone(0); } } }
  s.score=Math.max(0,10-s.fl*2); if(s.t>=s.dur){ s.done=1; s.score=Math.max(0,10-s.fl*2); }
 },
 press(s,k){
  if(k==='left') s.c=Math.max(0,s.c-1); else if(k==='right') s.c=Math.min(5,s.c+1);
  else if(k==='z'){ const h=s.h[s.c]; h.cv=2.2; h.f=Math.max(0,h.f*0.3); s.puff=1; blip(); }
 },
 draw(s,c,t){
  rgRoom(c,'#1c1418','#3a2024','#2c1a1a');
  for(let i=0;i<6;i++){ const x=50+i*76, h=s.h[i];
   rect(c,x-26,130,52,70,'#6a5248'); rect(c,x-20,140,40,50,'#1c0e0c');
   if(h.cv>0){ ell(c,x,184,22,8,'#8a8078'); for(let k=0;k<3;k++) ell(c,x+k*6-6,178,8,3,'#a89e96'); }
   else rgFlame(c,x,186,10+h.f*34,t+i,0.7+h.f*0.3);
   rect(c,x-22,70,44,6,'#3a2020'); rect(c,x-22,70,44*h.f,6,h.f>0.75?'#ff5a3a':'#e0902f'); }
  const cx=50+s.c*76; c.strokeStyle='#ffd166'; c.lineWidth=3; c.strokeRect(cx-30,124,60,82);
  if(s.puff>0) for(let k=0;k<8;k++) circ(c,cx+Math.sin(k*2.1)*22,160-s.puff*50+k*4,4,'rgba(200,190,180,'+s.puff.toFixed(2)+')');
  mgDuck(c,cx,240,1,'#d9503f');
 }
};

/* Walk of the Cold Fires: keep the lantern steady against the wind */
MG.coldwalk={
 hint:'Steady your lantern against the wind.', keys:'Hold Left / Right',
 how:['You walk with a lantern at the Wood\'s edge.','The wind leans the flame. Hold Left or Right to steady it.','Keep it inside the gold bracket.'],
 hud:s=>Math.max(0,Math.ceil(s.dur-s.t))+'s  |  Steady '+Math.round(s.safe/s.dur*100)+'%',
 init(s){ s.t=0; s.dur=18; s.fl=0; s.v=0; s.safe=0; s.out=0; s.walk=0; },
 update(s,dt){
  s.t+=dt; s.walk+=dt*70;
  const a=0.9+s.t*0.09, wind=Math.sin(s.t*1.25)*a+Math.sin(s.t*3.3+1)*a*0.5;
  const ctl=(keys.right?1:0)-(keys.left?1:0);
  s.v+=(wind*2.2-ctl*3-1.1*s.fl-1.6*s.v)*dt; s.fl+=s.v*dt;
  if(Math.abs(s.fl)<0.42) s.safe+=dt;
  if(Math.abs(s.fl)>1){ s.fl=0; s.v=0; s.safe=Math.max(0,s.safe-1.5); s.msg='Snuffed! Relit.'; mgTone(0); }
  s.score=s.safe/s.dur*10; if(s.t>=s.dur){ s.done=1; s.score=Math.min(10,s.safe/s.dur*10); }
 },
 press(s,k){},
 draw(s,c,t){
  mgSky(c,'#1a1a2a','#3a2a34'); rect(c,0,190,MGW,80,'#2a2024');
  for(let i=0;i<12;i++){ const x=((i*90-s.walk*0.5)%1080+1080)%1080-60; rect(c,x,70,16,130,'#10151a'); circ(c,x+8,66,26,'#141e1a'); }
  for(let i=0;i<4;i++){ const x=((i*150-s.walk)%600+600)%600-60; mgDuck(c,x,215,0.9,'#c8483a'); rect(c,x+14,200,2,10,'#caa'); circ(c,x+15,196,3,'#ffb347'); }
  const lx=240+s.fl*60; rect(c,lx-1,100,2,60,'#8a6a4a'); rect(c,lx-8,150,16,24,'#3a2a1a'); ell(c,lx,162,8,10,'rgba(255,200,100,'+(0.2+0.3*(1-Math.min(1,Math.abs(s.fl)))).toFixed(2)+')');
  rgFlame(c,lx+s.fl*10,168,8,t,1);
  c.strokeStyle='#ffd166'; c.lineWidth=2; c.strokeRect(240-0.42*60-8,140,0.84*60+16,40);
  mgDuck(c,240,226,1.3,'#d9503f');
  mgBar(c,100,250,280,8,Math.min(1,s.safe/s.dur),'#ffb347');
 }
};

/* Ember Market: serve the right stall */
MG.market={
 hint:'Send each customer to the right stall.', keys:'Arrow = stall',
 how:['Customers ask for something. Up = Beet loaf, Right = Thread,','Down = Candle, Left = Clockwork beetle.','Ten customers. Don\'t keep them waiting.'],
 hud:s=>'Customer '+Math.min(10,s.n+1)+'/10  |  Served '+s.ok,
 IT:{up:['a beet loaf','#a8402e'],right:['red thread','#e0452f'],down:['a candle','#f2d45a'],left:['a clockwork beetle','#6fd08a']},
 init(s){ s.n=0; s.ok=0; s.cur=null; s.wait=0.4; s.life=0; s.dur=3; s.res=0; },
 nxt(s){ s.n++; s.cur=null; s.wait=0.35; s.score=s.ok; if(s.n>=10){ s.done=1; s.score=s.ok; } },
 update(s,dt){
  s.res=Math.max(0,s.res-dt*2);
  if(s.done) return;
  if(!s.cur){ s.wait-=dt; if(s.wait<=0){ s.cur=['up','right','down','left'][RGR(4)]; s.life=0; s.dur=Math.max(1.5,3.0-s.n*0.16); s.face=RGR(3); } }
  else { s.life+=dt; if(s.life>=s.dur){ s.msg='They wandered off.'; mgTone(0); this.nxt(s); } }
 },
 press(s,k){
  if(!s.cur||!RGDIR[k]) return;
  if(k===s.cur){ s.ok++; s.msg='Sold!'; mgTone(1); } else { s.msg='Wrong stall!'; mgTone(0); }
  this.nxt(s);
 },
 draw(s,c,t){
  rgRoom(c,'#3a2018','#5a2e24','#43241c');
  const P={up:[240,58],right:[410,140],down:[240,226],left:[70,140]};
  for(const k in P){ const [x,y]=P[k], it=this.IT[k]; rect(c,x-50,y-18,100,36,'#7a4a32'); rect(c,x-50,y-18,100,8,it[1]); rect(c,x-44,y-6,88,22,'#4a2a1e');
   circ(c,x-24,y+4,7,it[1]); circ(c,x,y+4,7,it[1]); circ(c,x+24,y+4,7,it[1]); mgT(c,it[0].replace(/^an? /,''),x,y+22,9,'#ffd8c0'); }
  const col=['#d9503f','#e0722f','#c8483a'][s.face||0];
  if(s.cur){ mgDuck(c,240,168,1.5,col); const it=this.IT[s.cur];
   rect(c,150,86,180,34,'#fff4e0'); mgT(c,'I would like '+it[0]+'.',240,103,11,'#3a2a1a'); mgBar(c,170,124,140,6,1-s.life/s.dur,s.life/s.dur>0.7?'#e0452f':'#7fd37a'); }
  else mgDuck(c,240,168,1.5,'#6a4a40');
  rgArrow(c,240,100-6*0,'up',0,'#0000');
 }
};

/* Hearthside Hour: listen, then answer */
MG.hearth={
 cap:80,
 hint:'Listen to the Elder\'s tale. Then answer.', keys:'Up / Down choose, Z answer',
 how:['An Elder tells a short tale by the Great Hearth.','Listen carefully. Then a child asks you a question.','Up and Down to pick, Z to answer. Five tales.'],
 hud:s=>'Tale '+Math.min(5,s.n+1)+'/5  |  Right '+s.ok,
 ST:[
  {t:['A beetle once carried a single coal','across the whole dark Wood, and never let it go out.'],q:'What did the beetle carry?',o:['A lantern','A single coal','A seed'],a:1},
  {t:['At the seventh river a stranger in a yellow coat','gave a mother his last loaf, and never gave his name.'],q:'Where was the stranger\'s gift given?',o:['At the seventh river','At the Hall','On the wall'],a:0},
  {t:['The Great Hearth was lit from the last campfire','of the March. One log is laid each hour.'],q:'How often is a log laid on the Hearth?',o:['Every day','Every hour','Every year'],a:1},
  {t:['My grandmother said the Wood is not a wall.','She said it is a hand, held out, trembling.'],q:'What did she say the Wood is?',o:['A hand, held out','A great wall','A sleeping beast'],a:0},
  {t:['Every duckling gets a red braid at birth','and one new knot for every year they live.'],q:'What is added to the braid each year?',o:['A bead','A feather','A knot'],a:2}
 ],
 init(s){ s.n=0; s.ok=0; s.ph='tell'; s.tm=0; s.sel=0; this.start(s); },
 start(s){ s.ph='tell'; s.tm=0; s.sel=0; s.msg=''; },
 update(s,dt){ s.tm+=dt; if(s.ph==='tell'&&s.tm>3.2){ s.ph='ask'; s.tm=0; } if(s.ph==='res'&&s.tm>1.1){ s.n++; if(s.n>=5){ s.done=1; s.score=s.ok*2; } else this.start(s); } s.score=s.ok*2; },
 press(s,k){
  if(s.ph==='tell'&&k==='z'){ s.ph='ask'; s.tm=0; return; }
  if(s.ph!=='ask') return;
  if(k==='up') s.sel=(s.sel+2)%3; else if(k==='down') s.sel=(s.sel+1)%3;
  else if(k==='z'){ const st=this.ST[s.n]; if(s.sel===st.a){ s.ok++; s.msg='Yes. You listened.'; mgTone(1); } else { s.msg='Not quite. It was "'+st.o[st.a]+'".'; mgTone(0); } s.ph='res'; s.tm=0; }
 },
 draw(s,c,t){
  rgRoom(c,'#25140f','#42221a','#33190f');
  const st=this.ST[s.n]||this.ST[4];
  ell(c,240,215,150,26,'#2a1410'); rgFlame(c,240,214,34,t,1); ell(c,240,216,70,14,'rgba(255,140,50,0.2)');
  mgDuck(c,70,210,1.5,'#8f3a30'); for(let i=0;i<3;i++) mgDuck(c,150+i*50,225,0.8,['#d9503f','#e0722f','#c8483a'][i]); mgDuck(c,380,225,0.9,'#f2d45a');
  if(s.ph==='tell'){ rect(c,30,30,420,74,'rgba(255,244,224,0.92)'); mgT(c,st.t[0],240,56,12,'#3a2a1a'); mgT(c,st.t[1],240,80,12,'#3a2a1a'); mgT(c,'(Z skips)',240,114,10,'#caa'); }
  else { rect(c,30,22,420,36,'rgba(255,244,224,0.92)'); mgT(c,st.q,240,40,13,'#3a2a1a');
   st.o.forEach((o,i)=>{ const on=i===s.sel; rect(c,120,66+i*30,240,24,on?'#ffd166':'rgba(255,244,224,0.8)'); mgT(c,o,240,78+i*30,12,'#3a2a1a'); }); }
 }
};

/* Thread-Tying Day: tie each duckling's knot */
MG.knots={
 hint:'Tie the knots in order before the thread frays.', keys:'Arrows in order',
 how:['A duckling holds out a wing for its knot.','Press the arrows shown, in order.','A wrong arrow unpicks your knot. Five knots.'],
 hud:s=>'Knot '+Math.min(5,s.n+1)+'/5',
 init(s){ s.n=0; s.pts=0; this.begin(s); },
 begin(s){ const len=4+s.n, ks=['up','right','down','left']; s.seq=[]; for(let i=0;i<len;i++) s.seq.push(ks[RGR(4)]); s.i=0; s.life=0; s.dur=len*1.2+1; s.ph='tie'; s.tm=0; s.msg=''; },
 update(s,dt){
  if(s.ph==='tie'){ s.life+=dt; if(s.life>=s.dur){ const part=s.i>=s.seq.length/2?1:0; s.pts+=part; s.score=s.pts; s.msg='The thread frayed.'; mgTone(0); s.ph='res'; s.tm=0.9; } }
  else { s.tm-=dt; if(s.tm<=0){ s.n++; if(s.n>=5){ s.done=1; s.score=s.pts; } else this.begin(s); } }
 },
 press(s,k){
  if(s.ph!=='tie'||!RGDIR[k]) return;
  if(k===s.seq[s.i]){ s.i++; blip(); if(s.i>=s.seq.length){ s.pts+=2; s.score=s.pts; s.msg='Tied!'; mgTone(1); s.ph='res'; s.tm=0.9; } }
  else { s.i=0; s.msg='Unpicked!'; mgTone(0); }
 },
 draw(s,c,t){
  rgRoom(c,'#2c1820','#4a2630','#38202a');
  mgDuck(c,360,210,2,['#d9503f','#e0722f','#c8483a','#f2d45a','#8f3a30'][s.n%5]);
  c.strokeStyle='#e0452f'; c.lineWidth=4; c.beginPath(); c.moveTo(330,170); for(let i=0;i<=s.i;i++) c.quadraticCurveTo(300-i*8,150+((i%2)?20:-20),290-i*12,175); c.stroke();
  for(let i=0;i<s.i;i++) circ(c,330-i*14,172+(i%2)*4,6,'#e0452f');
  const n=s.seq.length, x0=240-(n-1)*28-60;
  for(let i=0;i<n;i++){ const done=i<s.i, cur=i===s.i; rect(c,x0+i*56-20,40,40,40,done?'#3a5a3a':cur?'#fff4e0':'#6a4a50'); rgArrow(c,x0+i*56,60,s.seq[i],11,done?'#9be08a':cur?RGCOL[s.seq[i]]:'#caa'); }
  mgBar(c,100,100,280,8,1-s.life/s.dur,s.life/s.dur>0.7?'#e0452f':'#e8c070');
  mgDuck(c,60,215,1.2,'#d9503f');
 }
};

/* Banking Song Night: sing the lullaby note for note */
MG.song={
 hint:'Sing the notes as they reach the line.', keys:'Arrows on the beat',
 how:['Notes of the lullaby drift down four lanes.','Press the matching arrow as each reaches the line.','Soft and steady. Miss too many and the song falters.'],
 hud:s=>'Notes '+s.hit+'/'+s.notes.length,
 init(s){ s.t=0; s.hit=0; s.pts=0; s.notes=[]; let t=1.6, last='', rep=0; const ks=['left','up','down','right'];
  for(let i=0;i<24;i++){ let k=ks[RGR(4)]; if(k===last){ rep++; if(rep>=2) k=ks[(ks.indexOf(k)+1)%4]; } else rep=0; last=k; s.notes.push({t:t,k:k,r:null}); t+=i%4===3?0.95:0.65; }
  s.fx=null; },
 update(s,dt){
  s.t+=dt;
  for(const n of s.notes) if(n.r===null&&s.t>n.t+0.22){ n.r=0; s.msg='Missed'; }
  s.score=s.pts/s.notes.length*10; if(s.t>s.notes[s.notes.length-1].t+0.7){ s.done=1; s.score=Math.min(10,s.pts/s.notes.length*10); }
 },
 press(s,k){
  if(!RGDIR[k]) return;
  const n=s.notes.find(x=>x.r===null&&x.k===k&&Math.abs(x.t-s.t)<0.24);
  if(!n){ s.msg='Off key'; tone('square',200,160,0.1,0.04); return; }
  const e=Math.abs(n.t-s.t), v=e<0.09?1:0.65; n.r=v; s.pts+=v; s.hit++; s.msg=v===1?'Lovely':'Good'; tone('sine',RGFREQ[k],RGFREQ[k],0.22,0.08);
 },
 draw(s,c,t){
  mgSky(c,'#14101e','#2a1a2e'); rect(c,0,222,MGW,48,'#20141c');
  for(let i=0;i<8;i++){ const x=30+i*60; rect(c,x,20+(i%3)*10,30,30,'#3a2a3a'); rect(c,x+8,26+(i%3)*10,14,18,i%2?'#e8a860':'#4a3a50'); }
  const ks=['left','up','down','right'];
  for(let i=0;i<4;i++){ const x=150+i*60; rect(c,x-24,0,48,222,'rgba(255,255,255,0.04)'); rect(c,x-24,200,48,4,RGCOL[ks[i]]); rgArrow(c,x,214,ks[i],9,RGCOL[ks[i]]); }
  for(const n of s.notes){ if(n.r!==null) continue; const y=202-(n.t-s.t)*150; if(y<-10||y>230) continue; const x=150+ks.indexOf(n.k)*60; circ(c,x,y,13,RGCOL[n.k]); rgArrow(c,x,y,n.k,7,'#fff'); }
  mgDuck(c,60,250,1.1,'#d9503f'); mgDuck(c,420,250,1.1,'#c8483a');
 }
};

/* ---- events become games: mark them in the calendar ---- */
(function(){
  const MINI={rbank:'Cover the hearths before they flare.',rcoldwalk:'Steady your lantern against the wind.',rmarket:'Send each customer to the right stall.',rstory:'Listen to the tale, then answer.',rthread:'Tie the knots in order.',rsong:'Sing the notes as they arrive.'};
  for(const e of RED_EVENTS){ if(MINI[e.id]){ e.mini=1; e.say=MINI[e.id]; if(e.desc.indexOf('(Game')<0) e.desc+=' (A game: take part to earn crumbs.)'; } }
})();
