/* ===== THE NEST (v1.25) =====
   The sandbox used to hand out crumbs and give you nowhere to put them. Now home is a place that grows.
   - Near your home (the first pond, or wherever you set it), press N.
   - Four upgrades, three levels each. Each one changes something you do every day, and each wants a town
     reputation rank as well as crumbs, so favors and odd jobs are a road to it, not a chore beside it.
   - The Crumb Jar fills while you are away (up to five days), so coming home is a small reward.
   - The Hoard keeps count of every crumb you ever earn, and names you for it.
   Saved in g.story.x.nest. Adds D10.openNest; wraps wlCrumbP, luckBonus, payMul. */
(function(){
'use strict';
const D10=window.D10=window.D10||{};
const UPS=[
  {id:'jar',  n:'Crumb Jar',   rank:1, cost:[40,90,170], desc:l=>'Holds '+(3*l)+' crumbs a day while you are out (up to five days). '+(l?'Level '+l+'.':'')},
  {id:'perch',n:'Lucky Perch', rank:2, cost:[60,130,240], desc:l=>'Every favor and job pays +'+l+' crumb'+(l===1?'':'s')+' more.'},
  {id:'rack', n:'Tool Rack',   rank:2, cost:[70,150,260], desc:l=>'Every town pays '+(5*l)+'% more for work. Stacks with rank.'},
  {id:'bed',  n:'Foraging Bed',rank:3, cost:[80,160,280], desc:l=>'Foraging turns up a crumb '+(3*l)+'% more often.'},
  /* v1.27: two bigger projects for the crumbs that now have somewhere to go */
  {id:'garden',n:'Herb Garden', rank:3, cost:[120,260,460], desc:l=>'While you are away, '+(2*l)+' brewing ingredients a day grow here (up to three days)'+(l>=3?', some of them Choice grade':'')+'.'},
  {id:'study', n:'Study Nook',  rank:4, cost:[150,320,560], desc:l=>'Commissions and aims pay '+(8*l)+'% more. A quiet desk makes a better detective.'}
];
const HOARD=[[100,'Pocket Keeper'],[300,'Crumb Collector'],[700,'Nest Builder'],[1500,'Hoarder of the Pond'],[3000,'Keeper of Many Crumbs'],[6000,'The Duck Who Owns the Forest']];
const NS=()=>{ const x=XS(); if(!x.nest) x.nest={lv:{},life:0,last:null,jarDay:null,title:-1}; return x.nest; };
const lv=id=>{ try{ return (NS().lv[id])||0; }catch(e){ return 0; } };
const bestRank=()=>{ let r=0; try{ for(const t in g.rep) r=Math.max(r,rankOf(g.rep[t]||0)); }catch(e){} return r; };
const RN=()=>{ try{ return RANKS; }catch(e){ return []; } };

{ const o=wlCrumbP; wlCrumbP=function(){ return o()+0.03*lv('bed'); }; }
{ const o=luckBonus; luckBonus=function(){ return o()+lv('perch'); }; }
{ const o=payMul;   payMul=function(t){ return o(t)+0.05*lv('rack'); }; }

/* lifetime crumbs: count every rise, ignore every spend */
let lastC=null;
setInterval(()=>{
  try{
    if(!g||!g.story||typeof g.crumbs!=='number'){ lastC=null; return; }
    const n=NS();
    if(lastC===null||n.last===null) { lastC=g.crumbs; n.last=g.crumbs; if(n.life<g.crumbs) n.life=g.crumbs; return; }
    if(g.crumbs>lastC) n.life+=g.crumbs-lastC;
    lastC=g.crumbs; n.last=g.crumbs;
    let t=-1; HOARD.forEach((h,i)=>{ if(n.life>=h[0]) t=i; });
    if(t>n.title){ if(n.title>=0||t>=0){ toast('The Hoard names you: '+HOARD[t][1]+'.',3600); try{ D10.sting&&D10.sting('rank'); }catch(e){} } n.title=t; }
  }catch(e){}
},700);

const near=()=>{ if(g.scene!=='world') return false; const h=homePos(), p=worldPos(); return Math.hypot(h.x-p.x,h.y-p.y)<=7; };
const distHome=()=>{ const h=homePos(), p=worldPos(); return Math.round(Math.hypot(h.x-p.x,h.y-p.y)); };

function collectJar(){
  const n=NS(), L=lv('jar'); if(!L) return 0;
  if(n.jarDay==null){ n.jarDay=g.day; return 0; }
  const days=Math.max(0,Math.min(5,g.day-n.jarDay)); if(!days) return 0;
  const amt=days*3*L; n.jarDay=g.day; g.crumbs+=amt; coin(); return amt;
}
function body(){
  const n=NS(), tl=n.title>=0?HOARD[n.title][1]:'No name yet';
  const next=HOARD.find(h=>n.life<h[0]);
  return 'Crumbs earned in all: '+n.life+'  ·  '+tl+(next?'  (next: '+next[0]+')':'')+'\nYou have '+g.crumbs+' crumbs. Your best rank is '+(RN()[bestRank()]||{n:'?'}).n+'.';
}
function collectGarden(){
  const L=lv('garden'); if(!L) return 0;
  const n=NS(); if(n.gDay==null||n.gDay===undefined){ n.gDay=g.day; return 0; }
  const days=Math.max(0,Math.min(3,g.day-n.gDay)); if(!days) return 0;
  n.gDay=g.day; const cats=['flower','bush','mush','tree','rock','stump']; let tot=0;
  try{ const b=BS(); for(let i=0;i<days*2*L;i++){ const c=cats[Math.floor(hash(g.day,i,9911)*6)], gr=(L>=3&&hash(g.day,i,9912)<0.4)?1:0, k=c+':'+gr; b.ing[k]=(b.ing[k]||0)+1; tot++; } }catch(e){}
  return tot;
}
function open(msg){
  if(!near()){ say('',['Your Nest is '+distHome()+' steps away.','Press N when you are beside it. (Home is set on the Map with H. Until then, it is the first pond.)']); return; }
  D10.mark&&D10.mark('nest');
  const got=collectJar(), gg=collectGarden();
  const go=()=>{
    const labels=UPS.map(u=>{ const L=lv(u.id); return u.n+'  Lv '+L+'/3'+(L<3?'  ·  '+u.cost[L]+' crumbs'+(bestRank()<u.rank?'  (needs '+RN()[u.rank].n+')':''):'  · done'); });
    labels.push('Leave');
    choose('Your Nest',(msg?msg+'\n':'')+body(),labels,k=>{
      if(k>=UPS.length) return;
      const u=UPS[k], L=lv(u.id);
      if(L>=3){ say('',[u.n+' is as good as it gets.']); return open(); }
      if(bestRank()<u.rank){ say('',['Not yet. Towns have to know you first: be '+RN()[u.rank].n+' somewhere.','Favors and odd jobs raise your standing.'],()=>open()); return; }
      if(g.crumbs<u.cost[L]){ say('',['That is '+u.cost[L]+' crumbs and you have '+g.crumbs+'.'],()=>open()); return; }
      choose(u.n,u.desc(L+1)+'\nCost: '+u.cost[L]+' crumbs.',['Build it','Not now'],j=>{
        if(j!==0) return open();
        g.crumbs-=u.cost[L]; NS().lv[u.id]=L+1; coin(); try{ D10.sting&&D10.sting('rank'); }catch(e){}
        open(u.n+' is now level '+(L+1)+'.');
      },1);
    },UPS.length);
  };
  const ln=[]; if(got) ln.push('The Crumb Jar has filled while you were away.','+'+got+' crumbs.'); if(gg) ln.push('The Herb Garden has grown while you were away.','+'+gg+' ingredients are in your satchel.');
  if(ln.length){ say('',ln,go); } else go();
}
D10.openNest=open; D10.nest=NS; D10.nestLevel=lv;

KEYMAP.n='nest'; KEYMAP.N='nest';
{ const _p=press; press=function(k){ if(k==='nest'){ if(g.mode==='play') open(); return; } _p(k); }; }
/* a button under More */
(function(){
  const more=document.querySelector('.moremenu'); if(!more) return;
  const b=document.createElement('button'); b.type='button'; b.className='hb inmore'; b.textContent='Nest (N)';
  b.addEventListener('click',e=>{ e.currentTarget.blur(); if(g.mode==='play') open(); });
  more.appendChild(b);
})();
})();
