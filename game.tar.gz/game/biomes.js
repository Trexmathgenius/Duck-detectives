'use strict';
/* ===== BIOMES: fourteen kinds of country, each with its own trees, flowers, bushes, mushrooms, rocks and stumps =====
   Outside the story lands, the wild world is carved into biomes by two slow noises (warmth and wetness) plus a few rare ones. A town
   pulls the country around it towards its own style (a snowy burrow sits in tundra, a bazaar in the dunes). Winding game trails cross
   every biome. Species are chosen per tile from the biome's lists; the species decides how the tile looks and what it is called. */
const WL_CATS=['tree','flower','bush','mush','rock','stump'];
const WL_CATN={tree:'Trees',flower:'Flowers',bush:'Bushes',mush:'Mushrooms',rock:'Rocks',stump:'Stumps and logs'};
const WL_CATS1={tree:'tree',flower:'flower',bush:'bush',mush:'mushroom',rock:'rock',stump:'stump'};
const WL_TILECAT={}; WL_TILECAT[T.TREE]='tree'; WL_TILECAT[T.FLOWER]='flower'; WL_TILECAT[T.BUSH]='bush'; WL_TILECAT[T.MUSH]='mush'; WL_TILECAT[T.ROCK]='rock'; WL_TILECAT[T.STUMP]='stump';

const TR=(name,k,c,o)=>Object.assign({name:name,k:k,c:c},o||{});
const FL=(name,k,c,o)=>Object.assign({name:name,k:k,c:c},o||{});
const BU=(name,k,c,o)=>Object.assign({name:name,k:k,c:c},o||{});
const MU=(name,k,c,o)=>Object.assign({name:name,k:k,c:c},o||{});
const RO=(name,k,c,o)=>Object.assign({name:name,k:k,c:c},o||{});
const ST=(name,k,c,o)=>Object.assign({name:name,k:k,c:c},o||{});

const WL_BIOMES=[
 {id:'forest',name:'Oakwood Forest',plain:true,
  tree:[0.04,0.30],q:[0.010,0.006,0.054,0.03,0.015],wt:0.72,mapTree:'#2f6b34',
  sp:{
   tree:[TR('English Oak','round',['#6b4a2f','#2f6b34','#3a7d3d','#47914a']),TR('Silver Birch','birch',['#ece8dc','#3b3b3b','#3f8a3a','#58a64a','#7cc467']),TR('Hazel Tree','round',['#6b4a2f','#3d7a36','#4d8c3d','#6aa84a'],{fruit:'#c9a06a',sz:0.92}),TR('Copper Beech','round',['#5a3d2c','#6a2e3a','#7e3a46','#9a5a5a'],{sz:1.04})],
   flower:[FL('Bluebell','bell',['#6a7fe0','#c9d4ff','#2f6b34']),FL('Wood Anemone','daisy',['#ffffff','#f6e27a','#2f6b34']),FL('Foxglove','spike',['#c46ab0','#e8a6d8','#2f6b34']),FL('Primrose','daisy',['#f5e06a','#e8a94a','#2f6b34'])],
   bush:[BU('Bramble','bush',['#336b34','#47914a','#3f8441'],{berry:'#5a2a5a'}),BU('Hazel Shrub','bush',['#3a6e30','#58903f','#6aa84a'])],
   mush:[MU('Fly Agaric','cap',['#d65a5a','#ffffff','#e9e2d0']),MU('Penny Bun','cap',['#8a5a34','#c9a06a','#efe3c8']),MU('Chanterelle','tall',['#e8a734','#f6d27a','#f2d9a0'])],
   rock:[RO('Mossy Boulder','boulder',['#7d838c','#a0a6ae','#c3c8cf'],{moss:'#4f8f45'}),RO('Lichen Rock','boulder',['#8a8f98','#a8adb5','#c9cdd2'],{spot:'#d9a640'})],
   stump:[ST('Mossy Stump','stump',['#6b4a2f','#a97c50','#8a6238'],{moss:'#4f8f45'}),ST('Fallen Log','stump',['#6b4a2f','#a97c50','#8a6238'],{v:'log',moss:'#4f8f45'})]
  },
  finds:['r_goldacorn','r_antler','r_owlfeather']},

 {id:'meadow',name:'Flower Meadow',
  grass:['#5fae4c','#66b852','#58a646'],blade:'#4a9a3c',tuft:'#8fd76e',mapGrass:'#6cba58',decor:'meadow',
  tree:[0.004,0.05],q:[0.004,0.003,0.20,0.03,0.01],wt:0.74,mapTree:'#3b8a45',
  sp:{
   tree:[TR('Hawthorn','round',['#6b4a2f','#3b8a45','#4aa053','#6bc468'],{fruit:'#d83a3a',sz:0.92}),TR('Crab Apple','round',['#6b4a2f','#3b8a45','#52a850','#7bc86a'],{fruit:'#e8603a',sz:0.96}),TR('Elder','round',['#5a4a3a','#3f8a46','#56a852','#7bc86a'],{bloom:'#ffffff',sz:0.9})],
   flower:[FL('Buttercup','poppy',['#fadc3c','#d9a21e','#2f6b34']),FL('Ox-eye Daisy','daisy',['#ffffff','#f6d13a','#2f6b34']),FL('Cornflower','daisy',['#4a6fe0','#2a3fa0','#2f6b34']),FL('Red Poppy','poppy',['#e0382e','#2a1a1a','#2f6b34']),FL('Cowslip','bell',['#f4d83c','#e8a82a','#2f6b34']),FL('Red Clover','puff',['#d6609a','#f2a6c8','#2f6b34'])],
   bush:[BU('Wild Rose','bush',['#336b34','#47914a','#3f8441'],{berry:'#f06aa0'}),BU('Gorse','bush',['#3a6e30','#4f8a3a','#5f9a42'],{berry:'#f6d02a',spikes:1})],
   mush:[MU('Meadow Waxcap','cap',['#f2c14a','#ffe9a0','#f2e8c8']),MU('Fairy Ring Champignon','cluster',['#d8b88a','#f0e0c0','#efe3c8'])],
   rock:[RO('Sunny Stone','boulder',['#8c9096','#b3b7bd','#d6d9de'],{spot:'#d9a640'}),RO('Flat Rock','slab',['#8c9096','#a8acb2','#6f7379'])],
   stump:[ST('Hollow Stump','stump',['#7a5a3a','#b98c5a','#8a6238'],{cap:'#e8a734'}),ST('Old Fence Rail','stump',['#8a6a44','#b98c5a','#8a6238'],{v:'log'})]
  },
  finds:['r_honeycomb','r_bumblecharm','r_rainbowbloom']},

 {id:'autumn',name:'Amber Woods',
  grass:['#8f8a3a','#9a9440','#86823a'],blade:'#6e6a2a',tuft:'#c9a850',mapGrass:'#9a8f40',decor:'leaves',part:'leaves',
  tree:[0.06,0.34],q:[0.010,0.012,0.03,0.04,0.03],wt:0.72,mapTree:'#c9622e',
  sp:{
   tree:[TR('Sugar Maple','round',['#6b3a22','#b8321c','#d9582b','#f08a3c'],{ground:'#d9582b'}),TR('Golden Aspen','birch',['#efe9d4','#4a4a4a','#c99a1a','#e8b13a','#f6d36a']),TR('Red Oak','round',['#5a3a22','#8a2e1c','#a8432b','#c9622e'],{ground:'#a8432b',sz:1.04}),TR('Gold Larch','spire',['#5a3d22','#b8841a','#d9a82b','#f2cb52'])],
   flower:[FL('Purple Aster','daisy',['#9a6ad8','#f6d13a','#6a7f2f']),FL('Goldenrod','spike',['#f2c21e','#d99a12','#6a7f2f']),FL('Harvest Lily','lily',['#e8822a','#f6d13a','#6a7f2f']),FL('Rust Chrysanthemum','poppy',['#c9562a','#f2b04a','#6a7f2f'])],
   bush:[BU('Burning Bush','bush',['#7a1f1c','#b8321c','#d9582b']),BU('Rosehip','bush',['#6e5a28','#8f7a34','#a89040'],{berry:'#e8602a'})],
   mush:[MU('Honey Fungus','cluster',['#d9a04a','#f0d090','#e9d9b0']),MU('Autumn Bolete','cap',['#b8641e','#e8a04a','#efe3c8'])],
   rock:[RO('Leaf-Strewn Rock','boulder',['#76706a','#9a948c','#bdb7ad'],{spot:'#d9582b'}),RO('Rusty Boulder','boulder',['#8a5a3a','#b07a52','#d19a72'])],
   stump:[ST('Acorn-Littered Stump','stump',['#5a3d22','#b98c5a','#8a6238'],{cap:'#c9622e'}),ST('Toppled Maple','stump',['#5a3d22','#a97c50','#8a6238'],{v:'log'})]
  },
  finds:['r_rainbowleaf','r_ambertear','r_syrup']},

 {id:'tundra',name:'Frostwood Tundra',
  grass:['#e8f0f7','#dfe9f3','#eef4fa'],blade:'#b3c8de',tuft:'#ffffff',mapGrass:'#e4eef6',snow:true,decor:'snow',part:'snow',
  tree:[0.04,0.24],q:[0.02,0.006,0.025,0.035,0.008],wt:0.70,mapTree:'#2d5f4a',mapWater:'#cfe6f5',waterTint:'rgba(228,242,252,0.72)',ice:true,
  sp:{
   tree:[TR('Frost Spruce','pine',['#2d5f4a','#3a7459','#eaf4f8'],{snow:1,cones:1}),TR('Snow Fir','pine',['#2a5668','#34708a','#d6ecf6'],{snow:1,sz:1.08}),TR('Ice Birch','birch',['#f2f6fa','#6a7a8a','#b8d4e6','#d4e8f4','#f4fbff']),TR('Hoarfrost Pine','pine',['#4a6a5a','#5f8a76','#f4fbff'],{snow:1,sz:0.9})],
   flower:[FL('Snowdrop','snowdrop',['#ffffff','#8fd09a','#4f8f5a']),FL('Winter Aconite','poppy',['#f6dc3a','#6a8a3a','#4f8f5a']),FL('Frost Crocus','tulip',['#b8a4f0','#f6e27a','#4f8f5a']),FL('Ice Violet','cluster',['#8ab4f0','#d4e6ff','#4f8f5a'])],
   bush:[BU('Snowberry','bush',['#3a6a5a','#5a8a76','#8ab8a0'],{snow:1,berry:'#ffffff'}),BU('Blue Juniper','bush',['#2a5668','#3f7a8f','#5f9aaa'],{snow:1,berry:'#4a5fa0'})],
   mush:[MU('Frost Cap','cap',['#9ac0e0','#ffffff','#e6eef4']),MU('Winter Oyster','flat',['#d4d0c8','#f0ece4','#e6eef4'])],
   rock:[RO('Snow-Capped Boulder','boulder',['#7a8696','#a4b0c0','#d4dce6'],{snow:1}),RO('Glacial Ice','ice',['#9ad0f0','#c4e6fa','#7ab4dc'])],
   stump:[ST('Frozen Stump','stump',['#6a5a4a','#c9b9a0','#a89880'],{snow:1}),ST('Icebound Log','stump',['#6a5a4a','#c9b9a0','#a89880'],{v:'log',snow:1})]
  },
  finds:['r_frozendew','r_snowcrystal','r_mammothtooth']},

 {id:'highlands',name:'Stony Highlands',
  grass:['#6f8a5c','#76925f','#688456'],blade:'#566f46',tuft:'#8fa878',mapGrass:'#708a60',decor:'pebbles',
  tree:[0.02,0.12],q:[0.06,0.006,0.04,0.04,0.01],wt:0.74,mapTree:'#3e6a45',
  sp:{
   tree:[TR('Scots Pine','pine',['#2f5a3a','#3f7348','#5a9060'],{cones:1}),TR('Rowan','round',['#5a4a3a','#3e7a48','#52944f','#74b268'],{fruit:'#e0402e',sz:0.9}),TR('Twisted Juniper','spire',['#5a4a3a','#35604a','#4a7a5c','#6a9a78'],{sz:0.9}),TR('Windswept Thorn','dead',['#5a4a3a','#7a6a58'],{moss:'#6a8a50'})],
   flower:[FL('Mountain Heather','puff',['#a86ab8','#d8a6e0','#4f6a3a']),FL('Gentian','tulip',['#2a4fd0','#8ab0ff','#4f6a3a']),FL('Edelweiss','lily',['#f2f0e6','#f6dc6a','#7a9a6a']),FL('Harebell','bell',['#8aa0e8','#d4dcff','#4f6a3a'])],
   bush:[BU('Bilberry','bush',['#3a5a38','#4f7a46','#628f58'],{berry:'#3a3a8a'}),BU('Crowberry','heath',['#2f4a38','#4a6a4a'],{berry:'#222831'})],
   mush:[MU('Mountain Bolete','cap',['#8a6a4a','#b8986a','#e6dcc4']),MU('Grey Knight','tall',['#9a9a9a','#c4c4c4','#e6e6e6'])],
   rock:[RO('Granite Boulder','boulder',['#7d838c','#a0a6ae','#c3c8cf']),RO('Quartz Outcrop','crystal',['#d8dce6','#b8bece','#ffffff']),RO('Weathered Cairn','cairn',['#7d838c','#9aa0a8','#b8bec6'])],
   stump:[ST('Weathered Stump','stump',['#7a6a5a','#bfae94','#9a8a72']),ST('Bleached Log','stump',['#8a7a68','#c9bba4','#a89a84'],{v:'log'})]
  },
  finds:['r_quartz','r_eaglefeather','r_meteorite']},

 {id:'desert',name:'Dune Sea',
  grass:['#e2c98a','#dcc182','#e8d094'],blade:'#c9ab6a',tuft:'#f2e0aa',mapGrass:'#e0c888',decor:'dunes',
  tree:[0.004,0.03],q:[0.035,0.004,0.02,0.07,0.002],wt:0.84,mapTree:'#4f8f4a',mapWater:'#3ea0b8',waterTint:'rgba(60,200,200,0.16)',
  sp:{
   tree:[TR('Saguaro','cactus',['#4f8f4a','#356a35','#f2d0e0'],{v:'saguaro'}),TR('Joshua Tree','cactus',['#6a8a3a','#8aaa4a','#f6f0c0'],{v:'joshua'}),TR('Date Palm','palm',['#8a6a42','#3f7a3a','#6aa84a'],{fruit:'#c0762a'}),TR('Golden Barrel','cactus',['#7aa84a','#4f7a32','#f6d02a'],{v:'barrel'})],
   flower:[FL('Desert Marigold','daisy',['#f6d02a','#c98a12','#6a8a4a']),FL('Sand Verbena','cluster',['#e06aa8','#f6a6d0','#6a8a4a']),FL('Ocotillo Bloom','spike',['#e8402a','#f68a52','#6a8a4a']),FL('Aloe Flower','spike',['#f28a22','#f6c04a','#6a8a4a']),FL('Pincushion Cactus Bloom','succulent',['#ec5a9a','#fbd0e4','#5a8a4a','#7ab05a'])],
   bush:[BU('Creosote','dry',['#6a7a3a','#8a9a52'],{dot:'#f6d02a'}),BU('Tumbleweed','tumble',['#9a7a3e','#c9a85a']),BU('Prickly Pear','pear',['#5a9a4a','#3f7a38','#e8f0c0'],{berry:'#d6406a'})],
   mush:[MU('Desert Truffle','flat',['#c9a878','#e8d2a8','#e6d9bc']),MU('Dune Puffball','cap',['#e6d6b0','#b89a62','#e6d9bc'])],
   rock:[RO('Sandstone Pillar','mesa',['#c9824a','#a8643a','#e0a070']),RO('Sun-Baked Boulder','boulder',['#b08a60','#d0aa7e','#ead0a4']),RO('Desert Rose Rock','geode',['#b08a60','#d0aa7e','#e8a0a0'],{core:'#fff0f0'})],
   stump:[ST('Bleached Driftwood','stump',['#b8a888','#e0d4ba','#c9b99a'],{v:'log'}),ST('Dry Stump','stump',['#9a8466','#d8c8a8','#b8a888'])]
  },
  finds:['r_scarab','r_sungeode','r_desertglass','r_sandrose']},

 {id:'jungle',name:'Canopy Jungle',
  grass:['#2f7a3a','#348540','#2a7035'],blade:'#1f5a2b',tuft:'#4fa85c',mapGrass:'#2f7a3a',decor:'litter',part:'fly',
  tree:[0.14,0.40],q:[0.008,0.008,0.09,0.10,0.03],wt:0.70,mapTree:'#1f6a30',waterTint:'rgba(20,110,60,0.24)',
  sp:{
   tree:[TR('Kapok Giant','jungle',['#6a5a48','#1f5a2b','#2f7a3a','#52a850'],{bloom:'#f06aa0'}),TR('Banana Palm','palm',['#7a6a3a','#3f8a2f','#7ac84a'],{fruit:'#f6d02a',thick:3,fr:8}),TR('Strangler Fig','jungle',['#4a3a2a','#1a4a26','#27683a','#44904a'],{fruit:'#c0402e',sz:0.96}),TR('Tree Fern','palm',['#4a3a2a','#2a7a38','#5ac060'],{fr:10,droop:11,len:15,thick:5}),TR('Rubber Tree','round',['#5a4a38','#1f5a2b','#2f7a3a','#52a850'],{sz:1.06})],
   flower:[FL('Lobster Claw Heliconia','spike',['#e8402a','#f6c02a','#2f6b34']),FL('Hibiscus','poppy',['#e8325a','#f6d02a','#2f6b34']),FL('Jungle Orchid','orchid',['#c46ae0','#f6e27a','#2f6b34']),FL('Bird of Paradise','lily',['#f28a22','#4a6fe0','#2f6b34']),FL('Ginger Torch','puff',['#f06a8a','#f6a6c0','#2f6b34'])],
   bush:[BU('Giant Fern','fern',['#1f6a30','#52b858'],{n:9,len:14}),BU('Monstera','fern',['#2a7a38','#6ac870'],{n:6,len:12}),BU('Passion Vine','bush',['#1f5a2b','#2f7a3a','#44904a'],{berry:'#9a3ad8'})],
   mush:[MU('Coral Fingers','cluster',['#f08a5a','#f6c0a0','#f2d9c0']),MU('Orange Pore Fungus','flat',['#e87a2a','#f6b04a','#e6d9bc']),MU('Lacy Stinkhorn','tall',['#e8e0d0','#8a6a3a','#f2ecdc'])],
   rock:[RO('Mossy Ruin Stone','boulder',['#6a7a6a','#8a9a8a','#aab8aa'],{moss:'#3f8f45'}),RO('Jade-Veined Rock','boulder',['#5a6a5a','#7a8a7a','#8ac8a0'],{spot:'#6ad8a0'})],
   stump:[ST('Vine-Choked Stump','stump',['#4a3a2a','#8a6a44','#6a4a2a'],{vine:'#2f7a3a'}),ST('Fallen Giant','stump',['#4a3a2a','#8a6a44','#6a4a2a'],{v:'log',moss:'#3f8f45'})]
  },
  finds:['r_jadeidol','r_orchidresin','r_parrotfeather']},

 {id:'swamp',name:'Mistmarsh',
  grass:['#4f6b3e','#56744a','#486238'],blade:'#38502c',tuft:'#6f8f58',mapGrass:'#4f6b3e',decor:'bog',part:'fly',
  tree:[0.05,0.20],q:[0.004,0.012,0.05,0.13,0.03],wt:0.60,mapTree:'#3a5a3a',mapWater:'#4a6a4a',waterTint:'rgba(70,95,40,0.42)',lilies:true,
  sp:{
   tree:[TR('Weeping Willow','willow',['#5a4a38','#3f6a38','#58904a']),TR('Bald Cypress','mangrove',['#6a4a38','#3a6a3a','#4f8a46','#6aa85a'],{moss:'#a8c090'}),TR('Black Mangrove','mangrove',['#4a3a2a','#2f5a30','#3f7a3c','#58964c']),TR('Dead Snag','dead',['#4a4238','#6a6050'],{moss:'#5a7a3a'})],
   flower:[FL('Water Lily','lily',['#f6a6c8','#f6e27a','#3f7a3a']),FL('Marsh Marigold','poppy',['#f6d02a','#c98a12','#3f7a3a']),FL('Blue Flag Iris','lily',['#5a5ad8','#f6e27a','#3f7a3a']),FL('Pitcher Plant','spike',['#9a2a3a','#c9505a','#5a7a3a']),FL('Bog Cotton','cotton',['#ffffff','#e8e0c8','#5a7a3a'])],
   bush:[BU('Cattail','reed',['#4f7a3a','#6a9a4a','#3a5a2c'],{head:'#6a3f1e',tall:18}),BU('Bulrush','reed',['#5a8a40','#7aaa56','#3a5a2c'],{tall:20}),BU('Bog Myrtle','bush',['#3a5a2c','#4f7a3a','#6a9a4a'],{berry:'#c9a02a'})],
   mush:[MU('Swamp Waxcap','cap',['#7aa84a','#d8f0a0','#e6ecc4']),MU('Shaggy Ink Cap','tall',['#d8d8d0','#4a4a4a','#efefe6']),MU('Bog Bracket','flat',['#8a6a3a','#b8985a','#e6dcc4'])],
   rock:[RO('Peat Mound','boulder',['#3a3228','#5a4e3c','#7a6c54'],{moss:'#4f7a3a'}),RO('Slime-Green Stone','boulder',['#5a6a50','#7a8a6a','#9aaa8a'],{moss:'#6a9a40'})],
   stump:[ST('Rotting Log','stump',['#4a3a2a','#8a7a5a','#6a5a3a'],{v:'log',moss:'#4f7a3a'}),ST('Sunken Stump','stump',['#4a3a2a','#8a7a5a','#6a5a3a'],{moss:'#4f7a3a',cap:'#c9a050'})]
  },
  finds:['r_bogpearl','r_wisp','r_peatamber']},

 {id:'bamboo',name:'Bamboo Hollow',
  grass:['#6aa84f','#72b258','#629c48'],blade:'#4f8a3a',tuft:'#9ad37a',mapGrass:'#6aa84f',decor:'bamboo',
  tree:[0.12,0.38],q:[0.01,0.01,0.03,0.06,0.02],wt:0.72,mapTree:'#5aa04a',
  sp:{
   tree:[TR('Moso Bamboo','bamboo',['#5aa84a','#a8e08a','#3a7a32','#4f9a42']),TR('Golden Bamboo','bamboo',['#d6b83a','#f6e27a','#a8861e','#8ab84a']),TR('Black Bamboo','bamboo',['#2f3a32','#5a6a5c','#1a221c','#3f7a3a']),TR('Japanese Maple','round',['#5a3a2c','#8a1e2e','#b8323c','#e0585a'],{sz:0.9})],
   flower:[FL('Camellia','rose',['#e8528a','#f6a0c0','#2f6b34']),FL('Tree Peony','poppy',['#f6a6c8','#f2d04a','#2f6b34']),FL('Plum Blossom','cluster',['#f6c0d0','#ffffff','#5a3a2c']),FL('Japanese Iris','lily',['#7a4ad0','#f6e27a','#2f6b34'])],
   bush:[BU('Azalea','bush',['#2f6b34','#3f8a42','#52a850'],{berry:'#f06aa8'}),BU('Dwarf Bamboo','fern',['#3f8a42','#8ad06a'],{n:7,len:11})],
   mush:[MU('Shiitake','cap',['#7a5230','#a87a4a','#efe3c8']),MU('Enoki','cluster',['#f2ead0','#ffffff','#f6f0dc'])],
   rock:[RO('Zen Stone','boulder',['#6a6e72','#8a8e92','#b0b4b8'],{moss:'#4f8f45'}),RO('Stone Lantern Base','cairn',['#7a7e82','#9a9ea2','#babebe'])],
   stump:[ST('Cut Bamboo Stump','stump',['#a8a84a','#e0e0a0','#7a8a3a']),ST('Pale Log','stump',['#8a7a5a','#c9b894','#a89874'],{v:'log',moss:'#4f8f45'})]
  },
  finds:['r_bambooflute','r_luckyknot','r_teabrick']},

 {id:'cherry',name:'Blossom Hills',
  grass:['#7fb866','#88c26e','#78b05f'],blade:'#5f9a4a',tuft:'#f2c6d8',mapGrass:'#86c06c',decor:'petals',part:'petals',
  tree:[0.04,0.18],q:[0.006,0.004,0.10,0.04,0.01],wt:0.74,mapTree:'#f2a6c3',
  sp:{
   tree:[TR('Cherry Blossom','round',['#5a3d2c','#e888a8','#f2a6c3','#fbd0e0'],{bloom:'#ffffff',ground:'#f6b0c8'}),TR('White Sakura','round',['#5a3d2c','#e6dcdc','#f4ecec','#ffffff'],{bloom:'#f6c0d0',ground:'#ffffff'}),TR('Weeping Cherry','willow',['#5a3d2c','#e888a8','#fbc0d6']),TR('Plum Tree','round',['#5a3d2c','#7a4a8a','#9a62a8','#b88ac8'],{fruit:'#4a2a6a',sz:0.94})],
   flower:[FL('Sakura Violet','cluster',['#c8a0f0','#f0e0ff','#2f6b34']),FL('Pink Tulip','tulip',['#f06aa0','#f6a6c8','#2f6b34']),FL('Wisteria','bell',['#9a7ae0','#d8c6ff','#2f6b34']),FL('Blossom Daisy','daisy',['#f8c0d8','#f6e27a','#2f6b34'])],
   bush:[BU('Camellia Shrub','bush',['#2f6b34','#3f8a42','#52a850'],{berry:'#f06a9a'}),BU('White Spirea','bush',['#3a7a40','#58a05a','#78c078'],{berry:'#ffffff'})],
   mush:[MU('Rosy Cap','cap',['#e896b0','#ffffff','#f2e6e0']),MU('Peach Oyster','flat',['#f2b890','#f8d6b8','#f2e6e0'])],
   rock:[RO('Petal-Dusted Rock','boulder',['#8a8a94','#aaaab4','#cacad2'],{spot:'#f2a6c3'}),RO('Garden Stone','slab',['#8a8a94','#a8a8b2','#7a7a84'],{moss:'#6aa050'})],
   stump:[ST('Blossom Stump','stump',['#5a3d2c','#c9a07a','#a07a54'],{cap:'#f2a6c3'}),ST('Fallen Branch','stump',['#5a3d2c','#c9a07a','#a07a54'],{v:'log'})]
  },
  finds:['r_everbloom','r_lanterncharm','r_hairpin']},

 {id:'glowcap',name:'Glowcap Grove',
  grass:['#2f6b4f','#357657','#2b6247'],blade:'#1f4f3a',tuft:'#4f9a73',mapGrass:'#2f6b4f',decor:'specks',part:'spores',
  tree:[0.06,0.26],q:[0.015,0.008,0.07,0.04,0.09],wt:0.72,mapTree:'#2a9a8a',waterTint:'rgba(30,200,170,0.22)',
  sp:{
   tree:[TR('Glow Tree','glow',['#2a3a34','#1f6a5a','#2a8a74','#3fb094','rgba(130,255,230,A)'],{halo:'rgba(60,230,200,0.10)'}),TR('Giant Glowcap','giantmush',['#e6dcc8','#2a6a8a','#3f9ac0','#a8f0ff'],{glow:'80,200,255'}),TR('Mooncap Tree','glow',['#2a2a3a','#4a3a8a','#6a52b0','#8a74d8','rgba(210,170,255,A)'],{halo:'rgba(170,110,255,0.10)'}),TR('Lantern Fir','pine',['#1f5a4a','#2a8a6a','#7affd0'],{cones:1})],
   flower:[FL('Moonpetal','glowbloom',['#cfe8ff','#ffffff','#2f6b4f'],{glow:'160,200,255'}),FL('Lumen Bell','bell',['#7affd0','#d4fff0','#2f6b4f']),FL('Starfern Bloom','glowbloom',['#b8ffe0','#ffffff','#2f6b4f'],{glow:'120,255,200'}),FL('Dream Orchid','orchid',['#d08af0','#f6e0ff','#2f6b4f'])],
   bush:[BU('Glowberry','bush',['#1f5a4a','#2a7a60','#3f9a7a'],{berry:'#aaffd8'}),BU('Fairy Fern','fern',['#1f6a50','#5affc0'],{n:8,tip:'#d4fff0'})],
   mush:[MU('Glowcap','cap',['#b36bff','#7ff0ff','#e9e2d0'],{glow:'168,85,247'}),MU('Spore Lantern','tall',['#5affd0','#d4fff0','#e0f6ee'],{glow:'90,255,208'}),MU('Blue Ghost','cluster',['#8ac8ff','#ffffff','#e6f0f8'],{glow:'110,190,255'})],
   rock:[RO('Luminous Crystal','crystal',['#5affd0','#2ab08e','#d4fff0'],{glow:'90,255,208'}),RO('Mossy Geode','geode',['#3a5a4a','#587a68','#b36bff'],{core:'#e0c0ff'})],
   stump:[ST('Spore Stump','stump',['#2a3a34','#4a6a5c','#3a5a4c'],{cap:'#b36bff'}),ST('Glimmer Log','stump',['#2a3a34','#4a6a5c','#3a5a4c'],{v:'log',moss:'#3f9a7a'})]
  },
  finds:['r_sporevial','r_moonstone','r_fairychalice']},

 {id:'lavender',name:'Lavender Fields',
  grass:['#8ba66a','#93ae70','#839f62'],blade:'#6f8a52',tuft:'#b9a7d8',mapGrass:'#8fa86c',decor:'purple',
  tree:[0.004,0.04],q:[0.006,0.003,0.22,0.05,0.005],wt:0.74,mapTree:'#6f8a58',
  sp:{
   tree:[TR('Olive Tree','round',['#7a6a52','#6a7a52','#8a9a68','#a8b888'],{fruit:'#3a4a2a',sz:0.92}),TR('Italian Cypress','spire',['#5a4a3a','#2a5a3a','#3a7a4c','#5a9a6a']),TR('Silver Poplar','spire',['#7a7a6a','#7a9a8a','#9ab8a8','#c4dcd0']),TR('Almond Tree','round',['#5a3d2c','#7a9a5a','#9ab878','#d8e8b8'],{bloom:'#fbe0e8',sz:0.9})],
   flower:[FL('English Lavender','spike',['#8a5ad8','#b898f0','#6f8a52']),FL('French Lavender','spike',['#b04ad0','#d896f0','#6f8a52']),FL('Sage Blossom','spike',['#4a7ad8','#8aaaf0','#6f8a52']),FL('Pink Cosmos','daisy',['#f08ab8','#f6d04a','#6f8a52']),FL('Hyssop','spike',['#3a3ab8','#6a6ae0','#6f8a52'])],
   bush:[BU('Rosemary','bush',['#4a6a44','#678a56','#86aa72'],{berry:'#9ab8f0'}),BU('Wild Thyme','heath',['#5a7a4e','#7a9a6a'],{berry:'#d896d8'})],
   mush:[MU('Field Mushroom','cap',['#efe6d4','#cdb894','#efe6d4']),MU('Parasol Mushroom','tall',['#d8c8a8','#8a6a4a','#efe6d4'])],
   rock:[RO('Terracotta Rock','boulder',['#a86a4a','#c98a64','#e0a888']),RO('Dry-Stone Wall Bit','slab',['#9a9288','#b8b0a4','#7a7268'],{moss:'#7a9a5a'})],
   stump:[ST('Olive Stump','stump',['#7a6a52','#c9b894','#a89874']),ST('Trellis Post','stump',['#8a6a44','#c9a878','#a8844e'],{v:'log'})]
  },
  finds:['r_sachet','r_lavjar','r_dreampillow']},

 {id:'shore',name:'Sunny Shore',
  grass:['#e6d6a0','#e0cf98','#ecdeaa'],blade:'#cdbb82',tuft:'#f6eac2',mapGrass:'#e2d29c',decor:'shells',part:'sparkle',
  tree:[0.01,0.08],q:[0.02,0.01,0.05,0.05,0.002],wt:0.62,mapTree:'#4a9a52',mapWater:'#4fb3d0',waterTint:'rgba(80,225,235,0.20)',
  sp:{
   tree:[TR('Coconut Palm','palm',['#8a6a42','#3f8a3a','#6ac060'],{fruit:'#6a4a22'}),TR('Sea Pine','pine',['#3a6a4a','#4f8a5e','#78b08a']),TR('Sea Almond','round',['#6a4a32','#3f8a46','#58a858','#80c878'],{sz:0.94}),TR('Beach Hibiscus Tree','round',['#6a4a32','#3f8a46','#58a858','#80c878'],{bloom:'#f6d02a',sz:0.9})],
   flower:[FL('Beach Morning Glory','lily',['#b06af0','#ffffff','#4f8f4a']),FL('Sea Lavender','cluster',['#c8a4f0','#f0e4ff','#4f8f4a']),FL('Coral Hibiscus','poppy',['#f26a5a','#f6d02a','#4f8f4a']),FL('Sea Thrift','puff',['#f08ab8','#ffd0e4','#4f8f4a'])],
   bush:[BU('Beach Rose','bush',['#3a7a40','#58a05a','#78c078'],{berry:'#f06a9a'}),BU('Sea Grass','reed',['#8aaa5a','#b8d070','#c9b87a'],{tall:14}),BU('Sea Grape','bush',['#3a6a40','#58905a','#78b078'],{berry:'#7a3a8a'})],
   mush:[MU('Dune Cap','flat',['#e6d2a8','#f6ead0','#f2e6cc']),MU('Beach Puffball','cap',['#f2e6cc','#d8c8a0','#f2e6cc'])],
   rock:[RO('Tidepool Rock','boulder',['#5a6a76','#7a8a96','#9ab0bc'],{spot:'#e8e0c8'}),RO('Shell-Crusted Rock','boulder',['#8a8a88','#aaaaa6','#cacac6'],{spot:'#f6c0b0'})],
   stump:[ST('Driftwood','stump',['#a89878','#d8cdb4','#c0b494'],{v:'log'}),ST('Salt-Bleached Stump','stump',['#a89878','#d8cdb4','#c0b494'])]
  },
  finds:['r_seaglass','r_pearl','r_conch','r_bottle']},

 {id:'savanna',name:'Golden Savanna',
  grass:['#b5a548','#bdad4e','#ab9c42'],blade:'#8f8030',tuft:'#d6c870',mapGrass:'#b8a84c',decor:'tallgrass',
  tree:[0.003,0.05],q:[0.015,0.006,0.04,0.08,0.003],wt:0.76,mapTree:'#7a8a3a',
  sp:{
   tree:[TR('Umbrella Acacia','acacia',['#5a4a32','#5a7a32','#7a9a42','#a0b85a']),TR('Baobab','baobab',['#9a8266','#6a8a3a','#9ab85a']),TR('Marula','round',['#6a5a3a','#6a8a3a','#82a64a','#a8c868'],{fruit:'#f2c23a',sz:0.96}),TR('Fever Tree','acacia',['#c9b83a','#7a9a32','#9ab84a','#c0d868'],{sz:0.9})],
   flower:[FL('Savanna Lily','lily',['#e84a3a','#f6d02a','#8a9a3a']),FL('Golden Everlasting','daisy',['#f6d02a','#c98a12','#8a9a3a']),FL('Fireball Lily','puff',['#e8402a','#f68a52','#8a9a3a']),FL('Desert Rose','poppy',['#f08ab0','#ffffff','#8a9a3a'])],
   bush:[BU('Elephant Grass','reed',['#a8a03a','#cfc454','#b8a850'],{tall:22}),BU('Thornbush','bush',['#5a6a2c','#7a8a3a','#9aaa4a'],{spikes:1}),BU('Mopane Shrub','bush',['#6a7a32','#8a9a42','#a8b85a'])],
   mush:[MU('Termite Mushroom','tall',['#b89a6a','#8a6a3a','#d8c8a4']),MU('Savanna Puffball','cap',['#efe6c8','#c9b88a','#efe6c8'])],
   rock:[RO('Kopje Boulder','boulder',['#9a8a6a','#bba98a','#d8c8a8']),RO('Red Rock Slab','slab',['#a8603a','#c98054','#8a4a2a'])],
   stump:[ST('Sun-Bleached Log','stump',['#a8946a','#d8c8a0','#bfae84'],{v:'log'}),ST('Termite Mound Stump','stump',['#a8603a','#d89a6a','#8a4a2a'])]
  },
  finds:['r_ostrich','r_sunstone','r_termitegem']}
];
const WL_BY={}; WL_BIOMES.forEach(b=>{ WL_BY[b.id]=b; });
/* ===== one thousand species: the hand-made ones, then every list is grown with colour, size and name variants, sorted into seven rarities ===== */
const WL_PTIER=['Common','Uncommon','Rare','Epic','Legendary','Mythic','Chromatic'];
const WL_PCOL=['#9db8a7','#86e29a','#7ab8ff','#d49aff','#ffb347','#ff5fa2','#ffffff'];
const WL_PWT=[100,45,18,7,2.5,0.8,0.2];
const WL_TIER_DESC=['seen everywhere','found here and there','hard to spot','a lucky sight','a once-in-a-while wonder','almost a legend','shimmers through every colour; almost never seen'];
function wlHsl(h){
  let r,g,b; h=h.replace('#','');
  if(h.length===3){ r=parseInt(h[0]+h[0],16); g=parseInt(h[1]+h[1],16); b=parseInt(h[2]+h[2],16); } else { r=parseInt(h.slice(0,2),16); g=parseInt(h.slice(2,4),16); b=parseInt(h.slice(4,6),16); }
  r/=255; g/=255; b/=255; const mx=Math.max(r,g,b), mn=Math.min(r,g,b), l=(mx+mn)/2; let hh=0, s=0;
  if(mx!==mn){ const d=mx-mn; s=l>0.5?d/(2-mx-mn):d/(mx+mn); hh=mx===r?(g-b)/d+(g<b?6:0):mx===g?(b-r)/d+2:(r-g)/d+4; hh*=60; }
  return [hh,s,l];
}
function wlHex(a){
  const h=((a[0]%360)+360)%360, s=Math.max(0,Math.min(1,a[1])), l=Math.max(0.04,Math.min(0.96,a[2]));
  const q=l<0.5?l*(1+s):l+s-l*s, p=2*l-q, f=t=>{ t=(t+1)%1; return t<1/6?p+(q-p)*6*t:t<0.5?q:t<2/3?p+(q-p)*(2/3-t)*6:p; };
  const x=v=>('0'+Math.round(v*255).toString(16)).slice(-2);
  return '#'+x(f(h/360+1/3))+x(f(h/360))+x(f(h/360-1/3));
}
function wlShiftCol(col,dh,ds,dl,cat,tint){
  if(typeof col!=='string'||col[0]!=='#') return col;
  const a=wlHsl(col), trunk=a[0]>=10&&a[0]<=50&&a[2]<0.5&&a[1]>0.2;
  if(a[1]<0.13||cat==='rock'){ if(cat==='rock'||tint){ a[0]=tint?tint[0]:dh; a[1]=Math.max(a[1],0.12)*(tint?tint[1]:1.6); a[2]+=dl*0.6; return wlHex(a); } return col; }
  if(trunk&&(cat==='tree'||cat==='stump')) { a[2]+=dl*0.4; return wlHex(a); }
  a[0]+=dh; a[1]*=ds; a[2]+=dl; return wlHex(a);
}
function wlRecolor(sp,dh,ds,dl,tint){
  const o=Object.assign({},sp);
  o.c=sp.c.map(x=>wlShiftCol(x,dh,ds,dl,sp.cat,tint));
  for(const k in sp){ if(k==='c'||k==='name'||k==='id'||typeof sp[k]!=='string'||sp[k][0]!=='#') continue; o[k]=wlShiftCol(sp[k],dh,ds,dl,sp.cat,tint); }
  return o;
}
const wlChromaCache={};
function wlChroma(sp,time){
  const ph=Math.floor(time*2.2+(sp.id.length*3))%36, key=sp.id+'/'+ph;
  return wlChromaCache[key]||(wlChromaCache[key]=Object.assign(wlRecolor(sp,ph*10,1.15,0.04),{id:sp.id,tier:6,cat:sp.cat,biome:sp.biome}));
}
function wlRng(seed){ let s=0; for(let i=0;i<seed.length;i++) s=(Math.imul(s,31)+seed.charCodeAt(i))|0; return ()=>{ s=(s+0x6D2B79F5)|0; let t=Math.imul(s^(s>>>15),1|s); t=(t+Math.imul(t^(t>>>7),61|t))^t; return ((t^(t>>>14))>>>0)/4294967296; }; }
const WL_ADJ0=['Little','Wild','Common','Gentle','Dusty','Mossy','Plain','Tall','Dwarf','Lesser','Field','Hill','River','Shade','Dewy','Rustling','Quiet','Sleepy','Humble','Breezy','Sunny','Bristly','Smooth','Hardy','Scrappy','Cheery','Slender','Stout','Tufted','Woolly'];
const WL_ADJ1=['Spotted','Striped','Ruffled','Scarlet','Speckled','Honeyed','Freckled','Curly','Lacy','Fringed','Dappled','Crested','Pale','Ashen','Rosy','Saffron','Cinnamon','Dusky','Peppered','Sparkling'];
const WL_ADJ2=['Velvet','Crimson','Emerald','Silken','Gilded','Amethyst','Cobalt','Coral','Copper','Ivory','Jade','Moonlit','Sapphire','Topaz','Garnet','Ember','Violet','Indigo','Opal','Pearl'];
const WL_ADJ3=['Royal','Twilight','Crowned','Stormcaller','Duskwing','Thunder','Regal','Noble','Midnight','Sunforged','Frostborn','Emberheart','Dragonscale','Wyrmwood','Starlit','Tempest','Siren','Baroness','Warden','Oracle'];
const WL_ADJ4=['Ancient','Eternal','Heartwood','Elder','Sovereign','Immortal','Primeval','Titan','Founders','Everbloom','Sunken King','Kingmaker','Worldroot','Dawnbringer','Evergold'];
const WL_ADJ5=['Phantom','Moonborn','Starfall','Spirit','Wraith','Dreaming','Celestial','Veiled','Eclipse','Aether','Lunar','Ghostlight','Nightbloom','Astral','Mirage'];
const WL_ADJ6=['Prismatic','Kaleidoscope','Opaline','Aurora','Chromatic','Iridescent','Rainbow','Spectral','Shimmerglass','Polychrome'];
const WL_ADJT=[WL_ADJ0,WL_ADJ1,WL_ADJ2,WL_ADJ3,WL_ADJ4,WL_ADJ5,WL_ADJ6];
const WL_NOUNS={
 tree:{round:['Oak','Elm','Ash','Maple','Beech','Chestnut','Hornbeam','Sycamore','Linden','Walnut','Plane Tree','Alder'],spire:['Cypress','Poplar','Spire Tree','Larch','Juniper','Fir'],pine:['Pine','Spruce','Fir','Hemlock','Cedar','Larch'],palm:['Palm','Date Palm','Fan Palm','Coconut Palm','Sago Palm'],cactus:['Cactus','Saguaro','Prickly Tree','Cholla','Barrel Cactus'],birch:['Birch','Aspen','Silver Poplar','Paper Birch','Alder'],willow:['Willow','Weeping Tree','Drooping Elm','Trailing Birch'],bamboo:['Bamboo','Cane','Giant Reed','Stalk Grove'],acacia:['Acacia','Umbrella Thorn','Flat-Top','Marula'],jungle:['Kapok','Ironwood','Mahogany','Strangler Fig','Teak','Rubber Tree'],mangrove:['Mangrove','Stilt Tree','Tidal Tree','Brine Fig'],glow:['Glowtree','Lumina','Lantern Tree','Sporeglow'],dead:['Snag','Dead Tree','Husk Tree','Bone Tree'],baobab:['Baobab','Bottle Tree','Giant Trunk'],giantmush:['Giant Toadstool','Mushroom Tree','Cap Tower']},
 flower:{daisy:['Daisy','Aster','Cosmos','Chamomile','Marguerite','Fleabane'],tulip:['Tulip','Crocus','Fritillary'],bell:['Bluebell','Harebell','Campanula','Bellflower','Snowbell'],spike:['Foxglove','Lupine','Delphinium','Salvia','Lavender','Liatris'],lily:['Lily','Iris','Gladiolus','Amaryllis','Day Lily'],poppy:['Poppy','Buttercup','Anemone','Marigold','Cornflower'],puff:['Allium','Thistle','Dandelion','Clover','Pompom'],sun:['Sunflower','Coneflower','Gaillardia','Black-Eyed Susan'],cluster:['Phlox','Hydrangea','Yarrow','Verbena','Lilac','Forget-Me-Not'],orchid:['Orchid','Lady Slipper','Bird of Paradise','Moth Orchid'],succulent:['Stonecrop','Aloe Bloom','Sedum','Agave Flower'],cotton:['Cotton Grass','Cottonwort','Fluffweed','Pampas'],rose:['Rose','Peony','Camellia','Ranunculus','Dahlia'],snowdrop:['Snowdrop','Winter Aconite','Hellebore','Frost Violet'],glowbloom:['Glowbloom','Moonflower','Lumen Lily','Sparkbud']},
 bush:{bush:['Shrub','Bramble','Hedge','Thicket','Briar','Currant','Holly'],reed:['Reed','Rush','Sedge','Cattail','Papyrus'],fern:['Fern','Bracken','Frond','Horsetail','Tree Fern'],dry:['Scrub','Sagebrush','Creosote','Saltbush','Thornbrush'],heath:['Heather','Heath','Broom','Gorse','Lavender Bush'],tumble:['Tumbleweed','Rolling Brush','Windbush'],pear:['Prickly Pear','Paddle Cactus','Nopal','Fig Bush']},
 mush:{cap:['Cap','Toadstool','Bolete','Waxcap','Russula','Brittlegill','Webcap','Inkcap'],tall:['Parasol','Shaggy Mane','Stinkhorn','Morel','Chanterelle'],cluster:['Clusterstool','Honey Fungus','Oyster Cluster','Fairy Ring']},
 rock:{boulder:['Boulder','Stone','Outcrop','Cobble','Granite Block','Crag'],crystal:['Crystal','Quartz Spire','Shard Cluster','Gem Stone'],mesa:['Mesa Rock','Red Butte','Sandstone Tower','Hoodoo'],cairn:['Cairn','Stack Stone','Waymarker','Balanced Stone'],geode:['Geode','Hollow Stone','Druse','Crack Egg'],ice:['Ice Block','Frost Boulder','Glacier Chunk','Rime Stone'],slab:['Slab','Flagstone','Shale Slab','Table Rock','Monolith']},
 stump:{stump:['Stump','Log','Snag','Burl','Root Knot','Driftwood','Fallen Bough','Trunk Base']}
};
const WL_BPFX={forest:'Oakwood',meadow:'Meadow',autumn:'Amber',tundra:'Frost',highlands:'Highland',desert:'Dune',jungle:'Jungle',swamp:'Bog',bamboo:'Grove',cherry:'Blossom',glowcap:'Glowcap',lavender:'Heath',shore:'Shore',savanna:'Savanna'};
function wlTierCounts(n,ch){
  const p=[.33,.24,.18,.11,.08,.04,.02]; const c=p.map(x=>Math.floor(x*n)); let sum=c.reduce((a,b)=>a+b,0);
  const rem=p.map((x,i)=>[x*n-c[i],i]).sort((a,b)=>b[0]-a[0]); for(let i=0;sum<n;i++,sum++) c[rem[i%7][1]]++;
  if(!ch||n<12){ c[0]+=c[6]; c[6]=0; } else if(c[6]===0){ c[6]=1; c[0]--; }
  if(n>=7&&c[4]===0){ c[4]=1; c[0]--; } if(n>=8&&c[5]===0){ c[5]=1; c[0]--; }
  return c;
}
{
  /* decide how long each list becomes: 1000 species in all */
  const base={tree:15,flower:15,bush:11,mush:12,rock:9,stump:9}, want={}, order=['tree','flower','mush','bush','rock','stump'];
  let total=0;
  for(const b of WL_BIOMES){ want[b.id]={}; for(const cat of WL_CATS){ const have=(b.sp[cat]||[]).length; want[b.id][cat]=Math.max(have,base[cat]); total+=want[b.id][cat]; } }
  for(let i=0;total<1000;i++){ const b=WL_BIOMES[i%WL_BIOMES.length], cat=order[Math.floor(i/WL_BIOMES.length)%order.length]; want[b.id][cat]++; total++; }
  for(let i=0;total>1000;i++){ const b=WL_BIOMES[i%WL_BIOMES.length], cat=order[order.length-1-Math.floor(i/WL_BIOMES.length)%order.length]; if(want[b.id][cat]>(b.sp[cat]||[]).length){ want[b.id][cat]--; total--; } if(i>5000) break; }
  const used=new Set(); for(const b of WL_BIOMES) for(const cat of WL_CATS) for(const s of (b.sp[cat]||[])) used.add(s.name);
  for(const b of WL_BIOMES) for(const cat of WL_CATS){
    const list=b.sp[cat]||(b.sp[cat]=[]), hand=list.length, n=want[b.id][cat]; if(!hand) continue;
    const counts=wlTierCounts(n,cat==='tree'||cat==='flower'||cat==='mush'), tiers=[]; counts.forEach((k,t)=>{ for(let i=0;i<k;i++) tiers.push(t); });
    const rnd=wlRng(b.id+cat);
    for(let i=0;i<hand;i++){ list[i].hand=true; }
    for(let i=hand;i<n;i++){
      const t=tiers[i], src=list[i%hand], nouns=(WL_NOUNS[cat][src.k]||[].concat(...Object.values(WL_NOUNS[cat])));
      const dh=t>=3?(rnd()*360):((rnd()-0.5)*84), ds=0.85+rnd()*0.35+t*0.03, dl=(rnd()-0.5)*0.12+(t>=4?0.05:0);
      const sp=wlRecolor(src,dh,ds,dl,null); delete sp.hand;
      if(sp.sz||cat==='tree') sp.sz=Math.min(1.18,(src.sz||1)*(0.9+rnd()*0.2+(t>=4?0.08:0)));
      let name='', tries=0;
      do{
        const adjs=WL_ADJT[t], adj=adjs[Math.floor(rnd()*adjs.length)], noun=nouns[Math.floor(rnd()*nouns.length)];
        name=(tries>6||(t<2&&rnd()<0.35)?WL_BPFX[b.id]+' ':'')+adj+' '+noun; tries++;
        if(tries>14) name=name+' '+(tries-13);
      } while(used.has(name));
      used.add(name); sp.name=name; sp.tier=t; list.push(sp);
    }
    for(let i=0;i<hand;i++) list[i].tier=tiers[i];
  }
}

/* give every species an id, category, biome and a rarity (the first listed is the commonest) */
const WL_SPECIES={}, WL_SPLIST=[];
WL_BIOMES.forEach(b=>{
  b.sps=[];
  for(const cat of WL_CATS){
    const list=b.sp[cat]||[];
    list.forEach((sp,i)=>{
      sp.id=b.id+':'+cat+':'+i; sp.cat=cat; sp.biome=b.id; sp.rank=i; sp.rare=sp.tier>=3; sp.w=WL_PWT[sp.tier]*(sp.hand&&sp.tier<=1?3:1);
      WL_SPECIES[sp.id]=sp; WL_SPLIST.push(sp); b.sps.push(sp);
    });
  }
  if(!b.plain){
    b.style={id:'wl_'+b.id,biome:b,label:b.name,plaza:'dirt',snow:!!b.snow,grass:b.grass,blade:b.blade,tuft:b.tuft,map:{plaza:'#c9b48a',grass:b.mapGrass},
      roofs:ROOFS,walls:WALLS,part:b.part||null};
  }
  b.pQ=[]; let acc=0; for(const q of b.q){ acc+=q; b.pQ.push(acc); }
});
function wlPickSpecies(list,r){
  if(!list.cum){ let t=0; list.cum=list.map(x=>t+=x.w); }
  const a=r*list.cum[list.cum.length-1];
  for(let i=0;i<list.length;i++) if(a<=list.cum[i]) return list[i];
  return list[list.length-1];
}

/* ---------- where each biome lives ---------- */
const WL_STYLE_BIOME={cobble:'forest',garden:'meadow',harvest:'autumn',frost:'tundra',cove:'shore',grove:'glowcap',bazaar:'desert'};
const wlClamp=v=>v<0?0:v>1?1:v;
const wlStretch=v=>wlClamp((v-0.5)*1.9+0.5);
/* the story lands and the first miles around the pond keep their original look; every flower and tree there is still a forest species */
function wlProtected(x,y){
  if(Math.abs(x-KX)<420&&Math.abs(y-KY)<420) return 2;      /* the kingdom, the Hollow Wood, Emberwick */
  if(Math.hypot(x,y)<150) return 1;                          /* the Quiet Forest, the trail and Puddlewick */
  return 0;
}
function wlNoiseBiome(x,y){
  const t=wlStretch(fbm(x*0.0085+31,y*0.0085-77,331)), m=wlStretch(fbm(x*0.0085-210,y*0.0085+130,332));
  const s1=fbm(x*0.016+900,y*0.016-500,333), s2=fbm(x*0.016-400,y*0.016+700,334), s3=fbm(x*0.013+250,y*0.013+250,335), s4=fbm(x*0.02-60,y*0.02+90,336);
  if(s1>0.765) return 'cherry';
  if(s2>0.775) return 'glowcap';
  if(t<0.16) return m<0.42?'highlands':'tundra';
  if(t>0.76){ if(m<0.34) return 'desert'; if(m<0.62) return 'savanna'; return 'jungle'; }
  if(s3>0.745&&t>0.2) return 'shore';
  if(m>0.88) return 'swamp';
  if(t>0.45&&m>0.68) return 'bamboo';
  if(m<0.16) return 'lavender';
  if(s4<0.38) return 'meadow';
  if(s4>0.60&&t<0.62) return 'autumn';
  return 'forest';
}
function wlTownPull(x,y){
  const rx=Math.floor((x+24)/REG), ry=Math.floor((y+24)/REG);
  let best=null, bd=1e9;
  for(let dy=-1;dy<=1;dy++) for(let dx=-1;dx<=1;dx++){
    const t=getTown(rx+dx,ry+dy); if(!t||t.isRed) continue;
    const ddx=Math.max(t.x0-x,0,x-(t.x0+t.w-1)), ddy=Math.max(t.y0-y,0,y-(t.y0+t.h-1)), d=Math.hypot(ddx,ddy);
    if(d<bd){ bd=d; best=t; }
  }
  if(!best||bd>80) return null;
  const id=WL_STYLE_BIOME[best.style.id]; if(!id) return null;
  if(bd<=34) return id;
  const w=(80-bd)/46;
  return fbm(x*0.05+17,y*0.05-9,337)<w*0.9?id:null;
}
const wlCache=new Map();
function wlBiomeAt(x,y){
  const k=tkey(x,y);
  let v=wlCache.get(k);
  if(v!==undefined) return v;
  v=null;
  const pr=wlProtected(x,y);
  if(pr===2) v=null;
  else if(_wlStyleAt(x,y)) v=null;                    /* inside a town's grounds */
  else if(pr===1) v=WL_BY.forest;
  else if(darkAt(x,y)>0.05) v=WL_BY.forest;           /* the dark patches keep their own look */
  else { const id=wlTownPull(x,y)||wlNoiseBiome(x,y); v=WL_BY[id]; }
  if(wlCache.size>90000) wlCache.clear();
  wlCache.set(k,v);
  return v;
}
let _wlStyleAt=styleAt;
function wlRidge(x,y,sc,ox,oy,s){
  const v=fbm(x*sc+ox,y*sc+oy,s), vx=fbm((x+1)*sc+ox,y*sc+oy,s), vy=fbm(x*sc+ox,(y+1)*sc+oy,s);
  const gr=Math.hypot(vx-v,vy-v);
  return gr>0.0035&&Math.abs(v-0.5)/gr<0.5;
}
function wlTrail(x,y){
  if(wlRidge(x,y,0.021,410,-330,321)) return true;
  return fbm(x*0.01+5,y*0.01+5,323)>0.5&&wlRidge(x,y,0.034,-90,260,322);
}
const WL_NAT=new Set([T.GRASS,T.TREE,T.ROCK,T.STUMP,T.FLOWER,T.BUSH,T.MUSH,T.WATER,T.CRUMBS]);
{
  const _gen=genTile;
  genTile=function(x,y){
    const prev=_gen(x,y);
    if(!WL_NAT.has(prev)) return prev;
    const b=wlBiomeAt(x,y);
    if(!b||wlProtected(x,y)) return prev;
    if(nearTown(x,y,4)) return prev;
    if(darkAt(x,y)>0.05) return prev;
    const wv=fbm(x*0.06+100,y*0.06+100,3);
    if(b.plain){
      if(prev!==T.WATER&&wlTrail(x,y)) return T.PATH;
      return prev;
    }
    if(wv>b.wt) return T.WATER;
    if(wlTrail(x,y)) return T.PATH;
    const fd=forestAt(x,y);
    const prob=b.tree[0]+(b.tree[1]-b.tree[0])*wlClamp((fd-0.3)/0.4);
    if(hash(x,y,11)<prob) return T.TREE;
    if(hash(x,y,14)<0.0075&&!taken.has(x+','+y)) return T.CRUMBS;
    const q=hash(x,y,13), P=b.pQ;
    if(q<P[0]) return T.ROCK;
    if(q<P[1]) return T.STUMP;
    if(q<P[2]) return T.FLOWER;
    if(q<P[3]) return T.BUSH;
    if(q<P[4]) return T.MUSH;
    return T.GRASS;
  };
}
/* which species stands on this tile? null in towns, the story lands and the dark patches */
function wlSpeciesAt(x,y,t){
  const cat=WL_TILECAT[t]; if(!cat) return null;
  const b=wlBiomeAt(x,y); if(!b) return null;
  const list=b.sp[cat]; if(!list||!list.length) return null;
  return wlPickSpecies(list,hash(x,y,901+WL_CATS.indexOf(cat)));
}
