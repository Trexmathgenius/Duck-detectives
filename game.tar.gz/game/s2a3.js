'use strict';
/* ===== ACT III: THE TWO WORDS ===== chapters 9 to 12 ===== */

PGLYPH.oldtree=(c,x,y,col,t)=>{
  ell(c,x+16,y+30,28,7,'rgba(0,0,0,0.35)'); rect(c,x+4,y-24,24,52,'#1a1412'); rect(c,x-12,y-8,18,6,'#1a1412'); rect(c,x+26,y-14,20,6,'#1a1412'); rect(c,x-4,y-34,10,14,'#1a1412'); rect(c,x+24,y-40,10,16,'#1a1412');
  rect(c,x+12,y+6,8,22,'#050304'); const a=0.5+0.5*Math.sin(t*1.5); circ(c,x+16,y+16,22,'rgba(255,170,80,'+(0.08+0.07*a).toFixed(2)+')'); circ(c,x+13,y+14,2,'rgba(255,220,150,0.8)'); circ(c,x+19,y+14,2,'rgba(255,220,150,0.8)');
};
const THR_FOLLOW={name:'Hermit Mallow',pal:RED_PALS[0],head:'hood',seen:false};
const WARDEN_PAL={body:'#b5322a',wing:'#8a2620',bill:'#ff9d2e'};
ITEMS.hearthcoal={name:'Coal of the First Hearth',desc:'A coal in an iron cup. It will not go out and it will not burn you. It is the first fire of Emberwick, and a sister to the crystal in the dark.',use:'note',note:'It is warm. When you hold it toward the north-west, it brightens.',nogift:true};
Object.assign(RICON,{hearthcoal:(R,C,E)=>{ R(4,9,8,4,'#4a4a52'); C(8,8,4,'#ff7a2a'); C(8,8,2,'#ffd166'); }});

/* =========================================================
   CHAPTER 9 (RED): THE TWELVE SPELLS (infiltrating Quackenhold)
   ========================================================= */
S2.ch.c9r={route:'red',title:'Quackenhold',sub:'A banished duck, a satchel of spells, and a castle that is not asleep.',
  intro:['The road to Kingsbill is the longest you have walked. At every farm, a shutter closes. At every well, a child is pulled indoors.','You carry a letter, a lantern, and twelve ways of asking the world for something. The castle has two guards, a moat, a hundred and twelve men, and a king who has not spoken to anyone in a hundred years.'],
  recap:'You slipped into Quackenhold and found the throne door. The voice behind it said: wait for a summons.',
  start(){ s2kit(); s2set(0); },
  obj(s){ return ['Travel to <b>Castle Quackenhold</b>, south of the Royal Gardens, with Cinder\'s letter and the Keeper\'s Lantern.',
    'The gate is shut to red feathers. Find another way in. The <b>moat grate</b>, west of the plaza, breathes cold air.'][s]; }
};
S2.zone({id:'castlearrive',k:[0,20],r:6,when:()=>s2at('c9r',0),fn(){
  seq([['Castle Guard Drake',['Halt. Red feathers. The king receives no one. Not you, not anyone. It is not the colour. It is procedure.','Go home, little duck. Go back to your wood.']],
    [P3,['(The lantern in your satchel leans against the stone, hard, toward the castle door. Somewhere in the walls, a note rises, and falls.)','(There must be another way in. A castle this old has drains.)']]],()=>{ s2set(1); });
}});
S2.prop({id:'moatgrate',k:[-18,13],glyph:'door',col:'#2a2a38',when:()=>s2at('c9r',1),mark:'!',use(){
  say('',['An iron grate in the foot of the moat wall, bolted open. Cold air breathes out of it, with a smell of old water and a hum you feel in your teeth.'],()=>sxEnter('inf1'));
}});
sxDef('inf1',{name:'Under the Moat',theme:'crypt',indoor:true,dark:0.6,lightR:90,start:[1,4,'right'],seek:S=>[24,4],
  hint:'A veil makes you uninteresting. The walls block the sentry\'s sight. Wait for it to turn.',
  caughtLines:['"Who is down there?" A lantern swings. You press yourself flat against the weeping stone, and it is not quite enough.','You are shooed back to the grate, with a lecture, and a wet tail.'],
  rows:sxGrid(26,9,[[0,4,'D'],[25,4,'>'],[7,1,4,7,'~'],[6,4,'w'],[13,1,1,3,'#'],[13,5,1,3,'#'],[17,1,1,3,'#'],[17,5,1,3,'#'],[13,4,'S'],[17,4,'T'],[20,1,1,3,'#'],[20,5,1,3,'#'],[20,4,'F']]),
  exits:{D:{to:'world',wx:KX-18,wy:KY+14},'>':{to:'inf2',tx:1,ty:6,dir:'right'}},
  objs:{
    w:sxSpellObj({name:'Moat water',glyph:'none',desc:'Black water, four tiles wide, with a skin of cold on it.',solid:false,when:S=>!S.fl.ice},{Frost:'ask the water to slow and still'},(S)=>{ S.fl.ice=1; for(let x=7;x<=10;x++) sxSet(S,x,4,'i'); coin(); sxSay(S,'',['"Slow," you ask. "Still." The moat takes a breath and holds it. A white lane of ice runs across, humming under your feet.']); },'Cold slows and stills. Ask the water.'),
    S:sxSpellObj({name:'Fallen masonry',glyph:'boulder',desc:'A block of old wall, fallen across the tunnel and wedged.',solid:true,when:S=>!S.fl.stone},{Stone:'ask it to break along its seams'},(S)=>{ S.fl.stone=1; coin(); sxSay(S,'',['You press the Rune Stone to it and ask. The block parts along a seam older than the castle, in two neat halves, and settles.']); },'Stone is asked, not struck.'),
    T:sxSpellObj({name:'Rope net',glyph:'thorns',desc:'A net of tarred rope, hung across the tunnel to catch drowned things.',solid:true,when:S=>!S.fl.net},{Kindle:'ask a flame to remember the tar'},(S)=>{ S.fl.net=1; coin(); sxSay(S,'',['"Kindle," you ask, very politely. The tar remembers being pine, and burns with a clean orange flame, and then the net is a few neat threads of ash.']); },'Rope burns. The Ember Wand remembers fire.'),
    F:sxSpellObj({name:'Steam',glyph:'fog',desc:'A bank of white steam from the old boiler-house. It stings the eyes.',solid:true,when:S=>!S.fl.steam},{Gust:'blow it back to its pipes'},(S)=>{ S.fl.steam=1; coin(); sxSay(S,'',['"Away," you whisper, to the charm. The steam leaves in a long white line, up a vent, with a sound like someone sighing in relief.']); },'Steam is air. A gust will move air.')
  },
  guards:[{name:'Moat Sentry',path:[[15,1],[15,7]],speed:30,range:5,fov:64,pause:0.9,head:'helm'}]
});
sxDef('inf2',{name:'The Lower Halls',theme:'castle',indoor:true,dark:0.5,lightR:90,start:[1,6,'right'],seek:S=>S.fl.lv?[20,6]:[10,2],
  hint:'Pillars block sight, shadows halve it, Veil all but hides you. The lever is broken. What mends a broken thing?',
  caughtLines:['"HALT!" A spear drops across the passage. The guard is white to the lips, and does not seem to know why he is afraid.','You are marched back, politely and firmly, to the start of the hall.'],
  rows:sxGrid(24,13,[[0,6,'<'],[23,6,'>'],[17,1,1,5,'#'],[17,7,1,5,'#'],[20,1,1,5,'#'],[20,7,1,5,'#'],[20,6,'C'],[3,9,5,3,','],[13,1,3,3,','],[10,2,'L'],[4,10,'S'],[6,5,'P'],[6,7,'P'],[12,5,'P'],[12,8,'P']]),
  doors:[{tx:17,ty:6,key:'lv'}],
  exits:{'<':{to:'inf1',tx:24,ty:4,dir:'left'},'>':{fn:S=>{ sxGoto('cs2',1,5,'right'); }}},
  objs:{
    P:{name:'Pillar',glyph:'pillar',block:true,col:'#a8a698'},
    L:sxSpellObj({name:'Broken lever',glyph:'lever',key:'lv',desc:'A great iron lever in the wall, snapped at the pivot. A hundred years of damp have eaten it.',solid:true},{Mend:'match the iron to the iron'},(S)=>{ if(S.fl.lv){ say('',['The lever has been thrown. Somewhere, a door groans open.']); return; } sxOpen(S,'lv'); sxSay(S,'',['"Mend what is broken, not what is gone." The iron remembers being one piece. You throw the lever, and in the east wall, a heavy door sighs open.']); },'A lever is mended, not hammered.'),
    C:sxSpellObj({name:'Curse-mark',glyph:'curse',desc:'A mark glows on the archway: a circle, a cross, a very old sentence. It hums at you.',solid:true,when:S=>!S.fl.curse},{Ward:'hold the knot to your heart'},(S)=>{ S.fl.curse=1; coin(); sxSay(S,'',['You hold the Ward Charm to your heart and think of home. The mark flares violet, flinches, and goes out like a candle in a draught.']); },'A curse is turned by a ward, held to the heart.'),
    S:{name:'Steward\'s desk',glyph:'desk',desc:'A steward\'s desk, with a ledger left open.',use:(S)=>{ s2fl('stairHint',1); say('Steward\'s Ledger',['"Servants are to light the Crystal Stair in the colours of the flag: first the gold, for the Crown. Then the blue, for the sky. Then the white, for the swan. Never otherwise. The stair remembers."']); }}
  },
  guards:[{name:'Night Guard',path:[[2,2],[15,2],[15,11],[2,11]],speed:34,range:5,fov:62,head:'helm'},
          {name:'Night Guard',path:[[9,1],[9,11]],speed:30,range:5,fov:60,head:'helm',pause:0.8,scan:true}]
});

/* =========================================================
   CHAPTER 9 (CROWN): THE HEARTH VAULT
   ========================================================= */
S2.ch.c9c={route:'crown',title:'The Hollow Door',sub:'A banished duck goes home by the back way.',
  intro:['Emberwick cast you out in a ring of red runes. You have never been so glad of a small wooden disc.','At midnight, by the south wall, there is a door in the ground that is not on any map.'],
  recap:'In the Hearth Vault, Cinder showed you the twin of the king\'s crystal, and gave you a coal of the First Hearth.',
  start(){ s2set(0); },
  obj(s){ return ['At <b>midnight</b>, find the <b>Hollow Door</b> outside Emberwick\'s south wall, where the sealed gate is. Mallow will meet you there.',''][s]; }
};
S2.prop({id:'hollowdoor',red:[36,RH+3],glyph:'door',col:'#5a3a22',when:()=>s2at('c9c',0),mark:'!',use(){
  const night=g.clock>=23.5||g.clock<3;
  const go=()=>seq([[H3,['You came. You are very brave and I am very frightened and we shall be brave and frightened together.','Token, please. Quietly. The door is old and it hears.']],
    ['',['The disc fits a hollow in the stone that has been waiting for it. The ground opens like a held breath.']]],()=>sxEnter('vault1'));
  if(night) go();
  else choose('The Hollow Door','Stone, in the south wall, with a hollow the size of a disc. Mallow said midnight.',['Wait until midnight','Come back later'],k=>{ if(k===0){ fade(1.2); advanceClock(((23.6-g.clock)+24)%24); setTimeout(go,300); } },1);
}});
sxDef('vault1',{name:'The Hollow Door',theme:'hearth',indoor:true,dark:0.62,lightR:84,start:[1,4,'right'],follow:THR_FOLLOW,
  hint:'Shadows halve what they see. The pillars block their sight. Mallow keeps close, and they have not seen him either.',
  caughtLines:['"WHO\'S THERE?" A Hearthwarden raises a lantern, and the lantern shows a banished face.','You are hustled to the door and set outside. You go in again, and wait a minute.'],
  rows:sxGrid(26,9,[[0,4,'D'],[25,4,'>'],[5,2,'P'],[5,6,'P'],[10,3,'P'],[10,5,'P'],[15,2,'P'],[15,6,'P'],[8,1,3,2,','],[12,6,3,2,','],[19,3,4,3,','],[21,4,'.'],[18,1,1,3,'#'],[18,5,1,3,'#'],[18,4,'G'],[7,1,'L']]),
  exits:{D:{to:'world',wx:RX0+36,wy:RY0+RH+3},'>':{to:'vault2',tx:1,ty:6,dir:'right'}},
  objs:{
    P:{name:'Pillar',glyph:'pillar',block:true,col:'#8a5a4a'},
    L:{name:'Old lever',glyph:'lever',key:'pc',desc:'A bronze lever in the wall. It has been polished by many wings over many years.',solid:true,use:(S)=>{ if(S.fl.pc){ say('',['The portcullis is up.']); return; } sxOpen(S,'pc'); sxSay(S,H3,['Poppy found this one. She says it is how she gets to the Hearth to watch the fire.']); }},
    G:{name:'Portcullis',glyph:'gate',solid:true,when:S=>!S.fl.pc,desc:'An iron portcullis, lowered.'}
  },
  guards:[{name:'Hearthwarden',path:[[2,1],[23,1],[23,7],[2,7]],speed:34,range:5,fov:62,pal:WARDEN_PAL,head:'helm'},
          {name:'Hearthwarden',path:[[8,4],[16,4]],speed:28,range:5,fov:60,pal:WARDEN_PAL,head:'helm',pause:0.9,scan:true}],
  onEnter(S){ if(!S.fl.hint){ S.fl.hint=1; sxSay(S,H3,['It was a hiding place for the first founders. The Hearthwardens use it now to guard the way to the vault. They are the nicest ducks in the world, and in a bad mood, and they have been told to expect you.','Shadows help. Pillars help. I will keep close.']); } }
});
sxDef('vault2',{name:'The Hearth Vault',theme:'hearth',indoor:true,dark:0.5,lightR:110,start:[1,6,'right'],follow:THR_FOLLOW,
  rows:sxGrid(22,13,[[0,6,'<'],[11,12,'E'],[11,5,'H'],[8,3,'t'],[14,3,'t'],[8,9,'t'],[14,9,'t']]),
  exits:{'<':{to:'vault1',tx:24,ty:4,dir:'left'},E:{fn:S=>{ if(!S.fl.done){ say('',['Not yet. Cinder is waiting.']); return; } sxLeave(RX0+36,RY0+RH+3); S2.finish('c9c'); }}},
  objs:{
    t:{name:'Wall torch',glyph:'torch',light:true,lightR:80,solid:true},
    H:{name:'The Hearth Crystal',glyph:'crystal',solid:true,col:'#ff9d2e',light:true,lightR:120,desc:'A column of orange crystal, three times your height, set in an iron basin of coals. It hums, very low, one note. It is the same note.',use:(S)=>{ say('',['You lay a wing on the glass. It is warm, and it is humming in answer to something, the way a cello hums when another is played.','Through it, for one breath, you see a tall blue crystal, in a dark room, in another place. They are leaning toward each other.']); }}
  },
  npcs:[{name:'Elder Cinder',tx:11,ty:8,pal:RED_PALS[2],head:'wizard',talk:(S,n)=>{
    if(S.fl.done){ say('Elder Cinder',['Go, and be careful. I have not been this frightened since I was nine.'],null); return; }
    cutSeq(['vault'],[['Elder Cinder',['Little detective. You came. Mallow said you would. He is very bad at hiding that he is pleased.','Look at it. Our Hearth. The Great Hearth above is a window. This is the room behind the window: the first flame of Emberwick, lit from the Keeper\'s Lantern a hundred years ago, on the night we made this place a home.']],
      ['Elder Cinder',['The king\'s crystal, in the castle, was lit from the same lantern, by the same hand. Eider\'s hand. He carried the fire to both ends of the road, before the Edict, before the siege, when he and the red ducks were friends.','Two lights, one flame. When one dims, so does the other. When the ward on the Burnt Wood weakens, they both lean toward it, the way a candle leans toward an open door.','He is the ward. I think he has always been the ward. That is why he cannot come out.']],
      [H3,['Cinder, they will tell me I should hate him. I find I cannot. He was the only one who tried to say "shelter".']],
      ['Elder Cinder',['Take this. A coal of the First Hearth, in a cup. When you reach the king, it will light in his hands. He will know us by it.','And Detective. You are banished. The wall is sealed. I did not do that, and I could not stop it. If anyone asks, you were never here.']]],()=>{
      S.fl.done=1; addItem('hearthcoal'); coin(); hudCache.obj=null; toast('Received: the Coal of the First Hearth.',4200);
      sxSay(S,'Warden Ruddock',['(Ruddock stands in the vault door. He has been there a while.)','I did not see you. I am an old duck with bad eyes and a worse temper, and I have never been more certain I saw nothing.','Go. And apprentice: stay alive. I voted no. I would not like to be proven right.']);
    });
  }}],
  onEnter(S){ if(!S.fl.hint){ S.fl.hint=1; sxSay(S,'',['A round, low chamber, domed in red brick. In the centre, in an iron basin, a column of orange crystal. Around it, four torches, and a very small, very upright old duck, waiting.']); } }
});

/* =========================================================
   CHAPTER 10: THE KING IN THE DARK
   ========================================================= */
S2.ch.c10={route:'both',title:'The King in the Dark',sub:'Every door has a duck behind it.',
  intro:['Quackenhold, past midnight. The gate stands open an inch.','You know the way now, down the cold hall and up the stair that remembers, through a door that has been waiting a hundred years for somebody to knock.'],
  recap:'You met King Eider, who is not a ruler but a ward: the door that holds the Burnt Wood shut. He asked you to see what the Old Tree remembers.',
  start(){ s2set(0); sxEnter('throne'); },
  obj(s){ return ['Speak with <b>King Eider</b> in the dark, in the throne room of Castle Quackenhold.'][s]||''; }
};
const KQ=[['What are you keeping?','q1'],['Why a hundred years?','q2'],['What do you need from me?','q3']];
sxDef('throne',{name:'The Throne Room',theme:'crypt',indoor:true,dark:0.82,lightR:56,start:[2,5,'right'],
  rows:sxGrid(19,11,[[0,5,'<'],[8,1,3,1,'X'],[4,3,'k'],[4,7,'k'],[10,3,'k'],[10,7,'k'],[16,5,'E'],[14,3,3,1,'r'],[14,7,3,1,'r']]),
  exits:{'<':{fn:S=>{ if(!S.fl.done){ say('',['You cannot leave. Not yet. There is a question you have not asked.']); return; } sxLeave(KX+11,KY+11); S2.finish('c10'); }}},
  objs:{
    X:{name:'The King\'s Crystal',glyph:'crystal',light:true,lightR:120,solid:true,desc:'The tower crystal, seen from underneath, in the throne room where it began. It is the colour of a bruise.'},
    k:{name:'Pillar',glyph:'pillar',block:true,col:'#4a4658'},
    r:{name:'Carpet',glyph:'rug',solid:false,col:'#2a3a7a'},
    E:{name:'The Throne',glyph:'chair',solid:true,desc:'A high throne of grey stone, empty. Someone sat in it for a hundred years, and left a shape.'}
  },
  npcs:[{name:'King Eider',tx:15,ty:5,pal:{body:'#d8d4c8',wing:'#aaa595',bill:'#c9b27a'},head:'royal',still:true,talk:(S,n)=>{
    S.fl.talks=S.fl.talks||0;
    const asked=(k)=>S.fl[k];
    if(!S.fl.met){
      S.fl.met=1;
      seq([['King Eider',s2red()?['You brought the lantern. I can feel it from here. Like a hand on the back of the head.','Cinder\'s duck. Cinder\'s... I am sorry. I am so sorry. Please. Come where I can see you.']:['You read the draft. I know you did. I felt the page turn.','Detective. You are the first one to come who was not afraid of the dark, and not afraid of me.']],
        ['',['An old duck, white as ash, sits in the throne\'s shadow with his wings folded and his crown, quite bent, on the floor beside him. He is not bound to anything you can see. He has the stillness of a thing that has been very careful for a very long time.']],
        ['King Eider',['The voice at the door was mine. It is what is left, when I cannot spare the whole of myself for the door. It is only an echo. It says what I would say. It signs what I would sign.','Ask me, Detective. Ask me anything. It is the first time anyone has.']]],()=>{});
      return;
    }
    const left=KQ.filter(q=>!asked(q[1]));
    if(!left.length){ say('King Eider',['Go. And please, will you take the lantern\'s light with you?'],null); return; }
    choose('King Eider','Ask.',left.map(q=>q[0]).concat(['Not now']),k=>{
      if(k>=left.length) return;
      const key=left[k][1]; S.fl[key]=1; S.fl.talks++;
      let lines;
      if(key==='q1') lines=[['King Eider',['Three hundred ducks, in the shape of a wood. I spoke a word, on my wall, the last night of the siege, and a hundred years of things stopped. Gordamom, and all who followed him, and all the fire they had.','I will not say the word. Words are worn thin by use, and this one holds more than I do. But they are not dead. That is the cruelty, and the mercy. They dream. I have never known which.']]];
      else if(key==='q2') lines=[['King Eider',['Because I was told it would hold until it was safe. I have never known how to say it is safe. Nobody asked.','The ward is not a wall. It is a cradle, which is a cage that has been taught manners. It is tied to me. Where I go, it goes, so I do not go. When I fail, it fails. I am failing.','I am not telling you this for pity. I am telling you because the one thing worse than a king who cannot leave his door is a kingdom who believes the door is a wall.']]];
      else lines=[['King Eider',s2red()?['Take Cinder this answer. Yes. I would meet her. Not here. Somewhere that is neither castle nor town.','And then go to the Old Tree, in the Burnt Wood. It remembers the night. I cannot tell it. Only it can show it. If you will look, you will understand a thing I have not the courage to say.']:['Tell Captain Halbeak: hold the wall, and do not march. Tell the red town I would meet them. Not here. Somewhere that is neither castle nor town.','And then go to the Old Tree, in the Burnt Wood. It remembers the night. I cannot tell it. Only it can show it. If you will look, you will understand a thing I have not the courage to say.']]];
      seq(lines,()=>{
        if(S.fl.talks>=3){ S.fl.done=1; seq([['King Eider',['Go. Please. See it for yourself. I have been the only witness for a hundred years, and a witness who is also the accused is no witness at all.']],['',['(The echo at the door says, in the king\'s own voice, from nowhere: "Thank you." And, softer: "I was afraid you would not stay.")']]],()=>{}); }
      });
    },left.length);
  }}],
  onEnter(S){ if(!S.fl.hint){ S.fl.hint=1; sxSay(S,'',['The throne room is dark, and enormous, and very quiet. At the far end, under the crystal, a small shape in the shadow of a chair.']); } }
});

/* =========================================================
   CHAPTER 11: THE DREAMING TREE
   ========================================================= */
S2.ch.c11={route:'both',title:'The Dreaming Tree',sub:'A tree that remembers is a tree that cannot forgive, or cannot stop.',
  intro:['The Burnt Wood is the quietest place in the world. The ground is ash and the sky is a lid. Everything is grey, and everything hums.','At the centre stands an Old Tree, the tallest thing for a mile. There is a hollow in its trunk the size of a door. The hollow is humming the lullaby.'],
  recap:'The Old Tree showed you the night of the siege. You were asked whose child you are.',
  start(){ s2set(0); },
  obj(s){ return ['Travel to the <b>Old Tree</b> in the heart of the Burnt Wood (north-west of the kingdom). Be still, and look.','Walk back through the tree\'s dream. Find all three memories.'][s]||''; }
};
S2.prop({id:'oldtree',k:[-66,-64],glyph:'oldtree',when:()=>s2at('c11',0,1),mark:'!',use(){
  say('',['The trunk is split like a door. Inside, the air is warm. A note, four slow notes, is humming from the wood. As you step closer, the notes slow, and you lose track of whether you are standing, or being remembered.'],()=>{ s2set(1); sxEnter('dr1'); });
}});
const DREAM_PAL=[{body:'#8a7aa8',wing:'#6a5a88',bill:'#c9b0e0'}];
function dreamNote(S,key,title,pages){ if(S.fl[key]){ say(title,['(You have seen this.)']); return; } S.fl[key]=1; S.fl.n=(S.fl.n||0)+1; coin(); say(title,pages,()=>{ toast('Memory '+S.fl.n+' of 3.',2200); }); }
sxDef('dr1',{name:'The Fifth Fire',theme:'dream',fx:'dream',dark:0.55,lightR:90,start:[1,4,'right'],
  rows:sxGrid(22,9,[[0,4,'<'],[21,4,'>'],[5,2,'a'],[11,6,'b'],[15,2,'c'],[8,4,'g'],[4,6,'f'],[10,2,'f'],[17,6,'f']]),
  exits:{'<':{to:'world',wx:KX-66,wy:KY-62},'>':{cond:S=>S.fl.n>=3,msg:'The dream will not let you through yet. There are three things you have not seen.',to:'dr2',tx:1,ty:4,dir:'right'}},
  objs:{
    a:{name:'A child\'s shoe',glyph:'rock',col:'#a8885a',desc:'A very small shoe, left on the road.',use:(S)=>dreamNote(S,'ma','A shoe',['A very small red shoe, tied in a hurry. Somewhere, far behind, a child is calling a name. The march has not stopped for her. The march could not.','"They were all lost on the road," a voice says, wearily, from a long way off. "A thousand ducks, and by the fifth fire, forty-one families had a place at the table that nobody filled. We did not come to burn. We came to find them."'])},
    b:{name:'A torn banner',glyph:'statue',col:'#c0392b',desc:'A torn red banner, tied to a spear.',use:(S)=>dreamNote(S,'mb','The banner',['A red banner, torn across, tied to a spear that is leaning against a stump. A soldier has carved his name on the shaft. Three names, in three hands, each one crossed out.','"We carried this to the walls," says the tired voice. "I did not want it carried anywhere. I wanted it taken home."'])},
    c:{name:'A bread cloth',glyph:'rug',col:'#e8d8b0',desc:'A woman is handing out bread to the tired.',use:(S)=>dreamNote(S,'mc','The bread',['A woman, hooded, is breaking a loaf in the firelight, and passing it down the line without looking, so that nobody has to say thank you. She is humming. Four slow notes.','"Bree," says the tired voice, with a very great tenderness. "Of course it was Bree. She would not rest until the last one had eaten."'])},
    f:{name:'Campfire',glyph:'brazier',light:true,lightR:80,solid:true,desc:'A fire that was lit a hundred years ago, and is still lit, in a dream.'},
    g:{name:'Gordamom',glyph:'statue',col:'#8a2a2a',solid:true,use:(S)=>{ say('Gordamom',['(A big, old, red duck sits with his back to a stump, looking into the fire. He does not look up.)','"I know you. Not your face. The way you stand. Like someone who is listening for a question. Ask it, small one. Not now. At the gate."']); }}
  }
});
sxDef('dr2',{name:'The Wall',theme:'dream',fx:'dream',dark:0.55,lightR:90,start:[1,4,'right'],
  rows:sxGrid(18,9,[[0,4,'<'],[17,4,'>'],[8,3,'D'],[3,2,'f'],[3,6,'f'],[13,2,'f'],[13,6,'f']]),
  exits:{'<':{to:'dr1',tx:20,ty:4,dir:'left'},'>':{cond:S=>S.fl.seen,msg:'The dream is not finished with you. Look at what he is writing.',to:'dr3',tx:1,ty:4,dir:'right'}},
  objs:{
    f:{name:'Torch',glyph:'torch',light:true,lightR:80,solid:true},
    D:{name:'The Edict',glyph:'desk',desc:'A young duck bends over a page on the battlement, writing, by torchlight, with a hand that shakes. He does not see you.',use:(S)=>{
      if(S.fl.seen){ say('',['The dream has already turned the page.']); return; }
      seq([['Young Eider',['(He is much younger. The crown is too big for him. He writes: "Let those of the red feather go north, and be sheltered, until it is safe."','A hand reaches over his shoulder and strikes through a word. "That is not what the council wants," says someone behind him. "Say it as we told you."','He looks at the page for a very long time.)']],
        ['Young Eider',['"I wrote what I meant. And then I signed what they gave me. I told myself the two were the same thing."']],
        ['',['In the dream you cannot touch the page. You cannot change it. But as he signs, he looks up, straight at you, as if he had heard something.']]],()=>{
        choose('The dream','What do you do?',['Say, quietly, "That was not what you meant."','Say nothing. Stay with him while he signs.','Look away'],k=>{
          if(k===0){ s2led('truth',1); say('Young Eider',['(He lowers the pen. For a moment, in the dream, it is as though he almost does.)']); }
          else if(k===1){ s2led('mercy',1); say('',['You stay. It is not much. It is the only thing the dream allows.']); }
          else say('',['You look at the stones. There is a longer silence than you expected.']);
          S.fl.seen=1; coin();
        },2);
      });
    }}
  }
});
sxDef('dr3',{name:'The Two Words',theme:'dream',fx:'dream',dark:0.5,lightR:100,start:[1,4,'right'],
  rows:sxGrid(18,9,[[0,4,'<'],[17,4,'>'],[3,4,'a'],[15,4,'.'],[8,4,'m']]),
  exits:{'<':{to:'dr2',tx:16,ty:4,dir:'left'},'>':{fn:S=>{ if(!S.fl.done){ say('',['The two of them are waiting for you to answer.']); return; } sxLeave(KX-66,KY-62); S2.finish('c11'); }}},
  objs:{
    a:{name:'The Battlement',glyph:'altar',solid:true,desc:'A stretch of wall. Eider stands on it, with his wings out, looking down at the gate.'},
    m:{name:'The siege gate',glyph:'gate',solid:true,when:S=>false}
  },
  npcs:[{name:'Gordamom',tx:12,ty:4,pal:{body:'#8a2a2a',wing:'#5a1a1a',bill:'#c9a24a'},head:'helm',talk:(S,n)=>{
    if(S.fl.done){ say('Gordamom',['You are still here. Good. Go home, small one. You have a long way to go.'],null); return; }
    if(!S.fl.asked){
      S.fl.asked=1;
      cutSeq(['siege'],[['',['The dream turns. The wall is above you, and on it, a king, with a crown too big, looking down. At the gate, a very tired red duck with an army, sitting, not standing, with his wings in his lap.']],
        ['Gordamom',['I know why I came. I came for the children. And now there are ten thousand arrows pointing at us, and not one of them has asked.','Small one. You, who are not part of this. A question, before the end of the dream, because you listened, and no one else did.']]],()=>{
        choose('Gordamom','Whose child are you?',['I am nobody\'s child.','I think... I am yours.','I do not remember.','I am Mallardia\'s. I belong to the kingdom.'],k=>{
          s2fl('childAns',k);
          const rs=[['"Everyone is someone\'s," says Gordamom, not unkindly. "But I understand. Sometimes the someone is gone."'],['A very long silence. Then, wearily, with something nearly like a laugh: "No. Not mine. But I wish you were. I would be a better father to you than I was to anyone."'],['"Then you are very like the rest of us. Come. Sit by me. We shall remember together."'],['"The kingdom," says Gordamom, tasting it. "It is a good thing to belong to. It did not belong to us."']];
          if(k===1||k===2) s2led('kin',1); if(k===3) s2led('crown',1);
          say('Gordamom',rs[k],()=>{
            cutSeq(['siege'],[['',['Above, on the wall, the king raises both wings. He says a word. You cannot hear it. The dream holds the sound the way a hand holds water: it runs out between your fingers, and what is left is the shape of a mouth, and the silence after.','Below, at the gate, Gordamom stands, for the first time in the dream. He says a word of his own. This one is not silence. It is a shape, too, and it is a very different shape: open, like an arm, or a door.','The two words go up and down in the dream like two birds in a storm. And the world stops. And stays stopped.']],
              ['Gordamom',['That is all. That is all that happened. And a hundred years of the most patient dream there ever was.','Go back, small one. Tell my friend on the wall I am not angry. Tell him I never was. Tell him I am only very, very tired of being asleep.']]],()=>{ S.fl.done=1; coin(); toast('The dream lets go. You can leave.',3600); });
          });
        },3);
      });
      return;
    }
    say('Gordamom',['Whenever you are ready, small one.'],null);
  }},
  {name:'King Eider',tx:3,ty:3,pal:{body:'#d8d4c8',wing:'#aaa595',bill:'#c9b27a'},head:'royal',still:true,talk:(S,n)=>{ say('Young Eider',['(He does not see you. His eyes are on the gate, and they are wet.)','"I did it so no one else would have to."']); }}]
});

/* =========================================================
   CHAPTER 12: THE RECKONING
   ========================================================= */
S2.ch.c12={route:'both',title:'The Reckoning',sub:'Everything you did to get here is about to be read aloud.',
  intro:['Word reaches you the morning after the dream: a parley. Cinder and a delegation from the Hollow. Halbeak and the Crown\'s lords. A tent on the old watchtower hills, halfway between a town and a castle, neither of which will cross the road first.','Everyone is going to want to know what you have seen. Everyone is going to want to know what you have done.'],
  recap:'The summit at the watchtower failed. War is a matter of days.',
  start(){ s2set(0); },
  obj(s){ return ['Go to the <b>parley tent</b> on the old watchtower hills, west of Kingsbill.','Return to the road. The parley has failed. Choose where you stand.'][s]||''; }
};
function ledgerLines(){
  const L=s2().led, out=[];
  const w=(k,n)=>L[k]>=n;
  out.push(w('truth',3)?'You told the truth, even when it cost you. The clerk writes it down.':w('lie',1)?'You lied, once, when it was easy. The clerk writes it down.':'You told the truth when it was convenient. The clerk writes it down.');
  out.push(w('mercy',3)?'You spared those who deserved it, and some who did not. The clerk writes it down.':'You were not always merciful. The clerk writes it down.');
  if(w('pride',2)) out.push('You held your pride when you should have put it down. The clerk writes it down.');
  if(w('trust',2)) out.push('Mallow trusted you, and you kept it. The clerk writes it down.');
  return out;
}
S2.prop({id:'summit',k:[-76,-24],glyph:'banner',col:'#c9a6ff',when:()=>s2at('c12',0),mark:'!',use(){
  const red=s2red();
  seq([['',['A tent of grey cloth on the hill, two banners facing across a table, red and blue. Cinder sits at one side with Ruddock at her shoulder. Halbeak sits at the other, with a clerk. Mallow stands at the back, as small as he can make himself.']],
    ['Elder Cinder',['Detective. You have seen the king, and the Tree. They say you hold both halves of this. Say what you know, and say it plainly.']],
    ['Captain Halbeak',['And say what you have done. We have both heard. Every deed, good and ill, from both sides of the road. It is on the table. It is in the clerk\'s hand.']]],()=>{
    say('The Clerk',ledgerLines(),()=>{
      const L=s2().led, has=(k,n)=>(L[k]||0)>=n;
      S2.persuade({who:'The Parley',intro:['Silence. Both sides are looking at you, and neither side looks at the other.'],
        rounds:[
         {q:'Cinder: "Tell us what the king said. Truly."',opts:[
           {t:'Tell all of it: the ward, the door, the tree.',p:2,req:()=>has('truth',2),say:['"All of it." A murmur on both sides. "Then it is true. It is all true."']},
           {t:'Tell only the part that helps your side.',p:0,led:{lie:1},say:['The clerk writes a short line. The ink looks cold.']},
           {t:'Tell what you can, and say the rest is not yours to tell.',p:1,say:['"That, at least, is honest."']}]},
         {q:'Halbeak: "And the march? My men have sharpened their spears for three days."',opts:[
           {t:'"You stopped it. Thank you. Tell them so."',p:2,req:()=>s2fl('marchFinal')==='stopped'||s2fl('march')==='stopped',say:['"I did. And I would again." A pause. "It is easier to put down a spear when somebody has said thank you."']},
           {t:'"Your men marched, and I could not stop them. I am sorry."',p:1,req:()=>s2fl('march')==='went',led:{truth:1},say:['"Say it to them, Detective. Not to me."']},
           {t:'"Whoever marches first is the one who will be remembered."',p:1,say:['Silence. Somebody coughs.']}]},
         {q:'Both sides, at once: "What do you ask?"',opts:[
           {t:'"Three days. No spears. No wardens. Let the king and Cinder meet."',p:2,req:()=>has('trust',2)||has('crown',2)||has('kin',1),led:{trust:1},say:['Cinder looks at Halbeak. Halbeak looks at Cinder. For a moment, nobody breathes.']},
           {t:'"Ask the sleepers. They are the ones with the most to lose."',p:2,req:()=>has('mercy',2),say:['A long, long silence. "...We have not asked them. In a hundred years. We have not asked them."']},
           {t:'"Whatever is fair."',p:0,say:['"Fair," mutters Ruddock. "That is a word for people who have not been hurt."']}]}],
        need:4,
        win:()=>{ s2fl('summit',2); shatter(); },
        lose:()=>{ s2fl('summit',s2fl('summit')||1); shatter(); }});
    });
    function shatter(){
      const good=s2fl('summit')===2;
      seq([['',good?['It is almost there. Cinder has put out her wing. Halbeak has half-risen. You can feel the whole kingdom tipping, like a scale, toward something other than war.']:['It does not take. The silence goes on too long, on both sides, and in it you can hear the thing everyone has been afraid of.']],
        ['',['A horn sounds on the ridge. Not a Crown horn. Not an Emberwick horn. A small, nervous, rattling horn, that somebody has blown too soon.','Archers stand up on both hills. The tent goes over. Somebody shouts "Hold!", and somebody else shouts "Hold!", and neither of them is heard.']],
        ['Elder Cinder',['I will not be the one to draw first. I will not. But I will not be the one who does not draw, either.']],
        ['Captain Halbeak',['This is not what the king wanted. I know that. And I have a wall to defend.']],
        ['Hermit Mallow',['They will march. Both of them. We have days. Maybe hours.','Little detective. You will have to choose where you stand now. Not for ever. But for this part. And I will stand with you, wherever it is.']]],()=>{
        S2.finish('c12');
      });
    }
  });
}});
