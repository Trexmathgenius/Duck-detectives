'use strict';
const FULL=/[?&]full=/.test(location.search);
if(FULL) document.documentElement.classList.add('full');
/* ===== WORLD GENERATION (infinite, deterministic, tile = 32px) ===== */
const TS=32, REG=48, TOWN_W=36, TOWN_H=22, TRAIL_END=77;
const T={GRASS:0,TREE:1,DARK:2,WATER:3,PATH:4,COBBLE:5,ROCK:6,WALL:7,ROOF:8,DOOR:9,FOUNTAIN:10,LAMP:11,CRUMBS:12,FLOWER:13,BUSH:14,MUSH:15,HOUSEDOOR:16,WINDOW:17,STUMP:18,SIGN:19,
  BENCH:20,CRATE:21,HAY:22,STALL:23,BOARD:24,WELL:25,STATUE:26,FIRE:27};
const SOLID=new Set([T.TREE,T.DARK,T.ROCK,T.WALL,T.ROOF,T.DOOR,T.FOUNTAIN,T.LAMP,T.HOUSEDOOR,T.WINDOW,T.STUMP,T.SIGN,T.BENCH,T.CRATE,T.HAY,T.STALL,T.BOARD,T.WELL,T.STATUE,T.FIRE]);
const PROPS=new Set([T.BENCH,T.CRATE,T.HAY,T.STALL,T.BOARD,T.WELL,T.STATUE,T.FIRE]);
const taken=new Set();

let SEED=0, SEED_TEXT='';   /* world seed: 0 = the original world; anything else reshuffles every hash-driven feature */
function seedFromText(t){
  let h=2166136261;
  for(let i=0;i<t.length;i++){ h^=t.charCodeAt(i); h=Math.imul(h,16777619); }
  h=(h^(h>>>15))|0;
  return h||1;
}
function hash(x,y,s){
  let h=(Math.imul(x|0,374761393)+Math.imul(y|0,668265263)+Math.imul((s||0)|0,1442695041)+Math.imul(SEED,-2048144777))|0;
  h=Math.imul(h^(h>>>13),1274126177);
  h^=h>>>16;
  return (h>>>0)/4294967296;
}
/* ---- seeded fate (v1.26): every roll that matters (loot, fish, finds) comes from here, never Math.random.
   rnd() walks a stream seeded by the world seed and saved with the game, so the same seed gives the same luck.
   withRng(k,fn) pins the stream to a place (a plant, a dig tile, a cast) so that spot always gives the same result. */
let RNG_O=null;
function mul32(a){ return function(){ a=(a+0x6D2B79F5)|0; let t=Math.imul(a^(a>>>15),1|a); t=(t+Math.imul(t^(t>>>7),61|t))^t; return ((t^(t>>>14))>>>0)/4294967296; }; }
function rnd(){
  if(RNG_O) return RNG_O();
  const s=g.story||(g.story={});
  if(typeof s.rngS!=='number') s.rngS=(Math.imul(SEED|0,2654435761)^0x9e3779b9)|0;
  s.rngS=(s.rngS+0x6D2B79F5)|0; let t=s.rngS;
  t=Math.imul(t^(t>>>15),1|t); t=(t+Math.imul(t^(t>>>7),61|t))^t; return ((t^(t>>>14))>>>0)/4294967296;
}
function rndKey(){ let h=SEED|0; for(let i=0;i<arguments.length;i++) h=Math.imul(h^(arguments[i]|0),2246822519)+0x9e3779b9|0; return h; }
function withRng(k,fn){ const p=RNG_O; RNG_O=mul32(k|0); try{ return fn(); } finally{ RNG_O=p; } }
function vnoise(x,y,s){
  const xi=Math.floor(x), yi=Math.floor(y), xf=x-xi, yf=y-yi;
  const u=xf*xf*(3-2*xf), v=yf*yf*(3-2*yf);
  const a=hash(xi,yi,s), b=hash(xi+1,yi,s), c=hash(xi,yi+1,s), d=hash(xi+1,yi+1,s);
  return a+(b-a)*u+(c-a)*v+(a-b-c+d)*u*v;
}
function fbm(x,y,s){ return 0.65*vnoise(x,y,s)+0.35*vnoise(x*2.1,y*2.1,s+1); }
function trailY(x){
  return Math.round(3*Math.sin(x*0.13)*Math.min(1,x/25)*Math.min(1,(TRAIL_END+1-x)/25));
}
function forestAt(x,y){ return fbm(x*0.035-200,y*0.035+50,4); }

const townCache=new Map();
function getTown(rx,ry){
  const k=(rx+32768)*65536+(ry+32768);
  if(townCache.has(k)) return townCache.get(k);
  let t=null;
  const first=(rx===2&&ry===0);
  if(first||(Math.max(Math.abs(rx),Math.abs(ry))>=2&&hash(rx,ry,77)<0.2&&!kingdomBlocksTown(rx,ry))) t=buildTown(rx,ry,first);
  townCache.set(k,t);
  return t;
}
function townAtTile(x,y){
  const t=getTown(Math.floor((x+24)/REG),Math.floor((y+24)/REG));
  if(t&&x>=t.x0&&x<t.x0+t.w&&y>=t.y0&&y<t.y0+t.h) return t;
  return null;
}
function nearTown(x,y,m){
  const t=getTown(Math.floor((x+24)/REG),Math.floor((y+24)/REG));
  return !!(t&&x>=t.x0-m&&x<t.x0+t.w+m&&y>=t.y0-m&&y<t.y0+t.h+m);
}
function darkAt(x,y){
  const d=Math.hypot(x,y);
  if(d<12) return 0;
  if(Math.abs(x-KX)<=KW+16&&Math.abs(y-KY)<=KH+16) return 0;
  if(nearTown(x,y,5)) return 0;
  let n=fbm(x*0.045+500,y*0.045-300,9);
  n+=0.4*Math.exp(-((x-44)*(x-44)+(y-5)*(y-5))/90);
  const lv=Math.max(0,Math.min(1,(n-0.6)/0.12));
  return lv*Math.min(1,(d-12)/10);
}

const PALS=[
  {body:'#f4f4ee',wing:'#d4d8cf',bill:'#ff9d2e'},
  {body:'#8d7352',wing:'#6f5a40',head:'#2f7d57',bill:'#e6c441',collar:'#ffffff'},
  {body:'#9aa4ad',wing:'#7d8791',bill:'#ff9d2e'},
  {body:'#2b2f36',wing:'#1f2227',bill:'#ff9d2e'},
  {body:'#d9a066',wing:'#b9814b',bill:'#6b4a2f'},
  {body:'#e9b7c8',wing:'#c993a8',bill:'#ff9d2e'},
  {body:'#87b4d8',wing:'#6a97bd',bill:'#ffb347'}
];
const NPC_NAMES=['Waddles','Pip','Marigold','Sir Quackington','Bessie','Dot','Mr. Feathers','Olive','Ferdinand','Pebbles','Gus','Daisy','Nugget','Mabel','Bartholomew','Clementine'];
const KEEPER_NAMES=['Hortense','Biscuit','Mr. Crumb','Lulu','Orville','Tansy','Wilbur','Fig','Poppy','Hubert','Juniper','Cosmo','Edna','Rufus','Tilly','Basil'];
const SHOP_KINDS=['bakery','market','supply','curio','cafe','florist','books','tailor','toys'];
const SHOP_NAMES={
  bakery:['Crumb & Co. Bakery','The Rising Loaf','Quackers Bakehouse'],
  market:['Pond Market','Green Pea Grocer','The Seed Stall'],
  supply:['Sleuth Supply','Clue & Cue Outfitters','Magnifique Goods'],
  curio:['Odd Feather Curios','The Dusty Nest','Shiny Things'],
  cafe:['The Warm Puddle Cafe','Sip & Paddle','Acorn Cup Cafe'],
  florist:['Petal Pushers','The Daisy Chain','Bill & Bloom'],
  books:['Dog-Eared Books','The Quill Shelf','Page & Plume'],
  tailor:['Stitch in Time','The Feather Tailor','Snug & Co. Haberdashery'],
  toys:['Squeaky Things','The Toy Pond','Wind-Up Wonders']
};
/* opening hours (24h clock) */
const HOURS={bakery:[6,19],market:[7,19],supply:[9,18],curio:[10,21],cafe:[7,22],florist:[8,18],books:[9,20],tailor:[9,18],toys:[9,19]};
const ROOFS=['#b5483a','#3a7ca5','#7a5195','#4c8c4a','#c9822b','#2f8f8a'];
const WALLS=['#e8d9b5','#d9e2c9','#d6d0e8','#f0cfc0','#cfe2e8'];

/* Every town picks one of these at random: it sets the ground, colours, centrepiece, street plan, decorations and weather. */
const STYLES=[
  {id:'cobble',label:'a cobblestone square',plaza:'cobble',grass:['#4c8b43','#52944a','#488740'],blade:'#3c7835',tuft:'#66aa5c',
   roofs:ROOFS,walls:WALLS,tree:{cols:['#2f6b34','#3a7d3d','#47914a']},centers:['fountain','fountain','statue','well'],patterns:['band','streets','plaza'],
   decor:{tree:.045,flower:.07,hay:0,mush:0,crate:.5,stall:0},part:null,
   pre:['Puddle','Reed','Mallard','Feather','Cattail','Downy','Bill','Quill','Marsh','Pebble'],suf:['wick','ford','ton','hollow','bay','dale','mere'],
   map:{plaza:'#98a3b0',grass:'#5b9a4e'}},
  {id:'garden',label:'a flower-strewn garden village',plaza:'dirt',grass:['#58a04c','#5eaa52','#509a46'],blade:'#438a3c',tuft:'#7fca6e',
   roofs:['#e07aa8','#f2a65a','#8e7cc3','#6bb5a0','#e8c547','#7fb3e0'],walls:['#fdf0d5','#f6e3e8','#e6f2dc','#e3ecf7'],tree:{cols:['#3b8a45','#4aa053','#6bc468']},
   centers:['pond','pond','fountain'],patterns:['streets','plaza'],decor:{tree:.05,flower:.3,hay:0,mush:0,crate:.2,stall:0},part:'petals',
   pre:['Petal','Clover','Daisy','Bloom','Meadow','Lily','Tulip','Honey'],suf:['patch','bower','glen','ford','mead','dell'],
   map:{plaza:'#c9b48a',grass:'#68b25c'}},
  {id:'harvest',label:'a golden harvest hamlet',plaza:'dirt',grass:['#9a9a3e','#a2a044','#92923a'],blade:'#7a7a2c',tuft:'#c0b85a',
   roofs:['#a8432b','#c46a2a','#8a5a2b','#b5483a','#d1953a'],walls:['#f0dcb0','#e8cfa0','#dcc8a8','#f2d8b8'],tree:{cols:['#b8481c','#d9822b','#e8b13a']},
   centers:['well','bonfire','well'],patterns:['band','streets'],decor:{tree:.04,flower:.02,hay:.05,mush:0,crate:.7,stall:0},part:'leaves',
   pre:['Barley','Acorn','Maple','Haystack','Pumpkin','Russet','Wheat','Cider'],suf:['field','stead','barn','hollow','crossing','ton'],
   map:{plaza:'#b99a63',grass:'#a39a45'}},
  {id:'frost',label:'a snowy burrow',plaza:'frost',snow:true,grass:['#e8f0f7','#dfe9f3','#eef4fa'],blade:'#b3c8de',tuft:'#ffffff',
   roofs:['#5b7fa6','#7b9ec4','#8c5e58','#4d6d8a','#a05a5a'],walls:['#f4f1ea','#e7edf4','#efe6dc'],snowRoof:true,tree:{cols:['#2d5f4a','#3a7459','#eaf4f8'],pine:true},
   centers:['bonfire','fountain','statue'],patterns:['streets','plaza','band'],decor:{tree:.06,flower:0,hay:0,mush:0,crate:.5,stall:0},part:'snow',
   pre:['Frost','Icicle','Sleet','Snowdrift','Winter','Hoar','Chill','Flurry'],suf:['mere','burrow','peak','ford','haven','glade'],
   map:{plaza:'#b8cde0',grass:'#e4eef6'}},
  {id:'cove',label:'a sunny sandy cove',plaza:'sand',grass:['#b9c77a','#c2cf84','#adbd70'],blade:'#8fa05a',tuft:'#d8dfa0',
   roofs:['#2aa7a0','#e8745a','#f2b84b','#3f7fc4','#e0587a'],walls:['#fbf1d6','#fde8c8','#e9f4f1','#fff5e0'],tree:{cols:['#4a9a52','#63b564','#8ad07a']},
   centers:['pond','well','statue'],patterns:['streets','plaza','band'],decor:{tree:.03,flower:.06,hay:0,mush:0,crate:.7,stall:0},part:'sparkle',
   pre:['Sandy','Driftwood','Shell','Tide','Gull','Salt','Pebble','Sunny'],suf:['cove','bay','shore','strand','wharf','landing'],
   map:{plaza:'#e0cf9a',grass:'#bccb7c'}},
  {id:'grove',label:'a glowing mushroom grove',plaza:'moss',grass:['#2f6b4f','#357657','#2b6247'],blade:'#1f4f3a',tuft:'#4f9a73',
   roofs:['#6b4fa0','#2f8f8a','#a05a8a','#3a6f9a','#7a9a3a'],walls:['#d5cfe0','#cfe0d5','#e0d5c0','#c9d9e0'],tree:{cols:['#1f5a3f','#2a7050','#3e9068']},
   centers:['statue','well','pond'],patterns:['streets','plaza','band'],decor:{tree:.06,flower:.1,hay:0,mush:.08,crate:.3,stall:0},part:'spores',
   pre:['Moss','Mush','Fern','Glow','Spore','Hollow','Lichen','Twilight'],suf:['grove','glen','hollow','bower','thicket','den'],
   map:{plaza:'#5f8a70',grass:'#2f6b4f'}},
  {id:'bazaar',label:'a bustling bazaar town',plaza:'brick',grass:['#6aa04a','#70a850','#659a45'],blade:'#528538',tuft:'#8cc46a',
   roofs:['#d9482b','#f2a02a','#2a9d8f','#c8366b','#3a7bd5'],walls:['#f5e3b8','#f0d9a8','#fae8c8'],tree:{cols:['#2f6b34','#3a7d3d','#47914a']},
   centers:['fountain','statue'],patterns:['band','band','streets'],decor:{tree:.035,flower:.05,hay:0,mush:0,crate:.8,stall:1},part:'confetti',
   pre:['Bargain','Haggle','Trinket','Stall','Penny','Bustle','Barrel','Crumb'],suf:['market','square','bazaar','row','cross','mart'],
   map:{plaza:'#b8654a',grass:'#6aa04a'}}
];

/* Building slots per layout: [x offset, y offset] inside the 36x22 town box. */
const ROW4=[2,10,18,26], ROW3=[3,15,27];
const LAYOUTS={
  A:{N:ROW4.map(x=>[x,2]),S:ROW3.map(x=>[x,15]),first:'N',max:5},
  B:{N:ROW3.map(x=>[x,2]),S:ROW4.map(x=>[x,15]),first:'S',max:5},
  C:{N:ROW4.map(x=>[x,2]),S:ROW4.map(x=>[x,15]),first:'N',max:6}
};

/* town sizes: a hamlet of a few shops up to a sprawling city (the region is 48 tiles square, so a town never needs more than 46) */
const TOWN_CLASS={hamlet:{name:'hamlet'},village:{name:'village'},town:{name:'town'},city:{name:'city'}};
function townClassOf(rx,ry,first){
  if(first) return {cls:'village',w:36,h:22};
  let r=hash(rx,ry,108);
  /* big towns keep clear of the kingdom and the red clans' land */
  let near=false;
  for(let dy=-1;dy<=1&&!near;dy++) for(let dx=-1;dx<=1;dx++){
    if((dx||dy)&&typeof kingdomBlocksTown==='function'&&kingdomBlocksTown(rx+dx,ry+dy)) near=true;
    if(typeof RRX!=='undefined'&&Math.abs(rx+dx-RRX)<=0&&Math.abs(ry+dy-RRY)<=0) near=true;
  }
  if(near&&r>=0.62) r=0.5;
  if(r<0.27) return {cls:'hamlet',w:hash(rx,ry,109)<0.5?20:28,h:22};
  if(r<0.62) return {cls:'village',w:36,h:22};
  if(r<0.86) return {cls:'town',w:44,h:22};
  return {cls:'city',w:44,h:35};
}
/* building slots for a footprint: [x,y] offsets, a front row (shops fill it first) and the rest */
function slotLayout(W,H,key){
  const nc=Math.round((W-4)/8), spread=(m,y)=>{ const a=[]; for(let i=0;i<m;i++) a.push([m===1?(W-6)/2:2+Math.round(i*(W-10)/(m-1)),y]); return a; };
  if(nc===4&&H===22) return {first:LAYOUTS[key][LAYOUTS[key].first].slice(),rest:LAYOUTS[key][LAYOUTS[key].first==='N'?'S':'N'].slice(),max:LAYOUTS[key].max};
  const full=y=>{ const a=[]; for(let i=0;i<nc;i++) a.push([2+8*i,y]); return a; };
  const N=key==='B'?spread(Math.max(1,nc-1),2):full(2), S=key==='A'?spread(Math.max(1,nc-1),15):full(15);
  let rest=key==='B'?S:S; let first=N;
  if(key==='B'){ first=S; rest=N; }
  rest=rest.slice();
  if(H>22){ const S2=full(28); rest=rest.concat(S2); }
  return {first:first.slice(),rest:rest,max:first.length+rest.length};
}
function isPlaza(t,lx,ly){
  const W=t.w, H=t.h, mx=W/2;
  if(ly<6||ly>H-2) return false;
  if(lx<=1||lx>=W-2) return true;
  const p=t.pattern;
  if(p==='band') return ly<=H-3;
  if(ly<=7||ly>=19) return true;
  if(ly>=10&&ly<=12) return true;
  if(Math.abs(lx-mx)<=2) return true;
  if(p==='plaza'){ const dx=(lx-mx)/(W/4), dy=(ly-11)/5.6; return dx*dx+dy*dy<=1; }
  return false;
}

function buildTown(rx,ry,first){
  const SZ=townClassOf(rx,ry,first), W=SZ.w, H=SZ.h, cx=rx*REG, cy=ry*REG, x0=cx-W/2, y0=cy-11;
  const rnd=i=>hash(rx,ry,100+i);
  const style=first?STYLES[0]:STYLES[Math.floor(rnd(3)*STYLES.length)];
  const name=first?'Puddlewick':style.pre[Math.floor(rnd(1)*style.pre.length)]+style.suf[Math.floor(rnd(2)*style.suf.length)];
  const layoutKey=first?'C':['A','B','C'][Math.floor(rnd(4)*3)];
  const L=slotLayout(W,H,layoutKey);
  const pattern=first?'band':(H>22?'band':style.patterns[Math.floor(rnd(5)*style.patterns.length)]);
  const center=first?'fountain':style.centers[Math.floor(rnd(6)*style.centers.length)];
  /* which shops live here */
  let kinds;
  if(first) kinds=['bakery','market','supply','curio','cafe','florist','hardware'];
  else{
    const slotsN=L.first.length+L.rest.length;
    let n=SZ.cls==='hamlet'?2+Math.floor(rnd(7)*2):SZ.cls==='village'?4+Math.floor(rnd(7)*(L.max-3)):SZ.cls==='town'?6+Math.floor(rnd(7)*4):9+Math.floor(rnd(7)*5);
    n=Math.max(2,Math.min(n,slotsN-1,SHOP_KINDS.length));
    kinds=SHOP_KINDS.slice().sort((a,b)=>hash(rx,ry,400+SHOP_KINDS.indexOf(a))-hash(rx,ry,400+SHOP_KINDS.indexOf(b))).slice(0,n);
    if(!kinds.some(k=>k==='bakery'||k==='market'||k==='cafe')) kinds[kinds.length-1]='market';
    if(!kinds.includes('hardware')){ const ix=kinds.findIndex(k=>k!=='bakery'&&k!=='market'&&k!=='cafe'); kinds[ix<0?0:ix]='hardware'; }
  }
  /* shops take the front row first, then scatter across the rest */
  const back=L.rest.map((s,i)=>({s,o:hash(rx,ry,420+i)})).sort((a,b)=>a.o-b.o).map(e=>e.s);
  const order=L.first.concat(back);
  const buildings=[], houses=[];
  order.forEach((s,i)=>{
    const bx=x0+s[0], by=y0+s[1];
    if(i<kinds.length){
      const kind=kinds[i];
      buildings.push({
        kind, enterable:true, idx:buildings.length, x:bx, y:by, w:6, h:4,
        name:SHOP_NAMES[kind][Math.floor(rnd(10+i)*3)],
        roof:style.roofs[Math.floor(rnd(20+i)*style.roofs.length)],
        wall:style.walls[Math.floor(rnd(30+i)*style.walls.length)],
        doorX:bx+3, doorY:by+3, snow:!!style.snowRoof,
        keeper:{name:KEEPER_NAMES[(i*3+Math.floor(rnd(40)*16))%16], pal:PALS[Math.floor(rnd(41+i)*PALS.length)], acc:{head:hash(rx,ry,450+i)<0.35?'cap':null,neck:hash(rx,ry,460+i)<0.4?'scarf':null}}
      });
    } else {
      houses.push({
        kind:'house', enterable:false, idx:houses.length, x:bx, y:by, w:6, h:4, name:'',
        roof:style.roofs[Math.floor(rnd(60+i)*style.roofs.length)],
        wall:style.walls[Math.floor(rnd(70+i)*style.walls.length)],
        doorX:bx+3, doorY:by+3, snow:!!style.snowRoof
      });
    }
  });
  const t={rx,ry,key:rx+','+ry,cx,cy,x0,y0,w:W,h:H,cls:SZ.cls,name,style,layout:layoutKey,pattern,center,buildings,houses,all:buildings.concat(houses),npcs:[],
    priceSeed:rnd(5),fixed:new Map(),lamps:[],board:null,sells:new Set(),spots:null,favCache:{}};
  buildings.forEach(b=>STOCK[b.kind].forEach(id=>t.sells.add(id)));
  /* fixed furniture */
  const fx=(x,y,code)=>{ t.fixed.set(x+','+y,code); };
  if(center==='fountain'){ for(let j=-2;j<=0;j++) for(let i=-1;i<=1;i++) fx(cx+i,cy+j,T.FOUNTAIN); }
  else if(center==='pond'){ for(let j=-2;j<=0;j++) for(let i=-2;i<=2;i++) fx(cx+i,cy+j,T.WATER); }
  else if(center==='well') fx(cx,cy-1,T.WELL);
  else if(center==='statue') fx(cx,cy-1,T.STATUE);
  else if(center==='bonfire') fx(cx,cy-1,T.FIRE);
  const lampSpots=[[-9,-3],[9,-3],[-9,3],[9,3],[-15,-2],[15,-2],[-15,2],[15,2],[-21,-2],[21,-2],[-21,2],[21,2],[-7,-3],[7,3]].filter(p=>Math.abs(p[0])<=W/2-2);
  if(H>22) for(const ly of [9,17]) for(const lx of [-14,-4,6,16]) if(Math.abs(lx)<=W/2-2) lampSpots.push([lx,ly]);
  lampSpots.forEach(p=>{ fx(cx+p[0],cy+p[1],T.LAMP); t.lamps.push({x:cx+p[0],y:cy+p[1]}); });
  t.board={x:cx+5,y:cy-3}; fx(t.board.x,t.board.y,T.BOARD);
  fx(cx-6,cy+2,T.BENCH); fx(cx+6,cy+2,T.BENCH);
  /* crates beside shops */
  for(const b of t.all){
    if(hash(rx,ry,500+b.x*3+b.y)<style.decor.crate){
      const px=hash(rx,ry,510+b.x)<0.5?b.x+b.w:b.x-1;
      if(!t.fixed.has(px+','+(b.y+3))) fx(px,b.y+3,T.CRATE);
    }
  }
  /* bazaar stalls */
  if(style.decor.stall){
    for(const ly of [8,14]) for(let lx=4;lx<=W-4;lx+=4){
      const sx=x0+lx, sy=y0+ly;
      if(t.fixed.has(sx+','+sy)) continue;
      if(Math.abs(lx-W/2)<=3) continue;
      if(t.fixed.has((sx-1)+','+sy)||t.fixed.has((sx+1)+','+sy)) continue;
      if(t.all.some(b=>Math.abs(b.doorX-sx)<=0)) continue;
      if(isPlaza(t,lx,ly)&&hash(rx,ry,530+lx+ly)<0.75) fx(sx,sy,T.STALL);
    }
  }
  /* townducks: nine of them; the last is always a night owl */
  const cand=[];
  for(let ly=2;ly<=H-2;ly++) for(let lx=2;lx<=W-3;lx++){
    const x=x0+lx, y=y0+ly;
    const c=townTile(t,x,y);
    if(SOLID.has(c)||c===T.WATER) continue;
    if(t.all.some(b=>Math.abs(b.doorX-x)<=0&&y===b.doorY+1)) continue;
    if(Math.abs(x-cx)<=3&&Math.abs(y-(cy-1))<=3) continue;
    cand.push([x,y]);
  }
  for(let i=0;i<9;i++){
    const pk=cand[Math.floor(hash(rx,ry,200+i*7)*cand.length)]||[x0+3,y0+11];
    const persona=(i===8)?11:(i+Math.floor(rnd(52)*11))%11;
    t.npcs.push({
      idx:i, name:NPC_NAMES[(i*3+Math.floor(rnd(50)*16))%16],
      pal:PALS[(i+Math.floor(rnd(51)*7))%7],
      acc:{head:[null,null,'cap','bow','crown','hat'][Math.floor(hash(rx,ry,600+i)*6)],neck:[null,null,'scarf','bowtie'][Math.floor(hash(rx,ry,610+i)*4)]},
      persona, owl:persona===11,
      town:t, x:(pk[0]+0.5)*TS, y:(pk[1]+0.95)*TS, hx:(pk[0]+0.5)*TS, hy:(pk[1]+0.95)*TS,
      dir:'down', moving:false, t:Math.random()*2, phase:0, talking:false
    });
  }
  return t;
}

/* every grass tile inside the town: used for hiding lost things */
function townSpots(t){
  if(t.spots) return t.spots;
  const a=[], seen=new Set(), q=[[t.x0,t.cy]];
  seen.add(t.x0+','+t.cy);
  while(q.length){
    const p=q.pop(), x=p[0], y=p[1], c=townTile(t,x,y);
    if((c===T.GRASS||c===T.FLOWER)&&!(Math.abs(x-t.cx)<=2&&Math.abs(y-t.cy)<=3)) a.push(p);
    for(const d of [[1,0],[-1,0],[0,1],[0,-1]]){
      const nx=x+d[0], ny=y+d[1], k=nx+','+ny;
      if(seen.has(k)||nx<t.x0||nx>=t.x0+t.w||ny<t.y0||ny>=t.y0+t.h) continue;
      seen.add(k);
      if(!SOLID.has(townTile(t,nx,ny))) q.push([nx,ny]);
    }
  }
  a.sort((u,v)=>u[0]-v[0]||u[1]-v[1]);
  t.spots=a; return a;
}
function townTile(t,x,y){
  for(const b of t.all){
    if(x>=b.x&&x<b.x+b.w&&y>=b.y&&y<b.y+b.h){
      const row=y-b.y;
      if(row<2) return T.ROOF;
      if(x===b.doorX&&y===b.doorY) return b.enterable?T.DOOR:T.HOUSEDOOR;
      if(row===2&&(x-b.x===1||x-b.x===4)) return T.WINDOW;
      return T.WALL;
    }
  }
  const f=t.fixed.get(x+','+y);
  if(f!==undefined) return f;
  const lx=x-t.x0, ly=y-t.y0;
  if(isPlaza(t,lx,ly)) return T.COBBLE;
  const d=t.style.decor;
  const edge=(ly<=1||ly>=t.h-1||(lx>=2&&lx<=3)||(lx>=t.w-4&&lx<=t.w-3));
  if(hash(x,y,17)<d.tree*(edge?2.6:1)) return T.TREE;
  if(d.hay&&hash(x,y,18)<d.hay) return T.HAY;
  if(d.mush&&hash(x,y,19)<d.mush) return T.MUSH;
  return hash(x,y,9)<d.flower?T.FLOWER:T.GRASS;
}
function buildingAt(x,y){
  const t=townAtTile(x,y);
  if(!t) return null;
  for(const b of t.all) if(x>=b.x&&x<b.x+b.w&&y>=b.y&&y<b.y+b.h) return b;
  return null;
}
/* the town (and its style) that owns this tile or the 3-tile margin around it */
function styleAt(x,y){
  const t=getTown(Math.floor((x+24)/REG),Math.floor((y+24)/REG));
  if(t&&x>=t.x0-3&&x<t.x0+t.w+3&&y>=t.y0-3&&y<t.y0+t.h+3) return t.style;
  return null;
}
function inPlazaTile(x,y){
  const t=townAtTile(x,y);
  return !!(t&&isPlaza(t,x-t.x0,y-t.y0))||kingdomPaved(x,y);
}

function genTile(x,y){
  { const kt=kingdomTile(x,y); if(kt!==null) return kt; }
  const town=townAtTile(x,y);
  if(town) return townTile(town,x,y);
  if(x===3&&y===-1) return T.SIGN;
  const d=Math.hypot(x,y);
  if(x>=1&&x<=TRAIL_END){
    const dy=y-trailY(x);
    if(dy===0) return T.PATH;
    if(dy===1&&hash(x,y,5)<0.4) return T.PATH;
    if(Math.abs(dy)<=2) return hash(x,y,6)<0.08?T.FLOWER:T.GRASS;
  }
  if(d<4) return hash(x,y,7)<0.12?T.FLOWER:T.GRASS;
  if(nearTown(x,y,3)) return hash(x,y,8)<0.06?T.FLOWER:T.GRASS;
  if(fbm(x*0.06+100,y*0.06+100,3)>0.72&&d>9) return T.WATER;
  const dk=darkAt(x,y), fd=forestAt(x,y);
  let prob=fd<0.4?0.035:0.05+fd*0.35;
  if(dk>0.05) prob=Math.max(prob,0.15+0.25*dk);
  if(hash(x,y,11)<prob){
    if(dk>0.3&&hash(x,y,12)<0.25+dk*0.65) return T.DARK;
    return T.TREE;
  }
  if(hash(x,y,14)<0.0075&&!taken.has(x+','+y)) return T.CRUMBS;
  const q=hash(x,y,13);
  if(q<0.010) return T.ROCK;
  if(q<0.016) return T.STUMP;
  if(q<0.07) return dk>0.3?T.MUSH:T.FLOWER;
  if(q<0.10) return T.BUSH;
  if(q<0.115) return T.MUSH;
  return T.GRASS;
}

const tileCache=new Map();
function tkey(x,y){ return (x+1048576)*2097152+(y+1048576); }
function tileAt(x,y){
  const k=tkey(x,y);
  let v=tileCache.get(k);
  if(v===undefined){
    v=genTile(x,y);
    if(tileCache.size>80000) tileCache.clear();
    tileCache.set(k,v);
  }
  return v;
}

/* map pixel colors */
const MAPCOL={};
MAPCOL[T.GRASS]='#5b9a4e';MAPCOL[T.TREE]='#2f6b34';MAPCOL[T.DARK]='#5b2d8a';MAPCOL[T.WATER]='#3f86c4';
MAPCOL[T.PATH]='#c9a468';MAPCOL[T.COBBLE]='#98a3b0';MAPCOL[T.ROCK]='#7d838c';MAPCOL[T.WALL]='#e8d9b5';
MAPCOL[T.ROOF]='#c0584a';MAPCOL[T.DOOR]='#7b4a22';MAPCOL[T.FOUNTAIN]='#6fb7e8';MAPCOL[T.LAMP]='#ffd166';
MAPCOL[T.CRUMBS]='#ffcf5a';MAPCOL[T.FLOWER]='#e07aa8';MAPCOL[T.BUSH]='#3f7d3b';MAPCOL[T.MUSH]='#c7a0e6';
MAPCOL[T.HOUSEDOOR]='#5c3d7a';MAPCOL[T.WINDOW]='#8ecae6';MAPCOL[T.STUMP]='#8a6a3b';MAPCOL[T.SIGN]='#a8793f';
MAPCOL[T.BENCH]='#8a6238';MAPCOL[T.CRATE]='#a8793f';MAPCOL[T.HAY]='#d9b84a';MAPCOL[T.STALL]='#d9482b';MAPCOL[T.BOARD]='#c79a5a';
MAPCOL[T.WELL]='#8a8f98';MAPCOL[T.STATUE]='#e0b84a';MAPCOL[T.FIRE]='#ff7a2a';
function mapColor(x,y){
  let t=tileAt(x,y);
  if(t===T.CRUMBS) t=T.GRASS;
  const st=styleAt(x,y);
  if(st){ if(t===T.COBBLE) return st.map.plaza; if(t===T.GRASS||t===T.FLOWER) return st.map.grass; if(t===T.ROOF) return '#c0584a'; }
  if(t===T.GRASS||t===T.FLOWER||t===T.BUSH){ if(darkAt(x,y)>0.3) return '#3d3a5c'; }
  if(t===T.TREE&&darkAt(x,y)>0.3) return '#3a2a58';
  return MAPCOL[t]||'#5b9a4e';
}

/* ===== RENDERING HELPERS ===== */
function circ(c,x,y,r,col){c.fillStyle=col;c.beginPath();c.arc(x,y,r,0,6.2832);c.fill();}
function ell(c,x,y,rx,ry,col){c.fillStyle=col;c.beginPath();c.ellipse(x,y,rx,ry,0,0,6.2832);c.fill();}
function rect(c,x,y,w,h,col){c.fillStyle=col;c.fillRect(x,y,w,h);}

function drawDuck(c,x,y,dir,phase,moving,pal,o){
  o=o||{};
  const sc=o.scale||1, wet=!!o.wet;
  c.save(); c.translate(x,y); c.scale(sc,sc);
  const bob=moving?-Math.abs(Math.sin(phase))*2:0;
  const sink=wet?5:0;
  const head=pal.head||pal.body;
  const side=(dir==='left'||dir==='right');
  const fx=dir==='right'?1:dir==='left'?-1:0;
  ell(c,0,0,11,4,'rgba(0,0,0,0.25)');
  if(!wet){
    const s=moving?Math.sin(phase):0;
    rect(c,-5,-6,3,6-(s>0?1:0),'#ff8a1f');
    rect(c,2,-6,3,6-(s<0?1:0),'#ff8a1f');
  }
  const by=-12+bob+sink;
  if(side){
    c.fillStyle=pal.body; c.beginPath(); c.moveTo(-fx*8,by-3); c.lineTo(-fx*16,by-9); c.lineTo(-fx*9,by+4); c.fill();
  }
  ell(c,-fx*1,by,10,8,pal.body);
  if(side) ell(c,-fx*2,by,6,4,pal.wing);
  else{ ell(c,-9,by,3,5,pal.wing); ell(c,9,by,3,5,pal.wing); }
  const hx=fx*5, hy=-22+bob+sink;
  if(wet){ ell(c,0,-3,13,5,'rgba(59,130,196,0.78)'); c.strokeStyle='rgba(255,255,255,0.65)'; c.lineWidth=1; c.beginPath(); c.ellipse(0,-3,13+Math.sin(phase*0.7)*2,5,0,0,6.2832); c.stroke(); }
  circ(c,hx,hy,7,head);
  if(pal.collar) rect(c,hx-5,hy+5,10,2,pal.collar);
  if(dir==='right') rect(c,hx+5,hy,7,4,pal.bill);
  else if(dir==='left') rect(c,hx-12,hy,7,4,pal.bill);
  else if(dir==='down') ell(c,hx,hy+4,4,2.6,pal.bill);
  if(dir==='right') circ(c,hx+3,hy-2,1.5,'#111');
  else if(dir==='left') circ(c,hx-3,hy-2,1.5,'#111');
  else if(dir==='down'){ circ(c,hx-3,hy-1,1.5,'#111'); circ(c,hx+3,hy-1,1.5,'#111'); }
  const hd=o.head||(o.hat?'hat':null), nk=o.neck;
  if(nk==='scarf'){
    rect(c,hx-6,hy+5,12,3,'#c0392b'); rect(c,hx-6,hy+6,12,1,'#e8685a');
    if(dir==='down'||dir==='up') rect(c,hx+2,hy+7,3,7,'#c0392b'); else rect(c,hx-fx*7-2,hy+7,3,6,'#c0392b');
  } else if(nk==='bowtie'){
    const bx=dir==='down'?hx:hx+fx*2;
    c.fillStyle='#8a2be2'; c.beginPath(); c.moveTo(bx,hy+8); c.lineTo(bx-5,hy+4); c.lineTo(bx-5,hy+12); c.closePath(); c.fill();
    c.beginPath(); c.moveTo(bx,hy+8); c.lineTo(bx+5,hy+4); c.lineTo(bx+5,hy+12); c.closePath(); c.fill();
    circ(c,bx,hy+8,1.6,'#5a1a99');
  }
  if(hd==='hat'){
    ell(c,hx,hy-5,9,3,'#7a4f2a');
    rect(c,hx-5,hy-11,10,7,'#8a5a2b');
    rect(c,hx-5,hy-7,10,2,'#3b2a18');
    circ(c,hx,hy-11,1.6,'#5b3a1c');
  } else if(hd==='crown'){
    const cols=['#f06292','#ffd54f','#fff59d','#ba68c8','#81d4fa'];
    ell(c,hx,hy-5.5,8,2.4,'#4caf50');
    for(let i=0;i<5;i++){ const a=-2+i; circ(c,hx+a*3.2,hy-6.5-((i&1)?0:1.5),2.3,cols[i]); circ(c,hx+a*3.2,hy-6.5-((i&1)?0:1.5),0.8,'#fff8c4'); }
  } else if(hd==='cap'){
    ell(c,hx,hy-5,7,4,'#3a62a8'); rect(c,hx-7,hy-5,14,2,'#2d4e88');
    if(dir==='right') rect(c,hx+3,hy-4,7,2,'#2d4e88'); else if(dir==='left') rect(c,hx-10,hy-4,7,2,'#2d4e88');
  } else if(hd==='helm'){
    ell(c,hx,hy-3,8,6,'#aab4c0'); rect(c,hx-8,hy-3,16,2,'#7d8896'); rect(c,hx-1,hy-14,2,8,'#c0392b'); ell(c,hx,hy-14,3,2,'#e85a4a');
  } else if(hd==='wizard'){
    c.fillStyle='#4b2a8a'; c.beginPath(); c.moveTo(hx-9,hy-4); c.lineTo(hx+1,hy-24); c.lineTo(hx+9,hy-4); c.closePath(); c.fill();
    ell(c,hx,hy-4,11,3,'#3a1f6e'); circ(c,hx-1,hy-12,1.5,'#ffd54f'); circ(c,hx+3,hy-8,1.2,'#ffd54f');
  } else if(hd==='royal'){
    rect(c,hx-6,hy-9,12,5,'#e0b84a'); for(let i=0;i<3;i++){ c.fillStyle='#e0b84a'; c.beginPath(); c.moveTo(hx-6+i*5,hy-9); c.lineTo(hx-4+i*5,hy-14); c.lineTo(hx-2+i*5,hy-9); c.fill(); }
    circ(c,hx,hy-7,1.5,'#c0392b');
  } else if(hd==='hood'){
    c.strokeStyle='#1d1a2b'; c.lineWidth=4; c.beginPath(); c.arc(hx,hy,8,2.9,6.5); c.stroke(); rect(c,hx-9,hy-3,3,12,'#1d1a2b'); rect(c,hx+6,hy-3,3,12,'#1d1a2b');
  } else if(hd==='bow'){
    c.fillStyle='#ff5fa2'; c.beginPath(); c.moveTo(hx+4,hy-7); c.lineTo(hx-1,hy-11); c.lineTo(hx-1,hy-3); c.closePath(); c.fill();
    c.beginPath(); c.moveTo(hx+4,hy-7); c.lineTo(hx+9,hy-11); c.lineTo(hx+9,hy-3); c.closePath(); c.fill(); circ(c,hx+4,hy-7,1.6,'#c2185b');
  }
  c.restore();
}

function drawIcon(c,id,s){
  const u=s/16;
  c.save(); c.scale(u,u); c.clearRect(0,0,16,16);
  const R=(x,y,w,h,col)=>{c.fillStyle=col;c.fillRect(x,y,w,h);};
  const C=(x,y,r,col)=>circ(c,x,y,r,col);
  switch(id){
    case 'map': R(2,3,12,10,'#e8d3a0'); R(6,3,1,10,'#c9b27a'); R(10,3,1,10,'#c9b27a'); R(4,6,2,2,'#c0392b'); R(8,9,3,1,'#7a5a2a'); break;
    case 'crust': ell(c,8,9,6,4,'#d9a05b'); R(5,6,1,3,'#a8732f'); R(8,5,1,3,'#a8732f'); R(11,6,1,3,'#a8732f'); break;
    case 'muffin': R(4,9,8,5,'#b98a5a'); ell(c,8,8,6,4,'#8b5a8c'); C(6,7,1,'#2d6cdf'); C(9,6,1,'#2d6cdf'); C(10,8,1,'#2d6cdf'); break;
    case 'tea': R(4,7,7,6,'#f2f2ee'); R(5,8,5,2,'#8a5a2b'); R(11,8,2,3,'#f2f2ee'); R(6,3,1,3,'rgba(255,255,255,0.6)'); R(9,2,1,4,'rgba(255,255,255,0.6)'); break;
    case 'seeds': ell(c,5,6,2,3,'#4a4a4a'); ell(c,10,7,2,3,'#4a4a4a'); ell(c,7,11,2,3,'#4a4a4a'); R(5,5,1,2,'#eee'); R(10,6,1,2,'#eee'); break;
    case 'peas': R(2,7,12,4,'#3f8f3f'); C(5,9,2,'#86e29a'); C(8,9,2,'#86e29a'); C(11,9,2,'#86e29a'); break;
    case 'clover': C(5,6,3,'#3ea04a'); C(11,6,3,'#3ea04a'); C(5,11,3,'#3ea04a'); C(11,11,3,'#3ea04a'); R(8,8,1,6,'#2d7a38'); break;
    case 'worms': R(4,4,8,10,'rgba(160,210,230,0.7)'); R(3,3,10,2,'#7a5a2a'); R(5,8,5,1,'#e58aa0'); R(6,10,5,1,'#e58aa0'); break;
    case 'glass': c.strokeStyle='#c9a24a'; c.lineWidth=2; c.beginPath(); c.arc(7,7,4.5,0,6.2832); c.stroke(); R(7,3,1,1,'#fff'); c.beginPath(); c.moveTo(10.5,10.5); c.lineTo(14,14); c.stroke(); break;
    case 'hat': ell(c,8,11,7,2.5,'#7a4f2a'); R(4,4,8,7,'#8a5a2b'); R(4,8,8,2,'#3b2a18'); C(8,4,1.3,'#5b3a1c'); break;
    case 'notebook': R(3,2,10,12,'#3a62a8'); R(4,4,8,1,'#cfe0ff'); R(4,7,8,1,'#cfe0ff'); R(4,10,6,1,'#cfe0ff'); break;
    case 'lantern': R(5,5,6,8,'#f2b84b'); R(6,6,4,6,'#fff1b0'); R(5,3,6,2,'#4a4a4a'); R(6,1,4,1,'#4a4a4a'); R(5,13,6,1,'#4a4a4a'); break;
    case 'pebble': ell(c,8,10,5,4,'#8a8f98'); R(6,8,2,1,'#c3c8cf'); break;
    case 'feather': c.fillStyle='#8f7ac9'; c.beginPath(); c.moveTo(3,13); c.quadraticCurveTo(4,3,13,2); c.quadraticCurveTo(12,11,3,13); c.fill(); R(4,12,1,1,'#fff'); break;
    case 'key': c.strokeStyle='#e0b84a'; c.lineWidth=2; c.beginPath(); c.arc(5,5,3,0,6.2832); c.stroke(); R(7,7,7,2,'#e0b84a'); R(11,9,2,3,'#e0b84a'); R(13,9,1,2,'#e0b84a'); break;
    case 'compass': C(8,8,6,'#c9a24a'); C(8,8,4.5,'#f4efe0'); c.fillStyle='#c0392b'; c.beginPath(); c.moveTo(8,3.5); c.lineTo(10,8); c.lineTo(6,8); c.fill(); c.fillStyle='#444'; c.beginPath(); c.moveTo(8,12.5); c.lineTo(10,8); c.lineTo(6,8); c.fill(); break;
    case 'cocoa': R(4,6,8,7,'#c0392b'); R(5,7,6,2,'#5a3420'); R(12,7,2,4,'#c0392b'); R(6,2,1,3,'rgba(255,255,255,0.6)'); R(9,1,1,4,'rgba(255,255,255,0.6)'); R(5,9,6,1,'#f6e7d0'); break;
    case 'scone': ell(c,8,10,6,4,'#d9a05b'); R(4,7,8,3,'#e6b673'); R(6,8,1,1,'#fff3d0'); R(9,7,1,1,'#fff3d0'); R(5,12,6,1,'#a8732f'); break;
    case 'soup': ell(c,8,10,6.5,4.5,'#8a5a2b'); ell(c,8,9,5.5,3,'#86c46a'); C(6,9,1,'#e8f2c0'); C(10,9,1,'#e8f2c0'); R(6,3,1,3,'rgba(255,255,255,0.6)'); R(9,2,1,4,'rgba(255,255,255,0.6)'); break;
    case 'daisy': for(let i=0;i<6;i++){ const a=i*1.047; C(8+Math.cos(a)*3.6,7+Math.sin(a)*3.6,2,'#fff'); } C(8,7,2,'#f6d55c'); R(8,10,1,5,'#2f6b34'); break;
    case 'bouquet': R(7,9,2,6,'#2f6b34'); C(5,6,2.5,'#e86a92'); C(10,5,2.5,'#f6d55c'); C(8,4,2.5,'#c792ea'); C(11,8,2,'#8ecae6'); C(5,9,2,'#fff'); R(5,12,6,3,'#e8d3a0'); break;
    case 'bulb': ell(c,8,10,4.5,5,'#c9a24a'); ell(c,8,9,3.5,3.5,'#e8cf8a'); R(7,2,2,4,'#2f6b34'); R(5,3,2,2,'#3ea04a'); break;
    case 'crown': R(2,10,12,2,'#4caf50'); C(3,8,2,'#f06292'); C(6,6,2,'#ffd54f'); C(8,8,2,'#fff59d'); C(10,6,2,'#ba68c8'); C(13,8,2,'#81d4fa'); break;
    case 'novel': R(3,2,10,12,'#7a2a2a'); R(4,2,1,12,'#5a1a1a'); R(6,5,6,1,'#f0d890'); R(6,8,5,1,'#f0d890'); C(9,11,1.5,'#f0d890'); break;
    case 'guide': R(3,2,10,12,'#2f6f4f'); R(4,2,1,12,'#1f4f37'); ell(c,9,7,3,2.2,'#f4efe0'); R(9,6,1,1,'#222'); R(6,11,6,1,'#cfe8d8'); break;
    case 'cookbook': R(3,2,10,12,'#d9a05b'); R(4,2,1,12,'#a8732f'); C(9,7,3,'#f6f1e6'); R(8,6,2,2,'#c0392b'); R(6,12,6,1,'#7a4f1f'); break;
    case 'scarf': R(3,4,10,4,'#c0392b'); R(3,5,10,1,'#e8685a'); R(9,8,3,6,'#c0392b'); R(9,13,3,2,'#e8685a'); break;
    case 'bowtie': c.fillStyle='#8a2be2'; c.beginPath(); c.moveTo(8,8); c.lineTo(2,4); c.lineTo(2,12); c.closePath(); c.fill(); c.beginPath(); c.moveTo(8,8); c.lineTo(14,4); c.lineTo(14,12); c.closePath(); c.fill(); C(8,8,2,'#5a1a99'); break;
    case 'socks': R(4,2,4,8,'#8ecae6'); R(4,9,8,4,'#8ecae6'); R(4,3,4,1,'#fff'); R(4,5,4,1,'#fff'); R(9,4,4,8,'#f6d55c'); R(9,5,4,1,'#fff'); R(9,7,4,1,'#fff'); break;
    case 'ducky': ell(c,8,11,6,3.5,'#ffd84a'); C(11,6,3.5,'#ffd84a'); R(13,6,3,2,'#ff8a1f'); C(12,5,0.8,'#111'); ell(c,7,11,3,1.8,'#f0b921'); break;
    case 'kite': c.fillStyle='#e0587a'; c.beginPath(); c.moveTo(8,1); c.lineTo(13,7); c.lineTo(8,12); c.lineTo(3,7); c.closePath(); c.fill(); R(8,1,1,11,'#f6d55c'); R(3,7,10,1,'#f6d55c'); R(8,12,1,3,'#7a5a2a'); break;
    case 'marbles': C(5,10,3,'#3a7ca5'); C(11,9,3,'#e07a3a'); C(8,5,3,'#4caf50'); R(4,9,1,1,'#fff'); R(10,8,1,1,'#fff'); R(7,4,1,1,'#fff'); break;
    case 'top': c.fillStyle='#d9482b'; c.beginPath(); c.moveTo(3,6); c.lineTo(13,6); c.lineTo(8,14); c.closePath(); c.fill(); R(7,2,2,4,'#f6d55c'); R(3,6,10,2,'#f2a02a'); break;
    case 'parcel': R(3,5,10,8,'#c9a06a'); R(3,5,10,2,'#dcb888'); R(7,5,2,8,'#c0392b'); R(3,8,10,2,'#c0392b'); C(8,4,2,'#c0392b'); break;
    case 'trinket': C(8,8,5,'#e0b84a'); C(8,8,3.5,'#f6dc82'); R(7,5,2,1,'#fff'); R(6,7,1,1,'#fff'); C(8,8,1.2,'#a8732f'); break;
    case 'medal': R(5,1,2,6,'#3a62a8'); R(9,1,2,6,'#c0392b'); C(8,10,5,'#e0b84a'); C(8,10,3.5,'#f6dc82'); R(7,8,2,4,'#e0b84a'); R(6,9,4,2,'#e0b84a'); break;
    case 'cake': R(3,8,10,6,'#f4d4a8'); R(3,6,10,3,'#f2a7c3'); R(3,6,10,1,'#fff'); R(7,2,2,4,'#fff3c4'); R(7,1,2,1,'#ff9d2e'); C(5,5,1.3,'#c0392b'); C(11,5,1.3,'#c0392b'); break;
    case 'honey': R(4,5,8,9,'#e0a020'); R(4,5,8,2,'#f6c84a'); R(3,3,10,2,'#8a5a2b'); R(6,9,4,3,'#f6d36a'); break;
    case 'specs': C(5,9,3.2,'#2a2f3a'); C(11,9,3.2,'#2a2f3a'); C(5,9,2,'#9ad3f0'); C(11,9,2,'#9ad3f0'); R(5,5,2,3,'#2a2f3a'); R(9,5,2,3,'#2a2f3a'); R(7,8,2,2,'#2a2f3a'); break;
    default: R(3,3,10,10,'#888');
  }
  c.restore();
}

/* ---- ground tiles ---- */
const FLOWER_COLS=['#e86a92','#f6d55c','#8ecae6','#ffffff','#c792ea'];
function drawGrass(c,x,y,px,py,dk,st){
  const h=hash(x,y,1), pal=st?st.grass:null;
  rect(c,px,py,TS,TS,pal?(h<0.34?pal[0]:h<0.67?pal[1]:pal[2]):(h<0.34?'#4c8b43':h<0.67?'#52944a':'#488740'));
  c.fillStyle=st?st.blade:'#3c7835';
  for(let i=0;i<3;i++) if(hash(x,y,20+i)<0.6) c.fillRect(px+((hash(x,y,30+i)*28)|0),py+((hash(x,y,40+i)*26)|0),2,4);
  if(hash(x,y,2)<0.5) rect(c,px+((hash(x,y,3)*28)|0),py+((hash(x,y,4)*28)|0),3,2,st?st.tuft:'#66aa5c');
  if(st&&st.snow&&hash(x,y,5)<0.2){ const sx=px+((hash(x,y,6)*24)|0), sy=py+((hash(x,y,7)*24)|0); rect(c,sx,sy,2,2,'#fff'); rect(c,sx+1,sy+3,1,1,'#fff'); }
  if(dk>0.03){ c.fillStyle='rgba(58,18,102,'+(dk*0.6).toFixed(2)+')'; c.fillRect(px,py,TS,TS); }
}
function drawCobble(c,x,y,px,py){
  rect(c,px,py,TS,TS,'#8f9aa8');
  c.fillStyle='#78839a'; c.fillRect(px,py+15,TS,2); c.fillRect(px,py,TS,1);
  const o=((x+y)&1)?8:20;
  c.fillRect(px+o,py,2,16); c.fillRect(px+((o+16)%32),py+16,2,16);
  rect(c,px+4,py+3,6,2,'#a6b0bd');
}
/* town ground: the plaza material depends on the town's style */
function drawPlaza(c,x,y,px,py,st){
  const m=st?st.plaza:'cobble';
  if(m==='cobble'){ drawCobble(c,x,y,px,py); return; }
  if(m==='dirt'){
    rect(c,px,py,TS,TS,(x+y)&1?'#c9a875':'#c4a26e');
    c.fillStyle='#b08a55';
    for(let i=0;i<5;i++) c.fillRect(px+((hash(x,y,80+i)*28)|0),py+((hash(x,y,90+i)*28)|0),3,2);
    c.fillStyle='#dcc08e'; for(let i=0;i<2;i++) c.fillRect(px+((hash(x,y,100+i)*26)|0),py+((hash(x,y,110+i)*26)|0),4,2);
  } else if(m==='sand'){
    rect(c,px,py,TS,TS,(x*7+y*3)%5<2?'#e8d3a0':'#e2cc96');
    c.fillStyle='#cdb77c'; const o=(hash(x,y,81)*10)|0;
    c.fillRect(px+3+o,py+8,12,1); c.fillRect(px+14-o,py+21,10,1);
    c.fillStyle='#f5e6bb'; c.fillRect(px+((hash(x,y,82)*26)|0),py+((hash(x,y,83)*26)|0),2,1);
  } else if(m==='frost'){
    rect(c,px,py,TS,TS,'#b9c9da');
    c.fillStyle='#9fb2c8'; c.fillRect(px,py+15,TS,2); c.fillRect(px,py,TS,1);
    const o=((x+y)&1)?8:20; c.fillRect(px+o,py,2,16); c.fillRect(px+((o+16)%32),py+16,2,16);
    rect(c,px+4,py+3,6,2,'#dce8f4');
    if(hash(x,y,84)<0.4){ rect(c,px+((hash(x,y,85)*20)|0),py+((hash(x,y,86)*20)|0),9,4,'rgba(255,255,255,0.8)'); }
  } else if(m==='moss'){
    rect(c,px,py,TS,TS,'#5d7f6a');
    c.fillStyle='#456653'; c.fillRect(px,py+15,TS,2); c.fillRect(px,py,TS,1);
    const o=((x+y)&1)?8:20; c.fillRect(px+o,py,2,16); c.fillRect(px+((o+16)%32),py+16,2,16);
    c.fillStyle='#7fb08a'; for(let i=0;i<3;i++) c.fillRect(px+((hash(x,y,87+i)*26)|0),py+((hash(x,y,90+i)*26)|0),4,2);
  } else if(m==='brick'){
    rect(c,px,py,TS,TS,'#b8654a');
    c.fillStyle='#8f4a35';
    for(let r=0;r<4;r++){ c.fillRect(px,py+r*8,TS,1); const off=(r&1)?0:8; c.fillRect(px+off,py+r*8,1,8); c.fillRect(px+off+16,py+r*8,1,8); }
    rect(c,px+2,py+2,5,2,'#cc7a5c');
  }
}
/* ground under a prop: plaza if we are on the plaza, otherwise grass */
function drawGround(c,x,y,px,py,st,dk){
  if(inPlazaTile(x,y)) drawPlaza(c,x,y,px,py,st); else drawGrass(c,x,y,px,py,dk||0,st);
}
function drawPath(c,x,y,px,py){
  rect(c,px,py,TS,TS,'#c5a26a');
  c.fillStyle='#b38d55';
  for(let i=0;i<4;i++) c.fillRect(px+((hash(x,y,80+i)*28)|0),py+((hash(x,y,90+i)*28)|0),3,2);
  rect(c,px,py,TS,2,'rgba(70,110,50,0.35)'); rect(c,px,py+TS-2,TS,2,'rgba(70,110,50,0.35)');
}
function drawWater(c,x,y,px,py,time){
  rect(c,px,py,TS,TS,'#3b82c4');
  c.fillStyle='rgba(255,255,255,0.22)';
  for(let i=0;i<2;i++){ const ox=Math.sin(time*1.4+x*1.3+y*0.9+i*2)*5; c.fillRect(px+8+ox+i*6,py+9+i*13,10,2); }
  c.fillStyle='#d8c58a';
  if(tileAt(x,y-1)!==T.WATER) c.fillRect(px,py,TS,3);
  if(tileAt(x,y+1)!==T.WATER) c.fillRect(px,py+TS-3,TS,3);
  if(tileAt(x-1,y)!==T.WATER) c.fillRect(px,py,3,TS);
  if(tileAt(x+1,y)!==T.WATER) c.fillRect(px+TS-3,py,3,TS);
}
function drawBuildingTile(c,x,y,t,px,py){
  const b=buildingAt(x,y);
  if(!b){ rect(c,px,py,TS,TS,'#888'); return; }
  const row=y-b.y, col=x-b.x;
  if(t===T.ROOF){
    rect(c,px,py,TS,TS,b.roof);
    c.fillStyle='rgba(0,0,0,0.18)';
    for(let i=0;i<4;i++) c.fillRect(px,py+i*8+6,TS,2);
    c.fillStyle='rgba(255,255,255,0.12)';
    for(let i=0;i<4;i++){ const o=(i&1)?0:16; c.fillRect(px+o,py+i*8,2,6); c.fillRect(px+o+16,py+i*8,2,6); }
    if(row===0) rect(c,px,py,TS,3,'rgba(255,255,255,0.28)');
    if(col===0) rect(c,px,py,2,TS,'rgba(0,0,0,0.28)');
    if(col===b.w-1) rect(c,px+TS-2,py,2,TS,'rgba(0,0,0,0.28)');
    if(b.snow){
      rect(c,px,py,TS,row===0?12:5,'#f4f9fc');
      c.fillStyle='#f4f9fc';
      for(let i=0;i<4;i++){ const hh=3+((hash(x+i,y,88)*6)|0); c.fillRect(px+i*8,py+(row===0?12:5),8,hh); }
      rect(c,px,py+(row===0?9:2),TS,2,'#d6e4ef');
    }
    return;
  }
  rect(c,px,py,TS,TS,b.wall);
  c.fillStyle='rgba(0,0,0,0.08)'; c.fillRect(px,py+10,TS,1); c.fillRect(px,py+21,TS,1);
  if(row===2) rect(c,px,py,TS,4,'rgba(0,0,0,0.2)');
  if(col===0) rect(c,px,py,2,TS,'rgba(0,0,0,0.15)');
  if(col===b.w-1) rect(c,px+TS-2,py,2,TS,'rgba(0,0,0,0.15)');
  const lit=buildingLit(b);
  if(t===T.WINDOW){
    rect(c,px+6,py+7,20,16,'#5a3d2b'); rect(c,px+8,py+9,16,12,lit?(b.enterable?'#ffe9a3':'#ffd98a'):(b.enterable?'#6d7f99':'#8ecae6'));
    c.fillStyle='#5a3d2b'; c.fillRect(px+15,py+9,2,12); c.fillRect(px+8,py+14,16,2);
    if(lit&&NIGHT>0.12) lights.push({x:px+16,y:py+18,r:62,s:0.75,w:0.8});
  }
  if(t===T.DOOR||t===T.HOUSEDOOR){
    const open=t===T.DOOR&&shopOpen(b);
    rect(c,px+5,py+2,22,30,'#3a2412'); rect(c,px+7,py+4,18,28,t===T.DOOR?(open?'#7b4a22':'#5a3a1c'):'#5c3d7a');
    rect(c,px+7,py+4,18,3,'rgba(255,255,255,0.15)'); circ(c,px+21,py+19,2,'#ffd166');
    if(open&&NIGHT>0.12) lights.push({x:px+16,y:py+28,r:58,s:0.7,w:0.8});
  }
}
function drawFountain(c,cx,cy,time,st){
  const px=(cx-1)*TS, py=(cy-2)*TS;
  for(let j=0;j<3;j++) for(let i=0;i<3;i++) drawPlaza(c,cx-1+i,cy-2+j,px+i*TS,py+j*TS,st);
  const mx=px+48, my=py+48;
  ell(c,mx,my+3,47,41,'rgba(0,0,0,0.2)');
  ell(c,mx,my,46,40,'#c3ccd6'); ell(c,mx,my,40,34,'#9aa5b2'); ell(c,mx,my,36,30,'#58aee6');
  c.strokeStyle='rgba(255,255,255,0.5)'; c.lineWidth=1;
  for(let i=0;i<2;i++){ c.beginPath(); c.ellipse(mx,my,14+((time*10+i*14)%28),11+((time*8+i*11)%22),0,0,6.2832); c.stroke(); }
  circ(c,mx,my,8,'#d7dee6'); circ(c,mx,my,4,'#b3bdc8');
  for(let i=0;i<5;i++){ const tt=(time*0.9+i*0.2)%1; const a=i*1.2566+time*0.5; circ(c,mx+Math.cos(a)*tt*14,my-6-Math.sin(tt*3.14159)*18,1.6,'rgba(220,240,255,'+(1-tt).toFixed(2)+')'); }
}
function drawBush(c,px,py){ ell(c,px+16,py+24,12,5,'rgba(0,0,0,0.18)'); ell(c,px+16,py+19,12,8,'#336b34'); ell(c,px+12,py+17,7,5,'#47914a'); ell(c,px+21,py+19,6,4,'#3f8441'); }
function drawRock(c,x,y,px,py){ ell(c,px+16,py+25,12,5,'rgba(0,0,0,0.2)'); ell(c,px+16,py+19,11,8,'#7d838c'); ell(c,px+14,py+16,7,4,'#a0a6ae'); }
function drawStump(c,px,py){ ell(c,px+16,py+26,11,4,'rgba(0,0,0,0.2)'); rect(c,px+8,py+14,16,12,'#6b4a2f'); ell(c,px+16,py+14,8,4,'#a97c50'); ell(c,px+16,py+14,4,2,'#8a6238'); }
function drawFlower(c,x,y,px,py){
  const n=1+((hash(x,y,50)*3)|0);
  for(let i=0;i<n;i++){
    const fx=px+6+((hash(x,y,51+i)*20)|0), fy=py+10+((hash(x,y,55+i)*16)|0);
    rect(c,fx,fy,2,6,'#2f6b34'); circ(c,fx+1,fy,3,FLOWER_COLS[(hash(x,y,60+i)*5)|0]); circ(c,fx+1,fy,1,'#fff3b0');
  }
}
function drawMush(c,x,y,px,py,dk,time){
  const sty=styleAt(x,y), glow=dk>0.3||(sty&&sty.id==='grove');
  const mx=px+10+((hash(x,y,70)*10)|0), my=py+16+((hash(x,y,71)*8)|0);
  if(glow){ circ(c,mx,my-2,9,'rgba(168,85,247,'+(0.18+0.1*Math.sin(time*2+x)).toFixed(2)+')'); }
  rect(c,mx-1,my,3,5,'#e9e2d0'); ell(c,mx,my,5,3.5,glow?'#b36bff':'#d65a5a');
  if(!glow){ rect(c,mx-2,my-2,1,1,'#fff'); rect(c,mx+1,my-1,1,1,'#fff'); } else { rect(c,mx-2,my-1,1,1,'#7ff0ff'); rect(c,mx+1,my-2,1,1,'#7ff0ff'); }
}
function drawCrumbs(c,x,y,px,py,time){
  ell(c,px+16,py+23,9,4,'rgba(0,0,0,0.2)');
  circ(c,px+12,py+20,3.5,'#e8c27a'); circ(c,px+19,py+21,3,'#d6a85a'); circ(c,px+16,py+17,3,'#f1d391');
  const s=(Math.sin(time*4+x*3)+1)/2;
  c.fillStyle='rgba(255,247,194,'+(0.4+0.6*s).toFixed(2)+')';
  c.fillRect(px+22,py+10-s*2,2,2); c.fillRect(px+8,py+12,2,2);
}
function drawSign(c,px,py){
  ell(c,px+16,py+30,9,3,'rgba(0,0,0,0.2)');
  rect(c,px+14,py+12,4,19,'#6b4a2f');
  rect(c,px+3,py+3,26,14,'#a8793f'); rect(c,px+3,py+3,26,2,'#c79a5a'); rect(c,px+3,py+15,26,2,'#7a5429');
  rect(c,px+7,py+9,13,2,'#4a3018');
  c.fillStyle='#4a3018'; c.beginPath(); c.moveTo(px+21,py+6); c.lineTo(px+27,py+10); c.lineTo(px+21,py+14); c.fill();
}
function drawLamp(c,px,py,time){
  circ(c,px+16,py-8,20,'rgba(255,209,102,'+(0.14+0.03*Math.sin(time*3)).toFixed(2)+')');
  rect(c,px+11,py+28,10,4,'#2a2f3a'); rect(c,px+15,py-2,3,32,'#2a2f3a');
  rect(c,px+9,py-14,14,13,'#2a2f3a'); rect(c,px+11,py-12,10,9,'#ffd166'); rect(c,px+12,py-11,3,3,'#fff3c4');
}
function drawPine(c,px,py,sway,cols,s){
  ell(c,px+16,py+30,12,4,'rgba(0,0,0,0.22)');
  rect(c,px+14,py+20,5,12,'#5a3d22');
  const tiers=[[26,3,16],[17,-3,13],[9,-8,10]];
  for(const tr of tiers){
    const by=py+tr[0]+2, ty=py+tr[1]-12, hw=tr[2]*s;
    c.fillStyle=cols[0]; c.beginPath(); c.moveTo(px+16+sway*0.4,ty); c.lineTo(px+16+hw,by); c.lineTo(px+16-hw,by); c.closePath(); c.fill();
    c.fillStyle=cols[1]; c.beginPath(); c.moveTo(px+16+sway*0.4,ty); c.lineTo(px+16+hw*0.45,by); c.lineTo(px+16-hw*0.25,by); c.closePath(); c.fill();
    c.fillStyle=cols[2]; c.beginPath(); c.moveTo(px+16+sway*0.4,ty); c.lineTo(px+16+hw*0.55,ty+(by-ty)*0.45); c.lineTo(px+16-hw*0.55,ty+(by-ty)*0.45); c.closePath(); c.fill();
  }
}
function drawTree(c,x,y,px,py,time,dark,glint){
  const h=hash(x,y,3), s=0.9+h*0.3, sway=Math.sin(time*1.2+x*1.7+y)*1.2;
  const sty=dark?null:styleAt(x,y);
  if(sty&&sty.tree&&sty.tree.pine){ drawPine(c,px,py,sway,sty.tree.cols,s); return; }
  ell(c,px+16,py+30,14,5,'rgba(0,0,0,0.24)');
  if(!dark){
    rect(c,px+12,py+14,8,18,'#6b4a2f'); rect(c,px+17,py+14,3,18,'#53381f');
    let g1=h<0.3?'#3d7a36':'#2f6b34', g2=h<0.3?'#4d8c3d':'#3a7d3d', g3=h<0.3?'#6aa84a':'#47914a';
    if(sty&&sty.tree){ const k=sty.tree.cols; g1=k[0]; g2=k[1]; g3=k[2]; }
    circ(c,px+16+sway,py-2,17*s,g1); circ(c,px+7+sway,py+7,12*s,g1); circ(c,px+25+sway,py+7,12*s,g1);
    circ(c,px+16+sway,py+4,13*s,g2); circ(c,px+12+sway,py-5,8*s,g3);
  } else {
    circ(c,px+16,py+26,22,'rgba(120,40,200,0.16)');
    rect(c,px+12,py+14,8,18,'#2a1f33'); rect(c,px+17,py+14,3,18,'#1c1424');
    c.fillStyle='#a855f7'; c.fillRect(px+14,py+17,1,6); c.fillRect(px+15,py+22,3,1); c.fillRect(px+17,py+22,1,7);
    const pulse=0.55+0.45*Math.sin(time*2.2+x+y);
    circ(c,px+16+sway,py-2,17*s,'#1a1226'); circ(c,px+7+sway,py+7,12*s,'#1a1226'); circ(c,px+25+sway,py+7,12*s,'#1a1226');
    circ(c,px+16+sway,py+4,13*s,'#271a3a'); circ(c,px+12+sway,py-5,8*s,'#33224d');
    c.fillStyle='rgba(192,132,252,'+pulse.toFixed(2)+')';
    c.fillRect(px+10+sway,py-3,2,2); c.fillRect(px+21+sway,py+1,2,2); c.fillRect(px+15+sway,py+7,2,2); c.fillRect(px+6+sway,py+6,2,2);
    for(let i=0;i<3;i++){
      const tt=(time*0.45+hash(x,y,40+i))%1;
      c.fillStyle='rgba(216,180,254,'+(1-tt).toFixed(2)+')';
      c.fillRect(px+6+hash(x,y,44+i)*20+Math.sin(tt*6+i)*3,py+14-tt*40,2,2);
    }
    if(glint){ const g=(Math.sin(time*5+x)+1)/2; c.fillStyle='rgba(255,255,255,'+(0.4+0.6*g).toFixed(2)+')'; c.fillRect(px+22,py+8,3,3); c.fillRect(px+23,py+6,1,7); c.fillRect(px+20,py+9,7,1); }
  }
}
/* ---- town props ---- */
function drawBench(c,px,py){
  ell(c,px+16,py+28,14,4,'rgba(0,0,0,0.2)');
  rect(c,px+4,py+12,24,3,'#8a5a2b'); rect(c,px+4,py+16,24,3,'#8a5a2b');
  rect(c,px+3,py+20,26,5,'#a97c50'); rect(c,px+3,py+25,26,2,'#6b4a2f');
  rect(c,px+4,py+11,3,16,'#4a3018'); rect(c,px+25,py+11,3,16,'#4a3018');
  rect(c,px+5,py+27,3,3,'#4a3018'); rect(c,px+24,py+27,3,3,'#4a3018');
}
function drawCrate(c,x,y,px,py){
  ell(c,px+16,py+29,12,4,'rgba(0,0,0,0.22)');
  if(hash(x,y,61)<0.5){
    rect(c,px+5,py+10,22,19,'#a8793f'); rect(c,px+5,py+10,22,3,'#c79a5a');
    c.strokeStyle='#6b4a22'; c.lineWidth=2; c.strokeRect(px+6,py+11,20,17);
    c.beginPath(); c.moveTo(px+6,py+11); c.lineTo(px+26,py+28); c.moveTo(px+26,py+11); c.lineTo(px+6,py+28); c.stroke();
    if(hash(x,y,63)<0.5) circ(c,px+12,py+8,4,'#e86a4a');
  } else {
    ell(c,px+16,py+14,10,4,'#c79a5a'); rect(c,px+6,py+14,20,14,'#8a5a2b'); ell(c,px+16,py+28,10,3,'#6b4a22');
    rect(c,px+6,py+18,20,2,'#3b2a18'); rect(c,px+6,py+24,20,2,'#3b2a18'); ell(c,px+16,py+14,8,3,'#6b4a22');
  }
}
function drawHay(c,x,y,px,py){
  ell(c,px+16,py+28,13,4,'rgba(0,0,0,0.22)');
  ell(c,px+16,py+19,13,10,'#d9b84a'); ell(c,px+16,py+19,9,6,'#e8cb64');
  c.strokeStyle='#b8962c'; c.lineWidth=1; c.beginPath(); c.ellipse(px+16,py+19,6,3.5,0,0,6.2832); c.stroke();
  rect(c,px+3,py+19,26,2,'#b8962c');
}
function drawStall(c,x,y,px,py){
  const col=['#d9482b','#2a9d8f','#f2a02a','#3a7bd5','#c8366b'][(hash(x,y,62)*5)|0];
  ell(c,px+16,py+30,15,4,'rgba(0,0,0,0.22)');
  rect(c,px+3,py+8,3,22,'#6b4a2f'); rect(c,px+26,py+8,3,22,'#6b4a2f');
  rect(c,px+3,py+20,26,10,'#8a6238'); rect(c,px+3,py+20,26,3,'#b98a55');
  const gc=['#e86a4a','#86e29a','#f6d55c','#c792ea'];
  for(let i=0;i<4;i++) circ(c,px+8+i*6,py+18,3,gc[(i+((hash(x,y,64)*4)|0))%4]);
  for(let i=0;i<6;i++) rect(c,px+1+i*5,py-3,5,12,i&1?'#fff6e0':col);
  for(let i=0;i<6;i++) ell(c,px+3.5+i*5,py+9,2.5,2.2,i&1?'#fff6e0':col);
}
function drawBoard(c,px,py,time,fresh){
  ell(c,px+16,py+30,12,3,'rgba(0,0,0,0.22)');
  rect(c,px+6,py+14,3,17,'#6b4a2f'); rect(c,px+23,py+14,3,17,'#6b4a2f');
  rect(c,px+2,py+1,28,19,'#5a3d22'); rect(c,px+4,py+3,24,15,'#c79a5a');
  rect(c,px+6,py+5,8,7,'#fff6dc'); rect(c,px+16,py+6,9,6,'#f6e19a'); rect(c,px+9,py+12,9,5,'#fff6dc'); rect(c,px+19,py+13,6,4,'#ffd3d3');
  c.fillStyle='#4a3018'; for(const r of [[7,7],[7,9],[17,8],[17,10],[10,14],[20,14]]) c.fillRect(px+r[0],py+r[1],5,1);
  circ(c,px+10,py+5,1.3,'#c0392b'); circ(c,px+20,py+6,1.3,'#3a62a8');
  if(fresh) drawMark(c,px+16,py+2,time,'!','#ffd166');
}
function drawWell(c,px,py){
  ell(c,px+16,py+29,15,5,'rgba(0,0,0,0.22)');
  ell(c,px+16,py+23,13,8,'#7d838c'); ell(c,px+16,py+21,12,7,'#a0a6ae'); ell(c,px+16,py+21,8,4.5,'#1e3a52');
  rect(c,px+4,py+4,3,19,'#6b4a2f'); rect(c,px+25,py+4,3,19,'#6b4a2f');
  c.fillStyle='#a8532f'; c.beginPath(); c.moveTo(px,py+8); c.lineTo(px+16,py-6); c.lineTo(px+32,py+8); c.closePath(); c.fill();
  c.fillStyle='rgba(255,255,255,0.18)'; c.beginPath(); c.moveTo(px+16,py-6); c.lineTo(px+32,py+8); c.lineTo(px+16,py+8); c.closePath(); c.fill();
  rect(c,px+15,py+8,2,8,'#e8d9b5'); rect(c,px+12,py+15,8,4,'#8a5a2b');
}
function drawStatue(c,px,py){
  ell(c,px+16,py+30,15,5,'rgba(0,0,0,0.22)');
  rect(c,px+5,py+21,22,10,'#98a3b0'); rect(c,px+5,py+21,22,3,'#c3ccd6'); rect(c,px+8,py+17,16,5,'#8a95a3');
  ell(c,px+14,py+10,9,7,'#e0b84a'); ell(c,px+13,py+10,5,3.5,'#c99a2a');
  circ(c,px+21,py+1,5,'#e0b84a'); rect(c,px+24,py+1,6,3,'#d9962a'); circ(c,px+22,py,1,'#3a2a08');
  rect(c,px+9,py+3,3,3,'#f6dc82'); c.fillStyle='#e0b84a'; c.beginPath(); c.moveTo(px+4,py+7); c.lineTo(px-3,py+1); c.lineTo(px+6,py+13); c.fill();
}
function drawFire(c,px,py,time){
  ell(c,px+16,py+28,14,5,'rgba(0,0,0,0.25)');
  for(let i=0;i<8;i++){ const a=i*0.785; ell(c,px+16+Math.cos(a)*10,py+26+Math.sin(a)*4,4,3,'#6b6f78'); }
  rect(c,px+8,py+23,16,3,'#4a3018'); rect(c,px+10,py+20,12,3,'#5a3d22');
  const f=Math.sin(time*9)*2, f2=Math.sin(time*13+1)*1.5;
  c.fillStyle='#ff7a2a'; c.beginPath(); c.moveTo(px+7,py+23); c.quadraticCurveTo(px+9+f2,py+8,px+16,py+1+f); c.quadraticCurveTo(px+22,py+10,px+25,py+23); c.closePath(); c.fill();
  c.fillStyle='#ffd166'; c.beginPath(); c.moveTo(px+11,py+23); c.quadraticCurveTo(px+13,py+12,px+16,py+8+f2); c.quadraticCurveTo(px+20,py+14,px+21,py+23); c.closePath(); c.fill();
  c.fillStyle='#fff3c4'; c.beginPath(); c.moveTo(px+14,py+23); c.quadraticCurveTo(px+15,py+17,px+16,py+14); c.quadraticCurveTo(px+18,py+18,px+18,py+23); c.closePath(); c.fill();
  for(let i=0;i<3;i++){ const tt=(time*0.7+i*0.33)%1; c.fillStyle='rgba(255,200,100,'+(1-tt).toFixed(2)+')'; c.fillRect(px+10+i*5+Math.sin(tt*7+i)*3,py+10-tt*26,2,2); }
}
function drawMark(c,x,y,time,ch,col){
  const by=y-6+Math.sin(time*4)*2;
  circ(c,x,by,7,'#2a1700'); circ(c,x,by,5.5,col);
  c.fillStyle='#2a1700'; c.font='800 11px ui-monospace,"Courier New",monospace'; c.textAlign='center'; c.textBaseline='middle'; c.fillText(ch,x,by+1);
}
function drawBubble(c,x,y,time,txt){
  const by=y-4+Math.sin(time*5)*1.5;
  rect(c,x-8,by-14,16,14,'#fff6dc'); rect(c,x-8,by-14,16,14,'rgba(0,0,0,0)');
  c.strokeStyle='#2a1700'; c.lineWidth=1.5; c.strokeRect(x-8,by-14,16,14);
  c.fillStyle='#fff6dc'; c.beginPath(); c.moveTo(x-3,by); c.lineTo(x,by+4); c.lineTo(x+3,by); c.fill();
  c.fillStyle='#2a1700'; c.font='600 12px ui-monospace,"Courier New",monospace'; c.textAlign='center'; c.textBaseline='middle'; c.fillText(txt||'Z',x,by-6.5);
}

/* ---- the open world ---- */
let NIGHT=0, lights=[], view={ox:0,oy:0};
function drawWorld(c,W,H,kd,camX,camY,time){
  const vw=W/kd, vh=H/kd;
  const ox=Math.round((camX-vw/2)*kd)/kd, oy=Math.round((camY-vh/2)*kd)/kd;
  view.ox=ox; view.oy=oy; lights.length=0;
  c.setTransform(kd,0,0,kd,-ox*kd,-oy*kd);
  const x0=Math.floor(ox/TS)-1, x1=Math.floor((ox+vw)/TS)+1, y0=Math.floor(oy/TS)-1, y1=Math.floor((oy+vh)/TS)+1;
  const objs=[], night=NIGHT>0.12;
  for(let y=y0;y<=y1;y++){
    for(let x=x0;x<=x1;x++){
      const t=tileAt(x,y), px=x*TS, py=y*TS, st=styleAt(x,y);
      switch(t){
        case T.WATER: drawWater(c,x,y,px,py,time); break;
        case T.PATH: drawPath(c,x,y,px,py); break;
        case T.COBBLE: drawPlaza(c,x,y,px,py,st); break;
        case T.LAMP: drawGround(c,x,y,px,py,st,0); objs.push({y:py+TS,k:'lamp',x:px,py:py}); if(night) lights.push({x:px+16,y:py-8,r:135,s:0.95,w:1}); break;
        case T.FOUNTAIN: { const tw=townAtTile(x,y); if(tw&&x===tw.cx&&y===tw.cy-1) drawFountain(c,tw.cx,tw.cy-1+1,time,st); break; }
        case T.ROOF: case T.WALL: case T.WINDOW: case T.DOOR: case T.HOUSEDOOR: drawBuildingTile(c,x,y,t,px,py); break;
        default: {
          if(t>=28){ drawKTile(c,x,y,t,px,py,time,objs,night); break; }
          const dk=darkAt(x,y);
          if(PROPS.has(t)){
            drawGround(c,x,y,px,py,st,0);
            if(t===T.BENCH) drawBench(c,px,py);
            else if(t===T.CRATE) drawCrate(c,x,y,px,py);
            else if(t===T.HAY) drawHay(c,x,y,px,py);
            else{
              objs.push({y:py+TS,k:'prop',t:t,x:x,yy:y,px:px,py:py});
              if(t===T.FIRE&&night) lights.push({x:px+16,y:py+8,r:190,s:1,w:1.3});
            }
            break;
          }
          drawGrass(c,x,y,px,py,dk,st);
          if(t===T.TREE||t===T.DARK) objs.push({y:py+TS,k:t===T.DARK?'dark':'tree',x:x,yy:y,px:px,py:py});
          else if(t===T.ROCK) drawRock(c,x,y,px,py);
          else if(t===T.STUMP) drawStump(c,px,py);
          else if(t===T.BUSH) drawBush(c,px,py);
          else if(t===T.FLOWER) drawFlower(c,x,y,px,py);
          else if(t===T.MUSH){ drawMush(c,x,y,px,py,dk,time); if(night&&st&&st.id==='grove') lights.push({x:px+16,y:py+20,r:50,s:0.35,w:0}); }
          else if(t===T.CRUMBS) drawCrumbs(c,x,y,px,py,time);
          else if(t===T.SIGN) drawSign(c,px,py);
        }
      }
    }
  }
  /* lost things being looked for */
  for(const q of g.quests){
    if(q.type!=='lost'||q.found) continue;
    if(q.lost.x<x0||q.lost.x>x1||q.lost.y<y0||q.lost.y>y1) continue;
    const lx=q.lost.x*TS+16, ly=q.lost.y*TS+20, s=(Math.sin(time*5)+1)/2;
    ell(c,lx,ly+4,7,3,'rgba(0,0,0,0.25)'); circ(c,lx,ly,5,'#e0b84a'); circ(c,lx,ly,3.2,'#f6dc82');
    c.fillStyle='rgba(255,255,255,'+(0.5+0.5*s).toFixed(2)+')'; c.fillRect(lx-1,ly-12-s*2,2,6); c.fillRect(lx-4,ly-9-s*2,8,2);
    if(night) lights.push({x:lx,y:ly,r:36,s:0.5,w:0.5});
  }
  /* shop plaques and open/closed tags */
  const rx0=Math.floor((x0+24)/REG), rx1=Math.floor((x1+24)/REG), ry0=Math.floor((y0+24)/REG), ry1=Math.floor((y1+24)/REG);
  for(let ry=ry0;ry<=ry1;ry++) for(let rx=rx0;rx<=rx1;rx++){
    const tw=getTown(rx,ry); if(!tw) continue;
    for(const b of tw.buildings){
      if(b.x+b.w<x0||b.x>x1||b.y+b.h<y0||b.y>y1) continue;
      let fs=12; c.textAlign='center'; c.textBaseline='middle';
      do{ c.font='600 '+fs+'px ui-monospace,"Courier New",monospace'; fs--; }while(fs>7&&c.measureText(b.name).width>TS*5.4);
      const w=c.measureText(b.name).width+10, cx2=(b.x+b.w/2)*TS, cy2=(b.y+1.15)*TS;
      rect(c,cx2-w/2,cy2-8,w,16,'rgba(27,20,13,0.88)');
      c.strokeStyle=shopOpen(b)?'#ffe3b0':'#a08a74'; c.lineWidth=1; c.strokeRect(cx2-w/2+0.5,cy2-7.5,w-1,15);
      c.fillStyle=shopOpen(b)?'#ffe3b0':'#a08a74'; c.fillText(b.name,cx2,cy2+1);
      const open=shopOpen(b), tgx=(b.doorX+0.5)*TS, tgy=b.doorY*TS-3;
      c.font='700 8px ui-monospace,"Courier New",monospace';
      rect(c,tgx-17,tgy-5,34,10,open?'#2f7d3a':'#8c2f2f'); c.fillStyle='#fff'; c.fillText(open?'OPEN':'CLOSED',tgx,tgy+0.5);
    }
  }
  /* sorted objects: trees, lamps, props, townducks, player */
  const hourNow=g.clock;
  for(const n of g.npcs) objs.push({y:n.y,k:'npc',n:n});
  objs.push({y:g.py,k:'me'});
  if(typeof hostCollect==='function') hostCollect(c,objs,x0,y0,x1,y1,time);
  objs.sort((a,b)=>a.y-b.y);
  const px0=Math.floor(g.px/TS), py0=Math.floor(g.py/TS);
  for(const o of objs){
    if(o.k==='tree') drawTree(c,o.x,o.yy,o.px,o.py,time,false,false);
    else if(o.k==='dark') drawTree(c,o.x,o.yy,o.px,o.py,time,true,isHeld('glass')&&!g.inspected.has(o.x+','+o.yy)&&Math.abs(o.x-px0)<7&&Math.abs(o.yy-py0)<6);
    else if(o.k==='lamp') drawLamp(c,o.x,o.py,time);
    else if(o.k==='prop'){
      const t=o.t;
      if(t===T.STALL) drawStall(c,o.x,o.yy,o.px,o.py);
      else if(t===T.BOARD){ const tw=townAtTile(o.x,o.yy); drawBoard(c,o.px,o.py,time,!!(tw&&boardFresh(tw))); }
      else if(t===T.WELL) drawWell(c,o.px,o.py);
      else if(t===T.STATUE) drawStatue(c,o.px,o.py);
      else if(t===T.FIRE) drawFire(c,o.px,o.py,time);
    }
    else if(o.k==='npc'){
      const n=o.n, sc=n.scale||(n.persona===2?0.75:1);
      drawDuck(c,n.x,n.y,n.dir,n.phase,n.moving,n.pal,{scale:sc,head:n.acc.head,neck:n.acc.neck});
      if(n.deco) n.deco(c,n,time);
      const mk=npcMark(n); if(mk) drawMark(c,n.x,n.y-34*sc,time,mk.ch,mk.col);
      if(n.owl&&night) lights.push({x:n.x,y:n.y-12,r:80,s:0.7,w:0.7});
    }
    else if(o.k==='fn') o.f();
    else drawMe(c,time);
  }
  if(night){
    const lan=!!isHeld('lantern');
    lights.push({x:g.px,y:g.py-14,r:lan?230:105,s:lan?0.95:0.8,w:lan?0.9:0.15});
  }
  if(g.target&&g.mode==='play') drawBubble(c,g.target.x,g.target.y,time,'Z');
  c.setTransform(1,0,0,1,0,0);
}

/* ---- day and night ---- */
const NIGHT_MAX=0.72;
const AMB=[[0,[8,12,44,0.72]],[4.6,[10,16,56,0.70]],[5.8,[255,140,90,0.30]],[7.2,[255,200,150,0.11]],[8.6,[255,240,200,0]],[16.4,[255,240,200,0]],[18,[255,170,80,0.17]],[19.6,[200,90,110,0.34]],[21,[16,20,68,0.62]],[22.5,[8,12,44,0.72]],[24,[8,12,44,0.72]]];
function ambient(h){
  for(let i=1;i<AMB.length;i++){
    if(h<=AMB[i][0]){
      const a=AMB[i-1], b=AMB[i], k=(h-a[0])/(b[0]-a[0]);
      return [a[1][0]+(b[1][0]-a[1][0])*k,a[1][1]+(b[1][1]-a[1][1])*k,a[1][2]+(b[1][2]-a[1][2])*k,a[1][3]+(b[1][3]-a[1][3])*k];
    }
  }
  return AMB[AMB.length-1][1];
}
let nc=null, nctx=null;
function drawNight(c,W,H,kd){
  const a=ambient(g.clock);
  NIGHT=a[3]/NIGHT_MAX;
  if(a[3]<0.015) return;
  if(!nc){ nc=document.createElement('canvas'); nctx=nc.getContext('2d'); }
  if(nc.width!==W||nc.height!==H){ nc.width=W; nc.height=H; }
  const n=nctx;
  n.setTransform(1,0,0,1,0,0); n.globalCompositeOperation='source-over'; n.clearRect(0,0,W,H);
  n.fillStyle='rgba('+(a[0]|0)+','+(a[1]|0)+','+(a[2]|0)+','+a[3].toFixed(3)+')'; n.fillRect(0,0,W,H);
  n.globalCompositeOperation='destination-out';
  for(const L of lights){
    const sx=(L.x-view.ox)*kd, sy=(L.y-view.oy)*kd, r=L.r*kd;
    if(sx+r<0||sy+r<0||sx-r>W||sy-r>H) continue;
    const gr=n.createRadialGradient(sx,sy,r*0.08,sx,sy,r);
    gr.addColorStop(0,'rgba(0,0,0,'+L.s+')'); gr.addColorStop(0.55,'rgba(0,0,0,'+(L.s*0.55).toFixed(2)+')'); gr.addColorStop(1,'rgba(0,0,0,0)');
    n.fillStyle=gr; n.fillRect(sx-r,sy-r,r*2,r*2);
  }
  n.globalCompositeOperation='source-over';
  c.drawImage(nc,0,0);
  const k=Math.min(1,a[3]/0.45);
  c.globalCompositeOperation='lighter';
  for(const L of lights){
    if(!L.w) continue;
    const sx=(L.x-view.ox)*kd, sy=(L.y-view.oy)*kd, r=L.r*kd*0.85;
    if(sx+r<0||sy+r<0||sx-r>W||sy-r>H) continue;
    const gr=c.createRadialGradient(sx,sy,0,sx,sy,r);
    gr.addColorStop(0,'rgba(255,170,70,'+(0.34*L.w*k).toFixed(3)+')'); gr.addColorStop(1,'rgba(255,150,50,0)');
    c.fillStyle=gr; c.fillRect(sx-r,sy-r,r*2,r*2);
  }
  c.globalCompositeOperation='source-over';
}
function phaseName(h){
  if(h>=5&&h<7.5) return 'Dawn';
  if(h>=7.5&&h<12) return 'Morning';
  if(h>=12&&h<17) return 'Afternoon';
  if(h>=17&&h<21) return 'Evening';
  return 'Night';
}
function clockStr(){
  const h=Math.floor(g.clock), m=Math.floor((g.clock-h)*60/10)*10, hh=h%12===0?12:h%12;
  return hh+':'+String(m).padStart(2,'0')+(h>=12?' PM':' AM');
}

/* ---- weather-ish particles drawn in screen space ---- */
const parts=[];
const PCOL={leaves:['#c4561e','#d9822b','#e8b13a','#a8432b'],petals:['#f4a6c3','#fff','#fbd2e2','#f6d55c'],confetti:['#e86a92','#f6d55c','#8ecae6','#86e29a','#c792ea']};
function updateParts(dt,kind,W,H){
  if(!kind){ parts.length=0; return; }
  const target=kind==='snow'?70:kind==='fly'?20:kind==='sparkle'?16:28;
  while(parts.length<target){
    parts.push({x:Math.random()*W,y:Math.random()*H,v:0.5+Math.random(),p:Math.random()*6.28,c:Math.random()});
  }
  while(parts.length>target) parts.pop();
  for(const p of parts){
    p.p+=dt*(1+p.v);
    if(kind==='snow'){ p.y+=dt*H*0.07*p.v; p.x+=Math.sin(p.p)*dt*14; }
    else if(kind==='leaves'||kind==='petals'||kind==='confetti'){ p.y+=dt*H*0.06*p.v; p.x+=dt*W*0.025*p.v+Math.sin(p.p)*dt*20; }
    else if(kind==='spores'){ p.y-=dt*H*0.035*p.v; p.x+=Math.sin(p.p)*dt*10; }
    else if(kind==='embers'){ p.y-=dt*H*0.05*p.v; p.x+=Math.sin(p.p)*dt*16; }
    else if(kind==='fly'||kind==='sparkle'){ p.x+=Math.sin(p.p*0.7)*dt*22; p.y+=Math.cos(p.p*0.9)*dt*16; }
    if(p.y>H+10) p.y=-10; if(p.y<-12) p.y=H+10; if(p.x>W+10) p.x=-10; if(p.x<-12) p.x=W+10;
  }
}
function drawParts(c,kind,kd){
  if(!kind) return;
  const u=Math.max(2,kd*1.5);
  for(const p of parts){
    if(kind==='snow'){ c.fillStyle='rgba(255,255,255,'+(0.5+0.4*p.v/1.5).toFixed(2)+')'; c.fillRect(p.x,p.y,u*(0.8+p.v*0.5),u*(0.8+p.v*0.5)); }
    else if(kind==='fly'){ const a=(0.35+0.65*Math.max(0,Math.sin(p.p*2.3))); c.fillStyle='rgba(220,255,120,'+a.toFixed(2)+')'; c.fillRect(p.x,p.y,u,u); c.fillStyle='rgba(220,255,120,'+(a*0.25).toFixed(2)+')'; c.fillRect(p.x-u,p.y-u,u*3,u*3); }
    else if(kind==='spores'){ const a=0.3+0.5*Math.max(0,Math.sin(p.p*1.4)); c.fillStyle='rgba('+(p.c<0.5?'140,255,220':'210,160,255')+','+a.toFixed(2)+')'; c.fillRect(p.x,p.y,u,u); }
    else if(kind==='embers'){ const a=0.25+0.6*Math.max(0,Math.sin(p.p*1.7)); c.fillStyle='rgba('+(p.c<0.5?'255,150,60':'255,200,90')+','+a.toFixed(2)+')'; c.fillRect(p.x,p.y,u,u); }
    else if(kind==='sparkle'){ const a=Math.max(0,Math.sin(p.p*2.1)); c.fillStyle='rgba(255,255,255,'+(a*0.8).toFixed(2)+')'; c.fillRect(p.x,p.y,u,u); c.fillRect(p.x-u,p.y+u*0.3,u*3,u*0.4); }
    else{
      const cols=PCOL[kind]; c.fillStyle=cols[(p.c*cols.length)|0];
      const w=u*(kind==='leaves'?2:1.4), h=u*(kind==='leaves'?1.4:1);
      c.save(); c.translate(p.x,p.y); c.rotate(p.p); c.fillRect(-w/2,-h/2,w,h); c.restore();
    }
  }
}
function drawMe(c,time){
  const wet=g.scene==='world'&&tileAt(Math.floor(g.px/TS),Math.floor((g.py-2)/TS))===T.WATER;
  drawDuck(c,g.px,g.py,g.dir,g.phase,g.moving,{body:'#ffd84a',wing:'#f0b921',bill:'#ff8a1f'},{head:g.worn.head,neck:g.worn.neck,wet:wet});
}

/* ---- shop interiors ---- */
const INT_W=11, INT_H=8;
const INTERIOR=[
  'WWWWWWWWWWW',
  'WSSS...SSSW',
  'W..CCCCC..W',
  'W.........W',
  'W.........W',
  'W.P.....P.W',
  'W.........W',
  'WWWWDDDWWWW'
];
const FLOORS={bakery:['#c89b6a','#b98b5c'],market:['#86b36a','#76a35c'],supply:['#4f6296','#455788'],curio:['#7a5a9a','#6b4c8a'],
  cafe:['#b08a62','#a07c56'],florist:['#d6c4a0','#cdb994'],books:['#7a5538','#6b4a30'],tailor:['#a05f6f','#925464'],toys:['#e0c04a','#d4b440']};
const RUGS={bakery:'#e8d3a0',market:'#c9e0a8',supply:'#8aa0d6',curio:'#b794d6',cafe:'#d98a6a',florist:'#f2b8cc',books:'#c9604a',tailor:'#d6a0ff',toys:'#5ac0e0'};
const GOODS={bakery:['#d9a05b','#8b5a8c','#f2e2b8'],market:['#e86a4a','#86e29a','#f6d55c'],supply:['#c9a24a','#8a5a2b','#3a62a8'],curio:['#8f7ac9','#e0b84a','#c3c8cf'],
  cafe:['#f6f1e6','#8a5a2b','#c0392b'],florist:['#e86a92','#f6d55c','#c792ea'],books:['#7a2a2a','#2f6f4f','#3a62a8'],tailor:['#c0392b','#8a2be2','#f6d55c'],toys:['#e0587a','#3a7ca5','#4caf50']};
function interiorSolid(tx,ty){
  if(tx<0||ty<0||tx>=INT_W||ty>=INT_H) return true;
  const ch=INTERIOR[ty][tx];
  return ch==='W'||ch==='S'||ch==='C'||ch==='P';
}
function drawInterior(c,W,H,kd,time){
  const sh=g.shop, kind=sh.b.kind;
  const vw=W/kd, vh=H/kd;
  const ox=Math.round((INT_W*TS/2-vw/2)*kd)/kd, oy=Math.round((INT_H*TS/2-vh/2)*kd)/kd;
  c.setTransform(kd,0,0,kd,-ox*kd,-oy*kd);
  for(let ty=0;ty<INT_H;ty++) for(let tx=0;tx<INT_W;tx++){
    const ch=INTERIOR[ty][tx], px=tx*TS, py=ty*TS;
    if(ch==='W'){
      rect(c,px,py,TS,TS,'#4a3626'); rect(c,px,py+TS-4,TS,4,'#2e2016'); rect(c,px+4,py+4,TS-8,2,'rgba(255,255,255,0.08)');
    } else {
      rect(c,px,py,TS,TS,FLOORS[kind][(tx+ty)&1]);
      if(ch==='D') rect(c,px+2,py+4,TS-4,TS-8,'#8c3b2f');
    }
  }
  /* rug */
  rect(c,3.6*TS,3.5*TS,3.8*TS,2.6*TS,RUGS[kind]);
  c.strokeStyle='rgba(0,0,0,0.25)'; c.lineWidth=2; c.strokeRect(3.6*TS+4,3.5*TS+4,3.8*TS-8,2.6*TS-8);
  rect(c,3.6*TS+10,3.5*TS+10,3.8*TS-20,2.6*TS-20,'rgba(255,255,255,0.18)');
  const gc=GOODS[kind];
  for(let tx=0;tx<INT_W;tx++){
    if(INTERIOR[1][tx]!=='S') continue;
    const px=tx*TS, py=TS;
    rect(c,px,py,TS,TS,'#5b4430'); rect(c,px+2,py+2,TS-4,TS-4,'#3b2b1e'); rect(c,px+2,py+15,TS-4,2,'#8a6a45');
    for(let i=0;i<3;i++){ circ(c,px+7+i*9,py+11,3.5,gc[(tx+i)%3]); circ(c,px+7+i*9,py+25,3.5,gc[(tx+i+1)%3]); }
  }
  const k=sh.b.keeper;
  drawDuck(c,5.5*TS,2*TS-4,'down',0,false,k.pal,{head:k.acc&&k.acc.head,neck:k.acc&&k.acc.neck});
  for(let tx=3;tx<=7;tx++){
    const px=tx*TS, py=2*TS;
    rect(c,px,py+6,TS,TS-6,'#8a6238'); rect(c,px,py+6,TS,5,'#b98a55'); rect(c,px,py+TS-4,TS,4,'#5b3f22');
  }
  for(const tx of [2,8]){
    const px=tx*TS, py=5*TS;
    rect(c,px+9,py+18,14,12,'#a8532f'); circ(c,px+16,py+12,9,'#2f8f3f'); circ(c,px+11,py+8,5,'#47a853'); circ(c,px+21,py+9,5,'#3a9a47');
  }
  rect(c,4.5*TS,7*TS+8,TS*2+TS/2,2,'rgba(255,255,255,0.0)');
  drawMe(c,time);
  if(g.target&&g.mode==='play') drawBubble(c,g.target.x,g.target.y,time,'Z');
  const a2=ambient(g.clock);
  if(a2[3]>0.1){ c.fillStyle='rgba(20,18,50,'+(a2[3]*0.28).toFixed(2)+')'; c.fillRect(ox,oy,vw,vh); }
  c.setTransform(1,0,0,1,0,0);
}

/* ===== GAME DATA & STATE ===== */
const ITEMS={
  map:{name:"Explorer's Map",desc:"Charts everywhere you have walked. It fills in on its own. Wheel or +/- zooms, drag pans.",use:'map',nogift:true},
  crust:{name:'Crusty Bread',price:3,desc:'Day-old and perfect. Ducks are not supposed to have this much. Ducks do not care.',use:'eat',boost:15,quip:'Crunch. Wonderful.'},
  muffin:{name:'Berry Muffin',price:5,desc:'Warm, soft, and slightly purple.',use:'eat',boost:30,quip:'You eat it in two bites and regret nothing.'},
  tea:{name:'Pond-Water Tea',price:4,desc:'Steeped in actual pond. Surprisingly calming.',use:'eat',boost:40,quip:'Warm all the way down to your tail feathers.'},
  scone:{name:'Honey Scone',price:4,desc:'Crumbly, golden, and dangerously good with tea.',use:'eat',boost:25,quip:'Crumbs everywhere. You are a duck. This is fine.'},
  cocoa:{name:'Acorn Cocoa',price:5,desc:'Thick, sweet, and a little nutty. Served in a mug the size of your head.',use:'eat',boost:45,quip:'You get a chocolate moustache. It suits you.'},
  soup:{name:'Pea Soup',price:6,desc:'Green, steamy, and extremely filling.',use:'eat',boost:60,quip:'Slurp. You feel like you could waddle for miles.'},
  seeds:{name:'Sunflower Seeds',price:2,desc:'A small paper bag. Excellent for nibbling while thinking.',use:'eat',boost:15,quip:'Crack, crack, crack. Good thinking snack.'},
  peas:{name:'Fresh Peas',price:3,desc:'Round, green, and extremely duck-approved.',use:'eat',boost:20,quip:'Pop! Sweet and fresh.'},
  clover:{name:'Lucky Clover',price:6,desc:'Four leaves. Probably. You count them twice.',use:'note',note:'You feel slightly luckier. It may be placebo.'},
  worms:{name:'Worm Jar',price:4,desc:'They wiggle. They look at you. You look at them.',use:'eat',boost:25,quip:'Wriggly and delicious. Do not think about it.'},
  honey:{name:'Wild Honey',price:10,desc:'A little jar of amber. The market only keeps it for ducks it trusts.',use:'eat',boost:75,quip:'Sticky, sweet, and powerful. Your feet barely touch the ground.'},
  cake:{name:'Celebration Cake',price:14,desc:'A tiny cake with a tiny candle. The bakery only bakes these for friends.',use:'eat',boost:90,quip:'You make a wish and blow out the candle. Then eat the candle. Mistake. Worth it.'},
  glass:{name:'Magnifying Glass',price:15,desc:'Makes small clues big. Dark trees will now glint if you have not studied them yet.',use:'note',note:'You peer at your own feather through it. Impressive.'},
  hat:{name:'Detective Hat',price:20,desc:'A proper deerstalker. Instantly makes you more mysterious.',use:'equip',slot:'head',wear:'hat'},
  crown:{name:'Flower Crown',price:14,desc:'Woven daisies and violets. Smells like a good afternoon.',use:'equip',slot:'head',wear:'crown'},
  scarf:{name:'Red Scarf',price:12,desc:'Long, soft, and unapologetically red.',use:'equip',slot:'neck',wear:'scarf'},
  bowtie:{name:'Violet Bow Tie',price:10,desc:'For ducks who mean business. Or at least parties.',use:'equip',slot:'neck',wear:'bowtie'},
  socks:{name:'Cozy Socks',price:6,desc:'Striped. Not strictly useful for webbed feet. Still.',use:'note',note:'You try to put them on. It is a long and humbling experience.'},
  notebook:{name:'Notebook',price:8,desc:'For writing down clues. Your case notes below are kept in it.',use:'note',note:'You flip to a fresh page. It smells like possibility.'},
  novel:{name:'Detective Novel',price:9,desc:'"The Case of the Missing Pond." Page one is already dramatic.',use:'note',note:'Chapter one: it was a dark and stormy puddle. You are hooked.'},
  guide:{name:'Field Guide to Ducks',price:8,desc:'Pictures of ducks. Rude comments in the margins.',use:'note',note:'You look yourself up. "Common, but charming." You will take it.'},
  cookbook:{name:'Bread Cookbook',price:7,desc:'Four hundred recipes. All of them are bread.',use:'note',note:'Page 212: bread, but warm. Revolutionary.'},
  lantern:{name:'Little Lantern',price:12,desc:'A warm glow that pushes the dark back. Lights up the night and the dark woods around you.',use:'note',note:'It glows warmly. The dark feels a little less heavy.'},
  specs:{name:'Binoculars',price:16,desc:'Sold only to trusted customers. See far, see detail, see that frog glaring at you.',use:'note',note:'Through the lenses you see a very distant frog. It is staring back.'},
  daisy:{name:'Daisy Bunch',price:3,desc:'A cheerful little bunch tied with grass.',use:'note',note:'He loves me. He loves me not. You stop counting.'},
  bouquet:{name:'Wildflower Bouquet',price:7,desc:'Every colour at once. A reliable way to make a friend.',use:'note',note:'You bury your bill in the petals. Lovely.'},
  bulb:{name:'Tulip Bulb',price:4,desc:'Plant it and wait. You are not good at waiting.',use:'note',note:'You pat it. It does not do anything yet.'},
  ducky:{name:'Rubber Duckie',price:6,desc:'A smaller, squeakier, far less dignified relative.',use:'note',note:'Squeak! You pretend you did not do that.'},
  kite:{name:'Paper Kite',price:9,desc:'It flies if you run. You are fast when you want to be.',use:'note',note:'You run in a circle. The kite does not. You get dizzy.'},
  marbles:{name:'Marbles',price:5,desc:'Little glass worlds in a drawstring bag.',use:'note',note:'Click, click. A very satisfying sound.'},
  top:{name:'Spinning Top',price:4,desc:'Wind it, pull it, watch it go. Hypnotic.',use:'note',note:'It spins for ages. You forget what you were doing.'},
  pebble:{name:'Shiny Pebble',price:5,desc:'Smooth, round, and unreasonably shiny.',use:'note',note:'You hold it up to the light. Very shiny.'},
  feather:{name:'Odd Feather',price:7,desc:'Not a duck feather. You checked.',use:'note',note:'It shimmers a color you cannot name.'},
  key:{name:'Mystery Key',price:25,desc:'It is warm to the touch. It does not fit any lock you know of.',use:'note',note:'The key hums faintly. You decide not to think about it.'},
  compass:{name:'Old Compass',price:18,desc:'The needle does not point north. It points home. Shows a Home arrow at the top.',use:'note',note:'The needle swings, then settles. It knows the way back.'},
  parcel:{name:'Sealed Parcel',desc:'Wrapped in twine. Check your journal to see who it is for.',use:'note',note:'You give it a gentle shake. Something rattles. You stop shaking it.',nogift:true},
  trinket:{name:'Lost Trinket',desc:'Somebody is missing this. Return it before it gets lost again.',use:'note',note:'It is still warm from the sun.',nogift:true},
  medal:{name:'Honorary Medal',desc:'Awarded for being a true friend to a town. Heavy, shiny, and a little embarrassing.',use:'note',note:'You pin it to your chest feathers. A tiny bit of glory.',nogift:true}
};
const STOCK={
  bakery:['crust','muffin','tea','scone'], market:['seeds','peas','clover','worms'], supply:['notebook','glass','hat','lantern'], curio:['pebble','feather','key','compass'],
  cafe:['cocoa','soup','scone','tea'], florist:['daisy','bouquet','bulb','crown'], books:['novel','guide','cookbook','notebook'], tailor:['scarf','bowtie','socks','hat'], toys:['ducky','kite','marbles','top']
};
/* only sold to ducks the town trusts (Trusted Neighbor and up) */
const SPECIAL={bakery:'cake',market:'honey',supply:'specs'};
const GREET={
  bakery:['Fresh out of the oven!','Mind the crumbs. Actually, do not. Eat them.'],
  market:['Everything here is fresh. Mostly.','Peas today are exceptional.'],
  supply:['A detective is only as good as their kit.','Looking for clues? You are in the right place.'],
  curio:['Strange things for strange ducks.','Do not touch the key. Actually, touch the key.'],
  cafe:['Warm drinks for cold feathers!','Sit anywhere. Well. Stand anywhere. Ducks are short.'],
  florist:['Everything in here is in bloom. Most of it on purpose.','Flowers say what ducks cannot. Mostly "quack."'],
  books:['Shh. Quiet voices. Quack voices are fine.','Every book here has been read by at least one duck.'],
  tailor:['Measurements are free. Opinions are extra.','Nothing fits a duck. That is why I am in business.'],
  toys:['Do not wind the clockwork frog. Last time went poorly.','Everything here squeaks. Yes, everything.']
};
const RANKS=[
  {n:'Stranger',at:0,disc:0},{n:'Newcomer',at:5,disc:0.03},{n:'Familiar Face',at:12,disc:0.06},
  {n:'Trusted Neighbor',at:24,disc:0.10},{n:'Local Hero',at:42,disc:0.15},{n:'Town Legend',at:66,disc:0.20}
];
const RANK_GREET=[
  ['Hello, stranger.','Oh! A new face.'],
  ['Hello again!','Back again, I see.'],
  ['Good to see you!','Ah, a familiar face.'],
  ['Always a pleasure!','Hey, neighbor!'],
  ['The town hero returns!','There you are! Everyone is talking about you.'],
  ['The legend herself! Himself? Itself! Welcome!','Our favorite duck is here!']
];
const LOST_NAMES=['lucky spoon','knitting needle','tiny bell','reading glasses','favorite button','silver thimble','pocket watch','good luck charm','crochet hook','little compass'];
function rankOf(pts){ let r=0; for(let i=0;i<RANKS.length;i++) if(pts>=RANKS[i].at) r=i; return r; }
function itemBase(id,town){ return Math.max(1,ITEMS[id].price+Math.floor(hash(town.rx,town.ry,id.charCodeAt(0)*7+id.length)*3)-1); }
function itemPrice(id,town){ return Math.max(1,Math.round(itemBase(id,town)*(1-RANKS[townRank(town)].disc))); }
function shopStock(b,town){
  const a=STOCK[b.kind].slice();
  if(SPECIAL[b.kind]&&townRank(town)>=3) a.push(SPECIAL[b.kind]);
  return a;
}
function shopOpen(b){ if(!b.enterable) return false; const h=HOURS[b.kind]; return g.clock>=h[0]&&g.clock<h[1]; }
/* windows glow: shops while open, houses through the evening */
function buildingLit(b){
  if(b.enterable) return shopOpen(b)&&NIGHT>0.05;
  return g.clock>=17.5&&g.clock<23.5&&hash(b.x,b.y,g.day%5)<0.75;
}

const DARK_LINES=[
  'The bark is cold, and it hums faintly. Your feathers stand on end.',
  'Black sap crawls beneath the bark, slow as a thought.',
  'You press your bill to the wood. Something under the roots is... listening.',
  'The leaves do not rustle with the wind. They rustle against it.',
  'Scratches ring the trunk. Not claws. Not beaks. Something older.',
  'A feather is caught in the bark. Yours? No. Yours is not that color. Not yet.',
  'The hum changes pitch when you step closer. It knows you are here.',
  'Violet threads pulse under the moss, all pointing the same way.'
];
const GLASS_LINES=[
  'Through the glass you see pale threads linking this tree to the next, and the next, and somewhere deep.',
  'The glass shows tiny shapes in the sap. They are moving.',
  'Under the lens, the bark looks like writing. You almost understand it.'
];
const TREE_LINES=['Bark, moss, and a beetle with strong opinions.','A perfectly ordinary tree. For now.','You peck at it. It does not peck back.','Smells like pine and distant rain.'];
const ROCK_LINES=['A rock. Solid. Dependable. Not a clue.','You nudge it with your bill. It declines to move.'];
const FLOWER_LINES=['Smells like spring and small adventures.','A flower. You consider eating it, then decide against it.'];
const BUSH_LINES=['A rustle inside. Just a beetle. Probably.','Prickly. You pick a leaf out of your feathers.'];
const MUSH_LINES=['A little mushroom. You do not eat it. Ducks are not that brave.','It smells earthy and a little bit funny.'];
const MUSH_DARK_LINES=['The mushroom glows faintly. It does not like being looked at.','Its cap pulses in time with the humming trees.'];
const STUMP_LINES=['An old stump with rings. You count them and lose track at forty.','A perfectly good place to stand and look important.'];
const LAMP_LINES=['A friendly lamp. It hums in a much nicer way than the trees.'];
const HOUSE_LINES=['Nobody answers. You hear snoring, and one very small quack.','The door is locked. A note says: Back soon. Napping.','Someone is definitely home, but they are not telling.'];
const WISH_LINES=['You toss in a crumb. The water ripples, and for a second it glows violet. Then it is just water.','You make a wish. The fountain wishes you luck. Then it wishes it had not.','A crumb for the pond. Far away, something hums back.'];

function hasShop(t,k){ return t.buildings.some(b=>b.kind===k); }
function shopNameOf(t,k){ const b=t.buildings.find(b=>b.kind===k); return b?b.name:''; }
function shopListText(t){
  const L=Object.assign({bakery:'a bakery',market:'a market',supply:'a detective supplier',curio:'a curio shop',cafe:'a cafe',florist:'a florist',books:'a bookshop',tailor:'a tailor',toys:'a toy shop'},window.SHOP_LABEL||{});
  const a=t.buildings.map(b=>L[b.kind]);
  return a.length>1?a.slice(0,-1).join(', ')+' and '+a[a.length-1]:a[0];
}
const PERSONAS=[
  [['Well, hello there, traveler! Welcome to {town}.',(g,n)=>'Around here you will find '+shopListText(n.town)+'.','Short on crumbs? Keep your eyes on the ground. Or check the notice board in the square for odd jobs.'],['Still here? Good. A town needs ducks.','Tip: help folks out and word spreads. Shopkeepers give better prices to ducks they trust.']],
  [['Did you come through the forest?','Strange things out there. Some of the trees have gone dark. Not dead. Dark.','My cousin went to look and came back humming. Would not say what he saw.'],['Do not tell anyone I told you about the trees. Okay? Okay.']],
  [[g=>g.worn.head==='hat'?'WOW. A detective hat! You are a REAL detective!':'Are you a detective? Detectives wear hats. Just saying.','I am going to be a detective when I grow up. Or a baker. Or both.'],['Do you think a duck can solve a mystery? Mama says only big ones.']],
  [['Seventy winters I have watched this pond.','The woods used to sing at night. Crickets, owls. Now they just hum.','Something changed. I would look into it, but my knees say no.'],['Mind the dark trees. Pretty to look at. Not pretty to listen to.']],
  [['Bread is the finest thing a duck can eat. Do not let anyone say otherwise.','Crusty Bread is the cheapest. The Berry Muffin is the treat.'],['Fresh bread smell. Do you smell it? I smell it constantly.']],
  [['Press I and unfold your map. It fills in as you walk, as far as you can see.','Zoom out and the whole world is a smudge. Zoom in and every flower is a pixel. I find it calming.'],['The world does not end, you know. I tried to reach the edge. Gave up on Tuesday.']],
  [[(g,n)=>hasShop(n.town,'supply')?'Looking for a proper detective kit? '+shopNameOf(n.town,'supply')+' sells a hat and a magnifying glass.':'No detective supplier in {town}, sadly. Try another town for a magnifying glass.','A lantern helps in the dark woods. And at night, anywhere. A compass helps you get home.'],['Some shops keep their best goods for ducks they trust. Be trustworthy. It pays.']],
  [['Have you seen the lights out in the forest? Faint purple. Like something breathing.','I am sure it is nothing. It is probably nothing. Quack.'],['It is nothing. It is nothing. It is... nothing.']],
  [['Flowers love attention. Honestly, so do I.','A bouquet makes anyone smile. A lot of ducks in {town} are secretly sentimental.'],['The night-blooming ones open once the lamps come on. I sit and watch.']],
  [['I hum when I walk. Every town has its own tune, did you notice?','{town} sounds like a flute, I think.'],['When the dark trees hum, it is always the same flat note. Rude.']],
  [['I run parcels for half the town. Between us, I am always late.','If you have spare time, the notice board in the square is full of little jobs.'],['Run errands, earn trust. Earn trust, earn discounts. That is how a small town works.']],
  [['Shh. Not many ducks awake at this hour.','I like the night. The lamps, the quiet, the little lights in the grass.','Most shops close up, but the cafe stays open late.'],['The dark trees hum louder at night. Take a lantern.']]
];
const RUMORS=[
  'Between us: the first tree went dark behind the old mill, the night the wheel stopped turning.',
  'My cousin hummed in his sleep for a week. Same note as the trees. Now he will not eat peas. PEAS.',
  'I saw a violet light under the pond once. Mama says it was a reflection. It was not a reflection.',
  'Seventy winters, and I never saw the dark creep toward a town. It shies away from lamplight. Interesting, hm?',
  'The bread dough rises faster near the dark trees. Spooky. I did not sell that batch.',
  'I mapped the dark patches. They form a ring. We are standing somewhere inside a ring.',
  'Lanterns work on the dark. Burn bright enough and the purple fades. Not forever, but it fades.',
  'The lights in the forest blink in a pattern. Three short, one long. Like a heartbeat.',
  'Nothing grows near the dark trees except mushrooms. Glowing ones. Do not pick them.',
  'The humming has words, if you listen closely at night. I will not tell you what they say.',
  'I delivered a parcel to the forest edge once. Nobody lived there. Someone signed for it.',
  'At night the trees turn toward the town. Slowly. Like sunflowers. They are watching the lamps.'
];

const g={
  mode:'title',scene:'world',time:0,
  px:0.5*TS,py:0.8*TS,dir:'down',faceKey:null,moving:false,phase:0,
  camX:0.5*TS,camY:0.5*TS,
  crumbs:25,inv:{map:1},worn:{head:null,neck:null},inspected:new Set(),clues:0,
  flags:{},towns:new Map(),npcs:[],target:null,dist:0,
  clock:8,day:1,rep:{},mem:{},quests:[],work:{},rumors:[],boost:0,choice:null,mini:null,curTown:null,fadeMax:0.4,
  dialog:null,shop:null,shopSel:0,invSel:0,saved:null,fadeIn:0,sound:true,
  slot:0,dkLevel:0,lastTx:null,lastTy:null,scanT:0,explored:0
};
const DIRV={up:{x:0,y:-1},down:{x:0,y:1},left:{x:-1,y:0},right:{x:1,y:0}};
const OPP={up:'down',down:'up',left:'right',right:'left'};
const keys={};

/* ===== audio ===== */
let AC=null;
function ac(){ if(!AC){ try{ AC=new (window.AudioContext||window.webkitAudioContext)(); }catch(e){} } return AC; }
function tone(type,f0,f1,dur,vol){
  if(!g.sound) return;
  const a=ac(); if(!a) return;
  try{
    const t=a.currentTime, o=a.createOscillator(), gn=a.createGain(), f=a.createBiquadFilter();
    o.type=type; o.frequency.setValueAtTime(f0,t); o.frequency.exponentialRampToValueAtTime(f1,t+dur*0.8);
    f.type='bandpass'; f.frequency.value=type==='sawtooth'?900:2400;
    gn.gain.setValueAtTime(0.0001,t); gn.gain.exponentialRampToValueAtTime(vol,t+0.02); gn.gain.exponentialRampToValueAtTime(0.0001,t+dur);
    o.connect(f); f.connect(gn); gn.connect(a.destination); o.start(t); o.stop(t+dur+0.02);
  }catch(e){}
}
function quack(){ tone('sawtooth',520,240,0.18,0.16); }
function blip(){ tone('square',700,900,0.08,0.05); }
function coin(){ tone('square',880,1320,0.14,0.06); }

/* ===== explored-map storage: 32x32-tile chunks, one pixel per tile ===== */
const CH=32, chunks=new Map();
function chunkAt(cxk,cyk){
  const k=cxk+','+cyk; let ch=chunks.get(k);
  if(!ch){
    ch={cxk:cxk,cyk:cyk,flags:new Uint8Array(CH*CH),cv:null,ctx:null};
    chunks.set(k,ch);
  }
  if(!ch.cv) buildChunk(ch);
  return ch;
}
function buildChunk(ch){
  const cv=document.createElement('canvas'); cv.width=CH; cv.height=CH;
  ch.cv=cv; ch.ctx=cv.getContext('2d');
  for(let i=0;i<CH*CH;i++) if(ch.flags[i]){
    const lx=i%CH, ly=(i/CH)|0;
    ch.ctx.fillStyle=mapColor(ch.cxk*CH+lx,ch.cyk*CH+ly); ch.ctx.fillRect(lx,ly,1,1);
  }
}
function reveal(tx,ty,r){
  for(let dy=-r;dy<=r;dy++) for(let dx=-r;dx<=r;dx++){
    if(dx*dx+dy*dy>r*r+1) continue;
    const ax=tx+dx, ay=ty+dy, cxk=Math.floor(ax/CH), cyk=Math.floor(ay/CH);
    const ch=chunkAt(cxk,cyk), lx=ax-cxk*CH, ly=ay-cyk*CH, i=ly*CH+lx;
    if(ch.flags[i]) continue;
    ch.flags[i]=1; g.explored++;
    ch.ctx.fillStyle=mapColor(ax,ay); ch.ctx.fillRect(lx,ly,1,1);
  }
}

/* ===== DOM ===== */
const $=id=>document.getElementById(id);
const stage=$('stage'), cv=$('view'), ctx=cv.getContext('2d');
const el={hud:$('hud'),crumbs:$('crumbs'),area:$('area'),homeChip:$('homeChip'),homeTxt:$('homeTxt'),toast:$('toast'),
  dialog:$('dialog'),dWho:$('dWho'),dText:$('dText'),shop:$('shop'),shName:$('shName'),shSay:$('shSay'),shCrumbs:$('shCrumbs'),
  shList:$('shList'),shMsg:$('shMsg'),inv:$('inv'),slots:$('slots'),dName:$('dName'),dDesc:$('dDesc'),dNote:$('dNote'),dUse:$('dUse'),
  notes:$('notes'),clock:$('clockTxt'),repChip:$('repChip'),repTxt:$('repTxt'),boostChip:$('boostChip'),boostT:$('boostT'),
  dNext:$('dNext'),dChoices:$('dChoices'),mini:$('mini'),miTitle:$('miTitle'),miSay:$('miSay'),miPay:$('miPay'),miZone:$('miZone'),miMark:$('miMark'),miDots:$('miDots'),miMsg:$('miMsg'),
  jr:$('jr'),jrBody:$('jrBody'),mapview:$('mapview'),mapc:$('mapc'),mRead:$('mRead'),title:$('title'),obj:$('objective'),bSnd:$('bSnd')};
const mctx=el.mapc.getContext('2d');
let dpr=1, kd=2, mapW=300, mapH=300, toastTimer=0;
const m={z:5,cx:0,cy:0,drag:null};

function resize(){
  dpr=Math.min(2,window.devicePixelRatio||1);
  const w=Math.max(1,stage.clientWidth), h=Math.max(1,stage.clientHeight);
  cv.width=Math.floor(w*dpr); cv.height=Math.floor(h*dpr);
  kd=FULL?Math.max(1,Math.round(Math.min(w,h)/14*dpr/32)):Math.max(1,Math.round(Math.min(w,h)/11*dpr/32*1.35));
  if(g.mode==='map') sizeMap();
}
function sizeMap(){
  mapW=Math.max(1,el.mapview.clientWidth); mapH=Math.max(1,el.mapview.clientHeight);
  el.mapc.width=Math.floor(mapW*dpr); el.mapc.height=Math.floor(mapH*dpr);
}
function toast(msg,ms){
  el.toast.textContent=msg; el.toast.hidden=false;
  clearTimeout(toastTimer); toastTimer=setTimeout(()=>{el.toast.hidden=true;},ms||2600);
}
function pick(a){ return a[Math.floor(Math.random()*a.length)]; }
function fmt(s,town){ return s.replace('{town}',town?town.name:'town'); }

/* ===== collision ===== */
function solidTile(tx,ty){
  if(g.scene==='shop') return interiorSolid(tx,ty);
  return SOLID.has(tileAt(tx,ty));
}
function blockedAt(x,y){
  const l=x-6, r=x+6, t=y-6, b=y-0.01;
  for(let ty=Math.floor(t/TS);ty<=Math.floor(b/TS);ty++) for(let tx=Math.floor(l/TS);tx<=Math.floor(r/TS);tx++) if(solidTile(tx,ty)) return true;
  if(g.scene==='world') for(const n of g.npcs) if(Math.abs(n.x-x)<12&&Math.abs(n.y-y)<8) return true;
  return false;
}
function moveAxis(mx,my){
  const nx=g.px+mx, ny=g.py+my;
  if(!blockedAt(nx,ny)){ g.px=nx; g.py=ny; }
}
function npcBlocked(x,y,n){
  const l=x-5, r=x+5, t=y-5, b=y-0.01;
  for(let ty=Math.floor(t/TS);ty<=Math.floor(b/TS);ty++) for(let tx=Math.floor(l/TS);tx<=Math.floor(r/TS);tx++){
    const tt=tileAt(tx,ty); if(SOLID.has(tt)||tt===T.WATER) return true;
  }
  if(Math.abs(g.px-x)<14&&Math.abs(g.py-y)<10) return true;
  for(const o of g.npcs) if(o!==n&&Math.abs(o.x-x)<12&&Math.abs(o.y-y)<8) return true;
  return false;
}

/* ===== dialog ===== */
function say(name,pages,onEnd){
  g.dialog={name:name||'',pages:pages.map(p=>typeof p==='function'?p(g):p),i:0,n:0,onEnd:onEnd||null,shown:-1};
  g.choice=null; g.mode='dialog'; el.dialog.hidden=false; el.dChoices.hidden=true; el.dNext.hidden=false;
  el.dWho.textContent=g.dialog.name; el.dWho.hidden=!g.dialog.name;
  el.dText.textContent='';
}
function advance(){
  const d=g.dialog; if(!d) return;
  const full=d.pages[d.i];
  if(d.n<full.length){ d.n=full.length; return; }
  blip();
  if(d.i<d.pages.length-1){ d.i++; d.n=0; return; }
  el.dialog.hidden=true; g.mode='play'; g.dialog=null;
  if(d.onEnd) d.onEnd();
}
function typeDialog(dt){
  const d=g.dialog; if(!d) return;
  const full=d.pages[d.i];
  d.n=Math.min(full.length,d.n+dt*60);
  const shown=Math.floor(d.n);
  if(shown!==d.shown){ d.shown=shown; el.dText.textContent=full.slice(0,shown); }
}

/* ===== TOWN LIFE: reputation, favors, jobs, clock ===== */
const DAY_SECS=480;                 /* one in-game day lasts 8 real minutes */
const MAX_QUESTS=3, SHIFTS_PER_DAY=2;
const peekMemDefault={fr:0,talks:0,done:0,gift:0,chat:0,rum:0,hint:0};
function npcMem(t,i){ const k=t.key+':'+i; return g.mem[k]||(g.mem[k]={fr:0,talks:0,done:0,gift:0,chat:0,rum:0,hint:0}); }
function peekMem(t,i){ return g.mem[t.key+':'+i]||peekMemDefault; }
function townRank(t){ return rankOf(g.rep[t.key]||0); }
function payMul(t){ return 1+0.1*townRank(t); }
function townByKey(k){ const a=k.split(','); return getTown(+a[0],+a[1]); }
function delInv(id){ if(!g.inv[id]) return; g.inv[id]--; if(g.inv[id]<=0) delete g.inv[id]; }
function addRep(t,n){
  if(!n) return;
  const old=townRank(t);
  g.rep[t.key]=(g.rep[t.key]||0)+n;
  const nr=townRank(t);
  if(nr>old){
    const bonus=nr*5; g.crumbs+=bonus; coin();
    let msg=t.name+': you are now a '+RANKS[nr].n+'! +'+bonus+' crumbs';
    if(nr===4){ addItem('medal'); msg+=' and an Honorary Medal'; }
    toast(msg,4600);
  } else toast('+'+n+' reputation in '+t.name,1800);
}
function advanceClock(h){
  g.clock+=h;
  while(g.clock>=24){ g.clock-=24; newDay(); }
}
function newDay(){
  g.day++;
  for(const q of g.quests.slice()) if(q.due<g.day) dropQuest(q,true);
  g.flags.dayPassed=true;
}
function dropQuest(q,expired){
  const i=g.quests.indexOf(q); if(i>=0) g.quests.splice(i,1);
  if(q.type==='deliver') delInv('parcel');
  if(q.type==='lost'&&q.found) delInv('trinket');
  if(expired){ const t=townByKey(q.tk); if(t) toast('A favor for '+t.npcs[q.gi].name+' ran out of time.',3200); }
}
function npcAsleep(n){ return !n.owl&&(g.clock>=22.5||g.clock<5.5); }
function fmtHour(h){ const hh=h%12===0?12:h%12; return hh+(h>=12&&h<24?' PM':' AM'); }
function workCount(key){ const w=g.work[key]; return w&&w.day===g.day?w.n:0; }
function workBump(key){ const w=g.work[key]; if(w&&w.day===g.day) w.n++; else g.work[key]={day:g.day,n:1}; }

/* ---- favors from townducks ---- */
function favorDef(t,i){
  const key=g.day+':'+i;
  if(t.favCache[key]!==undefined) return t.favCache[key];
  let def=null;
  const r=hash(t.rx*31+i,t.ry*17+g.day,900+i);
  if(r<0.6){
    const type=r<0.27?'fetch':r<0.42?'deliver':'lost';
    def={type};
    if(type==='fetch'){
      const pool=[...t.sells].filter(id=>ITEMS[id].price&&ITEMS[id].price<=24).sort();
      def.item=pool[Math.floor(hash(t.rx+i,t.ry,910+g.day)*pool.length)];
    } else if(type==='deliver'){
      let j=Math.floor(hash(t.rx+i,t.ry,920+g.day)*8); if(j>=i) j++;
      def.ti=j;
    } else {
      const sp=townSpots(t), k=sp[Math.floor(hash(t.rx+i,t.ry,930+g.day)*sp.length)];
      def.lost={x:k[0],y:k[1],name:LOST_NAMES[Math.floor(hash(t.rx,t.ry+i,940+g.day)*LOST_NAMES.length)]};
    }
  }
  t.favCache[key]=def;
  return def;
}
function favorReward(t,def){
  const base=def.type==='fetch'?ITEMS[def.item].price*1.5+4:def.type==='deliver'?7:8;
  return Math.max(3,Math.round(base*payMul(t)));
}
function favorAvail(t,i){
  const def=favorDef(t,i); if(!def) return null;
  if(peekMem(t,i).done===g.day) return null;
  if(g.quests.some(q=>q.tk===t.key&&q.gi===i)) return null;
  return def;
}
function boardFresh(t){ for(let i=0;i<t.npcs.length;i++) if(favorAvail(t,i)) return true; return false; }
function questReady(q){ return q.type==='fetch'?(g.inv[q.item]||0)>0:q.type==='lost'?q.found:false; }
function shopSelling(t,id){ return t.buildings.find(b=>STOCK[b.kind].includes(id)); }
function npcMark(n){
  if(n.special) return specialMark(n);
  if(n.talking) return null;
  const t=n.town,i=n.idx;
  if(g.quests.some(q=>(q.tk===t.key&&q.gi===i&&questReady(q))||(q.type==='deliver'&&q.tk===t.key&&q.ti===i))) return {ch:'?',col:'#86e29a'};
  if(favorAvail(t,i)) return {ch:'!',col:'#ffd166'};
  return null;
}
function shortFavor(t,i,def){
  const nm=t.npcs[i].name;
  if(def.type==='fetch') return nm+': bring '+ITEMS[def.item].name;
  if(def.type==='deliver') return nm+': deliver a parcel to '+t.npcs[def.ti].name;
  return nm+': find a lost '+def.lost.name;
}
function questText(q){
  const t=townByKey(q.tk), giver=t.npcs[q.gi];
  if(q.type==='fetch') return 'Bring '+giver.name+' '+ITEMS[q.item].name+'.';
  if(q.type==='deliver') return 'Deliver the parcel to '+t.npcs[q.ti].name+'.';
  return q.found?'Return the '+q.lost.name+' to '+giver.name+'.':'Find '+giver.name+"'s lost "+q.lost.name+' (look for a sparkle).';
}
function acceptFavor(t,i,def){
  const q={id:Date.now()+':'+i,tk:t.key,gi:i,type:def.type,item:def.item||null,ti:def.ti===undefined?-1:def.ti,lost:def.lost||null,found:false,reward:favorReward(t,def),due:g.day+1};
  g.quests.push(q);
  if(q.type==='deliver') addItem('parcel');
  g.flags.favor=true; coin();
  return q;
}
function favorPitch(t,i,def){
  const rw=favorReward(t,def), late='No rush, but I need it done by the end of tomorrow.';
  if(def.type==='fetch'){
    const sh=shopSelling(t,def.item);
    return ['Oh, you look capable! Could you fetch me '+ITEMS[def.item].name+'?',(sh?'They sell it at '+sh.name+'.':'Somebody around here must sell it.')+' I will pay you '+rw+' crumbs for it. '+late];
  }
  if(def.type==='deliver'){
    const tg=t.npcs[def.ti];
    return ['I have a parcel that needs to reach '+tg.name+'. They are somewhere around town.','Mind it carefully. '+tg.name+' will thank you for the trouble, I promise. '+late];
  }
  return ['I lost my '+def.lost.name+' somewhere in town. I keep looking and looking.','Look for a little sparkle in the grass. Bring it back and I will give you '+rw+' crumbs. '+late];
}
function giftFav(n){
  const ids=Object.keys(ITEMS).filter(id=>ITEMS[id].price&&!ITEMS[id].nogift).sort();
  return ids[Math.floor(hash(n.town.rx+n.idx,n.town.ry,970)*ids.length)];
}

/* ---- talking ---- */

function talkTo(n){
  if(n.special){ specialTalk(n); return; }
  const t=n.town, i=n.idx;
  n.dir=OPP[g.dir]; n.moving=false; n.talking=true; g.flags.talked=true;
  const done=()=>{ n.talking=false; n.t=1; };
  const dq=g.quests.find(q=>q.type==='deliver'&&q.tk===t.key&&q.ti===i);
  if(dq){ completeDelivery(dq,n,done); return; }
  const tq=g.quests.find(q=>q.tk===t.key&&q.gi===i);
  if(tq&&questReady(tq)){ turnIn(tq,n,done); return; }
  npcMenu(n,done);
}
function completeDelivery(q,n,done){
  const t=n.town, giver=t.npcs[q.gi];
  dropQuest(q,false);
  g.crumbs+=q.reward+luckBonus(); coin();
  npcMem(t,q.gi).fr+=3; npcMem(t,n.idx).fr+=1;
  say(n.name,['A parcel for me? Oh, wonderful! From '+giver.name+', of course.','Here, for your trouble: '+q.reward+' crumbs.'],()=>{ addRep(t,3); done(); });
}
function turnIn(q,n,done){
  const t=n.town;
  if(q.type==='fetch') delInv(q.item);
  dropQuest(q,false);
  g.crumbs+=q.reward+luckBonus(); coin();
  npcMem(t,n.idx).fr+=4; npcMem(t,n.idx).done=g.day;
  const pages=q.type==='fetch'
    ?['Is that... '+ITEMS[q.item].name+'? Perfect! You are a lifesaver.','Here are '+q.reward+' crumbs, as promised.']
    :['My '+q.lost.name+'! Where did you find it? Never mind, I do not care. Thank you!','Here are '+q.reward+' crumbs, with my gratitude.'];
  say(n.name,pages,()=>{ addRep(t,q.type==='fetch'?4:5); done(); });
}
function npcMenu(n,done){
  const t=n.town,i=n.idx, opts=[], fns=[];
  const add=(l,f)=>{ opts.push(l); fns.push(f); };
  add('Chat',()=>chat(n,done));
  const aq=g.quests.find(q=>q.tk===t.key&&q.gi===i), def=favorAvail(t,i);
  if(aq) add('About that favor...',()=>say(n.name,[aq.type==='fetch'?'Still waiting on '+ITEMS[aq.item].name+'. '+(shopSelling(t,aq.item)?shopSelling(t,aq.item).name+' has it.':''):aq.type==='lost'?'Any luck with my '+aq.lost.name+'? Look for a sparkle in the grass.':'Did you deliver that parcel yet?'],done));
  else if(def) add('Need a hand?',()=>offerFavor(n,def,done));
  add('Give a gift',()=>giftMenu(n,done));
  add('Goodbye',done);
  const gr=RANK_GREET[townRank(t)];
  choose(n.name,gr[(i+g.day)%gr.length],opts,k=>fns[k](),opts.length-1);
}
function chat(n,done){
  const t=n.town, m=npcMem(t,n.idx), p=PERSONAS[n.persona];
  if(m.chat!==g.day){ m.chat=g.day; m.fr+=1; }
  const idx=m.talks===0?0:1+((m.talks-1)%(p.length-1));
  m.talks++;
  const pages=p[idx].map(s=>typeof s==='function'?s(g,n):fmt(s,t));
  if(m.fr>=2&&!m.hint){ m.hint=1; pages.push('Between us? I would love '+ITEMS[giftFav(n)].name+' someday. Just saying.'); }
  if(m.fr>=4&&!m.rum){ m.rum=1; g.rumors.push(t.key+':'+n.idx); pages.push(RUMORS[n.persona%RUMORS.length]); toast('Rumor added to your journal.',2400); }
  say(n.name,pages,done);
}
function offerFavor(n,def,done){
  const t=n.town;
  if(g.quests.length>=MAX_QUESTS){ say(n.name,['Oh, you look busy already. Come see me when you have a free moment.'],done); return; }
  say(n.name,favorPitch(t,n.idx,def),()=>{
    choose(n.name,'Will you help?',['Sure, I will help!','Not right now'],k=>{
      if(k===0){ acceptFavor(t,n.idx,def); toast('Favor accepted. Details are in your journal (J).',3000); say(n.name,['Thank you so much! I knew I could count on you.'],done); }
      else say(n.name,['No worries. Maybe tomorrow.'],done);
    },1);
  });
}
function giftMenu(n,done){
  const ids=Object.keys(g.inv).filter(id=>!ITEMS[id].nogift).slice(0,8);
  if(!ids.length){ say(n.name,['You do not have anything to give right now. That is okay.'],done); return; }
  const labels=ids.map(id=>ITEMS[id].name+(g.inv[id]>1?' x'+g.inv[id]:'')).concat(['Never mind']);
  choose(n.name,'What would you like to give?',labels,k=>{
    if(k>=ids.length){ done(); return; }
    giveGift(n,ids[k],done);
  },labels.length-1);
}
function giveGift(n,id,done){
  const t=n.town, m=npcMem(t,n.idx);
  delInv(id);
  const it=ITEMS[id];
  if(it.use==='equip'&&!g.inv[id]&&g.worn[it.slot]===it.wear) g.worn[it.slot]=null;
  const liked=id===giftFav(n), price=it.price||3;
  let amt=liked?3:(price>=8?2:1), pages;
  if(m.gift===g.day){ amt=0; pages=['You already spoiled me today. Thank you, though!']; }
  else pages=liked?['MY FAVORITE! How did you know?!','I will treasure this. Thank you, truly.']:price>=8?['What a lovely gift! Thank you so much!']:['Aw, thank you! That is sweet of you.'];
  m.gift=g.day;
  if(amt) m.fr+=amt;
  g.flags.gifted=true; coin();
  say(n.name,pages,()=>{ if(amt) addRep(t,amt); done(); });
}

/* ---- the notice board ---- */
const ODD_JOBS=['Sweep the Plaza','Water the Flowerbeds','Hang the Bunting','Polish the Lamps','Stack the Crates'];
function useBoard(t){
  const avail=[];
  t.npcs.forEach((n,i)=>{ const d=favorAvail(t,i); if(d) avail.push({i,d}); });
  const oddKey='odd:'+t.key, left=SHIFTS_PER_DAY-workCount(oddKey);
  const opts=[], fns=[];
  const add=(l,f)=>{ opts.push(l); fns.push(f); };
  add('Posted favors ('+avail.length+')',()=>{
    if(!avail.length){ say('Notice Board',['Nothing new is posted. Check back tomorrow, or chat with the townducks.']); return; }
    if(g.quests.length>=MAX_QUESTS){ say('Notice Board',['Your hands are full. Finish a favor first.']); return; }
    const lab=avail.map(a=>shortFavor(t,a.i,a.d)+' (+'+favorReward(t,a.d)+')').concat(['Back']);
    choose('Notice Board','Pick a favor to take on:',lab,k=>{
      if(k>=avail.length) return;
      const a=avail[k]; acceptFavor(t,a.i,a.d);
      toast('Favor accepted. Details are in your journal (J).',3000);
    },lab.length-1);
  });
  { const te=eventFor(t,g.day);
    add('Village calendar'+(te&&g.clock<te.h+te.dur?'  (today: '+te.title+')':''),()=>openCalendar(t));
    if(te&&evLive(te)&&!g.ev[evKey(t,g.day)]) add('Join: '+te.title,()=>attendEvent(t,te)); }
  const title=ODD_JOBS[(g.day+t.rx+t.ry)%ODD_JOBS.length];
  add('Odd job: '+title+' ('+Math.max(0,left)+' left today)',()=>{
    if(left<=0){ say('Notice Board',['The odd jobs are all taken for today. Come back tomorrow.']); return; }
    if(g.clock<6||g.clock>=21){ say('Notice Board',['Too dark to work. Odd jobs run from 6 AM to 9 PM.']); return; }
    startMini({title:title,say:'Press Z when the marker is in the green zone.',onDone:S=>{
      const pay=Math.max(3,Math.round((2+S*0.7)*payMul(t)));
      g.crumbs+=pay+luckBonus(); coin(); workBump(oddKey); advanceClock(1);
      toast('Odd job done: +'+pay+' crumbs',2400); g.flags.worked=true;
      if(S>=6) addRep(t,S>=9?2:1);
    }});
  });
  add('Check my standing',()=>{
    const pts=g.rep[t.key]||0, r=townRank(t), nx=RANKS[r+1];
    say('Notice Board',['In '+t.name+' you are a '+RANKS[r].n+' ('+pts+' reputation).'+(RANKS[r].disc?' Shops give you '+Math.round(RANKS[r].disc*100)+'% off.':''),nx?'Next rank: '+nx.n+' at '+nx.at+'. Favors, gifts and honest work all count.':'You are as respected as a duck can be here.']);
  });
  add('Leave',()=>{});
  choose('Notice Board','TOWN NOTICES  -  '+t.name,opts,k=>fns[k](),opts.length-1);
}

/* ---- shop counter: browse, work a shift, chat ---- */
function wkey(b){ return 'shop:'+b.x+','+b.y; }
function openCounter(){
  const b=g.shop.b, t=g.shop.town, left=SHIFTS_PER_DAY-workCount(wkey(b));
  const opts=['Browse the shelves','Ask for work ('+Math.max(0,left)+' shift'+(left===1?'':'s')+' left today)','Chat','Leave'];
  const gr=RANK_GREET[townRank(t)];
  choose(b.keeper.name,gr[(b.idx+g.day)%gr.length]+' What can I do for you?',opts,k=>{
    if(k===0) openShop(); else if(k===1) askWork(b,t); else if(k===2) chatKeeper(b,t);
  },3);
}
const JOBS={
  bakery:['Knead the Dough','Pound the dough as the marker crosses the zone.'],
  market:['Sort the Produce','Pick the ripest ones at the right moment.'],
  supply:['Polish the Lenses','One careful buff at the right moment.'],
  curio:['Dust the Curios','Gently. Gently. Now!'],
  cafe:['Pour the Tea','Stop pouring right in the zone.'],
  florist:['Arrange the Bouquets','Snip the stems at the perfect moment.'],
  books:['Shelve the Books','Slot each book in as the marker passes.'],
  tailor:['Stitch the Hems','Pull the thread right in the zone.'],
  toys:['Wind the Toys','Stop winding at just the right click.']
};
function askWork(b,t){
  const left=SHIFTS_PER_DAY-workCount(wkey(b)), close=HOURS[b.kind][1];
  if(left<=0){ say(b.keeper.name,['You have been a big help today. I do not need anyone else until tomorrow.']); return; }
  if(close-g.clock<1.6){ say(b.keeper.name,['We are almost closing up. Come help me tomorrow?']); return; }
  const j=JOBS[b.kind];
  say(b.keeper.name,['Looking for work? I could use a hand.','One shift is about an hour and a half. Do it well and you will earn a few crumbs and some goodwill.'],()=>{
    startMini({title:j[0],say:j[1],onDone:S=>{
      const pay=Math.max(3,Math.round((2+S*0.85)*payMul(t)));
      g.crumbs+=pay+luckBonus(); coin(); workBump(wkey(b)); advanceClock(1.5); g.flags.worked=true;
      const pages=S>=9?['Flawless. I could hire you full time!']:S>=6?['Nice work! Here is your pay.']:S>=3?['Not bad. A little rough, but you tried.']:['Well. You showed up. Here is something for the effort.'];
      pages.push('That is '+pay+' crumbs.');
      say(b.keeper.name,pages,()=>{ if(S>=5) addRep(t,S>=10?2:1); });
    }});
  });
}
function chatKeeper(b,t){
  const r=townRank(t);
  const extra=r>=4?'You are the best thing to happen to this town since the fountain.':r>=3?'You are practically family now.':r>=1?'Nice to see a regular face.':'First time in here? Take your time.';
  say(b.keeper.name,[pick(GREET[b.kind]),extra,'Open '+fmtHour(HOURS[b.kind][0])+' to '+fmtHour(HOURS[b.kind][1])+', every day.']);
}

/* ---- the timing mini-game used for all jobs ---- */
function startMini(o){
  g.mini={o:o,round:0,rounds:5,pos:0,dir:1,res:[],stage:'run',wait:0,zc:0.5,zw:0.28,spd:0.9,last:''};
  miniRound();
  el.mini.hidden=false; g.mode='mini';
  el.miTitle.textContent=o.title; el.miSay.textContent=o.say;
  renderMini();
}
function miniRound(){
  const m=g.mini;
  m.zw=Math.max(0.12,0.3-m.round*0.035); m.zc=0.2+Math.random()*0.6; m.spd=0.85+m.round*0.22; m.pos=0; m.dir=1; m.stage='run';
}
function updateMini(dt){
  const m=g.mini; if(!m) return;
  if(m.stage==='run'){ m.pos+=m.dir*m.spd*dt; if(m.pos>=1){ m.pos=1; m.dir=-1; } if(m.pos<=0){ m.pos=0; m.dir=1; } }
  else if(m.stage==='hold'){ m.wait-=dt; if(m.wait<=0){ m.round++; if(m.round>=m.rounds) m.stage='done'; else miniRound(); } }
  renderMini();
}
function miniScore(){ return g.mini.res.reduce((a,b)=>a+b,0); }
function miniPress(){
  const m=g.mini; if(!m) return;
  if(m.stage==='run'){
    const d=Math.abs(m.pos-m.zc), r=d<=m.zw*0.2?2:d<=m.zw/2?1:0;
    m.res.push(r); m.stage='hold'; m.wait=0.5; m.last=r===2?'Perfect!':r===1?'Good':'Miss';
    if(r) coin(); else tone('square',300,180,0.12,0.05);
  } else if(m.stage==='done'){
    const S=miniScore(), o=m.o;
    g.mini=null; el.mini.hidden=true; g.mode='play'; blip();
    o.onDone(S);
  }
}
function renderMini(){
  const m=g.mini; if(!m) return;
  el.miZone.style.left=((m.zc-m.zw/2)*100)+'%'; el.miZone.style.width=(m.zw*100)+'%';
  el.miMark.style.left=(m.pos*100)+'%';
  el.miMark.style.opacity=m.stage==='run'?1:0.5;
  const dots=el.miDots;
  if(dots.children.length!==m.rounds){ dots.innerHTML=''; for(let i=0;i<m.rounds;i++) dots.appendChild(document.createElement('span')); }
  for(let i=0;i<m.rounds;i++){
    const r=m.res[i]; dots.children[i].className=r===2?'p':r===1?'g':r===0?'m':'';
  }
  el.miPay.textContent=miniScore()+' / '+(m.rounds*2);
  el.miMsg.textContent=m.stage==='done'?'Shift complete! Press Z to finish.':m.stage==='hold'?m.last:'Round '+(m.round+1)+' of '+m.rounds;
}

/* ---- choices inside the dialog box ---- */
function choose(who,text,opts,cb,cancel){
  g.choice={opts:opts,sel:0,cb:cb,cancel:cancel===undefined?opts.length-1:cancel};
  g.dialog=null; g.mode='choice';
  el.dialog.hidden=false; el.dWho.textContent=who||''; el.dWho.hidden=!who;
  el.dText.textContent=text; el.dNext.hidden=true;
  renderChoices();
}
function renderChoices(){
  const c=g.choice; if(!c) return;
  el.dChoices.hidden=false; el.dChoices.innerHTML='';
  c.opts.forEach((o,i)=>{
    const li=document.createElement('li'); li.textContent=o;
    if(i===c.sel) li.className='sel';
    li.addEventListener('click',()=>{ if(g.mode==='choice'){ if(c.sel===i) pickChoice(i); else { c.sel=i; blip(); renderChoices(); } } });
    el.dChoices.appendChild(li);
  });
}
function moveChoice(d){ const c=g.choice; c.sel=(c.sel+d+c.opts.length)%c.opts.length; blip(); renderChoices(); }
function pickChoice(i){
  const c=g.choice; if(!c) return;
  el.dialog.hidden=true; el.dChoices.hidden=true; el.dNext.hidden=false;
  g.choice=null; g.mode='play'; blip();
  c.cb(i);
}

/* ---- journal ---- */
function openJournal(){ g.mode='journal'; el.jr.hidden=false; renderJournal(); blip(); }
function closeJournal(){ g.mode='play'; el.jr.hidden=true; blip(); }
function renderJournal(){
  const root=el.jrBody; root.innerHTML='';
  const sec=(title)=>{ const h=document.createElement('h3'); h.textContent=title; root.appendChild(h); };
  const line=(txt,cls)=>{ const p=document.createElement('p'); p.textContent=txt; if(cls) p.className=cls; root.appendChild(p); return p; };
  line('Day '+g.day+'  -  '+phaseName(g.clock)+', '+clockStr(),'jdim');
  sec('Active favors ('+g.quests.length+'/'+MAX_QUESTS+')');
  if(!g.quests.length) line('None. Look for a ! over a townduck, or read the notice board in a town square.','jdim');
  for(const q of g.quests){
    const t=townByKey(q.tk);
    line(questText(q)+'  ['+t.name+']  Reward: '+q.reward+' crumbs. Due by the end of day '+q.due+'.');
  }
  sec('Reputation');
  const towns=[...g.towns.values()];
  if(!towns.length) line('You have not found a town yet.','jdim');
  for(const tw of towns){
    const t=townByKey(tw.key), pts=g.rep[tw.key]||0, r=rankOf(pts), nx=RANKS[r+1];
    const row=document.createElement('div'); row.className='jrow';
    const nm=document.createElement('div'); nm.innerHTML='<b></b> <span class="jdim"></span>';
    nm.firstChild.textContent=t.name; nm.lastChild.textContent=' '+t.style.label;
    const rk=document.createElement('div'); rk.textContent=RANKS[r].n+(RANKS[r].disc?'  ('+Math.round(RANKS[r].disc*100)+'% off)':'');
    const bar=document.createElement('div'); bar.className='jbar'; const fill=document.createElement('i');
    const lo=RANKS[r].at, hi=nx?nx.at:RANKS[r].at+1;
    fill.style.width=(nx?Math.min(100,(pts-lo)/(hi-lo)*100):100)+'%'; bar.appendChild(fill);
    const pt=document.createElement('div'); pt.className='jdim'; pt.textContent=pts+(nx?' / '+nx.at+' to '+nx.n:' (max)');
    row.append(nm,rk,bar,pt); root.appendChild(row);
  }
  sec('Case notes');
  line('Dark trees studied: '+g.clues);
  line('Rumors heard: '+g.rumors.length+'   Tiles explored: '+g.explored.toLocaleString());
  line('Honorary medals: '+(g.inv.medal||0));
  journalExtra(sec,line);
}

/* ===== world interaction ===== */
function addItem(id,n){ g.inv[id]=(g.inv[id]||0)+(n||1); }
const CRATE_LINES=['Supplies, mostly. One crate squeaks. You decide not to ask.','A crate stamped FRAGILE. In very small letters: ducks.','It smells of apples and adventure.'];
const HAY_LINES=['A hay bale. You consider napping on it. You do not.','Prickly and golden. A mouse looks out at you, then retreats.'];
const STALL_LINES=['The stall is stacked with good things, but the stall-keeper only sells at the shops. Shop rules.','Bright awnings, shiny trinkets. You window-shop with great enthusiasm.','A hand-written sign: NO HAGGLING. Below it, in different handwriting: HAGGLING WELCOME.'];
const FIRE_LINES=['A warm bonfire. The sparks drift up like tiny stars.','You warm your feet. Pure bliss.'];
const NIGHT_HOUSE_LINES=['Lights out. Somebody is snoring, and somebody else is pretending not to.','Nobody answers. Quacking at doors at night is considered rude.'];
function benchMenu(){
  const night=g.clock>=19||g.clock<5;
  const opts=['Rest for an hour'];
  if(night) opts.push('Nap until morning');
  opts.push('Not now');
  choose('',night?'A cozy bench. The night is quiet and smells of lamp oil.':'A sturdy bench. Perfect for sitting and thinking.',opts,k=>{
    if(k===0){ fade(0.5); advanceClock(1); toast('You rest for a bit. It is '+clockStr()+'.',2400); }
    else if(night&&k===1){ const need=((6.5-g.clock)+24)%24; advanceClock(need); fade(1.2); toast('You wake up refreshed. It is '+clockStr()+'.',2600); }
  },opts.length-1);
}
function wish(){
  if(g.crumbs>=1){ g.crumbs--; coin(); say('',[pick(WISH_LINES)]); }
  else say('',['You pat your empty pockets. Not even a crumb to wish with.']);
}
function interact(){
  const tg=g.target;
  quack();
  if(!tg){ toast('Quack!',900); return; }
  if(tg.k==='npc'){ talkTo(tg.n); return; }
  if(tg.k==='counter'){ openCounter(); return; }
  if(tg.k==='lost'){ tg.q.found=true; addItem('trinket'); coin(); toast('You found the '+tg.q.lost.name+'! Bring it back.',2600); return; }
  const t=tg.t, tx=tg.tx, ty=tg.ty;
  switch(t){
    case T.DOOR: {
      const b=buildingAt(tx,ty);
      if(shopOpen(b)) enterShop(b);
      else say('',['The door is locked. A sign says: Open '+fmtHour(HOURS[b.kind][0])+' to '+fmtHour(HOURS[b.kind][1])+'.']);
      break;
    }
    case T.HOUSEDOOR: say('',[pick(g.clock>=20||g.clock<6?NIGHT_HOUSE_LINES:HOUSE_LINES)]); break;
    case T.DARK: inspectDark(tx,ty); break;
    case T.TREE: say('',[pick(TREE_LINES)]); break;
    case T.ROCK: say('',[pick(ROCK_LINES)]); break;
    case T.FLOWER: say('',[pick(FLOWER_LINES)]); break;
    case T.BUSH: say('',[pick(BUSH_LINES)]); break;
    case T.STUMP: say('',[pick(STUMP_LINES)]); break;
    case T.LAMP: say('',[pick(LAMP_LINES)]); break;
    case T.MUSH: { const st=styleAt(tx,ty); say('',[pick(darkAt(tx,ty)>0.3?MUSH_DARK_LINES:(st&&st.id==='grove'?['It glows a soft, friendly teal. This one does not mind being looked at.','The whole grove hums, but gently. Like a sleepy cat.']:MUSH_LINES))]); break; }
    case T.SIGN:
      g.flags.sign=true;
      say('Wooden Sign',['PUDDLEWICK  >>  about 90 waddles east.','Underneath, in smaller scratchy letters: Mind the trees. Some of them look at you.']);
      break;
    case T.FOUNTAIN: case T.WELL: wish(); break;
    case T.STATUE: { if(inK(tx,ty)){ kStatue(tx,ty); break; } const tw=townAtTile(tx,ty); say('',['A golden duck statue. The plaque reads: "To the first duck who stayed. '+(tw?tw.name:'')+'."']); break; }
    case T.FIRE: say('',[pick(FIRE_LINES)]); break;
    case T.BENCH: benchMenu(); break;
    case T.CRATE: say('',[pick(CRATE_LINES)]); break;
    case T.HAY: say('',[pick(HAY_LINES)]); break;
    case T.STALL: say('',[pick(STALL_LINES)]); break;
    case T.BOARD: { const tw=townAtTile(tx,ty); if(tw) useBoard(tw); break; }
    case T.CRUMBS: {
      const n=1+Math.floor(hash(tx,ty,15)*3);
      g.crumbs+=n+luckBonus(); taken.add(tx+','+ty); tileCache.delete(tkey(tx,ty)); coin();
      toast('+'+n+' crumb'+(n>1?'s':''),1400);
      break;
    }
    default: if(t>=28) kingdomInteract(t,tx,ty); break;
  }
}
function inspectDark(tx,ty){
  const key=tx+','+ty, first=!g.inspected.has(key), pages=[];
  if(first){
    g.inspected.add(key); g.clues++; g.flags.dark=true;
    pages.push(DARK_LINES[(g.clues-1)%DARK_LINES.length]);
    if(isHeld('glass')) pages.push(GLASS_LINES[(g.clues-1)%GLASS_LINES.length]);
    if(g.clues===1) pages.push('You make a mental note. Case file: Strange Trees. Entry one.');
    if(g.clues===4) pages.push('Four now. They all hum the same low note. Somewhere below, something hums back.');
    if(g.clues===8) pages.push('Eight trees. You are almost sure they are arranged. Almost.');
  } else pages.push('You have already studied this one. The hum has not stopped.');
  say('Detective Duck',pages);
}
/* ===== shops ===== */
function fade(t){ g.fadeIn=t; g.fadeMax=t; }
function enterShop(b){
  if(!b) return;
  g.saved={x:g.px,y:g.py,dir:g.dir};
  g.shop={b:b,town:townAtTile(b.doorX,b.doorY)};
  g.scene='shop'; g.px=5.5*TS; g.py=6.2*TS; g.dir='up'; fade(0.4); g.flags.shop=true; g.target=null;
  quack();
  toast(b.keeper.name+': "'+pick(GREET[b.kind])+'"',3000);
}
function exitShop(){
  const b=g.shop.b;
  g.scene='world'; g.px=(b.doorX+0.5)*TS; g.py=(b.doorY+1.7)*TS; g.dir='down'; g.shop=null; fade(0.4);
  g.camX=g.px; g.camY=g.py;
  blip();
}
function openShop(){
  g.mode='shop'; g.shopSel=0; el.shop.hidden=false; el.shMsg.innerHTML='&nbsp;';
  const b=g.shop.b, r=townRank(g.shop.town);
  el.shName.textContent=b.name;
  el.shSay.textContent=b.keeper.name+', shopkeeper'+(RANKS[r].disc?'  -  '+RANKS[r].n+': '+Math.round(RANKS[r].disc*100)+'% off':'');
  renderShop();
}
function closeShop(){ g.mode='play'; el.shop.hidden=true; blip(); }
function iconCanvas(id){
  const c=document.createElement('canvas'); c.width=48; c.height=48;
  drawIcon(c.getContext('2d'),id,48); return c;
}
function renderShop(){
  const b=g.shop.b, town=g.shop.town, stock=shopStock(b,town);
  el.shCrumbs.textContent=g.crumbs;
  el.shList.innerHTML='';
  stock.forEach((id,i)=>{
    const it=ITEMS[id], price=itemPrice(id,town);
    const li=document.createElement('li');
    li.className='row'+(i===g.shopSel?' sel':'')+(g.crumbs<price?' poor':'');
    const ic=iconCanvas(id);
    const mid=document.createElement('div');
    const own=g.inv[id]?' (you have '+g.inv[id]+')':'';
    const sp=(SPECIAL[b.kind]===id)?'  [trusted customers only]':'';
    mid.innerHTML='<div class="nm"></div><div class="ds"></div>';
    mid.firstChild.textContent=it.name+own+sp; mid.lastChild.textContent=it.desc;
    const pr=document.createElement('div'); pr.className='price'; pr.textContent=price+' crumbs';
    li.append(ic,mid,pr);
    li.addEventListener('click',()=>{ if(g.shopSel===i) buy(); else { g.shopSel=i; blip(); renderShop(); } });
    el.shList.appendChild(li);
  });
}
function shopMove(d){
  const n=shopStock(g.shop.b,g.shop.town).length;
  g.shopSel=(g.shopSel+d+n)%n; blip(); renderShop();
}
function buy(){
  const id=shopStock(g.shop.b,g.shop.town)[g.shopSel], it=ITEMS[id], price=itemPrice(id,g.shop.town);
  if(g.crumbs<price){ el.shMsg.style.color='var(--bad)'; el.shMsg.textContent='Not enough crumbs for the '+it.name+'.'; tone('square',300,180,0.15,0.06); return; }
  g.crumbs-=price; addItem(id); g.flags.bought=true; coin();
  el.shMsg.style.color='var(--good)';
  el.shMsg.textContent='Bought '+it.name+'.'+(it.use==='equip'?' Wear it from your inventory.':'');
  renderShop();
}
/* ===== inventory ===== */
function invIds(){ return Object.keys(g.inv); }
function openInv(){ g.mode='inv'; g.invSel=0; el.inv.hidden=false; el.dNote.textContent=''; renderInv(); blip(); }
function closeInv(){ g.mode='play'; el.inv.hidden=true; blip(); }
function renderInv(){
  const ids=invIds();
  el.slots.innerHTML='';
  for(let i=0;i<16;i++){
    const sl=document.createElement('div');
    sl.className='slot'+(i===g.invSel?' sel':'');
    if(ids[i]){
      sl.appendChild(iconCanvas(ids[i]));
      if(g.inv[ids[i]]>1){ const ct=document.createElement('span'); ct.className='ct'; ct.textContent=g.inv[ids[i]]; sl.appendChild(ct); }
    }
    sl.addEventListener('click',()=>{ if(g.invSel===i&&ids[i]) useItem(ids[i]); else { g.invSel=i; el.dNote.textContent=''; renderInv(); } });
    el.slots.appendChild(sl);
  }
  const id=ids[g.invSel];
  if(id){
    const it=ITEMS[id], isW=it.use==='equip'&&g.worn[it.slot]===it.wear;
    el.dName.textContent=it.name+(isW?' (worn)':''); el.dDesc.textContent=it.desc; el.dUse.hidden=false;
    el.dUse.textContent=it.use==='map'?'Unfold (Z)':it.use==='eat'?'Eat (Z)':it.use==='equip'?(isW?'Take off (Z)':'Wear (Z)'):'Examine (Z)';
  }
  else { el.dName.textContent='Empty slot'; el.dDesc.textContent='Nothing here yet. Shops and the forest floor are good places to look.'; el.dUse.hidden=true; }
  const towns=[...g.towns.values()].map(t=>t.name+' ('+RANKS[rankOf(g.rep[t.key]||0)].n+')').join(', ')||'none yet';
  el.notes.innerHTML='<b>CASE NOTES</b><br>Dark trees studied: '+g.clues+'<br>Towns found: <span id="nTowns"></span><br>Tiles explored: '+g.explored.toLocaleString()+'<br>Crumbs: '+g.crumbs;
  $('nTowns').textContent=towns;
}
function useItem(id){
  const it=ITEMS[id];
  if(it.use==='map'){ closeInv(); openMap(); return; }
  if(it.use==='eat'){
    delInv(id);
    if(it.boost){ g.boost=Math.min(150,g.boost+it.boost); }
    el.dNote.textContent=it.quip+(it.boost?' You feel zippy for a while.':''); quack(); renderInv(); return;
  }
  if(it.use==='equip'){
    const on=g.worn[it.slot]===it.wear;
    g.worn[it.slot]=on?null:it.wear;
    el.dNote.textContent=on?'You take it off.':id==='hat'?'You tip the hat. Instantly more mysterious.':'Looking sharp.';
    blip(); renderInv(); return;
  }
  el.dNote.textContent=it.note||'Nothing to do with it yet.'; blip();
}
/* ===== map ===== */
function openMap(){
  g.mode='map'; g.flags.map=true; el.mapview.hidden=false; sizeMap(); mapHomeUi('');
  centerMap(); m.z=Math.max(m.z,2); blip();
}
function closeMap(){ g.mode='play'; el.mapview.hidden=true; blip(); }
function homePos(){ const h=g.story&&g.story.x&&g.story.x.home; return h?{x:h.x,y:h.y,custom:true}:{x:0.5,y:0.5}; }
function worldPos(){ const p=g.scene==='world'?{x:g.px,y:g.py}:g.saved; return {x:p.x/TS,y:p.y/TS}; }
function centerMap(){ const p=worldPos(); m.cx=p.x; m.cy=p.y; }
function zoomMap(f,mx,my){
  const nz=Math.max(0.25,Math.min(24,m.z*f));
  if(mx===undefined){ m.z=nz; return; }
  const wx=m.cx+(mx-mapW/2)/m.z, wy=m.cy+(my-mapH/2)/m.z;
  m.z=nz; m.cx=wx-(mx-mapW/2)/nz; m.cy=wy-(my-mapH/2)/nz;
}
function pinAt(c,x,y,col,label,z){
  c.fillStyle=col; c.beginPath(); c.moveTo(x,y-8); c.lineTo(x+6,y); c.lineTo(x,y+8); c.lineTo(x-6,y); c.closePath(); c.fill();
  c.strokeStyle='#0d1613'; c.lineWidth=2; c.stroke();
  if(label){ c.font='600 13px ui-monospace,"Courier New",monospace'; c.textAlign='left'; c.textBaseline='middle'; c.lineWidth=3; c.strokeStyle='#0d1613'; c.strokeText(label,x+10,y+1); c.fillStyle='#eaf2dc'; c.fillText(label,x+10,y+1); }
}
let lastRead='';
function drawMap(){
  const c=mctx, W=mapW, H=mapH, z=m.z;
  c.setTransform(dpr,0,0,dpr,0,0);
  c.fillStyle='#0d1613'; c.fillRect(0,0,W,H);
  const tx0=m.cx-W/2/z, ty0=m.cy-H/2/z, tx1=tx0+W/z, ty1=ty0+H/z;
  let step=1; for(const s of [1,2,4,8,16,32,64,128,256,512,1024,2048,4096,8192]){ step=s; if(s*z>=56) break; }
  c.strokeStyle='rgba(255,255,255,0.06)'; c.lineWidth=1; c.beginPath();
  for(let gx=Math.ceil(tx0/step)*step;gx<tx1;gx+=step){ const sx=Math.round((gx-tx0)*z)+0.5; c.moveTo(sx,0); c.lineTo(sx,H); }
  for(let gy=Math.ceil(ty0/step)*step;gy<ty1;gy+=step){ const sy=Math.round((gy-ty0)*z)+0.5; c.moveTo(0,sy); c.lineTo(W,sy); }
  c.stroke();
  c.imageSmoothingEnabled=z<1;
  const cx0=Math.floor(tx0/CH), cx1=Math.floor(tx1/CH), cy0=Math.floor(ty0/CH), cy1=Math.floor(ty1/CH);
  for(let cyk=cy0;cyk<=cy1;cyk++) for(let cxk=cx0;cxk<=cx1;cxk++){
    const ch=chunks.get(cxk+','+cyk); if(!ch) continue;
    if(!ch.cv) buildChunk(ch);
    const sx=Math.floor((cxk*CH-tx0)*z), sy=Math.floor((cyk*CH-ty0)*z);
    c.drawImage(ch.cv,sx,sy,Math.ceil(((cxk+1)*CH-tx0)*z)-sx,Math.ceil(((cyk+1)*CH-ty0)*z)-sy);
  }
  { const hm=homePos();
    if(hm.custom) pinAt(c,(0.5-tx0)*z,(0.5-ty0)*z,'#9fb0a0','First pond',z);
    pinAt(c,(hm.x-tx0)*z,(hm.y-ty0)*z,'#eaf2dc','Home',z);
    const sx=W/2, sy=H/2; c.strokeStyle='rgba(234,242,220,0.75)'; c.lineWidth=2; c.beginPath(); c.moveTo(sx-9,sy); c.lineTo(sx+9,sy); c.moveTo(sx,sy-9); c.lineTo(sx,sy+9); c.stroke(); }
  for(const t of g.towns.values()) pinAt(c,(t.x-tx0)*z,(t.y-ty0)*z,'#ff9d2e',t.name,z);
  const p=worldPos(), mx=(p.x-tx0)*z, my=(p.y-ty0)*z;
  const pulse=9+Math.sin(g.time*4)*2;
  c.strokeStyle='rgba(255,157,46,0.8)'; c.lineWidth=2; c.beginPath(); c.arc(mx,my,pulse,0,6.2832); c.stroke();
  const ang={right:0,down:Math.PI/2,left:Math.PI,up:-Math.PI/2}[g.dir]||0;
  c.save(); c.translate(mx,my); c.rotate(ang); c.fillStyle='#ffd84a'; c.strokeStyle='#2a1700'; c.lineWidth=2;
  c.beginPath(); c.moveTo(8,0); c.lineTo(-6,-6); c.lineTo(-3,0); c.lineTo(-6,6); c.closePath(); c.fill(); c.stroke(); c.restore();
  /* scale bar */
  let L=1; for(const s of [1,2,5,10,20,50,100,200,500,1000,2000,5000,10000]){ L=s; if(s*z>=70) break; }
  const bx=14, by=H-44, bw=L*z;
  c.fillStyle='#eaf2dc'; c.fillRect(bx,by,bw,3); c.fillRect(bx,by-4,2,11); c.fillRect(bx+bw-2,by-4,2,11);
  c.font='600 13px ui-monospace,"Courier New",monospace'; c.textAlign='left'; c.textBaseline='bottom'; c.fillText(L+' waddles',bx,by-7);
  const rd=Math.round(m.cx)+', '+Math.round(m.cy)+'  |  '+g.explored.toLocaleString()+' tiles explored  |  seed '+seedLabel()+'  |  zoom '+(z<1?z.toFixed(2):z.toFixed(1))+'x';
  if(rd!==lastRead){ lastRead=rd; el.mRead.textContent=rd; }
}

/* ===== input ===== */
const KEYMAP={h:'h',H:'h',ArrowUp:'up',ArrowDown:'down',ArrowLeft:'left',ArrowRight:'right',z:'z',Z:'z',x:'x',X:'x',Escape:'x',i:'i',I:'i',j:'j',J:'j',m:'m',M:'m','+':'plus','=':'plus','-':'minus','_':'minus',c:'c',C:'c',s:'s',S:'s'};
const DIRKEYS=['up','down','left','right'];
window.addEventListener('keydown',e=>{
  if(e.target&&e.target.tagName==='INPUT') return;
  const k=KEYMAP[e.key]; if(!k) return;
  if(e.ctrlKey||e.metaKey||e.altKey) return;
  e.preventDefault();
  if(AC&&AC.state==='suspended') AC.resume();
  if(!e.repeat){ if(DIRKEYS.includes(k)) g.faceKey=k; press(k); }
  keys[k]=true;
});
window.addEventListener('keyup',e=>{ const k=KEYMAP[e.key]; if(k) keys[k]=false; });
window.addEventListener('blur',()=>{ for(const k in keys) keys[k]=false; });
function press(k){
  const md=g.mode;
  if(md==='title'){ menuKey(k); return; }
  if(md==='play'){ if(k==='z') interact(); else if(k==='i') openInv(); else if(k==='m') openMap(); else if(k==='j') openJournal(); else if(k==='s') showSeed(); return; }
  if(md==='cut'){ cutPress(k); return; }
  if(md==='cal'){ calPress(k); return; }
  if(md==='dialog'){ if(k==='z') advance(); return; }
  if(md==='choice'){ if(k==='up') moveChoice(-1); else if(k==='down') moveChoice(1); else if(k==='z') pickChoice(g.choice.sel); else if(k==='x') pickChoice(g.choice.cancel); return; }
  if(md==='mg'){ mgPress(k); return; }
  if(md==='mini'){ if(k==='z') miniPress(); else if(k==='x'&&g.mini&&g.mini.stage!=='done'){ g.mini=null; el.mini.hidden=true; g.mode='play'; blip(); } return; }
  if(md==='journal'){ if(k==='x'||k==='j') closeJournal(); return; }
  if(md==='shop'){ if(k==='up') shopMove(-1); else if(k==='down') shopMove(1); else if(k==='z') buy(); else if(k==='x') closeShop(); return; }
  if(md==='inv'){
    const ids=invIds(); let s=g.invSel;
    if(k==='left') s=Math.max(0,s-1); else if(k==='right') s=Math.min(15,s+1);
    else if(k==='up') s=Math.max(0,s-4); else if(k==='down') s=Math.min(15,s+4);
    else if(k==='z'){ if(ids[s]) useItem(ids[s]); return; }
    else if(k==='x'||k==='i'){ closeInv(); return; }
    else return;
    if(s!==g.invSel){ g.invSel=s; el.dNote.textContent=''; blip(); renderInv(); }
    return;
  }
  if(md==='map'){
    if(k==='x'||k==='m'||k==='z') closeMap();
    else if(k==='plus') zoomMap(1.4); else if(k==='minus') zoomMap(1/1.4); else if(k==='c') centerMap(); else if(k==='h') setHomeHere();
  }
}
$('bInv').addEventListener('click',e=>{ e.currentTarget.blur(); if(g.mode==='play') openInv(); });
$('bJr').addEventListener('click',e=>{ e.currentTarget.blur(); if(g.mode==='play') openJournal(); });
$('jrClose').addEventListener('click',()=>{ if(g.mode==='journal') closeJournal(); });
$('bMap').addEventListener('click',e=>{ e.currentTarget.blur(); if(g.mode==='play') openMap(); });
$('bSnd').addEventListener('click',e=>{ e.currentTarget.blur(); g.sound=!g.sound; el.bSnd.textContent='Sound: '+(g.sound?'on':'off'); });
$('invClose').addEventListener('click',()=>{ if(g.mode==='inv') closeInv(); });
$('dUse').addEventListener('click',()=>{ const id=invIds()[g.invSel]; if(id) useItem(id); });
$('mClose').addEventListener('click',()=>{ if(g.mode==='map') closeMap(); });
$('mIn').addEventListener('click',()=>zoomMap(1.4));
$('mOut').addEventListener('click',()=>zoomMap(1/1.4));
$('mMe').addEventListener('click',centerMap);
$('mHome').addEventListener('click',e=>{ e.currentTarget.blur(); if(g.mode==='map') setHomeHere(); });
$('mHomeX').addEventListener('click',e=>{ e.currentTarget.blur(); if(g.mode==='map') resetHome(); });
cv.addEventListener('pointerdown',()=>cv.focus());
el.mapc.addEventListener('wheel',e=>{ e.preventDefault(); const r=el.mapc.getBoundingClientRect(); zoomMap(e.deltaY<0?1.25:0.8,e.clientX-r.left,e.clientY-r.top); },{passive:false});
el.mapc.addEventListener('pointerdown',e=>{ m.drag={x:e.clientX,y:e.clientY}; el.mapc.setPointerCapture(e.pointerId); el.mapc.style.cursor='grabbing'; });
el.mapc.addEventListener('pointermove',e=>{ if(!m.drag) return; m.cx-=(e.clientX-m.drag.x)/m.z; m.cy-=(e.clientY-m.drag.y)/m.z; m.drag={x:e.clientX,y:e.clientY}; });
const endDrag=()=>{ m.drag=null; el.mapc.style.cursor='grab'; };
el.mapc.addEventListener('pointerup',endDrag); el.mapc.addEventListener('pointercancel',endDrag);
document.querySelectorAll('.tb').forEach(b=>{
  const dk=b.dataset.k, pk=b.dataset.p;
  if(dk){
    const on=e=>{ e.preventDefault(); keys[dk]=true; g.faceKey=dk; if(g.mode==='inv'||g.mode==='shop'||g.mode==='mg'||g.mode==='brew') press(dk); };
    const off=()=>{ keys[dk]=false; };
    b.addEventListener('pointerdown',on); b.addEventListener('pointerup',off); b.addEventListener('pointerleave',off); b.addEventListener('pointercancel',off);
  } else if(pk){
    b.addEventListener('pointerdown',e=>{ e.preventDefault(); keys[pk]=true; press(pk); });
    const offp=()=>{ keys[pk]=false; }; b.addEventListener('pointerup',offp); b.addEventListener('pointerleave',offp); b.addEventListener('pointercancel',offp);
  }
});

/* ===== start ===== */
function begin(){
  el.title.hidden=true; el.hud.hidden=false; cv.focus();
  ac(); if(AC&&AC.state==='suspended') AC.resume();
  g.mode='play'; quack();
  boot_();
  reveal(0,0,8);
  say('',['Quack?','You wake up in a quiet forest. Dew on your feathers, moss on the log you slept on. Everything seems perfectly normal.','Have a look around. Arrow keys to walk, Z to talk to or use whatever is in front of you. Press ? any time to see every key, and K for what to do today.']);
}

/* ===== per-frame update ===== */
const INTERACTIVE=new Set([T.DOOR,T.HOUSEDOOR,T.DARK,T.TREE,T.ROCK,T.SIGN,T.FOUNTAIN,T.CRUMBS,T.FLOWER,T.BUSH,T.MUSH,T.STUMP,T.LAMP,T.BENCH,T.CRATE,T.HAY,T.STALL,T.BOARD,T.WELL,T.STATUE,T.FIRE]);

function collectNpcs(){
  g.npcs.length=0;
  if(g.scene!=='world') return;
  const prx=Math.floor((g.px/TS+24)/REG), pry=Math.floor((g.py/TS+24)/REG);
  for(let dy=-1;dy<=1;dy++) for(let dx=-1;dx<=1;dx++){
    const t=getTown(prx+dx,pry+dy);
    if(t) for(const n of t.npcs) if(!npcAsleep(n)) g.npcs.push(n);
  }
  extraNpcs(g.npcs);
}
function updateNPCs(dt){
  for(const n of g.npcs){
    if(Math.abs(n.x-g.px)>900||Math.abs(n.y-g.py)>700) continue;
    if(n.talking||n.still) continue;
    n.t-=dt;
    if(n.t<=0){
      if(n.moving){ n.moving=false; n.t=1+Math.random()*2.5; }
      else{
        n.moving=true; n.t=0.5+Math.random()*1.2;
        n.dir=['up','down','left','right'][(Math.random()*4)|0];
        const ddx=n.hx-n.x, ddy=n.hy-n.y;
        if(Math.hypot(ddx,ddy)>3*TS) n.dir=Math.abs(ddx)>Math.abs(ddy)?(ddx>0?'right':'left'):(ddy>0?'down':'up');
      }
    }
    if(n.moving){
      const v=DIRV[n.dir], sp=34*dt, nx=n.x+v.x*sp, ny=n.y+v.y*sp;
      if(!npcBlocked(nx,ny,n)){ n.x=nx; n.y=ny; n.phase+=dt*9; } else { n.moving=false; n.t=0.4; }
    }
  }
}
function movePlayer(dt){
  let dx=(keys.right?1:0)-(keys.left?1:0), dy=(keys.down?1:0)-(keys.up?1:0);
  g.moving=false;
  if(!dx&&!dy) return;
  g.moving=true;
  if(g.faceKey&&keys[g.faceKey]) g.dir=g.faceKey;
  else if(Math.abs(dx)>=Math.abs(dy)&&dx) g.dir=dx>0?'right':'left';
  else g.dir=dy>0?'down':'up';
  if(dx&&dy){ dx*=0.7071; dy*=0.7071; }
  const wet=g.scene==='world'&&tileAt(Math.floor(g.px/TS),Math.floor((g.py-2)/TS))===T.WATER;
  const sp=(wet?(g.worn.feet==='socks'?100:78):128)*(g.boost>0?1.3:1)*dt, ox=g.px, oy=g.py;
  moveAxis(dx*sp,0); moveAxis(0,dy*sp);
  g.phase+=dt*(wet?9:14);
  g.dist+=Math.hypot(g.px-ox,g.py-oy);
  if(g.dist>TS*4) g.flags.moved=true;
}
function findTarget(){
  g.target=null;
  if(g.mode!=='play') return;
  const v=DIRV[g.dir], fx=g.px+v.x*14, fy=g.py-6+v.y*14;
  if(g.scene==='shop'){
    const tx=Math.floor(fx/TS), ty=Math.floor(fy/TS);
    if(ty>=0&&ty<INT_H&&tx>=0&&tx<INT_W&&INTERIOR[ty][tx]==='C') g.target={k:'counter',x:5.5*TS,y:1*TS-6};
    return;
  }
  for(const n of g.npcs){
    if(Math.hypot(n.x-fx,(n.y-8)-fy)<18){ g.target={k:'npc',n:n,x:n.x,y:n.y-30*(n.scale||(n.persona===2?0.75:1))}; return; }
  }
  const tx=Math.floor(fx/TS), ty=Math.floor(fy/TS), t=tileAt(tx,ty);
  const ox=Math.floor(g.px/TS), oy=Math.floor((g.py-2)/TS);
  for(const q of g.quests){
    if(q.type!=='lost'||q.found) continue;
    if((q.lost.x===tx&&q.lost.y===ty)||(q.lost.x===ox&&q.lost.y===oy)){ g.target={k:'lost',q:q,x:(q.lost.x+0.5)*TS,y:q.lost.y*TS-4}; return; }
  }
  if(INTERACTIVE.has(t)){
    const tall=(t===T.TREE||t===T.DARK||t===T.LAMP||t===T.STALL||t===T.BOARD||t===T.WELL||t===T.STATUE||t===T.FIRE||KTALL.has(t));
    g.target={k:'tile',t:t,tx:tx,ty:ty,x:(tx+0.5)*TS,y:ty*TS+(tall?-12:2)};
    return;
  }
  if(tileAt(ox,oy)===T.CRUMBS) g.target={k:'tile',t:T.CRUMBS,tx:ox,ty:oy,x:(ox+0.5)*TS,y:oy*TS+2};
}
function areaName(){
  if(g.scene==='shop') return g.shop.b.name;
  const tx=Math.floor(g.px/TS), ty=Math.floor((g.py-2)/TS);
  const tw=townAtTile(tx,ty); if(tw) return tw.name;
  { const ka=kingdomArea(tx,ty); if(ka) return ka; }
  if(tileAt(tx,ty)===T.WATER) return 'Pond';
  const dk=darkAt(tx,ty);
  if(dk>0.35) return 'Dark Woods';
  if(Math.hypot(tx,ty)<14) return 'Quiet Forest';
  if(forestAt(tx,ty)<0.4) return 'Meadow';
  return 'Forest';
}
function scanDark(){
  const tx=Math.floor(g.px/TS), ty=Math.floor(g.py/TS);
  for(let dy=-6;dy<=6;dy++) for(let dx=-6;dx<=6;dx++) if(tileAt(tx+dx,ty+dy)===T.DARK) return true;
  return false;
}
function update(dt){
  g.time+=dt;
  if(g.mode!=='title'&&g.mode!=='cut') advanceClock(dt*24/DAY_SECS);
  if(g.boost>0) g.boost=Math.max(0,g.boost-dt);
  if(g.fadeIn>0) g.fadeIn=Math.max(0,g.fadeIn-dt);
  if(g.mode==='dialog') typeDialog(dt);
  if(g.mode==='mini') updateMini(dt);
  if(g.mode==='mg') mgUpdate(dt);
  if(g.mode==='map'){
    const sp=520/m.z*dt;
    if(keys.left) m.cx-=sp; if(keys.right) m.cx+=sp; if(keys.up) m.cy-=sp; if(keys.down) m.cy+=sp;
  }
  collectNpcs();
  if(g.mode==='play') movePlayer(dt);
  else g.moving=false;
  if(g.scene==='world') updateNPCs(dt);
  if(g.scene==='shop'&&g.mode==='play'){
    if(g.py>7*TS+6) exitShop();
    else if(!shopOpen(g.shop.b)){ const k=g.shop.b.keeper.name; exitShop(); toast(k+': "Closing time! See you tomorrow."',3000); }
  }
  findTarget();
  extraUpdate(dt); storyUpdate(dt);

  const tx=Math.floor(g.px/TS), ty=Math.floor((g.py-2)/TS);
  if(g.scene==='world'){
    if(tx!==g.lastTx||ty!==g.lastTy){
      g.lastTx=tx; g.lastTy=ty; reveal(tx,ty,7);
      if(tileAt(tx,ty)===T.PATH) g.flags.trail=true;
    }
    const tw=townAtTile(tx,ty), tkk=tw?tw.key:null;
    if(tkk!==g.curTown){
      g.curTown=tkk;
      if(tw){
        if(!g.towns.has(tw.key)){
          g.towns.set(tw.key,{key:tw.key,name:tw.name,x:tw.cx+0.5,y:tw.cy+0.5});
          g.flags.town=true; toast('You arrive in '+tw.name+', '+tw.style.label,3800);
        } else toast('Welcome back to '+tw.name+'  -  '+RANKS[townRank(tw)].n,2600);
      }
    }
    const dk=darkAt(tx,ty);
    g.dkLevel+=(dk-g.dkLevel)*Math.min(1,dt*3);
    g.scanT-=dt;
    if(g.scanT<=0){
      g.scanT=0.5;
      if(!g.flags.darkSeen&&g.mode==='play'&&scanDark()){
        g.flags.darkSeen=true;
        say('',['Some of the trees ahead look wrong.','Not autumn-wrong. Deep, glossy, purple-black wrong, like they are soaking something up instead of giving anything back.','A faint violet shimmer drifts off the bark. Probably nothing. Press Z on one if you are curious.']);
      }
    }
  } else g.dkLevel*=0.9;

  const tcx=g.scene==='world'?g.px:0, tcy=g.scene==='world'?g.py-10:0;
  if(g.scene==='world'){ g.camX+=(tcx-g.camX)*Math.min(1,dt*8); g.camY+=(tcy-g.camY)*Math.min(1,dt*8); }
  updateHud();
}
/* ===== HUD ===== */
const ARROWS=['→','↘','↓','↙','←','↖','↑','↗'];
let hudCache={};
function setText(node,key,val){ if(hudCache[key]!==val){ hudCache[key]=val; node.textContent=val; } }
function objective(){
  const f=g.flags;
  { const so=storyObjective(); if(so) return so; }
  if(!f.moved) return 'Waddle around with the <b>arrow keys</b>. Press <b>Z</b> on things you find.';
  if(!f.sign&&!f.trail) return 'A wooden sign stands near where you woke up. Face it and press <b>Z</b>.';
  if(!f.trail) return 'Follow the dirt trail east. Someone must live that way.';
  if(!f.town) return f.dark?'Keep following the trail east. You will find company.':'Keep following the trail east. Take a closer look at anything that seems off.';
  if(!f.talked) return 'You made it. Face a townduck and press <b>Z</b> to talk.';
  if(!f.shop) return 'Step into a shop: face a door and press <b>Z</b>.';
  if(!f.bought) return 'Walk up to the counter, press <b>Z</b>, and spend some crumbs.';
  if(!f.map) return 'Press <b>I</b> for your inventory. Your map is inside. Or press <b>M</b>.';
  if(g.quests.length) return 'Favor: '+questText(g.quests[0])+'  ('+g.quests.length+' active, press <b>J</b> for your journal)';
  if(!f.worked) return 'Need crumbs? Ask a shopkeeper for <b>work</b> at the counter, or use the <b>notice board</b> in the town square.';
  if(!f.favor) return 'Townducks with a <b>!</b> over their heads need a hand. Talk to them to earn crumbs and reputation.';
  return 'The world never ends. Build your reputation, earn crumbs, and find out what is wrong with the dark trees.';
}
function showChip(node,on){ if(node.hidden===on) node.hidden=!on; }
function updateHud(){
  setText(el.crumbs,'cr',String(g.crumbs));
  setText(el.area,'area',areaName());
  setText(el.clock,'clk','Day '+g.day+'  '+clockStr()+'  '+phaseName(g.clock));
  const tw=g.scene==='shop'?g.shop.town:townAtTile(Math.floor(g.px/TS),Math.floor((g.py-2)/TS));
  showChip(el.repChip,!!tw);
  if(tw) setText(el.repTxt,'rep',RANKS[townRank(tw)].n);
  showChip(el.boostChip,g.boost>0);
  if(g.boost>0) setText(el.boostT,'bst',Math.ceil(g.boost)+'s');
  const o=objective(); if(hudCache.obj!==o){ hudCache.obj=o; el.obj.innerHTML=o; }
  const hasC=isHeld('compass');
  if(el.homeChip.hidden===hasC) el.homeChip.hidden=!hasC;
  if(hasC){
    const p=worldPos(), hp=homePos(), dx=hp.x-p.x, dy=hp.y-p.y;
    const a=Math.atan2(dy,dx), i=((Math.round(a/(Math.PI/4))%8)+8)%8;
    setText(el.homeTxt,'home',ARROWS[i]+' '+Math.round(Math.hypot(dx,dy)));
  }
}
/* ===== render ===== */
let frameDt=0.016;
function render(){
  const c=ctx, W=cv.width, H=cv.height;
  c.setTransform(1,0,0,1,0,0); c.fillStyle='#0b1411'; c.fillRect(0,0,W,H);
  c.imageSmoothingEnabled=false;
  NIGHT=ambient(g.clock)[3]/NIGHT_MAX;
  if(g.scene==='world'){
    drawWorld(c,W,H,kd,g.camX,g.camY,g.time);
    drawNight(c,W,H,kd);
    const tw=townAtTile(Math.floor(g.px/TS),Math.floor((g.py-2)/TS));
    const kind=tw?tw.style.part:(NIGHT>0.5?'fly':null);
    updateParts(frameDt,kind,W,H); drawParts(c,kind,kd);
  } else { drawInterior(c,W,H,kd,g.time); updateParts(0,null,W,H); }
  if(g.scene==='world'&&g.dkLevel>0.02){
    const lant=isHeld('lantern')?0.5:1, a=0.7*g.dkLevel*lant;
    const gr=c.createRadialGradient(W/2,H/2,Math.min(W,H)*0.22,W/2,H/2,Math.max(W,H)*0.72);
    gr.addColorStop(0,'rgba(24,0,52,0)'); gr.addColorStop(1,'rgba(24,0,52,'+a.toFixed(2)+')');
    c.fillStyle=gr; c.fillRect(0,0,W,H);
    if(isHeld('lantern')){
      const r=150*kd, gl=c.createRadialGradient(W/2,H/2-10*kd,4,W/2,H/2-10*kd,r);
      gl.addColorStop(0,'rgba(255,214,120,'+(0.3*g.dkLevel).toFixed(2)+')'); gl.addColorStop(1,'rgba(255,214,120,0)');
      c.fillStyle=gl; c.fillRect(0,0,W,H);
    }
  }
  if(g.fadeIn>0){ c.fillStyle='rgba(0,0,0,'+(g.fadeIn/g.fadeMax).toFixed(2)+')'; c.fillRect(0,0,W,H); }
  if(g.mode==='map') drawMap();
  if(g.mode==='cut') cutRender(frameDt);
}
/* ===== main loop ===== */
let lastT=0;
function frame(ts){
  const dt=Math.min(0.05,(ts-lastT)/1000||0.016); lastT=ts; frameDt=dt;
  update(dt); render();
  requestAnimationFrame(frame);
}
function boot(){
  resize();
  new ResizeObserver(resize).observe(stage);
  reveal(0,0,8);
  el.obj.innerHTML=objective();
  requestAnimationFrame(frame);
}

/* ===== saving: the popup closes whenever it loses focus, so progress is stored automatically ===== */
const hasChromeStore=()=>!!(window.chrome&&chrome.storage&&chrome.storage.local);
const store={
  get(k){
    try{ if(hasChromeStore()) return chrome.storage.local.get(k).then(r=>r[k]); }catch(e){}
    try{ const v=localStorage.getItem(k); return Promise.resolve(v?JSON.parse(v):undefined); }catch(e){ return Promise.resolve(undefined); }
  },
  set(k,v){
    try{ if(hasChromeStore()) return chrome.storage.local.set({[k]:v}); }catch(e){}
    try{ localStorage.setItem(k,JSON.stringify(v)); }catch(e){}
    return Promise.resolve();
  },
  remove(k){
    try{ if(hasChromeStore()) return chrome.storage.local.remove(k); }catch(e){}
    try{ localStorage.removeItem(k); }catch(e){}
    return Promise.resolve();
  }
};
function packFlags(f){
  let s='';
  for(let i=0;i<f.length;i+=8){ let b=0; for(let j=0;j<8;j++) if(f[i+j]) b|=1<<j; s+=String.fromCharCode(b); }
  return btoa(s);
}
function unpackFlags(str){
  const s=atob(str), f=new Uint8Array(CH*CH);
  for(let i=0;i<s.length;i++){ const b=s.charCodeAt(i); for(let j=0;j<8;j++) if(b&(1<<j)) f[i*8+j]=1; }
  return f;
}
function snapshot(){
  const p=(g.scene==='shop'&&g.saved)?g.saved:{x:g.px,y:g.py,dir:g.dir};
  const ch={}; chunks.forEach((c,k)=>{ ch[k]=packFlags(c.flags); });
  return {v:2,slot:g.slot,seed:SEED,seedText:SEED_TEXT,savedAt:Date.now(),x:p.x,y:p.y,dir:p.dir||g.dir,crumbs:g.crumbs,inv:g.inv,worn:g.worn,clues:g.clues,
    inspected:[...g.inspected],flags:g.flags,towns:[...g.towns.values()],dist:g.dist,taken:[...taken],
    explored:g.explored,sound:g.sound,chunks:ch,
    clock:g.clock,day:g.day,rep:g.rep,mem:g.mem,quests:g.quests,work:g.work,rumors:g.rumors,ev:g.ev,story:g.story};
}
function unstick(){
  if(!blockedAt(g.px,g.py)) return;
  const cx=Math.floor(g.px/TS), cy=Math.floor(g.py/TS);
  for(let r=1;r<=12;r++) for(let dy=-r;dy<=r;dy++) for(let dx=-r;dx<=r;dx++){
    if(Math.max(Math.abs(dx),Math.abs(dy))!==r) continue;
    const x=(cx+dx+0.5)*TS, y=(cy+dy+0.9)*TS;
    if(!blockedAt(x,y)){ g.px=x; g.py=y; return; }
  }
}
function applySave(s){
  g.px=s.x; g.py=s.y; g.dir=s.dir||'down'; g.camX=g.px; g.camY=g.py-10;
  g.crumbs=s.crumbs; g.inv=s.inv||{map:1}; if(!g.inv.map) g.inv={map:1,...g.inv};
  g.worn=s.worn||{head:s.hatOn?'hat':null,neck:null};
  g.clues=s.clues||0; g.inspected=new Set(s.inspected||[]);
  g.flags=s.flags||{}; g.dist=s.dist||0; g.explored=s.explored||0; g.sound=s.sound!==false;
  g.towns=new Map((s.towns||[]).map(t=>{
    const key=t.key||(Math.round((t.x-0.5)/REG)+','+Math.round((t.y-0.5)/REG));
    return [key,{key:key,name:t.name,x:t.x,y:t.y}];
  }));
  g.clock=typeof s.clock==='number'?s.clock:8; g.day=s.day||1; g.rep=s.rep||{}; g.mem=s.mem||{};
  g.ev=s.ev||{}; g.story=s.story||{}; g.quests=s.quests||[]; g.work=s.work||{}; g.rumors=s.rumors||[]; g.boost=0; g.curTown=null;
  taken.clear(); (s.taken||[]).forEach(k=>taken.add(k)); tileCache.clear();
  for(const k in (s.chunks||{})){
    const [a,b]=k.split(',').map(Number);
    chunks.set(k,{cxk:a,cyk:b,flags:unpackFlags(s.chunks[k]),cv:null,ctx:null});
  }
  el.bSnd.textContent='Sound: '+(g.sound?'on':'off');
  el.title.hidden=true; el.hud.hidden=false; g.mode='play'; g.lastTx=null;
  unstick();
  g.camX=g.px; g.camY=g.py-10;
  toast('Welcome back, detective.',2200);
}
let lastSig='', savingOff=false;
function autosave(){
  if(savingOff||g.mode==='title'||!g.slot) return;
  const sig=[Math.round(g.px),Math.round(g.py),g.crumbs,g.explored,g.clues,JSON.stringify(g.worn),g.sound,JSON.stringify(g.inv),g.inspected.size,taken.size,g.towns.size,JSON.stringify(g.flags),Math.floor(g.clock*2),g.day,JSON.stringify(g.rep),JSON.stringify(g.mem),JSON.stringify(g.quests),JSON.stringify(g.work),g.rumors.length,JSON.stringify(g.ev),JSON.stringify(g.story)].join('|');
  if(sig===lastSig) return;
  lastSig=sig; store.set(slotKey(g.slot),snapshot());
}
setInterval(autosave,1500);
document.addEventListener('visibilitychange',()=>{ if(document.hidden) autosave(); });
window.addEventListener('pagehide',autosave);

/* ===== save flush ===== */
function flushSave(){ if(g.mode==='title'||!g.slot) return Promise.resolve(); lastSig=''; return Promise.resolve(store.set(slotKey(g.slot),snapshot())); }
$('keysTip').innerHTML='Arrows move &middot; Z interact &middot; I inventory &middot; J journal &middot; M map &middot; S seed';

/* ===== seed display ===== */
function seedLabel(){ return SEED_TEXT||'Original world'; }
function showSeed(){
  const t=SEED_TEXT;
  toast(t?('World seed: '+t+'  (copied)'):'World seed: Original world',3500);
  if(t){ try{ navigator.clipboard.writeText(t).catch(()=>{}); }catch(e){} }
}
$('bSeed').addEventListener('click',e=>{ e.currentTarget.blur(); if(g.mode==='play') showSeed(); });
$('bMenu').addEventListener('click',e=>{ e.currentTarget.blur(); if(g.mode==='title') return; savingOff=true; flushSave().then(()=>location.reload()); });

/* ===== start menu: 5 save slots, each with its own world seed ===== */
const SLOTS=5;
const slotKey=n=>'duckDetectivesSlot'+n;
const menu={slots:[],sel:0,view:'slots',seedText:'',busy:false};
function randomSeedText(){
  const A='ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; let r='';
  const b=new Uint32Array(6);
  try{ crypto.getRandomValues(b); }catch(e){ for(let i=0;i<6;i++) b[i]=Math.random()*4294967296; }
  for(let i=0;i<6;i++) r+=A[b[i]%A.length];
  return r;
}
function esc(t){ return String(t).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }
function resetWorld(){
  townCache.clear(); tileCache.clear(); chunks.clear(); taken.clear();
  for(const k of Object.keys(g.flags)) delete g.flags[k];
  g.ev={}; g.story={}; resetKingdom();
}
function setSeed(text){
  SEED_TEXT=text; SEED=text?seedFromText(text):0;
  resetWorld();
}
async function loadSlots(){
  const out=[];
  for(let n=1;n<=SLOTS;n++){
    let s; try{ s=await store.get(slotKey(n)); }catch(e){}
    if(!s&&n===1){   /* migrate the old single-save into slot 1 */
      try{ const old=await store.get('duckDetectivesSave1'); if(old&&(old.v===1||old.v===2)){ old.slot=1; old.seed=0; old.seedText=''; s=old; await store.set(slotKey(1),old); await store.remove('duckDetectivesSave1'); } }catch(e){}
    }
    out.push(s&&(s.v===1||s.v===2)?s:null);
  }
  return out;
}
function slotSummary(s){
  const when=s.savedAt?new Date(s.savedAt).toLocaleDateString(undefined,{month:'short',day:'numeric'}):'';
  return 'Day '+(s.day||1)+' &middot; '+(s.crumbs||0)+' crumbs &middot; '+(s.explored||0).toLocaleString()+' tiles'+(when?' &middot; '+when:'');
}
function renderMenu(){
  const box=$('menuBody');
  if(menu.view==='slots'){
    let h='<div class="slots5">';
    menu.slots.forEach((s,i)=>{
      h+='<div class="slotrow'+(i===menu.sel?' sel':'')+'" data-i="'+i+'">'
        +'<div class="sn">'+(i+1)+'</div>'
        +'<div class="si">'+(s
          ?'<b>Seed: '+esc(s.seedText||'Original world')+'</b><span>'+slotSummary(s)+'</span>'
          :'<b class="empty">Empty slot</b><span>Start a new game here</span>')+'</div>'
        +'<div class="sa">'+(s?'<button class="hb" data-act="play" data-i="'+i+'" type="button">Continue</button><button class="hb" data-act="del" data-i="'+i+'" type="button">'+(menu.confirmDel===i?'Sure?':'Delete')+'</button>'
          :'<button class="hb" data-act="new" data-i="'+i+'" type="button">New game</button>')+'</div></div>';
    });
    h+='</div><p class="small">Up/Down choose &middot; Z select &middot; each slot keeps its own world seed.</p>';
    box.innerHTML=h;
  } else {
    box.innerHTML='<div class="seedform"><h3>New game &mdash; slot '+(menu.sel+1)+'</h3>'
      +'<p>Choose the world seed. The same seed always builds the same forest, towns and shops.</p>'
      +'<div class="seedrow"><input id="seedIn" type="text" maxlength="24" autocomplete="off" spellcheck="false" placeholder="Type a seed, or leave blank for random" value="'+esc(menu.seedText)+'">'
      +'<button class="hb" id="seedRnd" type="button">Roll random</button></div>'
      +'<div class="seedbtns"><button class="hb big" id="seedGo" type="button">Start</button><button class="hb" id="seedBack" type="button">Back</button></div>'
      +'<p class="small">Tip: type <b>original</b> to play the classic forest.</p></div>';
    const inp=$('seedIn');
    inp.addEventListener('input',()=>{ menu.seedText=inp.value; });
    inp.addEventListener('keydown',e=>{ e.stopPropagation(); if(e.key==='Enter') startNew(); else if(e.key==='Escape'){ menu.view='slots'; renderMenu(); } });
    $('seedRnd').addEventListener('click',()=>{ menu.seedText=randomSeedText(); inp.value=menu.seedText; });
    $('seedGo').addEventListener('click',startNew);
    $('seedBack').addEventListener('click',()=>{ menu.view='slots'; renderMenu(); });
    setTimeout(()=>inp.focus(),0);
  }
}
function startNew(){
  if(menu.busy) return;
  let t=menu.seedText.trim();
  if(!t) t=randomSeedText();
  if(t.toLowerCase()==='original') t='';
  const slot=menu.sel+1;
  setSeed(t); g.slot=slot;
  menu.busy=true;
  lastSig='';
  begin();
  flushSave();
}
function continueSlot(i){
  const s=menu.slots[i]; if(!s||menu.busy) return;
  menu.busy=true;
  setSeed(s.seedText||''); g.slot=i+1;
  try{ applySave(s); }catch(e){ console.error(e); }
  boot_();
}
function deleteSlot(i){
  if(menu.confirmDel!==i){ menu.confirmDel=i; renderMenu(); clearTimeout(menu.delT); menu.delT=setTimeout(()=>{ menu.confirmDel=-1; if(menu.view==='slots') renderMenu(); },3000); return; }
  menu.confirmDel=-1;
  store.remove(slotKey(i+1)).then(()=>{ menu.slots[i]=null; renderMenu(); });
}
function menuAction(i){ menu.sel=i; if(menu.slots[i]) continueSlot(i); else { menu.view='seed'; menu.seedText=''; renderMenu(); } }
$('menuBody').addEventListener('click',e=>{
  const b=e.target.closest('[data-act]');
  if(b){ const i=+b.dataset.i; menu.sel=i; if(b.dataset.act==='play') continueSlot(i); else if(b.dataset.act==='new'){ menu.view='seed'; menu.seedText=''; renderMenu(); } else if(b.dataset.act==='del') deleteSlot(i); return; }
  const r=e.target.closest('.slotrow'); if(r){ menu.sel=+r.dataset.i; renderMenu(); }
});
function menuKey(k){
  if(menu.view!=='slots') return;
  if(k==='up'){ menu.sel=(menu.sel+SLOTS-1)%SLOTS; renderMenu(); }
  else if(k==='down'){ menu.sel=(menu.sel+1)%SLOTS; renderMenu(); }
  else if(k==='z') menuAction(menu.sel);
}

let booted=false;
function boot_(){ if(booted) return; booted=true; boot(); }
loadSlots().then(sl=>{ menu.slots=sl; menu.confirmDel=-1; renderMenu(); }).catch(()=>{ menu.slots=Array(SLOTS).fill(null); renderMenu(); });
