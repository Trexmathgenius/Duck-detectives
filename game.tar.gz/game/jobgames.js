'use strict';
/* ===== JOB GAMES for the six newer shops: each has its own mini-game ===== */
Object.assign(MG_BY_TITLE,{
 'Sharpen the Blades':'sharpen','Tie the Flies':'flies','Ink the Maps':'ink',
 'Press the Specimens':'specimen','Mix the Tonics':'tonic','Pack the Satchels':'satchel'
});
JOBS.hardware=['Sharpen the Blades','Hold Z to grind, keep the pressure in the green.'];
JOBS.tackle=['Tie the Flies','Copy the knot: repeat the arrow pattern.'];
JOBS.cartog=['Ink the Maps','Steer the pen along the coastline with Up and Down.'];
JOBS.naturalist=['Press the Specimens','Find the matching pairs of leaves.'];
JOBS.apoth=['Mix the Tonics','Add the bottles in the order on the recipe.'];
JOBS.provision=['Pack the Satchels','Fit each item in the right satchel by its size.'];

/* Toolshed: hold Z to grind, hold the pressure gauge inside the green band */
MG.sharpen={
 hint:'Hold Z to grind. Let go to ease off. Keep the gauge in the green.', keys:'Hold Z grind',
 how:['Hold Z to press the blade to the stone.','The gauge drifts up when you grind and down when you rest.','Keep it in the green band. Too hot and the blade burns.'],
 hud:s=>'Edge '+Math.round(s.edge*100)+'%',
 init(s){ s.t=0; s.g=0.3; s.edge=0; s.burn=0; s.band=0.5; s.sp=[]; s.dur=14; },
 update(s,dt){
  s.t+=dt; s.band=0.5+Math.sin(s.t*0.8)*0.18;
  s.g=mgClamp(s.g+(keys.z?0.55:-0.45)*dt+Math.sin(s.t*5)*0.004,0,1);
  const inb=Math.abs(s.g-s.band)<0.12;
  if(inb&&keys.z){ s.edge=Math.min(1,s.edge+dt/9); if(Math.random()<0.6) s.sp.push({x:300,y:150,vx:mgRnd(20,90),vy:mgRnd(-90,-10),a:1}); }
  else if(s.g>s.band+0.12){ s.burn+=dt; s.edge=Math.max(0,s.edge-dt*0.05); s.msg='Too hot!'; }
  else if(keys.z) s.msg='Press harder'; else s.msg='';
  for(const p of s.sp){ p.x+=p.vx*dt; p.y+=p.vy*dt; p.vy+=200*dt; p.a-=dt*2; } s.sp=s.sp.filter(p=>p.a>0);
  if(s.t>=s.dur||s.edge>=1){ s.done=1; s.score=Math.max(0,s.edge*10-s.burn*0.5); }
 },
 press(s,k){},
 draw(s,c,t){
  mgSky(c,'#d9d4c8','#b9b2a2'); rect(c,0,200,MGW,70,'#7a6a58'); rect(c,0,200,MGW,5,'#5a4a3a');
  ell(c,300,170,56,56,'#8a8f98'); ell(c,300,170,44,44,'#a9aeb7'); ell(c,300,170,8,8,'#4a4e55');
  c.save(); c.translate(300,170); c.rotate(keys.z?t*9:t*1.2); rect(c,-2,-52,4,16,'#6a6e75'); c.restore();
  const bx=200+(keys.z?6:0); c.fillStyle='#c9ced6'; c.beginPath(); c.moveTo(bx-80,150); c.lineTo(bx+16,146); c.lineTo(bx+16,160); c.lineTo(bx-80,164); c.fill(); rect(c,bx-110,148,34,16,'#7a4a2a');
  c.strokeStyle='rgba(255,255,255,'+(0.2+s.edge*0.8).toFixed(2)+')'; c.lineWidth=2; c.beginPath(); c.moveTo(bx+16,146); c.lineTo(bx+16,160); c.stroke();
  for(const p of s.sp) circ(c,p.x,p.y,2,'rgba(255,200,80,'+p.a.toFixed(2)+')');
  rect(c,400,50,24,150,'#2a2f33'); rect(c,400,50+150*(1-(s.band+0.12)),24,150*0.24,'#4caf6a');
  rect(c,396,200-150*s.g-2,32,5,s.g>s.band+0.12?'#e0452f':'#fff');
  mgBar(c,60,240,360,10,s.edge,'#e8e8f0'); mgT(c,'Edge',34,245,12,'#333');
  mgDuck(c,90,210,1.3);
 }
};

/* Tackle: copy the knot pattern of arrows (Simon says) */
MG.flies={
 hint:'Watch the knot, then tie it: repeat the arrows.', keys:'Arrow keys',
 how:['A knot is shown one arrow at a time.','Repeat it with the arrow keys.','Each round adds one more turn. Ten rounds.'],
 hud:s=>'Knot '+Math.min(10,s.r+1)+'/10  |  Tied '+s.ok,
 init(s){ s.r=0; s.ok=0; s.seq=[]; this.next(s); },
 next(s){ const d=['left','up','right','down']; s.seq=[]; const n=Math.min(2+Math.floor(s.r/2),6); for(let i=0;i<n;i++) s.seq.push(d[(Math.random()*4)|0]); s.ph='show'; s.i=0; s.w=0.7; s.inp=0; s.msg='Watch...'; s.flash=''; },
 update(s,dt){
  if(s.ph==='show'){ s.w-=dt; if(s.w<=0){ s.i++; s.w=0.55; if(s.i>s.seq.length){ s.ph='in'; s.inp=0; s.msg='Your turn'; s.i=0; } } }
  else if(s.ph==='res'){ s.w-=dt; if(s.w<=0){ s.r++; if(s.r>=10){ s.done=1; s.score=s.ok; } else this.next(s); } }
 },
 press(s,k){
  if(s.ph!=='in'||!RGDIR[k]) return;
  s.flash=k;
  if(k===s.seq[s.inp]){ s.inp++; mgTone(1); if(s.inp>=s.seq.length){ s.ok++; s.ph='res'; s.w=0.7; s.msg='Tied!'; } }
  else { s.ph='res'; s.w=0.9; s.msg='Knot slipped...'; mgTone(0); }
 },
 draw(s,c,t){
  mgSky(c,'#cfe3e8','#a6c8d2'); rect(c,0,200,MGW,70,'#8a6a45'); rect(c,0,200,MGW,5,'#6a4a2a');
  const n=s.seq.length; for(let i=0;i<n;i++){
   const x=240-(n-1)*26+i*52; const lit=s.ph==='show'&&s.i===i+1&&s.w>0.15;
   const done=s.ph==='in'&&i<s.inp;
   rect(c,x-20,90,40,40,lit?'#ffd166':done?'#7fd37a':'#2a3a40');
   if(lit||done||s.ph==='res') rgArrow(c,x,110,s.seq[i],10,'#111');
   else mgT(c,'?',x,110,18,'#6a8a96');
  }
  c.strokeStyle='#e8e0c8'; c.lineWidth=2; c.beginPath(); c.moveTo(60,180); c.bezierCurveTo(140,150,200,215,260,175); c.stroke();
  ell(c,300,172,14,6,'#e0452f'); rect(c,310,170,16,3,'#ffd166'); rect(c,262,168,6,10,'#aaa');
  mgDuck(c,420,205,1.3,null,-1);
 }
};

/* Surveyor: steer the pen along a wavy coastline */
MG.ink={
 hint:'Keep the pen on the coastline. Up and Down steer.', keys:'Up / Down',
 how:['The coast scrolls past from the right.','Press Up and Down to keep the pen on the line.','Every moment on the line inks the map.'],
 hud:s=>'Inked '+Math.round(s.inked/s.dur*100)+'%',
 init(s){ s.t=0; s.dur=14; s.y=135; s.vy=0; s.inked=0; s.drops=[]; s.ph=Math.random()*6; },
 coast(s,t){ return 135+Math.sin(t*1.3+s.ph)*45+Math.sin(t*2.9+s.ph*2)*18; },
 update(s,dt){
  s.t+=dt; s.vy*=Math.pow(0.02,dt); s.y=mgClamp(s.y+s.vy*dt,40,215);
  const e=Math.abs(s.y-this.coast(s,s.t));
  if(e<13){ s.inked+=dt; s.msg=''; } else { s.msg='Off the line!'; if(Math.random()<0.4) s.drops.push({x:140,y:s.y,a:1}); }
  for(const d of s.drops){ d.x-=60*dt; d.a-=dt; } s.drops=s.drops.filter(d=>d.a>0);
  if(s.t>=s.dur){ s.done=1; s.score=s.inked/s.dur*10; }
 },
 press(s,k){ if(k==='up') s.vy-=150; else if(k==='down') s.vy+=150; },
 draw(s,c,t){
  mgSky(c,'#efe0b8','#e2cd98'); rect(c,24,28,MGW-48,MGH-56,'#f6ecd0'); c.strokeStyle='#8a6a3a'; c.lineWidth=3; c.strokeRect(24,28,MGW-48,MGH-56);
  c.strokeStyle='rgba(60,40,20,0.35)'; c.lineWidth=7; c.setLineDash([2,6]); c.beginPath(); for(let x=140;x<=450;x+=6){ const y=this.coast(s,s.t+(x-140)/60); x===140?c.moveTo(x,y):c.lineTo(x,y); } c.stroke(); c.setLineDash([]);
  c.strokeStyle='#2a3a6a'; c.lineWidth=3; c.beginPath(); let st=false; for(let x=40;x<=140;x+=4){ const y=this.coast(s,s.t-(140-x)/60); const tt=s.t-(140-x)/60; if(tt<0) continue; st?c.lineTo(x,y):(c.moveTo(x,y),st=true); } c.stroke();
  for(const d of s.drops) circ(c,d.x,d.y,3,'rgba(30,30,90,'+d.a.toFixed(2)+')');
  c.save(); c.translate(140,s.y); rect(c,0,-3,38,6,'#6a4a2a'); c.fillStyle='#2a3a6a'; c.beginPath(); c.moveTo(0,-3); c.lineTo(-10,0); c.lineTo(0,3); c.fill(); c.restore();
  mgBar(c,60,242,360,8,s.t/s.dur,'#8a6a3a');
 }
};

/* Naturalist: flip cards, find the matching pressed leaves */
MG.specimen={
 hint:'Flip two cards. Match all five pairs of leaves.', keys:'Arrows move, Z flips',
 how:['Ten cards lie face down.','Move with the arrows, flip with Z.','Match all five pairs. Fewer flips, higher score.'],
 hud:s=>'Pairs '+s.pairs+'/5  |  Flips '+s.flips,
 init(s){ const a=[0,0,1,1,2,2,3,3,4,4]; for(let i=9;i>0;i--){ const j=(Math.random()*(i+1))|0; [a[i],a[j]]=[a[j],a[i]]; } s.cards=a.map(v=>({v,up:false,ok:false})); s.cur=0; s.open=[]; s.pairs=0; s.flips=0; s.lock=0; },
 update(s,dt){
  if(s.lock>0){ s.lock-=dt; if(s.lock<=0){ const [a,b]=s.open; if(s.cards[a].v===s.cards[b].v){ s.cards[a].ok=s.cards[b].ok=true; s.pairs++; mgTone(1); } else { s.cards[a].up=s.cards[b].up=false; mgTone(0); } s.open=[]; if(s.pairs>=5){ s.done=1; s.score=mgClamp(10-(s.flips-10)*0.7,2,10); } } }
 },
 press(s,k){
  if(k==='left') s.cur=(s.cur+9)%10; else if(k==='right') s.cur=(s.cur+1)%10; else if(k==='up') s.cur=(s.cur+5)%10; else if(k==='down') s.cur=(s.cur+5)%10;
  else if(k==='z'&&!s.lock){ const cd=s.cards[s.cur]; if(cd.up||cd.ok) return; cd.up=true; s.open.push(s.cur); s.flips++; blip(); if(s.open.length===2) s.lock=0.8; }
 },
 draw(s,c,t){
  mgSky(c,'#d8e8c8','#b8d0a0'); rect(c,0,214,MGW,56,'#7a5a3a');
  const cols=['#4caf50','#e0a030','#c0503a','#8a5ac8','#3a9ac8'];
  s.cards.forEach((cd,i)=>{ const x=80+(i%5)*70, y=40+((i/5)|0)*82;
   rect(c,x,y,56,70,cd.up||cd.ok?'#f6f0dc':'#5a7a4a');
   if(cd.up||cd.ok){ const col=cols[cd.v]; c.fillStyle=col; c.beginPath(); c.ellipse(x+28,y+34,14,22,cd.v*0.5-0.8,0,6.3); c.fill(); c.strokeStyle='#0004'; c.beginPath(); c.moveTo(x+28,y+14); c.lineTo(x+28,y+56); c.stroke(); for(let q=0;q<=cd.v;q++) rect(c,x+8+q*6,y+60,4,4,col); }
   else { c.strokeStyle='#3a5a2a'; c.strokeRect(x+6.5,y+6.5,43,57); mgT(c,'?',x+28,y+35,22,'#9ac07a'); }
   if(cd.ok) { c.fillStyle='rgba(120,210,120,0.25)'; c.fillRect(x,y,56,70); }
   if(i===s.cur){ c.strokeStyle='#ffd166'; c.lineWidth=3; c.strokeRect(x-2,y-2,60,74); } });
 }
};

/* Apothecary: add the bottles in the recipe's order */
const TN_COL=[{n:'red',k:'up',c:'#e0452f'},{n:'gold',k:'right',c:'#f2d45a'},{n:'blue',k:'down',c:'#5aa0e0'},{n:'green',k:'left',c:'#6fd08a'}];
MG.tonic={
 hint:'Follow the recipe: add the bottles in order, red-up, gold-right, blue-down, green-left.', keys:'Arrows pour',
 how:['A recipe card lists bottles in order.','Press the arrow of each bottle: Up red, Right gold, Down blue, Left green.','A wrong pour ruins the batch. Six tonics, and the recipes get longer.'],
 hud:s=>'Batch '+Math.min(6,s.r+1)+'/6  |  Brewed '+s.ok,
 init(s){ s.r=0; s.ok=0; this.next(s); },
 next(s){ s.rec=[]; const n=Math.min(3+Math.floor(s.r/2),5); for(let i=0;i<n;i++) s.rec.push((Math.random()*4)|0); s.i=0; s.fill=0; s.w=0; s.ph='mix'; s.msg='Add them in order'; s.t=0; s.lim=2.2+n*1.5; },
 update(s,dt){
  if(s.ph==='mix'){ s.t+=dt; if(s.t>s.lim){ s.ph='res'; s.w=1; s.msg='Too slow, it curdled.'; mgTone(0); } }
  else { s.w-=dt; if(s.w<=0){ s.r++; if(s.r>=6){ s.done=1; s.score=s.ok*10/6; } else this.next(s); } }
 },
 press(s,k){
  if(s.ph!=='mix') return; const ix=TN_COL.findIndex(x=>x.k===k); if(ix<0) return;
  if(ix===s.rec[s.i]){ s.i++; s.fill=s.i/s.rec.length; mgTone(1); if(s.i>=s.rec.length){ s.ok++; s.ph='res'; s.w=0.9; s.msg='Perfect batch!'; } }
  else { s.ph='res'; s.w=1; s.msg='Wrong bottle! Boom.'; mgTone(0); }
 },
 draw(s,c,t){
  mgSky(c,'#e4d8ee','#c8b8dc'); rect(c,0,205,MGW,65,'#6a4a5a'); rect(c,0,205,MGW,4,'#4a2a3a');
  TN_COL.forEach((b,i)=>{ const x=70+i*60; rect(c,x-14,150,28,46,b.c); rect(c,x-6,138,12,14,'#e8e8e8'); rgArrow(c,x,224,b.k,9,'#fff'); });
  rect(c,40,60,200,50,'#f6ecd0'); s.rec.forEach((r,i)=>{ circ(c,70+i*34,85,11,TN_COL[r].c); if(i<s.i) mgT(c,'ok',70+i*34,85,10,'#fff'); });
  c.fillStyle='#a8d0e0'; c.beginPath(); c.moveTo(330,90); c.lineTo(420,90); c.lineTo(440,196); c.lineTo(310,196); c.fill();
  const fy=196-100*s.fill; c.fillStyle=s.i>0?TN_COL[s.rec[s.i-1]].c:'#ccc'; c.fillRect(316,fy,118,196-fy);
  if(s.ph==='mix') mgBar(c,330,70,90,8,1-s.t/s.lim,'#f2c230');
  mgDuck(c,470,205,1.1,null,-1);
 }
};

/* Provisions: fit each item into the satchel with room for it */
MG.satchel={
 hint:'Send each item to the satchel with enough room. Left, Up or Right.', keys:'Left / Up / Right',
 how:['Three satchels have different room left.','Each item has a weight on it.','Send it to a satchel it fits in, without wasting the big gap.'],
 hud:s=>'Packed '+s.n+'/10  |  Good '+s.ok,
 init(s){ s.n=0; s.ok=0; s.fx=0; this.newBags(s); this.item(s); },
 newBags(s){ s.bag=[0,0,0].map(()=>({cap:6+((Math.random()*3)|0),use:0})); },
 item(s){ s.w=1+((Math.random()*5)|0); },
 press(s,k){
  const i={left:0,up:1,right:2}[k]; if(i===undefined||s.done) return;
  const b=s.bag[i], room=b.cap-b.use;
  if(s.w<=room){ b.use+=s.w; s.ok++; s.msg='Packed'; mgTone(1); s.fx=1; } else { s.msg='Does not fit!'; mgTone(0); }
  s.n++; if(s.n>=10){ s.done=1; s.score=s.ok; return; }
  if(s.bag.every(x=>x.cap-x.use<1)) this.newBags(s); else if(s.n%4===0) s.bag.forEach(x=>{ if(x.cap-x.use<1) x.use=0; });
  this.item(s);
 },
 update(s,dt){ s.fx=Math.max(0,s.fx-dt*3); },
 draw(s,c,t){
  mgSky(c,'#e6dcc0','#d4c49a'); rect(c,0,205,MGW,65,'#9a7a4a'); rect(c,0,205,MGW,4,'#6a4a2a');
  s.bag.forEach((b,i)=>{ const x=110+i*130; rect(c,x-40,100,80,100,'#8a6a3a'); rect(c,x-40,96,80,10,'#6a4a22');
   const f=b.use/b.cap; rect(c,x-34,194-88*f,68,88*f,'#c9a24a'); mgT(c,(b.cap-b.use)+' left',x,86,13,'#4a3418'); rgArrow(c,x,222,['left','up','right'][i],10,'#4a3418'); });
  rect(c,222,30,36,36,'#e0452f'); mgT(c,String(s.w),240,48,22,'#fff');
  mgDuck(c,40,210,1.2);
 }
};
