'use strict';
/* ===== EMBERWICK: tile art =====
   The castle, the palisade, the church and archive, lanterns, banners, monuments and the Great Hearth. */

function redLocal(x,y){ return [x-RX0,y-RY0]; }
function rGround(c,x,y,px,py){ drawGround(c,x,y,px,py,RED_STYLE,0); }
function rIsCastleTile(x,y){ const t=tileAt(x,y); return t===RCROOF||t===RCSTONE||t===RCWIN||t===RCGATE; }
function castleOpenNow(){ const s=g.story; return !!(s&&s.castleOpen&&!s.ch3Met); }

function drawRPalisade(c,x,y,px,py){
  rGround(c,x,y,px,py);
  const lx=x-RX0, ly=y-RY0, horiz=(ly===0||ly===RH-1);
  ell(c,px+16,py+30,15,3,'rgba(0,0,0,0.22)');
  for(let i=0;i<4;i++){
    const bx=px+i*8, top=py+2+((hash(x,i,7800)*5)|0)-(horiz&&ly===0?0:0);
    rect(c,bx,top+4,7,TS-top+py-3,(i&1)?'#6b3a2a':'#74402e');
    c.fillStyle=(i&1)?'#6b3a2a':'#74402e'; c.beginPath(); c.moveTo(bx,top+4); c.lineTo(bx+3.5,top-3); c.lineTo(bx+7,top+4); c.fill();
    rect(c,bx+5,top+4,2,TS-top+py-3,'rgba(0,0,0,0.22)');
    rect(c,bx+1,top+6,1,18,'rgba(255,200,150,0.13)');
  }
  rect(c,px,py+13,TS,3,'#4a2a20'); rect(c,px,py+23,TS,3,'#4a2a20');
  void lx;
}
function drawRPost(c,x,y,px,py,time,objs){
  rGround(c,x,y,px,py);
  objs.push({y:py+TS,k:'fn',f:()=>{
    ell(c,px+16,py+30,9,3,'rgba(0,0,0,0.25)');
    rect(c,px+11,py-26,10,56,'#5a2f22'); rect(c,px+11,py-26,3,56,'#74402e'); rect(c,px+9,py-28,14,4,'#3a1d15'); rect(c,px+9,py+6,14,3,'#3a1d15');
    const sw=Math.sin(time*1.6+x)*1.2;
    rect(c,px+15,py-34,2,8,'#3a1d15');
    ell(c,px+16+sw,py-40,7,8,'#d9382a'); ell(c,px+16+sw,py-40,4.5,6,'#ff7a3a'); rect(c,px+13+sw,py-48,6,2,'#3a1d15'); rect(c,px+13+sw,py-33,6,2,'#3a1d15');
    circ(c,px+16+sw,py-40,18,'rgba(255,90,40,'+(0.13+0.03*Math.sin(time*3+x)).toFixed(2)+')');
  }});
  if(NIGHT>0.05) lights.push({x:px+16,y:py-36,r:120,s:0.85,w:1});
}
function drawRCStone(c,x,y,px,py){
  kStoneBase(c,x,y,px,py,'#a2503f','#7f3a2e');
  rect(c,px,py,TS,2,'rgba(255,255,255,0.10)'); rect(c,px,py+TS-3,TS,3,'rgba(0,0,0,0.22)');
  if(tileAt(x,y-1)===RCROOF) rect(c,px,py,TS,5,'rgba(0,0,0,0.28)');
  if(hash(x,y,7810)<0.07){ rect(c,px+10,py+8,3,10,'rgba(0,0,0,0.22)'); }
  if(!rIsCastleTile(x-1,y)) rect(c,px,py,2,TS,'rgba(0,0,0,0.3)');
  if(!rIsCastleTile(x+1,y)) rect(c,px+TS-2,py,2,TS,'rgba(0,0,0,0.3)');
}
function drawRCRoof(c,x,y,px,py,time,objs,lx,ly){
  rect(c,px,py,TS,TS,'#6d2328');
  c.fillStyle='#4f1a1e'; for(let i=0;i<4;i++){ c.fillRect(px,py+i*8+6,TS,2); const o=(i&1)?0:16; c.fillRect(px+o,py+i*8,1,6); c.fillRect(px+o+16,py+i*8,1,6); }
  c.fillStyle='rgba(255,170,140,0.10)'; for(let i=0;i<4;i++) c.fillRect(px+((i&1)?3:19),py+i*8+1,8,2);
  const above=tileAt(x,y-1);
  if(above!==RCROOF){
    rect(c,px,py,TS,3,'#a2503f');
    for(let i=0;i<4;i+=2) rect(c,px+i*8+2,py-5,6,6,'#a2503f');
    rect(c,px,py+3,TS,1,'rgba(0,0,0,0.3)');
  }
  if(!rIsCastleTile(x-1,y)||tileAt(x-1,y)!==RCROOF) rect(c,px,py,2,TS,'rgba(0,0,0,0.3)');
  if(tileAt(x+1,y)!==RCROOF) rect(c,px+TS-2,py,2,TS,'rgba(0,0,0,0.3)');
  /* flagpoles on the keep and the two great towers */
  if(above!==RCROOF&&((lx===35&&ly===2)||(lx===21&&ly===3)||(lx===50&&ly===3))){
    const big=(ly===2);
    objs.push({y:py+TS,k:'fn',f:()=>{
      const h=big?44:30; rect(c,px+15,py-h,2,h,'#3a1d15'); circ(c,px+16,py-h,2.5,'#e0b84a');
      const w=Math.sin(time*3+lx)*3; c.fillStyle='#c0392b'; c.beginPath(); c.moveTo(px+17,py-h+2); c.lineTo(px+(big?36:30)+w,py-h+(big?6:5)); c.lineTo(px+(big?34:29)+w*0.5,py-h+(big?18:13)); c.lineTo(px+17,py-h+(big?16:12)); c.closePath(); c.fill();
      circ(c,px+(big?25:23)+w*0.6,py-h+(big?10:8),big?3:2,'#ffd166');
    }});
  }
}
function drawRCWin(c,x,y,px,py){
  kStoneBase(c,x,y,px,py,'#a2503f','#7f3a2e');
  rect(c,px,py+TS-3,TS,3,'rgba(0,0,0,0.22)');
  rect(c,px+8,py+4,16,22,'#3a1d15'); ell(c,px+16,py+6,8,5,'#3a1d15');
  const lit=NIGHT>0.12;
  rect(c,px+10,py+7,12,17,lit?'#ffc46a':'#4a5a7a'); c.fillStyle='#3a1d15'; c.fillRect(px+15,py+7,2,17); c.fillRect(px+10,py+14,12,2);
  if(lit) lights.push({x:px+16,y:py+16,r:64,s:0.7,w:0.8});
}
function drawRCGate(c,x,y,px,py,time,objs){
  const lx=x-RX0, ly=y-RY0, gx=lx-35, gy=ly-12, open=castleOpenNow();
  kStoneBase(c,x,y,px,py,'#8a4034','#6f3026');
  rect(c,px,py,TS,TS,'#2a1410');
  /* the arch frame */
  if(gy===0){ rect(c,px,py,TS,5,'#c9a24a'); }
  if(gx===0) rect(c,px,py,3,TS,'#c9a24a'); else rect(c,px+TS-3,py,3,TS,'#c9a24a');
  const dx=gx===0?3:0, dw=TS-3;
  if(open){
    rect(c,px+dx,py+(gy===0?5:0),dw,TS,'#1a0c0a');
    /* red carpet running in */
    rect(c,px+(gx===0?10:0),py+(gy===0?5:0),gx===0?22:22,TS,'#a8232f');
    rect(c,px+(gx===0?30:2),py+(gy===0?5:0),2,TS,'#e0b84a');
    const lg=c.createLinearGradient(0,py,0,py+TS); lg.addColorStop(0,'rgba(255,170,80,0.18)'); lg.addColorStop(1,'rgba(255,170,80,0)'); c.fillStyle=lg; c.fillRect(px,py,TS,TS);
  } else {
    rect(c,px+dx,py+(gy===0?5:0),dw,TS,'#4a2a1a');
    c.fillStyle='#331c12'; for(let i=0;i<4;i++) c.fillRect(px+dx+i*8+(gx===0?0:0),py+(gy===0?5:0),1,TS);
    rect(c,px+dx,py+9+(gy===0?3:0),dw,3,'#7d838c'); rect(c,px+dx,py+22+(gy===0?3:0),dw,3,'#7d838c');
    if(gx===0) rect(c,px+TS-3,py,3,TS,'#1a0c0a');
    else rect(c,px,py,3,TS,'#1a0c0a');
    if(gy===0){ /* the ember sigil over the doors */
      const gl=0.6+0.4*Math.sin(time*3);
      const cx=gx===0?px+TS:px;
      circ(c,cx,py+15,6,'#7a1f1f'); circ(c,cx,py+15,4,'rgba(255,140,50,'+gl.toFixed(2)+')'); circ(c,cx,py+15,1.8,'#fff3c4');
    }
    if(gy===1){ circ(c,gx===0?px+27:px+5,py+14,2,'#e0b84a'); }
  }
  if(gy===1&&NIGHT>0.05) lights.push({x:px+(gx===0?32:0),y:py,r:90,s:0.55,w:0.7});
}
function drawRBuilding(c,x,y,t,px,py,time,objs){
  const lx=x-RX0, ly=y-RY0, b=redBuildingAtLocal(lx,ly);
  if(!b){ rGround(c,x,y,px,py); rect(c,px,py,TS,TS,'#888'); return; }
  const row=ly-b.ly, col=lx-b.lx, roofRows=b.h-2, church=b.type==='church', school=b.type==='school';
  if(t===RBROOF){
    rect(c,px,py,TS,TS,b.roof);
    c.fillStyle='rgba(0,0,0,0.2)'; for(let i=0;i<4;i++) c.fillRect(px,py+i*8+6,TS,2);
    c.fillStyle='rgba(255,255,255,0.12)'; for(let i=0;i<4;i++){ const o=(i&1)?0:16; c.fillRect(px+o,py+i*8,2,6); c.fillRect(px+o+16,py+i*8,2,6); }
    if(row===0) rect(c,px,py,TS,3,'rgba(255,255,255,0.28)');
    if(col===0) rect(c,px,py,2,TS,'rgba(0,0,0,0.3)'); if(col===b.w-1) rect(c,px+TS-2,py,2,TS,'rgba(0,0,0,0.3)');
    if(church&&row===1&&(col===5||col===6)){
      /* the great flame emblem splits across two tiles */
      const sx=col===5?px+TS:px;
      c.fillStyle='#f6b04a'; c.beginPath(); c.moveTo(sx-12,py+30); c.quadraticCurveTo(sx-14,py+6,sx,py-8); c.quadraticCurveTo(sx+14,py+6,sx+12,py+30); c.closePath(); c.fill();
      c.fillStyle='#ffe9a8'; c.beginPath(); c.moveTo(sx-6,py+30); c.quadraticCurveTo(sx-7,py+12,sx,py+4); c.quadraticCurveTo(sx+7,py+12,sx+6,py+30); c.closePath(); c.fill();
    }
    if(school&&row===1&&col===4){
      const sx=px+16; c.fillStyle='#e8d8ff'; c.beginPath(); for(let k=0;k<10;k++){ const r=k%2?5:13, a=-1.5708+k*0.6283; c.lineTo(sx+Math.cos(a)*r,py+16+Math.sin(a)*r); } c.closePath(); c.fill(); circ(c,sx,py+16,3,'#7a5ad6');
    }
    if(!church&&!school&&row===1&&(col===4||col===5)){
      const sx=col===4?px+TS:px;
      rect(c,sx-12,py+6,24,18,'#f4efe0'); rect(c,sx-12,py+6,3,18,'#a8432b'); rect(c,sx-6,py+10,14,2,'#5a3a4a'); rect(c,sx-6,py+14,14,2,'#5a3a4a'); rect(c,sx-6,py+18,9,2,'#5a3a4a');
    }
    if(church&&row===0&&col===6){
      objs.push({y:py+TS,k:'fn',f:()=>{
        const f=Math.sin(time*7)*1.5; rect(c,px+15,py-14,2,16,'#3a1d15');
        c.fillStyle='#ff7a2a'; c.beginPath(); c.moveTo(px+9,py-12); c.quadraticCurveTo(px+11,py-26+f,px+16,py-34+f); c.quadraticCurveTo(px+22,py-24,px+23,py-12); c.fill();
        c.fillStyle='#ffd166'; c.beginPath(); c.moveTo(px+12,py-12); c.quadraticCurveTo(px+14,py-20,px+16,py-24+f); c.quadraticCurveTo(px+19,py-19,px+20,py-12); c.fill();
        circ(c,px+16,py-20,24,'rgba(255,140,60,0.10)');
      }});
      if(NIGHT>0.05) lights.push({x:px+16,y:py-14,r:120,s:0.7,w:1});
    }
    return;
  }
  rect(c,px,py,TS,TS,b.wall);
  c.fillStyle='rgba(0,0,0,0.08)'; c.fillRect(px,py+10,TS,1); c.fillRect(px,py+21,TS,1);
  if(row===roofRows) rect(c,px,py,TS,4,'rgba(0,0,0,0.22)');
  if(col===0) rect(c,px,py,2,TS,'rgba(0,0,0,0.16)'); if(col===b.w-1) rect(c,px+TS-2,py,2,TS,'rgba(0,0,0,0.16)');
  const night=NIGHT>0.12;
  if(t===RBWIN){
    rect(c,px+7,py+2,18,26,'#5a2f22'); ell(c,px+16,py+4,9,5,'#5a2f22');
    const cols=church?['#c0392b','#e0b84a','#d9602a','#e0b84a']:school?['#7a5ad6','#a98aff','#7a5ad6','#a98aff']:['#e8c76a','#d9b25a','#e8c76a','#d9b25a'];
    rect(c,px+9,py+5,6,10,cols[0]); rect(c,px+17,py+5,6,10,cols[1]); rect(c,px+9,py+17,6,9,cols[2]); rect(c,px+17,py+17,6,9,cols[3]);
    if(!night&&church){ rect(c,px+9,py+5,6,10,'#9c3a30'); rect(c,px+17,py+17,6,9,'#c9a23a'); }
    rect(c,px+15,py+4,2,23,'#5a2f22'); rect(c,px+9,py+15,14,2,'#5a2f22');
    if(night||church) lights.push({x:px+16,y:py+16,r:church?70:56,s:night?0.8:0.2,w:night?0.9:0});
  } else if(t===RBDOOR){
    rect(c,px+3,py+1,26,31,'#3a1d15'); ell(c,px+16,py+5,13,6,'#3a1d15');
    rect(c,px+5,py+6,10,26,'#7b4a22'); rect(c,px+17,py+6,10,26,'#7b4a22');
    rect(c,px+15,py+3,2,29,'#3a1d15'); rect(c,px+5,py+14,22,2,'#c9a24a'); rect(c,px+5,py+24,22,2,'#c9a24a');
    circ(c,px+13,py+20,1.6,'#ffd166'); circ(c,px+19,py+20,1.6,'#ffd166');
    const gl=0.6+0.4*Math.sin(time*3);
    if(church){ c.fillStyle='rgba(255,150,60,'+gl.toFixed(2)+')'; c.beginPath(); c.moveTo(px+11,py+12); c.quadraticCurveTo(px+13,py+3,px+16,py-1); c.quadraticCurveTo(px+19,py+3,px+21,py+12); c.fill(); }
    else if(school){ circ(c,px+16,py+7,4,'#d8c8ff'); rect(c,px+15,py+2,2,10,'#d8c8ff'); rect(c,px+11,py+6,10,2,'#d8c8ff'); }
    else { rect(c,px+10,py+3,12,8,'#f4efe0'); rect(c,px+10,py+3,2,8,'#a8432b'); }
    lights.push({x:px+16,y:py+20,r:80,s:night?0.7:0.2,w:night?0.8:0});
  } else {
    /* plain wall: a few cracks and a stone course */
    if(hash(x,y,7820)<0.12) rect(c,px+12,py+6,2,12,'rgba(0,0,0,0.12)');
  }
}
function drawRLant(c,x,y,px,py,time,objs){
  rGround(c,x,y,px,py);
  objs.push({y:py+TS,k:'fn',f:()=>{
    ell(c,px+16,py+30,7,2.5,'rgba(0,0,0,0.25)');
    rect(c,px+15,py-10,3,40,'#4a2a20'); rect(c,px+11,py-10,11,3,'#4a2a20');
    const sw=Math.sin(time*1.8+x*0.7)*1.2;
    rect(c,px+16,py-7,1,4,'#4a2a20');
    ell(c,px+16.5+sw,py-1,5.5,7,'#d9382a'); ell(c,px+16.5+sw,py-1,3.2,5,'#ff8a3a'); rect(c,px+14+sw,py-8,5,1.6,'#3a1d15'); rect(c,px+14+sw,py+5,5,1.6,'#3a1d15');
    circ(c,px+16.5+sw,py-1,17,'rgba(255,100,40,'+(0.12+0.03*Math.sin(time*3+x)).toFixed(2)+')');
  }});
  if(NIGHT>0.05) lights.push({x:px+16,y:py-2,r:150,s:0.9,w:1});
}
function drawRBanner(c,x,y,px,py,time,objs){
  rGround(c,x,y,px,py);
  objs.push({y:py+TS,k:'fn',f:()=>{
    ell(c,px+16,py+30,8,3,'rgba(0,0,0,0.25)');
    rect(c,px+15,py-34,3,64,'#4a2a20'); circ(c,px+16.5,py-35,3,'#e0b84a'); rect(c,px+8,py-30,17,2,'#4a2a20');
    const w=Math.sin(time*2.2+x)*2;
    c.fillStyle='#b5322a'; c.beginPath(); c.moveTo(px+9,py-28); c.lineTo(px+24,py-28); c.lineTo(px+24+w,py+0); c.lineTo(px+16.5+w*0.6,py-6); c.lineTo(px+9+w*0.3,py+0); c.closePath(); c.fill();
    c.fillStyle='#ffb347'; c.beginPath(); c.moveTo(px+16.5+w*0.3,py-24); c.quadraticCurveTo(px+11,py-14,px+16.5+w*0.3,py-8); c.quadraticCurveTo(px+22,py-14,px+16.5+w*0.3,py-24); c.fill();
  }});
}
function drawRHearth(c,x,y,px,py,time,objs){
  const lx=x-RX0, ly=y-RY0, left=(lx===35), top=(ly===29);
  drawPlaza(c,x,y,px,py,RED_STYLE);
  /* stone basin quarter */
  const ox=left?px+8:px, ow=TS-8, oy=top?py+8:py, oh=TS-8;
  rect(c,ox,oy,ow,oh,'#6f6a6a'); rect(c,ox+(left?0:ow-3),oy,3,oh,'#8a8484'); rect(c,ox,oy+(top?0:oh-3),ow,3,'#8a8484');
  rect(c,ox+(left?3:0),oy+(top?3:0),ow-3,oh-3,'#2a1410');
  if(left&&top){
    objs.push({y:py+TS*2,k:'fn',f:()=>{
      const cx=px+TS, cy=py+TS;
      ell(c,cx,cy+8,26,10,'rgba(0,0,0,0.25)');
      const f1=Math.sin(time*8)*3, f2=Math.sin(time*12+1)*2.4, f3=Math.sin(time*5+2)*2;
      c.fillStyle='#e0502a'; c.beginPath(); c.moveTo(cx-24,cy+14); c.quadraticCurveTo(cx-22+f2,cy-16,cx-8,cy-34+f1); c.quadraticCurveTo(cx+0,cy-48+f3,cx+8,cy-34+f1); c.quadraticCurveTo(cx+22-f2,cy-14,cx+24,cy+14); c.closePath(); c.fill();
      c.fillStyle='#ff9d2e'; c.beginPath(); c.moveTo(cx-16,cy+14); c.quadraticCurveTo(cx-14,cy-12,cx-4,cy-24+f2); c.quadraticCurveTo(cx+2,cy-34+f1,cx+6,cy-24+f2); c.quadraticCurveTo(cx+16,cy-10,cx+16,cy+14); c.closePath(); c.fill();
      c.fillStyle='#ffd166'; c.beginPath(); c.moveTo(cx-8,cy+14); c.quadraticCurveTo(cx-7,cy-4,cx,cy-14+f3); c.quadraticCurveTo(cx+7,cy-4,cx+8,cy+14); c.closePath(); c.fill();
      c.fillStyle='#fff3c4'; c.beginPath(); c.moveTo(cx-3,cy+14); c.quadraticCurveTo(cx-2,cy+4,cx,cy-2); c.quadraticCurveTo(cx+2,cy+4,cx+3,cy+14); c.closePath(); c.fill();
      for(let i=0;i<8;i++){ const tt=(time*0.5+i*0.125)%1; c.fillStyle='rgba(255,'+(150+((i*17)%80))+',80,'+(1-tt).toFixed(2)+')'; c.fillRect(cx-18+i*5+Math.sin(tt*6+i)*5,cy-12-tt*58,2,2); }
    }});
    lights.push({x:px+TS,y:py+TS,r:260,s:1,w:1.5});
  }
}
function rMonKind(x,y){ return RMONS[(x-RX0)+','+(y-RY0)]; }
function drawRMon(c,x,y,px,py,time,objs){
  const k=rMonKind(x,y);
  rGround(c,x,y,px,py);
  if(k==='founders'){
    const l=rMonKind(x-1,y)==='founders', r=rMonKind(x+1,y)==='founders';
    ell(c,px+16,py+29,15,3,'rgba(0,0,0,0.22)');
    rect(c,px+(l?0:3),py+6,TS-(l?0:3)-(r?0:3),22,'#8a8484'); rect(c,px+(l?0:3),py+6,TS-(l?0:3)-(r?0:3),3,'#a8a2a2');
    c.fillStyle='rgba(40,30,30,0.55)'; for(let i=0;i<4;i++){ c.fillRect(px+(l?3:6)+((i*7)%14),py+12+i*4,8-((i*3)%4),1); }
    if(hash(x,y,7830)<0.5) rect(c,px+20,py+18,3,6,'#b5322a');
    return;
  }
  objs.push({y:py+TS,k:'fn',f:()=>{
    ell(c,px+16,py+30,13,4,'rgba(0,0,0,0.25)');
    if(k==='march'){
      rect(c,px+3,py+21,26,9,'#7d7676'); rect(c,px+3,py+21,26,3,'#a29a9a');
      const bz='#a85a3a', bz2='#7a3f28';
      /* parent walking, duckling on its back */
      ell(c,px+14,py+8,10,6,bz); ell(c,px+12,py+8,6,3.5,bz2);
      rect(c,px+8,py+12,3,9,bz2); rect(c,px+17,py+12,3,9,bz2);
      c.fillStyle=bz; c.beginPath(); c.moveTo(px+20,py+6); c.lineTo(px+24,py-6); c.lineTo(px+28,py-5); c.lineTo(px+25,py+7); c.fill(); circ(c,px+27,py-7,4,bz); rect(c,px+29,py-7,5,2.5,'#7a3f28');
      ell(c,px+10,py+1,4,3,'#c27a52'); circ(c,px+13,py-3,2.5,'#c27a52'); rect(c,px+15,py-3,3,1.5,'#7a3f28');
      rect(c,px+4,py+3,2,12,'#4a2a20'); rect(c,px+2,py+0,7,5,'#d9382a'); rect(c,px+3,py+1,5,3,'#ff9d2e');
    } else if(k==='empty'){
      rect(c,px+8,py-14,16,42,'#8f8a8a'); rect(c,px+8,py-14,16,3,'#b3adad'); rect(c,px+8,py-14,3,42,'#a29c9c');
      rect(c,px+12,py-6,8,22,'#4a4646'); rect(c,px+13,py-5,6,20,'#3a3636');
      rect(c,px+6,py+6,20,3,'#b5322a'); rect(c,px+22,py+6,3,14,'#b5322a');
    } else if(k==='bell'){
      rect(c,px+3,py-16,3,46,'#4a2a20'); rect(c,px+26,py-16,3,46,'#4a2a20'); rect(c,px+1,py-18,30,4,'#5a2f22');
      const sw=Math.sin(time*1.4)*2.2;
      rect(c,px+15,py-14,2,6,'#3a1d15');
      c.fillStyle='#c9a24a'; c.beginPath(); c.moveTo(px+10+sw,py+6); c.quadraticCurveTo(px+11+sw,py-8,px+16+sw,py-9); c.quadraticCurveTo(px+21+sw,py-8,px+22+sw,py+6); c.closePath(); c.fill();
      rect(c,px+9+sw,py+5,14,3,'#e0b84a'); circ(c,px+16+sw,py+10,2,'#7a5a1a');
    }
  }});
}
function drawRCold(c,x,y,px,py,time,objs){
  rGround(c,x,y,px,py);
  const idx=RCOLDPOS.findIndex(p=>p[0]+RX0===x&&p[1]+RY0===y);
  ell(c,px+16,py+27,14,5,'rgba(0,0,0,0.25)');
  for(let i=0;i<8;i++){ const a=i*0.785; ell(c,px+16+Math.cos(a)*10.5,py+25+Math.sin(a)*4,4,3,'#6b6f78'); }
  ell(c,px+16,py+24,8,3.4,'#2a2624'); rect(c,px+9,py+21,14,3,'#1c1816');
  for(let i=0;i<2;i++){ const tt=(time*0.22+i*0.5+hash(x,0,5)*1)%1; ell(c,px+16+Math.sin(time*0.8+i*2)*2,py+16-tt*20,2.2+tt*3,1.6+tt*2,'rgba(175,175,188,'+(0.36*(1-tt)).toFixed(2)+')'); }
  c.fillStyle='#c9a24a'; c.font='700 8px ui-monospace,"Courier New",monospace'; c.textAlign='center'; c.textBaseline='middle';
  rect(c,px+12,py+27,8,5,'#3a2a1a'); c.fillStyle='#e0b84a'; c.fillText(String(idx+1),px+16,py+30);
}

/* ---------- wiring ---------- */
{
  const _drawPlaza=drawPlaza;
  drawPlaza=function(c,x,y,px,py,st){
    if(st&&st.plaza==='ember'){
      rect(c,px,py,TS,TS,((x+y)&1)?'#8a4a3a':'#84453a');
      c.fillStyle='#5e2f27'; c.fillRect(px,py+15,TS,2); c.fillRect(px,py,TS,1);
      const o=((x+y)&1)?8:20; c.fillRect(px+o,py,2,16); c.fillRect(px+((o+16)%32),py+16,2,16);
      rect(c,px+4,py+3,6,2,'#a8604c');
      if(hash(x,y,7840)<0.18){ rect(c,px+((hash(x,y,7841)*24)|0),py+((hash(x,y,7842)*24)|0),2,2,'rgba(255,150,60,0.55)'); }
      return;
    }
    _drawPlaza(c,x,y,px,py,st);
  };
  const _drawKTile=drawKTile;
  drawKTile=function(c,x,y,t,px,py,time,objs,night){
    switch(t){
      case RWALL: drawRPalisade(c,x,y,px,py); return;
      case RPOST: drawRPost(c,x,y,px,py,time,objs); return;
      case RCSTONE: drawRCStone(c,x,y,px,py); return;
      case RCROOF: drawRCRoof(c,x,y,px,py,time,objs,x-RX0,y-RY0); return;
      case RCWIN: drawRCWin(c,x,y,px,py); return;
      case RCGATE: drawRCGate(c,x,y,px,py,time,objs); return;
      case RBROOF: case RBWALL: case RBWIN: case RBDOOR: drawRBuilding(c,x,y,t,px,py,time,objs); return;
      case RLANT: drawRLant(c,x,y,px,py,time,objs); return;
      case RBANNER: drawRBanner(c,x,y,px,py,time,objs); return;
      case RHEARTH: drawRHearth(c,x,y,px,py,time,objs); return;
      case RMON: drawRMon(c,x,y,px,py,time,objs); return;
      case RCOLD: drawRCold(c,x,y,px,py,time,objs); return;
    }
    _drawKTile(c,x,y,t,px,py,time,objs,night);
  };
  /* signs over the three grand buildings */
  const _drawWorld=drawWorld;
  drawWorld=function(c,W,H,kd,camX,camY,time){
    _drawWorld(c,W,H,kd,camX,camY,time);
    if(!(g.story&&g.story.redOpen)||g.scene!=='world') return;
    if(Math.abs(g.px/TS-(RX0+36))>40||Math.abs(g.py/TS-(RY0+28))>30) return;
    const vw=W/kd, vh=H/kd, ox=Math.round((camX-vw/2)*kd)/kd, oy=Math.round((camY-vh/2)*kd)/kd;
    c.setTransform(kd,0,0,kd,-ox*kd,-oy*kd);
    const t=getRed();
    const plaque=(txt,cx,cy,lit)=>{
      let fs=12; c.textAlign='center'; c.textBaseline='middle';
      do{ c.font='600 '+fs+'px ui-monospace,"Courier New",monospace'; fs--; }while(fs>7&&c.measureText(txt).width>TS*7);
      const w=c.measureText(txt).width+10;
      rect(c,cx-w/2,cy-8,w,16,'rgba(40,14,10,0.9)'); c.strokeStyle=lit?'#ffcf9a':'#b08a74'; c.lineWidth=1; c.strokeRect(cx-w/2+0.5,cy-7.5,w-1,15);
      c.fillStyle=lit?'#ffcf9a':'#b08a74'; c.fillText(txt,cx,cy+1);
    };
    for(const b of t.specials){
      if(b.isCastle) plaque(b.name,(RX0+36)*TS,(RY0+11.2)*TS,true);
      else if(b.type==='church') plaque(b.name,(b.x+b.doorCol+0.5)*TS,(b.doorY-0.6)*TS,true);
      else if(b.type==='school') plaque(b.name,(b.x+b.doorCol+0.5)*TS,(b.doorY-0.6)*TS,schoolOpen());
      else if(b.type==='library') plaque(b.name,(b.x+b.doorCol+0.5)*TS,(b.doorY-0.6)*TS,archiveOpen());
    }
    c.setTransform(1,0,0,1,0,0);
  };
}
