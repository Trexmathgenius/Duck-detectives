'use strict';
/* ===== LESSONS ARE PROBLEMS, NOT QUIZZES (v1.24) =====
   A verse is taught once, plainly, the same way for every verse: the master tells you what they saw in you, and then what the verse is.
   Then the master conjures a problem into the room, and you solve it by casting the verse. No multiple choice. The problem is shaped
   like the verse: it can be solved the right way, it can be solved the wrong way and taught from, and it cannot be solved by luck. */

const PR={on:false,v:null,ctx:null,done:null,win:null,M:'',ret:null,std:false,onCast:null};
const pracFx=(S,x,y,col,n)=>{ (S.fx=S.fx||[]).push({x:x,y:y,b:null,col:col||'#fff3b0',n:n||18}); };
function pracDraw(c,S,time,layer){
  if(layer!=='over'||!S.fx) return;
  S.fx=S.fx.filter(f=>{
    if(f.b===null) f.b=time; const a=time-f.b; if(a>1.1) return false;
    const k=a/1.1;
    c.save(); c.globalAlpha=1-k; c.strokeStyle=f.col; c.lineWidth=2.4; c.beginPath(); c.arc(f.x,f.y,6+k*52,0,6.283); c.stroke();
    c.beginPath(); c.arc(f.x,f.y,3+k*30,0,6.283); c.stroke();
    c.fillStyle=f.col; for(let i=0;i<f.n;i++){ const an=i/f.n*6.283+f.b, r=4+k*(38+(i%3)*10); c.beginPath(); c.arc(f.x+Math.cos(an)*r,f.y+Math.sin(an)*r-k*14,1.6*(1-k)+0.4,0,6.283); c.fill(); }
    c.restore(); return true;
  });
}
const pracReset=S=>{ for(const k of Object.keys(S.fl)) delete S.fl[k]; };
const pracNpcAt=(S)=>{ const v=DIRV[g.dir], fx=g.px+v.x*14, fy=g.py-6+v.y*14; for(const n of S.npcs){ if(n.when&&!n.when(S)) continue; if(Math.hypot(n.x-fx,(n.y-8)-fy)<20) return n; } return null; };

/* the teacher is in every room, and is the way out */
function pracTeacher(M,tx,ty,task){
  return {name:M,tx:tx,ty:ty,pal:RED_PALS[1],head:'wizard',dir:'down',talk:(S,n)=>{
    choose(M,'Yes?',['What am I meant to do?','Say the verse to me again.','I would like to stop for now.','Nothing.'],k=>{
      if(k===0) say(M,[task(S)]);
      else if(k===1) say(M,PR.v.pages||TEACH[PR.v.n].pages);
      else if(k===2) say(M,['"Of course. The problem will keep. It is, I am told, very patient."'],()=>pracLeave(false));
    },3);
  }};
}
/* the common shell of a practice room */
function pracRoom(v,M,o){
  return {name:o.name,theme:o.theme||'archive',indoor:true,dark:o.dark||0,lightR:o.lightR||80,start:o.start||[1,4,'right'],
    rows:o.rows,exits:Object.assign({D:{fn:S=>{ if(S.fl.won) return; say(M,['"Leaving? The problem stays. Come back for it, or stay and finish it."'],()=>{ choose(M,'Leave the practice room?',['Leave for now','Stay'],k=>{ if(k===0) pracLeave(false); },1); }); }}},o.exits||{}),
    objs:o.objs,npcs:[pracTeacher(M,o.teacher[0],o.teacher[1],o.task)].concat(o.npcs||[]),guards:o.guards||[],doors:o.doors||[],
    tick:o.tick,draw:(c,S,time,layer)=>{ pracDraw(c,S,time,layer); if(o.draw) o.draw(c,S,time,layer); },
    seek:o.seek,onSeek:o.onSeek,trig:o.trig,caughtLines:o.caughtLines,hint:o.hint,
    onEnter:S=>{ pracReset(S); if(o.init) o.init(S); sxSay(S,M,o.intro,()=>{ toast('Q and E choose a spell, C casts it at whatever you are facing.',5200); if(o.afterIntro) o.afterIntro(S); }); }};
}

/* -------------------------------------------------------------- the eight problems */
const PRAC={};

/* 1. TRUTHLIGHT: one of four doors is real. Three are paint. Light the room, not the face. */
PRAC.Truthlight=(v,M)=>{
  const keys=['a','b','c','d'], ys=[1,3,5,7];
  const door=k=>({name:'A door',glyph:'door',solid:true,col:'#7a4a24',
    desc:'A tall oak door with a brass handle. It looks exactly like a door.',
    when:S=>!S.fl['x'+k],
    use:(S,o)=>{
      if(S.fl.real!==k){ sxSay(S,'',['You put your wing on the handle. The handle is paint. So is the wall behind it. You are a duck leaning on a drawing.'],()=>{ sxSay(S,M,['"A guess, Detective. Guesses are how doors are chosen by people who do not look."']); }); return; }
      if(!S.fl.found){ sxSay(S,M,['"Is that a guess, or a knowing? Ask the light, and then ask the door."']); return; }
      sxSay(S,'',['The handle is cold brass. The door opens onto a cupboard of real chalk, a real ink-pot, and an expression of calm.'],()=>pracWin(S,['"That is Truthlight. Not a lamp, which shows everything and cares about nothing, but a light that is asked, and answers.','Three of those doors were mine, and I am rather proud of them. The fourth was a door. You knew which was which because you asked.','Take the verse. It is yours."']));
    },
    cast:{Truthlight:(S,o,tx,ty)=>{
      pracFx(S,(tx+0.5)*TS,(ty+0.5)*TS,'#fff3b0',24);
      if(S.fl.real===k){ S.fl.found=1; toast('The light settles on the door and does not flinch. This one is real.',3800); }
      else { S.fl['x'+k]=1; toast('The light goes through the door like a draught through a drawing. Paint.',3600); }
    }}
  });
  const objs={}; keys.forEach(k=>{ objs[k]=door(k); });
  const pip={name:'Pip',tx:4,ty:7,pal:PALS[2],dir:'up',talk:(S,n)=>say('Pip',['"I am not allowed to say which door. The Mistress says a clue is a kind of lie when it is given too early."']),
    cast:{Truthlight:(S,n)=>{ pracFx(S,n.x,n.y-16,'#fff3b0',16); sxSay(S,'Pip',['(The light finds Pip\'s face. Pip winces, and then, with enormous dignity, sneezes.)'],()=>sxSay(S,M,['"Room, Detective. Not the face. The face is a person; the room is a place. You will thank me in a year."'])); }}};
  return pracRoom(v,M,{name:'The Practice Hall: four doors',theme:'archive',
    rows:sxGrid(15,9,[[0,4,'D'],[13,1,'a'],[13,3,'b'],[13,5,'c'],[13,7,'d']]),
    objs:objs,teacher:[3,2],npcs:[pip],
    task:S=>'"One of the four doors on the east wall is a door. Three are drawings I made this morning. I want the chalk from the real one. Do not guess. Ask."',
    intro:['"There is a cupboard in this hall, and it has a door. I have also, as a courtesy, hung three that are not.','Ask the light. Face a door, and cast. When the light does not flinch, that is your door. Then open it."'],
    init:S=>{ S.fl.real=keys[Math.floor(Math.random()*4)]; }});
};

/* 2. SOFTFALL: a child is crying. Ask. Then be quiet. Then, and only then, the petals. */
PRAC.Softfall=(v,M)=>{
  return pracRoom(v,M,{name:'The Practice Hall: a small noise',theme:'archive',
    rows:sxGrid(13,9,[[0,4,'D'],[10,2,'T']]),
    objs:{T:{name:'A broken vase',glyph:'crate',solid:true,col:'#c9a24a',desc:'A blue vase in four pieces. It has been swept into a polite pile.'}},
    teacher:[2,2],
    npcs:[{name:'Pip',tx:7,ty:5,pal:PALS[2],dir:'left',
      talk:(S,n)=>{
        if(S.fl.done){ say('Pip',['"I feel better. I think I will go and apologise to the vase."']); return; }
        if(!S.fl.asked){
          say('Pip',['(Pip is crying, not loudly, in the way that has been going on for some time.)'],()=>{
            choose('Pip','What do you do?',['Ask what is the matter','Tell Pip it will be all right','Walk away'],k=>{
              if(k===0){ S.fl.asked=1; say('Pip',['"I broke her vase. The blue one. I was only dusting. I will be sent home and I have not even finished the first week."'],()=>say('',['(Pip stops. Pip is waiting to see what you say. This is the part where most people say something.)'])); }
              else if(k===1){ say('Pip',['"You do not know that." (The crying gets louder, with an edge of being not listened to.)']); }
            },2);
          }); return;
        }
        if(!S.fl.quiet){
          choose('Pip','Pip is looking at you.',['Say something comforting','Say nothing. Sit beside Pip.'],k=>{
            if(k===0){ S.fl.quiet=0; say('Pip',['"It is not fine. Please do not tell me it is fine."'],()=>sxSay(S,M,['"Ask, then be quiet. The second half is harder."'])); }
            else { S.fl.quiet=1; say('',['(You sit. You say nothing. After a long while Pip\'s breathing evens out. Pip\'s eyes are red, and watchful, and open.)']); }
          },1); return;
        }
        say('Pip',['"..."  (Pip is looking at the floor, and waiting, and not alone.)']);
      },
      cast:{Softfall:(S,n)=>{
        if(!S.fl.asked){ pracFx(S,n.x,n.y-16,'#ffb3d1',12); sxSay(S,'Pip',['(The petals land on someone who has not been asked. Pip flinches, and wipes them off.)'],()=>sxSay(S,M,['"You did not ask. Softfall is not a spell for making people feel better. Begin by asking."'])); return; }
        if(!S.fl.quiet){ pracFx(S,n.x,n.y-16,'#ffb3d1',12); sxSay(S,'Pip',['"Stop... fixing me."'],()=>sxSay(S,M,['"Ask, then be quiet. You are still talking. The petals can tell."'])); return; }
        S.fl.done=1; pracFx(S,n.x,n.y-16,'#ffb3d1',34); pracFx(S,n.x,n.y-8,'#ffe1ee',20);
        sxSay(S,'Pip',['(The petals come down very slowly. Pip does not look up, but one lands in a wing and Pip lets it stay.)','"...Thank you."'],()=>pracWin(S,['"You did not make the room kinder. You made it safe to feel in. That is the whole verse, and it took you less than ten minutes, which is faster than I did it.','If a duck says no, put it away. That is not the verse failing. That is the verse."']));
      }}}],
    task:S=>S.fl.done?'"Done."':!S.fl.asked?'"There is a child in this room who is crying about something. Find out what. Do not fix it."':!S.fl.quiet?'"You have asked. Now: be quiet. Sit beside them. I will wait."':'"Now the verse. Face Pip, and cast."',
    intro:['"There is a very small noise in this room. A student of mine, and a vase of mine, in several pieces.','I did not set this up. I would like you to know that I did not set this up. I merely did not stop it.','Find out, and help. Do not hurry. Softfall is not a spell for making people feel better."']});
};

/* 3. STANDFAST: a shelf is slipping over an old duck. Hold. */
PRAC.Standfast=(v,M)=>{
  return pracRoom(v,M,{name:'The Practice Hall: the shelf',theme:'archive',
    rows:sxGrid(15,9,[[0,4,'D'],[9,1,'W']]),
    objs:{W:{name:'The slipping shelf',glyph:'shelf',solid:true,desc:'A tall oak shelf of ledgers, tilted a hand\'s breadth from true. Something in the wall behind it has given way. It creaks.',
      use:(S,o)=>{ if(S.fl.held){ say('',['It is perfectly still, in a ring of faint runes.']); return; } say('',['It creaks, and you do not touch it. (Whatever holds it now will not be a duck\'s wing.)']); },
      cast:{Standfast:(S,o,tx,ty)=>{
        if(S.fl.held) return; S.fl.held=1; S.timer=null; pracFx(S,(tx+0.5)*TS,(ty+0.5)*TS,'#ffcf8a',28); pracFx(S,g.px,g.py-8,'#ffcf8a',18);
        sxSay(S,'Old Reed',['(Old Reed looks up. The ledgers have stopped sliding. A ring of runes sits round the foot of the shelf, and round your feet, and holds.)','"Oh. Is that the time? I seem to have stopped dying."'],()=>pracWin(S,['"A Standfast is a ring, not a wall. A wall keeps things out. A ring has an inside, and you made the inside for him.','It lasts as long as you remember who it is for. Do not forget him, Detective. He is very old and has the last copy of my handwriting."']));
      }}}},
    teacher:[2,2],
    npcs:[{name:'Old Reed',tx:9,ty:4,pal:PALS[5],dir:'up',talk:(S,n)=>say('Old Reed',['"Do not mind me. I am reading. I have been reading this ledger since before you hatched, and I have not once looked up."','(He has not looked up. Above him, something creaks.)'])}],
    task:S=>'"The shelf above Reed is going to fall. It will take about a minute. Do not push it. Do not carry him. Set your weight beside the hardest thing, and cast Standfast at it."',
    intro:['"Something in that wall has given way. I did not do it; the building is four hundred years old and has opinions.','You have about a minute. I cannot help, and I will not: I am old, and I would rather you learned this from a shelf than from a person."'],
    afterIntro:S=>{ const arm=()=>sxTimer(S,50,'The shelf',()=>{
      if(S.fl.held) return;
      S.fl.slips=(S.fl.slips||0)+1;
      sxSay(S,M,['(There is a groan. The shelf drops two feet, and stops: the Mistress has caught it, at a cost to her dignity.)','"Again. The shelf will wait; the shelf has all the time in the world. I am the one who does not."'],arm);
    }); arm(); }});
};

/* 4. LANTERNWALK: a dark maze, and a lantern that knows who is waiting. */
function pracMaze(seed){
  let s=seed; const rnd=()=>{ s=(s*1664525+1013904223)>>>0; return s/4294967296; };
  const W=17, H=9, g2=[]; for(let y=0;y<H;y++){ g2.push([]); for(let x=0;x<W;x++) g2[y].push('#'); }
  const vis=[]; for(let y=0;y<4;y++){ vis.push([]); for(let x=0;x<8;x++) vis[y].push(false); }
  const st=[[0,0]]; vis[0][0]=true; g2[1][1]='.';
  while(st.length){
    const [cx,cy]=st[st.length-1], nb=[[1,0],[-1,0],[0,1],[0,-1]].filter(d=>{ const nx=cx+d[0], ny=cy+d[1]; return nx>=0&&ny>=0&&nx<8&&ny<4&&!vis[ny][nx]; });
    if(!nb.length){ st.pop(); continue; }
    const d=nb[Math.floor(rnd()*nb.length)], nx=cx+d[0], ny=cy+d[1];
    vis[ny][nx]=true; g2[ny*2+1][nx*2+1]='.'; g2[cy*2+1+d[1]][cx*2+1+d[0]]='.'; st.push([nx,ny]);
  }
  g2[1][0]='D'; g2[7][16]='E';
  return g2.map(r=>r.join(''));
}
function pracPath(S,from,to){
  const rows=S.def.rows, key=(x,y)=>x+','+y, q=[from], prev={}; prev[key(from[0],from[1])]=null;
  while(q.length){
    const [x,y]=q.shift(); if(x===to[0]&&y===to[1]) break;
    for(const d of [[1,0],[-1,0],[0,1],[0,-1]]){ const nx=x+d[0], ny=y+d[1]; if(nx<0||ny<0||ny>=rows.length||nx>=rows[0].length) continue; const ch=rows[ny][nx]; if(ch==='#'||prev[key(nx,ny)]!==undefined) continue; prev[key(nx,ny)]=[x,y]; q.push([nx,ny]); }
  }
  const out=[]; let c=to; if(prev[key(to[0],to[1])]===undefined) return out;
  while(c){ out.unshift(c); c=prev[key(c[0],c[1])]; } return out;
}
PRAC.Lanternwalk=(v,M)=>{
  const rows=pracMaze(41);
  return pracRoom(v,M,{name:'The Practice Hall: the long dark',theme:'crypt',dark:0.94,lightR:46,start:[1,1,'right'],
    rows:rows,
    exits:{E:{fn:S=>{ if(!S.fl.lit){ say('',['A doorway in the dark. Something small, on the far side, is waiting. You cannot tell what. You did not use the verse.'],()=>{ sxSay(S,M,['"You found the end by walking into it. Fine. But a lantern does not know where it is going. It knows who is waiting. Cast it, and let it go ahead of you, and then walk."']); }); return; }
      sxSay(S,'Wren',['(In the dark beyond the doorway, a small shape in a scarf holds a stub of candle and has been holding it for some time.)','"I was only told to wait. I did not know how long. Thank you for coming."'],()=>pracWin(S,['"A lantern goes ahead, and stops, and the reason it stops is usually a person.','Do not follow it for the shortcut. Follow it for the company. You were not looking for the end of a maze. You were looking for Wren."'])); }}},
    objs:{},teacher:[5,1],
    task:S=>'"Somebody is waiting at the far end of this hall, in the dark. I cannot say who. Cast Lanternwalk, and let it go ahead of you."',
    intro:['"Someone is waiting at the far end of the hall. I will not say who, because the lantern knows, and I would like you to ask it.','There is a great deal of dark between here and there. Cast the verse, and be quiet, and then go where it goes."'],
    tick:(S,dt)=>{
      if(S.lant>0){ S.lant-=dt; S.lumen=Math.max(S.lumen||0,0.5); }
      if(S.lant>0){ S.pt=(S.pt||0)-dt; if(S.pt<=0){ S.pt=0.25; S.lpath=pracPath(S,[Math.floor(g.px/TS),Math.floor((g.py-2)/TS)],[16,7]); } }
    },
    draw:(c,S,time,layer)=>{
      S.lantLight=null; if(layer!=='over'||!(S.lant>0)||!S.lpath||S.lpath.length<2) return;
      const p=S.lpath, n=Math.min(p.length-1,14);
      for(let i=1;i<=n;i++){ const q=p[i], a=Math.max(0,1-i/(n+1)); c.save(); c.globalAlpha=a*0.9; c.fillStyle='#ffd98a'; c.beginPath(); c.arc((q[0]+0.5)*TS,(q[1]+0.5)*TS-4,3+Math.sin(time*5+i)*0.8,0,6.283); c.fill(); c.globalAlpha=a*0.25; c.beginPath(); c.arc((q[0]+0.5)*TS,(q[1]+0.5)*TS-4,12,0,6.283); c.fill(); c.restore(); }
      const f=p[Math.min(4,p.length-1)]; S.lantLight={x:(f[0]+0.5)*TS,y:(f[1]+0.5)*TS-10,r:78}; c.save(); c.fillStyle='#fff6c8'; c.beginPath(); c.arc((f[0]+0.5)*TS,(f[1]+0.5)*TS-12+Math.sin(time*3)*2,5,0,6.283); c.fill(); c.restore();
    },
    seek:null});
};
PRAC.Lanternwalk.cast=(S)=>{ S.lant=90; S.fl.lit=1; S.lumen=40; pracFx(S,g.px,g.py-14,'#ffd98a',24); toast('The lantern lights, and drifts ahead, and waits for you.',3600); };

/* 5. QUIETCOAT: pass the proctor without being seen, and without lying. */
PRAC.Quietcoat=(v,M)=>{
  return pracRoom(v,M,{name:'The Practice Hall: the proctor',theme:'tower',start:[1,4,'right'],
    rows:sxGrid(17,9,[[0,4,'D'],[16,4,'E'],[8,1,1,2,'#'],[8,6,1,2,'#']]),
    exits:{E:{fn:S=>{ if(S.fl.won) return;
      sxSay(S,'Porter',['(A porter is sitting by the far door with a clipboard, the way porters do.)','"Evening. Did you use the coat to get past the Proctor?"'],()=>{
        choose('Porter','What do you say?',['Yes. I did. I was quiet, and I did not lie.','No. I just walked in.'],k=>{
          if(k===0){ sxSay(S,'Porter',['"Honest. Hm. Most of them say no." (He ticks a box.)'],()=>pracWin(S,['"You may be quiet. You may not be false. You were both, and you said so when it was inconvenient.','A coat is for the weather. Not for the war. Take it, and keep it on the latch."'])); }
          else { S.caught=(S.caught||0)+1; sxSay(S,M,['(The Porter looks at the Mistress. The Mistress looks at you.)','"The coat makes you uninteresting. It does not make you false. There is a very old distinction between a door left on the latch and a door painted on a wall.','Go back to the start. Take the coat off for a minute and sit in the cold until you remember who you are."'],()=>{ S.veil=0; g.px=1.5*TS; g.py=4.95*TS; }); }
        },1);
      }); }}},
    objs:{},teacher:[2,7],
    npcs:[],
    guards:[{name:'The Proctor',path:[[3,4],[13,4]],speed:30,range:6.5,fov:70,pal:WARDEN_PAL,head:'helm',pause:0.8,scan:true,loop:false}],
    caughtLines:['"WHO\'S THERE?" says the Proctor, and the lamp swings across your face.','"Hm," says the Proctor, not unkindly. "Back you go. The Mistress asked me to be a nuisance."'],
    hint:'The Proctor sees a long way, but the coat makes you uninteresting at a distance. Keep to the walls and cast Quietcoat before you cross his line.',
    task:S=>'"The Proctor patrols the middle of the hall. Get to the far door without being seen. Do not try the coat on the Porter at the end. He is rather good."',
    intro:['"There is a Proctor in this hall, and it is his job to see you, and he is rather good at it.','Go to the far door. Cast the verse first. And: you may be quiet. You may not be false. The Porter at the end will ask."']});
};
PRAC.Quietcoat.cast=(S)=>{ S.veil=Math.max(S.veil||0,90); pracFx(S,g.px,g.py-10,'#b9b3e8',20); toast('The coat settles. You are grey, and quiet, and not a liar.',3400); };

/* 6. REMEMBRANCE: three lost things, three owners. The verse remembers back to you what you ask for. */
PRAC.Remembrance=(v,M)=>{
  const items=[
    {k:'a',x:3,y:2,glyph:'scroll',name:'A green scarf',own:'Dill',clue:'It remembers a long neck, and a window at the back of the room, and a person who is always cold.'},
    {k:'b',x:6,y:2,glyph:'book',name:'A chewed quill',own:'Pip',clue:'It remembers ink on a left wing, and a habit of chewing the end when thinking.'},
    {k:'c',x:9,y:2,glyph:'candle',name:'A hair ribbon',own:'Wren',clue:'It remembers a braid tied by someone else every morning, and never by its owner.'}
  ];
  const objs={};
  items.forEach(it=>{
    objs[it.k]={name:it.name,glyph:it.glyph,key:'it'+it.k,solid:true,when:S=>!S.fl['ret'+it.k],
      desc:'Left on the practice-hall table, with a note: "Return to owner." The owner has not been named.',
      use:(S,o)=>{
        if(!S.fl['rem'+it.k]){ say('',['You turn it over. It is a '+it.name.toLowerCase().replace(/^an? /,'')+'. It does not say whose it is. (It might, if asked.)']); return; }
        choose(it.name,it.clue,['Return it to Dill','Return it to Pip','Return it to Wren','Leave it'],k=>{
          if(k===3) return;
          const who=['Dill','Pip','Wren'][k];
          if(who===it.own){ S.fl['ret'+it.k]=1; pracFx(S,(it.x+0.5)*TS,(it.y+0.5)*TS,'#cfe6ff',20); coin();
            sxSay(S,it.own,[{Dill:'"My scarf! I looked everywhere. I was cold all week."',Pip:'"My quill. I chew it. Do not tell the Mistress."',Wren:'"My ribbon! Mother will be so pleased I did not lose it."'}[it.own]],()=>{
              if(S.fl.reta&&S.fl.retb&&S.fl.retc) pracWin(S,['"Remembrance will not remember for you what you have not done. It remembers back to you what you ask, in your own words.','It is not kind and not unkind. It is only exact. You asked three times, and you gave three things back, and nobody was told who they were by a stranger.','Do not use it to win an argument. It is not that sort of verse."']);
            });
          } else { sxSay(S,who,[{Dill:'"No, that is not mine. I am very tall, and always cold. I stand at the back window."',Pip:'"No, not mine. I am left-winged, and I chew everything."',Wren:'"Not mine. My mother ties my hair every morning. I cannot do it myself."'}[who]]); }
        },3);
      },
      cast:{Remembrance:(S,o,tx,ty)=>{ S.fl['rem'+it.k]=1; pracFx(S,(tx+0.5)*TS,(ty+0.5)*TS,'#cfe6ff',22); toast(it.clue,5600); }}};
  });
  return pracRoom(v,M,{name:'The Practice Hall: the lost things',theme:'archive',
    rows:sxGrid(13,9,[[0,4,'D'],[3,2,'a'],[6,2,'b'],[9,2,'c']]),
    objs:objs,teacher:[11,6],
    npcs:[{name:'Dill',tx:2,ty:6,pal:PALS[1],dir:'right',talk:()=>say('Dill',['"I am always cold. I stand by the window at the back so I can see the weather coming."'])},
          {name:'Pip',tx:6,ty:6,pal:PALS[2],dir:'up',talk:()=>say('Pip',['"I write with my left wing. It makes a mess. I am improving."'])},
          {name:'Wren',tx:9,ty:6,pal:PALS[4],dir:'left',talk:()=>say('Wren',['"My mother does my hair. I am no good at it. She says that is what mothers are for."'])}],
    task:S=>'"Three things were left on that table. Three students are waiting. I will not tell you whose is whose. Ask the things. Then give them back."',
    intro:['"Three things were left on the table, and three of my students have lost something. I have not told them which is which. I have not told you either.','Face a thing, and cast. Remembrance remembers back to you what you ask for. Then give each one to its owner."']});
};

/* 7. BLOOM: three garden beds. Ask the one who works them. Bloom what they say, and not one stem more. */
PRAC.Bloom=(v,M)=>{
  const beds=[
    {k:'a',x:3,y:3,own:'Tam',ok:true,name:'Tam\'s bed'},
    {k:'b',x:7,y:3,own:'Mirrin',ok:true,name:'Mirrin\'s herb row'},
    {k:'B',x:8,y:3,own:'Mirrin',ok:false,name:'Mirrin\'s lawn'},
    {k:'c',x:11,y:3,own:'Gorse',ok:false,name:'Gorse\'s resting plot'}
  ];
  const objs={};
  beds.forEach(b=>{
    objs[b.k]={name:b.name,glyph:'rug',col:'#5a4a30',solid:false,key:'bd'+b.k,
      desc:'A bed of bare brown soil in the practice garden. It is winter in here. The Mistress would like it to stay that way until someone says otherwise.',
      use:(S,o)=>say('',['Bare soil, neat as a made bed. '+(S.fl['bl'+b.k]?'It is green, now.':'A little cold.')]),
      cast:{Bloom:(S,o,tx,ty)=>{
        pracFx(S,(tx+0.5)*TS,(ty+0.5)*TS,'#7fe09a',26);
        if(b.ok&&S.fl['ask'+b.own]){ S.fl['bl'+b.k]=1; objs[b.k].col='#3a8a3a'; toast(b.own==='Tam'?'Tam\'s bed goes green, and Tam laughs.':'The herb row greens, and the lawn is left alone.',3600);
          if(S.fl.bla&&S.fl.blb) setTimeout(()=>sxSay(S,'Mirrin',['"Thank you for leaving my lawn alone. I like it bare. Everyone thinks it is a mistake."'],()=>pracWin(S,['"Bloom is the oldest verse we have, and the most abused, by well-meaning ducks who wanted to be thanked.','You asked the land, and the one who works it, and you bloomed what you were asked and not one stem more. A garden is a conversation. Do not interrupt."'])),600);
          return; }
        const asked=S.fl['ask'+b.own];
        const lines=!asked?['"You did not ask. A bed is somebody\'s, even in winter. Ask the one who works it."']:b.own==='Gorse'?['"It is winter-bare because he lets it rest. You asked, and he said no. Bloom does not take a no and make it a yes."']:['"You asked about the herbs. That is not the lawn. Not one stem more."'];
        sxSay(S,M,['(The garden goes green for a breath. Then, gently, the Mistress folds it back.)'].concat(lines).concat(['"Again."']),()=>{ for(const k of Object.keys(S.fl)) delete S.fl[k]; beds.forEach(bb=>objs[bb.k].col='#5a4a30'); });
      }}};
  });
  return pracRoom(v,M,{name:'The Practice Hall: the winter garden',theme:'wood',
    rows:sxGrid(15,9,[[0,4,'D'],[3,3,'a'],[7,3,'b'],[8,3,'B'],[11,3,'c']]),
    objs:objs,teacher:[1,7],
    npcs:[{name:'Tam',tx:3,ty:5,pal:PALS[1],dir:'up',talk:(S)=>{ S.fl.askTam=1; say('Tam',['"Oh, would you? Bloom it, please! I have been looking at brown for a week."']); }},
          {name:'Mirrin',tx:7,ty:5,pal:PALS[4],dir:'up',talk:(S)=>{ S.fl.askMirrin=1; say('Mirrin',['"The herbs on the left, yes. The lawn on the right, no. It is bare because I like it bare."']); }},
          {name:'Gorse',tx:11,ty:5,pal:PALS[5],dir:'up',talk:(S)=>{ S.fl.askGorse=1; say('Gorse',['"No. It is resting. I let it rest every winter, and it does me the same courtesy. Leave it be."']); }}],
    task:S=>'"Four beds, three gardeners. Ask each one what they want. Bloom what is asked, and not one stem more."',
    intro:['"Three gardeners have beds in this hall. It is winter in here. I would like a garden. I did not say whose.','Ask the land. Ask the one who works it. Then bloom what they say, and not one stem more."']});
};

/* 8. BANNER: a crowd is leaving. The temptation is to make them stay. */
PRAC.Banner=(v,M)=>{
  const crowd=['Hob','Lark','Sedge','Tilly','Brann'];
  const mk=(nm,tx,ty,i)=>({name:nm,tx:tx,ty:ty,pal:PALS[(i+1)%PALS.length],dir:'left',
    talk:(S,n)=>{
      if(S.fl.bowed&&S.fl.bowed[nm]){ say(nm,['"Of course," says '+nm+'. "Whatever you like." The voice is polite and very far away.']); return; }
      if(S.fl.hill){ S.fl['ch'+nm]=1; say(nm,['"What was that, over the hill? Gold, wasn\'t it? ...I was going to leave. I think I will stay, a minute. I would like to see what you do next."'],()=>{
          if(crowd.filter(c=>S.fl['ch'+c]).length>=2) pracWin(S,['"A Banner is the oldest temptation we have, and the loveliest, and it works. Cast at a crowd, it makes them stand quiet and bow, and afterwards they will thank you, and it will not be them thanking you.','You cast it at an empty hill and a crowd came because they wanted to. That is a banner. The other is a leash that happens to be gold.','I teach it so that you know what it is. So that, when someone asks you to, you can say no, and mean something by it."']);
        }); return; }
      say(nm,['"Sorry, I\'m just leaving. I have a thing."  (They are halfway out the door, in a bundle of coats.)']);
    },
    cast:{Banner:(S,n)=>{
      S.fl.bowed=S.fl.bowed||{};
      if(S.fl.bowed[nm]){ return; }
      S.fl.bowed[nm]=1; S.fl.nb=(S.fl.nb||0)+1; pracFx(S,n.x,n.y-18,'#ffd75a',22);
      sxSay(S,nm,['(They go very still. Then they bow, a little, without having decided to.)'],()=>{
        if(S.fl.lesson){ sxSay(S,'',['(You know better now. You let them go.)'],()=>{ S.fl.bowed={}; }); return; }
        sxSay(S,M,['"Stop. Look at them. They stayed. They are polite. They would stay for the rest of the day if I let you.','That is the second law, and the only one with a corpse in it: the Art does not take a will.','Release them. Then cast it where nobody has to bow."'],()=>{ S.fl.bowed={}; S.fl.lesson=1; });
      });
    }}});
  const npcs=crowd.map((nm,i)=>mk(nm,4+(i%3)*2,3+Math.floor(i/3)*2,i));
  return pracRoom(v,M,{name:'The Practice Hall: the leaving crowd',theme:'castle',
    rows:sxGrid(15,9,[[0,4,'D'],[12,1,'H']]),
    objs:{H:{name:'The high window',glyph:'shutter',solid:true,desc:'A tall window onto an empty hill. Nobody is out there. It is beautiful, which is permitted.',
      cast:{Banner:(S,o,tx,ty)=>{
        S.fl.hill=1; pracFx(S,(tx+0.5)*TS,(ty+0.5)*TS,'#ffd75a',34); pracFx(S,(tx+0.5)*TS,(ty+0.5)*TS-14,'#fff3b0',22);
        sxSay(S,'',['(A sigil of gold stands over the empty hill, huge and quiet, and nobody has to bow to it.)','(Behind you, the crowd stops shuffling. They turn, one by one, to look.)']);
      }}}},
    teacher:[2,7],npcs:npcs,
    task:S=>S.fl.hill?'"Now talk to them. See whether they stay. Notice who is doing the choosing."':'"They are leaving. I would like them to stay for the lesson. You have the Banner. You have, I think, a choice about where to put it."',
    intro:['"A crowd of my students is about to leave before the lesson. I would like them to stay.','You have a verse that can make people stay. Think about where to put it."']});
};

/* -------------------------------------------------------------- running a lesson */
function pracStart(v,ctx,onWin,onQuit){
  const M=ctx.master||v.master;
  PR.on=true; PR.v=v; PR.ctx=ctx; PR.win=onWin; PR.done=onQuit; PR.M=M;
  PR.ret={scene:g.scene,kind:g.libKind,px:g.px,py:g.py,dir:g.dir,saved:g.saved?Object.assign({},g.saved):null};
  ART().practice=v.n;
  const def=PRAC[v.n](v,M); PR.cast=PRAC[v.n].cast||null; PR.std=!!v.std; PR.onCast=PRAC[v.n].onCast||null;
  const id='prac_'+v.n; sxDef(id,def);
  sxEnter(id);
  try{ spSetSel(v.n); }catch(e){}
}
function pracWin(S,lines){
  if(S.fl.won) return; S.fl.won=1; coin();
  sxSay(S,PR.M,lines,()=>pracLeave(true));
}
function pracLeave(ok){
  if(!PR.on) return;
  const R=PR.ret, win=PR.win, quit=PR.done, M=PR.M;
  PR.on=false; ART().practice='';
  try{ sxLeave(); }catch(e){ console.error(e); }
  if(R&&R.scene==='lib'){ enterInterior(R.kind); g.px=R.px; g.py=R.py; g.dir=R.dir; if(R.saved) g.saved=R.saved; }
  if(ok) win&&win();
  else say(M,['"Come back when you like. The problem will have changed. They do."'],()=>quit&&quit());
}
/* verses are castable in a practice room, and only the one being practised */
{
  const _can=sxCan;
  sxCan=function(sp){
    if(PR.on) return !!(PR.v&&PR.v.n===sp);
    return _can(sp);
  };
  const _cast=sxCast;
  sxCast=function(sp){
    const S=SX.S; if(!S) return;
    if(PR.on&&PR.v&&PR.v.n===sp&&PR.std){
      /* an Academy spell: its ordinary effect on the room, then whatever it touches */
      const n0=pracNpcAt(S);
      if(n0&&n0.cast&&n0.cast[sp]){ n0.cast[sp](S,n0); return; }
      _cast(sp);
      if(sp==='Spark'||sp==='Lumen'||sp==='Veil'||sp==='Hearthsong'){   /* these answer the room first, then the thing in front of you */
        const v=DIRV[g.dir], tx=Math.floor((g.px+v.x*16)/TS), ty=Math.floor((g.py-6+v.y*16)/TS), o=sxObjAt(S,tx,ty);
        if(o&&o.cast&&o.cast[sp]) o.cast[sp](S,o,tx,ty);
      }
      if(PR.onCast) PR.onCast(S); return;
    }
    if(PR.on&&PR.v&&PR.v.n===sp){
      if(PR.cast) PR.cast(S);
      const n=pracNpcAt(S);
      if(n&&n.cast&&n.cast[sp]){ n.cast[sp](S,n); return; }
      const v=DIRV[g.dir], tx=Math.floor((g.px+v.x*16)/TS), ty=Math.floor((g.py-6+v.y*16)/TS), o=sxObjAt(S,tx,ty);
      if(o&&o.cast&&o.cast[sp]){ o.cast[sp](S,o,tx,ty); return; }
      if(!PR.cast) toast('Nothing here answers to '+sp+'. Face the thing you mean to ask, then press C.',3200);
      return;
    }
    /* the verses in the story's own rooms also answer the thing in front of you */
    _cast(sp);
    if(VBY[sp]&&!PR.on){
      const n=pracNpcAt(S);
      if(n&&n.cast&&n.cast[sp]){ n.cast[sp](S,n); return; }
      const v=DIRV[g.dir], tx=Math.floor((g.px+v.x*16)/TS), ty=Math.floor((g.py-6+v.y*16)/TS), o=sxObjAt(S,tx,ty);
      if(o&&o.cast&&o.cast[sp]) o.cast[sp](S,o,tx,ty);
    }
  };
}
