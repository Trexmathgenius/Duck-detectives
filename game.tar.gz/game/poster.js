'use strict';
/* ===== THE ROYAL REWARD NOTICES: 300 crumbs for word of a red duck colony ===== */
const KPOSTER=95;
SOLID.add(KPOSTER); INTERACTIVE.add(KPOSTER); KTALL.add(KPOSTER);
MAPCOL[KPOSTER]='#c9a24a';
const POSTER_AT=[[-4,35],[-12,27],[-6,10],[22,23],[-22,23],[14,34]];
function posterHere(x,y){ const lx=x-KX, ly=y-KY; for(const p of POSTER_AT) if(p[0]===lx&&p[1]===ly) return true; return false; }
{
  const _kt=kingdomTile;
  kingdomTile=function(x,y){
    const t=_kt(x,y);
    if(t!==null&&!SOLID.has(t)&&posterHere(x,y)) return KPOSTER;
    return t;
  };
  const _drawKTile=drawKTile;
  drawKTile=function(c,x,y,t,px,py,time,objs,night){
    if(t===KPOSTER){
      kGround(c,x,y,px,py);
      objs.push({y:py+TS,k:'fn',f:()=>{
        ell(c,px+16,py+30,10,3,'rgba(0,0,0,0.3)');
        rect(c,px+8,py+8,3,22,'#5b3f22'); rect(c,px+21,py+8,3,22,'#5b3f22');
        rect(c,px+4,py-10,24,26,'#8a6238'); rect(c,px+6,py-8,20,22,'#efe0b0');
        rect(c,px+6,py-8,20,6,'#a8232f'); rect(c,px+9,py-6,14,2,'#f6e6c8');
        rect(c,px+9,py+1,14,1.5,'#7a5a3a'); rect(c,px+9,py+4,11,1.5,'#7a5a3a');
        circ(c,px+16,py+10,3.2,'#e0b84a'); circ(c,px+16,py+10,2,'#f6dc82');
        rect(c,px+4,py-10,24,2,'#6a4a28');
      }});
      return;
    }
    _drawKTile(c,x,y,t,px,py,time,objs,night);
  };
  const _kInteract=kingdomInteract;
  kingdomInteract=function(t,tx,ty){
    if(t===KPOSTER){ readPoster(); return; }
    _kInteract(t,tx,ty);
  };
}
function readPoster(){
  const st=g.story; st.posterSeen=1;
  const pages=[
    'BY ORDER OF HIS MAJESTY KING EIDER, RULER OF MALLARDIA.',
    'REWARD: 300 CRUMBS. To any duck who brings the Crown reliable word of a colony of red-feathered ducks said to be hiding in the wild north-east, beyond the hills.',
    'Report to the Castle Guards at the gate. Payment is made at the king\'s own table. Tell no one else. Do not go looking alone.'
  ];
  if(st.isRed) pages.push('You read it with your head very low. Three hundred crumbs. That is what you are worth, apparently. You walk on, quickly, and do not look up.');
  else if(st.dinnerDone) pages.push('You already collected on this one. The ink looks a little different, now.');
  else if(st.redOpen) pages.push('You know exactly where that colony is. You also know what it would cost you to say so. Or what it would cost them.');
  say('Royal Notice',pages);
}
