'use strict';
/* ===== EVERY OBJECT DOES SOMETHING: timed buffs, and a use for foods, finds and trinkets ===== */
const FXS=()=>{ const s=g.story||(g.story={}); if(!s.fx) s.fx={}; if(!s.fx.until) s.fx.until={}; if(!s.fx.cool) s.fx.cool={}; return s.fx; };
const fxNow=()=>g.day*24+g.clock;
const FX_NAMES={forage:'Keen Nose',luck:'Fortune',angler:'Steady Hands',haggle:'Silver Tongue'};
const FX_TEXT={forage:'better odds of crumbs when you forage',luck:'better odds of finds when you forage',angler:'more rare fish bite',haggle:'shops pay more for your finds'};
function fxLeft(k){ const u=FXS().until[k]; return u?Math.max(0,u-fxNow()):0; }
function fxGive(k,h){ const x=FXS(); const now=fxNow(); x.until[k]=Math.min(now+10,Math.max(x.until[k]||0,now)+h); }
function wlWorn(id){ return g.worn&&(g.worn.head===id||g.worn.neck===id||g.worn.feet===id||g.worn.charm===id||Object.values(g.worn).indexOf(id)>=0); }
const wlWearing=id=>{ const it=ITEMS[id]; return !!(it&&it.slot&&g.worn[it.slot]===it.wear); };
function wlCrumbP(){ return 0.10+(fxLeft('forage')>0?0.15:0)+(wlWearing('crown')?0.05:0); }
function wlItemMul(){ return (fxLeft('luck')>0?2:1)*(wlWearing('hat')?1.25:1)*(wlWearing('feather')?1.3:1); }
function wlHaggle(){ return 1+(fxLeft('haggle')>0?0.2:0)+(wlWearing('bowtie')?0.1:0); }
{
  const _rh=rumorHere;
  rumorHere=function(type){ if(type==='biting'&&(fxLeft('angler')>0||wlWearing('scarf'))) return true; return _rh(type); };
}

/* ---- effect recipes: tokens are  speed60  forage2  luck3  angler2  haggle3  glow300  rep1  crumbs4-9  time3  dowse  dowseDig  dowseTrail  hunt  sure ---- */
const FXD={
 /* foods */
 crust:'speed20', muffin:'speed20 forage2', tea:'angler3 speed10', scone:'haggle3', cocoa:'glow300 speed15', soup:'speed90',
 seeds:'forage2', peas:'luck2', worms:'angler4', honey:'speed40 glow300', cake:'speed40 rep1', beetloaf:'speed35 forage1',
 emberroll:'speed30 glow180', ashbread:'speed20 dowse', pepcocoa:'speed60', cinderstew:'speed40 luck2', embertea:'glow400 angler2',
 roastnut:'speed20 forage1', warmtonic:'forage3 luck1', spiceseed:'speed25 forage1', roastfish:'speed90 angler3', t_mix:'speed35 forage1',
 tonic_luck:'luck4', tonic_forage:'forage4', tonic_angler:'angler4', tonic_haggle:'haggle4', tonic_glow:'glow600', tonic_speed:'speed100',
 lure:'angler2', baittin:'angler4', hardtack:'speed45', driedberries:'forage2 speed15', trailsand:'speed60 luck1', waterskin:'speed70', teablend:'forage3',
 /* fish */
 fish_minnow:'speed20', fish_perch:'speed30 angler1', fish_carp:'speed40', fish_trout:'speed50 angler2', fish_catfish:'speed60 luck1',
 fish_goldkoi:'luck4 haggle4', fish_mooneel:'glow600 luck2', fish_oldboot:'crumbs1-3',
 /* trinkets and keepsakes */
 flint:'glow180', tinderbox:'glow600', vigil:'glow600', redthread:'rep1', tinkerbeetle:'dowseTrail', healleaf:'speed50 luck1',
 blessfeather:'luck4', redbraid:'rep1', embertoken:'rep1 !day', medal:'rep1 !day',
 gustcharm:'speed45', wardcharm:'luck2', runestone:'dowse',
 /* rare finds */
 r_goldacorn:'luck4 forage2', r_antler:'dowse', r_owlfeather:'glow600', r_honeycomb:'speed60 haggle2', r_bumblecharm:'forage3', r_rainbowbloom:'luck3 rep1',
 r_rainbowleaf:'speed30 luck1', r_ambertear:'sure', r_syrup:'speed80', r_frozendew:'angler3', r_snowcrystal:'glow400', r_mammothtooth:'sure',
 r_quartz:'hunt', r_eaglefeather:'speed90', r_meteorite:'sure luck1', r_scarab:'luck5 haggle3', r_sungeode:'crumbs8-16', r_desertglass:'glow300',
 r_sandrose:'rep1 forage2', r_jadeidol:'luck6', r_orchidresin:'forage3', r_parrotfeather:'speed50', r_bogpearl:'angler4', r_wisp:'glow900 dowse',
 r_peatamber:'luck2 forage2', r_bambooflute:'rep2', r_luckyknot:'luck4', r_teabrick:'angler2 speed40', r_everbloom:'luck2 rep1', r_lanterncharm:'glow600',
 r_hairpin:'rep2 haggle2', r_sporevial:'glow300 forage2', r_moonstone:'glow900 luck2', r_fairychalice:'luck3 forage3', r_sachet:'time1', r_lavjar:'speed60',
 r_dreampillow:'time6 luck2', r_seaglass:'angler2', r_pearl:'haggle4 luck2', r_conch:'dowse', r_bottle:'hunt', r_ostrich:'crumbs6-12', r_sunstone:'glow600 speed40',
 r_termitegem:'forage4',
 g_penny:'luck3', g_button:'forage1 luck1', g_marble:'luck2', g_bell:'rep1 speed20', g_waxseal:'haggle4', g_goldfeather:'luck6 speed60',
 /* trail items */
 t_mitten:'rep1', t_token:'dowseTrail', t_whistle:'speed40', t_postcard:'dowse', t_needle:'dowseTrail', t_stick:'speed70', t_button:'luck1 haggle1',
 t_cup:'angler2', t_bookmark:'forage2', t_lace:'speed30', t_duck:'luck3', t_shoe:'luck3',
 /* relics */
 d_trilobite:'sure', d_ammonite:'sure luck1', d_shard:'haggle2 dowse', d_spear:'forage3', d_idol:'luck4', d_jug:'crumbs4-9', d_claw:'speed60 luck2', d_coinold:'crumbs5-10 haggle2',
 /* treasure */
 tr_doubloon:'haggle4 crumbs5-10', tr_ingot:'haggle4', tr_ruby:'luck4', tr_sapphire:'angler4 glow300', tr_emerald:'forage4 luck2', tr_goblet:'rep2 luck2', tr_crown:'rep3 haggle4 luck3'
};
const FXP={}; /* parsed */
for(const id in FXD){ if(!ITEMS[id]) continue; FXP[id]=FXD[id].split(' ').map(t=>{ const m=/^(!?[a-zA-Z]+)([\d-]*)$/.exec(t); const a=m[2].split('-').map(Number); return {k:m[1],a:a[0]||0,b:a[1]||0}; }); }
function fxSummary(list){
  const parts=[];
  for(const e of list){
    switch(e.k){
      case 'speed': parts.push('a burst of speed'); break;
      case 'forage': case 'luck': case 'angler': case 'haggle': case 'finder': case 'plenty': case 'charm': parts.push(FX_NAMES[e.k]+' for '+e.a+'h ('+FX_TEXT[e.k]+')'); break;
      case 'glow': parts.push('light around you for '+Math.round(e.a/60)+' min'); break;
      case 'rep': parts.push('+'+e.a+' standing in the town you are in'); break;
      case 'crumbs': parts.push(e.a+'-'+e.b+' crumbs'); break;
      case 'time': parts.push('a nap of '+e.a+'h'); break;
      case 'hum': parts.push('for a couple of hours you can feel which way the nearest unstudied Dark Tree lies'); break;
      case 'dowse': parts.push('shows where a dig spot, trail item or treasure is nearby'); break;
      case 'dowseDig': parts.push('points to the nearest dig spot'); break;
      case 'dowseTrail': parts.push('points to the nearest trail item'); break;
      case 'hunt': parts.push('points to your nearest treasure map'); break;
      case 'sure': parts.push('your next dig turns up a relic'); break;
      case '!day': parts.push('(not used up; once per day)'); break;
    }
  }
  return parts.join(', ');
}
for(const id in FXP){ const it=ITEMS[id]; if(!it.fxDesc){ it.fxDesc=1; it.desc=it.desc+' Use it: '+fxSummary(FXP[id])+'.'; } }
/* worn items do something too */
ITEMS.hat.desc+=' Worn: finds turn up a bit more often.'; ITEMS.crown.desc+=' Worn: a few more crumbs when you forage.';
ITEMS.scarf.desc+=' Worn: rare fish bite more.'; ITEMS.bowtie.desc+=' Worn: shops pay a bit more for your finds.'; ITEMS.feather.desc+=' Worn: finds turn up more often.';

/* ---- dowsing ---- */
function fxScan(kind){
  const p=wlTile(), w=WD(); let best=null;
  const R=kind==='trail'?30:36;
  if(kind!=='hunt') for(let dy=-R;dy<=R;dy++) for(let dx=-R;dx<=R;dx++){
    const x=p.x+dx, y=p.y+dy, d=Math.hypot(dx,dy); if(best&&d>=best.d) continue;
    if((kind==='dig'||kind==='any')&&wlDigSpot(x,y)) best={d:d,x:x,y:y,w:'a glinting dig spot'};
    else if((kind==='trail'||kind==='any')&&tileAt(x,y)===T.PATH&&wlTrailSpot(x,y)) best={d:d,x:x,y:y,w:'something glinting on the trail'};
  }
  if(kind==='hunt'||kind==='any') for(const h of w.hunts){ const d=Math.hypot(h.x-p.x,h.y-p.y); if(!best||d<best.d) best={d:d,x:h.x,y:h.y,w:'your buried treasure'}; }
  return best&&{best:best,p:p};
}
function fxPoint(kind){
  const r=fxScan(kind);
  if(!r){ el.dNote.textContent='It tingles, then settles. Nothing of that sort is close. Try elsewhere.'; blip(); return false; }
  const dx=r.best.x-r.p.x, dy=r.best.y-r.p.y;
  el.dNote.textContent='It pulls '+wlDir(dx,dy)+' '+wlArrow(dx,dy)+': '+r.best.w+', about '+Math.max(1,Math.round(r.best.d))+' waddles away.';
  return true;
}
/* ---- apply ---- */
function fxApply(id,list){
  const x=FXS(), msgs=[]; let used=true, noTown=false;
  for(const e of list){
    if(e.k==='!day'){ if(x.cool[id]===g.day){ el.dNote.textContent='It has done its work for today. Try again tomorrow.'; blip(); return false; } }
  }
  for(const e of list){
    switch(e.k){
      case 'speed': g.boost=Math.min(150,g.boost+e.a); msgs.push('Zippy!'); break;
      case 'forage': case 'luck': case 'angler': case 'haggle': case 'finder': case 'plenty': case 'charm': fxGive(e.k,e.a); msgs.push(FX_NAMES[e.k]+'.'); break;
      case 'glow': lumenUntil=Math.max(lumenUntil,g.time)+e.a; msgs.push('A soft light gathers around you.'); break;
      case 'rep': { const t=g.curTown&&g.scene==='world'?townByKey(g.curTown):null; if(t){ addRep(t,e.a); msgs.push('+'+e.a+' standing in '+t.name+'.'); } else { noTown=true; msgs.push('(No town around to hear of it.)'); } break; }
      case 'crumbs': { const n=e.a+Math.floor(rnd()*(e.b-e.a+1)); g.crumbs+=n; coin(); msgs.push('+'+n+' crumbs.'); break; }
      case 'time': closeInv(); fade(1.2); advanceClock(e.a); msgs.push('You nap. It is '+clockStr()+'.'); break;
      case 'dowse': if(!fxPoint('any')) return false; break;
      case 'dowseDig': if(!fxPoint('dig')) return false; break;
      case 'dowseTrail': if(!fxPoint('trail')) return false; break;
      case 'hunt': if(!fxPoint('hunt')) return false; break;
      case 'sure': WD().sureDig=1; msgs.push('Your next dig will find something.'); break;
      case 'hum': { const x11=(g.story.x11||(g.story.x11={})); x11.humUntil=Math.max(x11.humUntil||0,fxNow())+e.a/900; msgs.push('A low hum rises in your bones. You can tell which way the nearest unstudied Dark Tree lies.'); break; }
      case '!day': if(!noTown) x.cool[id]=g.day; used=false; break;
    }
  }
  const dn=el.dNote.textContent;
  const it=ITEMS[id], q=it.quip||it.note||'';
  const hasDow=list.some(e=>e.k.indexOf('dowse')===0||e.k==='hunt');
  el.dNote.textContent=(hasDow?dn+' ':'')+(q?q+' ':'')+msgs.join(' ');
  if(used) delInv(id);
  return true;
}
{
  const _use=useItem;
  useItem=function(id){
    const list=FXP[id], it=ITEMS[id];
    if(list&&it&&!(it.use==='magic'&&typeof magicTrained==='function'&&!magicTrained(id))){
      if(it.cat==='find'&&it.use!=='eat'&&it.sell>=3){
        const sum=fxSummary(list);
        choose('',it.name+': '+sum+'. Use it up? (You could sell it for about '+it.sell+' crumbs.)',['Use it','Keep it'],k=>{ if(k===0){ if(fxApply(id,list)){ quack(); renderInv(); } } },1);
        return;
      }
      if(fxApply(id,list)){ quack(); renderInv(); }
      return;
    }
    _use(id);
  };
  const _ri=renderInv;
  renderInv=function(){
    _ri();
    const id=invIds()[g.invSel];
    if(id&&FXP[id]&&ITEMS[id].use!=='equip') el.dUse.textContent='Use (Z)';
  };
}
/* the sure-dig flag: the next shovel strike finds a relic */
{
  const _dig=wlDigAt;
  wlDigAt=function(x,y,known){
    const w=WD();
    if(w.sureDig&&isHeld('shovel')&&w.dug[x+','+y]!==g.day){ w.sureDig=0; w.dug[x+','+y]=g.day; tone('sawtooth',160,90,0.16,0.07); wlDigRelic(x,y); return; }
    _dig(x,y,known);
  };
}
/* a chip for the active buffs */
{
  const chips=document.querySelector('#hud .chips'), chip=document.createElement('span'); chip.className='chip'; chip.id='fxChip'; chip.hidden=true; chips.appendChild(chip);
  const _upd=updateHud; let last='';
  updateHud=function(){
    _upd();
    const parts=[]; for(const k in FX_NAMES){ const h=fxLeft(k); if(h>0) parts.push(FX_NAMES[k]+' '+(h>=1?Math.floor(h)+'h':Math.ceil(h*60)+'m')); }
    if(g.time<lumenUntil) parts.push('Glow');
    const s=parts.join(' · ');
    if(s!==last){ last=s; chip.hidden=!s; chip.textContent=s; }
  };
}
