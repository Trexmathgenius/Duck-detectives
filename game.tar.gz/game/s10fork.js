/* ===== CONSEQUENCES (v1.25) =====
   Choices that used to change a line now change the hardest scene in the game.
   The Ward Breaks (chapter 19) is a stealth-and-time scene: four anchors, wisps, a clock.
   Who is standing with you, and how much time and quiet you get, comes from what you did earlier:
     - the parley at the watchtower went well          -> both sides hold the perimeter: +40 seconds, one fewer wisp
     - you stopped the march (Crown road)              -> Halbeak's men keep the ring clear: +25 seconds
     - you were merciful to those who did not earn it  -> the sleepers are calmer: +20 seconds
     - you told the truth when it cost you             -> the anchors steady faster (hold time -0.6s)
     - you were proud, and lied                        -> the wisps know you: they see a little further
   The scene says which of these apply, in the scene, so you can read cause and effect.
   The Rite (chapter 8, Red road) is timed too: the kin you helped (+30s) and the mercy you showed (+15s) buy it time.
   Adds D10.wardFork(); wraps sxTimer and sxEnter. */
(function(){
'use strict';
const D10=window.D10=window.D10||{};
function fork(){
  const L=s2().led||{}, fl=s2().fl||{}, out={sec:0,fewer:false,fast:0,wide:0,why:[]};
  if(fl.summit===2){ out.sec+=40; out.fewer=true; out.why.push('Both sides sent riders to hold the ring: +40 seconds, one wisp fewer.'); }
  else if(fl.summit===1) out.why.push('The parley failed. Nobody is holding the ring but you.');
  if(fl.march==='stopped'||fl.marchFinal==='stopped'){ out.sec+=25; out.why.push('Halbeak\'s men keep the edge clear: +25 seconds.'); }
  if((L.mercy||0)>=3){ out.sec+=20; out.why.push('The sleepers remember your mercy and sleep lightly: +20 seconds.'); }
  if((L.truth||0)>=3){ out.fast=0.6; out.why.push('You told the truth when it cost you. The anchors steady quicker.'); }
  if((L.lie||0)>=1&&(L.pride||0)>=2){ out.wide=1; out.why.push('The wisps have heard how you lie. They look further.'); }
  return out;
}
D10.wardFork=fork;
let active=null;
{
  const _en=sxEnter;
  sxEnter=function(id){
    active=null;
    if(id==='wardsc'){ try{ active=fork(); }catch(e){ active=null; } }
    const r=_en.apply(this,arguments);
    try{
      const S=SX.S;
      if(id==='wardsc'&&S&&active){
        if(active.fewer){ const i=S.guards.findIndex(q=>q.scan); if(i>=0) S.guards.splice(i,1); }
        if(active.wide) S.guards.forEach(q=>{ if(typeof q.range==='number') q.range+=1; });
        S.fork=active;
        if(active.fast&&S.def&&!S.def.__forkTick){ S.def.__forkTick=1; const ot=S.def.tick; S.def.tick=function(S2,dt){ return ot.call(this,S2,(S2.fork&&S2.fork.fast)?dt*(1+S2.fork.fast/4):dt); }; }
        if(active.why.length) setTimeout(()=>{ try{ if(g.scene==='sx') toast(active.why.join('  '),active.why.length>2?9000:6500); }catch(e){} },2500);
      }
    }catch(e){ console.warn('wardFork',e); }
    return r;
  };
  const _tm=sxTimer;
  sxTimer=function(S,secs,label,onEnd){
    if(label==='The Ward'&&active) secs+=active.sec;
    if(label==='The Rite'){
      try{
        const L=s2().led||{}, why=[]; let add=0;
        if((L.kin||0)>=1){ add+=30; why.push('The houses you helped keep a lamp in the window: +30 seconds.'); }
        if((L.mercy||0)>=2){ add+=15; why.push('Those you spared stand watch: +15 seconds.'); }
        if(add){ secs+=add; setTimeout(()=>{ try{ if(g.scene==='sx') toast(why.join('  '),7000); }catch(e){} },2500); }
      }catch(e){}
    }
    return _tm(S,secs,label,onEnd);
  };
}
})();
