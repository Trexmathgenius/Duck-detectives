'use strict';
/* ===== EXTRAS: the "Coming up" timers, weary carters you can pay for a ride, weather and the spells you can cast in the world ===== */
const XS=()=>{ const s=g.story; if(!s.x) s.x={}; return s.x; };
const xAbs=()=>g.day*24+g.clock;
const xPlayerTile=()=>({x:Math.floor(g.px/TS),y:Math.floor((g.py-2)/TS)});
function xIn(h){
  if(h<=0.01) return 'a moment';
  if(h<1) return 'under an hour';
  if(h<24) return Math.ceil(h)+' hour'+(Math.ceil(h)===1?'':'s');
  const d=Math.floor(h/24), r=Math.round(h-d*24);
  return d+' day'+(d===1?'':'s')+(r?' '+r+' h':'');
}
/* a choice list that pages itself when there are too many entries */
function pagedChoose(who,text,labels,onPick,size){
  size=size||5; let page=0;
  const show=()=>{
    const start=page*size, slice=labels.slice(start,start+size), more=start+size<labels.length;
    const opts=slice.concat(more?['More...']:[],['Back']);
    choose(who,text,opts,k=>{
      if(more&&k===slice.length){ page++; show(); return; }
      if(k>=slice.length) return;
      onPick(start+k);
    },opts.length-1);
  };
  show();
}

/* ---------- the notice board grows three new entries ---------- */
{
  const _choose=choose;
  choose=function(who,text,opts,cb,cancel){
    if(who==='Notice Board'&&/^TOWN NOTICES/.test(text)&&opts.length>1&&!g.__nbWrapped){
      const tw=xPlayerTile(), t=townAtTile(tw.x,tw.y);
      if(t){
        const extra=[['Rumour of the day',()=>readRumor(t)],['Collections album',()=>openAlbum()],['Carters on the road',()=>openCart(t)]];
        const base=opts.slice(0,-1);
        const nopts=base.concat(extra.map(e=>e[0]),[opts[opts.length-1]]);
        const ncb=k=>{ if(k<base.length) cb(k); else if(k<base.length+extra.length) extra[k-base.length][1](); else cb(opts.length-1); };
        return _choose(who,text,nopts,ncb,nopts.length-1);
      }
    }
    return _choose(who,text,opts,cb,cancel);
  };
}

/* ---------- what is coming up ---------- */
function storyTimers(){
  const st=g.story, out=[], now=xAbs();
  const when=abs=>{ const d=Math.floor(abs/24)-g.day, h=((abs%24)+24)%24;
    return (d<=0?'today':d===1?'tomorrow':'on day '+Math.floor(abs/24))+' at '+hourLabel(h)+(abs>now?' (in '+xIn(abs-now)+')':''); };
  if(st.redOpen&&st.hermitFollow&&!st.ch3Met){
    if(st.hermitHold) out.push('Hermit Mallow is waiting outside the castle. Talk to him.');
    else if(st.hermitAway||st.hermitWalking) out.push('Hermit Mallow comes out of the castle '+when(st.hermitUntil)+'.');
    else { const m=(st.mtgDone||0)+1; if(m<=3) out.push('The Elders send for the hermit (meeting '+m+' of 3) '+when(meetTime(m))+'.'); }
  }
  if(st.castleOpen) out.push('The castle gate is open. The Elders will see you now.');
  if(st.ch3Met&&!st.isRed&&!st.dinnerDone&&!st.reportAt){
    const d=(st.school&&st.school.days)||0;
    if(d<12) out.push('The Academy teaches from 8:00 AM to 5:00 PM. Next lesson: day '+(d+1)+' of 12.'); }
  if(st.reportAt&&!st.dinnerAt) out.push('The king\'s answer is due '+when(st.reportAt+24)+', delivered between 7 AM and 4 PM.');
  if(st.dinnerAt&&!st.dinnerDone) out.push('Dinner with the king: '+when(st.dinnerAt)+'. Castle gate. Do not be late.');
  for(const q of g.quests){ out.push('A favor is due by day '+q.due+' ('+Math.max(0,q.due-g.day)+' day'+(q.due-g.day===1?'':'s')+' left).'); }
  const p=xPlayerTile(), t=townAtTile(p.x,p.y);
  if(t){
    const e=eventFor(t,g.day);
    if(e&&g.clock<e.h+e.dur) out.push('Today in '+t.name+': '+e.title+' at '+hourLabel(e.h)+'.');
    const e2=eventFor(t,g.day+1);
    if(e2) out.push('Tomorrow in '+t.name+': '+e2.title+' at '+hourLabel(e2.h)+'.');
  }
  const w=wxNow(); if(w!=='clear') out.push('Weather: '+WXN[w]+(wxEndsAt()?', clearing around '+hourLabel(wxEndsAt()%24):'')+'.');
  return out;
}
{
  const _journalExtra=journalExtra;
  journalExtra=function(sec,line){
    _journalExtra(sec,line);
    sec('Coming up');
    const l=storyTimers(); if(!l.length) line('Nothing is scheduled.'); else l.forEach(x=>line(x));
    collJournal(sec,line);
  };
}

/* ---------- setting your home on the map ---------- */
function mapHomeUi(msg){
  const h=homePos(); const b=$('mHomeX'); if(b) b.hidden=!h.custom;
  const hp=$('mHelp'); if(hp) hp.textContent=msg||'Wheel or +/- to zoom  \u00b7  drag or arrows to pan  \u00b7  H sets your home at the + in the middle (a town or the kingdom you have visited)';
}
function trvHomeMoved(){
  const hd=trvHomeDest();
  for(const k in TRV){ const r=TRV[k]; if(!r||!r.plan||r.plan.to.id!=='home') continue;
    r.plan.to=hd; r.plan.d=Math.hypot(hd.x-r.plan.o.x,hd.y-r.plan.o.y); }
}
function setHomeHere(){
  const tx=Math.floor(m.cx), ty=Math.floor(m.cy);
  const no=why=>{ mapHomeUi('Cannot make a home there: '+why+'.'); blip(); };
  let sp=null;
  for(let r=0;r<=3&&!sp;r++) for(let dy=-r;dy<=r&&!sp;dy++) for(let dx=-r;dx<=r&&!sp;dx++){
    if(Math.max(Math.abs(dx),Math.abs(dy))!==r) continue;
    const t=tileAt(tx+dx,ty+dy); if(!SOLID.has(t)&&t!==T.WATER&&t!==T.DARK) sp=[tx+dx,ty+dy];
  }
  if(!sp) return no('no open ground at the +');
  const kin=inK(sp[0],sp[1]), tw=townAtTile(sp[0],sp[1]);
  if(inRed(sp[0],sp[1])||inRed(sp[0]+6,sp[1]+6)||inRed(sp[0]-6,sp[1]-6)) return no('carters do not travel to Emberwick');
  if(!kin&&!tw) return no('a home must be in a town or in the kingdom');
  if(tw&&!g.towns.has(tw.key)) return no('you have not travelled to '+tw.name+' yet');
  if(kin&&!XS().kvisit) return no('you have not travelled to the kingdom yet');
  if(!g.story.x) g.story.x={};
  g.story.x.home={x:sp[0]+0.5,y:sp[1]+0.5};
  trvHomeMoved(); coin(); mapHomeUi('Home set at '+sp[0]+', '+sp[1]+'. Carters and your compass now point there.');
}
function resetHome(){ if(g.story.x) delete g.story.x.home; trvHomeMoved(); blip(); mapHomeUi('Home is back at the first pond.'); }

/* ---------- weary carters: travellers who pass through towns and sell you a ride ---------- */
const TRV={};   /* town key -> {day, plan, npc} */
const TRV_NAMES=['Dusty Drake','Mabel Mudfoot','Old Gander Pell','Pip Reedwhistle','Tansy Longbill','Barnaby Quill','Hettie Down','Wendell Wade','Marigold Puddle','Fennick Flap','Orla Sedge','Bram Tuftwing'];
const TRV_FLAVOUR=['the reed-beds past the hills','a farm up the old mill road','the far side of the marsh','a cheese fair somewhere east'];
const TRV_HEADS=['hat','cap','hood',null], TRV_NECKS=['scarf',null,'bowtie'];
function trvHomeDest(){ const h=homePos(); return h.custom?{id:'home',name:'Home (your own spot)',x:h.x,y:h.y,custom:true}:{id:'home',name:'Home (the first pond)',x:0.5,y:3}; }
function trvPlaces(t){
  const out=[];
  for(let dy=-4;dy<=4;dy++) for(let dx=-4;dx<=4;dx++){
    const o=getTown(Math.round(t.cx/REG)+dx,Math.round(t.cy/REG)+dy);
    if(o&&o.key!==t.key) out.push({id:o.key,name:o.name,x:o.cx+0.5,y:o.cy+3});
  }
  { const hd=trvHomeDest(); if(Math.hypot(t.cx-hd.x,t.cy-hd.y)>20&&!(hd.custom&&inK(Math.floor(hd.x),Math.floor(hd.y)))) out.push(hd); }
  out.forEach(o=>{ o.d=Math.hypot(o.x-t.cx,o.y-t.cy); });
  out.sort((a,b)=>a.d-b.d||(a.id<b.id?-1:1));
  const near=out.slice(0,9);
  if(t.key!=='kingdom') near.push({id:'kingdom',name:'Mallardia, the kingdom',x:KX+0.5,y:KY+16,d:Math.hypot(KX+0.5-t.cx,KY+16-t.cy)});   /* any carter may head for the kingdom */
  return near;
}
function trvFare(d){ return {cost:Math.max(3,Math.ceil(d/18)+1), hrs:Math.max(0.5,Math.round(d/70*2)/2)}; }
function trvPlan(t){
  const rec=TRV[t.key];
  if(rec&&rec.day===g.day) return rec.plan;
  let plan=null;
  const hh=(s)=>hash(t.cx+g.day*131,t.cy+g.day*17,5100+s);
  if(hh(1)<0.55){
    const pl=trvPlaces(t);
    if(pl.length){
      const kg=pl[pl.length-1], to=(hh(9)<0.3)?kg:pl[Math.floor(hh(2)*Math.min(pl.length-1,6))];
      const froms=pl.filter(o=>o.id!==to.id).map(o=>o.name).concat(TRV_FLAVOUR);
      const from=froms[Math.floor(hh(3)*froms.length)];
      const arr=7+Math.floor(hh(4)*18)/2;           /* 7:00 - 15:30 */
      plan={ to, from, arr, leave:arr+3.5, name:TRV_NAMES[Math.floor(hh(5)*TRV_NAMES.length)], pal:Math.floor(hh(6)*PALS.length),
             head:TRV_HEADS[Math.floor(hh(7)*TRV_HEADS.length)], neck:TRV_NECKS[Math.floor(hh(8)*TRV_NECKS.length)], gone:false, d:Math.hypot(to.x-t.cx,to.y-t.cy), o:{x:t.cx,y:t.cy} };
    }
  }
  TRV[t.key]={day:g.day,plan:plan,npc:null};
  return plan;
}
function trvHere(t){ const p=trvPlan(t); return (p&&!p.gone&&g.clock>=p.arr&&g.clock<p.leave)?p:null; }
function trvDeco(c,n,time){
  /* a small mule cart parked beside the traveller */
  const x=n.x+(n.dir==='left'?20:-20), y=n.y;
  rect(c,x-11,y-12,22,9,'#9a6b3a'); rect(c,x-11,y-12,22,2,'#b88650'); rect(c,x-9,y-16,18,4,'#d9b84a');
  circ(c,x-6,y-2,4,'#4a3320'); circ(c,x+6,y-2,4,'#4a3320'); circ(c,x-6,y-2,1.5,'#c9a46a'); circ(c,x+6,y-2,1.5,'#c9a46a');
  const mx=x+(n.dir==='left'?20:-20); rect(c,mx-6,y-14,12,8,'#8a7a6a'); rect(c,mx-5,y-6,2,6,'#6e6052'); rect(c,mx+3,y-6,2,6,'#6e6052');
  rect(c,mx+(n.dir==='left'?3:-8),y-20,5,7,'#8a7a6a'); rect(c,mx+(n.dir==='left'?4:-7),y-23,1.5,4,'#6e6052');
  const dr=(Math.sin(time*2)+1)*2; c.fillStyle='rgba(120,190,240,0.9)'; c.fillRect(n.x+6,n.y-34+dr,2,3);   /* a bead of sweat */
}
const KT={key:'kingdom',cx:KX+0.5,cy:KY+16};
const KSPOT=[[-9,36],[9,36]];
function trvKing(i){
  let rec=TRV['K'+i];
  if(rec&&rec.day===g.day) return rec;
  const pl=trvPlaces(KT), hh=(sd)=>hash(g.day*37+i*911,i*7+3,5300+sd);
  let k=Math.floor(hh(1)*Math.min(pl.length,7));
  if(i===1){ const k0=Math.floor(hash(g.day*37,3,5301)*Math.min(pl.length,7)); if(k===k0) k=(k+1)%Math.min(pl.length,7); }
  const nm=(Math.floor(hash(g.day*5,9,5302)*TRV_NAMES.length)+i*5)%TRV_NAMES.length;
  const to=pl[k];
  const plan={to,from:'Mallardia',arr:0,leave:99,perm:true,name:TRV_NAMES[nm],pal:(nm+i*3)%PALS.length,head:TRV_HEADS[(nm+i)%TRV_HEADS.length],neck:TRV_NECKS[(nm+i)%TRV_NECKS.length],gone:false,d:Math.hypot(to.x-KT.cx,to.y-KT.cy),o:{x:KT.cx,y:KT.cy}};
  const old=rec&&rec.npc;
  rec=TRV['K'+i]={day:g.day,plan,npc:null,kidx:i};
  const sp=snapFree(KX+KSPOT[i][0],KY+KSPOT[i][1],5);
  rec.npc={special:'traveler',kidx:i,name:plan.name,pal:PALS[plan.pal],acc:{head:plan.head,neck:plan.neck},persona:0,owl:true,still:true,idx:3500+i,
    x:(sp[0]+0.5)*TS,y:(sp[1]+0.95)*TS,hx:(sp[0]+0.5)*TS,hy:(sp[1]+0.95)*TS,dir:i?'left':'right',moving:false,t:1,phase:0,talking:false,lines:[['...']],cycle:0,deco:trvDeco};
  if(old&&old.talking) rec.npc.talking=true;
  return rec;
}
function trvNpc(t){
  const p=trvHere(t); if(!p) return null;
  const rec=TRV[t.key];
  if(!rec.npc){
    const sp=snapFree(t.board.x-2,t.board.y+3,4);
    rec.npc={special:'traveler',trv:t.key,name:p.name,pal:PALS[p.pal],acc:{head:p.head,neck:p.neck},persona:0,owl:false,still:true,idx:3000+(hash(t.cx,t.cy,5199)%900),
      x:(sp[0]+0.5)*TS,y:(sp[1]+0.95)*TS,hx:(sp[0]+0.5)*TS,hy:(sp[1]+0.95)*TS,dir:'left',moving:false,t:1,phase:0,talking:false,lines:[['...']],cycle:0,deco:trvDeco};
  }
  return rec.npc;
}
function trvRide(t,p){
  const f=trvFare(p.d);
  if(g.crumbs<f.cost){ say(p.name,['"That is '+f.cost+' crumbs, friend. You have '+g.crumbs+'. My mule eats more than that. Come back when your pockets rattle."']); return; }
  say(p.name,['"Splendid. Hop up, mind the hay, and do not touch the mule. He knows what he did."'],()=>{
    g.crumbs-=f.cost; coin(); fade(1.2); if(!p.perm) p.gone=true;
    advanceClock(f.hrs);
    g.px=p.to.x*TS; g.py=p.to.y*TS; g.dir='down'; unstick(); g.camX=g.px; g.camY=g.py-10; tileCache.clear(); g.lastTx=null;
    XS().rides=(XS().rides||0)+1;
    toast('The cart rattles to '+p.to.name+'. '+xIn(f.hrs)+' later.',3800);
  });
}
function openCart(t){
  const p=trvPlan(t), now=g.clock;
  if(!p) { say('Notice Board',['No carters are due through '+t.name+' today. Check again tomorrow.']); return; }
  if(p.gone) { say('Notice Board',['The carter who stopped in '+t.name+' today has already rolled on.']); return; }
  const f=trvFare(p.d);
  if(now<p.arr) say('Notice Board',['Word is a carter ('+p.name+') is due into '+t.name+' around '+hourLabel(p.arr)+', coming from '+p.from+'.','They are bound for '+p.to.name+' and sell seats. Fare about '+f.cost+' crumbs.']);
  else if(now<p.leave) say('Notice Board',[p.name+', a weary carter from '+p.from+', is resting by the notice board until about '+hourLabel(p.leave)+'.','Bound for '+p.to.name+'. Fare: '+f.cost+' crumbs, about '+xIn(f.hrs)+' on the road.']);
  else say('Notice Board',['A carter ('+p.name+') passed through '+t.name+' earlier today and has already moved on.']);
}
{
  const _specialTalk=specialTalk;
  specialTalk=function(n){
    if(n.special!=='traveler'){ _specialTalk(n); return; }
    const t=n.town||townAtTile(Math.floor(n.x/TS),Math.floor(n.y/TS));
    const p=n.kidx!==undefined?trvKing(n.kidx).plan:(t&&trvPlan(t));
    if(!p||p.gone){ say(n.name,['"Hm? Oh. I am only resting my hooves."']); return; }
    n.dir=OPP[g.dir]; n.moving=false; n.talking=true;
    const done=()=>{ n.talking=false; n.t=1; };
    const f=trvFare(p.d);
    const lines=p.perm?['"Welcome to Mallardia, small traveller. The Kingsbill carters wait here for fares, rain or shine."','"I am running to '+p.to.name+' today. Seat is '+f.cost+' crumbs: that is the distance, not the company."']:['"Oof. Oh! A friendly face. Pardon me. I have been on the road since before the sun was properly up."','"Came all the way from '+p.from+'. Heading on to '+p.to.name+'. If you want a seat on the cart, it is '+f.cost+' crumbs. That is the distance, not the company."'];
    say(n.name,lines,()=>{
      choose(n.name,'Ride to '+p.to.name+' for '+f.cost+' crumbs ('+xIn(f.hrs)+' on the road)? You have '+g.crumbs+'.',['Pay and ride','Chat a while','Not now'],k=>{
        if(k===0){ done(); trvRide(t,p); }
        else if(k===1){ say(n.name,[pick(['"My feet have blisters, and the blisters have blisters. But the road is the road."','"The mule is called Gerald. He does not like to be hurried or complimented."','"I passed a lovely pond on the way. Did not stop. Regret it."','"Folk say there are strange things in the dark woods. I say strange things are everywhere. Mind the weather."'])],done); }
        else done();
      },2);
    });
  };
  const _specialMark=specialMark;
  specialMark=function(n){ if(n.special==='traveler') return n.talking?null:{ch:'$',col:'#ffd166'}; return _specialMark(n); };
  const _extraNpcs=extraNpcs;
  extraNpcs=function(list){
    _extraNpcs(list);
    if(g.scene!=='world') return;
    const tl=xPlayerTile(), t=townAtTile(tl.x,tl.y);
    if(!t){ if(inK(tl.x,tl.y)) for(let i=0;i<KSPOT.length;i++){ const r=trvKing(i); if(Math.abs(r.npc.x/TS-tl.x)<45&&Math.abs(r.npc.y/TS-tl.y)<40&&list.indexOf(r.npc)<0) list.push(r.npc); } return; }
    const n=trvNpc(t); if(n){ n.town=t; if(list.indexOf(n)<0) list.push(n); }
  };
}

/* ---------- weather ---------- */
const WXN={clear:'Clear',cloud:'Overcast',rain:'Rain',fog:'Fog',storm:'Storm'};
function wxWin(day){ const s=5+hash(day,3,4243)*6, e=Math.min(23,s+7+hash(day,5,4244)*9); return [s,e]; }
function wxKind(day){ const h=hash(day,31,4242); return h<0.45?'clear':h<0.62?'cloud':h<0.8?'rain':h<0.91?'fog':'storm'; }
function wxEndsAt(){ const k=wxKind(g.day); return k==='clear'?0:wxWin(g.day)[1]; }
function wxAmt(){
  const k=wxKind(g.day); if(k==='clear') return 0;
  const [s,e]=wxWin(g.day), c=g.clock; if(c<s||c>e) return 0;
  let a=Math.min(1,(c-s)/1.2,(e-c)/1.2);
  if(k==='fog'&&XS().fogUntil>xAbs()) a*=Math.max(0,1-(XS().fogUntil-xAbs())*0.6);
  return Math.max(0,a);
}
function wxNow(){ return wxAmt()>0.02?wxKind(g.day):'clear'; }
const wxP=[]; let wxFlash=0, wxNext=6, wxDay=0, wxMsgDay=0;
function wxDrawOverlay(c,W,H,kd){
  const k=wxNow(), a=wxAmt(); if(k==='clear'||g.scene!=='world') { wxP.length=0; return; }
  const u=Math.max(1.5,kd*1.3), dt=frameDt;
  const tile=xPlayerTile(), tw=townAtTile(tile.x,tile.y), snow=tw&&tw.style&&tw.style.id==='frost';
  if(k==='cloud'){ c.fillStyle='rgba(70,80,100,'+(0.14*a).toFixed(3)+')'; c.fillRect(0,0,W,H); return; }
  if(k==='fog'){
    c.fillStyle='rgba(205,212,218,'+(0.30*a).toFixed(3)+')'; c.fillRect(0,0,W,H);
    for(let i=0;i<5;i++){ const x=((g.time*8*(0.6+i*0.2)+i*W/4)%(W+300))-150, y=H*(0.15+i*0.17); const gr=c.createRadialGradient(x,y,10,x,y,180*kd/2+90);
      gr.addColorStop(0,'rgba(240,244,248,'+(0.22*a).toFixed(3)+')'); gr.addColorStop(1,'rgba(240,244,248,0)'); c.fillStyle=gr; c.fillRect(x-300,y-300,600,600); }
    return;
  }
  const n=Math.round((k==='storm'?230:130)*a)+10;
  while(wxP.length<n) wxP.push({x:Math.random()*W,y:Math.random()*H,v:0.7+Math.random()*0.6});
  while(wxP.length>n) wxP.pop();
  c.fillStyle='rgba(50,62,84,'+((k==='storm'?0.26:0.14)*a).toFixed(3)+')'; c.fillRect(0,0,W,H);
  if(snow){
    c.fillStyle='rgba(255,255,255,0.85)';
    for(const p of wxP){ p.y+=dt*H*0.12*p.v; p.x+=Math.sin(p.y*0.02+p.v*5)*dt*30; if(p.y>H) { p.y=-5; p.x=Math.random()*W; } c.fillRect(p.x,p.y,u,u); }
  } else {
    c.strokeStyle='rgba(186,210,238,'+(0.5*a+0.15).toFixed(2)+')'; c.lineWidth=Math.max(1,u*0.5); c.beginPath();
    const sl=k==='storm'?0.35:0.16, len=(k==='storm'?16:11)*u;
    for(const p of wxP){ p.y+=dt*H*(k==='storm'?1.5:1.1)*p.v; p.x-=dt*H*sl*p.v*(k==='storm'?1.5:1.1); if(p.y>H){ p.y=-len; p.x=Math.random()*(W+200); } if(p.x<-20) p.x+=W+40; c.moveTo(p.x,p.y); c.lineTo(p.x-len*sl,p.y+len); }
    c.stroke();
  }
  if(k==='storm'){
    wxNext-=dt; if(wxNext<=0){ wxNext=7+Math.random()*10; wxFlash=0.22; setTimeout(()=>{ if(g.sound) tone('sawtooth',90,35,0.8,0.07); },500+Math.random()*900); }
    if(wxFlash>0){ wxFlash-=dt; c.fillStyle='rgba(235,240,255,'+(Math.max(0,wxFlash)*2.4).toFixed(2)+')'; c.fillRect(0,0,W,H); }
  }
}
{
  const _drawParts=drawParts;
  drawParts=function(c,kind,kd){
    _drawParts(c,kind,kd);
    wxDrawOverlay(c,cv.width,cv.height,kd);
    /* a Lumen glow around you in the dark */
    if(XS().lumenUntil>xAbs()&&(NIGHT>0.12||g.dkLevel>0.05)){
      const W=cv.width,H=cv.height, r=170*kd, gl=c.createRadialGradient(W/2,H/2-10*kd,6,W/2,H/2-10*kd,r);
      gl.addColorStop(0,'rgba(200,225,255,0.34)'); gl.addColorStop(1,'rgba(200,225,255,0)'); c.fillStyle=gl; c.fillRect(0,0,W,H);
    }
  };
  const _updateHud=updateHud;
  updateHud=function(){
    _updateHud();
    if(g.scene!=='world') return;
    const w=wxNow(); if(w==='clear') return;
    const base=areaName(), want=base+'  -  '+WXN[w];
    if(el.area.textContent!==want){ el.area.textContent=want; hudCache.area=base; }
  };
}

/* ---------- spells in the world (press C) ---------- */
const SPCD={Spark:1,Kindle:0.5,Lumen:4,Gust:3,Ward:24,Mend:0,Stone:0,Seek:2,Bind:1,Frost:24,Veil:3,Hearthsong:12};
const SPNEED={Kindle:'emberwand',Lumen:'lumenorb',Gust:'gustcharm',Ward:'wardcharm',Stone:'runestone',Seek:'seekerbeetle'};
function spellReady(n){ const c=(XS().cd||{})[n]||0; return c<=xAbs(); }
function setCd(n,h){ const x=XS(); x.cd=x.cd||{}; x.cd[n]=xAbs()+h; }
function spellLines(n){ return SPELLS.find(s=>s[0]===n); }
function castSpell(n){
  const x=XS(), st=g.story, need=SPNEED[n];
  if(need&&!isHeld(need)){ say('',[g.inv[need]?holdText(need)+' '+n+' needs it in hand.':'The '+ITEMS[need].name+' is not in your pack. '+n+' needs it.']); return; }
  if(!spellReady(n)){ say('',['The magic has not settled yet. '+n+' will be ready in '+xIn(x.cd[n]-xAbs())+'.']); return; }
  const done=(msg,cd)=>{ setCd(n,cd===undefined?SPCD[n]:cd); coin(); toast(msg,3600); };
  const tl=xPlayerTile();
  switch(n){
    case 'Spark': g.boost=Math.min(150,g.boost+30); done('Spark: a small warm light spreads through your feathers. You feel quick.'); break;
    case 'Kindle': {
      const fid=FISHIDS.find(id=>g.inv['fish_'+id]&&id!=='oldboot');
      if(!fid){ say('',['Kindle wants something to cook. Catch a fish first. (A rod is sold at the supply shop.)']); return; }
      delInv('fish_'+fid); addItem('roastfish'); done('Kindle: the wand glows and the '+FISHBY[fid].n+' roasts to a golden crisp. (Roast Fish added.)'); break; }
    case 'Lumen': x.lumenUntil=xAbs()+4; done('Lumen: a soft orb of light drifts at your shoulder for four hours.'); break;
    case 'Gust': {
      if(wxKind(g.day)==='fog'&&wxAmt()>0.05){ x.fogUntil=xAbs()+6; done('Gust: the fog tears apart and blows away. It will stay thin for a while.'); }
      else if(wxNow()==='rain'||wxNow()==='storm'){ x.rainStop=xAbs(); done('Gust: the rain hesitates. It is still raining. The wind is impressed, anyway.'); }
      else done('Gust: a pleasant breeze. Nothing to clear. A few leaves spin and curtsy.',1); break; }
    case 'Ward': st.luckDay=g.day; done('Ward: a quiet knot of luck settles over you for the rest of the day. Crumb rewards come a little richer.'); break;
    case 'Mend': {
      if((x.rodWear||0)>0){ x.rodWear=0; done('Mend: the frayed line knits itself whole. Your fishing rod is as good as new.',0); }
      else if(g.inv.fishrod) say('',['Mend finds nothing broken. Your rod is fine. A small, sensible sort of magic.']);
      else say('',['Nothing here needs mending. (Mend repairs a worn fishing rod.)']);
      return; }
    case 'Stone': {
      const v=DIRV[g.dir], fx=Math.floor((g.px+v.x*14)/TS), fy=Math.floor((g.py-6+v.y*14)/TS);
      let hit=null;
      for(let dy=-1;dy<=1&&!hit;dy++) for(let dx=-1;dx<=1&&!hit;dx++) if(tileAt(fx+dx,fy+dy)===T.ROCK) hit=[fx+dx,fy+dy];
      if(!hit){ say('',['Stone needs a rock to talk to. Face one and try again.']); return; }
      x.rocks=x.rocks||{}; const key=hit[0]+','+hit[1];
      if(x.rocks[key]&&x.rocks[key]+3>g.day){ say('',['This rock has been asked already. Give it a few days to think.']); return; }
      x.rocks[key]=g.day; const n=2+Math.floor(rnd()*4); g.crumbs+=n; addItem('pebble'); done('Stone: the rock splits along its own seams. A Shiny Pebble and '+n+' crumbs.',0); break; }
    case 'Seek': {
      let best=null; const rx0=Math.floor((tl.x+24)/REG), ry0=Math.floor((tl.y+24)/REG);
      for(let dy=-6;dy<=6;dy++) for(let dx=-6;dx<=6;dx++){ const t=getTown(rx0+dx,ry0+dy); if(!t||g.towns.has(t.key)) continue; const d=Math.hypot(t.cx-tl.x,t.cy-tl.y); if(!best||d<best.d) best={t:t,d:d}; }
      if(!best){ say('',['The beetle spins, then settles. No unfound town within a long walk. You have been thorough.']); return; }
      const a=Math.atan2(best.t.cy-tl.y,best.t.cx-tl.x), i=((Math.round(a/(Math.PI/4))%8)+8)%8;
      done('Seek: the beetle points '+['east','south-east','south','south-west','west','north-west','north','north-east'][i]+' '+ARROWS[i]+'. About '+Math.round(best.d/5)*5+' waddles to a town you have not found.'); break; }
    case 'Bind': x.bind=1; done('Bind: a ribbon of light ties itself loosely round your next cast. The fish will be easier to hold.'); break;
    case 'Frost': x.frostDay=g.day; done('Frost: a cold hush settles over your catch. Fish sell for a quarter more today.'); break;
    case 'Veil': x.veilUntil=xAbs()+3; done('Veil: you become wonderfully uninteresting for three hours. Fish will not notice you either.'); break;
    case 'Hearthsong': x.cd={}; g.boost=150; done('Hearthsong: you sing the whole song, and every spell is ready again.',SPCD.Hearthsong); x.cd.Hearthsong=xAbs()+SPCD.Hearthsong; break;
  }
}
function openCast(){
  const days=magicDays();
  if(days<1){ say('',['You know no spells yet. The Academy in Emberwick teaches them, one a day.']); return; }
  const list=SPELLS.slice(0,Math.min(12,days)).map(s=>s[0]);
  const labels=list.map(n=>{ const need=SPNEED[n], ok=!need||isHeld(need), rd=spellReady(n);
    return n+(!ok?(g.inv[need]?'  (hold the '+ITEMS[need].name+')':'  (needs '+ITEMS[need].name+')'):rd?'':'  (ready in '+xIn(XS().cd[n]-xAbs())+')'); });
  pagedChoose('Cast','Which spell? (C opens this menu anywhere.)',labels,i=>castSpell(list[i]));
}
{
  const _press=press;
  press=function(k){
    if(k==='c'&&g.mode==='play'&&g.scene==='world'){ openCast(); return; }
    _press(k);
  };
}

/* ---------- the per-frame bookkeeping ---------- */
{
  const _storyUpdate=storyUpdate;
  let t2=0;
  storyUpdate=function(dt){
    _storyUpdate(dt);
    if(g.mode==='title'||g.scene!=='world') return;
    const x=XS();
    if(XS().lumenUntil>xAbs()) g.dkLevel*=0.6;
    t2-=dt; if(t2>0) return; t2=1;
    const p=xPlayerTile();
    if(inK(p.x,p.y)&&!x.kvisit){ x.kvisit=1; collStamp('Mallardia','kingdom'); }
    const tw=townAtTile(p.x,p.y);
    if(tw) collStamp(tw.name,tw.key);
    if(tw&&g.mode==='play'){ const cp=trvHere(tw), rec=TRV[tw.key]; if(cp&&rec&&!rec.told){ rec.told=1; toast('A weary carter ('+cp.name+') has pulled in by the notice board. Bound for '+cp.to.name+'.',4200); } }
    if(g.mode==='play'){
      if(wxDay!==g.day&&wxKind(g.day)!=='clear'&&wxAmt()>0.1){ wxDay=g.day; toast('Weather: '+WXN[wxKind(g.day)]+' today.',3000); }
      if(magicDays()>=1&&!x.castHint){ x.castHint=1; toast('You can cast spells! Q and E choose one, C casts it. Or hold a magic item and press Z.',5200); }
      collCheck();
    }
  };
}
