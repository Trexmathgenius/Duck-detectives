'use strict';
/* ===== INSIDE THE CHAPTERS (v1.21) =====
   1. OPENINGS: every chapter from 6 to 20 now opens by telling you what your last turn did to the world.
   2. BEATS: six mid-chapter scenes that happen when an objective completes, so the chapters have something in the middle, too. */

const Tn=n=>S4.cx('t'+n);
const OPEN={
 6:{r:{sworn:'The thread on your wrist is already fraying at the knot. People look at it first, and then at you, and the looking is a little different from yesterday.',conditional:'There are two loops of thread on your wrist, not three, and a number of people have noticed and are being polite about it.',unsworn:'Nobody has tied anything to you. The town does not know where to put its eyes when you pass.'},
    c:{sworn:'The Chancellor\'s clerks hold doors for you now. It is a strangely lonely thing, to be held doors for.',conditional:'In the margin of a framed oath is a line in your hand. People stop to read it. Nobody says what they think.',unsworn:'You are a visitor in the Court. Nobody has asked you to leave, which is its own way of watching.'}},
 7:{r:{took:'The Hollow Wood has gone quiet at night. You notice it first in the lantern, where the flame leans toward the north-west and no longer wavers.',left:'A small lamp is burning at the shrine, and someone has begun to leave crumbs at the foot of it. Nobody has been seen doing either.',returned:'The Elders are cold at breakfast, and the Hearth is a shade dimmer than it was. You have made an enemy of the sun.',silent:'Tansy\'s threads are tied round three gateposts this morning, three loops and a knot. Nobody will say who they are for.'},
    c:{sheltered:'Lark\'s note is in your pocket, folded small. Somewhere east, a copyist is learning to milk a goat. It is a better outcome than most.',processed:'In the laundry, a thin figure bends over the boiling-vat and does not look up. The Court has found a use for them.',blamed:'There is a young man two doors down who is bad at pretending not to follow you. You find you do not mind.',silent:'The cells under the east passage are quiet. You walk the long way round the stair.'}},
 8:{r:{cordial:'Mallow is a shade steadier this morning, and he looks at the lantern now like a man looking at a friend instead of a bill.',readaloud:'Poppy has fallen asleep against Mallow\'s arm. He has not moved in an hour, for fear of waking her.',waited:'There is a cup of tea outside your door, still warm, with nobody near it.',forced:'Mallow has been very quiet since the doorstep. He takes the letter out, looks at it, and puts it away again.'},
    c:{paid:'There is a carved wooden goose on the inn windowsill, very badly made. Nobody will admit to leaving it.',road:'Two hundred soldiers with spades have mended the Gate road. The Hollow\'s scouts watched them do it from the hill, and drew a conclusion.',refused:'A goose was stolen from a stall this morning. A small thing. You find you are keeping a count of small things.'}},
 9:{r:{court:'The Hearth\'s court has sat on Brand. People are saying very little about it, in a very loud way.',free:'Brand has gone from the east gate. He left a trimmed candle on the cellar step, and a great many questions.',kept:'Brand is eating what you bring him. He says thank you. It is the most alarming thing about him.'},
    c:{kept:'Mallow has not told the Crown you were on the west hill. He has moved his fire deeper into the hills.',half:'Halbeak accepted half a truth and did not ask for the other half. He has the look of a man who knows.',told:'Mallow has been brought in. He does not look at you. He is unfailingly polite, which is the worst of it.'}},
 10:{'*':{listened:'The hall at Quackenhold is quieter than you remember it. You have stopped being afraid of it, and you are not sure that is a good sign.'}},
 11:{'*':{promised:'You have made a king a promise. It sits in your chest like a stone that is also a small warm animal.',tried:'You promised the king you would try. It is a more honest promise than most, and it feels, annoyingly, less like a rope.',refused:'The king has stopped asking. It is a kind of silence you can carry but not put down.',sat:'The dark in the throne room has followed you out. It is not a threat. It is a company.'}},
 12:{'*':{truth:'You came out of the Tree knowing how the siege went, both sides of it, in arithmetic. The knowledge has not made you any less tired.',silence:'The Tree\'s hum comes back on, apologetic, as you walk away. It had been silent for exactly one night, and it knows what it cost.',nothing:'The Tree has kept your nothing, small and warm. You feel strangely lighter for having asked it for no help.'}},
 13:{'*':{owned:'Both camps are quoting your sentence about the failed summit. Children play at being you, saying: it was mine, I should have said.',blamedcrown:'The Hearth calls you honest. The Crown calls you something else. Both words have gone warm in the mouth.',blamedhearth:'The Crown calls you honest. The Hearth calls you something else. Both words have gone warm in the mouth.',room:'You said the failure belonged to the room. Nobody was satisfied. Everybody is thinking about it.'}},
 14:{r:{public:'The new plaques on the Wall are still bright. Someone has chalked something across them. Sorrel scrubbed it off at dawn.',elders:'The Elders cut the Wall gently, at night, one plaque at a time. The town has not yet noticed it is being told something.',hid:'The children are still reciting the old story at the school gate, every word. You find it harder to hear than before.'},
    c:{exposed:'The plaza is a river of paper. Lords who were friends yesterday cannot meet each other\'s eye.',quiet:'The Court\'s books were opened in a back room, by candlelight. The Court is smaller, and honest in its bookkeeping, and no one has thanked anyone.',reserve:'There is something in a drawer you did not mean to keep. Mink bows too low when you pass.'}},
 15:{r:{named:'Six names went to the Hearth\'s court. The boy from the list will be twelve for a very long time.',work:'The baker lays his bread on the wall every morning at six and says nothing. The wall is taller than it was.',ringleader:'The Hands have lost Carrow, their most useful hand. The word "Brand" is being spoken more quietly.'},
    c:{told:'Halbeak has burned the page. It took longer than he expected. He is writing to a king he has never met.',kinder:'Halbeak has not asked for the whole answer. He carries the page folded in four, as one carries a thing not yet decided.',ask:'Halbeak\'s boots have been polished twice, and the sergeant has stopped asking why.'}},
 16:{r:{asked:'Poppy has a new walk. It is the walk of a person who was asked.',sent:'Poppy says "Good afternoon" exactly, and with a nod, and does not stop. She is nine and a half and has never been so formal.',used:'Poppy carries the lantern like a secret. She likes the job. She also knows why she was given it.'},
    c:{lent:'The coal came back a little dimmer. Halbeak\'s sergeant salutes you with unusual exactness.',kept:'The coal glows in its iron cup, and nobody asks to see it. The sergeant\'s salute has a notch in it.',spark:'Somewhere in a village you will never see, a lamp lit from the First Hearth is burning in a kitchen. You carry the rest.'}},
 17:{r:{blamed:'Orrel keeps his stripe. He has written to his mother. In the letter, you are a person who stood in a doorway.',letter:'There is a pie in your pack with a pastry lantern on top. It was from a mother you have never met.',silent:'You find yourself watching the boots of every guard you pass.'},
    c:{shielded:'Ruddock has said he will tell the truth about the gate, whatever you said. He is a poor liar and a good warden.',stood:'You stood in the line while Ruddock told his elders the truth. The thaw between the towns is two degrees.',left:'Ruddock has been demoted for a season. He does not complain. He does not forget.'}},
 18:{'*':{kept:'You carried all of it into the Wood, and the Wood let you. You are the same size you were, and it is much louder.',setpride:'You left something at the edge of the Wood. The place where it was is cool, like the dent in a pillow.',setcost:'You left the heaviest thing at the edge of the Wood. What fills the space has not yet decided what it is.'}},
 19:{'*':{boy:'In the dark under the Tree, a boy has said "Mama?" and somebody has answered. It is the best sound anyone has made in a hundred years.',tam:'Tam is awake, and grumbling, and giving orders. It is a relief to everyone, including you.',girl:'The youngest sleeper is awake. She asked if it was morning. Everyone has been trying to think of a way to say yes.',silent:'The sleepers woke all at once and out of order. For an hour, the clearing was shouting. It sorted itself out, as things do.'}},
 20:{'*':{listened:'The king\'s last words are in your pocket like a smooth stone: be a person that someone could write a letter to.'}}
};
{
  const _begin=S2.begin;
  S2.begin=function(id,skip){
    try{
      const c=S2.ch[id], m=/^c(\d+)([rc]?)$/.exec(id);
      if(c&&m){
        const num=+m[1], tbl=OPEN[num];
        c.__i0=c.__i0||(c.intro||[]).slice();
        let extra=null;
        if(tbl){
          const rt=m[2]||(s2red()?'r':'c');
          const v=tbl[rt]||tbl['*'];
          const prev=Tn(num-1);
          if(v&&prev&&v[prev]) extra=v[prev];
        }
        c.intro=extra?c.__i0.concat([extra]):c.__i0;
      }
    }catch(e){ console.error(e); }
    return _begin(id,skip);
  };
}

/* ---------- beats: scenes in the middle of a chapter ---------- */
const MID={};
const midSeen=()=>{ const q=s2(); return q.mid||(q.mid={}); };
const MIDQ=[];
const beat=(key,def)=>{ MID[key]=def; };
function runBeat(key,def,done){
  const tag='m_'+key.replace(':','_');
  const say1=(who,pages,cb)=>say(who,pages,cb);
  if(def.fmt==='listen'){
    say(def.who,def.pre,()=>{ turnApply(tag,def.result); say(def.afterWho===undefined?def.who:def.afterWho,def.after,()=>{ coin(); done(); }); });
    return;
  }
  say(def.who,def.pre,()=>{
    const opts=def.opts.filter(turnOK);
    choose(def.who,def.q,opts.map(turnLabel),k=>{
      const o=opts[k]; turnApply(tag,o);
      say(o.who||def.who,o.say,()=>{ coin(); done(); });
    },opts.length-1);
  });
}
{
  const _set=s2set;
  s2set=function(n){
    const q=s2(), before=q.step;
    _set(n);
    try{
      if(q.ch&&before!==n){
        const key=q.ch+':'+n, m=MID[key];
        if(m&&!midSeen()[key]){ midSeen()[key]=1; MIDQ.push({key,def:m}); }
      }
    }catch(e){ console.error(e); }
  };
  const _su=storyUpdate; const mc={t:0};
  storyUpdate=function(dt){
    _su(dt);
    if(!MIDQ.length||g.mode!=='play'||!g.story||!g.story.s2) return;
    if(typeof SX!=='undefined'&&SX.S&&SX.S.timer&&SX.S.timer.t>0) return;
    mc.t+=dt; if(mc.t<2.5) return; mc.t=0;
    const b=MIDQ.shift(); try{ runBeat(b.key,b.def,()=>{}); }catch(e){ console.error(e); }
  };
}

/* c5r step 2: the Dawn Bell */
beat('c5r:2',{who:'Warden Ruddock',fmt:'choice',
  pre:['The Dawn Bell is still shivering in its frame. Ruddock has taken the rope from your hands, gently, as one takes a thing from a child that it has held long enough.','"I ring it every morning," he says. "Nobody asked me to. I say a name, with every stroke. Eleven strokes. Eleven names. Then I go and be unpleasant to people until dusk."','"Say one. Not aloud, if you would rather not. The bell does not mind how it is told."'],
  q:'The bell hums down. Ruddock waits, not looking at you.',
  opts:[
   T6o('Say a name aloud, someone you lost.',{led:{kin:1},h:'tender',flag:'name',mem:'said a name aloud under the Dawn Bell',say:['You say it. It comes out smaller than you meant. The bell, to your surprise, answers: a thin, round note, held, as if listening.','Ruddock nods slowly. "That is how it works," he says. "You will say it again. It does not get easier. It gets said."']}),
   T6o('Ring the bell once more, in silence.',{h:'guarded',flag:'silent',mem:'rang the bell once more and told no one why',say:['You ring it once. The sound goes out over the roofs and does not come back. Ruddock watches you do it, and does not ask.','"Fair," he says. "A name does not have to be said to be rung."']}),
   T6o('"Whose names are yours?"',{led:{truth:1},h:'candid',flag:'asked',mem:'asked a warden whose names he rings for',set:()=>{ A5().ilseSeed=1; },say:['He is quiet for the length of a held breath. "A girl named Ilse is the first. She went up to the ward-stone on a bad night to hold it by hand. I was on the watch. I let her go."','"The others are all the ones I did not stop. Eleven. It is a poor sort of list." He hangs the rope on its hook. "Do not say you are sorry. The bell has been told."']})]});

/* c6r step 4: what to tell the town */
beat('c6r:4',{who:'Hearthwarden Pyre',fmt:'choice',
  pre:['You carry the Keeper\'s Lantern out of the Hollow Wood and through the south gate. The flame leans north-west with a patient, constant insistence, like a dog that has heard its name called a long way off.','Hearthwarden Pyre meets you at the Great Hearth. He looks at the flame, and then at the Hearth, and the two are leaning, just slightly, in the same direction.','"If I say what that means, the town will panic. If I do not, they will find out from the shrine road, from a stranger, in the worst way. I have been hearthwarden for forty years. I have never once had a good option."','"You carried it. You choose."'],
  q:'The flame leans. Pyre waits. The town is going about its morning.',
  opts:[
   T6o('"Tell them now, plainly, from the steps."',{cap:{hearth:1,sleepers:1},led:{truth:1},h:'candid',flag:'tell',mem:'told the town the truth about the Hearth from the steps',say:['Pyre tells them. It takes a quarter of an hour. Nobody screams. A woman drops a basket. A man laughs once, and stops.','By noon the square is full of quiet conversations in doorways. It is not panic. It is something slower and much harder to manage: the beginning of thinking.']}),
   T6o('"Wait for the Elders. It is theirs to say."',{cap:{hearth:1},led:{trust:1},h:'steady',flag:'wait',mem:'let the Elders decide what the town should be told',say:['Pyre nods, relieved. "It is the proper road." The Elders take three days. The town, in the meantime, knows anyway, as a town does.','You will notice, later, that the Elders thanked you for waiting, and that no one else did.']}),
   T6o('Carry the lantern through the square, openly, and let it speak.',{cap:{hearth:0,mallow:1},led:{mercy:1},h:'gentle',flag:'show',mem:'carried the lit lantern through the square and said nothing',say:['You walk the whole length of the square with the lantern held a little in front of you. The flame leans. People stop.','A child points. Her mother lowers the child\'s hand, then, after a moment, points too. Nobody says a word. It is, Pyre says afterwards, the cleanest announcement he has ever witnessed.']})]});

/* c13r step 1: the Hearth's own quiet faction */
beat('c13r:1',{who:'Hearthwarden Pyre',fmt:'choice',
  pre:['The council is arguing in three languages at once: wall, rite, peace. You slip out for air, and Pyre follows, carrying nothing, which is itself unusual.','"I will tell you what I do not tell the town. Some of us in the Hearth believe the flame is fed by the sleepers\' dream. That the ward does not only hold them. It warms us."','"I do not know it is true. I only know that if it is, then waking them puts out the Hearth. There are those among the Elders who would rather keep a hundred ducks asleep than lose the fire. They are not wicked. They have children."'],
  q:'Pyre has never said this to anyone. He does not know what he wants you to do with it.',
  opts:[
   T6o('"Tell Cinder. She has a right to know."',{cap:{hearth:1,sleepers:1},led:{truth:1},h:'candid',flag:'tellcinder',mem:'carried the Hearth\'s hardest suspicion to Elder Cinder',say:['Cinder listens, and goes grey, and sits down on the nearest bench. "I have known," she says. "Not known. Feared. It is the same word at three in the morning."','"Thank you for bringing it to me and not to the square." She holds the word in her hands, and does not drop it.']}),
   T6o('"Keep it between us. It might not be true."',{cap:{hearth:0,sleepers:-1},led:{lie:1},h:'guarded',flag:'secret',mem:'kept a hard suspicion about the Hearth to yourself',say:['Pyre nods. He looks relieved and a little ashamed. "Between us," he says. It is a very small word for something that size.','It will sit in your chest through the next chapters. It will have company.']}),
   T6o('"Ask Mallow. He has been alone with the question the longest."',{cap:{mallow:1},led:{trust:1},h:'steady',flag:'mallow',mem:'sent a hard question to the oldest hermit',say:['Pyre stares. "Mallow. I had forgotten that he knew." He turns it over. "It is an odd thing, to be sent to the very person one has been avoiding."','He goes, in the end, that evening, with a lantern and a bad conscience. He does not tell you what Mallow said. He is lighter the next morning.']})]});

/* c13c step 1: Lady Teal, the other face of the Quiet Chair */
beat('c13c:1',{who:'Lady Teal',fmt:'choice',
  pre:['The names are in your notebook: Gander, Plume, Teal, Mink. The war chest is open. You are in the arcade, going over the arithmetic one more time, when Lady Teal sits down on the bench beside you with great composure.','"I know you have my name. I wanted to be the one to say it." She smooths her skirt. "I funded it. Not for war. For quiet."','"My daughter was six. She walked into the Burnt Wood on a dare, and came out four hours later, silent. She has not spoken since. She is thirty now. She hums, sometimes, four notes, over and over."','"I would pay anything to keep that door shut. I did. I am sorry for what it bought."'],
  q:'Lady Teal is not asking you for forgiveness. She is asking you to look at her.',
  opts:[
   T6o('"I understand. Stand down, and I will tell no one why."',{cap:{crown:2},led:{mercy:1},h:'gentle',flag:'understand',mem:'let a grieving mother stand down with her reasons kept',say:['She closes her eyes. When she opens them they are bright and a little frightening. "Thank you. I will do it by dinner."','She does. By dinner, the chest is closed, and half the Court has been told it was a clerical error. She sends you a single candle, with no note.']}),
   T6o('"Your daughter is why we are here. Tell the whole Court. They should know."',{cap:{crown:1,sleepers:1},led:{truth:1},h:'candid',flag:'tell',mem:'asked a mother to tell the Court why she had done it',say:['She is white. "In public." "In the council room." She stands, very straight. "Yes," she says. "I think I must."','She tells it, plainly, that evening, and the room, which has been a pit of knives for a month, goes quiet for the first time. Two lords weep. One leaves. Nobody forgets it.']}),
   T6o('"Come to the road council. We will need someone who knows what the Wood costs."',{cap:{crown:1,sleepers:1,mallow:1},led:{trust:1},h:'steady',flag:'seat',mem:'offered a grieving mother a seat on the road council',say:['Teal stares, then, slowly, laughs, a surprised and rusty sound. "A seat. For the woman who tried to buy a wall." "For the woman who paid for it dearly."','"I will come," she says. "I will not say much. But I will be in the room, and I will remember what it is for."']})]});

/* c14c step 1: Halbeak and his sergeant */
beat('c14c:1',{who:'Sergeant Marl',fmt:'choice',
  pre:['The recall is in place. The barracks office is quiet, and the March has been unmade on paper. Halbeak is standing at the south wall with his hands behind his back, and his sergeant has come up beside him, cap crushed in both fists.','"Sir," says Marl. "Two hundred men. We have drilled six weeks. We have no enemy and no orders. Sir, I have been a soldier for thirty-one years. Who are we if we are not the march?"','Halbeak does not answer. He turns, and looks at you, and Marl looks at you, and it is suddenly, strangely, your question.'],
  q:'Marl is not being rhetorical. He is a man asking the only question he has.',
  opts:[
   T6o('"You are the road\'s guard. The road needs one."',{cap:{crown:1},led:{trust:1},h:'steady',flag:'guard',mem:'told a sergeant his army was now the road\'s guard',say:['Marl turns the cap over. "A road\'s guard." He says it again, trying the weight. "I have guarded a good many things. Never a thing that was only a way between two places."','"I like it," he says, in the end. It is the first time anyone has seen him look young.']}),
   T6o('"You are the ones who chose not to march."',{cap:{crown:1,sleepers:1},led:{truth:1},h:'candid',flag:'chose',mem:'told a sergeant his army had chosen not to march',say:['Marl is silent. Halbeak says, gently, "That is the harder one. It is also the only one I would not be ashamed of."','"We did not choose," Marl says, with great honesty. "We were told." "Then choose tomorrow," you say. "It counts anyway."']}),
   T6o('"That is yours to decide. It takes more than one night."',{cap:{crown:0,mallow:1},led:{mercy:1},h:'gentle',flag:'time',mem:'told a sergeant it takes more than a night to decide who you are',say:['Marl lets out a breath that is half a laugh. "Thirty-one years, and a stranger tells me it takes more than a night. I could have used that at twenty."','He salutes you, a little crookedly, and goes to see about the men. Halbeak, watching him go, says: "He will be all right. That was the right amount of nothing."']})]});

/* c18 step 1: a sleeper's dream (listen only) */
beat('c18:1',{who:'A Sleeper, dreaming',fmt:'listen',afterWho:'',
  pre:['You are walking the ring of sleepers, hearing them as you were told to, one at a time. Most of them hum in their sleep, four slow notes. One of them, a young soldier in a faded jerkin, does not hum. He talks.','"We were not marching," he says, to the ash, in a voice like a dry leaf. "I want that known. We were following the song."','"It came down the road from the wood in the dark, a lullaby, and we thought: somebody is calling. We were tired. We had been tired a long time. So we followed. We were three hundred and we were very quiet."','"The ones on the walls shouted. We did not hear. We were listening for the second verse. It never came. They told us, afterwards, that it was a war. We never knew we had been in one."'],
  result:{cap:{sleepers:1},led:{truth:1,kin:1},h:'tender',flag:'dream',mem:'heard a sleeper explain they had been following a song'},
  after:['The young soldier\'s mouth moves a little more, then closes. Under the Tree, the hum steadies, a half-tone sharper.','You stand where you are for a long while. There is a lesson in it somewhere about listening. You do not try to find it. It will find you.']});
