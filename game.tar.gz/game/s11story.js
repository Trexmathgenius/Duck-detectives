'use strict';
/* ===== v1.27.1: THE ROAD ASKS FOR WHAT THE FOREST TEACHES =====
   Version 1.27 gated three chapters behind sandbox work. That interrupted the story, so the gates are gone.
   In their place are eight REQUESTS: people on the road who need something the sandbox can supply (fish for a hungry family,
   herbs for a feverish soldier, a potion for a sleepers' ward, whatever you dug up in a field). Nothing blocks the story.
   Every request is a moral choice, and every one has at least one answer that needs no sandbox skill (the honest word, the
   sitting-with, the crumbs). What the sandbox adds is more ways to help, and the help is bigger. Each answer feeds the same
   hidden ledger as the older complications (truth, lie, mercy, pride, trust, kin, the four factions, and the memories the
   epilogue recalls), and people mention it afterwards.
   - A request appears about 20 seconds into the open world while its chapter window is open, one at a time.
   - It stays until the window closes. After that the person has managed without you (no penalty, but the chance is gone).
   - Old v1.27 saves that were standing at a gate chapter are finished automatically.
   Progress is saved in g.story.x11.req. Exposes D10.requests, D10.reqTick, D10.reqState. */
(function(){
'use strict';
const D10=window.D10=window.D10||{};

/* ---------- reading the pack ---------- */
const FV=id=>(FISHBY[id]&&FISHBY[id].v)||0;
const fishIds=rare=>FISHIDS.filter(id=>!(FISHBY[id]&&FISHBY[id].junk)&&(!rare||FISHBY[id].rare));
const fishHave=rare=>fishIds(rare).reduce((a,id)=>a+(g.inv['fish_'+id]||0),0);
function fishTake(n,rare){ for(const id of fishIds(rare).sort((a,b)=>FV(a)-FV(b))) while(n>0&&g.inv['fish_'+id]>0){ delInv('fish_'+id); n--; } }
const ingHave=()=>{ try{ return Object.values(BS().ing).reduce((a,b)=>a+b,0); }catch(e){ return 0; } };
function ingTake(n){ const b=BS().ing; for(const k of Object.keys(b).filter(k=>b[k]>0).sort((x,y)=>(+x.split(':')[1])-(+y.split(':')[1]))) while(n>0&&b[k]>0){ b[k]--; n--; } }
const relicIds=()=>Object.keys(g.inv).filter(id=>g.inv[id]>0&&/^(d_|tr_|r_)/.test(id)&&ITEMS[id]);
const relicHave=()=>relicIds().reduce((a,id)=>a+g.inv[id],0);
function relicTake(n){ for(const id of relicIds().sort((a,b)=>(ITEMS[a].sell||0)-(ITEMS[b].sell||0))) while(n>0&&g.inv[id]>0){ delInv(id); n--; } }
const potIds=()=>Object.keys(g.inv).filter(id=>g.inv[id]>0&&/^p_/.test(id)&&ITEMS[id]);
const potHave=()=>potIds().reduce((a,id)=>a+g.inv[id],0);
function potTake(n){ for(const id of potIds()) while(n>0&&g.inv[id]>0){ delInv(id); n--; } }
function bestStanding(){ let best={r:0,key:null}; for(const k in g.rep){ const r=rankOf(g.rep[k]||0); if(r>best.r||best.key===null) best={r:r,key:k}; } return best; }


/* ---------- the requests ---------- */
const ST=()=>{ const s=g.story; if(!s) return {}; const x=s.x11||(s.x11={}); return x.req||(x.req={}); };
const REQ=[
 { id:'bree', a:6, b:8, who:['Nell, a fisher\'s widow',cxP('#6a8a9a','#4a6a7a'),'scarf'],
   brief:'A widow and three hungry children near the camp. Fish, a rod, or bread money would help.',
   intro:['(A woman sits on an upturned boat at the edge of the camp, mending a net that has more holes than net. Three small ducks are watching her work as though it were a performance.)','"Pike took the last of the line in the spring. Since then it has been bread, when there is bread. I am not asking for coin. I have nothing to put it against."','"If you fish, there are fish. If you do not, there is a child who is going to ask me again at supper."'],
   q:'The smallest child has stopped watching the net and started watching you.',
   gone:'(You hear the fisher\'s widow got her children through the week. You do not hear how.)',
   opts:[
    {t:'Bring them fish, enough for a good supper.',need:{fish:3},habit:'tender',led:{mercy:1,kin:1},cap:{hearth:1},flag:'fed',mem:'fed a widow\'s children with fish you caught yourself',
     say:['You lay the fish on the boat. The smallest child counts them aloud, twice, as if the number might change.','Nell does not say thank you. She turns away quickly, and begins to scale the first one, very fast, with her back to you.']},
    {t:'Show the eldest how to cast a line.',need:{rod:1,hours:2},habit:'steady',led:{trust:1,kin:1},cap:{hearth:1},flag:'taught',mem:'taught a fisher\'s child to cast a line',
     say:['It takes two hours and most of a pond\'s patience. The eldest catches a boot, a reed, and, at the very end, a perch the length of a wing.','She looks at it as if it were a crown. "Again," she says.']},
    {t:'Leave her enough crumbs for bread.',need:{crumbs:30},habit:'gentle',led:{mercy:1},flag:'paid',mem:'left a widow bread money',
     say:['Nell counts it, and counts it again, and puts it in her sleeve without a word. The children eat bread for a week.','The net, you notice, goes on being mended.']},
    {t:'Sell her your catch at the market price.',need:{fish:3},gain:18,habit:'guarded',led:{pride:1},flag:'sold',mem:'sold fish to hungry children at full price',
     say:['She pays from a tin that is nearly empty, and does not look at you. The fish are good. The price is fair.','It is the fairest thing you have done all day, and you do not feel fair.']}]},

 { id:'fennel', a:7, b:9, who:['Madder, an herbalist',cxP('#7a9a6a','#5a7a4a'),'hood'],
   brief:'An herbalist is nursing a feverish soldier and has run out of green things. Plants, a potion, or the honest word.',
   intro:['(An old herbalist crouches over a cot in the shade of a cart. The soldier on it has a face the colour of tallow and a cough you can hear from here.)','"Marshroot, feverfew, anything with a green stem. I have used up the camp\'s and the next camp\'s. He will not see Tuesday without a good tea."','"I cannot leave him to go and look. You, I think, walk about a good deal."'],
   q:'The soldier coughs, and apologises for it.',
   gone:'(You hear the soldier on the cot did, or did not, see Tuesday. Nobody tells you which.)',
   opts:[
    {t:'Gather what she needs from the wild.',need:{ing:5},habit:'tender',led:{mercy:1,kin:1},cap:{hearth:1},flag:'gathered',mem:'gathered herbs for a feverish soldier',
     say:['She sorts what you bring with fast, careful fingers, and is boiling something before you have finished speaking.','By evening the cough is a little less. "Green stem," says Madder, to nobody. "I always said."']},
    {t:'Give her one of your brewed potions.',need:{pot:1},habit:'steady',led:{trust:1,mercy:1},cap:{hearth:1},flag:'potion',mem:'gave a brewed potion to a stranger\'s fever',
     say:['She holds it up to the light, and her face does something complicated. "Sixty years an herbalist," she says, "and I would not know how you did this."','He drinks. Colour comes back to his face in stages, like a kettle.']},
    {t:'Pay for a proper apothecary\'s tonic.',need:{crumbs:40},habit:'gentle',led:{mercy:1},flag:'bought',mem:'paid for a stranger\'s fever tonic',
     say:['A runner is sent. The tonic comes before dark, in a small brown bottle, and costs rather more than it should. The soldier drinks it and sleeps.']},
    {t:'Tell her the truth: a fever like that rarely turns. Make him comfortable.',habit:'candid',led:{truth:1},flag:'honest',mem:'told a herbalist the honest odds',
     say:['She is quiet for a long time. "Yes," she says. "I know. I wanted someone to say it, so I could stop pretending I did not."','She sits beside him. She does not look for any more green things.']}]},

 { id:'tamsin', a:9, b:11, who:['Old Tamsin',cxP('#a8947a','#7a6a4a'),'scarf'],
   brief:'An old widow lost her wedding ring in a field forty years ago. A shovel, or something old you have dug up, could help.',
   intro:['(A very old duck is leaning on a gatepost, looking at a field that has been ploughed over and over. She turns an empty ring-box in her wings as if it had a hinge to find.)','"Forty years ago my Alder put a ring on me in this field. I took it off to knead bread and lost it, and he ploughed the whole field himself that autumn. He did not find it. He said it was in the ground, waiting."','"He is gone now. I should like to hold it once."'],
   q:'She is not expecting a yes. She asks like someone knocking on a door she knows is empty.',
   gone:'(You hear the field was ploughed again that autumn, by a stranger, who found nothing.)',
   opts:[
    {t:'Dig the field for it.',need:{shovel:1,hours:3},habit:'steady',led:{trust:1,kin:1},cap:{hearth:1},flag:'dug',mem:'dug a forty-year-old field for a widow\'s ring',
     say:['It takes three hours, a great deal of mud, and an uncomfortable number of bottle-tops. At the end, in a furrow no one has opened in forty years, there is something small and round that is almost certainly not a ring.','Tamsin holds it anyway. "It will do," she says. "He would have said it was the one."']},
    {t:'Give her something old you have dug up.',need:{relic:1},habit:'tender',led:{mercy:1,lie:1},flag:'gave',mem:'gave an old woman a ring that was not hers, and let her believe',
     say:['You press something into her wing. She turns it over once, twice. She is a very old duck, and not a fool.','"Thank you," she says, in the voice of someone agreeing to a kindness. She puts it on her finger anyway.']},
    {t:'Tell her it is gone, and sit with her a while.',need:{hours:1},habit:'candid',led:{truth:1,mercy:1},flag:'sat',mem:'sat with an old woman and told her the ring was gone',
     say:['You sit on the wall beside her. After a while she tells you what Alder\'s hands looked like. After a longer while she stops needing the ring.']},
    {t:'Dig the field, find the ring, and keep what it is worth.',need:{shovel:1,hours:3},gain:55,habit:'guarded',led:{lie:1,pride:1},flag:'kept',mem:'dug up a widow\'s ring and sold it',
     say:['It is there, in the third furrow, exactly where a man who ploughed in a hurry would have turned it. It is worth rather more than you expected.','You tell Tamsin the field gave up nothing. She nods, and thanks you for trying. It is the thanks that stays.']}]},

 { id:'dill', a:10, b:12, who:['Quartermaster Pask',cxP('#8a7a5a','#6a5a3a'),'cap'],
   brief:'The camp has two days of stores and the road to the Tree is five. Fish and greens, crumbs, or a harder answer.',
   intro:['(Pask counts on his wing, does not like the answer, and counts again.)','"Two days of stores. The road to the Tree is five. Nobody will say it aloud, but it is a sum everyone in this camp can do."','"I cannot ask a duck to go hungry for a plan. I can ask a duck to go and look."'],
   q:'The cart behind him is not full. He is standing in front of it, as if that would help.',
   gone:'(The camp went hungry for two days on the road to the Tree. Nobody blamed the quartermaster. Everyone remembered it.)',
   opts:[
    {t:'Stock the cart with fish and greens.',need:{fish:4,ing:8},habit:'steady',led:{trust:1,kin:1},cap:{hearth:1,sleepers:1},flag:'stocked',mem:'stocked a camp\'s cart for the long road',
     say:['"A road is two parts walking and one part lunch," says Pask, and shuts the lid on the cart like a small, important door.','You watch him count again. This time he gets a different number, and does not say it aloud, because he is smiling.']},
    {t:'Pay for the stores outright.',need:{crumbs:60},habit:'gentle',led:{trust:1},cap:{hearth:1},flag:'bought',mem:'paid for a camp\'s stores out of your own purse',
     say:['Pask takes the crumbs as though they were hot. "I will put this in the book," he says, "under a heading I have not had to use before."']},
    {t:'Ration it. Half a meal each, from tonight.',habit:'proud',led:{truth:1,pride:1},cap:{hearth:-1},flag:'ration',mem:'put a hungry camp on half rations',
     say:['Pask writes it down. The camp takes it badly, and then, which is worse, quietly. Nobody argues with a sum.','You are right about the arithmetic. It does not help.']},
    {t:'"There is a supply cart three miles east, under somebody else\'s colours. Nobody is guarding it."',gain:40,habit:'guarded',led:{lie:1,pride:1},cap:{crown:-1},flag:'raid',mem:'raided a supply cart in the dark',
     say:['It is as easy as you said. The camp eats well for three days and does not ask where it came from. Pask, who is not stupid, asks nothing at all, very carefully.']}]},

 { id:'bram', a:12, b:14, who:['Cook Bram',cxP('#c9a06a','#8a6a3a'),'cap'],
   brief:'A cook needs a trout for a dying woman\'s last request. A rare fish, a market purchase, or an hour at her side.',
   intro:['(A cook with flour to the elbows stands at the door of a tent, holding a wooden spoon like a candle.)','"Sergeant Dunn\'s mother is dying, and has asked for exactly one thing. A trout. Not herring, not carp. A trout, cooked the way her husband did, in butter and a bay leaf."','"I have the bay leaf. I have the butter and some nerve. I do not have a trout, and the pond is eleven miles."'],
   q:'Bram does not ask. He holds the spoon out as if you might sign it.',
   gone:'(Sergeant Dunn\'s mother is said to have died on a Thursday, asking for a trout and being given broth.)',
   opts:[
    {t:'Bring a trout, or a better fish.',need:{rare:1},habit:'tender',led:{mercy:1,kin:1},cap:{hearth:1},flag:'trout',mem:'caught a dying woman her last requested meal',
     say:['Bram holds it up by the tail, and for a moment he is a younger man at a better table. "Butter," he says. "Bay leaf. Oh, you beauty."','She eats all of it. She asks, afterwards, who caught it. He tells her.']},
    {t:'Bring any fish. "She will not know the difference."',need:{fish:1},habit:'guarded',led:{lie:1,mercy:1},flag:'herring',mem:'let a dying woman believe a herring was a trout',
     say:['"She will know," Bram says, quite gently. "But she will say she doesn\'t. That is a different thing, and perhaps a better one."','He cooks it in butter and bay leaf. She eats half and calls it the best she ever had.']},
    {t:'Buy a trout at the market.',need:{crumbs:45},habit:'gentle',led:{mercy:1},flag:'bought',mem:'bought a trout for a dying woman',
     say:['It is not an especially good trout. It is a trout, and that is the whole of the request. Bram does something with the butter that makes up for most of it.']},
    {t:'Go to her. Sit with her instead. The meal is not what she wants.',need:{hours:2},habit:'tender',led:{kin:1,truth:1},flag:'sat',mem:'sat with a dying woman instead of feeding her',
     say:['She does not ask for the trout again. She holds your wing and tells you her husband\'s name, six times, getting it right each time.','Bram brings broth. She takes two sips, to be polite.']}]},

 { id:'ivy', a:14, b:16, who:['Nurse Ivy',cxP('#9a9aa8','#7a7a88'),'cap'],
   brief:'A nurse on the sleepers\' ward needs a calming draught for a dreamer who shakes. A potion, herbs, or your company.',
   intro:['(A nurse in a grey apron stands at the door of a long hall of cots. She is trying to look as though she is not holding the doorframe up.)','"They have been asleep for a hundred years, and they have started to dream aloud. The worst of them shakes. I have tried tea. I have tried singing."','"There is a kind of draught the brewers make, I am told. I have not the crumbs or the recipe. Do you?"'],
   q:'Behind her, somebody is saying a name over and over in their sleep.',
   gone:'(You hear the shaking sleeper settled, in the end, on their own. Ivy does not say how long it took.)',
   opts:[
    {t:'Give her a potion you brewed.',need:{pot:1},habit:'tender',led:{mercy:1,trust:1},cap:{sleepers:1},flag:'potion',mem:'gave a brewed potion to a ward of sleepers',
     say:['The sleeper stops shaking within the hour. Ivy sits down on the floor, quite suddenly, with her back to the cot.','"Oh," she says. "Oh, that is better." She does not get up for a while.']},
    {t:'Gather the herbs and help her steep a weaker draught.',need:{ing:6,hours:2},habit:'steady',led:{trust:1,kin:1},cap:{sleepers:1},flag:'gathered',mem:'steeped a calming draught on a sleepers\' ward',
     say:['It is a plain draught, and it works slowly. You sit up with it the whole of the second hour. By the end, the name has changed to a different name, and that, Ivy says, is progress.']},
    {t:'Sit the night watch beside them.',need:{hours:4},habit:'steady',led:{trust:1,mercy:1},cap:{sleepers:1},flag:'watched',mem:'sat a night watch beside a ward of sleepers',
     say:['You do not do anything. You sit. Towards morning the shaking eases, as if the cot were a boat that had reached shallow water.','"It is the company," says Ivy. "It is nearly always the company."']},
    {t:'Sell her a potion for what it is worth.',need:{pot:1},gain:70,habit:'guarded',led:{pride:1},flag:'sold',mem:'sold a potion to a nurse at full price',
     say:['Ivy pays from a purse she has clearly been saving for something else. She does not argue. The shaking stops, and you walk away with the full price in your pocket.']}]},

 { id:'marrow', a:15, b:17, who:['Wyn, a camp cook',cxP('#a07a5a','#7a5a3a'),'scarf'],
   brief:'A cook feeding refugees from a pot that is mostly water. Fish, plants, crumbs, or an honest word in the queue.',
   intro:['(A line of tired ducks shuffles past a pot that is mostly water. The cook ladling it is trying not to count the line.)','"The Watch has requisitioned the grain. I have been told to turn away anyone with a house to go to. Most of them have a house to go to. It is a hundred years since the house."','"If you fish, or forage, it would stretch. If you have crumbs, I will take crumbs. If you have neither, I will take a kind word, and try not to hate you for it."'],
   q:'The line is longer than the pot is wide.',
   gone:'(The refugees\' line moved on without a second ladle. You hear nobody complained, which is not the same as nobody being hungry.)',
   opts:[
    {t:'Bring fish for the pot.',need:{fish:5},habit:'tender',led:{mercy:1,kin:1},cap:{hearth:1},flag:'fish',mem:'filled a refugee pot with fish you caught',
     say:['The pot stops being water. A smell goes down the line like news. Someone laughs, hoarsely, for the first time that week.']},
    {t:'Bring greens and roots for the pot.',need:{ing:8},habit:'gentle',led:{mercy:1,trust:1},cap:{hearth:1},flag:'greens',mem:'filled a refugee pot with plants you gathered',
     say:['It is not a rich stew, but it is a stew. Wyn tastes it, and closes her eyes for a second, and says nothing, because there is a queue.']},
    {t:'Put crumbs toward the grain.',need:{crumbs:50},habit:'gentle',led:{mercy:1},flag:'paid',mem:'paid for grain for a refugee queue',
     say:['A runner comes back with a sack that is not quite enough, and then another that is. Wyn writes a note to herself on her sleeve: remember this one.']},
    {t:'Tell the queue plainly: it is a short pot, and some of you should look elsewhere.',habit:'candid',led:{truth:1,pride:1},cap:{hearth:-1},flag:'honest',mem:'told a hungry queue the pot would not stretch',
     say:['Nobody argues. A few drift away. The rest stay in line, out of habit, or out of hope.','Wyn does not thank you. She does not, you notice, tell you to leave, either.']}]},

 { id:'ashby', a:17, b:19, who:['Keeper Orme',cxP('#7a7a9a','#5a5a7a'),'hood'],
   brief:'An anchor of the Ward wants an offering: something from the water, the ground, a brew, or your own earnings.',
   intro:['(A keeper in a long grey coat stands by a flat stone with four shallow hollows. It hums, very slightly, the way a held note does.)','"The anchors hold the Ward. They always did, and they have been left to hold on their own. An anchor is only as strong as what is laid on it, and the old keepers used what the land gave."','"Something from the water. Something from the ground. Something brewed. Something earned. One, given honestly, will do. It does not matter what you could have sold it for. That is rather the point."'],
   q:'The stone hums. It does not ask. It waits, in the way very old things wait.',
   gone:'(The anchor held, for now, on what the old keepers left it. Orme says no more than that.)',
   opts:[
    {t:'Lay a rare fish on the stone.',need:{rare:1},habit:'steady',led:{trust:1,truth:1},cap:{hearth:1},flag:'water',mem:'laid a rare fish on an anchor stone',
     say:['The hollow takes the fish with a sound like a cup being set down. The note under the stone steadies, a little, and holds.']},
    {t:'Lay something old, from the ground.',need:{relic:1},habit:'steady',led:{trust:1,truth:1},cap:{mallow:1},flag:'ground',mem:'laid a relic on an anchor stone',
     say:['The stone seems to recognise it. It glows, just once, a colour you have no word for, and then goes back to being a stone.']},
    {t:'Lay a potion you brewed.',need:{pot:1},habit:'tender',led:{trust:1,kin:1},cap:{sleepers:1},flag:'brew',mem:'laid a brewed potion on an anchor stone',
     say:['The potion goes into the hollow and is gone, as if it had been poured into a well. Orme watches the stone, not you. "That one was made with care," he says.']},
    {t:'Lay sixty crumbs, the honest earnings of your work.',need:{crumbs:60},habit:'gentle',led:{trust:1,pride:1},cap:{hearth:1},flag:'earned',mem:'laid sixty crumbs on an anchor stone',
     say:['The crumbs clink into the last hollow and go quiet. It is the smallest offering. Orme, who has seen larger, nods as if it were not.']}]}
];
const RMAP={}; for(const r of REQ) RMAP[r.id]=r;
const needs=o=>o.need||{};
const have=(k)=>({fish:()=>fishHave(false),rare:()=>fishHave(true),ing:ingHave,pot:potHave,relic:relicHave,crumbs:()=>g.crumbs,rod:()=>(g.inv.fishrod||0),shovel:()=>(g.inv.shovel||0)}[k]||(()=>1))();
const unmet=o=>{ const n=needs(o), miss=[]; for(const k in n){ if(k==='hours') continue; const want=(k==='rare'||k==='rod'||k==='shovel'||k==='pot'||k==='relic')?Math.max(1,n[k]):n[k]; if(have(k)<want) miss.push(k); } return miss; };
const WORD={fish:'fish',rare:'a rare fish',ing:'plant ingredients',pot:'a brewed potion',relic:'something dug up',crumbs:'crumbs',rod:'a fishing rod',shovel:'a shovel'};
function needText(o){
  const n=needs(o), parts=[];
  for(const k in n){
    if(k==='hours'){ parts.push('about '+n[k]+' hour'+(n[k]===1?'':'s')); continue; }
    if(k==='rod'||k==='shovel'||k==='rare'||k==='pot'||k==='relic'){ parts.push(WORD[k]+(have(k)>=1?' ✓':' (you have none)')); continue; }
    parts.push(n[k]+' '+WORD[k]+(have(k)>=n[k]?' ✓':' (you have '+have(k)+')'));
  }
  return parts.length?'  ['+parts.join(', ')+']':'';
}
function gainOf(o){ return typeof o.gain==='function'?o.gain():(o.gain||0); }
function applyPick(r,o){
  const n=needs(o);
  if(n.fish) fishTake(n.fish,false);
  if(n.rare) fishTake(1,true);
  if(n.ing) ingTake(n.ing);
  if(n.pot) potTake(1);
  if(n.relic) relicTake(1);
  if(n.crumbs) g.crumbs-=n.crumbs;
  if(o.lose) for(const id of o.lose) delInv(id);
  if(n.hours) advanceClock(n.hours);
  if(o.gain) g.crumbs+=gainOf(o);
  const h0=S4st().h[o.habit];
  for(const k in (o.led||{})) s2led(k,o.led[k]);
  if(o.habit&&S4st().h[o.habit]===h0) S4st().h[o.habit]++;
  for(const k in (o.cap||{})) S6.cap(k,o.cap[k]);
  if(o.stand&&r.roll) S6st().stand[r.roll.n]=1;
  if(o.unstand&&r.roll) delete S6st().stand[r.roll.n];
  if(o.fx) D10.fx(o.fx);
  S4.setcx('rq_'+r.id,o.flag,o.mem);
  const st=ST()[r.id]; st.st='done'; st.pick=o.flag;
  try{ D10.mark('road'); }catch(e){}
  hudCache.obj=null;
}
function ask(r,done){
  const opts=r.opts;
  const labels=opts.map(o=>o.t+needText(o)).concat(['Not yet.']);
  choose(r.who[0],T(r.q),labels,k=>{
    if(k>=opts.length){ done(); return; }
    const o=opts[k], miss=unmet(o);
    if(miss.length){
      say('',['Not yet: you are short of '+miss.map(m=>WORD[m]).join(' and ')+'.','(They will wait. Go and get it, or choose another way to help.)'],()=>ask(r,done));
      return;
    }
    applyPick(r,o);
    say(r.who[0],o.say,()=>{ coin(); done(); });
  },opts.length);
}
const T=x=>typeof x==='function'?x():x;
function talk(r,done){ say(r.who[0],T(r.intro),()=>ask(r,done)); }

/* ---------- NPCs and timing ---------- */
const windowNum=()=>{ const q=g.story&&g.story.s2; if(!q||!q.ch||q.ch==='end') return NaN; const m=/(\d+)/.exec(q.ch); return m?+m[1]:NaN; };
const live=r=>{ const st=ST()[r.id]; return !!st&&st.st==='open'&&!!st.xy; };
const NPCS={};
function mk(r){
  NPCS[r.id]=S2.npc({id:'rq_'+r.id,name:r.who[0],wx:0,wy:0,pal:r.who[1],head:r.who[2],still:true,snap:2,mark:'!',
    when(){
      if(!live(r)) return false;
      const n=windowNum(); if(!(n>=r.a&&n<=r.b)) return false;
      const xy=ST()[r.id].xy, key=xy.join(',');
      if(this._k!==key){ this.wx=xy[0]; this.wy=xy[1]; this._k=key; this._o=null; this._r=0; }
      return true;
    },
    talk(n,done){ talk(r,done); }});
  RMAP[r.id]=r;
  regRoll(r);
}
/* the people who stood with you on the last night: one entry per person, however many times they came back */
const ROLLREQ={};
function regRoll(r){
  if(!r.roll||typeof ROLL==='undefined') return;
  const R=r.roll, list=ROLLREQ[R.n]||(ROLLREQ[R.n]=[]);
  if(list.indexOf(r)>=0) return;
  list.push(r);
  if(list.length>1) return;
  ROLL.push({n:R.n,who:r.who[0],ok:()=>!!S6st().stand[R.n],line:R.line});
  try{ ROLLX[R.n.split(' ')[0]]=()=>{ const l=ROLLREQ[R.n]; for(let i=l.length-1;i>=0;i--){ const st=ST()[l[i].id]; if(st&&st.st==='done'&&l[i].roll.ex&&l[i].roll.ex[st.pick]) return l[i].roll.ex[st.pick]; } return ''; }; }catch(e){}
}
for(const r of REQ) mk(r);
D10.reqRegRoll=regRoll;
D10.reqAdd=list=>{ for(const r of list){ if(RMAP[r.id]&&REQ.indexOf(r)>=0) continue; REQ.push(r); mk(r); } };
const place=(r,first)=>{
  const st=ST()[r.id], p=s2tile();
  const i=REQ.indexOf(r)%3; st.xy=[p.x+(g.dir==='left'?-2:2)+(i-1),p.y+1+(i===1?1:0)];
  toast(first?r.who[0]+' is waiting nearby, and looks like someone who needs a particular kind of help.':r.who[0]+' has caught up with the road, and is waiting nearby.',4200);
};
let COOL=0;
function tick(){
  try{
    if(!g.story||!g.story.s2) return;
    const n=windowNum(); if(!(n>=0)) return;
    const S=ST();
    for(const r of REQ){
      const st=S[r.id];
      if(st&&st.st==='open'&&n>r.b){ st.st='gone'; S4.setcx('rq_'+r.id,'ignored'); toast(r.gone,5600); }
    }
    if(g.mode!=='play'||g.scene!=='world') return;
    COOL=Math.max(0,COOL-2);
    const waiting=REQ.filter(r=>{ const st=S[r.id]; return st&&st.st==='open'&&st.xy&&n>=r.a&&n<=r.b; }).length;
    for(const r of REQ.slice().sort((x,y)=>(x.b-y.b)||(x.a-y.a))){
      const st=S[r.id];
      if((st&&st.st!=='open')||!(n>=r.a&&n<=r.b)) continue;
      if(!st&&r.if){ let okp=false; try{ okp=!!r.if(); }catch(e){} if(!okp) continue; }
      const s2_=st||(S[r.id]={st:'open',t:0,xy:null});
      if(!s2_.xy){ s2_.t+=2; if(s2_.t>=20&&COOL<=0&&waiting<3){ place(r,true); COOL=90; } continue; }
      const o=NPCS[r.id]._o;
      if(o&&Math.hypot(o.x-g.px,o.y-g.py)>TS*35) place(r,false);
    }
  }catch(e){}
}
setInterval(tick,2000);

/* the person is remembered afterwards */
const said=(who,id,fl,lines)=>rc(who,'rq_'+id+'_'+fl.join(''),()=>fl.indexOf(S4.cx('rq_'+id))>=0,lines);
said(['Little Poppy','Hermit Mallow'],'bree',['fed','taught'],['"There was a woman with a net that had more holes than net. She says a duck came with fish. Or taught her eldest. She was not clear. She was crying, a bit, the good kind."']);
said(['Elder Cinder','Captain Halbeak'],'fennel',['gathered','potion','bought'],['"A soldier I had written off sat up in his cot last week and asked for toast. The herbalist says he had help from outside the camp. I would like to know who."']);
said(['Captain Halbeak'],'fennel',['honest'],['"Madder says you told her the odds. She says no one else would. She says it was the first time in a month she was able to sit down."']);
said(['Warden Ruddock','Hermit Mallow'],'tamsin',['dug','gave','sat'],['"There is an old duck in the south field wearing a ring on a ribbon round her neck. She tells everybody it is the one. I have decided to agree with her."']);
said(['Warden Ruddock'],'tamsin',['kept'],['(He looks at the horizon, not at you.) "Somebody dug up Tamsin\'s field in the night, and Tamsin says there was nothing there. I find that interesting. I do not find it interesting aloud."']);
said(['Captain Halbeak','Elder Cinder'],'dill',['stocked','bought'],['"The cart is full. Pask is humming. In eleven years I have not heard him hum. I do not ask why, in case it stops."']);
said(['Captain Halbeak'],'dill',['raid'],['"Three days of good dinners, and a Crown cart that lost its wheels in the night. I have not asked. I am an excellent officer for not asking."']);
said(['Little Poppy','Orla'],'bram',['trout','herring','bought','sat'],['"The Warden\'s mother had a trout. Or a herring, or a trout in spirit. She said it was the best she ever had. They are going to put that on her stone."']);
said(['Hermit Mallow','Elder Cinder'],'ivy',['potion','gathered','watched'],['"The sleepers\' ward is quiet at night. Ivy sleeps on the floor of it, now. I am told it is the first time in a century that anyone in that room has dreamed gently."']);
said(['Orla','Hob'],'marrow',['fish','greens','paid'],['(She has a bowl in both wings and does not know who made the pot.) "The soup tasted of something. It has been so long since it tasted of anything."']);
said(['Hermit Mallow','Warden Ruddock'],'ashby',['water','ground','brew','earned'],['"Orme says the anchor sings a note higher now. He would like to know who laid on it. I told him the Ward does not keep names. It keeps what it is given."']);

/* ---------- the journal remembers who is waiting ---------- */
function whereText(r){
  const st=ST()[r.id]; if(!st||!st.xy) return '';
  const p=s2tile(), dx=st.xy[0]-p.x, dy=st.xy[1]-p.y, dist=Math.round(Math.hypot(dx,dy));
  return dist<5?' (right here)':' ('+wlDir(dx,dy)+' '+wlArrow(dx,dy)+', about '+dist+' waddles)';
}
{
  const _je=journalExtra;
  journalExtra=function(sec,line){
    _je(sec,line);
    try{
      const S=ST(), n=windowNum(), open=REQ.filter(r=>S[r.id]&&S[r.id].st==='open'&&S[r.id].xy&&n>=r.a&&n<=r.b);
      if(!open.length) return;
      sec('Someone Needs You');
      for(const r of open) line(r.who[0]+': '+r.brief+whereText(r));
    }catch(e){}
  };
}

/* ---------- v1.27 saves that were standing at a gate chapter just carry on ---------- */
for(const [gid,after] of [['c10s','c10'],['c17s','c17'],['c18s','c18']]){
  NEXT[gid]=NEXT[after];
  S2.ch[gid]={route:'both',title:'The Road Goes On',sub:'',numLabel:'THE ROAD',who:'',theme:'both',intro:['The road goes on.'],recap:'The road went on.',
    start(){ setTimeout(()=>{ try{ if(s2().ch===gid) S2.finish(gid); }catch(e){} },300); },obj(){ return 'The road goes on.'; }};
}

D10.reqHave=have;
D10.reqEligible=()=>{ const n=windowNum(), S=ST(); return REQ.filter(r=>{ if(S[r.id]||!(n>=r.a&&n<=r.b)) return false; try{ return !r.if||!!r.if(); }catch(e){ return false; } }).map(r=>r.id); };
D10.reqGet=id=>RMAP[id];
D10.reqPick=id=>(ST()[id]||{}).pick;
D10.reqList=()=>REQ.map(r=>({r:r,st:ST()[r.id]||null}));
D10.requests=()=>REQ.map(r=>({id:r.id,window:[r.a,r.b],state:(ST()[r.id]||{}).st||'new',pick:(ST()[r.id]||{}).pick||null}));
D10.reqTick=tick; D10.reqState=ST; D10.reqAsk=(id,done)=>talk(RMAP[id],done||(()=>{}));
})();
