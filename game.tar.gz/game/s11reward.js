'use strict';
/* ===== v1.28: WHAT THE ROAD GIVES BACK, AND WHAT IT CHARGES =====
   Story choices (requests, return visits, faction scenes) can now reach into the sandbox. This file is the single place
   where that happens, so the story files only say WHAT happens and this file knows HOW.
   - Four keepsake tools you can be given, each with a permanent effect while carried:
       Camp Cookpot (hearth)    brewing costs 15% less
       Crown Writ (crown)       jobs and favors pay 6% more
       Sleeper's Lantern        the hum arrow to the nearest Dark Tree is always on
       Hermit's Boots (mallow)  finds turn up 15% more often, plants give a crumb a little more often
   - Four locked recipes the Recipe Book shows only once they are earned.
   - Quiet changes to the world: a prices nudge, a pay nudge, a cold spell (the towns are cool toward you for some days) and
     "back rooms": rare stock that a shop begins to sell because of who you were to the people on the road.
   D10.fx(o) applies any of these from a story option, and D10.fxState() reads them back. All of it is saved in g.story.x11. */
(function(){
'use strict';
const D10=window.D10=window.D10||{};
const X=()=>{ const s=g.story||(g.story={}); return s.x11||(s.x11={}); };
const M=()=>{ const x=X(); return x.mods||(x.mods={buy:0,pay:0,sell:0,badUntil:0,unlock:{},rec:{}}); };
const carry=id=>{ try{ return !!(g.inv&&g.inv[id]>0); }catch(e){ return false; } };

/* ---------- the keepsakes ---------- */
ITEMS.crownwrit={name:'Crown Writ',price:1,use:'note',nogift:true,desc:'A sealed paper every Crown clerk will read before they argue. Carry it and jobs and favors pay 6% more.',note:'The seal is a little smudged. The signature is not.'};
RICON.crownwrit=(R,C,E)=>{ R(3,3,10,11,'#e8d9b5'); R(3,3,10,2,'#c9b98a'); R(5,7,6,1,'#8a6a3a'); R(5,9,5,1,'#8a6a3a'); R(9,10,4,4,'#b03030'); R(10,11,2,2,'#e0452f'); };
ITEMS.cookpot={name:'Camp Cookpot',price:1,use:'note',nogift:true,desc:'A dented pot with ten winters of stew in its bones. Carry it and brewing costs 15% less.',note:'It smells of onions, of rain, and of being fed.'};
RICON.cookpot=(R,C,E)=>{ R(3,6,10,7,'#4a4a52'); R(2,6,12,2,'#6a6a74'); R(1,8,2,2,'#4a4a52'); R(13,8,2,2,'#4a4a52'); R(4,3,8,2,'#8a8a94'); R(5,10,6,1,'#ff9d2e'); };
ITEMS.dreamlantern={name:'Sleeper\'s Lantern',price:1,use:'note',nogift:true,desc:'A shuttered lantern given by someone who has dreamed too long. Carry it and the hum arrow to the nearest Dark Tree is always on.',note:'The light inside is the colour of a very old lullaby.'};
RICON.dreamlantern=(R,C,E)=>{ R(6,2,4,2,'#6a5a8a'); R(4,4,8,9,'#8a7ab0'); R(5,5,6,7,'#d8c8ff'); R(7,7,2,3,'#fff3b0'); R(4,13,8,1,'#5a4a7a'); };
ITEMS.hermitboots={name:'Hermit\'s Boots',price:1,use:'note',nogift:true,desc:'Mallow\'s second-best boots, resoled. Carry them and finds turn up 15% more often, and plants give a crumb a little more.',note:'They are exactly one size too large, which is the right size for walking a long way.'};
RICON.hermitboots=(R,C,E)=>{ R(3,3,5,9,'#6b4a2f'); R(3,10,9,3,'#4a3220'); R(8,9,5,4,'#6b4a2f'); R(3,3,5,2,'#8a6a45'); };
ITEMS.campstew={name:'Camp Stew Tin',price:40,desc:'A tin of the camp\'s own stew, still faintly warm. A long, quick walk, a better nose and a little luck.',use:'eat',boost:150,quip:'It tastes like being looked after.'};
RICON.campstew=(R,C,E)=>{ R(3,5,10,8,'#8a8a94'); R(3,5,10,2,'#b0b0ba'); R(4,8,8,3,'#c9783a'); R(6,3,4,2,'#6a6a74'); };
ITEMS.hermittea={name:'Hermit\'s Moss Tea',price:36,desc:'Steeped slowly, in the dark, by someone with nowhere to be. A steadier line, a keener eye for plants, and a sense for what is buried.',use:'eat',boost:60,quip:'It tastes like a green afternoon.'};
RICON.hermittea=(R,C,E)=>{ R(4,6,8,7,'#7a9a6a'); R(3,6,10,2,'#9ab88a'); R(12,8,2,3,'#7a9a6a'); R(6,3,1,2,'#cfd8c0'); R(9,2,1,3,'#cfd8c0'); };
const fxParse=str=>str.split(' ').map(t=>{ const m=/^(!?[a-zA-Z]+)([\d-]*)$/.exec(t); const a=m[2].split('-').map(Number); return {k:m[1],a:a[0]||0,b:a[1]||0}; });
for(const [id,str] of [['campstew','speed150 forage3 luck2'],['hermittea','angler4 forage3 dowse']]){
  FXD[id]=str; FXP[id]=fxParse(str); ITEMS[id].desc+=' Use it: '+fxSummary(FXP[id])+'.';
}

/* ---------- locked recipes (the Recipe Book hides them until earned) ---------- */
const NEWREC=[
 {id:'campbroth',name:'Hearthfire Broth',tier:1,req:[['mush',2],['flower',2]],cost:14,fx:'speed120 forage3 luck1',col:['#d98a3a','#9a5a1a','#ffe0b0'],desc:'What the camp cooks when it has decided to look after you. Warm legs, warm luck.'},
 {id:'courtcord',name:'Courtier\'s Cordial',tier:1,req:[['flower',2],['bush',1]],cost:16,fx:'haggle5 rep1',col:['#b8a4e0','#6a5aa0','#f0e8ff'],desc:'Smooth, sealed and faintly smug. Shopkeepers hear you slightly differently.'},
 {id:'mosstea',name:'Mallow\'s Moss Brew',tier:1,req:[['stump',2],['mush',1]],cost:15,fx:'angler4 forage3 dowse',col:['#7ab88a','#3a7a52','#d8ffe4'],desc:'Slow, dark and green. A hermit\'s recipe, for people who are going to be out all day.'},
 {id:'dreamdraught',name:'Sleeper\'s Draught',tier:2,req:[['mush',2],['flower',2,1]],cost:28,fx:'luck5 glow600 hum1800',col:['#8a7ab0','#4a3a7a','#e0d4ff'],desc:'Brewed from what the sleepers hum. You will see further in the dark, and the dark will see you.'}
];
const REC={};
for(const r of NEWREC){
  REC[r.id]=r;
  const pid='p_'+r.id, list=fxParse(r.fx);
  FXD[pid]=r.fx; FXP[pid]=list;
  ITEMS[pid]={name:r.name,price:0,cat:'potion',desc:r.desc+' Use it: '+fxSummary(list)+'.',use:'note',note:'',nogift:true,glyph:r.tier>=1?'flask':'vial',gc:r.col};
  BR_RECIPES.push({id:r.id,name:r.name,tier:r.tier,req:r.req.map(q=>({c:q[0],n:q[1],g:q[2]||0})),cost:r.cost,fx:r.fx,col:r.col,desc:r.desc,lock:r.id}); }
const recKnown=id=>!!M().rec[id];
{
  const _rows=brRows;
  brRows=function(){
    const o=_rows(); const keep=o.rows.filter(x=>!x.r.lock||recKnown(x.r.lock));
    const all=BR_RECIPES.filter(r=>!r.lock||recKnown(r.lock)).length;
    return {rows:keep,nOk:keep.filter(x=>x.plan.ok).length,nAll:all};
  };
}
/* recipe cost with the Cookpot */
for(const r of BR_RECIPES){ const base=r.cost; Object.defineProperty(r,'cost',{get(){ return Math.max(1,Math.round(base*(carry('cookpot')?0.85:1))); },set(v){},configurable:true,enumerable:true}); }

/* ---------- quiet world changes ---------- */
const BACKROOM={
  hearth:{id:'campstew',kinds:['bakery','market','provision','cafe','rbake','rcafe','rherb']},
  crown:{id:'runestone',kinds:['hardware','supply','cartog','books','tackle']},
  mallow:{id:'hermittea',kinds:['apoth','naturalist','rherb','provision']},
  sleepers:{id:'wardcharm',kinds:['curio','toys','rtoy','rcandle','florist']}
};
{ const _sp=shopStock; shopStock=function(b,t){
    const a=_sp(b,t), u=M().unlock;
    for(const k in BACKROOM){ const d=BACKROOM[k]; if(u[k]&&d.kinds.indexOf(b.kind)>=0&&ITEMS[d.id]&&a.indexOf(d.id)<0) a.push(d.id); }
    return a;
  }; }
{ const _ip=itemPrice; itemPrice=function(id,t){ const m=M(); let mul=1+m.buy; if(g.day<m.badUntil) mul*=1.2; return Math.max(1,Math.round(_ip(id,t)*mul)); }; }
{ const _pm=payMul; payMul=function(t){ const m=M(); return _pm(t)+m.pay+(g.day<m.badUntil?-0.15:0)+(carry('crownwrit')?0.06:0); }; }
{ const _hg=wlHaggle; wlHaggle=function(){ return _hg()+M().sell; }; }
{ const _wi=wlItemMul; wlItemMul=function(){ return _wi()*(carry('hermitboots')?1.15:1); }; }
{ const _wc=wlCrumbP; wlCrumbP=function(){ return _wc()+(carry('hermitboots')?0.03:0); }; }
/* the lantern keeps the hum on */
setInterval(()=>{ try{ if(carry('dreamlantern')&&g.story) X().humUntil=Math.max(X().humUntil||0,fxNow()+3); }catch(e){} },3000);

/* ---------- applying an option's consequences ---------- */
const bits=[];
function fx(o){
  if(!o) return;
  const m=M(), say=[];
  if(o.rep){ for(const k of g.towns?[...g.towns.keys()]:[]){ const t=g.towns.get(k); if(!t) continue; if(o.rep>0) addRep(t,o.rep); else g.rep[t.key]=Math.max(0,(g.rep[t.key]||0)+o.rep); } say.push(o.rep>0?'Word of it travels. Every town you know thinks a little better of you.':'Word of it travels. Every town you know thinks a little less of you.'); }
  if(o.buy){ m.buy=Math.max(-0.2,Math.min(0.3,m.buy+o.buy)); say.push(o.buy>0?'Shops now quote you a little higher.':'Shops now quote you a little lower.'); }
  if(o.pay){ m.pay=Math.max(-0.2,Math.min(0.3,m.pay+o.pay)); say.push(o.pay>0?'Jobs and favors pay a little better.':'Jobs and favors pay a little worse.'); }
  if(o.sell){ m.sell=Math.max(-0.2,Math.min(0.3,m.sell+o.sell)); say.push(o.sell>0?'Shopkeepers pay a little more for your finds.':'Shopkeepers pay a little less for your finds.'); }
  if(o.cold){ m.badUntil=Math.max(m.badUntil,g.day+o.cold); say.push('The towns will be cool toward you for '+o.cold+' days: dearer prices, poorer pay.'); }
  if(o.unlock){ if(!m.unlock[o.unlock]){ m.unlock[o.unlock]=1; const d=BACKROOM[o.unlock]; say.push('A back room has opened: '+((ITEMS[d.id]||{}).name||d.id)+' now turns up in some shops.'); } }
  if(o.recipe){ if(!m.rec[o.recipe]){ m.rec[o.recipe]=1; say.push('New recipe in your Recipe Book: '+(REC[o.recipe]||{name:o.recipe}).name+'.'); } }
  if(o.item){ for(const id of [].concat(o.item)){ if(ITEMS[id]){ addItem(id,1); say.push('You are given: '+ITEMS[id].name+'.'); } } }
  if(o.give){ for(const k in o.give){ if(ITEMS[k]){ addItem(k,o.give[k]); say.push('You are given: '+ITEMS[k].name+(o.give[k]>1?' x'+o.give[k]:'')+'.'); } } }
  if(say.length) setTimeout(()=>{ try{ toast(say.join('  '),6200); }catch(e){} },900);
}
D10.fx=fx;
D10.fxState=()=>M();
D10.recipes=()=>NEWREC.map(r=>({id:r.id,name:r.name,known:recKnown(r.id)}));
})();
