/* ===== THE DARK TREES (v1.25) =====
   The game opens on a question: what is wrong with the dark trees? Until now the story never answered it.
   Now it does, in four steps, and the open forest changes to match:
     - Chapter 11, the Old Tree shows you the siege. Afterwards Mallow tells you what the dark trees were: seams in the ward.
     - Chapter 19, the ward breaks. If it let go gently the dark thins a little; if it broke, it does not.
     - The ending decides the rest. Wake: the dark trees turn ordinary. Door: most do. Keep: most do. Stay: none do.
     - Studying them is rewarded: 8 trees close the case file (crumbs), 12 show you the ring, and the Mystery Key points to its centre.
   The open forest really changes: dark trees become ordinary trees (same place, same spacing), the dark haze thins, and the map repaints.
   Saved in g.story.x.trees. Adds D10.trees. */
(function(){
'use strict';
const D10=window.D10=window.D10||{};
const TS_=()=>{ try{ const x=XS(); return x.trees||(x.trees={}); }catch(e){ return {}; } };
function stage(){
  try{
    const q=g.story&&g.story.s2; if(!q) return 'unknown';
    if(q.ending) return q.ending;
    if(q.done&&q.done.c19) return (q.fl&&q.fl.wardState)==='gentle'?'eased':'broken';
    if(q.done&&q.done.c11) return 'known';
  }catch(e){}
  return 'unknown';
}
const FRAC={unknown:0,known:0,broken:0,eased:0.35,wake:1,door:0.6,keep:0.75,stay:0};
const frac=()=>FRAC[stage()]||0;
D10.trees={stage,frac};

/* ---- the world: dark trees thin out, in the same places every time ---- */
let inGen=false;
{
  const _gt=genTile;
  genTile=function(x,y){
    inGen=true; let v; try{ v=_gt(x,y); }finally{ inGen=false; }
    if(v===T.DARK){ const f=frac(); if(f>0&&hash(x,y,77)<f) return T.TREE; }
    return v;
  };
  const _dk=darkAt;
  darkAt=function(x,y){ const r=_dk(x,y); return inGen?r:r*(1-frac()*0.9); };
}
let lastKey=null;
setInterval(()=>{
  try{
    if(!g.story) return;
    const k=stage(); if(lastKey===null){ lastKey=k; return; }
    if(k!==lastKey){ lastKey=k; tileCache.clear(); }
  }catch(e){}
},1200);

/* ---- studying one ---- */
const LINES={
  unknown:null,
  known:['It hums, and now you know whose word it is. Stay. A door being held shut, a long way off, and the hum is the seam.','Black sap, slow as a thought. It is not rot. It is the ward, thin here, showing through.'],
  broken:['The hum has changed since the ward broke. It is uneven now, like breath after running.','The seam has not closed. Whatever held this place has been let go in a hurry.'],
  eased:['The hum is softer than it was. The seam is closing slowly, the way a hand opens when it is ready.','Black sap, but slower. Something has stopped pushing.'],
  wake:['This one is only bark. Not dark, only a little old, and warm where the sun is on it. It has stopped humming.'],
  door:['A hand-width of hum, no more. The seam is open a little, on purpose. Someone is keeping it.'],
  keep:['The hum has a fifth note in it now, a step higher, like somebody setting down a cup.'],
  stay:['The hum has not changed. Nobody asked it anything. The seam is where it always was.']
};
function inspectDark2(tx,ty){
  const key=tx+','+ty, first=!g.inspected.has(key), pages=[], st=stage();
  const L=LINES[st];
  if(first){
    g.inspected.add(key); g.clues++; g.flags.dark=true;
    if(L) pages.push(L[(g.clues-1)%L.length]); else pages.push(DARK_LINES[(g.clues-1)%DARK_LINES.length]);
    if(isHeld('glass')) pages.push(GLASS_LINES[(g.clues-1)%GLASS_LINES.length]);
    if(g.clues===1) pages.push('You make a mental note. Case file: Strange Trees. Entry one.');
    if(g.clues===4) pages.push('Four now. They all hum the same low note. Somewhere below, something hums back.');
    if(g.clues===8){
      pages.push('Eight trees. You are almost sure they are arranged. Almost.');
      const t=TS_(); if(!t.c8){ t.c8=1; g.crumbs+=50; coin(); pages.push('You close the case file on the trees, with eight entries. A bookmark of ash-glass falls out of the back: 50 crumbs, taped to it.'); }
    }
    if(g.clues===12){
      const t=TS_(); if(!t.c12){ t.c12=1; g.crumbs+=120; coin(); pages.push('Twelve. You lay them out in your head and they close into a ring. In the Mystery Key, the hum turns, and holds, pointing at the centre of the ring. (+120 crumbs from an old cache you notice in the roots.)'); }
    }
  } else pages.push(st==='wake'?'You have already studied this one. It is quiet.':'You have already studied this one. The hum has not stopped.');
  say('Detective Duck',pages);
}
inspectDark=inspectDark2;

/* ---- the Mystery Key finds the centre of the ring ---- */
D10.treeKey=function(){
  try{ if(g.clues>=12||(FRAC[stage()]>0)||stage()==='stay') return [KX-66,KY-61]; }catch(e){}
  return null;
};

/* ---- the moments: what somebody tells you, once, when you are back in the open ---- */
const SCENES={
  known:{who:'Hermit Mallow',pages:['You have been writing the trees down. I have been watching you do it.','The dark ones are not cursed, little detective. They are seams. The Burnt Wood is held shut by a word, and the word hums, and where it is thin it shows through the forest as a tree gone dark.','They are not hungry. They are holding. I thought you should know that before you decide what to do about them.']},
  broken:{who:'Hermit Mallow',pages:['Listen. The dark trees. They hum differently since the ward broke.','It is uneven. Like a thing that was holding its breath and has been told to stop, all at once. They will settle. I think. It depends what we do next.']},
  eased:{who:'Hermit Mallow',pages:['The trees are quieter. Some of the dark ones are just trees again.','That is what a ward does when it lets go gently. It does not vanish. It thins, and the forest remembers what it was.']},
  wake:{who:'',pages:['Out in the forest, the dark trees have stopped humming. One at a time, then all together, the way a choir finishes.','Where they stood, there are only trees, a little old, a little crooked, and green at the edges. The ring Mallow once showed you on a map is a ring of ordinary woods now.']},
  door:{who:'',pages:['Most of the dark trees are ordinary now. A few still hum, softly, in the places where the door is ajar.','They are not warnings any more. They are a way of knowing, from the road, how far it is open.']},
  keep:{who:'',pages:['The dark trees have thinned. The ones that remain hum a fifth note, a step above the others, and it does not resolve.','People who pass them stop for a moment. Nobody asks why.']},
  stay:{who:'',pages:['Out in the forest, the dark trees hum as they always have. Nothing has changed. Somebody, someday, will count them again and wonder.']}
};
function deliver(){
  try{
    if(g.mode!=='play'||g.scene!=='world'||!g.story||!g.story.s2) return;
    const st=stage(), t=TS_(); if(!SCENES[st]||t['s_'+st]) return;
    t['s_'+st]=1; const S=SCENES[st];
    say(S.who,S.pages);
  }catch(e){}
}
setInterval(deliver,2500);

/* ---- the journal keeps the case ---- */
{
  const _je=journalExtra;
  journalExtra=function(sec,line){
    _je(sec,line);
    try{
      if(!g.clues&&stage()==='unknown') return;
      sec('Case File: Strange Trees');
      line('Dark trees studied: '+g.clues+'.');
      const st=stage();
      line(({unknown:'They hum one flat note. They are arranged, almost.',known:'They are seams in the ward Eider holds. They are not cursed. They are holding.',broken:'The ward broke hard. The hum is uneven.',eased:'The ward let go gently. The dark is thinning.',wake:'The ward is gone and the dark trees have turned ordinary.',door:'Most dark trees are ordinary. A few hum where the door stands ajar.',keep:'The remaining dark trees hum a fifth note.',stay:'Unchanged. Someone will ask again.'})[st]);
      if(g.clues>=12) line('The Mystery Key points to the centre of the ring.');
      else if(g.clues>=8) line('Case closed at eight, but the pattern is a ring, and a ring has a centre. (12 trees.)');
    }catch(e){}
  };
}
})();
