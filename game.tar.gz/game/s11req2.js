'use strict';
/* ===== v1.28: MORE PEOPLE ON THE ROAD, AND THE ROAD COMES BACK =====
   Three things live here:
   1. Patches to the eight v1.27.1 requests: the people who were helped can now stand at the anchors on the last night, and
      some answers now have costs or rewards that reach into the sandbox (prices, pay, cold spells, rare stock).
   2. Nine new requests, spread through all four acts, several of which need two skills at once (a brewed potion AND something
      you dug up; fish AND greens; a shovel AND four hours).
   3. Return visits: people come back, depending on what you did the first time. A kind answer can bring a gift, a hard
      answer can bring a bill, and a lie can follow you to a checkpoint in act V.
   Same engine, same rules as s11story.js: nothing blocks the story, every request has an answer that needs no sandbox skill. */
(function(){
'use strict';
const D10=window.D10=window.D10||{};
const R=D10.reqGet, pk=D10.reqPick;
const is=(id,...f)=>f.indexOf(pk(id))>=0;

/* ---------- 1. patch the first eight ---------- */
function patch(id,roll,stand,fx){
  const r=R(id); if(!r) return;
  r.roll=roll; D10.reqRegRoll(r);
  for(const i of stand) r.opts[i].stand=true;
  for(const k in (fx||{})) Object.assign(r.opts[+k],{fx:fx[k]});
}
patch('bree',{n:'Nell',line:`Nell, with her net over one shoulder, fully mended, and three children each holding a lantern.`,ex:{fed:`The smallest child counts everyone present, aloud, twice, to be sure.`,taught:`Her eldest has a line in her wing and the look of someone who has informed the pond.`,paid:`She has brought a loaf, and carries it like evidence.`}},[0,1,2],{3:{sell:-0.02}});
patch('fennel',{n:'Madder',line:`Madder, with a basket of green things, and a soldier on her arm who has apparently decided to live.`,ex:{gathered:`"Green stem," she says to the dark. "I always said."`,potion:`She will not tell anyone how it was done. She keeps patting her apron pocket.`,bought:`The little brown bottle is in her apron. It is empty. She keeps it.`,honest:`She stands beside you, and that is the whole of it.`}},[0,1,2,3]);
patch('tamsin',{n:'Tamsin',line:`Tamsin, with a ring on a ribbon round her neck and a stick she has no real use for.`,ex:{dug:`She taps her pocket. The thing from the field is in it, and it is, she maintains, the one.`,gave:`She wears the ring openly, and dares anyone to say it is not his.`,sat:`She tells you what Alder's hands looked like, again, and this time you are ready.`}},[0,1,2],{3:{cold:3}});
patch('dill',{n:'Pask',line:`Pask, with the camp's last cart behind him and the look of a man who has finally stopped counting.`,ex:{stocked:`"A road is two parts walking," he says, and does not finish, because he is smiling.`,bought:`He has written your name in the book under a heading he did not have before.`}},[0,1],{0:{unlock:'hearth'},1:{pay:0.02}});
patch('bram',{n:'Bram',line:`Bram, flour to the elbows, with a tin of bay leaf, as if the war had always been about dinner.`,ex:{trout:`"Butter," he says, to no one. "Bay leaf." He is smiling at a pan.`,herring:`He nods to you across the dark, like a man who has agreed on a story.`,bought:`He is holding a trout. He has not put it down since it was bought.`,sat:`He puts a hand briefly on your shoulder, and takes it away again.`}},[0,1,2,3]);
patch('ivy',{n:'Ivy',line:`Ivy, in her grey apron, who has left the ward in the care of someone she trusts, which cost her a great deal.`,ex:{potion:`She holds out a small bottle with the label turned to you. It is empty. It was the right one.`,gathered:`She carries a flask of the weak draught. "It works slowly," she says. "So do I."`,watched:`She nods, once, in the way of two people who have kept the same vigil.`}},[0,1,2],{0:{unlock:'sleepers'},3:{sell:-0.02}});
patch('marrow',{n:'Wyn',line:`Wyn, with the pot, which is full.`,ex:{fish:`"Stew," she says, and ladles you some, and looks at you as if you were a window.`,greens:`She holds the ladle like a sceptre.`,paid:`She has your crumbs sewn into her sleeve, still, and shows you.`}},[0,1,2],{0:{unlock:'hearth'},1:{unlock:'hearth'}});
patch('ashby',{n:'Orme',line:`Orme, in his long grey coat, who walks to the anchors without being told which.`,ex:{water:`He touches the stone as he passes. It hums.`,ground:`He nods at the stone like a colleague.`,brew:`He carries a lantern in the colour of your potion, and does not explain.`,earned:`He puts one wing flat on the stone. "Honest work," he says.`}},[0,1,2,3]);

/* ---------- 2. nine new requests ---------- */
const P=(b,w,h)=>({body:b,wing:w,bill:h||'#e6c441'});
D10.reqAdd([
 { id:'pell', a:5, b:7, who:[`Rudge, a ferryman`,P('#6a7a8a','#4a5a6a'),'cap'],
   brief:`A ferryman owes the Crown a toll debt he cannot pay. Crumbs, a rare fish, a dig on the sandbar, or the plain truth.`,
   intro:[`(A ferryman sits in his own boat, tied to the bank, holding a paper in both wings as if it were hot.)`,`"The Crown clerk says I owe eleven seasons of toll on a crossing my family has run since my grandfather. The paper says so. The paper is very sure."`,`"I have a boat and a pole. The clerk comes back at dusk."`],
   q:`Rudge turns the paper over. The back is blank, which is not helping either.`,
   gone:`(You hear Rudge paid the toll in the end, in instalments, over a very long winter.)`,
   roll:{n:'Rudge',line:`Rudge, with his pole across his shoulder, having shut the ferry for the night for the first time in forty years.`,ex:{paid:`He says the crossing is free for you, any time, and means it as a fact.`,dug:`He brought a tin of old coin to show you, and then did not open it.`,argued:`He has the paper folded small in his pocket, like a trophy.`}},
   opts:[
    {t:`Pay the toll for him.`,need:{crumbs:40},habit:'gentle',led:{mercy:1,trust:1},cap:{crown:1},flag:'paid',mem:`paid a ferryman's toll debt`,stand:true,
     say:[`The clerk counts it twice, stamps the paper, and goes without a word. Rudge is quiet for some time.`,`Then he says the crossing is free for you, any time, and means it as a matter of law.`]},
    {t:`Slip the clerk a rare fish. Clerks are people.`,need:{rare:1},habit:'guarded',led:{lie:1,pride:1},cap:{crown:-1},fx:{cold:2},flag:'bribed',mem:`bribed a Crown clerk with a fish`,
     say:[`The clerk looks at the fish, and at you, and the paper loses its second page somewhere between his hands.`,`Rudge stares. "I do not like that this worked," he says. "I will not say that I do not like it."`]},
    {t:`Dig the sandbar where his grandfather buried the takings.`,need:{shovel:1,hours:3},habit:'steady',led:{trust:1,kin:1},flag:'dug',mem:`dug a sandbar for a ferryman's old coins`,stand:true,
     say:[`Three hours of silt, a hairbrush, and at the end of it a tin box of his grandfather's takings, buried against hard times. Rudge weeps a little, efficiently, and pays the clerk in his own family's coin.`]},
    {t:`Read the paper properly, and tell the clerk it is wrong.`,habit:'candid',led:{truth:1},cap:{crown:1},flag:'argued',mem:`read a ferryman's paper and told a clerk it was wrong`,stand:true,
     say:[`It is wrong. Eleven seasons is one season, copied. The clerk goes the colour of the paper.`,`Rudge has never been so pleased to be right, and does not know where to put it.`]}]},

 { id:'wren', a:6, b:8, who:[`Calla, an herb-seller`,P('#8aaa7a','#6a8a5a'),'hat'],
   brief:`An herb-seller whose stall was wrecked by passing soldiers. Plants, a potion, a report to the captain, or bread money.`,
   intro:[`(A girl of about sixteen kneels in the ruin of a market stall, sorting trampled herbs into three piles: salvageable, possibly salvageable, and mulch. The third pile is the biggest.)`,`"They were not even angry. They just went through it, the way you go through a hedge. I do not think they saw it."`,`"I had a week of cuttings in that. And Mam's tonic, the shaking one, for her hands."`],
   q:`She does not look up. She is counting the mulch.`,
   gone:`(You hear a girl in the market sold out by the weekend, from a tiny stall with a hand-painted sign.)`,
   roll:{n:'Calla',line:`Calla, with a sack of dried herbs over her shoulder, and her mother on her arm, hands steady.`,ex:{restocked:`She has bundles of the wood sorrel in her pockets, "in case".`,potion:`Her mother's hands are completely still. She will not say why.`,reported:`She bows, stiffly and correctly, and does not smile until you have turned away.`}},
   opts:[
    {t:`Gather her a week of cuttings from the wild.`,need:{ing:6},habit:'tender',led:{mercy:1,kin:1},cap:{hearth:1},flag:'restocked',mem:`restocked a girl's ruined herb stall`,stand:true,
     say:[`She tips them out on the board and sorts them with a speed that is nearly rude. "Wood sorrel," she says. "You even got the roots."`,`She grins, for the first time, and looks embarrassed about it.`]},
    {t:`Give her a potion for her mother's hands.`,need:{pot:1},habit:'steady',led:{mercy:1,trust:1},cap:{hearth:1},flag:'potion',mem:`gave a girl a potion for her mother's shaking hands`,stand:true,
     say:[`She holds it as if it might spill upwards. "It is better than Mam's," she says, ashamed. "Do not tell Mam."`,`She puts it away somewhere safe, then moves it somewhere safer.`]},
    {t:`Tell the soldiers' captain, and get the stall paid for.`,habit:'proud',led:{truth:1,pride:1},cap:{crown:1},fx:{pay:0.02},flag:'reported',mem:`made the Watch pay a girl for her stall`,stand:true,
     say:[`The captain is mortified. He pays in full, with interest, and apologises to a sixteen-year-old beside a ruined stall.`,`She says thank you very correctly, and does not say it warmly.`]},
    {t:`Buy what is left of her stock, at a fair price.`,need:{crumbs:35},habit:'gentle',led:{mercy:1},flag:'bought',mem:`bought a girl's ruined stock at a fair price`,
     say:[`It is mostly mulch. It is good mulch. She counts the crumbs twice, which is how you know she is going to be all right.`]}]},

 { id:'gil', a:9, b:11, who:[`Gil, a well-digger`,P('#9a8a6a','#7a6a4a'),'cap'],
   brief:`A village well has run dry. A shovel, a brewed potion, a day of carrying water, or the hard word that the village should move.`,
   intro:[`(A well-digger stands waist-deep in a hole that used to be a well, looking up at you the way a man looks up from a grave he is not sure he should be in.)`,`"Forty feet down it stopped. Not slowly. It stopped like a door. There are eleven families on this road, and they have been drinking from the ditch for a week."`,`"There is water. I can smell it. I need hands, and another hand at the rope, and a miracle, if you have one."`],
   q:`Gil wipes his forehead with a wing that leaves it muddier.`,
   gone:`(You hear the well came back on its own in the spring, and nobody could say why.)`,
   roll:{n:'Gil',line:`Gil, with a coil of rope over his shoulder and mud to the knees, who says it is the only kind of tidy he knows.`,ex:{dug:`He holds up a blistered wing and shows it to you like a medal.`,brewed:`He says, privately, that the well is "grateful". He does not elaborate.`,carried:`Eleven families, each with a bucket, are behind him in single file.`}},
   opts:[
    {t:`Dig with him until the spring breaks.`,need:{shovel:1,hours:4},habit:'steady',led:{trust:1,kin:1},cap:{hearth:1},flag:'dug',mem:`dug a village well until it ran`,stand:true,
     say:[`Four hours, a blister, and a seam of shale that Gil addresses by name. At the end the bottom goes dark, then bright, then wet.`,`Eleven families come out of their houses at the sound.`]},
    {t:`Pour a brewed potion into the stone, and see.`,need:{pot:1},habit:'tender',led:{mercy:1},cap:{mallow:1},flag:'brewed',mem:`poured a potion into a dry well`,stand:true,
     say:[`It is an absurd thing to do, and you do it. The potion goes down in a thread of colour.`,`For a long moment nothing happens. Then, from very far below, something clears its throat. Gil swears, quietly, in awe.`]},
    {t:`Carry water from the pond, as many trips as it takes.`,need:{hours:3},habit:'steady',led:{trust:1},flag:'carried',mem:`carried water to eleven families for a day`,stand:true,
     say:[`It is a long day, and it is, honestly, mostly walking. Eleven families get their water. Nobody asks for your name, which feels right.`]},
    {t:`Tell him the well is gone. The village should move.`,habit:'candid',led:{truth:1,pride:1},cap:{hearth:-1},flag:'move',mem:`told a village to leave its well`,
     say:[`He nods, slowly, and climbs out of the hole one rung at a time. "I know," he says. "I wanted somebody else to say it."`,`He tells the village that evening. Nobody thanks you, and some of them never forgive you.`]}]},

 { id:'lanta', a:10, b:12, who:[`Lanta, a lamp-maker`,P('#d0a84a','#9a7a2a'),'hat'],
   brief:`A lamp-maker needs light for the night road. Glowing plants, a brewed potion, fish oil, or a firm word about being seen.`,
   intro:[`(A lamp-maker sits among a hundred unlit lamps with a tinderbox in one wing and a face that says the tinderbox has lost.)`,`"The camp marches by night, they tell me. I have lamps, and no oil. The oil went to the Watch. I have wicks, and no light in them."`,`"There are things that glow in the wood, and things the brewers make that glow. I do not have the legs for the one, or the crumbs for the other."`],
   q:`She lights one lamp. It flares, and dies, and she writes something on her sleeve.`,
   gone:`(The camp marched at night by what light there was. Lanta lit what she could.)`,
   roll:{n:'Lanta',line:`Lanta, with a lamp on a pole, lit, which she holds higher than anyone.`,ex:{gathered:`Her lamp comes up pale and silver, like a young moon.`,potion:`There are eleven lamps behind her, all burning the same colour.`,oil:`Her lamp burns yellow and sulks, and she loves it.`}},
   opts:[
    {t:`Bring glowing plants and fungi from the dark places.`,need:{ing:6},habit:'tender',led:{mercy:1,kin:1},cap:{hearth:1,sleepers:1},flag:'gathered',mem:`brought a lamp-maker light from the wild`,stand:true,
     say:[`She crushes the first handful into a lamp, and the lamp comes up the colour of a very young moon. She laughs, and then goes quiet, because someone is going to need that light and she knows who.`]},
    {t:`Give her a glowing brew.`,need:{pot:1},habit:'steady',led:{trust:1,mercy:1},cap:{sleepers:1},flag:'potion',mem:`gave a lamp-maker a potion that glows`,stand:true,
     say:[`She uncorks it over a row of lamps and watches the colour climb the wicks like a thing that remembers. Eleven lamps. It was enough for eleven lamps.`]},
    {t:`Sell her fish oil at a fair rate.`,need:{fish:4},gain:24,habit:'gentle',led:{mercy:1},flag:'oil',mem:`sold a lamp-maker fish oil for her lamps`,stand:true,
     say:[`The oil is rough and smells of pond. The lamps burn yellow and sulk. They burn.`,`She pays in coins that she has clearly been keeping in a lamp.`]},
    {t:`Tell her the march should go dark. A light can be seen for miles.`,habit:'proud',led:{truth:1,pride:1},cap:{crown:1,hearth:-1},flag:'dark',mem:`told a lamp-maker to put the lamps out`,
     say:[`She does, one by one, without arguing. It is the quietest night the camp has had.`,`It is also, as it turns out, the safest, and nobody thanks you, and that is how you know.`]}]},

 { id:'brock', a:13, b:15, who:[`Brock, a hearthkeeper`,P('#8a6a4a','#6a4a2a'),'scarf'],
   brief:`A hearthkeeper feeding children whose families are asleep in the ward. Fish and greens, flour money, or an evening at their table.`,
   intro:[`(A hearthkeeper stands over a long table of small bowls. Each bowl has a name chalked beside it. Some of the chalk is old.)`,`"These are the sleepers' young kin, three generations down. Their people are in the long hall, asleep, and they have never met them, and the winter is coming, and I have a pot and a lot of names."`,`"I do not ask for much. Something with fins, and something green. One good dinner, so they can say they had one."`],
   q:`A child pulls on your wing and asks, very politely, if you are the one who is bringing the fish.`,
   gone:`(The children ate what there was. A chalk name or two was wiped from the table before the snow.)`,
   roll:{n:'Brock',line:`Brock, with the long table's ladle in his belt and a line of small children, in order of height.`,ex:{dinner:`One of the children shows you a fishbone she is keeping in her pocket, as a keepsake.`,flour:`He says the flour is holding. He says it like a prayer.`,told:`The smallest child asks if you will tell the one about the river again.`}},
   opts:[
    {t:`Bring a proper dinner: fish and greens.`,need:{fish:3,ing:4},habit:'tender',led:{mercy:1,kin:1},cap:{hearth:1,sleepers:1},flag:'dinner',mem:`cooked a dinner from the wild for the sleepers' young kin`,stand:true,
     say:[`The pot has not smelled like this in months. The children are very formal about it. They eat with their best manners, and one of them saves a fishbone in her pocket as a keepsake.`]},
    {t:`Pay for the winter's flour.`,need:{crumbs:60},habit:'gentle',led:{mercy:1,trust:1},cap:{hearth:1},flag:'flour',mem:`paid for a hearth-table's winter flour`,stand:true,
     say:[`Brock does a sum on the table with his finger, and it works. It is the first sum that has worked in some weeks. He sits down, slowly.`]},
    {t:`Sit at the table with them, and tell them about the road.`,need:{hours:2},habit:'tender',led:{kin:1,truth:1},flag:'told',mem:`told the sleepers' young kin about the road`,stand:true,
     say:[`You tell them the true parts, and only a little of the frightening. The smallest falls asleep against your wing. The eldest asks very careful questions, and writes the answers on her sleeve.`]},
    {t:`Suggest the older ones work for their bowls.`,habit:'proud',led:{pride:1},cap:{hearth:-1},flag:'work',mem:`told hungry children to earn their dinner`,
     say:[`Brock looks at you for a long moment. "They already do," he says, mildly. "Thank you for the suggestion." He turns back to the pot, and there is a small chill in the room that does not leave with you.`]}]},

 { id:'ember', a:13, b:15, who:[`Rook, a young smith`,P('#b0602a','#7a3a1a'),'cap'],
   brief:`A young smith has iron for one thing only: a plough or a sword. Something dug up, a shovel and a long afternoon, or a word.`,
   intro:[`(A smith with soot to the elbows holds a lump of old iron up to the light as if it might confess.)`,`"Warden Ruddock wants swords. The village wants ploughs. I have iron for one or the other, and not enough for both, and my master is in the long hall, asleep."`,`"Something old, from the ground, would do. Old iron is better. It remembers a hammer."`],
   q:`Rook puts the iron down. It leaves a mark on the anvil.`,
   gone:`(The forge went cold, and Rook swept it, and started again with what there was.)`,
   roll:{n:'Rook',line:`Rook, with a hammer in her belt and a face still pink from the forge.`,ex:{plough:`She is carrying a small plough on her shoulder, for no reason except that it is hers.`,sword:`She is carrying a sword she did not want to make, and is making a point of not looking at it.`,both:`She has two things on her back and a grin across her whole face.`}},
   opts:[
    {t:`Give her something old you dug up, for a plough.`,need:{relic:1},habit:'tender',led:{mercy:1,kin:1},cap:{hearth:1,mallow:1},flag:'plough',mem:`told a smith to forge a plough`,stand:true,
     say:[`She heats it until it is the deep orange of an early sunset. The plough comes out of the fire shaped like a promise.`,`Ruddock is not pleased. The village sends flowers.`]},
    {t:`Give her something old you dug up, for a sword.`,need:{relic:1},habit:'proud',led:{pride:1,truth:1},cap:{crown:1},flag:'sword',mem:`told a smith to forge a sword`,stand:true,
     say:[`The sword is plain and very good, and its edge catches the firelight like an idea. Ruddock takes it without ceremony.`,`"Thank you," he says, and means it more than he wishes to.`]},
    {t:`Dig for more iron, so she can make both.`,need:{shovel:1,hours:4},habit:'steady',led:{trust:1,kin:1},cap:{hearth:1,crown:1},flag:'both',mem:`dug iron enough for a plough and a sword`,stand:true,
     say:[`Four hours and a shed of rusted nails, and the iron is there, as if it had been waiting for a reason. She makes both. She falls asleep on the anvil, and does not mind.`]},
    {t:`Tell her to melt it down for coin.`,need:{relic:1},gain:45,habit:'guarded',led:{pride:1,lie:1},cap:{hearth:-1},flag:'coin',mem:`told a smith to melt old iron for coin`,
     say:[`She does. The coin is clean and bright and you do not feel like looking at it for long. "Fair enough," she says, flatly, and starts on a horseshoe.`]}]},

 { id:'mim', a:14, b:16, who:[`Old Bryony, a beekeeper`,P('#d4b04a','#a07a1a'),'hood'],
   brief:`A beekeeper whose hives are failing. Blooming plants, a potion in the sugar-water, a night's vigil, or honest advice.`,
   intro:[`(A beekeeper in a veil stands very still among a row of silent hives, with her wing flat against one of them, as if taking its pulse.)`,`"They stopped humming on Tuesday. They do not hum in the cold, but this was not the cold. It was the other kind of quiet."`,`"The flowers up the hill have gone to seed. They need something blooming, and soon, or I shall lose the lot."`],
   q:`She does not take her wing off the hive.`,
   gone:`(You hear half the hives survived the winter. Bryony does not say which half.)`,
   roll:{n:'Bryony',line:`Bryony, in her veil, carrying a small hive on her back like an infant.`,ex:{flowers:`A bee is on her shoulder. She does not shoo it.`,potion:`She keeps a spoon of the sugar-water in her pocket, in case.`,vigil:`She has brought a blanket for you, and a thermos of something sweet.`}},
   opts:[
    {t:`Bring blooming plants for the hives.`,need:{ing:6},habit:'tender',led:{mercy:1,kin:1},cap:{hearth:1,mallow:1},flag:'flowers',mem:`brought a beekeeper flowers for her failing hives`,stand:true,
     say:[`She scatters them along the row, and stands back. For a long time nothing. Then one hive, at the end, makes a sound like someone clearing their throat in a very large room.`]},
    {t:`Pour a brewed potion into the sugar-water.`,need:{pot:1},habit:'steady',led:{trust:1,mercy:1},cap:{mallow:1},flag:'potion',mem:`put a potion in a failing hive's sugar-water`,stand:true,
     say:[`She tips it in with a face that says she has never done anything more foolish. By dusk, the hum is back, thin and uncertain, like a rumour.`]},
    {t:`Sit up with the hives through the night.`,need:{hours:4},habit:'tender',led:{kin:1,trust:1},flag:'vigil',mem:`sat a night with a beekeeper's failing hives`,stand:true,
     say:[`There is nothing to do, and you do it for four hours. Bryony tells you the names of the queens. Towards morning one of the hives takes a breath.`]},
    {t:`Tell her it is the other kind of quiet, and she should save what she can.`,habit:'candid',led:{truth:1},flag:'honest',mem:`told a beekeeper to save what she could`,
     say:[`"Yes," she says, after a long time. "I thought so. I wanted somebody to say it, so I could start." She begins to split the hives, gently, one frame at a time.`]}]},

 { id:'tessel', a:17, b:19, who:[`Tessel, a granddaughter`,P('#a09ac0','#807aa0'),'scarf'],
   brief:`A woman whose great-grandmother sleeps in the hall. A potion and something old to make a lullaby draught, an hour of company, or the truth about waking.`,
   intro:[`(A woman sits on the edge of a cot in the long hall, with an old woman's hand in both of hers.)`,`"She is my grandmother's mother. She went to sleep a hundred years ago, so I never met her, and she has no idea who I am. They say when the ward breaks she will wake."`,`"I want her to say my name once. Even if it is only because she is told it. Is there something that could do that?"`],
   q:`Tessel does not look up from the hand.`,
   gone:`(You hear the old woman woke on the third day. Tessel was there. Nothing else was said, and nobody needed it to be.)`,
   roll:{n:'Tessel',line:`Tessel, with an old lantern her great-grandmother's age, held in both hands like something warm.`,ex:{draught:`She has a flask of something that smells of old lullabies, wrapped in a shawl.`,sat:`She has taught herself the old woman's name, and says it, quietly, to check.`,truth:`She is standing very straight, and ready.`}},
   opts:[
    {t:`Brew a lullaby draught: a potion, and something old from the ground.`,need:{pot:1,relic:1},habit:'tender',led:{mercy:1,kin:1},cap:{sleepers:1,hearth:1},flag:'draught',mem:`made a draught for a sleeper to hear her own name`,stand:true,
     say:[`You stir the potion with the old thing from the ground until the potion begins to hum something that was a song before any of you were born.`,`Tessel pours it over a spoon. Nothing happens. Then the old woman's lips move, very slightly, on a syllable that might be a name.`]},
    {t:`Sit with her, and tell the old woman who she is, in your own words.`,need:{hours:2},habit:'tender',led:{kin:1,truth:1},cap:{sleepers:1},flag:'sat',mem:`told a sleeper who her great-granddaughter was`,stand:true,
     say:[`You say it plainly, as if reading from a letter. Tessel holds the hand. The old woman does not stir. But the cot creaks, once, as if someone had turned toward the sound.`]},
    {t:`Tell her honestly: they may not wake as she remembers.`,habit:'candid',led:{truth:1},flag:'truth',mem:`told a woman her sleeper might not wake the same`,stand:true,
     say:[`Tessel is quiet for some time. "I know," she says. "I have read the same things you have. Thank you for not letting me pretend I had not."`,`She holds the hand tighter. She is, if anything, steadier.`]},
    {t:`Offer to carry her great-grandmother's name to the anchors for her.`,habit:'steady',led:{trust:1},cap:{sleepers:1},flag:'carry',mem:`carried a sleeper's name to the anchors`,stand:true,
     say:[`She writes it on a scrap of cloth, and sews it, with her teeth, into the hem of your coat. "So the stone knows who she is," she says. "Whoever she is, when she wakes."`]}]},

 { id:'moth', a:17, b:19, who:[`Moth, a watch-boy`,P('#7a7a8a','#5a5a6a'),'helm'],
   brief:`A boy set to watch the road alone through the last night, with a horn he does not want to blow. Company, a hot meal, or a kind lie.`,
   intro:[`(A boy of about twelve sits on an upturned bucket at the edge of the road, with a helmet over his ears and a horn in both hands.)`,`"I am supposed to blow it if I see the Crown. I have been supposed to for six hours. I have not blown it. I do not want to find out what I would do."`,`"They say it is the last night, and everyone is busy, and I am the only one who is not."`],
   q:`Moth holds the horn as if it might go off.`,
   gone:`(You hear the boy watched the road alone all night. He did not blow the horn. He says he did not need to.)`,
   roll:{n:'Moth',line:`Moth, in a helmet too big for him, with the horn on a string round his neck, which he has not once touched.`,ex:{stayed:`He stands very close to you, and pretends he is not.`,fed:`He has a crust of bread in his pocket, saved from the dinner you brought.`,took:`He holds the horn out to you and says it is yours now, which is not what he meant to say.`}},
   opts:[
    {t:`Stay and keep the watch with him.`,need:{hours:4},habit:'tender',led:{kin:1,trust:1},cap:{hearth:1},flag:'stayed',mem:`kept the night watch with a frightened boy`,stand:true,
     say:[`You sit on the other bucket. Nobody comes. Around the third hour he stops holding the horn so hard, and around the fourth he is asleep against your shoulder, helmet and all.`]},
    {t:`Bring him a hot meal: fish and greens.`,need:{fish:2,ing:3},habit:'gentle',led:{mercy:1,kin:1},flag:'fed',mem:`fed a frightened watch-boy on the last night`,stand:true,
     say:[`He eats everything, very fast, and then slowly apologises for eating so fast. "It is the first thing I have had since the morning," he says, and puts the bowl down with great care.`]},
    {t:`Tell him he can put the horn down. You will watch.`,need:{hours:2},habit:'steady',led:{trust:1,kin:1},cap:{hearth:1},flag:'took',mem:`took a frightened boy's horn and kept his watch`,stand:true,
     say:[`He gives you the horn like a hot coal. You hold it. It is heavier than it looks. He is asleep within the quarter hour, and you are, for a while, the only person on the road.`]},
    {t:`Tell him the Crown does not blow horns at boys. He will be fine.`,habit:'guarded',led:{lie:1,mercy:1},flag:'fib',mem:`told a frightened boy a kind lie`,
     say:[`He nods, and the horn lowers, an inch. You do not know if it is true. He believes it, for now, and that is what the lie was for.`]}]}
]);

/* ---------- 3. the road comes back ---------- */
D10.reqAdd([
 /* Nell's eldest returns */
 { id:'tully', a:9, b:11, if:()=>is('bree','fed','taught','paid'), who:[`Tully, Nell's eldest`,P('#6a8a9a','#4a6a7a'),null],
   brief:`Nell's eldest has come back with a fish of her own.`,
   intro:()=>({fed:[`(A child with a fish bigger than her arm walks up to you with great dignity, trailing a line.)`,`"Mam says you brought us fish, so I caught one. It is a bad one. It is a very bad one. I wanted you to have it."`],
              taught:[`(Nell's eldest is standing very straight, holding a perch like a trophy and a witness.)`,`"I did it the way you showed me. The fish was stupid with surprise. Mam wept. I did not, but I could have."`],
              paid:[`(The eldest child holds up a line with a real hook, tied with a small, precise knot.)`,`"Mam bought this with your crumbs. I did the knots. They are good knots. I would like you to see them."`]})[pk('bree')],
   q:`She holds the fish out to you, and for a moment is entirely serious.`,
   gone:`(You hear a girl at the pond has become, for the moment, very insufferable about fish.)`,
   roll:{n:'Tully',line:`Tully, with a fish-hook on her collar like a medal.`,ex:{ate:`She tells everyone near her that she catches the best fish in the Ward.`}},
   opts:[
    {t:`Take the fish, and eat it with them.`,need:{hours:1},habit:'tender',led:{kin:1,mercy:1},cap:{hearth:1},fx:{give:{baittin:2}},flag:'ate',mem:`ate a fisher's child's first catch with her family`,stand:true,
     say:[`It is a very bad fish. You eat it. Nell makes a face at you over the fire that says everything about the last year, and then she laughs.`,`Tully presses her bait tin on you, formally. "For luck," she says. "It is lucky. I have caught two things with it."`]},
    {t:`Tell her she should sell it. It is worth more than she thinks.`,habit:'candid',led:{truth:1},fx:{sell:0.01},flag:'sell',mem:`taught a child what her fish was worth`,
     say:[`She is quiet for a moment, then her face lights, enormously, with the dawn of commerce. "Oh," she says. "OH." She runs off. You have created something.`]},
    {t:`Give her your rod. She has earned a proper one.`,need:{rod:1},lose:['fishrod'],habit:'steady',led:{trust:1,kin:1,mercy:1},cap:{hearth:1},fx:{give:{baittin:3}},flag:'rod',mem:`gave a fisher's child your fishing rod`,stand:true,
     say:[`She takes it in both wings like a baby. "I will not drop it," she says. "I will not."`,`You have a fish to catch with, now, one fewer rod, and a debt of attention to the pond. Nell watches you walk off, and does not trust herself to speak.`]}]},
 { id:'tullysold', a:9, b:11, if:()=>is('bree','sold'), who:[`Tully, Nell's eldest`,P('#6a8a9a','#4a6a7a'),null],
   brief:`Nell's eldest has come to give you something back.`,
   intro:[`(A small girl stands in front of you with her fist closed, her chin up, and the air of someone who has rehearsed this.)`,`"Mam says you charged us. Full price, for fish. She says it was fair. I think it was fair and I think it was a bit rotten."`,`"She says to give you this. She does not want it. I am not sure she is right."`],
   q:`She opens her fist. There are eighteen crumbs in it, in a damp little heap.`,
   gone:`(The eldest child kept the crumbs. You hear she spent them on a good knife.)`,
   roll:{n:'Tully',line:`Tully, with a knife on her belt that she is very proud of.`,ex:{refused:`She follows a pace behind you, and means it as thanks.`}},
   opts:[
    {t:`Refuse it, and give her a fish instead.`,need:{fish:1},habit:'gentle',led:{mercy:1,kin:1},flag:'refused',mem:`gave back a fisher's child what you had charged her`,stand:true,
     say:[`You hand her a fish. She looks at it, and at you. "That is not a trade," she says. "That is a gift. Mam says there is a difference. I think you are doing both."`,`She holds the fish like a hot loaf, and goes to tell her mother.`]},
    {t:`Take it. A deal is a deal.`,habit:'guarded',led:{pride:1},flag:'took',mem:`took a hungry child's crumbs back`,
     say:[`She hands them over. She does not say thank you. She says "OK" in a flat voice, and walks away.`]},
    {t:`Take it, and slip it back into her pocket when she turns.`,habit:'gentle',led:{mercy:1,lie:1},flag:'slipped',mem:`quietly slipped a child's crumbs back into her pocket`,stand:true,
     say:[`She gets three steps. She stops. She checks her pocket, and stands very still. When she turns around you are looking at the sky with enormous interest.`,`"I saw that," she says. And then, a moment later: "Thank you."`]}]},

 /* Tamsin's ring, one way or the other */
 { id:'tamsin2', a:12, b:14, if:()=>is('tamsin','dug','gave','sat'), who:[`Old Tamsin`,P('#a8947a','#7a6a4a'),'scarf'],
   brief:`Tamsin has found something in her flour tin, and wants you to see.`,
   intro:()=>({dug:[`(Tamsin holds up a small, scratched, unmistakable ring on its ribbon, and her face is the face of someone who has had the same thought for forty years.)`,`"I was kneading, and there it was. In the flour. All this time. Alder must have put it back, somehow. He never did like me to be without."`],
              gave:[`(Tamsin is wearing the thing you gave her openly now, but in her other wing she holds another ring, small and scratched.)`,`"I found Alder's in the flour tin this morning. The real one. I am wearing both. I thought you should see them side by side."`],
              sat:[`(Tamsin is crying, in the matter-of-fact way of someone who has finished being sad and is now only wet.)`,`"I found it. It was in the flour tin. The ring. After you sat with me, and I stopped looking, it was just there."`]})[pk('tamsin')],
   q:`She is holding out her wing, the ring in it. She is not quite offering it to you.`,
   gone:`(You hear Tamsin's ring has been seen on her finger at the market, and that she shows it to people who have not asked.)`,
   roll:{n:'Tamsin',line:`Tamsin, with a ring on her finger now, and the ribbon round her neck, just in case.`,ex:{charm:`She touches the ring, then the ribbon, then you, in the same gesture.`}},
   opts:[
    {t:`Tell her it is wonderful, and ask to hear about Alder.`,need:{hours:1},habit:'tender',led:{kin:1,mercy:1},cap:{hearth:1},fx:{give:{wardcharm:1}},flag:'charm',mem:`listened to an old woman tell of her husband`,stand:true,
     say:[`She tells you all of it, over the better part of an hour, and when she is done she presses a little charm into your wing. "It was his. He said it was for luck. I never had any use for it, once I had him."`]},
    {t:`Say you are glad, and leave her to it.`,habit:'gentle',led:{mercy:1},flag:'glad',mem:`was glad with an old woman and left her to her ring`,
     say:[`She smiles at you, and puts her wing back round the ring, and for a moment she is nobody's grandmother and nobody's widow. She is just a duck who found something.`]}]},
 { id:'tamsink', a:12, b:14, if:()=>is('tamsin','kept'), who:[`Magnus Perrow, a collector`,P('#7a5a8a','#5a3a6a'),'hat'],
   brief:`A collector is asking about a ring that came from Tamsin's field.`,
   intro:[`(A well-dressed duck with a magnifying glass and a ledger bows, a little too deeply, in front of you.)`,`"Someone sold me a ring last week. A plain thing, forty years in the ground, from a field in the south. The seller was evasive. It has a mark inside the band: A. and T., very small."`,`"A woman in the next village is asking after a ring with that mark. I should like to do the right thing. I should also like to be paid for it. Do you know anything?"`],
   q:`He turns the glass over in his wing, and does not look away from you.`,
   gone:`(You hear the ring went back to a woman in the south, after some argument, and that no one knows who had it before.)`,
   roll:{n:'Magnus',line:`Magnus Perrow, with a magnifying glass and a rather new humility.`,ex:{confess:`He nods at you once in the line, without comment.`}},
   opts:[
    {t:`Confess. Buy it back, and take it to her.`,need:{crumbs:80},habit:'candid',led:{truth:1,mercy:1},cap:{hearth:1},flag:'confess',mem:`bought back a ring you had sold, and returned it`,stand:true,
     say:[`Perrow takes the crumbs without joy, and the ring is yours. You walk it to Tamsin, and you do not say where it has been. She studies you for a long moment. "Thank you," she says, and leaves it there.`]},
    {t:`Deny it. You know nothing about any ring.`,habit:'guarded',led:{lie:1,pride:1},fx:{cold:3},flag:'deny',mem:`denied selling a widow's ring`,
     say:[`Perrow looks at you for a while, then shrugs, with all the grace of a man who has already written something down. Word travels. It is not kind.`]},
    {t:`Tell him the truth, and send him to Tamsin yourself.`,habit:'candid',led:{truth:1,pride:1},flag:'told',mem:`told a collector where a stolen ring came from`,
     say:[`He nods. "A brave answer, and an expensive one. I will see that she gets it." He does not say what he will keep.`]}]},

 /* Pask, the ration */
 { id:'dill2', a:13, b:15, if:()=>is('dill','ration'), who:[`Quartermaster Pask`,P('#8a7a5a','#6a5a3a'),'cap'],
   brief:`The camp is angry about the half rations, and Pask is standing between the camp and you.`,
   intro:[`(Pask is standing in front of the cart with his arms out, like a man at a river's edge. Behind him, the camp is a crowd.)`,`"They want to know who said half rations. I have not told them. I have also not told them anything else, and that is a worse kind of quiet."`,`"It was your word. It was a good one, I think. I do not know if it is good enough."`],
   q:`The crowd is not shouting. That is the part that worries him.`,
   gone:`(The camp ate what there was, and some of them stopped speaking to the quartermaster, and nobody ever said why.)`,
   roll:{n:'Pask',line:`Pask, with the camp's last cart behind him and the look of a man who has finally stopped counting.`,ex:{stand:`He has your name written on his sleeve, with a line under it, and will not say what for.`}},
   opts:[
    {t:`Stock the camp now: fish and greens, to end the half rations.`,need:{fish:4,ing:6},habit:'steady',led:{trust:1,kin:1},cap:{hearth:2},fx:{unlock:'hearth'},flag:'amends',mem:`ended the half rations by stocking the cart yourself`,stand:true,
     say:[`The cart is full by dusk. The crowd breaks up like fog. Pask nods once, and writes your name on his sleeve.`]},
    {t:`Stand with Pask and say it was your call, and why.`,need:{hours:1},habit:'candid',led:{truth:1,pride:1},cap:{hearth:1},flag:'stand',mem:`told a hungry camp it was your decision to ration`,stand:true,
     say:[`You say it plainly. Some of them nod. Some of them don't. It is a long, uncomfortable half hour, and at the end of it Pask puts a hand, briefly, on your arm.`]},
    {t:`Let Pask take the blame. He is the quartermaster.`,habit:'guarded',led:{lie:1,pride:1},cap:{hearth:-1},flag:'blame',mem:`let a quartermaster take the blame for your decision`,
     say:[`Pask takes it. He nods, with a face like a door. It is the only time in your life you have seen a man bear a thing silently for you. You do not feel good.`]}]},
 /* Pask's cart, and the Crown checkpoint */
 { id:'corvin', a:17, b:19, if:()=>is('dill','raid'), who:[`Garrick, a checkpoint clerk`,P('#6a6a8a','#4a4a6a'),'helm'],
   brief:`A Crown clerk at the checkpoint recognises the mark on a certain supply cart.`,
   intro:[`(A thin clerk at the checkpoint holds up a ledger page with a drawing on it. The drawing is a cart. The cart has a wheel with a distinctive notch.)`,`"This cart was reported missing, three weeks ago, from the east road. It has been seen in your camp. I have no wish to be a bother. I do have a form."`,`"There are, I find, several kinds of answer. I will accept most of them. I will remember all of them."`],
   q:`He waits, pen over the page, in the manner of a man who is rarely made to wait.`,
   gone:`(The checkpoint clerk filed a form. You hear it will be dealt with after the war.)`,
   roll:{n:'Garrick',line:`Garrick, in the Crown's grey, who has quietly lost the page about the cart.`,ex:{work:`He holds his place a pace behind you.`}},
   opts:[
    {t:`Pay the fine.`,need:{crumbs:50},habit:'steady',led:{trust:1},cap:{crown:1},flag:'fine',mem:`paid for a cart you had taken`,
     say:[`He writes the receipt in a clean, fast hand. "Closed," he says. "I like it when they are closed."`]},
    {t:`Work it off: haul sandbags for the Crown for the afternoon.`,need:{hours:3},habit:'steady',led:{trust:1,kin:1},cap:{crown:1},flag:'work',mem:`worked off a stolen cart hauling sandbags for the Crown`,stand:true,
     say:[`It is a long afternoon, and a dull one, and nobody speaks to you. At the end Garrick signs the page without looking, and says, in a voice like a closing door: "That is the way to do it."`]},
    {t:`Confess: the camp was starving, and you took it.`,habit:'candid',led:{truth:1,mercy:1},cap:{crown:-1},flag:'confess',mem:`told a clerk why you took the cart`,stand:true,
     say:[`He is silent for a long moment. "I will write that down," he says. "I will write it exactly. I will not write what I think."`]},
    {t:`Say you found it abandoned on the road.`,habit:'guarded',led:{lie:1,pride:1},fx:{cold:3},flag:'lied',mem:`told a clerk you found a stolen cart abandoned`,
     say:[`He writes it down. He doesn't look up. "Thank you," he says. "That is a very specific lie, and I will remember it."`]}]},

 /* Bram's dying woman, and the Warden */
 { id:'bram2', a:15, b:17, if:()=>is('bram','trout','herring','bought'), who:[`Cole, the sergeant's brother`,P('#7a8a9a','#5a6a7a'),'hat'],
   brief:`The sergeant's brother has come about their mother's last meal.`,
   intro:()=>({trout:[`(A broad-shouldered duck in a sergeant's coat, holding a cloth parcel in both wings, finds you at the fire.)`,`"Our mother had a trout, three weeks ago. Her last meal, and the best, she said. Dunn has asked me to find who caught it."`],
               herring:[`(A broad-shouldered duck in a sergeant's coat finds you at the fire, with a face carefully emptied of expression.)`,`"Our mother was given a fish, three weeks ago. She said it was the best she ever had. Dunn would like to know, discreetly, whether it was a trout."`],
               bought:[`(A broad-shouldered duck in a sergeant's coat finds you at the fire.)`,`"Our mother had a trout, three weeks ago, and said it was the best. Dunn wishes to know who bought it, and to thank them."`]})[pk('bram')],
   q:`He waits with the parcel.`,
   gone:`(The sergeant's brother left his thanks with the cook, who passed it on, in a way that lost most of it.)`,
   roll:{n:'Cole',line:`Cole, in a borrowed sergeant's coat, with his brother Dunn beside him, carrying a basket.`,ex:{thanks:`He bows to you in the line, a quarter-inch deeper than he needs to.`}},
   opts:[
    {t:`Tell him the truth about the fish, whatever it was.`,habit:'candid',led:{truth:1,mercy:1},cap:{hearth:1},flag:'thanks',mem:`told a sergeant's brother the truth about their mother's last meal`,stand:true,
     say:[`He listens, and he nods, and when you have finished he is looking at the fire. "Thank you," he says. "That is what she would have wanted. She hated being managed."`]},
    {t:`Accept the sergeant's thanks, and a small token of it.`,habit:'gentle',led:{trust:1},cap:{crown:1},fx:{rep:1},flag:'token',mem:`took a sergeant's thanks for his mother's last meal`,
     say:[`He unwraps the parcel. It is a small seal of Dunn's company, plain and unglamorous, with a bay-leaf on it. "It will open some doors," he says. "It will not open all."`]},
    {t:`Ask him to give the thanks to Bram, and leave your name out.`,habit:'tender',led:{kin:1,mercy:1},flag:'quiet',mem:`asked that a cook be thanked in your place`,stand:true,
     say:[`He pauses. "That is generous," he says. "Or modest. In my experience, they are the same, and neither is common." He goes to find Bram.`]}]},

 /* Madder's soldier */
 { id:'fennel2', a:11, b:13, if:()=>is('fennel','gathered','potion','bought'), who:[`The soldier from the cot`,P('#7a8a6a','#5a6a4a'),'helm'],
   brief:`The soldier Madder was nursing has come to find you.`,
   intro:[`(A young soldier, upright and slightly thin, with a bundle under one arm, is leaning on a post as if standing were something he is doing for the first time.)`,`"They told me you were the one. I was not conscious for it, so I am going on what I am told. I would like to say thank you, and I am not sure I know how."`,`"I have not got much. I have got this."`],
   q:`He holds out the bundle. It is full of green things.`,
   gone:`(The soldier went back to his post. He is said to be unbearable about herbal tea.)`,
   roll:{n:'Soldier',line:`The soldier from Madder's cot, with his helmet under his arm and a sprig of something in his belt.`,ex:{heal:`He stands as straight as he can, and coughs only once.`}},
   opts:[
    {t:`Accept the herbs, and wish him well.`,habit:'gentle',led:{mercy:1},fx:{give:{healleaf:5}},flag:'heal',mem:`accepted a recovered soldier's thanks`,stand:true,
     say:[`He puts the bundle in your wing like a man handing over the keys of a city. "Five of them," he says. "They are the good ones. Madder picked them."`]},
    {t:`Ask him to carry word to Halbeak: the camp has good healers.`,habit:'steady',led:{trust:1},cap:{hearth:1},flag:'word',mem:`sent word to the Captain about the camp's healers`,stand:true,
     say:[`He salutes. It is his first in some days. "I will say it like a report," he says, "and I will leave out nothing."`]},
    {t:`Ask him what he was fighting for.`,need:{hours:1},habit:'candid',led:{truth:1,kin:1},flag:'ask',mem:`asked a soldier what he was fighting for`,stand:true,
     say:[`He thinks about it for a long time. "I was told," he says. "I never actually knew." He tells you what he would fight for now. It is a short list, and it is mostly people.`]}]},
 { id:'fennel2h', a:11, b:13, if:()=>is('fennel','honest'), who:[`Madder`,P('#7a9a6a','#5a7a4a'),'hood'],
   brief:`Madder has asked for a hand with something sad.`,
   intro:[`(Madder is sitting by a small, fresh mound at the edge of the camp, with a trowel in her lap.)`,`"He went in the night. Quietly. You told me the odds, and I made him comfortable. I am glad I did. I wish I had been less sure."`,`"There is no one else to say anything over him. I should like it to be somebody who was told the truth."`],
   q:`She does not ask you directly. She simply holds the trowel out.`,
   gone:`(Madder buried the soldier alone, and said what there was to say. You hear it was brief and entirely accurate.)`,
   roll:{n:'Madder',line:`Madder, with a basket of green things and a face that has finished crying.`,ex:{stay:`She walks a step behind you, as though she had always meant to.`}},
   opts:[
    {t:`Help her finish, and say a few plain words.`,need:{hours:2},habit:'tender',led:{kin:1,truth:1},cap:{hearth:1},flag:'stay',mem:`said a few plain words over a soldier's grave`,stand:true,
     say:[`You say what you know, which is not much, and all of it true. Madder plants something green at the head. "Marshroot," she says. "It comes back."`]},
    {t:`Pay for a stone, and have his name cut on it.`,need:{crumbs:25},habit:'gentle',led:{mercy:1},flag:'stone',mem:`paid for a soldier's gravestone`,stand:true,
     say:[`A mason is found. The name is cut small and neat. Madder runs her thumb over it, checking whether it is still warm.`]}]},

 /* Ivy, one way or the other */
 { id:'ivyk', a:17, b:19, if:()=>is('ivy','potion','gathered','watched'), who:[`Nurse Ivy`,P('#9a9aa8','#7a7a88'),'cap'],
   brief:`Ivy is offering to open the ward's stores.`,
   intro:[`(Ivy is sitting on the floor of the ward, with her back to a cot, and a ring of keys on her lap that she is turning over slowly.)`,`"The sleepers' ward has a store. It has medicines, and blankets, and a small hoard of dried things nobody has the heart to throw out. I am the only one with the keys."`,`"You helped. I would like you to take something. I would also like you to say no, because I am tired of people saying yes."`],
   q:`She holds out the keys. She is already smiling a little at the answer she expects.`,
   gone:`(Ivy kept the keys, and her stores, and her pride.)`,
   roll:{n:'Ivy',line:`Ivy, in her grey apron, who has left the ward in the care of someone she trusts, which cost her a great deal.`,ex:{keep:`She nods to you across the clearing in the way of two people who share a vigil.`}},
   opts:[
    {t:`Accept the stores. The road is hard.`,habit:'gentle',led:{trust:1},cap:{sleepers:1},fx:{unlock:'sleepers'},flag:'take',mem:`accepted the sleepers' stores`,
     say:[`She hands you the keys and a short list. "Take the first three," she says, "and the dried pears. The pears are for luck."`]},
    {t:`Say no. Keep it for the ward.`,habit:'steady',led:{trust:1,kin:1},cap:{sleepers:1},flag:'keep',mem:`refused the sleepers' stores for the ward's sake`,stand:true,
     say:[`She laughs, once, with her whole face. "Good," she says. "Good. I was hoping." She puts the keys back in her apron and pats the pocket.`]}]},
 { id:'ivys', a:17, b:19, if:()=>is('ivy','sold'), who:[`Nurse Ivy`,P('#9a9aa8','#7a7a88'),'cap'],
   brief:`Ivy has something to say about the price of a potion.`,
   intro:[`(Ivy meets you at the ward door, and does not move aside.)`,`"You sold me a potion. At full price. It worked. I am not complaining about the potion."`,`"I am saying that I spent the ward's contingency on it, and the contingency was for the winter. I am saying I thought you were someone who would not."`],
   q:`She is not angry, exactly. She is something worse. She is accurate.`,
   gone:`(Ivy never mentioned it again. She also never again asked you for anything.)`,
   roll:{n:'Ivy',line:`Ivy, in her grey apron, at the edge of the group, a little apart.`,ex:{repaid:`She nods to you once, and it is a gift, and you know it.`}},
   opts:[
    {t:`Give her the crumbs back, with an apology.`,need:{crumbs:70},habit:'candid',led:{truth:1,mercy:1},cap:{sleepers:1},flag:'repaid',mem:`repaid a nurse the price of a potion`,stand:true,
     say:[`She counts it, and puts it in the contingency box without speaking. Then she holds the door open. "Thank you," she says. "Come in."`]},
    {t:`Say you needed the crumbs for the road.`,habit:'guarded',led:{pride:1},flag:'excuse',mem:`told a nurse you needed her crumbs for the road`,
     say:[`"I know," she says. "That is what I thought." She closes the door, not unkindly.`]},
    {t:`Say nothing. It was a fair price.`,habit:'proud',led:{pride:1},cap:{sleepers:-1},flag:'silent',mem:`said nothing to a nurse who overpaid`,
     say:[`She waits. You wait. She closes the door, quite gently, and a small cold thing settles in the space between you.`]}]},

 /* Wyn's pot, full */
 { id:'marrow2', a:17, b:19, if:()=>is('marrow','fish','greens','paid'), who:[`Wyn, a camp cook`,P('#a07a5a','#7a5a3a'),'scarf'],
   brief:`Wyn's pot has been full all week, and she has something for you.`,
   intro:[`(Wyn is standing at a pot so full it is making a small, unhappy noise at the lid.)`,`"A queue came through this morning, and the one at the back was carrying a baby. She asked who the stew was from. I said I did not know. I do know. I have been thinking about how to say it."`,`"I have three tins I kept back. They are the best I have made. I would like you to have them. I would also like to have said it."`],
   q:`She holds out a tin in each wing. The third is balanced on her head, which she has forgotten.`,
   gone:`(Wyn's pot went on being full. She hasn't forgotten who started it.)`,
   roll:{n:'Wyn',line:`Wyn, with the pot, which is full.`,ex:{tins:`She has brought the ladle and nothing else, and it is plenty.`}},
   opts:[
    {t:`Accept the tins. They are earned.`,habit:'gentle',led:{trust:1},fx:{give:{campstew:3}},flag:'tins',mem:`accepted a cook's best stew as thanks`,stand:true,
     say:[`She hands them over one by one, with a nod after each. "That one is for the road," she says. "That one is for the night after. That one is for the day you are tired."`]},
    {t:`Give them to the queue. They need them more.`,habit:'tender',led:{mercy:1,kin:1},cap:{hearth:1},flag:'queue',mem:`gave a cook's best stew to a refugee queue`,stand:true,
     say:[`She holds still. Then she turns and hands the tins down the line, one to a family. The baby gets the last one, and the mother says "thank you" to the tin.`]}]}
]);
})();
