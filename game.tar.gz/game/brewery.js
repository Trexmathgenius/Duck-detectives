'use strict';
/* ===== THE BREWERY: plants become ingredients, a Recipe Book turns them into potions you cannot get anywhere else =====
   - Every plant you forage now drops an ingredient (kept in your satchel, not your pack). Rarer plants drop better grades,
     and rare plants also drop a little Essence of the place they grow.
   - A new shop, the Brewery, sells the Brewer's Recipe Book (100 crumbs). You cannot work shifts there.
   - The book (B, or from your pack) lists every recipe, which ones you can brew right now, and what each potion does.
     Pick one and pay the crumbs to brew it. Brewed potions exist nowhere else in the game. */

/* ---------------- ingredients ---------------- */
const BR_CATS=['flower','bush','mush','tree','rock','stump'];
const BR_PART={
  flower:['Wild Petals','Fine Blossoms','Radiant Blooms'],
  bush:['Wild Berries','Ripe Fruit','Jewel Berries'],
  mush:['Mushroom Caps','Glimmer Caps','Mystic Caps'],
  tree:['Bark Shavings','Amber Sap','Heartwood Resin'],
  rock:['Pebble Grit','Crystal Dust','Gem Dust'],
  stump:['Soft Moss','Silver Lichen','Elder Lichen']
};
const BR_NOUN={flower:['blossom','blossoms'],bush:['berry','berries'],mush:['cap','caps'],tree:['sap','sap'],rock:['grit','grit'],stump:['moss','moss']};
const BR_GRADE=['Wild','Choice','Prime'];
const BR_ESS={forest:'Oakwood',meadow:'Meadow',autumn:'Amberwood',tundra:'Frostwood',highlands:'Highland',desert:'Dune',jungle:'Canopy',swamp:'Mistmarsh',bamboo:'Bamboo',cherry:'Blossom Hills',glowcap:'Glowcap',lavender:'Lavender',shore:'Shore',savanna:'Savanna'};
const BR_ESSCH=[0.08,0.12,0.4,0.6,0.85,1,1];      /* chance of an essence, by plant rarity tier */
const brGrade=t=>t>=2?2:t>=1?1:0;                  /* Common = Wild, Uncommon = Choice, Rare and up = Prime */
const brKey=(c,gr)=>c+':'+gr;
function BS(){
  const s=g.story||(g.story={}); const b=s.brew||(s.brew={});
  if(!b.ing) b.ing={}; if(!b.ess) b.ess={}; if(!b.made) b.made={};
  return b;
}

/* called from wlForage once a plant has been gathered; returns the text to show */
function brewDrop(sp,cat,bid){
  if(!BR_PART[cat]) return '';
  const s=BS(), tier=sp?sp.tier:0, gr=brGrade(tier), plenty=typeof fxLeft==='function'&&fxLeft('plenty')>0;
  const n=plenty?2:1, k=brKey(cat,gr);
  s.ing[k]=(s.ing[k]||0)+n;
  let txt='Ingredient: +'+n+' '+BR_PART[cat][gr]+'.';
  const biome=sp?sp.biome:bid;
  if(biome&&BR_ESS[biome]&&rnd()<Math.min(1,BR_ESSCH[tier]*(plenty?1.5:1))){
    s.ess[biome]=(s.ess[biome]||0)+1;
    txt+=' And a drop of '+BR_ESS[biome]+' Essence!';
  }
  if(!g.inv.recipebook&&!s.hint){ s.hint=1; txt+=' (A Brewer\'s Recipe Book, sold at breweries, turns these into potions.)'; }
  return txt;
}

/* ---------------- new timed effects ---------------- */
Object.assign(FX_NAMES,{finder:'Sharp Eyes',plenty:'Green Thumb',charm:'Charmed'});
Object.assign(FX_TEXT,{finder:'finds turn up far more often when you forage',plenty:'foraging gives extra ingredients and more essence',charm:'shops charge a little less'});
{
  const _wim=wlItemMul;
  wlItemMul=function(){ return _wim()*(fxLeft('finder')>0?3:1); };
  const _ip=itemPrice;
  itemPrice=function(id,town){
    if(id==='recipebook') return 100;
    const p=_ip(id,town);
    return fxLeft('charm')>0?Math.max(1,Math.round(p*0.85)):p;
  };
}

/* ---------------- the recipes ---------------- */
/* req: ['flower',2] = two flower parts of any grade;  ['rock',1,1] = one rock part, Choice grade or better;
        ['any',3] = three parts of any plant;  ['e:tundra',1] = one Frostwood Essence */
const BR_RECIPES=[];
const R=(id,name,tier,req,cost,fx,col,desc)=>BR_RECIPES.push({id:id,name:name,tier:tier,req:req.map(q=>({c:q[0],n:q[1],g:q[2]||0})),cost:cost,fx:fx,col:col,desc:desc});
/* -- Everyday brews (Wild ingredients) -- */
R('honeydew','Honeydew Cordial',0,[['flower',2],['bush',1]],8,'forage4 haggle2',['#f2c84a','#c98a12','#fff3b0'],'Sweet enough to make a bee blush. Foragers get a nose for crumbs and shopkeepers get a little soft.');
R('mossmoon','Mossy Moonbrew',0,[['stump',2],['mush',1]],8,'luck3 glow900',['#7ab88a','#3a7a52','#d8ffe4'],'Brewed in the dark, glows in the dark, tastes like a damp library.');
R('bramblefizz','Bramble Fizz',0,[['bush',2],['tree',1]],6,'speed120 forage2',['#b04a7a','#7a2a52','#ffc8e0'],'It fizzes up the nose and straight down to the feet.');
R('pebblepunch','Pebble Punch',0,[['rock',2],['stump',1]],8,'haggle3 angler3',['#9aa6b8','#5e6a80','#e0e8f4'],'Gritty, cold and strangely persuasive. Fish and shopkeepers both go quiet when you hold it.');
R('capnap','Sleepy Cap Tea',0,[['mush',2],['flower',1]],6,'time3 luck2',['#c8a8e0','#8a5ab0','#f0e0ff'],'A warm cup, a three hour nap, and you wake up luckier than you lay down.');
R('saplingstout','Sapling Stout',0,[['tree',2],['bush',1]],10,'plenty3 forage3',['#8a5a2a','#4a2a12','#e0c090'],'Dark, malty and green around the edges. Plants seem to want to be picked afterwards.');
R('petalpop','Petal Pop',0,[['flower',3]],6,'luck2 charm2',['#f090b8','#c04a80','#ffe0ee'],'Pink, bubbly and impossible to say no to.');
/* -- Fine brews (Choice ingredients) -- */
R('bloomwine','Bloomwine',1,[['flower',2,1],['bush',1]],24,'luck5 forage4 haggle3',['#c04a8a','#7a1a5a','#ffc0e4'],'Three blessings in one bottle. The petals are Choice, and you can tell.');
R('owleye','Owl-Eye Elixir',1,[['mush',2,1],['stump',1]],24,'finder4 glow1200',['#f0d84a','#a88a12','#fffbc0'],'Everything sparkles a little more. That is where the good stuff is hiding.');
R('treasuretinct','Treasure Tincture',1,[['rock',2,1],['tree',1]],26,'sure dowse',['#d8b84a','#8a6a12','#fff0b0'],'Your next dig finds a relic, and the bottle itself points to anything buried nearby.');
R('silversalve','Silver Sap Salve',1,[['tree',2,1],['flower',1]],26,'charm5 haggle4',['#c8d0e0','#8a94ac','#ffffff'],'Rub it on your bill. Shopkeepers will talk themselves into discounts.');
R('greenthumb','Green Thumb Tonic',1,[['flower',1,1],['tree',1,1],['stump',1]],22,'plenty5 forage3',['#5ac060','#2a7a32','#d0ffd4'],'For a few hours every plant you pick is generous. Ingredients come double.');
R('trailfizz','Trailblazer\'s Fizz',1,[['rock',1,1],['bush',2]],20,'dowseTrail speed150 luck2',['#e07a3a','#a8441a','#ffd8b0'],'Points at the nearest trail treasure and sends you hurrying towards it.');
R('cloverkick','Lucky Clover Cocktail',1,[['flower',2,1],['mush',1,1]],30,'luck8 finder3',['#3ac07a','#1a7a46','#c8ffe0'],'Four leaves, eight hours, and a rare find waiting behind every other bush.');
R('anglersamber','Angler\'s Amber',1,[['tree',1,1],['bush',1,1],['rock',1]],26,'angler7 luck3',['#e8a020','#a86a0a','#fff0b0'],'The pond goes still, then the rare ones come to say hello.');
R('humdraught','Hollowhum Draught',1,[['mush',2,1],['rock',1],['stump',1]],26,'hum1800 glow300',['#4a3a6a','#1a1030','#b8a0ff'],'Tastes of cold bark and a held breath. For a couple of hours you can feel the low hum of the Dark Trees, and which way it pulls.');
/* -- Masterworks (Prime ingredients) -- */
R('dawnpetal','Dawnpetal Draught',2,[['flower',1,2],['bush',1,1],['tree',1]],50,'luck10 forage6 haggle5 finder5',['#ff8aa8','#d0407a','#fff0f4'],'Four blessings at once, ten hours of luck. The Radiant Bloom inside it never stopped blooming.');
R('starnectar','Starlit Nectar',2,[['mush',1,2],['flower',1,1]],55,'glow3600 finder6 luck6 dowse',['#8aa8ff','#4a58d0','#e0e8ff'],'A whole hour of starlight in a bottle, and it hums when something valuable is near.');
R('heartwood','Heartwood Elixir',2,[['tree',1,2],['stump',1,1]],55,'plenty8 charm8 rep2',['#a8683a','#6a3a12','#f0d0a0'],'Slow, warm, ancient. Plants and people both give a little more.');
R('geodegold','Geode Gold Brew',2,[['rock',1,2],['rock',2]],60,'haggle10 sure luck4',['#f0b82a','#a87a0a','#fff4b0'],'Ten hours of sweet talk, a guaranteed relic, and a taste like a coin.');
R('eldervigor','Elder\'s Vigor',2,[['stump',1,2],['bush',1,1]],50,'speed150 forage8 angler6',['#7a9a4a','#3a5a1a','#dcf0b0'],'Lichen as old as the forest. You will feel old, then very fast.');
/* -- Essence brews: one drop of a faraway place, plus any three plants -- */
const BR_BIO=[
  ['forest','Oakwood Tonic','luck4 forage4',['#6a9a52','#3a6a2a','#d4f4c0'],'Acorns, bark and the quiet of the first forest.'],
  ['meadow','Meadow Mead','forage6 haggle4',['#f0d070','#c09a20','#fff8d0'],'Every flower in the meadow voted for this one.'],
  ['autumn','Amber Cider','luck5 speed90',['#d8782a','#8a3a0a','#ffd8a8'],'Spiced, warm, tastes like a bonfire in a good mood.'],
  ['tundra','Frostlight Elixir','glow2400 angler6',['#a0d8f8','#4a8ac0','#f0fbff'],'Cold enough to ring. Lights your way for forty minutes and calms the ice-fish.'],
  ['highlands','Highland Dram','haggle6 dowse',['#a89a8a','#5e5242','#ece4d8'],'Smoky stone and thin air. Haggle hard, dowse harder.'],
  ['desert','Mirage Draught','luck6 haggle4',['#e8c070','#a87a2a','#fff2c8'],'You are not sure you drank it. You are sure you got lucky.'],
  ['jungle','Canopy Cooler','forage6 speed100 plenty3',['#3ac07a','#0a7a46','#c8ffdc'],'Dripping, green, and louder than it has any right to be.'],
  ['swamp','Mistmarsh Murk','angler6 glow1200 luck3',['#6a8a6a','#364a38','#c8dcc8'],'Murky on purpose. The wisps like it, and so do the fish.'],
  ['bamboo','Bamboo Breeze','speed150 rep1 luck3',['#b8d860','#6a8a1a','#f0ffc0'],'Light as a reed, quick as a gust. Good manners in a bottle.'],
  ['cherry','Blossom Sake','charm6 luck5 rep1',['#f8b8d0','#d0608a','#fff0f6'],'Served with a falling petal. It is not for drinking quickly.'],
  ['glowcap','Glowcap Glimmer','glow3600 finder5',['#b87aff','#5a2aa8','#ecd8ff'],'A violet glow for an hour, and rare things start glowing back.'],
  ['lavender','Lavender Dreamcup','time6 luck4 charm3',['#a898e8','#6a58b8','#e8e0ff'],'Six hours of the best sleep you never had, and you wake up charming.'],
  ['shore','Sea-Breeze Spritz','angler8 speed60 charm3',['#6ad8c8','#2a8a9a','#d4fff6'],'Salt on the rim, tide in the glass. The rare fish come right up to the bank.'],
  ['savanna','Savanna Sunrise','speed120 forage5 finder3',['#f09a2a','#b8541a','#ffe0a8'],'Orange all the way down. You can see rare things on the horizon.']
];
for(const b of BR_BIO) R('ess_'+b[0],b[1],1,[['e:'+b[0],1],['any',3]],30,b[2],b[3],b[4]+' Needs a drop of '+BR_ESS[b[0]]+' Essence.');

/* -- the potions become real items with real effects -- */
const brFxParse=str=>str.split(' ').map(t=>{ const m=/^(!?[a-zA-Z]+)([\d-]*)$/.exec(t); const a=m[2].split('-').map(Number); return {k:m[1],a:a[0]||0,b:a[1]||0}; });
for(const r of BR_RECIPES){
  const id='p_'+r.id, list=brFxParse(r.fx);
  FXD[id]=r.fx; FXP[id]=list;
  ITEMS[id]={name:r.name,price:0,cat:'potion',desc:r.desc+' Use it: '+fxSummary(list)+'.',use:'note',note:'',nogift:true,glyph:r.tier>=1?'flask':'vial',gc:r.col};
}
function brBrief(list){
  const N={forage:'Keen Nose',luck:'Fortune',angler:'Steady Hands',haggle:'Silver Tongue',finder:'Sharp Eyes',plenty:'Green Thumb',charm:'Charmed'}, out=[];
  for(const e of list){
    if(N[e.k]) out.push(N[e.k]+' '+e.a+'h');
    else if(e.k==='speed') out.push('Zippy');
    else if(e.k==='glow') out.push('Glow '+Math.round(e.a/60)+'m');
    else if(e.k==='rep') out.push('Standing +'+e.a);
    else if(e.k==='time') out.push('Nap '+e.a+'h');
    else if(e.k==='dowse') out.push('Dowsing');
    else if(e.k==='hum') out.push('Dark-Tree sense 2h');
    else if(e.k==='dowseTrail') out.push('Trail sense');
    else if(e.k==='sure') out.push('Sure dig');
  }
  return out.join(', ');
}

/* ---------------- planning a brew ---------------- */
function brPlan(r){
  const s=BS(), ing=Object.assign({},s.ing), ess=Object.assign({},s.ess);
  const used={}, usedE={}, fail=r.req.map(()=>false);
  const order=r.req.map((q,i)=>i).sort((a,b)=>{
    const A=r.req[a], B=r.req[b], ea=A.c.indexOf('e:')===0?1:0, eb=B.c.indexOf('e:')===0?1:0;
    if(ea!==eb) return eb-ea;
    if(A.g!==B.g) return B.g-A.g;
    return (A.c==='any'?1:0)-(B.c==='any'?1:0);
  });
  for(const i of order){
    const q=r.req[i];
    if(q.c.indexOf('e:')===0){
      const b=q.c.slice(2);
      if((ess[b]||0)>=q.n){ ess[b]-=q.n; usedE[b]=(usedE[b]||0)+q.n; } else fail[i]=true;
      continue;
    }
    const cats=q.c==='any'?BR_CATS:[q.c], take=[];
    let need=q.n;
    for(let gr=q.g;gr<=2&&need>0;gr++) for(const c of cats){
      const k=brKey(c,gr), t=Math.min(need,ing[k]||0);
      if(t>0){ take.push([k,t]); need-=t; }
    }
    if(need>0){ fail[i]=true; continue; }
    for(const t of take){ ing[t[0]]-=t[1]; used[t[0]]=(used[t[0]]||0)+t[1]; }
  }
  return {ok:!fail.some(Boolean),fail:fail,used:used,usedE:usedE};
}
function brHave(q){      /* how many matching ingredients are in the satchel, for display */
  const s=BS();
  if(q.c.indexOf('e:')===0) return s.ess[q.c.slice(2)]||0;
  let n=0; for(const c of (q.c==='any'?BR_CATS:[q.c])) for(let gr=q.g;gr<=2;gr++) n+=s.ing[brKey(c,gr)]||0;
  return n;
}
function brReqLabel(q){
  if(q.c.indexOf('e:')===0) return q.n+' '+BR_ESS[q.c.slice(2)]+' Essence';
  if(q.c==='any') return q.n+' plant parts'+(q.g?' ('+BR_GRADE[q.g]+'+)':'');
  return q.n+' '+BR_NOUN[q.c][q.n>1?1:0]+(q.g?' ('+BR_GRADE[q.g]+'+)':'');
}

/* ---------------- the Recipe Book ---------------- */
const brUI={root:document.getElementById('brew'),list:document.getElementById('brList'),sat:document.getElementById('brSat'),det:document.getElementById('brDet'),msg:document.getElementById('brMsg'),cr:document.getElementById('brCrumbs'),say:document.getElementById('brSay'),filt:document.getElementById('brFilter')};
let brSel=0, brFilter=0;
function brRows(){
  const all=BR_RECIPES.map(r=>({r:r,plan:brPlan(r)}));
  const rows=brFilter===0?all.filter(x=>x.plan.ok):all;
  rows.sort((a,b)=>(b.plan.ok-a.plan.ok)||(a.r.tier-b.r.tier)||(a.r.cost-b.r.cost));
  return {rows:rows,nOk:all.filter(x=>x.plan.ok).length,nAll:all.length};
}
function brSatchel(){
  const s=BS(), parts=[];
  for(const c of BR_CATS) for(let gr=0;gr<3;gr++){ const n=s.ing[brKey(c,gr)]||0; if(n) parts.push(BR_PART[c][gr]+' <b>'+n+'</b>'); }
  const es=Object.keys(s.ess).filter(b=>s.ess[b]>0&&BR_ESS[b]).map(b=>BR_ESS[b]+' Essence <b>'+s.ess[b]+'</b>');
  return '<b>Satchel:</b> '+(parts.length?parts.join(', '):'empty')+(es.length?'<br><b>Essences:</b> '+es.join(', '):'')+(parts.length||es.length?'':'. Forage flowers, bushes, mushrooms, trees, rocks and stumps to fill it.');
}
function openBrew(){
  if(g.mode!=='play') return;
  if(!g.inv.recipebook){ toast('You need a Brewer\'s Recipe Book. Breweries sell them.',3000); return; }
  g.mode='brew'; brUI.root.hidden=false; brSel=0;
  brFilter=brRows().nOk?0:1;
  brUI.msg.style.color=''; brUI.msg.innerHTML='&nbsp;';
  brRender(); blip();
}
function closeBrew(){ if(g.mode!=='brew') return; g.mode='play'; brUI.root.hidden=true; blip(); }
function brRender(keepId){
  const d=brRows(), rows=d.rows;
  if(keepId){ const i=rows.findIndex(x=>x.r.id===keepId); if(i>=0) brSel=i; }
  if(brSel>=rows.length) brSel=Math.max(0,rows.length-1);
  brUI.cr.textContent=g.crumbs;
  brUI.say.textContent='Brewed so far: '+Object.keys(BS().made).reduce((n,k)=>n+BS().made[k],0)+'   |   '+d.nOk+' of '+d.nAll+' recipes ready to brew';
  brUI.sat.innerHTML=brSatchel();
  brUI.filt.textContent=brFilter===0?'Showing: can brew now ('+d.nOk+')  -  C for all '+d.nAll:'Showing: all '+d.nAll+' recipes  -  C for only brewable';
  brUI.list.innerHTML='';
  if(!rows.length){
    const li=document.createElement('li'); li.className='row'; li.style.cursor='default';
    li.innerHTML='<div></div><div><div class="nm">Nothing to brew yet</div><div class="ds">Forage plants to fill your satchel, then come back. Press C to read every recipe and see what each one needs.</div></div><div></div>';
    brUI.list.appendChild(li); brUI.det.textContent=''; return;
  }
  rows.forEach((x,i)=>{
    const r=x.r, poor=g.crumbs<r.cost;
    const li=document.createElement('li');
    li.className='row'+(i===brSel?' sel':'')+(poor?' poor':'')+(x.plan.ok?'':' miss');
    const ic=iconCanvas('p_'+r.id);
    const mid=document.createElement('div');
    const nm=document.createElement('div'); nm.className='nm'; nm.textContent=r.name+(BS().made[r.id]?'  (brewed '+BS().made[r.id]+')':'')+'  -  '+(r.id.indexOf('ess_')===0?'Essence':['Everyday','Fine','Masterwork'][r.tier]);
    const rq=document.createElement('div'); rq.className='ds req'; rq.appendChild(document.createTextNode('Needs: '));
    r.req.forEach((q,j)=>{
      const sp=document.createElement('span'); sp.className=x.plan.fail[j]?'no':'ok'; sp.textContent=brReqLabel(q)+' ['+brHave(q)+']';
      if(j) rq.appendChild(document.createTextNode(', ')); rq.appendChild(sp);
    });
    const ef=document.createElement('div'); ef.className='ds'; ef.textContent='Gives: '+brBrief(FXP['p_'+r.id]);
    mid.append(nm,rq,ef);
    const pr=document.createElement('div'); pr.className='price'; pr.textContent=r.cost+' crumbs';
    li.append(ic,mid,pr);
    li.addEventListener('click',()=>{ if(brSel===i) brBrew(); else { brSel=i; blip(); brRender(); } });
    brUI.list.appendChild(li);
  });
  const cur=rows[brSel];
  if(cur) brUI.det.textContent=cur.r.desc+'  Effects: '+fxSummary(FXP['p_'+cur.r.id])+'.';
  const sel=brUI.list.children[brSel]; if(sel&&sel.scrollIntoView) sel.scrollIntoView({block:'nearest'});
}
function brBrew(){
  const rows=brRows().rows, x=rows[brSel]; if(!x) return;
  const r=x.r;
  if(!x.plan.ok){ brUI.msg.style.color='var(--bad)'; brUI.msg.textContent='You are missing ingredients for the '+r.name+'.'; tone('square',300,180,0.15,0.06); return; }
  if(g.crumbs<r.cost){ brUI.msg.style.color='var(--bad)'; brUI.msg.textContent='Not enough crumbs: the '+r.name+' costs '+r.cost+'.'; tone('square',300,180,0.15,0.06); return; }
  const s=BS();
  for(const k in x.plan.used) s.ing[k]-=x.plan.used[k];
  for(const b in x.plan.usedE) s.ess[b]-=x.plan.usedE[b];
  g.crumbs-=r.cost; addItem('p_'+r.id); s.made[r.id]=(s.made[r.id]||0)+1;
  coin(); quack();
  brUI.msg.style.color='var(--good)'; brUI.msg.textContent='Brewed a '+r.name+'. It is in your pack.';
  brRender(r.id);
}
function brKeyPress(k){
  if(k==='x'||k==='b'){ closeBrew(); return; }
  const n=brRows().rows.length;
  if(k==='up'&&n){ brSel=(brSel-1+n)%n; blip(); brUI.msg.innerHTML='&nbsp;'; brRender(); }
  else if(k==='down'&&n){ brSel=(brSel+1)%n; blip(); brUI.msg.innerHTML='&nbsp;'; brRender(); }
  else if(k==='z') brBrew();
  else if(k==='c'){ brFilter=brFilter?0:1; brSel=0; blip(); brRender(); }
}
document.getElementById('brClose').addEventListener('click',closeBrew);
brUI.filt.addEventListener('click',()=>{ if(g.mode!=='brew') return; brFilter=brFilter?0:1; brSel=0; blip(); brRender(); });

/* ---------------- keys, the pack, the HUD ---------------- */
KEYMAP.b='b'; KEYMAP.B='b';
{
  const _press=press;
  press=function(k){
    if(g.mode==='brew'){ brKeyPress(k); return; }
    if(g.mode==='play'&&k==='b'){ openBrew(); return; }
    _press(k);
  };
  const _use=useItem;
  useItem=function(id){
    const it=ITEMS[id];
    if(it&&it.use==='brewbook'){ closeInv(); openBrew(); return; }
    _use(id);
  };
}
ITEMS.recipebook={name:'Brewer\'s Recipe Book',price:100,desc:'A stained, well-loved book of recipes. It lists every potion you could brew from the plants in your satchel, what each one does, and what it costs to make. Press B anywhere, or open it from your pack.',use:'brewbook',nogift:true,glyph:'recbook',gc:['#8a4a22','#f4e2b8','#e8b030']};
Object.assign(WL_G,{
  recbook:(c,k)=>{ rect(c,3,2,10,12,k[0]); rect(c,3,2,2,12,'rgba(0,0,0,0.3)'); rect(c,5.5,4,6,8,k[1]); c.fillStyle='#6a7a8a'; c.beginPath(); c.moveTo(7.2,5); c.lineTo(9.8,5); c.lineTo(9.8,7.4); c.lineTo(11,10.8); c.lineTo(6,10.8); c.lineTo(7.2,7.4); c.closePath(); c.fill(); rect(c,6.6,8.8,3.6,1.8,k[2]); rect(c,9.4,3,1.2,2,k[2]); },
  flask:(c,k)=>{ rect(c,6,1.5,4,2,'#8a5a2b'); rect(c,6.8,3.5,2.4,3,'rgba(215,235,245,0.85)'); circ(c,8,10.4,5,'rgba(215,235,245,0.85)'); circ(c,8,10.8,4.2,k[0]); rect(c,4.6,8.8,6.8,1,k[1]); rect(c,5.2,9.4,1.4,2.6,k[2]); circ(c,10,11.6,0.8,k[2]); }
});

/* ---------------- the Brewery shop ---------------- */
if(!SHOP_KINDS.includes('brewery')) SHOP_KINDS.push('brewery');
window.SHOP_LABEL=window.SHOP_LABEL||{}; window.SHOP_LABEL.brewery='a brewery';
SHOP_NAMES.brewery=['The Copper Kettle Brewery','Hops & Hollow Brewhouse','Steep & Stir Brewers','The Bubbling Cauldron'];
HOURS.brewery=[10,21];
FLOORS.brewery=['#8a5a3a','#7c4e30'];
RUGS.brewery='#c98a4a';
GOODS.brewery=['#b8742a','#e8c24a','#6a3a1a'];
GREET.brewery=['Mind the cauldron. It bites.','Nothing here is for drinking. Everything here is for brewing. Mostly.','Smell that? That is patience, fermenting.','Bring me plants and I will tell you what they could become.'];
STOCK.brewery=['recipebook'];
{
  const _openCounter=openCounter;
  openCounter=function(){
    const b=g.shop.b, t=g.shop.town;
    if(b.kind!=='brewery'){ _openCounter(); return; }
    const labels=['Browse the shelves','Ask about brewing'], fns=[()=>openShop(),()=>brAbout(b)];
    if(g.inv.recipebook){ labels.push('Open my recipe book'); fns.push(()=>openBrew()); }
    if(typeof wlFindCount==='function'&&wlFindCount()>0){ labels.push('Sell finds ('+wlFindCount()+')'); fns.push(()=>wlSellMenu(b,t)); }
    labels.push('Chat','Leave'); fns.push(()=>chatKeeper(b,t),()=>{});
    const gr=RANK_GREET[townRank(t)];
    choose(b.keeper.name,gr[(b.idx+g.day)%gr.length]+' What can I do for you?',labels,k=>fns[k](),labels.length-1);
  };
  const _buy=buy;
  buy=function(){
    const id=shopStock(g.shop.b,g.shop.town)[g.shopSel];
    if(id==='recipebook'&&g.inv.recipebook){ el.shMsg.style.color='var(--bad)'; el.shMsg.textContent='You already own a Recipe Book.'; tone('square',300,180,0.15,0.06); return; }
    _buy();
    if(id==='recipebook'&&g.inv.recipebook) el.shMsg.textContent+=' Press B to open it.';
  };
}
function brAbout(b){
  const k=b.keeper.name;
  say(k,[
    'Brewing is a craft, not a chore. I do not take on helpers here, and I do not sell potions. Nobody does.',
    'You make them. Forage flowers, bushes, mushrooms, trees, rocks and stumps, and each plant you take leaves you with an ingredient. Rarer plants leave better ones, and the rare ones can leave a drop of Essence from the place they grew.',
    'The Recipe Book is '+(g.inv.recipebook?'the one you already carry':'100 crumbs')+'. It shows every potion your satchel can make, what it does, and what the brewing costs. Pay the crumbs, out comes a potion nobody else can sell you.'
  ]);
}

/* ---------------- a HUD button, and a line in the journal ---------------- */
{
  const btns=document.querySelector('#hud .btns'), bb=document.createElement('button');
  bb.className='hb'; bb.id='bBrew'; bb.type='button'; bb.textContent='Brew (B)'; bb.hidden=true;
  bb.addEventListener('click',e=>{ e.currentTarget.blur(); if(g.mode==='play') openBrew(); });
  btns.insertBefore(bb,document.getElementById('bSnd'));
  const _upd=updateHud;
  updateHud=function(){
    _upd();
    const want=!!g.inv.recipebook;
    if(bb.hidden===want) bb.hidden=!want;
  };
  const _je=journalExtra;
  journalExtra=function(sec,line){
    _je(sec,line);
    if(!g.inv.recipebook) return;
    const s=BS(), n=Object.keys(s.made).length;
    sec('Brewing');
    line('Recipes brewed: '+n+' of '+BR_RECIPES.length+'   Potions made: '+Object.keys(s.made).reduce((a,k)=>a+s.made[k],0),'jdim');
  };
}
