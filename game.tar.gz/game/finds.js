'use strict';
/* ===== FINDS: every rare find, trail item, buried relic and treasure, with a drawn icon for each ===== */
/* [id, name, sell value, glyph, colours, description, flags]  flags: n = only after dark, d = only by day */
const WL_FINDLIST=[
 /* ---- rare finds, by biome ---- */
 ['r_goldacorn','Golden Acorn',16,'acorn',['#e0b84a','#a8802a','#f6dc82'],'An acorn in a shell of gold-coloured lacquer. Squirrels guard these jealously.','forest'],
 ['r_antler','Shed Antler',11,'antler',['#d9c9a8','#a8987a'],'Dropped, not taken. A deer will not miss it. Probably.','forest'],
 ['r_owlfeather','Barred Owl Feather',9,'feather',['#b8a07a','#6a5a40'],'Soft as a secret. It makes no sound at all when you wave it.','forest'],
 ['r_honeycomb','Honeycomb Chunk',10,'comb',['#f2b930','#c98a12'],'A hexagon-perfect chunk, abandoned. The bees have moved on to better things.','meadow'],
 ['r_bumblecharm','Bumblebee Charm',12,'bee',['#f6d02a','#2a2a2a'],'A tiny enamel bee on a thread. It looks busy even when it is not.','meadow'],
 ['r_rainbowbloom','Pressed Rainbow Bloom',20,'bloom',['#e86a92','#8ecae6','#f6d55c'],'A flower of every colour, pressed flat between two leaves. Nothing in the meadow admits to growing it.','meadow'],
 ['r_rainbowleaf','Rainbow Leaf',8,'leaf',['#e8602a','#f6d02a','#6aa03a'],'Green at the stem, gold in the middle, red at the tip. It could not decide.','autumn'],
 ['r_ambertear','Amber Tear',18,'drop',['#e8a020','#f6c84a','#fff0b0'],'A drop of old tree-sap gone hard and glassy. Something tiny sleeps inside it.','autumn'],
 ['r_syrup','Maple Syrup Vial',11,'vial',['#c9781a','#8a4a10','#f2d9a0'],'Someone tapped a tree and forgot a vial. Their loss, your pancakes.','autumn'],
 ['r_frozendew','Frozen Dewdrop',13,'drop',['#bfe6ff','#7ab4dc','#ffffff'],'A drop of dew that froze mid-fall and never thawed. It is cold to hold, and it rings when tapped.','tundra'],
 ['r_snowcrystal','Perfect Snowflake',16,'flake',['#e8f6ff','#9ad0f0'],'Six arms, every one exactly the same. It has been holding its shape for a very long time.','tundra'],
 ['r_mammothtooth','Mammoth Tooth',28,'tooth',['#e0d4b0','#b8a880'],'Enormous, ridged, and very much older than any duck.','tundra'],
 ['r_quartz','Quartz Cluster',14,'cluster',['#e6eaf4','#b8bece','#ffffff'],'Clear points grown together like a tiny city of glass.','highlands'],
 ['r_eaglefeather','Eagle Feather',13,'feather',['#7a5a3a','#f2ecd8'],'Long, broad, and brown with a white tip. It still smells of high wind.','highlands'],
 ['r_meteorite','Iron Meteorite Chip',30,'chunk',['#4a4a52','#7a7a86','#c4c4d0'],'Heavy for its size, and warm even in the cold. It fell from very far away.','highlands'],
 ['r_scarab','Scarab Amulet',22,'scarab',['#2a8a8a','#e0b84a','#1a5a5a'],'A turquoise beetle set in gold. Somebody wore it for luck. Nobody was ever sure it worked.','desert'],
 ['r_sungeode','Sun Geode',17,'halfgeode',['#b08a60','#f6d02a','#fff3b0'],'Crack it open and the inside is golden crystal. Somebody already did, so it is ready.','desert'],
 ['r_desertglass','Desert Glass',13,'shard',['#d9e8a0','#a8c860','#f4ffd0'],'Sand turned to glass by a very bad afternoon, a long time ago.','desert'],
 ['r_sandrose','Sand Rose',11,'bloom',['#d8b888','#b89860','#f0e0c0'],'Crystals grew in the sand and curled up like petals. A rose that never needed water.','desert'],
 ['r_jadeidol','Jade Jaguar Idol',32,'idol',['#4aa86a','#2a7a46','#8ae0a8'],'A small stern cat, carved from a single piece of green stone. It watches you back.','jungle'],
 ['r_orchidresin','Orchid Resin Drop',12,'drop',['#c46ae0','#8a3aa8','#f0c0ff'],'A bead of purple resin, sweet-smelling, still a little sticky after all this time.','jungle'],
 ['r_parrotfeather','Parrot Feather',9,'feather',['#e8402a','#2a6fe0'],'Red at the quill, blue at the tip. The parrot who owned it is still shouting about it somewhere.','jungle'],
 ['r_bogpearl','Bog Pearl',17,'orb',['#6a8a6a','#a8c8a8','#dff0df'],'Pale green and perfectly round. The swamp is quietly proud of this one.','swamp'],
 ['r_wisp','Wisp in a Jar',24,'vial',['#7affc8','#2a6a58','#d4fff0'],'A small bright something, bobbing in a jar. It does not seem to mind. It does not seem to mind anything.','swamp','n'],
 ['r_peatamber','Peat Amber',15,'drop',['#8a5a20','#c98a30','#f0c870'],'Dark, smoky amber from deep in the bog. It smells like rain on old leaves.','swamp'],
 ['r_bambooflute','Bamboo Flute',19,'flute',['#b8c84a','#6a7a2a'],'Six holes and a soft, sleepy voice. It plays one note perfectly.','bamboo'],
 ['r_luckyknot','Lucky Bamboo Knot',10,'knot',['#c0392b','#f6d02a'],'Red cord tied in a knot with no beginning and no end. Good luck is supposed to live in the middle.','bamboo'],
 ['r_teabrick','Pressed Tea Brick',8,'brick',['#5a3a22','#3a2412','#8a6a42'],'A hard brown brick of leaves. Shave a little off, add hot water, and wait for dusk.','bamboo'],
 ['r_everbloom','Everbloom Petal',18,'petal',['#f6a6c8','#fbd0e0','#ffffff'],'A cherry-blossom petal that has not wilted in a hundred springs.','cherry'],
 ['r_lanterncharm','Paper Lantern Charm',12,'lantern',['#e8402a','#f6d02a','#a82a1a'],'A tiny paper lantern, red as a berry, with a real wick no bigger than a whisker.','cherry'],
 ['r_hairpin','Blossom Hairpin',26,'pin',['#f2a6c3','#e0b84a','#ffffff'],'Silver, with a carved cherry flower on the end. Very fashionable. For ducks, probably.','cherry'],
 ['r_sporevial','Glowcap Spore Vial',14,'vial',['#b36bff','#4a2a8a','#e0c0ff'],'A vial of violet spores that drift and glitter when you are not looking directly at them.','glowcap'],
 ['r_moonstone','Moonstone Shard',24,'orb',['#cfe0ff','#8aa8e8','#ffffff'],'It only glows once the sun has gone. A pale ripple moves across it like a slow tide.','glowcap','n'],
 ['r_fairychalice','Fairy Chalice',21,'chalice',['#7affd0','#2a8a6a','#d4fff0'],'A cup carved from a glowing mushroom cap. It is not clear who it was made for. It is very small.','glowcap'],
 ['r_sachet','Lavender Sachet',8,'sachet',['#9a7ad8','#d8c8f0'],'A little cloth pouch of dried lavender. It smells like a nap.','lavender'],
 ['r_lavjar','Lavender Honey',11,'vial',['#d8a830','#8a5a18','#e0c0f0'],'Honey the colour of old sunshine, tasting faintly of purple.','lavender'],
 ['r_dreampillow','Dream Pillow',16,'pillow',['#b898f0','#7a5ad0','#ffffff'],'Stuffed with lavender and something else. Whatever it is, the dreams are better.','lavender'],
 ['r_seaglass','Sea Glass',9,'shard',['#7ad8c8','#3aa89a','#d4fff6'],'A bottle, a long time ago. The sea rubbed all the edges off.','shore'],
 ['r_pearl','Pearl',26,'orb',['#f4efe6','#cfc8c0','#ffffff'],'A perfect, creamy sphere. Someone is missing the oyster.','shore'],
 ['r_conch','Conch Shell',13,'shell',['#f2c0a0','#d98a68','#fff0e0'],'Hold it to your ear. It is still telling the same story about the sea.','shore'],
 ['r_bottle','Message in a Bottle',20,'bottle',['#6ac8b8','#f2e6c8','#c9a24a'],'Sealed with wax. Inside, a note in a language of waves. You cannot read it. It still feels important.','shore'],
 ['r_ostrich','Ostrich Egg Shard',12,'egg',['#f2e6c4','#c9b88a','#ffffff'],'A curved piece of very thick shell. Whoever laid it was not a duck.','savanna'],
 ['r_sunstone','Sunstone',19,'sun',['#f6a81a','#e0701a','#fff0a0'],'A stone that is warm in your wing like a held cup of tea. It cools at dusk.','savanna','d'],
 ['r_termitegem','Termite Gem',15,'cutgem',['#e0702a','#a8441a','#ffd0a0'],'A glassy orange stone a very busy colony tunneled right past. They did not notice. They were busy.','savanna'],
 /* ---- finds from anywhere ---- */
 ['g_penny','Lucky Penny',6,'coin',['#c98a4a','#8a5a2a'],'Face up. Of course it was face up.','any'],
 ['g_button','Mystery Button',5,'button',['#6a8ad8','#2a3a8a'],'It is from a coat somebody loved. Nobody knows whose.','any'],
 ['g_marble','Glass Marble',6,'orb',['#6ac8e8','#2a8ab8','#e0f6ff'],'A swirl of blue in clear glass. Somebody is still looking for it.','any'],
 ['g_bell','Tiny Silver Bell',9,'bell',['#d8dce6','#9aa0ae'],'It rings so softly you wonder if you made it up.','any'],
 ['g_waxseal','Broken Wax Seal',8,'coin',['#c0392b','#8a1a1a'],'Pressed with a tiny feather. Somebody opened a very private letter.','any'],
 ['g_goldfeather','Golden Feather',30,'feather',['#f6d02a','#c98a12'],'A feather made of nothing you can name. It makes your own feathers look duller.','any'],
 /* ---- trail items ---- */
 ['t_mitten','Lost Mitten',3,'mitten',['#e0402e','#ffffff'],'One left mitten, tiny, hand-knitted. Its partner is out there, probably cold.','trail'],
 ['t_token','Trail Marker Token',4,'coin',['#8a7a5a','#c9b88a'],'A wooden token the trail walkers swap, stamped with a boot.','trail'],
 ['t_whistle','Hiker\'s Whistle',5,'whistle',['#c9a24a','#8a6a2a'],'Three short blasts means help. One long one means lunch.','trail'],
 ['t_postcard','Faded Postcard',4,'card',['#e8d9b5','#c0392b'],'A view of a lake, signed "Wish you were here, but you are not, and that is fine."','trail'],
 ['t_needle','Compass Needle',6,'needle',['#c0392b','#d8dce6'],'The needle part of a compass. The rest got lost. It points at you.','trail'],
 ['t_stick','Carved Walking Stick',7,'stick',['#8a5a2b','#c9a06a'],'A knobbly staff with a bird carved on top. It has done a lot of miles.','trail'],
 ['t_button','Brass Button',3,'button',['#e0b84a','#a8802a'],'It bears an anchor. It has never seen the sea.','trail'],
 ['t_cup','Tin Cup',4,'cup',['#b8bec8','#7a808c'],'Dented, and a little proud of it.','trail'],
 ['t_bookmark','Pressed Leaf Bookmark',4,'bookmark',['#6aa03a','#c9a06a'],'A leaf, a ribbon, and a page number nobody remembers.','trail'],
 ['t_lace','Bootlace',2,'lace',['#e8d9b5','#8a7a5a'],'Long, tough, and surprisingly tangled for something so thin.','trail'],
 ['t_duck','Whittled Duck',7,'duckfig',['#c9a06a','#8a5a2b'],'A tiny carved duck, a little lopsided. It is perfect.','trail'],
 ['t_shoe','Rusty Horseshoe',5,'shoe',['#8a6a5a','#5a4034'],'Good luck, if you hang it the right way up. Nobody agrees which way that is.','trail'],
 /* ---- relics from the dig spots ---- */
 ['d_trilobite','Trilobite Fossil',18,'fossil',['#8a7a68','#5a4a3a'],'A ribbed armoured thing, left in stone before ducks were a notion.','dig'],
 ['d_ammonite','Ammonite Fossil',22,'spiral',['#a8987a','#6a5a40'],'A perfect stone spiral. It looks a little bit like a snail, if a snail was a hundred million years old.','dig'],
 ['d_shard','Painted Clay Shard',10,'shard',['#c9703a','#f6d02a','#8a3a1a'],'A piece of old pottery. The painted pattern is a row of tiny ducks, marching.','dig'],
 ['d_spear','Stone Spearhead',16,'spear',['#7a7a86','#a8a8b4'],'Chipped flint, sharp as a good argument.','dig'],
 ['d_idol','Clay Duck Idol',20,'idol',['#c9803a','#8a5a2a','#f0c090'],'A tiny ancient duck, with big eyes and a very serious expression.','dig'],
 ['d_jug','Ceramic Jug',14,'jug',['#c9803a','#8a5a2a'],'Still has a stopper. Somebody saved a lot of nothing for a very long time.','dig'],
 ['d_claw','Giant Claw',26,'claw',['#e0d4b0','#a89878'],'Longer than your whole wing. You decide not to think about who it belonged to.','dig'],
 ['d_coinold','Ancient Coin',12,'coin',['#c9a24a','#8a6a2a'],'Stamped with a face you do not recognise, and a duck you somehow do.','dig'],
 /* ---- buried treasure ---- */
 ['tr_doubloon','Gold Doubloon',30,'coin',['#f6d02a','#c98a12'],'Heavy and warm and definitely not made by anyone honest.','treasure'],
 ['tr_ingot','Silver Ingot',34,'ingot',['#d8dce6','#9aa0ae'],'A bar of dull silver, stamped with a crown.','treasure'],
 ['tr_ruby','Ruby',46,'cutgem',['#e0243a','#8a0a1a','#ff9aa8'],'Red as a good argument at a very good party.','treasure'],
 ['tr_sapphire','Sapphire',42,'cutgem',['#2a5ae0','#0a2a8a','#9ab8ff'],'Deep blue, like the middle of the lake at night.','treasure'],
 ['tr_emerald','Emerald',44,'cutgem',['#2ac870','#0a7a3a','#a0ffd0'],'Green enough to make the forest jealous.','treasure'],
 ['tr_goblet','Jeweled Goblet',60,'chalice',['#f6d02a','#c98a12','#e0243a'],'A golden cup with a ruby in it. Somebody important drank something important from it.','treasure'],
 ['tr_crown','Tiny Gold Crown',80,'crown',['#f6d02a','#c98a12','#e0243a'],'Made for a very small, very important head. It fits you perfectly.','treasure']
];
const WL_FIND={}, WL_FINDS_BY={forest:[],meadow:[],autumn:[],tundra:[],highlands:[],desert:[],jungle:[],swamp:[],bamboo:[],cherry:[],glowcap:[],lavender:[],shore:[],savanna:[],any:[],trail:[],dig:[],treasure:[]};
const WL_QUIPS=['You turn it over twice. It is better than it looks.','You hold it up to the light and feel very much like a detective.','You tuck it into your feathers for safe keeping.','Somebody, somewhere, is missing this. Not for long.','You give it a little polish with your wing.'];
for(const f of WL_FINDLIST){
  const it=ITEMS[f[0]]={name:f[1],sell:f[2],desc:f[5],use:'note',note:WL_QUIPS[(f[0].length*7+f[2])%WL_QUIPS.length],nogift:true,glyph:f[3],gc:f[4],cat:'find',src:f[6],night:f[7]==='n',day:f[7]==='d'};
  it.rar=f[2]<8?1:f[2]<15?2:f[2]<27?3:4;
  WL_FIND[f[0]]=it; WL_FINDS_BY[f[6]].push(f[0]);
}
/* trail mix is a snack as well as a find */
Object.assign(ITEMS.t_mix={},{name:'Trail Mix Bag',sell:3,desc:'Seeds, a raisin, a lonely peanut. Somebody left it for the next duck to come along.',use:'eat',boost:35,quip:'Crunchy, sweet and slightly salty. You feel ready for another mile.',nogift:true,glyph:'bag',gc:['#c9a06a','#8a5a2b'],cat:'find',src:'trail',rar:1});
WL_FIND.t_mix=ITEMS.t_mix; WL_FINDS_BY.trail.push('t_mix');
const WL_TRAIL=WL_FINDS_BY.trail.slice(), WL_DIG=WL_FINDS_BY.dig.slice(), WL_TREAS=WL_FINDS_BY.treasure.slice(), WL_ANY=WL_FINDS_BY.any.slice();

/* the three things you can buy */
ITEMS.shovel={name:'Sturdy Shovel',price:20,desc:'A short-handled spade, just the right size for a duck. Face the ground and press D to dig. Opens glinting dig spots, buried treasure and daily cases.',use:'note',note:'You plant it in the ground and lean on it. It looks like you know what you are doing.',nogift:true,glyph:'shovel',gc:['#8a5a2b','#b8bec8'],cat:'tool'};
ITEMS.tmap={name:'Treasure Map',price:10,desc:'Unmarked, unsigned and unpredictable. Unfold one and a treasure appears on your explorer\'s map, somewhere out in the wild. Dig it up with a shovel.',use:'tmap',nogift:true,glyph:'tmap',gc:['#e8d3a0','#c0392b','#7a5a2a'],cat:'tool'};
ITEMS.clog={name:'Collection Log',price:14,desc:'A leather-bound log with a page for every plant, find and place in the wild world. Press L, or open it from your pack. It fills in as you find things and shows what you have collected, with your progress for each rarity.',use:'clog',nogift:true,glyph:'clog',gc:['#2f6f4f','#f4efe0','#c9a24a'],cat:'tool'};
ITEMS.axe={name:'Woodcutter Axe',price:26,desc:'A small, sharp axe. Needed to cut down trees and chop up stumps and logs so you can collect them. A collected plant is gone for good.',use:'note',note:'You swing it once, for practice. A branch falls on your head.',nogift:true,glyph:'axe',gc:['#8a6238','#c3cad2','#eef2f6']};
ITEMS.pickaxe={name:'Stone Pickaxe',price:30,desc:'Heavy, a bit too big for a duck. Needed to break up rocks and boulders so you can collect them. A collected rock is gone for good.',use:'note',note:'You tap a rock. The rock stays. You are told to keep practising.',nogift:true,glyph:'pickaxe',gc:['#8a6238','#9aa3ad','#d3dae0']};
STOCK.supply.push('axe','pickaxe'); STOCK.market.push('axe','pickaxe');
STOCK.supply.push('shovel','clog'); STOCK.market.push('shovel','clog'); STOCK.toys.push('shovel'); STOCK.florist.push('shovel');
STOCK.curio.push('tmap','clog'); STOCK.books.push('tmap','clog'); STOCK.cafe.push('tmap'); STOCK.tailor.push('tmap');

/* ---------- glyphs (16-unit icons) ---------- */
const WL_G={
 acorn:(c,k)=>{ ell(c,8,10,4.5,5,k[0]); ell(c,8,6,5.6,3.2,k[1]); rect(c,7,2,2,3,k[1]); rect(c,6,8,1,3,k[2]); },
 antler:(c,k)=>{ c.lineCap='round'; wlLine(c,5,14,6,6,2.6,k[0]); wlLine(c,6,9,2.5,4,1.8,k[0]); wlLine(c,6,7,9,3,1.8,k[0]); wlLine(c,6,5,5,1.5,1.6,k[0]); wlLine(c,10,14,11,8,2,k[1]); wlLine(c,11,10,14,6,1.6,k[1]); c.lineCap='butt'; },
 feather:(c,k)=>{ c.fillStyle=k[0]; c.beginPath(); c.moveTo(3,14); c.quadraticCurveTo(3,4,13,2); c.quadraticCurveTo(12,11,3,14); c.fill(); c.strokeStyle=k[1]; c.lineWidth=1; c.beginPath(); c.moveTo(3,14); c.quadraticCurveTo(8,8,13,2); c.stroke(); rect(c,6,8,2,1,k[1]); rect(c,8,5,2,1,k[1]); },
 comb:(c,k)=>{ for(const p of [[5,5],[10,5],[7.5,9],[12.5,9],[2.5,9],[5,13],[10,13]]){ c.fillStyle=k[0]; c.beginPath(); for(let i=0;i<6;i++){ const a=i*1.047+0.52; c.lineTo(p[0]+Math.cos(a)*3,p[1]+Math.sin(a)*3); } c.closePath(); c.fill(); c.strokeStyle=k[1]; c.lineWidth=0.8; c.stroke(); } },
 bee:(c,k)=>{ ell(c,8,9,4.5,3.4,k[0]); rect(c,6,6,1.4,6,k[1]); rect(c,9.2,6,1.4,6,k[1]); ell(c,6,5,3,1.6,'rgba(210,235,255,0.85)'); ell(c,10,5,3,1.6,'rgba(210,235,255,0.85)'); circ(c,12.3,9,1.4,k[1]); },
 bloom:(c,k)=>{ for(let i=0;i<6;i++){ const a=i*1.047; circ(c,8+Math.cos(a)*3.5,7+Math.sin(a)*3.5,2.3,k[i%k.length]); } circ(c,8,7,1.9,'#fff3b0'); rect(c,7.5,10,1,5,'#2f6b34'); },
 leaf:(c,k)=>{ c.fillStyle=k[0]; c.beginPath(); c.moveTo(2,14); c.quadraticCurveTo(1,3,14,2); c.quadraticCurveTo(15,13,2,14); c.fill(); c.fillStyle=k[1]; c.beginPath(); c.moveTo(5,11); c.quadraticCurveTo(5,6,10,5); c.quadraticCurveTo(10,10,5,11); c.fill(); c.fillStyle=k[2]; c.beginPath(); c.moveTo(2,14); c.quadraticCurveTo(2,10,5,10); c.quadraticCurveTo(5,13,2,14); c.fill(); },
 drop:(c,k)=>{ c.fillStyle=k[0]; c.beginPath(); c.moveTo(8,1.5); c.quadraticCurveTo(14,8,11.5,12); c.quadraticCurveTo(8,15.5,4.5,12); c.quadraticCurveTo(2,8,8,1.5); c.fill(); ell(c,7,10,2.2,3.2,k[1]); rect(c,6,5,1,3,k[2]); },
 vial:(c,k)=>{ rect(c,6,2,4,2,'#8a5a2b'); rect(c,6.5,4,3,2,'#d8e6ee'); rect(c,4,6,8,8,'rgba(215,235,245,0.85)'); rect(c,4.8,8,6.4,5.4,k[0]); rect(c,5.5,8.6,1.4,3,k[2]); rect(c,4,6,1,8,'rgba(255,255,255,0.5)'); circ(c,9,10,0.9,k[2]); },
 flake:(c,k)=>{ c.strokeStyle=k[0]; c.lineWidth=1.3; c.lineCap='round'; for(let i=0;i<3;i++){ const a=i*1.047; c.beginPath(); c.moveTo(8+Math.cos(a)*6.5,8+Math.sin(a)*6.5); c.lineTo(8-Math.cos(a)*6.5,8-Math.sin(a)*6.5); c.stroke(); } c.strokeStyle=k[1]; c.lineWidth=1; for(let i=0;i<6;i++){ const a=i*1.047; const bx=8+Math.cos(a)*4, by=8+Math.sin(a)*4; c.beginPath(); c.moveTo(bx+Math.cos(a+1)*1.8,by+Math.sin(a+1)*1.8); c.lineTo(bx,by); c.lineTo(bx+Math.cos(a-1)*1.8,by+Math.sin(a-1)*1.8); c.stroke(); } c.lineCap='butt'; },
 tooth:(c,k)=>{ c.fillStyle=k[0]; c.beginPath(); c.moveTo(3,2); c.quadraticCurveTo(13,3,13,14); c.quadraticCurveTo(10,9,7,7); c.quadraticCurveTo(5,5,3,2); c.fill(); c.strokeStyle=k[1]; c.lineWidth=0.9; c.beginPath(); c.moveTo(5,3); c.quadraticCurveTo(11,5,12,12); c.stroke(); },
 cluster:(c,k)=>{ wlTri(c,8,1.5,11,13,5,13,k[0]); wlTri(c,8,1.5,11,13,8,13,k[1]); wlTri(c,3.5,6,6.5,13,0.5,13,k[0]); wlTri(c,3.5,6,6.5,13,3.5,13,k[1]); wlTri(c,12.5,5,15.5,13,9.5,13,k[0]); wlTri(c,12.5,5,15.5,13,12.5,13,k[1]); rect(c,7,4,1,4,k[2]); },
 chunk:(c,k)=>{ c.fillStyle=k[0]; c.beginPath(); c.moveTo(2,10); c.lineTo(5,4); c.lineTo(11,3); c.lineTo(14,8); c.lineTo(12,13); c.lineTo(5,13); c.closePath(); c.fill(); c.fillStyle=k[1]; c.beginPath(); c.moveTo(5,4); c.lineTo(11,3); c.lineTo(10,7); c.lineTo(5,8); c.closePath(); c.fill(); rect(c,6,5,2,1,k[2]); rect(c,9,10,2,1,k[1]); },
 scarab:(c,k)=>{ circ(c,8,8,7,k[1]); circ(c,8,8,5.6,k[0]); ell(c,8,9,3.3,4,k[2]); rect(c,7.6,5,0.8,8,k[1]); circ(c,8,4.8,1.7,k[2]); rect(c,4,7,2,1,k[1]); rect(c,10,7,2,1,k[1]); rect(c,4,10,2,1,k[1]); rect(c,10,10,2,1,k[1]); },
 halfgeode:(c,k)=>{ circ(c,8,8,7,k[0]); circ(c,8,8,5.2,'#6a4a2a'); circ(c,8,8,4.4,k[1]); circ(c,8,8,2.6,k[2]); rect(c,6,5,1,1,'#fff'); },
 shard:(c,k)=>{ c.fillStyle=k[0]; c.beginPath(); c.moveTo(3,6); c.lineTo(8,2); c.lineTo(14,6); c.lineTo(12,13); c.lineTo(5,14); c.closePath(); c.fill(); c.fillStyle=k[1]; c.beginPath(); c.moveTo(8,2); c.lineTo(14,6); c.lineTo(12,13); c.lineTo(9,8); c.closePath(); c.fill(); rect(c,5,6,2,1,k[2]||'#fff'); rect(c,6,9,1,2,k[2]||'#fff'); },
 idol:(c,k)=>{ rect(c,4,12,8,2,k[1]); rect(c,5,5,6,8,k[0]); circ(c,8,4.5,3.2,k[0]); rect(c,5.5,5,1.4,1.4,'#fff'); rect(c,9,5,1.4,1.4,'#fff'); rect(c,6,3,4,1,k[2]); rect(c,6.5,9,3,1,k[1]); wlTri(c,5,5,3,8,5,8,k[0]); wlTri(c,11,5,13,8,11,8,k[0]); },
 orb:(c,k)=>{ circ(c,8,8,6,k[0]); circ(c,8,8,4.8,k[1]); ell(c,6.2,5.8,2.2,1.6,k[2]); circ(c,10,10,1.2,k[2]); },
 shell:(c,k)=>{ c.fillStyle=k[0]; c.beginPath(); c.moveTo(2,12); c.quadraticCurveTo(2,3,10,3); c.quadraticCurveTo(15,3,14,9); c.quadraticCurveTo(13,14,6,14); c.closePath(); c.fill(); c.strokeStyle=k[1]; c.lineWidth=1; for(let i=0;i<4;i++){ c.beginPath(); c.arc(9,8,2+i*1.6,1.2,4.2); c.stroke(); } ell(c,11,6,2.5,1.6,k[2]); },
 bottle:(c,k)=>{ rect(c,6,1.5,4,2,'#8a5a2b'); rect(c,6.5,3.5,3,3,k[0]); rect(c,4.5,6,7,8,k[0]); rect(c,5.5,7.5,5,5,k[1]); rect(c,6,8.5,4,1,k[2]); rect(c,6,10.5,3,1,k[2]); rect(c,4.5,6,1,8,'rgba(255,255,255,0.35)'); },
 flute:(c,k)=>{ c.save(); c.translate(8,8); c.rotate(-0.6); rect(c,-7,-1.6,14,3.2,k[0]); rect(c,-7,-1.6,14,1,'rgba(255,255,255,0.3)'); for(let i=0;i<5;i++) rect(c,-4+i*2.2,-0.3,1,1.2,k[1]); rect(c,-7,-1.6,1.2,3.2,k[1]); rect(c,2,-1.6,0.8,3.2,k[1]); c.restore(); },
 knot:(c,k)=>{ c.lineWidth=1.8; c.strokeStyle=k[0]; c.beginPath(); c.arc(6,6,3.4,0,6.3); c.stroke(); c.beginPath(); c.arc(10,6,3.4,0,6.3); c.stroke(); c.beginPath(); c.arc(8,10,3.4,0,6.3); c.stroke(); rect(c,7,1,2,2,k[1]); c.lineWidth=1.2; c.beginPath(); c.moveTo(8,13); c.lineTo(6,15.5); c.moveTo(8,13); c.lineTo(10,15.5); c.stroke(); },
 brick:(c,k)=>{ rect(c,2,5,12,7,k[0]); rect(c,2,5,12,1.5,k[2]); rect(c,2,10.5,12,1.5,k[1]); rect(c,4,7,3,1,k[1]); rect(c,8,8,4,1,k[1]); rect(c,6,3.5,4,1.5,k[2]); },
 petal:(c,k)=>{ c.fillStyle=k[0]; c.beginPath(); c.moveTo(8,14); c.quadraticCurveTo(0,8,4,2); c.lineTo(8,4); c.lineTo(12,2); c.quadraticCurveTo(16,8,8,14); c.fill(); c.fillStyle=k[1]; c.beginPath(); c.moveTo(8,13); c.quadraticCurveTo(4,8,6,4); c.lineTo(8,5); c.quadraticCurveTo(10,8,8,13); c.fill(); rect(c,7,4,1,3,k[2]); },
 lantern:(c,k)=>{ rect(c,7,1,2,2,'#4a3a2a'); ell(c,8,8,5,6,k[0]); ell(c,8,8,3,5,k[1]); rect(c,4,6,8,1,k[2]); rect(c,4,10,8,1,k[2]); rect(c,6,14,4,1.5,'#4a3a2a'); },
 pin:(c,k)=>{ c.lineCap='round'; wlLine(c,3,14,11,5,1.6,k[1]); c.lineCap='butt'; for(let i=0;i<5;i++){ const a=i*1.256; circ(c,12+Math.cos(a)*2.2,4+Math.sin(a)*2.2,1.7,k[0]); } circ(c,12,4,1.3,'#f6d02a'); },
 chalice:(c,k)=>{ c.fillStyle=k[0]; c.beginPath(); c.moveTo(3,3); c.lineTo(13,3); c.quadraticCurveTo(13,9,8,9.5); c.quadraticCurveTo(3,9,3,3); c.fill(); rect(c,7,9,2,3,k[1]); rect(c,4.5,12,7,2,k[0]); rect(c,4.5,13,7,1,k[1]); circ(c,8,5.5,1.6,k[2]); rect(c,4,4,1,2,'rgba(255,255,255,0.4)'); },
 sachet:(c,k)=>{ c.fillStyle=k[0]; c.beginPath(); c.moveTo(4,6); c.quadraticCurveTo(1,13,4,14); c.lineTo(12,14); c.quadraticCurveTo(15,13,12,6); c.closePath(); c.fill(); rect(c,5,5,6,2,k[1]); rect(c,4,6,8,1,'#c9a24a'); rect(c,6,2.5,1,2.5,'#c9a24a'); rect(c,9,2.5,1,2.5,'#c9a24a'); rect(c,6,9,1,1,k[1]); rect(c,9,11,1,1,k[1]); },
 pillow:(c,k)=>{ c.fillStyle=k[0]; c.beginPath(); c.moveTo(2,5); c.quadraticCurveTo(8,2,14,5); c.quadraticCurveTo(15.5,8,14,11); c.quadraticCurveTo(8,14,2,11); c.quadraticCurveTo(0.5,8,2,5); c.fill(); c.strokeStyle=k[1]; c.lineWidth=0.9; c.beginPath(); c.moveTo(4,8); c.quadraticCurveTo(8,5.5,12,8); c.stroke(); circ(c,8,8,1.4,k[2]); },
 egg:(c,k)=>{ c.fillStyle=k[0]; c.beginPath(); c.moveTo(2,10); c.quadraticCurveTo(2,3,8,2); c.quadraticCurveTo(14,3,14,10); c.lineTo(12,13); c.lineTo(9,11); c.lineTo(6,14); c.lineTo(4,12); c.closePath(); c.fill(); rect(c,5,5,1,1,k[1]); rect(c,9,6,1,1,k[1]); rect(c,7,9,1,1,k[1]); rect(c,10,9,1,1,k[1]); rect(c,5,8,2,1,k[2]); },
 sun:(c,k)=>{ c.strokeStyle=k[1]; c.lineWidth=1.3; c.lineCap='round'; for(let i=0;i<8;i++){ const a=i*0.785; c.beginPath(); c.moveTo(8+Math.cos(a)*5.5,8+Math.sin(a)*5.5); c.lineTo(8+Math.cos(a)*7.5,8+Math.sin(a)*7.5); c.stroke(); } c.lineCap='butt'; circ(c,8,8,5,k[0]); circ(c,8,8,3.4,k[2]); },
 cutgem:(c,k)=>{ c.fillStyle=k[0]; c.beginPath(); c.moveTo(4,3); c.lineTo(12,3); c.lineTo(15,7); c.lineTo(8,14); c.lineTo(1,7); c.closePath(); c.fill(); c.fillStyle=k[1]; c.beginPath(); c.moveTo(1,7); c.lineTo(15,7); c.lineTo(8,14); c.closePath(); c.fill(); c.fillStyle=k[2]; c.beginPath(); c.moveTo(4,3); c.lineTo(6.5,7); c.lineTo(3,7); c.closePath(); c.fill(); rect(c,7,4,1.4,1,k[2]); },
 coin:(c,k)=>{ circ(c,8,8,6.6,k[1]); circ(c,8,8,5.6,k[0]); circ(c,8,8,3.6,k[1]); circ(c,8,8,3,k[0]); rect(c,6,4,2,1,'rgba(255,255,255,0.55)'); rect(c,7.4,6.4,1.4,3.4,k[1]); },
 button:(c,k)=>{ circ(c,8,8,6,k[1]); circ(c,8,8,5,k[0]); circ(c,6.4,6.4,0.9,k[1]); circ(c,9.6,6.4,0.9,k[1]); circ(c,6.4,9.6,0.9,k[1]); circ(c,9.6,9.6,0.9,k[1]); rect(c,5,4,2,1,'rgba(255,255,255,0.5)'); },
 bell:(c,k)=>{ c.fillStyle=k[0]; c.beginPath(); c.moveTo(3,12); c.quadraticCurveTo(3,3,8,3); c.quadraticCurveTo(13,3,13,12); c.closePath(); c.fill(); rect(c,2,12,12,1.6,k[1]); circ(c,8,14,1.4,k[1]); rect(c,7,1.5,2,2,k[1]); rect(c,5,5,1,4,'rgba(255,255,255,0.45)'); },
 mitten:(c,k)=>{ c.fillStyle=k[0]; c.beginPath(); c.moveTo(4,14); c.lineTo(4,6); c.quadraticCurveTo(4,2,8,2); c.quadraticCurveTo(12,2,12,6); c.lineTo(12,14); c.closePath(); c.fill(); ell(c,12.5,8,2,2.6,k[0]); rect(c,4,12,8,2,k[1]); rect(c,6,5,1,1,k[1]); rect(c,9,6,1,1,k[1]); rect(c,7,8,1,1,k[1]); },
 whistle:(c,k)=>{ rect(c,3,6,9,5,k[0]); rect(c,3,6,9,1.4,'rgba(255,255,255,0.35)'); rect(c,10,7,4,3,k[0]); circ(c,13,5,2.4,'rgba(0,0,0,0)'); c.strokeStyle=k[1]; c.lineWidth=1.2; c.beginPath(); c.arc(13,4,2.2,0,6.3); c.stroke(); rect(c,5,8,3,1.2,k[1]); },
 card:(c,k)=>{ rect(c,2,3,12,10,k[0]); rect(c,2,3,12,1,'rgba(0,0,0,0.15)'); rect(c,3,5,5,4,'#8ab8d8'); rect(c,3,8,5,1,'#4f8f45'); rect(c,9,4,4,3,k[1]); rect(c,9,9,4,1,'#8a7a5a'); rect(c,9,11,3,1,'#8a7a5a'); },
 needle:(c,k)=>{ circ(c,8,8,6,'#e8d9b5'); c.fillStyle=k[0]; c.beginPath(); c.moveTo(8,2.5); c.lineTo(9.6,8); c.lineTo(6.4,8); c.fill(); c.fillStyle=k[1]; c.beginPath(); c.moveTo(8,13.5); c.lineTo(9.6,8); c.lineTo(6.4,8); c.fill(); circ(c,8,8,1,'#333'); },
 stick:(c,k)=>{ c.lineCap='round'; wlLine(c,3,14,12,3,2.6,k[0]); wlLine(c,3,14,12,3,0.9,k[1]); c.lineCap='butt'; ell(c,12.5,3,2.2,2.2,k[1]); circ(c,13.2,2.6,0.6,'#222'); rect(c,6,9,3,1,k[1]); },
 bag:(c,k)=>{ c.fillStyle=k[0]; c.beginPath(); c.moveTo(4,5); c.quadraticCurveTo(1,13,4,14); c.lineTo(12,14); c.quadraticCurveTo(15,13,12,5); c.closePath(); c.fill(); rect(c,4,4,8,2,k[1]); rect(c,6.5,2,1,2.5,k[1]); rect(c,9,2,1,2.5,k[1]); circ(c,6,10,1,k[1]); circ(c,9,9,1,'#e0402e'); circ(c,10,11.5,1,'#f6d02a'); },
 cup:(c,k)=>{ c.fillStyle=k[0]; c.beginPath(); c.moveTo(3,4); c.lineTo(11,4); c.lineTo(10,13); c.lineTo(4,13); c.closePath(); c.fill(); rect(c,3,4,8,1.4,k[1]); c.strokeStyle=k[1]; c.lineWidth=1.4; c.beginPath(); c.arc(12,8,2.2,-1.5,1.5); c.stroke(); rect(c,5,6,1,5,'rgba(255,255,255,0.4)'); },
 bookmark:(c,k)=>{ rect(c,3,2,8,12,'#f4efe0'); rect(c,6,2,2,13,'#c0392b'); c.fillStyle=k[0]; c.beginPath(); c.moveTo(11,6); c.quadraticCurveTo(14,6,14,9); c.quadraticCurveTo(11,10,11,6); c.fill(); rect(c,4,5,2,1,'#8a7a5a'); rect(c,4,8,2,1,'#8a7a5a'); },
 lace:(c,k)=>{ c.strokeStyle=k[0]; c.lineWidth=1.6; c.beginPath(); c.moveTo(2,12); c.quadraticCurveTo(5,2,8,8); c.quadraticCurveTo(11,13,14,4); c.stroke(); rect(c,1,11.5,2,3,k[1]); rect(c,13,2.5,2,3,k[1]); },
 duckfig:(c,k)=>{ ell(c,8,11,5.5,3.4,k[0]); circ(c,10.5,6.2,3,k[0]); rect(c,12.5,6,3,1.6,k[1]); circ(c,11.2,5.4,0.6,'#222'); rect(c,4,10,6,1,k[1]); rect(c,5,13,6,1.4,k[1]); },
 shoe:(c,k)=>{ c.strokeStyle=k[0]; c.lineWidth=3; c.beginPath(); c.arc(8,8,4.5,2.5,6.9); c.stroke(); rect(c,2.6,8,2.6,5,k[0]); rect(c,10.8,8,2.6,5,k[0]); circ(c,4,10,0.7,k[1]); circ(c,12,10,0.7,k[1]); circ(c,5,6.2,0.7,k[1]); circ(c,11,6.2,0.7,k[1]); },
 fossil:(c,k)=>{ ell(c,8,8,6.5,5,k[0]); for(let i=0;i<5;i++) rect(c,4+i*2,4.5+Math.abs(i-2)*0.4,1,7-Math.abs(i-2)*0.8,k[1]); rect(c,7.5,3,1,10,k[1]); ell(c,8,8,6.5,5,'rgba(255,255,255,0.08)'); },
 spiral:(c,k)=>{ circ(c,8,8,6.5,k[0]); c.strokeStyle=k[1]; c.lineWidth=1.3; c.beginPath(); for(let a=0;a<12.5;a+=0.2){ const r=0.5+a*0.46; const x=8+Math.cos(a)*r, y=8+Math.sin(a)*r; if(a===0) c.moveTo(x,y); else c.lineTo(x,y); } c.stroke(); },
 spear:(c,k)=>{ c.fillStyle=k[0]; c.beginPath(); c.moveTo(8,1); c.quadraticCurveTo(14,6,10,11); c.lineTo(8,10); c.lineTo(6,11); c.quadraticCurveTo(2,6,8,1); c.fill(); c.fillStyle=k[1]; c.beginPath(); c.moveTo(8,1); c.quadraticCurveTo(11,6,8,10); c.closePath(); c.fill(); rect(c,7,10,2,5,'#8a5a2b'); },
 jug:(c,k)=>{ rect(c,6,1.5,4,2.4,k[1]); c.fillStyle=k[0]; c.beginPath(); c.moveTo(6,4); c.quadraticCurveTo(1,8,4,13); c.lineTo(12,13); c.quadraticCurveTo(15,8,10,4); c.closePath(); c.fill(); c.strokeStyle=k[1]; c.lineWidth=1.4; c.beginPath(); c.arc(13,7,2.2,-1.5,1.5); c.stroke(); rect(c,5,7,6,1,k[1]); rect(c,5,10,6,1,k[1]); },
 claw:(c,k)=>{ c.fillStyle=k[0]; c.beginPath(); c.moveTo(3,2); c.quadraticCurveTo(14,2,13,15); c.quadraticCurveTo(10,8,3,6); c.closePath(); c.fill(); c.strokeStyle=k[1]; c.lineWidth=1; c.beginPath(); c.moveTo(4,4); c.quadraticCurveTo(11,5,12.5,12); c.stroke(); },
 ingot:(c,k)=>{ c.fillStyle=k[1]; c.beginPath(); c.moveTo(1.5,13); c.lineTo(4,6); c.lineTo(12,6); c.lineTo(14.5,13); c.closePath(); c.fill(); c.fillStyle=k[0]; c.beginPath(); c.moveTo(4,6); c.lineTo(12,6); c.lineTo(11,9); c.lineTo(5,9); c.closePath(); c.fill(); rect(c,6,10,4,1,k[0]); },
 crown:(c,k)=>{ c.fillStyle=k[0]; c.beginPath(); c.moveTo(2,13); c.lineTo(1.5,5); c.lineTo(5.5,9); c.lineTo(8,3); c.lineTo(10.5,9); c.lineTo(14.5,5); c.lineTo(14,13); c.closePath(); c.fill(); rect(c,2,11,12,2,k[1]); circ(c,8,8.5,1.4,k[2]); circ(c,4.5,9.4,0.9,k[2]); circ(c,11.5,9.4,0.9,k[2]); },
 axe:(c,k)=>{ c.lineCap='round'; wlLine(c,4,14,11,4,2,k[0]); c.lineCap='butt'; c.fillStyle=k[1]; c.beginPath(); c.moveTo(8,3); c.lineTo(14,2); c.quadraticCurveTo(15,6,12,9); c.lineTo(9,7); c.closePath(); c.fill(); rect(c,11,3,1,4,k[2]); },
 pickaxe:(c,k)=>{ c.lineCap='round'; wlLine(c,4,14,11,5,2,k[0]); c.strokeStyle=k[1]; c.lineWidth=2.2; c.beginPath(); c.moveTo(3,6); c.quadraticCurveTo(8,0,14,6); c.stroke(); rect(c,6,2.5,2,1,k[2]); c.lineCap='butt'; },
 shovel:(c,k)=>{ c.lineCap='round'; wlLine(c,12,2,6.5,9,2,k[0]); c.lineCap='butt'; rect(c,10.5,1,4,1.6,k[0]); c.fillStyle=k[1]; c.beginPath(); c.moveTo(6,8); c.lineTo(9,9.5); c.lineTo(8,14.5); c.quadraticCurveTo(5,15,3,12); c.closePath(); c.fill(); rect(c,5,10,1,2,'rgba(255,255,255,0.4)'); },
 tmap:(c,k)=>{ rect(c,2,3,12,10,k[0]); rect(c,2,3,12,1,'rgba(0,0,0,0.12)'); rect(c,6,3,1,10,'#c9b27a'); rect(c,10,3,1,10,'#c9b27a'); wlLine(c,3,11,6,8,1,k[2]); wlLine(c,6,8,9,10,1,k[2]); wlLine(c,9,10,12,6,1,k[2]); wlLine(c,10.5,4.8,13,7.3,1.6,k[1]); wlLine(c,13,4.8,10.5,7.3,1.6,k[1]); },
 clog:(c,k)=>{ rect(c,3,2,10,12,k[0]); rect(c,3,2,2,12,'rgba(0,0,0,0.28)'); rect(c,5.5,4,6,8,k[1]); c.fillStyle='#4f8f45'; c.beginPath(); c.moveTo(7,11); c.quadraticCurveTo(6,6,10,5); c.quadraticCurveTo(11,9,7,11); c.fill(); rect(c,9,3,1,2,k[2]); rect(c,3,13,10,1,k[2]); }
};
{
  const _drawIcon3=drawIcon;
  drawIcon=function(c,id,s){
    const it=ITEMS[id];
    if(it&&it.glyph){
      const u=s/16; c.save(); c.scale(u,u); c.clearRect(0,0,16,16);
      (WL_G[it.glyph]||WL_G.chunk)(c,it.gc);
      c.restore(); return;
    }
    _drawIcon3(c,id,s);
  };
}
const WL_RAR=['','Common','Uncommon','Rare','Epic'];
const WL_RARCOL=['','#9db8a7','#86e29a','#7ab8ff','#d49aff'];
