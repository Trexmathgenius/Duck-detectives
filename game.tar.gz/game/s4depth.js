'use strict';
/* ===== DEPTH (v1.19) =====
   1. A quiet, hidden sense of WHO YOU ARE. Nothing here is ever shown as a number or a name: it shows up as how people talk to you,
      what they remember, what you are offered, and what the story says you have become.
   2. A complication in every chapter from 6 to 16: someone needs something, it costs something, and the consequence comes back.
   3. Places that carry meaning: a keeper in every land, and small things on the ground that are worth reading. */

const S4late=()=>swChNum()>=16||!!(g.story&&g.story.s2&&g.story.s2.ending);
const S4st=()=>{ const st=g.story; if(!st.s4) st.s4={h:{candid:0,gentle:0,proud:0,guarded:0,steady:0,tender:0},cx:{},seen:{},mem:[],voice:{}}; return st.s4; };

/* ---------- who you are ---------- */
const TRAIT={
  candid:{nick:'plain-speaker',line:'You say the true thing even when it would be easier not to. People have started to wait for you to say it.',edge:'The plainness. It has cost you friends, and bought you the right sort.',
    inner:['You have stopped softening things. It surprises you how much lighter that is.','Being honest has become a habit you cannot easily break, and have stopped trying to.','The truth is the one tool you have never had to sharpen.']},
  gentle:{nick:'gentle one',line:'You give people the benefit of the doubt before they ask. It is a habit, and a risk.',edge:'The gentleness. It has been spent on people who did not earn it, and on people who did.',
    inner:['You notice you have been kind all week, and that nobody has asked why.','Gentleness is slower than anger. It also lasts longer.','You are tired in the way kind people get tired: all the way down, and without complaint.']},
  proud:{nick:'stubborn duck',line:'You hold your ground. Sometimes it is the right ground. You do not often check.',edge:'The pride. It has kept you upright. It has also kept others at a distance.',
    inner:['You have been right a great many times lately. It has not made you warmer.','Your feathers have gone stiff in the cold. You tell yourself it is dignity.','Somewhere, someone is waiting for you to be wrong aloud. You can feel it.']},
  guarded:{nick:'careful one',line:'You keep a little back. Not lies, exactly. A door left on the latch.',edge:'The caution. It has kept you safe, and kept you from being known.',
    inner:['You notice how often you do not say the whole thing. It is a very small habit and a very large house.','You are good at leaving rooms. You are less good at arriving in them.','Careful ducks live a long time. You are starting to wonder what they live for.']},
  steady:{nick:'steady one',line:'People lean on you without noticing, and you let them. It is the quietest thing you do.',edge:'The steadiness. It has held others up. Nobody has asked who holds you.',
    inner:['You are the one people look to when the room goes quiet. You have not decided to be.','Someone leaned on you today and did not say thank you. You did not mind. You are noticing that you did not mind.','Steadiness is not the absence of fear. It is fear, carrying something.']},
  tender:{nick:'kind one',line:'You notice the small ones first. The child at the edge of the room, the shy hand.',edge:'The tenderness. It is the part of you the world is hardest on.',
    inner:['You keep noticing who is standing at the edge of things. It has become your job, and no one gave it to you.','Tenderness is not weakness. It is only very exposed.','Someone small has started to trust you. It is the most frightening thing that has happened all year.']}
};
const S4={
  note(k,n){ const map={truth:'candid',lie:'guarded',mercy:'gentle',pride:'proud',trust:'steady',kin:'tender'}; if(map[k]) S4st().h[map[k]]+=n; },
  shift(k,d){ const h=S4st().h; if(h[k]===undefined) return; h[k]=Math.max(0,h[k]+d); },
  top(n){ const h=S4st().h; return Object.keys(h).sort((a,b)=>h[b]-h[a]||(a<b?-1:1)).slice(0,n||2); },
  total(){ const h=S4st().h; return Object.keys(h).reduce((s,k)=>s+h[k],0); },
  has(k){ const h=S4st().h; return (h[k]||0)>=2&&S4.top(2).indexOf(k)>=0; },
  self(){ return S4.total()>=3?S4.top(1)[0]:null; },
  nick(){ const k=S4.self(); return k&&S4.total()>=6?TRAIT[k].nick:null; },
  cx(id){ return S4st().cx[id]; },
  setcx(id,v,mem){ const s=S4st(); s.cx[id]=v; if(mem) s.mem.push(mem); },
  portrait(){
    const [a,b]=S4.top(2), t=S4.total(), s=S4st();
    const lines=[];
    if(t<3) lines.push('"You have not written much of yourself yet. That is not a fault. It is a page left open."');
    else { lines.push('"'+TRAIT[a].line+'"'); if(S4st().h[b]>=2) lines.push('"'+TRAIT[b].line+'"'); }
    const m=s.mem.slice(-2); if(m.length) lines.push('"I also noticed that you '+m.join(', and that you ')+'."');
    return {lines,q1:TRAIT[a].edge+' Carry it, or set it down?',k1:a,q2:'And this: '+TRAIT[b].edge.charAt(0).toLowerCase()+TRAIT[b].edge.slice(1)+' Carry it, or set it down?',k2:b};
  },
  who(){ const k=S4.self(); return k||'none'; }
};
{
  const _led=s2led;
  s2led=function(k,n){ const r=_led(k,n); if(n>0) S4.note(k,n); return r; };
}

/* what people call you, and what they remember */
const S4RECALL=[];
const rc=(who,id,when,lines)=>S4RECALL.push({who:[].concat(who),id,when,lines});
const cxIs=(c,v)=>()=>S4.cx(c)===v;
const cxAny=c=>()=>S4.cx(c)!==undefined;
{
  const _say=say;
  say=function(name,pages,cb){
    try{
      if(name&&g.story&&g.story.s2&&g.story.s2.ch&&Array.isArray(pages)){
        const nk=(name==='Hermit Mallow')?S4.nick():null;
        if(nk) pages=pages.map((p,i)=>typeof p==='string'&&p.indexOf('little detective')>=0&&(i+p.length)%2===0?p.replace(/little detective/g,nk):p);
        const s=S4st();
        for(const r of S4RECALL){
          if(r.who.indexOf(name)<0||s.seen[r.id]) continue;
          let ok=false; try{ ok=r.when(); }catch(e){}
          if(!ok) continue;
          s.seen[r.id]=1; pages=r.lines.concat(pages); break;
        }
      }
    }catch(e){ console.error(e); }
    return _say(name,pages,cb);
  };
}
/* a quiet thought at the start of each chapter, shaped by who you have been */
{
  const _begin=S2.begin;
  S2.begin=function(id,skip){
    _begin(id,skip);
    const k=S4.self(), s=S4st();
    if(!k||s.voice[id]) return;
    s.voice[id]=1;
    const band=s2num(id)<10?0:s2num(id)<17?1:2;
    let tries=0; const tell=()=>{ if(g.mode!=='play'||g.scene!=='world'){ if(++tries<40) setTimeout(tell,1500); return; } if(S2.cur&&0) return; toast(TRAIT[k].inner[band],5200); };
    setTimeout(tell,6000);
  };
}

/* ---------- complications ---------- */
const CXS={active:null,t:0,pending:null};
const cxP=(b,w,h)=>({body:b,wing:w,bill:h||'#e6c441'});
const S4CX=[
 {ch:['c6r','c6c'],who:['Page Linnet',cxP('#6a8aa8','#4a6a88'),'cap'],
  intro:['(A thin young duck in a messenger\'s cap, holding a letter against her chest as if it were warm.)','"I am supposed to carry this to the other side\'s quartermaster. It is a peace offer. Nobody was brave enough to sign it. If I am caught on the road with it, I am a spy."','"I cannot make the road. Please. Will you?"'],
  q:'Linnet waits. Her hands are shaking.',
  opts:[
   {t:'"Give it to me. I will carry it, sealed."',cost:{hours:3},habit:'steady',led:{trust:1},flag:'carry',mem:'carried a letter nobody dared sign',say:['She does not say anything. She puts it into your wing with both hands, and then, before you can step back, she hugs you very briefly, like a person pressing a stamp.','It takes the better part of the afternoon to get it where it needs to go, and it is the most nervous you have been in weeks.']},
   {t:'"I will read it first."',habit:'guarded',led:{lie:1},flag:'read',mem:'read a letter that was not yours',say:['She flinches, then lets you. It is a plea for a ceasefire through the harvest: nothing about borders, nothing about blame. Only bread and weather.','"I did not know what was in it," she says, very quietly. "I am a little ashamed that I am relieved."','You carry it anyway, now that you know.']},
   {t:'"Burn it. It is too dangerous."',habit:'proud',led:{pride:1},flag:'burn',mem:'told a frightened girl to burn a peace letter',say:['"Burn it." She says it back, as if testing the word. She does it, there, in the lantern, and watches until there is nothing.','"I will tell them I lost it," she says. She does not look at you again.']}],
  ignore:{flag:'ignored',mem:'walked past a girl with a letter',say:['(Some days later you hear a girl in a messenger\'s cap was stopped on the road with a sealed letter. She was let go, eventually. You do not hear who she was.)']}},
 {ch:['c7r','c7c'],who:['Tarn Mudd',cxP('#9a7a5a','#6a5a3a'),null],
  intro:['(A tired duck with a small child behind one leg. The child is looking at your pockets.)','"We lost the barn in the last shake. The bread queue is two days long. She has not eaten since last night."','"I am not asking for much. I am asking because I have run out of other people."'],
  q:'Tarn looks at the ground.',
  opts:[
   {t:'Give them 15 crumbs.',cost:{crumbs:15},habit:'gentle',led:{mercy:1},flag:'fed',mem:'fed a hungry child without being asked twice',say:['The crumbs vanish into a fist that was already open. The child says something that could be "thank you" or "more". It does not matter which.','Tarn tries to speak, fails, and nods, hard, twice.']},
   {t:'Take them to the herbalist for broth.',cost:{hours:1},habit:'steady',led:{trust:1},flag:'broth',mem:'walked a stranger to a warm kitchen',say:['The herbalist looks at the pair of them, and at you, and says nothing, and ladles. It is not a grand gesture. It takes an hour. It is the thing they remember.']},
   {t:'"I have nothing to spare."',habit:'guarded',flag:'refused',mem:'said "I have nothing to spare" and meant it more than you liked',say:['Tarn nods as if this were the answer expected. The child watches you go. You tell yourself it was the sensible thing.']}],
  ignore:{flag:'ignored',say:['(You pass, later, the queue at the bread stall. It is not shorter.)']}},
 {ch:['c8r','c8c'],who:['Peddler Quill',cxP('#b0824a','#7a5a2a'),'hat'],
  intro:['(A peddler, with a tray of buttons and a voice that is slightly too loud for the street.)','"Detective! You have heard what they are saying? That you stopped the whole war singlehanded. Nonsense, of course. Utter nonsense. Marvellous for morale."','"I thought you should know. People are naming their children after you."'],
  q:'Quill beams. He is clearly not going to stop on his own.',
  opts:[
   {t:'Let it stand. People need a story.',habit:'proud',led:{pride:1},flag:'stand',mem:'let a flattering rumour stand',say:['"Splendid." He tips his tray at you. "I shall say you were modest about it."']},
   {t:'Correct it, plainly, in front of the stall.',habit:'candid',led:{truth:1},flag:'correct',mem:'corrected a rumour that flattered you, in public',say:['You do it loudly, and exactly, and with a list. The crowd goes a little quiet. A few of them look relieved, as if they had been waiting for permission not to believe it.']},
   {t:'Ask him to say that other people did the work, too.',habit:'gentle',led:{mercy:1},flag:'credit',mem:'asked for others to be named',say:['Quill blinks, and then, slowly, grins. "That is a harder story to tell. It is a much better one."']}],
  ignore:{flag:'ignored',say:['(The rumour grows without you. By the end of the week, you have apparently also fought a bear.)']}},
 {ch:['c9r','c9c'],who:['Gatekeeper Wick',cxP('#7a8a6a','#5a6a4a'),'helm'],
  intro:['(A gatekeeper, low, by the side wall, looking in both directions.)','"There is a way past the checkpoint. Quick. The guard on duty will not look at the logbook. If anyone does, he loses his post. His wife is expecting."','"I am only telling you it exists."'],
  q:'Wick does not look at you.',
  opts:[
   {t:'Take it. Time matters.',habit:'proud',led:{pride:1},flag:'shortcut',mem:'took a shortcut that cost a stranger',say:['It works. It saves nearly half a day. You will think, from time to time, about a man you never saw, and a logbook.']},
   {t:'Wait in line, like everyone.',cost:{hours:2},habit:'steady',led:{trust:1},flag:'line',mem:'waited in line rather than spend someone else\'s job',say:['It takes two hours. The man in front of you complains about the hours and the draught. You find, to your surprise, that you do not mind.']},
   {t:'Take it, and put your own name in the logbook.',cost:{crumbs:10},habit:'candid',led:{truth:1,mercy:1},flag:'name',mem:'put your own name in the logbook to cover for a stranger',say:['The guard stares at the entry, and at you, and says, very softly, "I am going to remember this." He does not say what.']}],
  ignore:{flag:'ignored',say:['(Somebody else takes the shortcut. You hear the guard was dismissed the next week.)']}},
 {ch:['c10'],who:['Watchman Dobb',cxP('#8a8a9a','#6a6a7a'),'helm'],
  intro:['(A watchman leaning against his own spear. His eyes are rimmed with red.)','"Three nights. I have not slept in three nights. If I close my eyes, I do not know if I will open them."','"I would not ask. But the post must be stood. And you are standing."'],
  q:'Dobb swallows a yawn that looks painful.',
  opts:[
   {t:'Stand his post for an hour while he sleeps.',cost:{hours:2},habit:'steady',led:{trust:1,mercy:1},flag:'relieved',mem:'stood another duck\'s post so he could sleep',say:['He is asleep before you finish saying yes, with his head on his arm, in the sentry box. You stand where he stood. Nothing happens. It is the longest hour you have ever done nothing.','When he wakes, he looks at the light, and at you, and says nothing at all, and something in the set of his shoulders has changed.']},
   {t:'"Go home. I will tell them you were ill."',habit:'gentle',led:{mercy:1,lie:1},flag:'sent',mem:'told a lie for a tired man',say:['"They will know," he says. "They will not say." He goes. You tell the lie later, to a captain who does not believe it, and does not ask.']},
   {t:'"Hold on. The post must be stood."',habit:'proud',led:{pride:1},flag:'held',mem:'told a man to hold on when he could not',say:['He straightens, with great effort, as if you had just pulled him up by the collar. "Yes. Of course." He is very polite. He will not forget it.']}],
  ignore:{flag:'ignored',say:['(You hear, a week later, that a watchman fell asleep at his post at the north gate. Nothing came of it, this time.)']}},
 {ch:['c11'],who:['Old Marta',cxP('#a8947a','#7a6a4a'),'scarf'],
  intro:['(A very old duck on the road, with a walking-stick that is mostly a branch and a bundle that is mostly a blanket.)','"You are going to the Old Tree. I can tell. You have the walk. My Teodor went in a hundred years ago, on the march, and did not come out. I have never been past the edge."','"I am slow. But I would like to see the place. Before the other kind of slow."'],
  q:'Marta leans on the stick. She does not push.',
  opts:[
   {t:'"Walk with me. We will go at your pace."',cost:{hours:3},habit:'tender',led:{kin:1,mercy:1},flag:'walked',mem:'walked an old woman to the edge of the Burnt Wood at her own pace',say:['It takes three hours. She tells you about Teodor the whole way: he was a baker, he sang flat, he never learned to whistle. At the edge of the wood, she stops, and puts her hand on a charred stump, and says his name, once, plainly.','"There," she says. "Now I have said it where he could hear." She does not go in. She does not need to.']},
   {t:'Tell her where the edge is, and what to expect.',habit:'candid',led:{truth:1},flag:'told',mem:'told an old woman the truth about where her husband was',say:['She listens. She does not interrupt. "Thank you for not making it smaller," she says. "People always make it smaller."']},
   {t:'"It is dangerous. You should go home."',habit:'guarded',flag:'warned',mem:'told an old woman to go home',say:['"I am a hundred and three," she says, mildly. "I am afraid of a great many things. The wood is not on the list." She goes anyway, slowly, in the opposite direction from you.']}],
  ignore:{flag:'ignored',say:['(You do not see her again on the road.)']}},
 {ch:['c13r','c13c','c13k'],who:['Trader Bellis',cxP('#b09a4a','#7a6a2a'),'hat'],
  intro:['(A trader, one hand on a crate and the other in his coat, smiling at nobody.)','"I have a quantity of grain. It would be very awkward if it were known I had a quantity of grain. The price is going up, you see, and so is the demand, and it would be a terrible shame for everyone if the price came down."','"I would be grateful for your silence. Sixty crumbs\' worth of grateful."'],
  q:'Bellis smiles. It is a practised smile, with nothing behind it.',
  opts:[
   {t:'Take the sixty crumbs and say nothing.',habit:'guarded',led:{lie:1},flag:'bribed',mem:'took a bribe to keep quiet about hoarded grain',say:['The crumbs are warm from his pocket. You put them away without counting. You do not feel the way you thought you would.'],gain:{crumbs:60}},
   {t:'"Open the crates. Sell it fair."',habit:'candid',led:{truth:1},flag:'fair',mem:'told a profiteer to open his crates',say:['His smile does not move, but something behind it has gone cold. "You will regret this." He does it, though. The queue at his stall is three streets long by noon.']},
   {t:'Tell the Watch, and let them decide.',habit:'proud',led:{pride:1},flag:'reported',mem:'reported a hoarder to the Watch',say:['It is done by the end of the day. The grain is taken, and sold, and the price falls, and Bellis is fined, and becomes, very quietly, the kind of enemy a person is better off not having.']}],
  ignore:{flag:'ignored',say:['(You hear the price of bread has gone up again.)']}},
 {ch:['c14r','c14c','c14k'],who:['Pip, a lantern-lighter',cxP('#c9a24a','#8a6a2a'),null],
  intro:['(A very small duck on a ladder, lighting a row of street-lanterns, one at a time, slowly.)','"My father went with the march. He said he would be back by the time the lanterns were all lit. I light them every night. I do the last one very slowly."','"Please do the last one with me. I think it is lucky if two people do it."'],
  q:'Pip holds out the taper. Her wing is steady. Her voice is not.',
  opts:[
   {t:'Light it with her.',habit:'tender',led:{kin:1},flag:'lit',mem:'lit a lantern with a child who was waiting for her father',say:['The two of you put the flame to the wick together. It catches. She looks at it for a long time. "Tomorrow," she says, "I will light it a little faster."']},
   {t:'"He may not be coming, Pip."',habit:'candid',led:{truth:1},flag:'told',mem:'told a child the truth about her father',say:['She does not cry. She puts the taper down very carefully, on the rung, and looks at the row of lanterns, and says "I know. I wanted someone to say it."']},
   {t:'"He will. I promise."',habit:'guarded',led:{lie:1,kin:1},flag:'promised',mem:'promised a child something you could not keep',say:['She smiles so widely that it hurts to look at. "I will tell my mother you said so." You have just made a promise you cannot keep, and she is going to repeat it to everyone.']}],
  ignore:{flag:'ignored',say:['(The last lantern on the street is left unlit. You see it from far off, a small dark gap in a row of lights.)']}},
 {ch:['c15r','c15c','c15k'],who:['Private Fenn',cxP('#7a8a9a','#5a6a7a'),'helm'],
  intro:['(A very young soldier, off to the side of the line, with his helmet in both hands.)','"I want to go home. I have been standing here two days and I do not know what for. I am not a coward. I have a mother and a field and I do not want to die for a grudge older than my grandmother."','"If you report me, they will shoot me. I would just like someone to know that I asked."'],
  q:'Fenn is crying, without sound.',
  opts:[
   {t:'Let him go. You saw nothing.',habit:'gentle',led:{mercy:1,lie:1},flag:'freed',mem:'let a frightened soldier leave the line',say:['He is gone before you finish the sentence. Somewhere in the hills a field is going to be ploughed by a boy with a helmet he did not return.']},
   {t:'Walk him back to his captain, and stand beside him.',cost:{hours:3},habit:'steady',led:{trust:1,truth:1},flag:'stood',mem:'stood beside a deserter while he told his captain the truth',say:['The captain is silent for a very long time. "You are a fool," he says, to Fenn. And then, to you: "Thank you for bringing him back alive." He is reassigned to the kitchens. It is, all things considered, the best outcome on offer.']},
   {t:'Report him. Orders are orders.',habit:'proud',led:{pride:1},flag:'reported',mem:'reported a frightened boy for desertion',say:['He does not argue. He puts his helmet on, very straight, and is taken away. You will not learn what happened to him. You will think about it at night.']}],
  ignore:{flag:'ignored',say:['(You hear a young soldier left the line in the night. You do not hear that he was caught.)']}},
 {ch:['c16r','c16c'],who:['Baker Orrin',cxP('#c9a06a','#8a6a3a'),'cap'],
  intro:['(A baker in a floury apron, holding the last loaf of the day in both hands, looking from the line of soldiers to the line of hungry ducks.)','"I have one loaf left. The Watch has been told it will be requisitioned at dusk. The queue at my door has been there since dawn. I cannot split it. It will not go round."','"You are somebody people listen to. Tell me what to do."'],
  q:'Orrin is not asking to be argued with. He is asking to be told.',
  opts:[
   {t:'"Give it to the queue. They were here first."',habit:'gentle',led:{mercy:1},flag:'queue',mem:'told a baker to feed the hungry before the army',say:['He breaks it into the smallest pieces a loaf has ever been broken into, and hands them out one at a time. Some do not get any. He counts them, aloud, and apologises to each.']},
   {t:'"Give it to the soldiers. Someone has to hold the line."',habit:'steady',led:{trust:1},flag:'army',mem:'told a baker to feed the line',say:['He nods slowly, and wraps it, and hands it over. The queue watches it go. Nobody says anything. It is a very quiet sound.']},
   {t:'"Throw it in the river. Then nobody gets it."',habit:'proud',led:{pride:1},flag:'river',mem:'told a baker to waste a loaf rather than choose',say:['Orrin looks at you for a very long time. Then he does it. He throws it, as far as his arm will go, and the river takes it, and nobody breathes.','"I hope that was wise," he says. He does not say it was.']}],
  ignore:{flag:'ignored',say:['(The loaf is gone by dusk. You do not hear where.)']}}
];
const CXMAP={}; for(const c of S4CX) for(const id of c.ch) CXMAP[id]=c;
const cxNpc=S2.npc({id:'cx_npc',name:'Someone',wx:0,wy:0,pal:cxP('#aaa','#888'),head:null,still:true,when:()=>!!CXS.active,mark:()=>CXS.active?'!':null,
  talk(n,done){ const c=CXS.active; if(!c){ done(); return; } cxTalk(c,done); }});
function cxCost(o){ const c=o.cost||{}; if(c.crumbs&&g.crumbs<c.crumbs) return false; return true; }
function cxPay(o){ const c=o.cost||{}; if(c.crumbs) g.crumbs-=c.crumbs; if(c.hours) advanceClock(c.hours); if(o.gain&&o.gain.crumbs) g.crumbs+=o.gain.crumbs; }
function cxTalk(c,done){
  const id=c.key||s2cur();
  const opts=c.opts.filter(cxCost);
  say(c.who[0],c.intro,()=>{
    choose(c.who[0],c.q,opts.map(o=>o.t+(o.cost&&o.cost.crumbs?'  ('+o.cost.crumbs+' crumbs)':'')+(o.cost&&o.cost.hours?'  (about '+o.cost.hours+' hours)':'')),k=>{
      const o=opts[k]; cxPay(o); const hb=Object.assign({},S4st().h);
      for(const key in (o.led||{})) s2led(key,o.led[key]);
      if(o.habit&&S4st().h[o.habit]===hb[o.habit]) S4st().h[o.habit]++;
      S4.setcx(c.key||id,o.flag,o.mem);
      CXS.active=null; hudCache.obj=null; if(c.onPick) c.onPick(o);
      say(c.who[0],o.say,()=>{ coin(); done(); });
    },opts.length-1);
  });
}
function cxSpawn(c){
  const d=cxNpc;
  d._o=null; d.name=c.who[0]; d.pal=c.who[1]; d.head=c.who[2]; d.snap=2;
  const p=s2tile(); d.wx=p.x+(g.dir==='left'?-2:2); d.wy=p.y+1; d._r=0;
  CXS.active=c; CXS.id=s2cur(); toast(c.who[0]+' is waiting nearby, and does not look like someone who is waiting for good news.',4200);
}
{
  const _su=storyUpdate;
  storyUpdate=function(dt){
    _su(dt);
    if(g.mode!=='play'||g.scene!=='world'||!g.story||!g.story.s2) return;
    const id=s2cur();
    if(CXS.active&&CXS.id!==id){ const c=CXS.active; const prev=CXS.id; CXS.active=null; if(S4.cx(prev)===undefined){ S4.setcx(prev,'ignored'); } }
    if(!id||!CXMAP[id]||S4.cx(id)!==undefined||CXS.active) { if(id!==CXS.last){ CXS.t=0; } CXS.last=id; return; }
    CXS.last=id; CXS.t+=dt;
    if(CXS.t>25){ CXS.t=0; cxSpawn(CXMAP[id]); }
  };
}
/* a debugging aid: skip ahead of the timer */
S4.spawnNow=()=>{ const c=CXMAP[s2cur()]; if(c&&!CXS.active&&S4.cx(s2cur())===undefined) cxSpawn(c); };

/* ---------- consequences: what comes back ---------- */
rc(['Captain Halbeak','Elder Cinder'],'rc_c6carry',cxIs('c6r','carry'),['(Before anything else, almost as an aside:) "A letter reached the quartermaster. A peace offer, unsigned. Nobody has said who carried it. I would like to shake that hand."']);
rc(['Captain Halbeak','Elder Cinder'],'rc_c6carry2',cxIs('c6c','carry'),['(Before anything else, almost as an aside:) "A letter reached the quartermaster. A peace offer, unsigned. Nobody has said who carried it. I would like to shake that hand."']);
rc(['Captain Halbeak','Elder Cinder'],'rc_c6burn',()=>S4.cx('c6r')==='burn'||S4.cx('c6c')==='burn',['(A pause, before the real conversation:) "There was a peace letter. It never arrived. A page was found, in the end, burned in a lantern. I do not know who advised that."']);
rc(['Hermit Mallow'],'rc_c7fed',()=>['fed','broth'].indexOf(S4.cx('c7r')||S4.cx('c7c'))>=0,['"A woman with a small child told me, last week, that a duck had been kind to her. She did not say who. I did not need her to."']);
rc(['Elder Cinder','Captain Halbeak'],'rc_c8',()=>(S4.cx('c8r')||S4.cx('c8c'))==='correct',['"Quill told me you stood up in the market and corrected him. In front of everyone. I have not seen anyone refuse praise in this town in thirty years."']);
rc(['Warden Ruddock','Captain Halbeak'],'rc_c9name',()=>(S4.cx('c9r')||S4.cx('c9c'))==='name',['"A guard at the north checkpoint wrote your name in his logbook, under a line that was not his. He asked me to say thank you. I said I would. I have."']);
rc(['Captain Halbeak','Warden Ruddock'],'rc_c10',()=>S4.cx('c10')==='relieved',['"Dobb has been sleeping at night. He told me who stood his post. He will not say it aloud. He only looks at the sentry box a little differently."']);
rc(['Hob'],'rc_c11',()=>S4.cx('c11')==='walked',['(Hob looks past you, at someone at the edge of the clearing. A very old woman with a stick, who has walked all the way. He lowers his voice.) "Teodor is two rows over. Tell her, will you? I cannot seem to stand."']);
rc(['Tam'],'rc_c15',()=>['stood','freed'].indexOf(S4.cx('c15r')||S4.cx('c15c')||S4.cx('c15k'))>=0,['"A boy left the line at the Reeds, a hundred years ago, and I never knew whether he got home. Did you meet one? I would like to think someone did."']);
rc(['Little Poppy'],'rc_c14',()=>(S4.cx('c14r')||S4.cx('c14c')||S4.cx('c14k'))==='lit',['"There is a girl who lights lanterns. She told me you did the last one with her. She does it faster now. Mama says that is what recovering looks like."']);
rc(['Orla'],'rc_c16',()=>(S4.cx('c16r')||S4.cx('c16c'))==='queue',['(She has a small piece of bread in her wing, and does not know who gave it to her.) "Somebody broke a loaf into pieces so small. They counted them aloud. I think about that."']);
rc(['Hermit Mallow'],'rc_prideC',()=>S4.has('proud'),['"I used to be very proud of being right. It took me about eighty years to notice nobody was standing next to me. I only mention it."']);

/* ---------- places that carry meaning ---------- */
const FL3=()=>{ const k=K3(); return k; };
const swStarted0=1;
npc3('hask','Fence-Warden Hask',{wx:SW_WP.mile.x+4,wy:SW_WP.mile.y+3},cxP('#8a8478','#5a5650'),'cap',()=>S4late(),(n,done)=>{
  const k=K3(), f=k.fence;
  const stage=f==='burned'?['"The posts are gone. The village is warm. I told myself it was fair. It was fair. It is also very quiet where the posts were."']:f==='kept'?['"I carried the firewood from the next valley myself. My back says it was not worth it. The posts say it was."']:f==='half'?['"We numbered them, and burned the even ones. It was a ghastly thing to do, and a very sensible one. I think I will never know which it was."']:['"The fence goes on. Every post is a soldier, and every soldier is a name I cannot say. Someone has to keep them standing."'];
  say('Fence-Warden Hask',['Hask is hammering a post, slowly, into ash that was once a field.'].concat(stage),()=>{
    if(!k.haskQ){ k.haskQ=1;
      choose('Fence-Warden Hask','"What do you think a wall is for?"',['"To keep something out."','"To keep something in."','"To make a place you can stand and say: here."'],q=>{
        S4st().h[['proud','guarded','steady'][q]]++;
        say('Fence-Warden Hask',[['"That is the first answer. It is the one everybody gives. It is also, I notice, the one that cost the most."','"Yes. That is the second answer, and it is the one nobody likes."','"Ah. That is the third. It took me a hundred posts to learn it. You are quicker than I was."'][q]],done);
      },2); } else done();
  });
},()=>null);
S2.prop({id:'cinder_posts',wx:SW_WP.mile.x-6,wy:SW_WP.mile.y+4,glyph:'grave',col:'#8a8478',when:()=>S4late(),use(){
  const L=['A fence-post, burnt black at the head. Someone has cut a name into it, very small: "Ebb". Under it, "who whistled".','A fence-post, leaning. A tin cup hangs from a nail on it. The cup has a hole in the bottom. Somebody hung it there anyway.','A fence-post with no name. Someone has chalked, over and over, "later", and rubbed it out, and chalked it again.'];
  K3().postN=((K3().postN||0)+1)%L.length; say('',[L[K3().postN]]);
}});
npc3('rue','Candle-Keeper Rue',{wx:SW_FERRY.x-6,wy:SW_FERRY.y+3},cxP('#7a9a8a','#4a6a5a'),'scarf',()=>S4late(),(n,done)=>{
  const k=K3(), c=k.candles;
  const stage=c==='lost'?['"The candle-stones are under the new deck. I light the ones at the edge now. It is fewer. It is, I tell myself, still the same vigil."']:c==='kept'?['"They stayed. The bridge goes beside them, and every night it throws a little shadow on the row. I find I do not mind the shadow."']:c==='ferry'?['"Pim still ferries us across. Rope and a flat boat and a lot of swearing. The candles are exactly as they were. I would not change it."']:['"I light them every night. A hundred years, I have kept someone\'s chair warm in case. Nobody sits in it. That is not the point."'];
  say('Candle-Keeper Rue',['Rue is setting small candles on flat stones along the water. Each stone has an empty place beside it, the shape of someone sitting.'].concat(stage),()=>{
    if(!k.rueQ){ k.rueQ=1;
      choose('Candle-Keeper Rue','"Do you think they are coming? The walkers?"',['"No."','"Yes. Some day."','"It does not matter. You light them."'],q=>{
        S4st().h[['candid','tender','steady'][q]]++;
        say('Candle-Keeper Rue',[['"No," she says, and nods, as if you had given her the correct change. "I know. Thank you for not pretending."','"Yes," she says, very quietly. "That is what I tell the candles."','"That is the one I believe. It is not the one I like best."'][q]],done);
      },2); } else done();
  });
},()=>null);
S2.prop({id:'fen_chairs',wx:SW_FERRY.x-8,wy:SW_FERRY.y-3,glyph:'candle',col:'#9ad8c0',when:()=>S4late(),use(){
  say('',['A row of flat stones, each with a candle on it, and each, to one side, a place the exact size of a duck. The grass in the places is not flattened. Nobody has sat here in a hundred years. The grass has been mown by hand, every week, regardless.']);
}});
S2.prop({id:'ridge_cairns',wx:SW_WP.ridge.x+8,wy:SW_WP.ridge.y+4,glyph:'stone',col:'#9a9aa0',when:()=>S4late(),use(){
  const L=['A waymark cairn. Under the top stone, a name, scratched: "Alder\'s mama says come home."','A waymark cairn, with a feather wedged between the stones. A scout\'s. Worn to a thread.','A waymark cairn with a small round pebble on top, and under it, in a child\'s hand: "I was here. I was walking. I was not scared."'];
  K3().cairnN=((K3().cairnN||0)+1)%L.length; say('',[L[K3().cairnN]]);
}});
npc3('odd','Name-Keeper Odd',{wx:SW_STONES.x+3,wy:SW_STONES.y+4},cxP('#cfe0ff','#8aaad0'),'scarf',()=>S4late(),(n,done)=>{
  const k=K3();
  say('Name-Keeper Odd',['Odd is sweeping snow off a brick, very gently, with a small brush made of reed. The brick has a name on it. He is reading it aloud, over and over, very softly, as if to see whether it still works.'].concat(k.wrote!==undefined?['"You wrote one. On the blank. I saw. It is a good brick. Someone will read it in a hundred years and wonder who you were."']:['"There is one blank brick, between Alder and Sedge. It has been blank for a hundred years. I cannot decide whose it is. I am a coward about it."']),()=>{
    if(!k.oddQ){ k.oddQ=1;
      choose('Name-Keeper Odd','"Is it better to be remembered, or to be forgiven?"',['"Remembered."','"Forgiven."','"They are the same thing."'],q=>{
        S4st().h[['proud','gentle','candid'][q]]++;
        say('Name-Keeper Odd',[['"Yes. That is what the names are for. Not forgiveness. Only that someone read them."','"Yes. I have thought so too. But nobody here can give it."','"They are the same thing, if you are lucky. I am not often lucky."'][q]],done);
      },2); } else done();
  });
},()=>null);
npc3('tansy','Thread-Mother Tansy',{wx:WX0+10,wy:WY0+13},cxP('#c0392b','#7a1a12'),'scarf',()=>S4late(),(n,done)=>{
  const k=K3();
  say('Thread-Mother Tansy',['Tansy is tying red thread around a branch, slowly, three loops and a knot. There are hundreds of knots already, on every third tree.','"Three loops for the ones who died. One for the ones who went missing. I never could decide which to use for the three hundred. So I do both."'],()=>{
    if(!k.tansyQ){ k.tansyQ=1;
      choose('Thread-Mother Tansy','"What do you tie for someone you did not know?"',['"One loop, to say I was here."','"Three. Someone has to."','"None. It is not mine to mourn."'],q=>{
        S4st().h[['tender','steady','guarded'][q]]++;
        say('Thread-Mother Tansy',[['"One. That is a very small and a very true number."','"Three. You will find it is heavier than it looks."','"No. You are right. Some of it is not ours. It is still kind to stand near it."'][q]],done);
      },2); } else done();
  });
},()=>null);
S2.prop({id:'hollow_posts',wx:WX0+13,wy:WY0+11,glyph:'banner',col:'#c0392b',when:()=>S4late(),use(){
  say('',['A fence-post with a red thread knotted round it, three loops and one. A lantern hangs from it, unlit. Underneath, someone has set a little cup of water, and a small hard loaf. For whoever is walking.']);
}});

/* a complication always speaks for itself, whatever the chapter's own talk would do */
{
  const _ct=s2chTalk;
  s2chTalk=function(n){ if(n&&n.s2===cxNpc) return false; return _ct(n); };
}
