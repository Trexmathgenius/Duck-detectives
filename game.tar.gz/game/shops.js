'use strict';
/* ===== MORE SHOPS: a toolshed, tackle shop, surveyor, naturalist, apothecary and provisions, and sensible stock everywhere ===== */
const WL_NEWKINDS=['hardware','tackle','cartog','naturalist','apoth','provision'];
window.SHOP_LABEL={hardware:'a toolshed',tackle:'a tackle shop',cartog:'a surveyor and mapmaker',naturalist:'a naturalist\'s lodge',apoth:'an apothecary',provision:'a provisions stall'};
for(const k of WL_NEWKINDS) if(!SHOP_KINDS.includes(k)) SHOP_KINDS.push(k);
Object.assign(SHOP_NAMES,{
  hardware:['Peck & Hammer Toolshed','The Sturdy Spade','Dig & Chop Hardware'],
  tackle:['Hook, Line & Sinker','The Bobbing Float','Reel Deal Tackle'],
  cartog:['Compass Rose Surveyors','X Marks the Spot','The Inked Quill Maps'],
  naturalist:['The Field & Feather Lodge','Leaf & Lens Naturalists','Wild Things Collective'],
  apoth:['The Bubbling Beak Apothecary','Tonic & Tail','Mortar & Pestle Remedies'],
  provision:['Trailside Provisions','Packed & Ready','The Satchel Stall']
});
Object.assign(HOURS,{hardware:[7,18],tackle:[5,20],cartog:[9,19],naturalist:[8,19],apoth:[9,19],provision:[6,20]});
Object.assign(FLOORS,{hardware:['#8a7a66','#7c6d5a'],tackle:['#6a8aa0','#5e7d94'],cartog:['#c9b48a','#bda77c'],naturalist:['#6e9a58','#628c4e'],apoth:['#6a5a8a','#5e4f7e'],provision:['#b89a62','#aa8c56']});
Object.assign(RUGS,{hardware:'#9a8a6a',tackle:'#8ac0d6',cartog:'#e8d3a0',naturalist:'#a8d890',apoth:'#b8a0d8',provision:'#d8b878'});
Object.assign(GOODS,{hardware:['#a8aeb8','#8a5a2b','#c9a24a'],tackle:['#4a9ad0','#e8602a','#f6d55c'],cartog:['#e8d3a0','#c0392b','#3a62a8'],naturalist:['#4f9a4a','#f6d55c','#c792ea'],apoth:['#c792ea','#86e29a','#e86a92'],provision:['#c98a3a','#d9503a','#86b36a']});
Object.assign(GREET,{
  hardware:['A good tool outlasts a bad day.','Spades, axes, pickaxes. If it digs or chops, I have it.'],
  tackle:['The fish are biting. Probably. Maybe.','Hooks, bait and a little hope. Take your pick.'],
  cartog:['Every treasure starts as a smudge on a map.','Maps drawn fresh. Accuracy not guaranteed. Adventure is.'],
  naturalist:['Mind the specimens. Some of them mind back.','Every leaf has a name. I know most of them.'],
  apoth:['A tonic a day keeps the grumbles away.','Do not shake the purple one. Trust me.'],
  provision:['Packed for a long walk? Let me help.','A duck marches on its stomach. Flat feet help, too.']
});
Object.assign(JOBS,{
  hardware:['Sharpen the Blades','Hold the edge to the stone at the right moment.'],
  tackle:['Tie the Flies','Pull the knot tight right in the zone.'],
  cartog:['Ink the Maps','One steady line at the right moment.'],
  naturalist:['Press the Specimens','Close the press at just the right time.'],
  apoth:['Grind the Herbs','Stop grinding right in the zone.'],
  provision:['Pack the Satchels','Seal each satchel at the right moment.']
});
BUY.tackle={m:1.25,name:'a fisher\'s catch'};

/* ---- new things to sell ---- */
const WL_NEW={
 tonic_luck:['Fortune Tonic',14,'A gold-flecked draught. Smells like a four-leaf clover.','vial',['#e8c24a','#c99a1a','#fff3b0']],
 tonic_forage:['Forager\'s Tonic',12,'Green and grassy. Gives you a nose for crumbs.','vial',['#6ac456','#3a8a3a','#d8ffc0']],
 tonic_angler:['Angler\'s Draught',12,'Smells faintly of pond. Steadies your hands for fishing.','vial',['#5aa8e0','#2a6aa8','#d0eeff']],
 tonic_haggle:['Silver-Tongue Syrup',14,'A glossy syrup that makes everything you say sound like a bargain.','vial',['#c3c8d6','#8a90a8','#ffffff']],
 tonic_glow:['Glow Tonic',10,'It hums, it fizzes, and it lights up your beak.','vial',['#7affd0','#2ab890','#e0fff4']],
 tonic_speed:['Swift Tonic',9,'Fizzy orange. Your feet start tapping before you finish the sip.','vial',['#ff9a3a','#e0601a','#ffe0b0']],
 lure:['Shiny Lure',6,'A little silver fish that is not a fish. Fish keep falling for it.','lure',['#c3c8d6','#e0242a','#ffffff']],
 baittin:['Bait Tin',9,'A tin of the juiciest worms around. Fish line up for these.','tin',['#a8aeb8','#8a5a2b','#d8d8e0']],
 hardtack:['Hardtack',3,'Dry as a bone, tough as a boot, and it keeps for ever.','hardtack',['#c9a06a','#a87c46','#e8cf9a']],
 driedberries:['Dried Berries',4,'Chewy, tart and sweet. A trail walker\'s treasure.','berries',['#8a2a4a','#5a1a30','#d86a8a']],
 trailsand:['Trail Sandwich',6,'Bread, cheese, pickles and a leaf of something green. Packed for a long walk.','sandwich',['#d9a05b','#86b36a','#f6d55c']],
 waterskin:['Waterskin',7,'Cold, clear spring water. Quenches and refreshes all the way to the tail.','skin',['#a8703a','#7a4a22','#7ac0e8']],
 teablend:['Forager\'s Tea Blend',6,'A mix of clover, mint and berry leaf. Sharpens the senses for the wild.','tea',['#8ac46a','#c9a06a','#f4efe0']]
};
for(const id in WL_NEW){ const n=WL_NEW[id]; ITEMS[id]={name:n[0],price:n[1],desc:n[2],use:'note',note:'',nogift:false,glyph:n[3],gc:n[4]}; }
Object.assign(WL_G,{
 lure:(c,k)=>{ ell(c,8,9,5.6,3,k[0]); wlTri(c,12,9,15.5,5.5,15.5,12.5,k[0]); circ(c,5,8.4,0.9,'#111'); rect(c,7,6,1,6,k[1]); rect(c,10,6.5,1,5,k[1]); wlLine(c,3,13,1.5,15,1,k[2]); },
 tin:(c,k)=>{ rect(c,3,5,10,9,k[0]); rect(c,3,4,10,2,k[2]); rect(c,3,13,10,1,'rgba(0,0,0,0.25)'); rect(c,5,8,6,3,k[1]); rect(c,5,8,1,3,'rgba(255,255,255,0.3)'); },
 hardtack:(c,k)=>{ rect(c,3,4,10,9,k[0]); rect(c,3,4,10,1,k[2]); for(const p of [[5,6],[8,6],[11,6],[5,9],[8,9],[11,9]]) rect(c,p[0],p[1],1,1,k[1]); },
 berries:(c,k)=>{ for(const p of [[5,9],[9,10],[7,6],[11,6],[5,5],[8,13]]){ circ(c,p[0],p[1],2.2,k[0]); rect(c,p[0]-1,p[1]-1,1,1,k[2]); } rect(c,6,2,1,3,'#3a6a2a'); },
 sandwich:(c,k)=>{ rect(c,2,10,12,3,k[0]); rect(c,2,8,12,2,k[1]); rect(c,2,7,12,1,k[2]); rect(c,2,4,12,3,k[0]); rect(c,3,4,9,1,'rgba(255,255,255,0.3)'); },
 skin:(c,k)=>{ ell(c,8,9,4.6,5.6,k[0]); rect(c,6,2,4,3,k[1]); rect(c,5,5,6,1.3,k[1]); ell(c,8,10,3,3.4,k[2]); rect(c,6,8,1,2,'rgba(255,255,255,0.45)'); },
 tea:(c,k)=>{ for(let i=0;i<5;i++){ ell(c,4+i*2,8+(i%2)*2.4,2.6,1.4,i%2?k[0]:k[1]); } rect(c,3,12,10,2,k[2]); }
});
/* sensible stock: sell what the shop would actually sell */
const WL_RM=(kind,ids)=>{ STOCK[kind]=STOCK[kind].filter(id=>!ids.includes(id)); };
WL_RM('market',['shovel','axe','pickaxe','clog']); WL_RM('supply',['shovel','axe','pickaxe','clog','fishrod','tmap']);
WL_RM('toys',['shovel','axe','tmap']); WL_RM('florist',['shovel','tmap']); WL_RM('curio',['tmap','clog','fishrod','shovel']);
WL_RM('cafe',['tmap']); WL_RM('tailor',['tmap']); WL_RM('books',['tmap']);
STOCK.hardware=['shovel','axe','pickaxe','lantern','flint','tinderbox'];
STOCK.tackle=['fishrod','worms','lure','baittin'];
STOCK.cartog=['tmap','compass','notebook','glass'];
STOCK.naturalist=['clog','guide','bulb','teablend'];
STOCK.apoth=['tonic_luck','tonic_forage','tonic_angler','tonic_haggle','tonic_glow','tonic_speed'];
STOCK.provision=['t_mix','hardtack','driedberries','trailsand','waterskin'];
SPECIAL.cartog='specs'; ITEMS.t_mix.price=4;
