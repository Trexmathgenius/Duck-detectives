'use strict';
/* ===== BIOMES FOR THE STORY LANDS (v1.18) =====
   Six new places join the wild world, each with its own plants, rare finds and essence:
     The Burnt Wood (Ashwood), the Cinder Fields, Weeping Ridge, the Ashen Fen, the Sealed North and the Hollow Wood.
   They plug into the same systems as every other biome: the species painters, foraging, the Collection Log, the explorer's map,
   essences and the Recipe Book. Some plants exist nowhere else (the Hearthbloom is the only way to a Prime flower for a Quiet Draught
   without a long walk), and every lore find is a small piece of the story. */

/* ---------------- lore finds ---------------- */
const SW_LORE=[
 /* the Burnt Wood */
 ['b_ashbead','Ash-Glass Bead',14,'orb',['#6a5a8a','#2a2040','#d0c0ff'],'A bead blown from sand where a pyre burned, and threaded on something long since turned to ash. Held to your ear, it hums four notes.','ashwood'],
 ['b_hobjug','Hob\'s Water-Jug',12,'jug',['#a8793f','#6a4a20','#e0c090'],'A cook\'s jug, stamped with a crude H. Hob fed three hundred ducks along a hundred miles and never once put his name on anything else.','ashwood'],
 ['b_cradlebell','Cradle-Bell',20,'bell',['#c9a24a','#8a6a1a','#fff0b0'],'A bell the size of a thumb, with no clapper. Somebody tied it to a cradle so the rocking would sound like something.','ashwood'],
 ['b_wrenfeather','Scout\'s Feather',16,'feather',['#8a6a4a','#4a3a2a'],'A scout wears one in her cap for each night she did not light a fire. This one is worn to a thread.','ashwood'],
 /* the Cinder Fields */
 ['c_siegepenny','Siege Penny',9,'coin',['#9a7a4a','#5a4a2a','#e0c080'],'Crown money, bent double. Whoever carried it was paid to stand on a wall, and kept it to remember what a wall costs.','cinder'],
 ['c_arrowhead','Crown-Iron Arrowhead',11,'spear',['#8a8f98','#4a4f58','#d0d4dc'],'Never fired. The head is still clean in the socket. Somebody put the arrow down and walked away from it.','cinder'],
 ['c_mitten','Scorched Mitten',8,'mitten',['#c0392b','#7a1a12'],'A child\'s mitten, red wool, burnt at the cuff. It has a second mitten somewhere, and a hand, and a whole afternoon.','cinder'],
 /* Weeping Ridge */
 ['w_cairnstone','Cairn-Stone',10,'chunk',['#9a9aa0','#6a6a72','#d0d0d8'],'The top stone of a waymark. Turn it over: somebody has scratched a name into the underside, and under that, "come home".','ridge'],
 ['w_whistle','Scout\'s Whistle',13,'whistle',['#b8a07a','#6a5a3a'],'It does not make a sound anyone can hear. It makes the sound that tells another scout, miles away, you are all right.','ridge'],
 ['w_needle','Waymark Needle',15,'needle',['#c0392b','#e8d9b5'],'A compass needle that points, a little unsteadily, toward the Burnt Wood. It has been pointing for a hundred years and has stopped expecting an answer.','ridge'],
 /* the Ashen Fen */
 ['f_marshcandle','Marsh Candle',18,'lantern',['#9ad8c0','#3a7a66','#e8fff4'],'A stub of candle that burns without wax or heat, green as pond-light. Fen ducks say it is somebody keeping a place at the table.','fen'],
 ['f_reedpipe','Reed Pipe',12,'flute',['#8a9a5a','#4a5a2a'],'A pipe cut from a fen reed. It has four holes and plays, no matter who blows it, the first four notes of a lullaby.','fen'],
 ['f_fenshell','Fen-Pearl Shell',16,'shell',['#c8d8d0','#7a9a8a'],'A river shell, opened by hand. There is no pearl, only a very small scratch in the shape of a house.','fen'],
 /* the Sealed North */
 ['n_namebrick','Name-Brick',17,'brick',['#8a6a5a','#5a4034','#c9a890'],'A brick from the Hall of Names. It has exactly one name on it. Whoever wrote it had to do it with a cold hand, and spelled it right.','sealed'],
 ['n_sedgedoll','Sedge\'s Rag Doll',24,'sachet',['#c9a890','#7a5a44','#f0e0d0'],'A doll of rags and a button for one eye. It was loved to the stuffing. It has been waiting in a cold room for someone to come and say it was good.','sealed'],
 ['n_winterwick','Winter-Wick',19,'lantern',['#cfe0ff','#6a8ac0','#ffffff'],'A lantern-wick that stays lit in the snow. The first exiles carried a hundred of them north, and the Elders say they never ran out.','sealed'],
 /* the Hollow Wood */
 ['h_keepertulip','Pressed Keeper\'s Tulip',12,'bloom',['#e0603f','#f6d02a','#6aa03a'],'A red tulip, pressed in a Keeper\'s notebook. Every page has one. Nobody has ever found out what she was counting.','hollow'],
 ['h_redknot','Red Thread Knot',10,'knot',['#c0392b','#7a1a12'],'A thread knotted three times for the dead, once for the missing. This one has all four.','hollow'],
 ['h_hearthbead','Hearth-Ash Bead',13,'orb',['#e0803a','#7a3a12','#ffe0b0'],'Ash from the first Hearth, pressed into a bead. Emberwick children are given one the day they learn to carry a lantern.','hollow']
];
for(const f of SW_LORE){
  const it=ITEMS[f[0]]={name:f[1],sell:f[2],desc:f[5],use:'note',note:'You turn it over twice. It is lighter than it looks, and heavier than it should be.',nogift:true,glyph:f[3],gc:f[4],cat:'find',src:f[6],night:false,day:false};
  it.rar=f[2]<10?1:f[2]<15?2:f[2]<22?3:4;
}
const SW_LOREBY={}; for(const f of SW_LORE) (SW_LOREBY[f[6]]=SW_LOREBY[f[6]]||[]).push(f[0]);
{
  const fx={b_ashbead:'glow600 luck1',b_hobjug:'speed60',b_cradlebell:'rep1 luck2',b_wrenfeather:'forage2 luck1',c_siegepenny:'haggle2',c_arrowhead:'sure',c_mitten:'rep1',
    w_cairnstone:'dowse',w_whistle:'speed60 dowseTrail',w_needle:'dowse',f_marshcandle:'glow900 angler2',f_reedpipe:'luck2 forage2',f_fenshell:'angler3',
    n_namebrick:'rep2',n_sedgedoll:'luck3 rep1',n_winterwick:'glow1200 ward3',h_keepertulip:'luck2 rep1',h_redknot:'luck1 rep1',h_hearthbead:'ward2 glow300'};
  for(const id in fx){ FXD[id]=fx[id]; FXP[id]=brFxParse(fx[id]); ITEMS[id].desc+=' Use it: '+fxSummary(FXP[id])+'.'; }
}

/* ---------------- the biomes ---------------- */
const SWB=(o,sp)=>Object.assign({sp:sp,q:[0.01,0.01,0.04,0.03,0.02],tree:[0.05,0.2],wt:0.9},o);
/* plants: [name, painter, colours, extras, tier, weight?] */
const swP=(cat,def)=>{ const f={tree:TR,flower:FL,bush:BU,mush:MU,rock:RO,stump:ST}[cat]; const sp=f(def[0],def[1],def[2],def[3]||{}); sp.tier=def[4]||0; if(def[5]) sp.w=def[5]; return sp; };
const SW_BIOME_DEFS=[
 SWB({id:'ashwood',name:'The Burnt Wood',grass:['#4a4540','#524c46','#403b36'],blade:'#2f2a26',tuft:'#6a5f55',mapGrass:'#4a4540',mapTree:'#2a2420',decor:'pebbles',part:'embers',finds:SW_LOREBY.ashwood.concat(['s_hearthember','s_ashglass'])},{
  tree:[['Charred Oak','dead',['#2a2220','#4a3a34'],{},0],['Ember-Crowned Ash','round',['#3a2c26','#4a3a34','#5c463c','#7a5a48'],{bloom:'#ff7a2a'},1],['Weeping Cinder-Birch','birch',['#d8d0c4','#2a2420','#6a5a4a','#8a7258','#a88a6a'],{},1],['Hearthwood','glow',['#3a2a24','#6a3a22','#8a4a28','#c9703a','rgba(255,170,90,A)'],{halo:'rgba(255,150,70,0.12)'},3,4]].map(d=>swP('tree',d)),
  flower:[['Ash Poppy','poppy',['#d8d0c4','#5a4a3a','#4a5a3a'],{},0],['Ember Thistle','spike',['#e0603f','#f09a4a','#4a5a3a'],{},1],['Hearthbloom','glowbloom',['#ffb347','#fff0b0','#4a5a3a'],{glow:'255,170,90'},2,14],['Keeper\'s Lily','lily',['#fff0d0','#e8a050','#4a5a3a'],{},3,4]].map(d=>swP('flower',d)),
  bush:[['Scorched Bramble','bush',['#2a2420','#4a3a34','#6a5a4a'],{berry:'#7a2a2a'},0],['Ember Berry','bush',['#3a2c26','#5a4034','#7a5a44'],{berry:'#ff7a2a'},1],['Wisp-Heather','heath',['#6a5a8a','#9a8ac8','#c0b0e8'],{},2]].map(d=>swP('bush',d)),
  mush:[['Ash Cap','cap',['#8a8a90','#c0c0c8','#e9e2d0'],{},0],['Glowing Ashcap','cap',['#ff9a4a','#ffd0a0','#e9e2d0'],{glow:'255,150,70'},1],['Hum-Cap','cap',['#9a8ac8','#d0c0f0','#e0d8f0'],{glow:'168,140,230'},2],['Lantern Morel','tall',['#ffcf6a','#fff0b0','#f0e0b0'],{glow:'255,200,100'},3]].map(d=>swP('mush',d)),
  rock:[['Charred Stone','boulder',['#3a3430','#524a44','#6a625a'],{},0],['Ashglass Crystal','crystal',['#8a7ab8','#5a4a88','#d0c0ff'],{glow:'168,140,255'},2],['Hearthstone Geode','geode',['#4a3a34','#6a4a3a','#ff9a4a'],{core:'#fff0b0'},3]].map(d=>swP('rock',d)),
  stump:[['Charred Stump','stump',['#2a2220','#4a3a34','#3a2c28'],{},0],['Burnt Log','stump',['#2a2220','#4a3a34','#3a2c28'],{v:'log'},0],['Sleeping Root','stump',['#4a3a2a','#6a5a40','#5a4a34'],{moss:'#6a7a4a'},2]].map(d=>swP('stump',d))}),
 SWB({id:'cinder',name:'The Cinder Fields',grass:['#5a5650','#625e58','#4e4a44'],blade:'#3a3632',tuft:'#7a756c',mapGrass:'#5a5650',mapTree:'#3a3632',decor:'pebbles',part:'embers',finds:SW_LOREBY.cinder},{
  tree:[['Ghost Ash','dead',['#c8c0b4','#8a8478'],{},0],['Lone Cinder Pine','pine',['#4a3a2e','#2a3a2a','#3a4a32','#4a5a3c'],{},1]].map(d=>swP('tree',d)),
  flower:[['Fireweed','spike',['#d8507a','#f09ab0','#5a7a3a'],{},0],['Ember Thistle','spike',['#e0603f','#f09a4a','#4a5a3a'],{},0],['Ashen Daisy','daisy',['#e8e4dc','#c0b8a8','#5a6a4a'],{},1],['Last Marigold','sun',['#f6a02a','#7a3a12','#5a7a3a'],{},2]].map(d=>swP('flower',d)),
  bush:[['Cinder Scrub','dry',['#6a5a48','#8a7a62','#a89a80'],{},0],['Tumble-Ash','tumble',['#8a8478','#a8a094','#c8c0b4'],{},1]].map(d=>swP('bush',d)),
  mush:[['Soot Cap','cap',['#4a4640','#7a766e','#d8d0c0'],{},0],['Ember Spore-Cap','cap',['#ff7a2a','#ffc07a','#e9e2d0'],{glow:'255,130,50'},2]].map(d=>swP('mush',d)),
  rock:[['Slag Boulder','boulder',['#3a3834','#5a5650','#7a766e'],{},0],['Glassed Stone','crystal',['#7a8a9a','#4a5a6a','#c0d0e0'],{},2]].map(d=>swP('rock',d)),
  stump:[['Burnt Fence-Post','stump',['#3a2c24','#5a4a3a','#4a3a2e'],{},0],['Wagon-Wheel Stump','stump',['#5a4a34','#8a7a5a','#6a5a40'],{v:'log'},1]].map(d=>swP('stump',d))}),
 SWB({id:'ridge',name:'Weeping Ridge',grass:['#5a6458','#626c60','#4e5850'],blade:'#3a463a',tuft:'#7a8a74',mapGrass:'#5a6458',mapTree:'#3a4a3a',decor:'litter',finds:SW_LOREBY.ridge},{
  tree:[['Weeping Ash','willow',['#5a4a3e','#4a5a4a','#6a7a62'],{},0],['Ridge Pine','pine',['#4a3a2e','#2a4a38','#3a5e48','#4a7258'],{},1],['Old Standing Oak','round',['#5a4a34','#3a5a38','#4a6e46','#5a8458'],{},2]].map(d=>swP('tree',d)),
  flower:[['Ridge Harebell','bell',['#8a9ae0','#d0d8ff','#4a6a4a'],{},0],['Weeping Bellflower','bell',['#b09ae0','#e0d0ff','#4a6a4a'],{},1],['Stonecrop','succulent',['#d0a0b0','#f0d0d8','#6a8a6a'],{},1],['Cairn-Flower','orchid',['#e0d0a0','#a8803a','#4a6a4a'],{},2]].map(d=>swP('flower',d)),
  bush:[['Rock Heath','heath',['#8a6a8a','#b08ab0','#d0b0d0'],{},0],['Ridge Fern','fern',['#3a6a4a','#6aa87a'],{n:7,tip:'#c0e8c8'},1]].map(d=>swP('bush',d)),
  mush:[['Grey Cap','cap',['#9a9aa0','#c8c8d0','#e9e2d0'],{},0],['Fog-Cap','cap',['#b8c8e0','#e8f0ff','#e9e2d0'],{glow:'180,200,240'},2]].map(d=>swP('mush',d)),
  rock:[['Ridge Slab','slab',['#7a7a82','#9a9aa2','#5a5a62'],{},0],['Waymark Cairn','cairn',['#8a8a90','#a8a8b0','#c8c8d0'],{},1],['Weeping Stone','boulder',['#6a6a72','#8a8a92','#a8a8b0'],{moss:'#5a7a4a'},2]].map(d=>swP('rock',d)),
  stump:[['Split Log','stump',['#5a4a3a','#8a7a62','#6a5a46'],{v:'log'},0],['Hollowed Stump','stump',['#4a3a2a','#6a5a40','#5a4a34'],{moss:'#5a7a4a'},1]].map(d=>swP('stump',d))}),
 SWB({id:'fen',name:'The Ashen Fen',grass:['#4a5a4e','#526456','#404e44'],blade:'#324036',tuft:'#6a8a74',mapGrass:'#4a5a4e',mapTree:'#3a4a3e',mapWater:'#4a6a5e',waterTint:'rgba(70,95,80,0.40)',decor:'bog',part:'spores',finds:SW_LOREBY.fen},{
  tree:[['Ash Willow','willow',['#4a4238','#3a5a48','#58806a'],{},0],['Bog Snag','dead',['#4a4238','#6a6050'],{moss:'#5a7a5a'},0],['Lantern Alder','glow',['#2a3a34','#2a5a4a','#3a7a60','#58a888','rgba(150,255,210,A)'],{halo:'rgba(100,255,200,0.12)'},3,4]].map(d=>swP('tree',d)),
  flower:[['Fen Lily','lily',['#e8e8e0','#f6e27a','#3f6a4a'],{},0],['Cotton-Ash','cotton',['#e8e4dc','#c0b8a8','#4a6a4a'],{},0],['Pitcher Plant','spike',['#9a2a3a','#c9505a','#5a7a4a'],{},1],['Marsh Lantern','glowbloom',['#9affd0','#e8fff4','#3f6a4a'],{glow:'120,255,200'},2,10]].map(d=>swP('flower',d)),
  bush:[['Ash Reed','reed',['#6a7a52','#8a9a68','#4a5a38'],{head:'#6a4a2a',tall:19},0,160],['Fen Cattail','reed',['#5a8a4a','#7aaa5a','#3a5a2c'],{head:'#6a3f1e',tall:20},1],['Bog Myrtle','bush',['#3a5a3e','#4a7a52','#6a9a6a'],{berry:'#c9a02a'},1]].map(d=>swP('bush',d)),
  mush:[['Mist Cap','cap',['#9ab0a8','#d0e0d8','#e9e2d0'],{},0],['Fen Glimmer','cap',['#7affc8','#d4fff0','#e0f6ee'],{glow:'110,255,200'},2]].map(d=>swP('mush',d)),
  rock:[['Mud Stone','boulder',['#5a5a52','#7a7a70','#9a9a8e'],{moss:'#4a6a4a'},0]].map(d=>swP('rock',d)),
  stump:[['Sunken Log','stump',['#4a4238','#6a6050','#5a5042'],{v:'log',moss:'#5a7a5a'},0],['Reed-Root Hummock','stump',['#5a4a34','#8a7a5a','#6a5a40'],{moss:'#6a8a5a'},1]].map(d=>swP('stump',d))}),
 SWB({id:'sealed',name:'The Sealed North',grass:['#8aa098','#94aaa2','#7c928a'],blade:'#6a8078',tuft:'#b0c8c0',mapGrass:'#8aa098',mapTree:'#3a5a4a',mapWater:'#8ab8d8',waterTint:'rgba(160,210,255,0.42)',snow:true,ice:true,decor:'snow',part:'snow',finds:SW_LOREBY.sealed.concat(['s_keeperpin'])},{
  tree:[['Frost Pine','pine',['#5a4a3a','#2a4a42','#3a6a5a','#5a8a7a'],{snow:'#f6fbff'},0],['Rime Spruce','pine',['#4a3a2e','#244038','#325a4e','#4a7a6a'],{snow:'#f6fbff'},1],['Elder Winter-Oak','round',['#6a5a4a','#4a6a5a','#5a7e6e','#8aaa9a'],{},3,3]].map(d=>swP('tree',d)),
  flower:[['Snowdrop','snowdrop',['#ffffff','#c8e8c8','#4a7a5a'],{},0],['Frost Aster','daisy',['#d8e8ff','#a8c8f0','#4a7a5a'],{},1],['Winter Hearthbloom','snowdrop',['#ffb347','#fff0b0','#4a7a5a'],{},3,6]].map(d=>swP('flower',d)),
  bush:[['Frost Bramble','bush',['#3a5a52','#5a8a7a','#8ab0a0'],{berry:'#c0d8f0',snow:true},0],['Winterberry','bush',['#2a4a42','#3a6a5a','#5a8a7a'],{berry:'#e0402f',snow:true},1]].map(d=>swP('bush',d)),
  mush:[['Frost Cap','cap',['#b8d8f0','#e8f4ff','#e9e2d0'],{},1],['Winter Lantern-Cap','cap',['#cfe0ff','#ffffff','#e0e8f4'],{glow:'200,220,255'},2]].map(d=>swP('mush',d)),
  rock:[['Ice Boulder','ice',['#b8d8f0','#8ab8e0','#e8f4ff'],{},0],['Rime Crystal','crystal',['#a8d0f0','#6a9ad0','#f0f8ff'],{glow:'170,210,255'},2]].map(d=>swP('rock',d)),
  stump:[['Frozen Log','stump',['#6a5a4a','#a89a88','#8a7a68'],{v:'log',snow:true},0]].map(d=>swP('stump',d))}),
 SWB({id:'hollow',name:'The Hollow Wood',grass:['#3f7a45','#468650','#38703d'],blade:'#2f5f33',tuft:'#6aa86a',mapGrass:'#3f7a45',mapTree:'#2a5a30',decor:'litter',part:'fly',finds:SW_LOREBY.hollow},{
  tree:[['Hollow Oak','round',['#5a3f2a','#2f5a30','#3f7a3c','#58964c'],{},0],['Hearth-Ash','round',['#6a4a30','#3a6a34','#4a8240','#6aa05a'],{ground:'#e0803a'},1],['Lantern Birch','birch',['#ece8dc','#3b3b3b','#4a8a3a','#68a85a','#8ac478'],{},1]].map(d=>swP('tree',d)),
  flower:[['Hollow Violet','bell',['#7a6ad8','#d0c8ff','#2f5a30'],{},0],['Keeper\'s Tulip','tulip',['#e0603f','#f6d02a','#3f7a3a'],{},1],['Emberwick Rose','rose',['#c0392b','#7a1a12','#3f6a30'],{},2,7]].map(d=>swP('flower',d)),
  bush:[['Hearth Hawthorn','bush',['#2f5a30','#47804a','#58964c'],{berry:'#c0392b'},0],['Red Currant','bush',['#2f5a30','#47804a','#6aa05a'],{berry:'#d8302a'},1]].map(d=>swP('bush',d)),
  mush:[['Hollow Cap','cap',['#d65a5a','#ffffff','#e9e2d0'],{},0],['Lantern Cap','cap',['#ffb85a','#ffe0a0','#e9e2d0'],{glow:'255,190,100'},2]].map(d=>swP('mush',d)),
  rock:[['Hearth-Stone','boulder',['#6a6058','#8a8078','#aaa098'],{moss:'#4f8f45'},0],['Ember-Veined Rock','geode',['#5a4a44','#7a5a4a','#ff9a4a'],{core:'#fff0b0'},3]].map(d=>swP('rock',d)),
  stump:[['Hollow Stump','stump',['#5a3f2a','#8a6238','#6a4a2a'],{moss:'#4f8f45'},0],['Lantern-Post Log','stump',['#6b4a2f','#a97c50','#8a6238'],{v:'log'},1]].map(d=>swP('stump',d))})
];
for(const b of SW_BIOME_DEFS){
  b.sps=[];
  for(const cat of WL_CATS){
    const list=b.sp[cat]||(b.sp[cat]=[]);
    list.forEach((sp,i)=>{
      sp.id=b.id+':'+cat+':'+i; sp.cat=cat; sp.biome=b.id; sp.rank=i; sp.hand=true; sp.rare=sp.tier>=3; sp.w=sp.w||WL_PWT[sp.tier]*(sp.tier<=1?3:1);
      WL_SPECIES[sp.id]=sp; WL_SPLIST.push(sp); b.sps.push(sp);
    });
  }
  b.style={id:'wl_'+b.id,biome:b,label:b.name,plaza:'dirt',snow:!!b.snow,grass:b.grass,blade:b.blade,tuft:b.tuft,map:{plaza:'#c9b48a',grass:b.mapGrass},roofs:ROOFS,walls:WALLS,part:b.part||null};
  b.pQ=[]; let acc=0; for(const q of b.q){ acc+=q; b.pQ.push(acc); }
  WL_BIOMES.push(b); WL_BY[b.id]=b;
  WL_FINDS_BY[b.id]=[]; WL_BPFX[b.id]=b.name.replace(/^The /,'');
  for(const id of (b.finds||[])){ if(WL_FIND[id]||ITEMS[id]){ WL_FIND[id]=ITEMS[id]; WL_FINDS_BY[b.id].push(id); } }
}
/* the lore finds (and the Ember finds) are Collection Log entries; Ember finds stay under 'story' */
for(const f of SW_LORE) WL_FIND[f[0]]=ITEMS[f[0]];

/* ---------------- where they are ---------------- */
function swBiomeKey(x,y){
  const z=swZoneOf(x,y); if(z) return z;
  if(inBW(x,y)) return 'ashwood';
  if(x>=WX0-3&&x<WX0+WSZ+3&&y>=WY0-3&&y<WY0+WSZ+3&&!(x>=RX0-4&&x<RX0+RW+4&&y>=RY0-4&&y<RY0+RH+4)) return 'hollow';
  return '';
}
{
  const _wb=wlBiomeAt;
  wlBiomeAt=function(x,y){ const k=swBiomeKey(x,y); if(k) return WL_BY[k]; return _wb(x,y); };
}

/* ---------------- essences, and brews made from them ---------------- */
Object.assign(BR_ESS,{ashwood:'Burnt Wood',cinder:'Cinder',ridge:'Ridge',fen:'Fen',sealed:'Winter',hollow:'Hollow'});
const SW_ESSBREW=[
 ['ashwood','Ashwood Ember-Tea',['#ff9d2e','#7a3a12','#ffe0b0'],'ward5 glow1800','Smoke, bark and a little courage. Calms the hum and lights your way for half an hour.'],
 ['cinder','Cinder-Spirit',['#c0c0c8','#5a5650','#ffffff'],'speed120 forage4','Grey as old ash, hot as a banked fire. Your feet remember how to run.'],
 ['ridge','Waymark Cordial',['#9a9aa0','#5a5a62','#e8e8f0'],'dowse luck3 speed60','Tastes of cold stone and long distances. It points at what is worth walking to.'],
 ['fen','Fen-Candle Draught',['#9ad8c0','#3a7a66','#e8fff4'],'glow2400 angler6 dowseTrail','Pond-light in a cup. The fish forgive you, and the trail shows itself.'],
 ['sealed','Winter-Hearth Tonic',['#cfe0ff','#6a8ac0','#ffffff'],'ward8 glow1800 charm3','The warmth of a house in the snow. Shopkeepers soften, and the ward goes quiet.'],
 ['hollow','Hollow Lantern-Wine',['#e0803a','#7a3a12','#ffe0b0'],'luck5 forage5 rep1','Red as the thread on a Hollow door. Good luck, good foraging, and a little standing in the town you drink it in.']
];
for(const b of SW_ESSBREW){
  BR_RECIPES.push({id:'ess_'+b[0],name:b[1],tier:1,req:[{c:'e:'+b[0],n:1,g:0},{c:'any',n:3,g:0}],cost:30,fx:b[3],col:b[2],desc:b[4]+' Needs a drop of '+BR_ESS[b[0]]+' Essence.'});
  const id='p_ess_'+b[0], list=brFxParse(b[3]);
  FXD[id]=b[3]; FXP[id]=list;
  ITEMS[id]={name:b[1],price:0,cat:'potion',desc:b[4]+' Use it: '+fxSummary(list)+'.',use:'note',note:'',nogift:true,glyph:'flask',gc:b[2]};
}

/* ---------------- the new places announce themselves ---------------- */
/* (the first-visit toast in wilds.js already handles every biome; these lines only add a line of story the first time) */
const SW_ARRIVE={
  cinder:'The ground is soft with old ash. Somebody planted a fence here, once. The posts are still in rows.',
  ridge:'A long grey ridge, weeping thin streams from every crack. Cairns stand along it like patient ducks.',
  fen:'A drowned country of reeds and slow water. Little green lights drift between the stalks. They are not wisps. They are, you decide, candles.',
  sealed:'It is cold in a way the rest of the world has forgotten. Everything is quiet, and everything is watching.',
  hollow:'The Hollow Wood. Red thread is tied to every third branch, and nobody has said why.',
  ashwood:'The Burnt Wood. Four slow notes, from every tree.'
};
{
  const seen={};
  const _su=storyUpdate; let t=0;
  storyUpdate=function(dt){
    _su(dt);
    if(g.mode!=='play'||g.scene!=='world'||!g.story) return;
    t-=dt; if(t>0) return; t=0.8;
    const k=swBiomeKey(Math.floor(g.px/TS),Math.floor((g.py-2)/TS)); if(!k||seen[k]) return;
    const w=WD(); w.arr=w.arr||{};
    seen[k]=1; if(w.arr[k]) return; w.arr[k]=1;
    if(SW_ARRIVE[k]&&g.story.s2&&g.story.s2.ch) setTimeout(()=>{ if(g.mode==='play') toast(SW_ARRIVE[k],5200); },900);
  };
}
