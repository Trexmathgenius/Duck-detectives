'use strict';
/* ===== THE VERSES TOUCH THE WORLD (v1.24) =====
   Every verse already did something for you (a buff, a light, a coat). Now each one also answers whatever you are facing:
   a duck, a plant, a rock, the water, a lamp, a wall, the ground, even one of the Umbral Wood's obstacles. Nothing here is a
   reskin of an old spell: each verse answers in its own character (Truthlight finds what is true, Softfall forgives, Standfast
   braces, Lanternwalk leads, Quietcoat listens, Remembrance recalls, Bloom restores, Banner tempts). */

const VRANGE=130;
const vKey=(tag,tg)=>{ const x=XS(); x.vt=x.vt||{}; const k=tag+':'+(tg.tx!==undefined?tg.tx+','+tg.ty:(tg.n&&tg.n.name)||'air'); if(x.vt[k]===g.day) return false; x.vt[k]=g.day; return true; };
const vName=tg=>{ try{ return spNpcName(tg.n); }catch(e){ return (tg.n&&tg.n.name)||'the duck'; } };
function vFlash(tg,cols,n){
  spRing(tg.x,tg.y,cols[0],3,30,0.6,2.5); spBurst(tg.x,tg.y,cols,n||16,70,{up:30,g:-14,life:0.8}); spLight(tg.x,tg.y,90,cols[1]||cols[0],0.55);
}
/* the Umbral Wood's five obstacles each have a verse that can also answer them */
function vObstacle(tg,verse,cols){
  if(!(tg&&tg.k==='tile'&&tg.cat==='uobs')) return null;
  const OK={Truthlight:[USHADE],Lanternwalk:[USHADE],Softfall:[UFOG],Standfast:[UBOULD,UCURSE],Bloom:[UTHORN]};
  const i=uwObstacle(tg.tx,tg.ty), nm={[UTHORN]:'thorns',[UFOG]:'fog',[UBOULD]:'boulder',[USHADE]:'shadow',[UCURSE]:'curse'}[tg.t]||'obstacle';
  if(i>=0&&(OK[verse]||[]).indexOf(tg.t)>=0){ spUwClear(i,tg.t,tg.tx,tg.ty); return ''; }
  vFlash(tg,cols,8);
  return 'The '+nm+' hears '+verse+' and is unmoved. It wants something else.';
}
function vSeek(cols){
  const tl=xPlayerTile(); let best=null; const rx0=Math.floor((tl.x+24)/REG), ry0=Math.floor((tl.y+24)/REG);
  for(let dy=-6;dy<=6;dy++) for(let dx=-6;dx<=6;dx++){ const t=getTown(rx0+dx,ry0+dy); if(!t||g.towns.has(t.key)) continue; const d=Math.hypot(t.cx-tl.x,t.cy-tl.y); if(!best||d<best.d) best={t:t,d:d}; }
  if(!best) return 'The lantern circles you once and settles. Every town within a long walk is already on your map.';
  const ang=Math.atan2(best.t.cy-tl.y,best.t.cx-tl.x), i=((Math.round(ang/(Math.PI/4))%8)+8)%8;
  const to={x:g.px+Math.cos(ang)*230,y:g.py-14+Math.sin(ang)*230};
  spFly('Seek',{x:g.px+14,y:g.py-30},to,()=>{ spRing(to.x,to.y,cols[1],2,30,0.8,2); spBurst(to.x,to.y,cols,14,60,{life:0.8}); },{spd:200,size:2.2,wob:10,wa:1.8});
  return 'The lantern leans '+['east','south-east','south','south-west','west','north-west','north','north-east'][i]+' '+ARROWS[i]+'. About '+Math.round(best.d/5)*5+' waddles to a town you have not found.';
}
const TRUE_LINES=['"You saw that," says {n}, very quietly. "Most people look past it."','{n} holds still in the light. Nothing in it is a lie, and {n} seems relieved.','The light finds the tired part of {n}, and stops, and does not press. {n} nods.','{n} says, "That is the first honest light anyone has turned on me this year."'];
const EAVES=['You hear {n} say, to nobody, that the price is a little lower than they pretend.','{n} mutters a number, and then a smaller one. You file both.','You overhear {n} counting: coins, days, favours. The favours are the larger sum.','{n} says a name softly. It is not a name they use aloud.'];
const FOREGIVE=['{n} watches the petals land and does not hurry to leave. Something unclenches.','The petals settle in {n}\'s feathers. {n} brushes at them, and then, quietly, stops.'];
const STEADY=['{n} stands a little straighter in the ring, as if remembering they have a spine.','{n} breathes in. The ring holds the out-breath for them.'];
const REMLINE={npc:'Remembrance asks {n} who they were before today. It answers in a single, particular image, and you keep it.',plant:'The plant remembers every paw that passed it, and every one that knelt.',tree:'The tree keeps its rings as a ledger. Your name is not in it yet. That is fine.',rock:'The rock remembers being a mountain. It does not hold a grudge.',water:'The water has forgotten everything. It remembers that, and is at peace.',light:'The flame remembers every face it has warmed. You are among them now.',crumbs:'The crumbs remember a hand, a pocket, a hurry.',build:'The wall remembers its builder\'s hands, and the weather since.',air:'The air remembers the last duck who stood here. They were hopeful.'};
const hashS=s=>{ let h=0; for(const ch of String(s)) h=(h*31+ch.charCodeAt(0))|0; return Math.abs(h); };
const WX_NAME={clear:'clear and bright',fog:'foggy',rain:'rainy',storm:'stormy',snow:'snowy',wind:'windy',sun:'sunny'};

const VT={
  Truthlight(tg,v){
    const cols=v.col, x=XS();
    const ob=vObstacle(tg,'Truthlight',cols); if(ob!==null) return ob;
    if(tg.k==='npc'){
      const nm=vName(tg), A=ART(); vFlash(tg,cols,22);
      let out=TRUE_LINES[hashS(nm)%TRUE_LINES.length].replace(/\{n\}/g,nm);
      A.touched=A.touched||{};
      if(!A.touched['T'+nm]){ A.touched['T'+nm]=1; S4.note('truth',1); out+=' (Candour, noted.)'; }
      return out;
    }
    if(tg.k!=='tile') return '';
    vFlash(tg,cols,18);
    if(tg.cat==='plant'||(tg.cat==='tree'&&tg.t!==T.DARK)){
      if(!vKey('T',tg)) return 'The light has already shown you everything this one has today.';
      spCollect({tx:tg.tx,ty:tg.ty,t:tg.t},'The light shows you what is ripe on'); return '';
    }
    if(tg.cat==='rock'){
      if(!vKey('Tr',tg)) return 'The seam is bright, and empty. You took what it had.';
      const n=2+Math.floor(rnd()*3); g.crumbs+=n; coin(); return 'Truthlight finds the seam that was always there. '+n+' crumbs fall out, as if embarrassed.';
    }
    if(tg.cat==='water'){ fxGive('angler',2); return 'The light goes under the water and shows you where the fish are lying. (Fishing is easier.)'; }
    if(tg.cat==='light'){ const k=(typeof wxKind==='function')?wxKind(g.day+1):'clear'; return 'The flame leans, and tells you plainly: tomorrow will be '+(WX_NAME[k]||k)+'.'; }
    if(tg.cat==='crumbs'){ if(!vKey('Tc',tg)) return 'Nothing more hides in these today.'; const n=1+Math.floor(rnd()*2); g.crumbs+=n; coin(); return 'The light shows you the crumbs that were stuck underneath. +'+n+'.'; }
    if(tg.cat==='build') return 'The wall is honest. It is also a wall. Truthlight lights the doorway, and that is all it has to say.';
    return '';
  },
  Softfall(tg,v){
    const cols=v.col, x=XS();
    const ob=vObstacle(tg,'Softfall',cols); if(ob!==null) return ob;
    if(tg.k==='npc'){
      const nm=vName(tg), A=ART(); A.touched=A.touched||{}; vFlash(tg,cols,16);
      if(!A.touched['S'+nm]){ A.touched['S'+nm]=1; const n=2+Math.floor(rnd()*3); g.crumbs+=n; coin(); S4.note('mercy',1); return FOREGIVE[hashS(nm)%FOREGIVE.length].replace(/\{n\}/g,nm)+' They press '+n+' crumbs into your wing, and are embarrassed by it.'; }
      return FOREGIVE[hashS(nm)%FOREGIVE.length].replace(/\{n\}/g,nm);
    }
    if(tg.k!=='tile') return '';
    vFlash(tg,cols,16);
    if(tg.cat==='gone'){
      const w=WD(); delete w.gone[tg.tx+','+tg.ty]; tileCache.delete(tkey(tg.tx,tg.ty));
      spBurst(tg.x,tg.y,['#ffb3d1','#ffe1ee','#fff6f0'],24,60,{up:40,g:-20,life:0.9});
      return 'The petals sink into the bare ground, and what you took from it grows back, a little ashamed of the fuss.';
    }
    if(tg.cat==='plant'||(tg.cat==='tree'&&tg.t!==T.DARK)){
      if(!vKey('S',tg)) return 'The petals settle, and the plant is content. It has given what it had today.';
      spCollect({tx:tg.tx,ty:tg.ty,t:tg.t},'The petals ask, and it gives'); return '';
    }
    if(tg.cat==='rock'){
      const key=tg.tx+','+tg.ty; x.rocks=x.rocks||{};
      if(x.rocks[key]){ delete x.rocks[key]; return 'The petals settle on the rock, and it lets go of its grudge. Stone may ask again.'; }
      return 'The petals settle on the rock. It was not angry. It is a little touched, though.';
    }
    if(tg.cat==='water'){ const was=(x.rodWear||0)>0; x.rodWear=0; fxGive('angler',1); return 'The water takes the petals and goes still.'+(was?' Your rod\'s frayed line knits itself whole.':'')+' (Fishing is a little easier.)'; }
    if(tg.cat==='light') return 'The flame steadies and burns lower, the way a lamp does when the house is asleep.';
    if(tg.cat==='crumbs') return 'The petals fall on the crumbs, and for a moment it looks like somebody\'s supper.';
    return '';
  },
  Standfast(tg,v){
    const cols=v.col, x=XS();
    const ob=vObstacle(tg,'Standfast',cols); if(ob!==null) return ob;
    if(tg.k==='npc'){
      const nm=vName(tg), A=ART(); A.touched=A.touched||{}; vFlash(tg,cols,18);
      if(!A.touched['F'+nm]){ A.touched['F'+nm]=1; S4.note('trust',1); }
      return STEADY[hashS(nm)%STEADY.length].replace(/\{n\}/g,nm);
    }
    if(tg.k!=='tile') return '';
    vFlash(tg,cols,16);
    if(tg.cat==='rock'){
      const key=tg.tx+','+tg.ty; x.rocks=x.rocks||{};
      if(x.rocks[key]&&x.rocks[key]+3>g.day) return 'Standfast holds the rock steady. It has been asked already; give it a few days.';
      x.rocks[key]=g.day; const n=3+Math.floor(rnd()*4); g.crumbs+=n; coin();
      spBurst(tg.x,tg.y,['#8a8f98','#c3c8cf','#ffcf8a'],22,100,{k:'dot',life:0.7,g:200,r:2.4});
      return 'You set your weight beside the rock and the ring holds the stone still while the seam opens. '+n+' crumbs, no pebble, no mess.';
    }
    if(tg.cat==='tree'||tg.cat==='plant'){
      if(!vKey('F',tg)) return 'The ring holds. The roots hold. Neither has anything more to give today.';
      if(tg.t===T.DARK) return 'The ring holds the dark tree still. It does not mind being held.';
      spCollect({tx:tg.tx,ty:tg.ty,t:tg.t},'You hold steady and gather from'); return '';
    }
    if(tg.cat==='water') return 'The ring sets on the water\'s edge, and holds. You will not slip here today.';
    if(tg.cat==='build') return 'You set your weight against the wall. The wall, for once, agrees.';
    if(tg.cat==='light') return 'The flame stands up straight in its own light.';
    return '';
  },
  Lanternwalk(tg,v){
    const cols=v.col;
    const ob=vObstacle(tg,'Lanternwalk',cols); if(ob!==null) return ob;
    if(tg.k==='npc'){
      const nm=vName(tg); vFlash(tg,cols,14);
      const A=ART(); A.touched=A.touched||{};
      let out='The lantern drifts to '+nm+' and hovers there, patient, like a child at a window.';
      if(!A.touched['L'+nm]){ A.touched['L'+nm]=1; S4.note('kin',1); out+=' (Tenderness, noted.)'; }
      return out+' '+vSeek(cols);
    }
    return (tg.k==='tile'?'':'')+vSeek(cols);
  },
  Quietcoat(tg,v){
    const cols=v.col;
    if(tg.k==='npc'){
      const nm=vName(tg), A=ART(); A.touched=A.touched||{}; vFlash(tg,cols,10);
      if(!vKey('Q',tg)) return nm+' has said what they will say today. The coat is not for pressing.';
      fxGive('haggle',2); return EAVES[hashS(nm+g.day)%EAVES.length].replace(/\{n\}/g,nm)+' (You will haggle better today. You did not lie, and you did not ask.)';
    }
    if(tg.k!=='tile') return '';
    vFlash(tg,cols,12);
    if(tg.cat==='water'){ fxGive('angler',2); return 'You settle beside the water in the coat, a grey stone with opinions. The fish forget you are there. (Fishing is easier.)'; }
    if(tg.cat==='crumbs'){ return 'You are too quiet to be worth stealing from, and so are the crumbs.'; }
    if(tg.cat==='build') return 'You stand against the wall. The wall considers you part of itself.';
    return '';
  },
  Remembrance(tg,v){
    const cols=v.col, A=ART(); A.frag=A.frag||{};
    let key, label, cat=tg.k==='npc'?'npc':(tg.cat||'air');
    if(tg.k==='npc'){ const nm=vName(tg); key='n:'+nm; label=nm; }
    else { const tx=tg.tx!==undefined?tg.tx:Math.floor(g.px/TS), ty=tg.ty!==undefined?tg.ty:Math.floor(g.py/TS); let b=null; try{ b=wlBiomeAt(tx,ty); }catch(e){} key='b:'+(b?b.id:'road')+':'+cat; label=b?(b.name||b.id):'the road'; }
    if(tg.k!=='air') vFlash(tg,cols,16);
    const line=(REMLINE[cat]||REMLINE.air).replace(/\{n\}/g,label);
    if(A.frag[key]) return line+' (You have this one already.)';
    A.frag[key]=1; const cnt=Object.keys(A.frag).length;
    let out=line+' (Memory fragment '+cnt+'.)';
    if(cnt===3){ g.crumbs+=8; coin(); out+=' The Art is pleased: 8 crumbs.'; }
    else if(cnt===6){ try{ s2led('kin',1); }catch(e){} out+=' You are beginning to be of this place. (Kinship, noted.)'; }
    else if(cnt===10){ fxGive('luck',3); g.crumbs+=15; coin(); out+=' Ten places remember you. 15 crumbs, and luck for the day.'; }
    return out;
  },
  Bloom(tg,v){
    const cols=v.col, x=XS();
    const ob=vObstacle(tg,'Bloom',cols); if(ob!==null) return ob;
    const w=WD(); let n=0; const p=s2tile(), out=[];
    for(const k of Object.keys(w.gone||{})){
      const [gx,gy]=k.split(',').map(Number);
      if(Math.hypot(gx-p.x,gy-p.y)>3.5) continue;
      delete w.gone[k]; tileCache.delete(tkey(gx,gy)); n++;
      spBurst((gx+0.5)*TS,(gy+0.5)*TS-6,['#7fe09a','#ffd1e8','#fff6c8'],12,50,{up:40,g:-20,life:0.9});
      if(n>=12) break;
    }
    if(n) out.push(n+' bare patch'+(n>1?'es':'')+' close by remember being green.');
    try{
      const em=swEmberNear(5);
      if(em.length){ BS().ess.ember=(BS().ess.ember||0)+1; if(swStarted()) SWS().ember++; out.push('Ember plants lean in; a drop of Ember Essence gathers. (Ember: '+BS().ess.ember+')'); }
    }catch(e){}
    if(tg.k==='npc'){
      const nm=vName(tg); vFlash(tg,cols,14);
      out.push(nm+' looks at the green and then at you. "You asked the land first," they say. It is not a question.');
    } else if(tg.k==='tile'){
      vFlash(tg,cols,16);
      if(tg.cat==='gone'){ const ww=WD(); delete ww.gone[tg.tx+','+tg.ty]; tileCache.delete(tkey(tg.tx,tg.ty)); out.push('The bare place at your feet is green again.'); }
      else if(tg.cat==='tree'||tg.cat==='plant') out.push('You ask the '+(tg.cat==='tree'?'tree':'plant')+' and it opens a little, and keeps what it has. Bloom restores. It does not take.');
      else if(tg.cat==='rock') out.push('Moss spreads over the rock, quietly. It looks pleased with itself.');
      else if(tg.cat==='water') out.push('Reeds lift at the water\'s edge. Something small moves between them.');
      else if(tg.cat==='build') out.push('A creeper climbs the wall for a moment and decides to stay.');
    }
    return out.join(' ');
  },
  Banner(tg,v){
    const cols=v.col;
    if(tg.k==='npc'){
      const nm=vName(tg), n=8+Math.floor(rnd()*8); g.crumbs+=n; coin();
      return nm+' hands you '+n+' crumbs without being asked. It feels like holding something that is not yours.';
    }
    vFlash(tg,cols,22);
    if(tg.k==='tile'&&(tg.cat==='tree'||tg.cat==='rock')) return 'The Banner stands over the '+(tg.cat==='tree'?'tree':'rock')+'. It bows to nothing, and you take that as the Art\'s approval.';
    if(tg.k==='tile'&&tg.cat==='water') return 'The Banner lies on the water like gold. Nothing is made to bow. It is only beautiful, which is permitted.';
    return '';
  }
};

for(const v of ARTV){
  const f=VERSEFX[v.n], t=VT[v.n]; if(!f||!t) continue;
  VERSEFX[v.n]=function(vv){
    const a=f(vv); let b='';
    try{ const tg=spScan('Mend',VRANGE); b=t(tg,vv)||''; }catch(e){ console.error(e); }
    return [a,b].filter(Boolean).join(' ');
  };
}

/* say what each verse also does, where the player will read it */
const VTOUCH={
  Truthlight:'Face something: it harvests the ripe, finds a rock\'s seam, shows where fish lie, forecasts tomorrow at a flame, clears the Umbral shadow.',
  Softfall:'Face something: it regrows bare ground, reconciles a rock, calms water, and gives a duck a moment (once each).',
  Standfast:'Face something: it holds a rock still while it opens, braces a duck, and clears the Umbral boulder and curse.',
  Lanternwalk:'Cast anywhere: the lantern points to the nearest town you have not found. It clears the Umbral shadow too.',
  Quietcoat:'Face a duck to overhear and haggle better; face water to fish unseen.',
  Remembrance:'Face anything to collect a memory of the place; they add up to small rewards.',
  Bloom:'Regrows bare patches nearby, wakes Ember plants, and clears the Umbral thorns.',
  Banner:'Face a duck and they will pay you, and you will have broken the second law. Face an empty hill.'
};
for(const v of ARTV){ v.blurb+=' '+VTOUCH[v.n]; const e=SPELLS.find(s=>s[0]===v.n); if(e) e[1]=v.blurb; }
