'use strict';
/* ===== Duck Kingdom: drawing ===== */
function kFloorTile(c,x,y,px,py){ rect(c,px,py,TS,TS,((x+y)&1)?'#cfc8b6':'#c6bfad'); c.fillStyle='#b3ab97'; c.fillRect(px,py,TS,1); c.fillRect(px,py,1,TS); rect(c,px+4,py+4,5,2,'rgba(255,255,255,0.35)'); }
function kGround(c,x,y,px,py){
  if(kingdomPaved(x,y)){ const lx=x-KX, ly=y-KY; if(ly>=9&&ly<=24&&Math.abs(lx)<=22) kFloorTile(c,x,y,px,py); else drawPlaza(c,x,y,px,py,null); }
  else{
    const lx=x-KX, ly=y-KY;
    if(!inCityL(lx,ly)&&inK(x,y)&&(kZone(lx,ly)==="Gordamom's Siege Field"||kZone(lx,ly)==='The Burnt Wood')) drawGrass(c,x,y,px,py,0.0,null),rect(c,px,py,TS,TS,'rgba(40,30,20,0.28)');
    else drawGrass(c,x,y,px,py,0,null);
  }
}
function kStoneBase(c,x,y,px,py,base,line){
  rect(c,px,py,TS,TS,base);
  c.fillStyle=line;
  for(let r=0;r<4;r++){ c.fillRect(px,py+r*8,TS,1); const off=(r&1)?0:8; c.fillRect(px+off,py+r*8,1,8); c.fillRect(px+off+16,py+r*8,1,8); }
}
function drawKTile(c,x,y,t,px,py,time,objs,night){
  const lx=x-KX, ly=y-KY;
  switch(t){
    case KWALL: {
      kStoneBase(c,x,y,px,py,'#9aa1ad','#7f8693');
      rect(c,px,py,TS,10,'#868d9a');
      for(let i=0;i<4;i+=2) rect(c,px+i*8,py,8,9,'#b8bec9');
      rect(c,px,py+9,TS,2,'#6c7380'); rect(c,px,py+TS-3,TS,3,'rgba(0,0,0,0.18)');
      break; }
    case KSTONE: {
      kStoneBase(c,x,y,px,py,'#8a919e','#727987');
      if(hash(x,y,5600)<0.035){ rect(c,px+14,py+8,4,13,'#2a2f3a'); rect(c,px+11,py+12,10,3,'#2a2f3a'); }
      rect(c,px,py,TS,2,'rgba(255,255,255,0.1)'); rect(c,px,py+TS-3,TS,3,'rgba(0,0,0,0.2)');
      break; }
    case KSLATE: {
      rect(c,px,py,TS,TS,'#46608f');
      c.fillStyle='#34496f'; for(let i=0;i<4;i++){ c.fillRect(px,py+i*8+6,TS,2); const o=(i&1)?0:16; c.fillRect(px+o,py+i*8,1,6); c.fillRect(px+o+16,py+i*8,1,6); }
      rect(c,px,py,TS,2,'rgba(255,255,255,0.18)');
      if(lx===0&&ly===-12){ const by=py-18; rect(c,px+15,by,2,26,'#e0b84a'); c.fillStyle='#e0b84a'; c.beginPath(); c.moveTo(px+17,by); c.lineTo(px+30+Math.sin(time*4)*2,by+5); c.lineTo(px+17,by+10); c.fill(); }
      break; }
    case KCWIN: {
      kStoneBase(c,x,y,px,py,'#8a919e','#727987');
      rect(c,px+8,py+4,16,22,'#4a3a5a'); ell(c,px+16,py+6,8,5,'#4a3a5a');
      const lit=night||NIGHT>0.12;
      rect(c,px+10,py+7,12,17,lit?'#ffd98a':'#5d7396'); c.fillStyle='#4a3a5a'; c.fillRect(px+15,py+7,2,17); c.fillRect(px+10,py+14,12,2);
      if(NIGHT>0.12) lights.push({x:px+16,y:py+16,r:60,s:0.7,w:0.8});
      break; }
    case KPORT: {
      const col=lx+1, row=ly-6;
      kStoneBase(c,x,y,px,py,'#7d8491','#666d7a');
      if(row===0){ c.fillStyle='#2a2018'; c.beginPath(); c.arc(px+(col===1?16:col===0?32:0),py+TS+2,22,Math.PI,0); }
      rect(c,px,py,TS,TS,'#2a2018');
      c.fillStyle='#8c929c'; for(let i=0;i<4;i++) c.fillRect(px+i*8+2,py,3,TS);
      c.fillStyle='#6d737d'; c.fillRect(px,py+9,TS,3); c.fillRect(px,py+22,TS,3);
      if(row===0){ rect(c,px,py,TS,3,'#c3a64a'); }
      if(col===1&&row===1){ circ(c,px+16,py+16,6,'#e0b84a'); circ(c,px+16,py+16,3,'#2a2018'); rect(c,px+15,py+17,2,5,'#2a2018'); }
      if(col===0) rect(c,px,py,3,TS,'#3b2a18'); if(col===2) rect(c,px+TS-3,py,3,TS,'#3b2a18');
      break; }
    case KHEDGE: {
      kGround(c,x,y,px,py);
      rect(c,px,py+3,TS,TS-3,'#2d6a35'); rect(c,px,py+3,TS,5,'#3b8442'); rect(c,px,py+TS-4,TS,4,'#245529');
      for(let i=0;i<6;i++) rect(c,px+((hash(x,y,5610+i)*28)|0),py+6+((hash(x,y,5620+i)*20)|0),3,2,hash(x,y,5630+i)<0.5?'#4aa050':'#1f4a26');
      break; }
    case KCARPET: {
      rect(c,px,py,TS,TS,'#a8232f'); rect(c,px+4,py,2,TS,'#8a1a24'); rect(c,px+26,py,2,TS,'#8a1a24');
      if(tileAt(x-1,y)!==KCARPET) rect(c,px,py,4,TS,'#e0b84a'); if(tileAt(x+1,y)!==KCARPET) rect(c,px+TS-4,py,4,TS,'#e0b84a');
      if(y%2===0) rect(c,px+13,py+14,6,4,'#c93a46');
      break; }
    case KFLAG: {
      kGround(c,x,y,px,py);
      objs.push({y:py+TS,k:'fn',f:()=>{
        ell(c,px+16,py+30,6,2,'rgba(0,0,0,0.25)'); rect(c,px+15,py-30,3,60,'#6b4a2f'); circ(c,px+16,py-31,3,'#e0b84a');
        const w=Math.sin(time*3+x)*3; c.fillStyle=(lx===-70||ly===25)?'#7a1f1f':'#a8232f'; c.beginPath(); c.moveTo(px+18,py-28); c.lineTo(px+34+w,py-24); c.lineTo(px+34+w*0.5,py-8); c.lineTo(px+18,py-6); c.closePath(); c.fill();
        circ(c,px+26+w*0.6,py-16,3,'#e0b84a');
      }});
      break; }
    case KBRIDGE: case KDOCK: {
      const ew=Math.abs(lx)>58&&Math.abs(ly)<10;
      if(t===KBRIDGE) drawWater(c,x,y,px,py,time);
      else drawWater(c,x,y,px,py,time);
      rect(c,px,py,TS,TS,'#a8793f');
      c.fillStyle='#7a5429';
      if(ew||t===KDOCK){ for(let i=0;i<4;i++) c.fillRect(px+i*8,py,1,TS); rect(c,px,py,TS,3,'#5a3d22'); rect(c,px,py+TS-3,TS,3,'#5a3d22'); }
      else { for(let i=0;i<4;i++) c.fillRect(px,py+i*8,TS,1); rect(c,px,py,3,TS,'#5a3d22'); rect(c,px+TS-3,py,3,TS,'#5a3d22'); }
      break; }
    case KFLOOR: {
      kFloorTile(c,x,y,px,py);
      break; }
    case KFOUNT: {
      const ax=lx, ay=ly;
      /* 3x3 royal fountains centred on (+-9,16) */
      const cx=ax<0?-9:9;
      for(const o of [0]){}
      if(ax===cx&&ay===16){
        const bx=(KX+cx-1)*TS, by=(KY+15)*TS;
        for(let j=0;j<3;j++) for(let i=0;i<3;i++) rect(c,bx+i*TS,by+j*TS,TS,TS,((i+j)&1)?'#cfc8b6':'#c6bfad');
        const mx=bx+48, my=by+48;
        ell(c,mx,my+3,47,41,'rgba(0,0,0,0.2)'); ell(c,mx,my,46,40,'#e0b84a'); ell(c,mx,my,41,35,'#c3ccd6'); ell(c,mx,my,36,30,'#58aee6');
        c.strokeStyle='rgba(255,255,255,0.5)'; c.lineWidth=1;
        for(let i=0;i<2;i++){ c.beginPath(); c.ellipse(mx,my,12+((time*10+i*14)%24),9+((time*8+i*11)%18),0,0,6.2832); c.stroke(); }
        circ(c,mx,my,8,'#e0b84a'); circ(c,mx,my-8,4,'#f6dc82');
        for(let i=0;i<6;i++){ const tt=(time*0.9+i*0.17)%1, a=i*1.0472+time*0.5; circ(c,mx+Math.cos(a)*tt*16,my-8-Math.sin(tt*3.14159)*22,1.6,'rgba(220,240,255,'+(1-tt).toFixed(2)+')'); }
      }
      break; }
    case KCHEST: {
      kGround(c,x,y,px,py);
      const open=chestOpen(x,y);
      ell(c,px+16,py+27,12,4,'rgba(0,0,0,0.25)');
      rect(c,px+6,py+13,20,13,'#8a5a2b'); rect(c,px+6,py+13,20,3,'#a97c50'); rect(c,px+6,py+22,20,2,'#e0b84a');
      if(open){ rect(c,px+6,py+6,20,5,'#6b4a22'); rect(c,px+8,py+14,16,5,'#2a1a0a'); }
      else { rect(c,px+6,py+8,20,6,'#a97c50'); rect(c,px+6,py+12,20,2,'#e0b84a'); circ(c,px+16,py+16,2.2,'#e0b84a'); }
      if(!open){ const s=(Math.sin(time*4+x)+1)/2; c.fillStyle='rgba(255,247,194,'+(0.4+0.6*s).toFixed(2)+')'; c.fillRect(px+24,py+4-s*2,2,2); c.fillRect(px+5,py+9,2,2); }
      break; }
    case KGRAVE: {
      kGround(c,x,y,px,py);
      rect(c,px,py,TS,TS,'rgba(40,30,20,0.35)');
      ell(c,px+16,py+27,9,3,'rgba(0,0,0,0.3)'); rect(c,px+9,py+10,14,17,'#8d939c'); ell(c,px+16,py+10,7,5,'#8d939c'); rect(c,px+13,py+13,6,1,'#5a6068'); rect(c,px+15,py+11,2,8,'#5a6068');
      if(hash(x,y,5640)<0.5) rect(c,px+20,py+22,4,3,'#c0392b');
      break; }
    case KTENT: {
      kGround(c,x,y,px,py);
      ell(c,px+16,py+28,14,4,'rgba(0,0,0,0.25)');
      c.fillStyle='#b5352b'; c.beginPath(); c.moveTo(px+2,py+28); c.lineTo(px+16,py+2); c.lineTo(px+30,py+28); c.closePath(); c.fill();
      c.fillStyle='#8a2420'; c.beginPath(); c.moveTo(px+16,py+2); c.lineTo(px+30,py+28); c.lineTo(px+20,py+28); c.closePath(); c.fill();
      c.fillStyle='#1d1612'; c.beginPath(); c.moveTo(px+12,py+28); c.lineTo(px+16,py+14); c.lineTo(px+20,py+28); c.closePath(); c.fill();
      rect(c,px+15,py-4,2,8,'#4a3018');
      if(hash(x,y,5650)<0.5){ c.fillStyle='#2a2420'; c.fillRect(px+5,py+20,6,4); c.fillRect(px+22,py+14,4,5); }
      break; }
    case KRUIN: {
      kGround(c,x,y,px,py);
      ell(c,px+16,py+27,13,4,'rgba(0,0,0,0.25)');
      rect(c,px+3,py+16,10,11,'#7d838c'); rect(c,px+3,py+16,10,3,'#9aa1ad'); rect(c,px+16,py+10,12,17,'#6d737d'); rect(c,px+16,py+10,12,3,'#8a919e');
      rect(c,px+10,py+24,8,4,'#868d9a'); if(hash(x,y,5660)<0.5){ rect(c,px+18,py+18,2,6,'#3f4650'); }
      break; }
    case KCHAR: {
      kGround(c,x,y,px,py);
      const big=(lx===-66&&ly===-64);
      objs.push({y:py+TS,k:'fn',f:()=>drawCharTree(c,px,py,time,big,x,y)});
      if(big&&NIGHT>0.1) lights.push({x:px+16,y:py-10,r:70,s:0.35,w:0});
      break; }
    case KPOST: {
      kGround(c,x,y,px,py);
      objs.push({y:py+TS,k:'fn',f:()=>drawSign(c,px,py)});
      break; }
    case KMILL: {
      kGround(c,x,y,px,py);
      if(lx===84&&ly===36) objs.push({y:py+TS+8,k:'fn',f:()=>drawMill(c,px,py,time)});
      break; }
    case KSTONES: {
      kGround(c,x,y,px,py);
      objs.push({y:py+TS,k:'fn',f:()=>{
        ell(c,px+16,py+29,11,4,'rgba(0,0,0,0.3)'); c.fillStyle='#7b8ba8'; c.beginPath(); c.moveTo(px+7,py+29); c.lineTo(px+10,py-14); c.lineTo(px+22,py-18); c.lineTo(px+26,py+29); c.closePath(); c.fill();
        c.fillStyle='#98a8c4'; c.beginPath(); c.moveTo(px+10,py-14); c.lineTo(px+22,py-18); c.lineTo(px+20,py+4); c.lineTo(px+11,py+4); c.closePath(); c.fill();
        const p=0.5+0.5*Math.sin(time*2+x*1.7); c.fillStyle='rgba(120,220,255,'+(0.5+0.5*p).toFixed(2)+')'; c.fillRect(px+14,py-8,3,10); c.fillRect(px+13,py+8,5,2); c.fillRect(px+16,py+12,2,6);
      }});
      if(NIGHT>0.1) lights.push({x:px+16,y:py+4,r:55,s:0.5,w:0});
      break; }
    case KCRYSTAL: {
      kGround(c,x,y,px,py);
      objs.push({y:py+TS,k:'fn',f:()=>{
        const p=0.6+0.4*Math.sin(time*2.4);
        circ(c,px+16,py+6,26,'rgba(111,208,255,'+(0.12*p).toFixed(3)+')');
        ell(c,px+16,py+29,13,5,'rgba(0,0,0,0.3)'); rect(c,px+6,py+22,20,8,'#8a919e'); rect(c,px+9,py+18,14,5,'#9aa1ad');
        const fl=Math.sin(time*2)*2;
        c.fillStyle='#6fd0ff'; c.beginPath(); c.moveTo(px+16,py-22+fl); c.lineTo(px+25,py+2+fl); c.lineTo(px+16,py+18); c.lineTo(px+7,py+2+fl); c.closePath(); c.fill();
        c.fillStyle='#b9ecff'; c.beginPath(); c.moveTo(px+16,py-22+fl); c.lineTo(px+16,py+18); c.lineTo(px+7,py+2+fl); c.closePath(); c.fill();
        c.fillStyle='rgba(255,255,255,'+(0.5*p).toFixed(2)+')'; c.fillRect(px+12,py-6+fl,2,8);
      }});
      if(NIGHT>0.05) lights.push({x:px+16,y:py,r:130,s:0.8,w:0});
      break; }
    case KCROP: {
      rect(c,px,py,TS,TS,'#c9a63e'); c.fillStyle='#a8862a'; for(let i=0;i<4;i++) c.fillRect(px+i*8+2,py,2,TS);
      for(let i=0;i<8;i++){ const sx=px+2+(i%4)*8, sy=py+2+Math.floor(i/4)*14, sw=Math.sin(time*1.6+x*0.9+i)*1.5; rect(c,sx+sw,sy,2,10,'#e8cb5a'); rect(c,sx+sw-1,sy-3,4,5,'#f2dc7a'); }
      break; }
    case KROOF: case KHWALL: case KHWIN: case KHDOOR: drawKBuilding(c,x,y,t,px,py,lx,ly); break;
    case KBOAT: {
      drawWater(c,x,y,px,py,time);
      ell(c,px+16,py+26,13,4,'rgba(0,0,0,0.2)'); c.fillStyle='#8a5a2b'; c.beginPath(); c.moveTo(px+1,py+16); c.lineTo(px+31,py+16); c.lineTo(px+25,py+27); c.lineTo(px+7,py+27); c.closePath(); c.fill();
      rect(c,px+1,py+15,30,3,'#a97c50'); rect(c,px+15,py,2,16,'#4a3018'); c.fillStyle='#f2efe0'; c.beginPath(); c.moveTo(px+17,py+1); c.lineTo(px+28,py+12); c.lineTo(px+17,py+12); c.fill();
      break; }
    case KSCARE: {
      kGround(c,x,y,px,py);
      objs.push({y:py+TS,k:'fn',f:()=>{
        ell(c,px+16,py+30,8,3,'rgba(0,0,0,0.25)'); rect(c,px+15,py-6,3,36,'#6b4a2f'); rect(c,px+3,py+4,26,3,'#6b4a2f');
        circ(c,px+16,py-8,7,'#e8cb7a'); ell(c,px+16,py-14,10,3,'#6b4a22'); rect(c,px+10,py-18,12,5,'#6b4a22'); circ(c,px+13,py-9,1.2,'#222'); circ(c,px+19,py-9,1.2,'#222');
        rect(c,px+9,py+7,14,12,'#3a62a8'); rect(c,px+1,py+4,6,3,'#e8cb7a'); rect(c,px+25,py+4,6,3,'#e8cb7a');
      }});
      break; }
    case KTORCH: {
      kGround(c,x,y,px,py);
      objs.push({y:py+TS,k:'fn',f:()=>{
        ell(c,px+16,py+30,6,2,'rgba(0,0,0,0.25)'); rect(c,px+15,py-4,3,34,'#4a3018'); rect(c,px+11,py-8,11,6,'#2a2f3a');
        const f=Math.sin(time*11+x)*1.5; c.fillStyle='#ff7a2a'; c.beginPath(); c.moveTo(px+11,py-8); c.quadraticCurveTo(px+13,py-20+f,px+16,py-26+f); c.quadraticCurveTo(px+21,py-18,px+22,py-8); c.fill();
        c.fillStyle='#ffd166'; c.beginPath(); c.moveTo(px+14,py-8); c.quadraticCurveTo(px+15,py-15,px+16,py-18+f); c.quadraticCurveTo(px+19,py-14,px+19,py-8); c.fill();
      }});
      lights.push({x:px+16,y:py-12,r:110,s:0.85,w:1});
      break; }
    case KMSTALL: {
      kGround(c,x,y,px,py);
      objs.push({y:py+TS,k:'fn',f:()=>drawStall(c,x,y,px,py)});
      break; }
    case KDUMMY: {
      rect(c,px,py,TS,TS,'#d8c58a'); c.fillStyle='#c7b377'; c.fillRect(px+4,py+8,10,1); c.fillRect(px+16,py+22,10,1);
      ell(c,px+16,py+28,9,3,'rgba(0,0,0,0.25)'); rect(c,px+14,py+10,4,18,'#6b4a2f'); rect(c,px+6,py+12,20,4,'#6b4a2f');
      ell(c,px+16,py+8,6,6,'#e8cb7a'); rect(c,px+10,py+14,12,10,'#c9a06a'); rect(c,px+10,py+18,12,2,'#8a5a2b'); circ(c,px+16,py+19,3,'#b5352b');
      break; }
    case KRACK: {
      rect(c,px,py,TS,TS,'#d8c58a');
      ell(c,px+16,py+28,13,3,'rgba(0,0,0,0.25)'); rect(c,px+3,py+8,26,3,'#6b4a2f'); rect(c,px+3,py+8,3,20,'#6b4a2f'); rect(c,px+26,py+8,3,20,'#6b4a2f'); rect(c,px+3,py+20,26,3,'#6b4a2f');
      for(let i=0;i<4;i++){ rect(c,px+7+i*5,py+0,2,22,'#aab4c0'); rect(c,px+6+i*5,py+0,4,3,'#7d8896'); }
      break; }
    case KASH: {
      rect(c,px,py,TS,TS,(x+y)&1?'#3a3330':'#352e2b'); c.fillStyle='#262120';
      for(let i=0;i<4;i++) c.fillRect(px+((hash(x,y,5670+i)*28)|0),py+((hash(x,y,5680+i)*28)|0),4,2);
      if(hash(x,y,5690)<0.12){ const a=0.4+0.6*Math.max(0,Math.sin(time*3+x*2)); c.fillStyle='rgba(255,120,40,'+a.toFixed(2)+')'; c.fillRect(px+((hash(x,y,5691)*26)|0),py+((hash(x,y,5692)*26)|0),2,2); }
      break; }
    case KSAND: {
      rect(c,px,py,TS,TS,(x*7+y*3)%5<2?'#d8c58a':'#d1be82'); c.fillStyle='#bba96e'; c.fillRect(px+4+((hash(x,y,5700)*14)|0),py+8,10,1); c.fillRect(px+14,py+22,9,1);
      break; }
    default: rect(c,px,py,TS,TS,'#888');
  }
}
function drawKBuilding(c,x,y,t,px,py,lx,ly){
  const b=kBuilding(lx,ly) || kBuilding(lx,ly);
  if(!b){ kGround(c,x,y,px,py); rect(c,px,py,TS,TS,'#888'); return; }
  const row=ly-b.y, col=lx-b.x, roofRows=b.h-2;
  if(t===KROOF){
    rect(c,px,py,TS,TS,b.roof);
    c.fillStyle='rgba(0,0,0,0.18)'; for(let i=0;i<4;i++) c.fillRect(px,py+i*8+6,TS,2);
    c.fillStyle='rgba(255,255,255,0.12)'; for(let i=0;i<4;i++){ const o=(i&1)?0:16; c.fillRect(px+o,py+i*8,2,6); c.fillRect(px+o+16,py+i*8,2,6); }
    if(row===0) rect(c,px,py,TS,3,'rgba(255,255,255,0.28)');
    if(col===0) rect(c,px,py,2,TS,'rgba(0,0,0,0.28)'); if(col===b.w-1) rect(c,px+TS-2,py,2,TS,'rgba(0,0,0,0.28)');
    if(b.type==='temple'&&row===0&&col===Math.floor(b.w/2)){ circ(c,px+16,py+14,9,'#f6dc82'); rect(c,px+15,py+4,2,20,'#e0b84a'); rect(c,px+8,py+12,16,2,'#e0b84a'); }
    if(b.type==='library'&&row===1&&col===Math.floor(b.w/2)){ rect(c,px+8,py+8,16,14,'#f4efe0'); rect(c,px+10,py+10,12,2,'#2f6f7a'); rect(c,px+10,py+14,12,2,'#2f6f7a'); rect(c,px+10,py+18,8,2,'#2f6f7a'); }
    return;
  }
  rect(c,px,py,TS,TS,b.wall);
  c.fillStyle='rgba(0,0,0,0.08)'; c.fillRect(px,py+10,TS,1); c.fillRect(px,py+21,TS,1);
  if(row===roofRows) rect(c,px,py,TS,4,'rgba(0,0,0,0.2)');
  if(col===0) rect(c,px,py,2,TS,'rgba(0,0,0,0.15)'); if(col===b.w-1) rect(c,px+TS-2,py,2,TS,'rgba(0,0,0,0.15)');
  const lit=g.clock>=17.5&&g.clock<23.5&&hash(b.x,b.y,g.day%5)<0.75;
  if(t===KHWIN){
    rect(c,px+6,py+7,20,16,'#5a3d2b'); rect(c,px+8,py+9,16,12,lit?'#ffd98a':'#8ecae6');
    c.fillStyle='#5a3d2b'; c.fillRect(px+15,py+9,2,12); c.fillRect(px+8,py+14,16,2);
    if(lit&&NIGHT>0.12) lights.push({x:px+16,y:py+18,r:62,s:0.75,w:0.8});
  }
  if(t===KHDOOR){
    rect(c,px+5,py+2,22,30,'#3a2412'); rect(c,px+7,py+4,18,28,b.type==='house'?'#5c3d7a':'#7b4a22'); rect(c,px+7,py+4,18,3,'rgba(255,255,255,0.15)'); circ(c,px+21,py+19,2,'#ffd166');
  }
}
function drawCharTree(c,px,py,time,big,x,y){
  const s=big?1.7:0.9+hash(x,y,5710)*0.3;
  ell(c,px+16,py+30,13*s,5,'rgba(0,0,0,0.3)');
  c.save(); c.translate(px+16,py+30); c.scale(s,s);
  rect(c,-5,-26,10,26,'#1f1a18'); rect(c,1,-26,4,26,'#15110f');
  c.strokeStyle='#1f1a18'; c.lineWidth=3;
  const br=[[-4,-24,-16,-38],[4,-26,14,-40],[0,-30,-4,-46],[-3,-18,-14,-26],[3,-16,13,-24]];
  for(const b of br){ c.beginPath(); c.moveTo(b[0],b[1]); c.lineTo(b[2],b[3]); c.stroke(); }
  c.fillStyle='#3a3330'; c.fillRect(-9,-4,18,3);
  c.restore();
  if(big){
    const night=NIGHT>0.25, blink=Math.sin(time*0.9)>-0.92;
    if(night&&blink){ const a=0.7+0.3*Math.sin(time*5); c.fillStyle='rgba(255,40,40,'+a.toFixed(2)+')'; c.fillRect(px+10,py-4,4,3); c.fillRect(px+19,py-4,4,3); circ(c,px+12,py-3,6,'rgba(255,40,40,0.18)'); circ(c,px+21,py-3,6,'rgba(255,40,40,0.18)'); }
    for(let i=0;i<5;i++){ const tt=(time*0.35+i*0.2)%1; c.fillStyle='rgba(180,170,160,'+(0.7*(1-tt)).toFixed(2)+')'; c.fillRect(px+4+i*5+Math.sin(tt*5+i)*4,py-10-tt*50,2,2); }
  } else if(hash(x,y,5711)<0.15){
    const tt=(time*0.5+hash(x,y,5712))%1; c.fillStyle='rgba(255,140,50,'+(1-tt).toFixed(2)+')'; c.fillRect(px+14+Math.sin(tt*6)*3,py+4-tt*26,2,2);
  }
}
function drawMill(c,px,py,time){
  const bx=px+16, by=py+TS;     /* bottom centre */
  ell(c,bx,by-2,34,8,'rgba(0,0,0,0.25)');
  c.fillStyle='#e8d9b5'; c.beginPath(); c.moveTo(bx-30,by-6); c.lineTo(bx-18,by-92); c.lineTo(bx+18,by-92); c.lineTo(bx+30,by-6); c.closePath(); c.fill();
  c.fillStyle='rgba(0,0,0,0.12)'; c.beginPath(); c.moveTo(bx+8,by-92); c.lineTo(bx+18,by-92); c.lineTo(bx+30,by-6); c.lineTo(bx+12,by-6); c.closePath(); c.fill();
  for(let r=0;r<5;r++) rect(c,bx-28+r*2,by-18-r*16,56-r*4,1,'rgba(0,0,0,0.12)');
  c.fillStyle='#a8432b'; c.beginPath(); c.moveTo(bx-24,by-90); c.lineTo(bx,by-120); c.lineTo(bx+24,by-90); c.closePath(); c.fill();
  rect(c,bx-8,by-24,16,22,'#5a3d22'); rect(c,bx-5,by-60,10,12,'#5a3d2b'); rect(c,bx-3,by-58,6,8,'#8ecae6');
  const hx=bx, hy=by-98, a=time*0.7;
  circ(c,hx,hy,5,'#4a3018');
  for(let i=0;i<4;i++){
    const ang=a+i*Math.PI/2, ex=hx+Math.cos(ang)*54, ey=hy+Math.sin(ang)*54;
    c.strokeStyle='#4a3018'; c.lineWidth=3; c.beginPath(); c.moveTo(hx,hy); c.lineTo(ex,ey); c.stroke();
    c.fillStyle='#f2efe0'; c.beginPath(); const nx=-Math.sin(ang), ny=Math.cos(ang);
    c.moveTo(hx+Math.cos(ang)*14,hy+Math.sin(ang)*14); c.lineTo(ex,ey); c.lineTo(ex+nx*12,ey+ny*12); c.lineTo(hx+Math.cos(ang)*14+nx*12,hy+Math.sin(ang)*14+ny*12); c.closePath(); c.fill();
  }
}
