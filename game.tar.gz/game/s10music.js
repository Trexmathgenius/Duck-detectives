/* ===== MUSIC (v1.25) =====
   The game had effects but no music. This is a small generative score made of Web Audio oscillators: no audio files.
   Each place and feeling has a mood (key, tempo, chord loop, instruments). The engine writes a bar at a time, a little ahead of the clock,
   and crossfades when the mood changes. Stingers mark learning a verse, finishing a chapter, a rank, a loss.
   The engine takes any AudioContext, so the tests can render it offline and check it is audible and does not clip.
   Adds D10.music (controller), D10.sting, D10.setMood, D10.musicApply. */
(function(){
'use strict';
const D10=window.D10=window.D10||{};
const mtof=m=>440*Math.pow(2,(m-69)/12);

/* [root semitone offset, chord tones above root] per bar */
const MOODS={
  forest:{bpm:62,root:62,prog:[[0,[0,4,7]],[-3,[0,3,7]],[-7,[0,4,7]],[-5,[0,4,7]]],scale:[0,2,4,7,9],pad:'triangle',padG:0.045,arp:{sub:1,dens:0.55,type:'sine',dec:1.6,g:0.05,oct:[12,24]},bass:[0],delay:0.38,lp:2400},
  town:  {bpm:94,root:60,prog:[[0,[0,4,7]],[7,[0,4,7]],[9,[0,3,7]],[5,[0,4,7]]],scale:[0,2,4,5,7,9,11],pad:'sine',padG:0.03,arp:{sub:2,dens:0.62,type:'triangle',dec:0.5,g:0.055,oct:[12,24]},bass:[0,2],perc:'shaker',delay:0.25,lp:3200},
  hearth:{bpm:76,root:62,prog:[[0,[0,4,7]],[-2,[0,4,7]],[-7,[0,4,7]],[-5,[0,4,7]]],scale:[0,2,4,5,7,9,10],pad:'triangle',padG:0.04,arp:{sub:2,dens:0.5,type:'triangle',dec:0.7,g:0.05,oct:[12,24]},bass:[0,2],delay:0.3,lp:2800},
  night: {bpm:50,root:57,prog:[[0,[0,3,7]],[-4,[0,4,7]],[-7,[0,4,7]],[-9,[0,3,7]]],scale:[0,3,5,7,10],pad:'sine',padG:0.045,arp:{sub:1,dens:0.35,type:'sine',dec:2.4,g:0.045,oct:[24,36]},bass:[0],delay:0.5,lp:2000},
  academy:{bpm:72,root:62,prog:[[0,[0,3,7,10]],[5,[0,4,7]],[-2,[0,4,7]],[3,[0,4,7]]],scale:[0,2,3,5,7,9,10],pad:'sine',padG:0.04,arp:{sub:2,dens:0.7,type:'triangle',dec:0.9,g:0.045,oct:[12,24]},bass:[0],delay:0.33,lp:3000},
  tense: {bpm:98,root:52,prog:[[0,[0,1,7]],[0,[0,1,7]],[-2,[0,3,7]],[1,[0,1,7]]],scale:[0,1,3,5,7,8,10],pad:'sawtooth',padG:0.012,arp:{sub:2,dens:0.28,type:'square',dec:0.18,g:0.012,oct:[24]},bass:[0,1,2,3],perc:'heart',delay:0.2,lp:1400},
  tender:{bpm:54,root:65,prog:[[0,[0,4,7]],[-5,[0,4,7]],[-3,[0,3,7]],[-7,[0,4,7]]],scale:[0,2,4,5,7,9,11],pad:'sine',padG:0.04,arp:{sub:1,dens:0.4,type:'triangle',dec:2.2,g:0.06,oct:[12,24]},bass:[0],delay:0.55,lp:2200},
  dark:  {bpm:46,root:45,prog:[[0,[0,7,12]],[1,[0,7,12]],[-2,[0,6,12]],[0,[0,7,12]]],scale:[0,1,3,6,7],pad:'sawtooth',padG:0.014,arp:{sub:1,dens:0.18,type:'sine',dec:3,g:0.03,oct:[24,36]},bass:[0],delay:0.6,lp:900},
  title: {bpm:66,root:62,prog:[[0,[0,4,7]],[-3,[0,3,7]],[-7,[0,4,7]],[-5,[0,4,7]]],scale:[0,2,4,7,9],pad:'triangle',padG:0.04,arp:{sub:2,dens:0.6,type:'sine',dec:1.4,g:0.05,oct:[12,24]},bass:[0],delay:0.45,lp:2600}
};
D10.MOODS=MOODS;

function rng(seed){ let s=seed>>>0||1; return ()=>{ s=(Math.imul(s,1664525)+1013904223)>>>0; return s/4294967296; }; }

function makeMusic(ctx,dest,opts){
  opts=opts||{};
  const master=ctx.createGain(); master.gain.value=opts.vol===undefined?0.6:opts.vol;
  const comp=ctx.createDynamicsCompressor(); comp.threshold.value=-18; comp.ratio.value=4; comp.attack.value=0.02; comp.release.value=0.3;
  master.connect(comp); comp.connect(dest||ctx.destination);
  const M={ctx:ctx,master:master,mood:null,bus:null,nextBar:0,bar:0,rand:rng(7),seed:7};

  function newBus(def){
    const bus=ctx.createGain(); bus.gain.value=0;
    const lp=ctx.createBiquadFilter(); lp.type='lowpass'; lp.frequency.value=def.lp||2400; lp.Q.value=0.4;
    const dl=ctx.createDelay(2); dl.delayTime.value=60/def.bpm*(def.delay>0.4?1.5:0.75);
    const fb=ctx.createGain(); fb.gain.value=0.34; const dlp=ctx.createBiquadFilter(); dlp.type='lowpass'; dlp.frequency.value=1800;
    const wet=ctx.createGain(); wet.gain.value=0.45;
    bus.connect(lp); lp.connect(master);
    lp.connect(dl); dl.connect(dlp); dlp.connect(fb); fb.connect(dl); dlp.connect(wet); wet.connect(master);
    return {bus:bus,lp:lp,nodes:[bus,lp,dl,fb,dlp,wet]};
  }
  function voice(B,type,freq,t,dur,gain,att,rel,detune){
    const o=ctx.createOscillator(), g2=ctx.createGain();
    o.type=type; o.frequency.value=freq; if(detune) o.detune.value=detune;
    g2.gain.setValueAtTime(0,t); g2.gain.linearRampToValueAtTime(gain,t+att);
    g2.gain.setValueAtTime(gain,t+Math.max(att,dur-rel)); g2.gain.linearRampToValueAtTime(0.0001,t+dur+rel*0.2);
    o.connect(g2); g2.connect(B.bus); o.start(t); o.stop(t+dur+rel*0.3+0.05);
  }
  function pluck(B,type,freq,t,dec,gain){
    const o=ctx.createOscillator(), g2=ctx.createGain();
    o.type=type; o.frequency.value=freq;
    g2.gain.setValueAtTime(0,t); g2.gain.linearRampToValueAtTime(gain,t+0.012); g2.gain.exponentialRampToValueAtTime(0.0001,t+dec);
    o.connect(g2); g2.connect(B.bus); o.start(t); o.stop(t+dec+0.05);
  }
  function noise(B,t,dur,gain,hp){
    const len=Math.max(1,Math.floor(ctx.sampleRate*dur)), buf=ctx.createBuffer(1,len,ctx.sampleRate), d=buf.getChannelData(0);
    for(let i=0;i<len;i++) d[i]=(Math.random()*2-1)*(1-i/len);
    const s=ctx.createBufferSource(); s.buffer=buf; const f=ctx.createBiquadFilter(); f.type='highpass'; f.frequency.value=hp||5000;
    const g2=ctx.createGain(); g2.gain.value=gain; s.connect(f); f.connect(g2); g2.connect(B.bus); s.start(t);
  }
  function thump(B,t,gain){
    const o=ctx.createOscillator(), g2=ctx.createGain(); o.type='sine'; o.frequency.setValueAtTime(75,t); o.frequency.exponentialRampToValueAtTime(38,t+0.18);
    g2.gain.setValueAtTime(gain,t); g2.gain.exponentialRampToValueAtTime(0.0001,t+0.3); o.connect(g2); g2.connect(B.bus); o.start(t); o.stop(t+0.35);
  }

  function writeBar(def,B,t0,barIx){
    const beat=60/def.bpm, len=beat*4, r=M.rand;
    const ch=def.prog[barIx%def.prog.length], base=def.root+ch[0], tones=ch[1];
    /* pad: the chord, held, slightly detuned */
    tones.forEach((s,i)=>{
      voice(B,def.pad,mtof(base+s-12),t0,len,def.padG,Math.min(1.4,len*0.35),Math.min(1.6,len*0.4),(i-1)*5);
    });
    /* bass */
    for(const b of def.bass) voice(B,'sine',mtof(base-24),t0+b*beat,beat*(def.bass.length>2?0.9:1.8),0.08,0.02,0.3);
    /* arpeggio / melody */
    const a=def.arp, steps=4*a.sub, pool=[];
    for(const o of a.oct){ tones.forEach(s=>pool.push(base+s+o)); def.scale.forEach(s=>pool.push(def.root+s+o)); }
    let last=-1;
    for(let i=0;i<steps;i++){
      if(r()>a.dens) continue;
      let k=Math.floor(r()*pool.length); if(k===last) k=(k+2)%pool.length; last=k;
      pluck(B,a.type,mtof(pool[k]),t0+i*(len/steps)+(r()-0.5)*0.015,a.dec,a.g*(0.7+0.5*r()));
    }
    /* percussion */
    if(def.perc==='shaker'){ for(let i=0;i<8;i++) noise(B,t0+i*beat/2,0.05,i%2?0.018:0.03,6500); }
    if(def.perc==='heart'){ thump(B,t0,0.14); thump(B,t0+beat*0.5,0.09); thump(B,t0+beat*2,0.14); thump(B,t0+beat*2.5,0.09); }
  }

  M.setMood=function(name,fade){
    if(name===M.mood||!MOODS[name]) return;
    const def=MOODS[name], t=ctx.currentTime, f=fade===undefined?3:fade;
    if(M.bus){ const old=M.bus; old.bus.gain.cancelScheduledValues(t); old.bus.gain.setValueAtTime(old.bus.gain.value,t); old.bus.gain.linearRampToValueAtTime(0,t+f); setTimeout(()=>{ try{ old.nodes.forEach(n=>n.disconnect()); }catch(e){} },(f+4)*1000); }
    M.mood=name; M.def=def; M.bus=newBus(def);
    M.bus.bus.gain.setValueAtTime(0,t); M.bus.bus.gain.linearRampToValueAtTime(1,t+f);
    M.nextBar=t+0.15; M.bar=0;
  };
  /* write bars until we are 1.5 bars ahead of the clock */
  M.tick=function(){
    if(!M.def) return;
    const len=60/M.def.bpm*4;
    while(M.nextBar<ctx.currentTime+len*1.5){ writeBar(M.def,M.bus,M.nextBar,M.bar++); M.nextBar+=len; }
  };
  /* for offline rendering and tests: write bars until `secs` of music exist */
  M.renderAhead=function(secs){ if(!M.def) return; const len=60/M.def.bpm*4; while(M.nextBar<secs){ writeBar(M.def,M.bus,M.nextBar,M.bar++); M.nextBar+=len; } };
  M.stop=function(fade){
    const t=ctx.currentTime, f=fade===undefined?1.5:fade;
    if(M.bus){ const old=M.bus; old.bus.gain.cancelScheduledValues(t); old.bus.gain.setValueAtTime(old.bus.gain.value,t); old.bus.gain.linearRampToValueAtTime(0,t+f); setTimeout(()=>{ try{ old.nodes.forEach(n=>n.disconnect()); }catch(e){} },(f+4)*1000); }
    M.bus=null; M.def=null; M.mood=null;
  };
  /* short musical phrases that mark a moment */
  const STING={
    learn:  {notes:[0,4,7,12,16],step:0.11,type:'triangle',dec:1.2,root:72,g:0.07},
    chapter:{notes:[0,7,12,7,16],step:0.16,type:'sine',dec:1.6,root:67,g:0.07},
    joy:    {notes:[0,4,7,12,7,16,19],step:0.1,type:'triangle',dec:1.1,root:72,g:0.07},
    loss:   {notes:[0,-2,-5,-9],step:0.28,type:'sine',dec:2.2,root:64,g:0.07},
    reveal: {notes:[0,7,14,19],step:0.22,type:'sine',dec:2.6,root:60,g:0.07},
    tender: {notes:[0,4,9,7],step:0.24,type:'triangle',dec:2.0,root:65,g:0.06}
  };
  M.sting=function(kind){
    const d=STING[kind]; if(!d) return;
    const t=ctx.currentTime+0.05; const B={bus:master};
    d.notes.forEach((s,i)=>pluck(B,d.type,mtof(d.root+s),t+i*d.step,d.dec,d.g));
    voice(B,'sine',mtof(d.root+d.notes[0]-12),t,d.notes.length*d.step+0.6,0.03,0.1,0.6);
  };
  return M;
}
D10.makeMusic=makeMusic;

/* ---------------- running in the game ---------------- */
let live=null, wantMood='title', override=null;
function engine(){
  if(live) return live;
  try{ const c=ac(); if(!c) return null; live=makeMusic(c,c.destination,{vol:0.6}); }catch(e){ console.warn('music',e); }
  return live;
}
function pickMood(){
  if(override&&override.until>performance.now()) return override.mood;
  if(g.mode==='title') return 'title';
  const sc=g.scene;
  try{
    if(sc==='sx'&&SX.S){
      const S=SX.S, th=S.def.theme||'stone';
      if(S.guards&&S.guards.length||S.timer) return 'tense';
      if(/crypt|ash|dream/.test(th)) return 'dark';
      if(th==='hearth') return 'hearth';
      if(th==='grove'||th==='wood') return 'forest';
      if(S.def.id&&/^prac_/.test(S.def.id)) return 'academy';
      return 'tender';
    }
    if(sc==='lib'){ return g.libKind==='rschool'?'academy':'tender'; }
    if(sc==='shop') return 'town';
    const tw=townAtTile(Math.floor(g.px/TS),Math.floor((g.py-2)/TS));
    if(g.clock>=21||g.clock<5) return tw&&tw.isRed?'hearth':'night';
    if(tw) return tw.isRed?'hearth':'town';
  }catch(e){}
  return 'forest';
}
D10.setMood=(mood,secs)=>{ override={mood:mood,until:performance.now()+(secs||30)*1000}; };
D10.clearMood=()=>{ override=null; };
D10.sting=kind=>{ try{ if(!D10.settings.music||!g.sound) return; const e=engine(); if(e&&e.ctx.state==='running') e.sting(kind); }catch(x){} };
D10.musicApply=()=>{ if(live&&!(D10.settings.music&&g.sound)) live.stop(1); };
D10.music=()=>live;

setInterval(()=>{
  try{
    if(!D10.settings.music||!g.sound){ if(live&&live.mood) live.stop(1); return; }
    const c=ac(); if(!c) return;
    if(c.state==='suspended'){ c.resume&&c.resume(); return; }
    const e=engine(); if(!e) return;
    const m=pickMood(); if(m!==wantMood||!e.mood){ wantMood=m; e.setMood(m,3); }
    e.tick();
  }catch(err){ console.warn('music tick',err); }
},400);

/* moments */
{
  const hook=(fn)=>{ try{ fn(); }catch(e){ console.warn('music hook',e); } };
  hook(()=>{ const o=S2.finish; S2.finish=function(){ const r=o.apply(this,arguments); D10.sting('chapter'); return r; }; });
  hook(()=>{ const o=pracLeave; pracLeave=function(ok){ const r=o(ok); if(ok) D10.sting('learn'); return r; }; });
  hook(()=>{ const o=addRep; addRep=function(t,n){ const old=townRank(t); const r=o(t,n); if(townRank(t)>old) D10.sting('joy'); return r; }; });
}
})();
