'use strict';
/* ===== TWO CHAPTERS THAT ONLY SOME PLAYERS GET (v1.21) =====
   x15  "The Boot"            Poppy's father comes to the fire. Only if Poppy told you what she knew.
   x17  "The Twelfth Name"    Ruddock shows you the beam. Only if you did not pull rank on him.
   A player who guarded their answers, or who spent their friends, simply never meets these chapters, and never knows they were there. */

/* a small branching-dialogue engine: nodes with a speaker, pages, a question and options that go to other nodes */
function dlgTree(nodes,id,done){
  const n=nodes[id]; if(!n){ done(); return; }
  const pre=typeof n.pre==='function'?n.pre():n.pre;
  say(n.who,pre,()=>{
    if(n.apply) n.apply();
    if(!n.opts){ done(); return; }
    const opts=n.opts.filter(o=>!o.req||o.req());
    choose(n.who,typeof n.q==='function'?n.q():n.q,opts.map(o=>o.t),k=>{
      const o=opts[k]; if(o.apply) o.apply();
      const go=()=>{ if(o.goto) dlgTree(nodes,o.goto,done); else done(); };
      if(o.say) say(o.who||n.who,o.say,go); else go();
    },opts.length-1);
  });
}
const FIRE={k:[-76,-26]};

/* ---------- x15: The Boot ---------- */
const POPP=()=>A5().p2;
const NODES15={
 start:{who:'',pre:()=>{
   const p=POPP();
   return ['It is late. The camp has gone to bed in ones and twos. Poppy has asked you to stay up, and has not said why, and has set the mended boot on the log by the fire, as one sets out a bowl for an animal that may or may not come.',
     p==='tell'?'Halbeak is posted at the edge of the light, pretending to be a tree. He has agreed to nothing. He has agreed to wait.':p==='write'?'In her pocket is the letter she wrote and has not sent. She is holding it through the cloth, like a small warm stone.':'Nobody else in the camp knows. It is just the two of you, and a fire, and a boot.',
     'Poppy sits in the dark behind a barrel, small as a held breath. She has told you: "If he comes, I will come out. If he does not, I will have been here."'];
 },q:'Footsteps. They come the long way round, from the side of the wood.',
  opts:[
   {t:'Say nothing. Let him come to the fire.',apply:()=>{ S4st().h.guarded++; },goto:'arrives'},
   {t:'"Poppy is here."',apply:()=>{ S4st().h.candid++; },goto:'arrives',say:['A grey shape stops at the edge of the firelight, as if you had pulled a rope. For a long moment nothing moves.']},
   {t:'Put the kettle on, loudly, so that he knows he is expected.',apply:()=>{ S4st().h.gentle++; },goto:'arrives',say:['The kettle clanks. Out in the dark, someone laughs, a small broken sound, and then stops it.']}]},
 arrives:{who:'Ollo, a grey-cloaked duck',pre:['He is thin. The cloak is too big for him, and one of his feet is bare, wrapped in rag against the cold. He stands at the edge of the light with his hood back and his wings open, as one stands who has come to be searched.','"I saw the lamp," he says. "I thought: somebody lit that for me. Then I thought: it is not for me. I came anyway."','He looks at the boot on the log. He does not reach for it.'],
  q:'He has not looked at the barrel. He knows exactly where she is.',
  opts:[
   {t:'"Why did you join them?"',goto:'why'},
   {t:'"She mended your boot every night for a month."',apply:()=>{ S4st().h.tender++; },goto:'boot'},
   {t:'"What did you carry for the Hands?"',apply:()=>{ S4st().h.guarded++; },goto:'carried'}]},
 why:{who:'Ollo',pre:['"The barn went in the last shake. The roof came down on the oats. We had nothing, and the Elders had a great deal of reasoning, and Brand had a voice."','"He said, you are afraid, and you are right to be. Nobody had said that. Everyone else said it would be all right. He said: it will not, and I will stand next to you in it."','"I would have followed anyone who said that. I want you to know it was not the cause. It was the voice."'],
  q:'Ollo is not asking to be excused. He is asking to be understood, which is harder.',
  opts:[{t:'"That is the most dangerous kind of leader."',goto:'turn'},{t:'"I know that voice. I have wanted to follow it."',apply:()=>{ S4st().h.tender++; },goto:'turn'}]},
 boot:{who:'Ollo',pre:['He goes very still. "Every night."','"I did not know. I thought she had thrown it away." He puts his wing to his face, quickly, and takes it down again, as though he were checking the weather.','"I have a lot of things to say to her and none of them is the right size."'],
  q:'The fire pops. Behind the barrel, something small breathes in.',
  opts:[{t:'"Say a small one."',goto:'turn'},{t:'"Tell me what you did, first."',goto:'carried'}]},
 carried:{who:'Ollo',pre:['"Ash. A sack at a time, on my back, to the Archive cellar door. It was for the ward, they said. A rite to make it safe."','"I read the plan on the third night. It was not a ward. It was a door, and it was to be a closed one. They meant to close it with everyone still inside. I carried one more sack, because I was a coward, and then I left."','"I have been standing at the edge of this camp for six nights. I came tonight because I saw the boot."'],
  q:'He is not asking you to absolve him. He is telling you what to hold, if you wish to hold it.',
  opts:[{t:'"You left. That is the thing that counts."',apply:()=>{ S4st().h.steady++; },goto:'turn'},{t:'"You carried it. That counts too."',apply:()=>{ S4st().h.candid++; },goto:'turn'}]},
 turn:{who:'',pre:['Poppy comes out from behind the barrel. She does not run. She walks, with her bag held in both hands in front of her, like a very small official, and stops an arm\'s length from her father.','"You did not take your boot," she says. "I mended it. It was the heel."','Ollo goes down on one knee in the ash. He does not say anything at all. She puts the boot into his wings, and he holds it, and there is a very long silence.'],
  q:'It is Poppy\'s moment. But they both look at you, and it is also yours.',
  opts:[
   {t:'"Go home with her. Tell Halbeak and the Elders what you know, in the morning."',apply:()=>{ A5().father='home'; S6.cap('hearth',1); S6.cap('crown',1); s2led('trust',1); S4.setcx('x15','home','brought a deserter home to his daughter'); },goto:'home'},
   {t:'"Turn yourself in tonight. Halbeak is at the edge of the camp, and he is fair."',req:()=>POPP()==='tell',apply:()=>{ A5().father='surrender'; S6.cap('crown',2); s2led('truth',1); S4.setcx('x15','surrender','walked a father to give himself up to a captain'); },goto:'surrender'},
   {t:'"It is yours to decide. We will not decide it for you."',apply:()=>{ const hands=S4.self()==='proud'||S4.self()==='guarded'; A5().father=hands?'hands':'home'; S4.setcx('x15','free','left a father the choice of which way to walk'); S6.cap('sleepers',1); },goto:'free'}]},
 home:{who:'Ollo',pre:['"Yes," he says, very quietly. "Yes. I think I can do that. I think it is the only part of it I can do."','He puts on the boot. It is too big for his foot. Poppy bites her lip. "It is the heel," she says. "I did the heel. It was never the size."','They walk away into the dark together, a very small girl and a very thin man, and neither of them looks back, and both of them are holding on.']},
 surrender:{who:'Ollo',pre:['"Tonight," he says. He stands. "Yes. Better tonight, before I find another reason."','Halbeak, at the edge of the light, takes one step forward and stops. He puts his hand on his sword hilt, not as a threat, but as a man steadying himself. "I will be gentle," he says. "I do not know how, but I will learn it tonight."','Poppy takes her father\'s hand, and then Halbeak\'s, and for a moment the three of them stand there in the firelight, a girl, a soldier and a thief of ash, and nobody says a word.']},
 free:{who:'Ollo',pre:()=>A5().father==='home'?['He looks at you for a long time. He looks at the boot. He looks at Poppy.','"I think," he says, "I think I would like to be a man with a boot." He puts it on. It is too big. He keeps it on anyway.','They walk away together. He limps. She lets him.']
   :['He looks at the boot for a long time. He looks at the dark where the Hands are.','"I want to," he says. "I want to, and I do not know that I can. They know where I live."','He puts the boot down, very carefully, on the log, and puts his hood up. "I will be at the Tree," he says. "I do not know whose side I will be on."','Poppy does not cry. She picks up the boot, and puts it in her bag, and says "Okay." It is the most terrible okay you have ever heard.']}
};
BREATH.x15={title:'The Boot',sub:'He will come, or he will not, and either way you were here.',who:'Ollo',
  intro:['The camp is asleep. The fire is low. Poppy has set a mended boot on the log, and has asked you to stay up.'],
  run(done){ dlgTree(NODES15,'start',()=>{ coin(); done(); }); }};
S2.ch.x15={route:'both',theme:'dark',numLabel:'A QUIET HOUR',title:BREATH.x15.title,sub:BREATH.x15.sub,intro:BREATH.x15.intro,recap:'A boot, a father, a girl.',start(){ s2set(0); },
  obj(s){ return ['Go to the <b>campfire</b> '+campWhere()+'. Poppy has asked you to stay up, and set a mended boot on the log.'][s]||''; }};

/* ---------- x17: The Twelfth Name ---------- */
const V17=()=>S4.cx('v17');
const SEEN17=()=>{ const k=K3(); return k.s17||(k.s17={}); };
BREATH.x17={title:'The Twelfth Name',sub:'A list is a way of not forgetting. Sometimes it is also a way of not forgiving.',who:'Warden Ruddock',
  intro:['Ruddock has asked you to the wall at dawn. He has not said why. Since the night you spoke to him as a friend and not an officer, he has been very correct, very careful, and slightly, unbearably hopeful.'],
  run(done){
    if(s2().step<1){ say('',['Ruddock is at the far end of the parapet with his back to you. There are three things on the wall he has not mentioned, and you have not yet looked at.']); return; }
    const hint=V17()==='asked'?'He is holding a tin cup, and has been for some minutes, without drinking.':'He has a cup of something, and does not drink it, and puts it down.';
    dlgTree({
     start:{who:'Warden Ruddock',pre:['Ruddock stands very straight at the edge of the parapet. '+hint,'"You looked at them. All three. Good. I thought you might not."','"There are eleven names on that beam. I have said them every dawn for nineteen years. A week ago, I added a twelfth. I did not tell you whose."','"It is Brand\'s."','"He is not dead. I know that. But the man who stood beside me at his sister\'s grave is not here, and I have been grieving him, very quietly, for a season. I scratched the name in. I have not known whether to scratch it out."'],
       q:'The dawn is coming up grey behind the wall. Ruddock waits for you to tell him what a name is for.',
       opts:[
        {t:'"Leave it. Grief is allowed to come early."',apply:()=>{ A5().rudBrand='left'; S4st().h.gentle++; s2led('mercy',1); S6.cap('hearth',1); S4.setcx('x17','left','told a warden that grief can come early'); },goto:'left'},
        {t:'"Scratch it out. He is not dead."',apply:()=>{ A5().rudBrand='off'; S4st().h.candid++; s2led('truth',1); S6.cap('hearth',1); S6.cap('sleepers',1); S4.setcx('x17','off','told a warden to scratch out a living man\'s name'); },goto:'off'},
        {t:'"Write your own name beside it."',apply:()=>{ A5().rudBrand='both'; S4st().h.tender++; s2led('kin',1); S6.cap('hearth',1); S6.cap('mallow',1); S4.setcx('x17','both','told a warden he belonged on his own list'); },goto:'both'}]},
     left:{who:'Warden Ruddock',pre:['He nods slowly. "Early. Yes." He lets his hand rest on the beam.','"I will leave it. I will also keep an eye on the man. Both can be true. I think that is what the beam is for."','He says it as if he has been waiting a long time for someone to say that it can.']},
     off:{who:'Warden Ruddock',pre:['He looks at the beam, and takes out a small knife, and does not use it. He holds it.','"If I scratch it out, it is a promise. That I will be the one to let him back in. I am not sure I am ready for the weight of that."','He puts the knife away. "I will scratch it. Tonight. Not now. I will think about how to say the thing to his face."']},
     both:{who:'Warden Ruddock',pre:['Ruddock goes completely still. "Mine."','"That is... I had not thought of that." He looks at the beam, at the eleven names, at the twelfth. "I have been a poor sort of guardian of my own name."','He takes out the knife, then, and scratches it, small, beneath Brand\'s: a short, plain, square-edged R. It takes him a long time. When he is done he is shaking, very slightly, in the cold.','"Thank you," he says. "I think I needed someone to say I was on it."']}
    },'start',()=>{ coin(); done(); });
  }};
S2.ch.x17={route:'both',theme:'dark',numLabel:'A QUIET HOUR',title:BREATH.x17.title,sub:BREATH.x17.sub,intro:BREATH.x17.intro,recap:'Eleven names, a twelfth, and a thirteenth.',
  start(){ s2set(0); K3().s17={}; },
  obj(s){ return ['Go to the camp wall '+campWhere()+'. At dawn, look at the <b>three things</b> Ruddock has left on the parapet ('+Object.keys(SEEN17()).length+'/3).','Speak with <b>Ruddock</b> at the <b>campfire</b> '+campWhere()+'.'][s]||''; }};
const P17=[
 {id:'x17_a',k:[-79,-26],glyph:'scroll',col:'#c9a24a',txt:['A beam under the walkway, scratched along the underside with a nail. Eleven names, in a row, in a square clear hand. The first is ILSE, with a little tail on the E where the nail slipped. Below the last name there is a space. In the space, very small, a twelfth name, and a number: nineteen.','Nineteen years. Eleven names. One a week ago.']},
 {id:'x17_b',k:[-73,-26],glyph:'candle',col:'#e0b84a',txt:['A tin cup on a nail, with a name stamped in the bottom, worn almost smooth. You turn it over. The name is ILSE.','It is a very ordinary cup. Somebody has been cleaning it, regularly, with a rag, for a very long time. It is the cleanest thing on the wall.']},
 {id:'x17_c',k:[-76,-29],glyph:'scroll',col:'#8a7a5a',txt:['A folded note, wedged between two stones, much creased. The paper is soft as cloth. It is in a hand you know, thin and crowded: Brand\'s.','"I should have forgiven you first. B." That is all it says. The date is nine days ago. It has been opened and refolded so many times the folds have gone white.']}];
for(const p of P17) S2.prop({id:p.id,k:p.k,glyph:p.glyph,col:p.col,when:()=>s2cur()==='x17'&&s2().step===0&&!SEEN17()[p.id],mark:'!',use(){
  say('',p.txt,()=>{ SEEN17()[p.id]=1; coin(); hudCache.obj=null; if(Object.keys(SEEN17()).length>=3) s2set(1); else toast('Looked at: '+Object.keys(SEEN17()).length+' of 3.',2400); });
}});

/* ---------- where the two chapters sit in the story ---------- */
{
  const _sn=s2next;
  s2next=function(id){
    const q=s2();
    if(id==='b15'&&!q.done.x15&&['tell','keep','write'].indexOf(A5().p2)>=0){ q.x15next=_sn(id); return 'x15'; }
    if(id==='x15') return q.x15next||null;
    if(id==='b17'&&!q.done.x17&&A5().ilse&&S4.cx('v17')!=='pulled'){ q.x17next=_sn(id); return 'x17'; }
    if(id==='x17') return q.x17next||null;
    return _sn(id);
  };
}
/* the breath prop already sends every b/x chapter through run(); only the guard for x17's step is needed there */

/* Poppy's ending now knows what became of her father */
{
  const _ec=epiCard;
  epiCard=function(label,title,sub,pages,theme,cb){
    try{
      if(label==='EPILOGUE'&&Array.isArray(pages)){
        const f=A5().father;
        const L={home:'Poppy\'s father sits at the end of the family table in a boot that is too big for him. He has learned to be home the way you learn a language: badly, and daily.',
          surrender:'Poppy\'s father sleeps in a room with a lamp, and answers questions of the ceiling, and Halbeak sends him bread on Sundays. Poppy brings the news.',
          hands:'On the last morning, a grey figure stood at the back of the clearing with a boot in his hand. He did not come forward. He did not leave. Poppy waved once, and he lifted the boot.'}[f];
        if(L) pages=pages.concat([L]);
        const rb=A5().rudBrand;
        const R={left:'Ruddock\'s twelfth name is still on the beam. He keeps it as a fact. He also, some mornings, takes Brand a cup of tea.',off:'Ruddock scratched out the twelfth name, and told Brand to his face. It is the hardest thing he has ever done, and he does not speak of it.',both:'Ruddock\'s name is on the beam beside Brand\'s, small and square. He tells people that it was not a punishment, and nobody believes him, and it is the first time he has been on a list as a person.'}[rb];
        if(R) pages=pages.concat([R]);
      }
    }catch(e){ console.error(e); }
    return _ec(label,title,sub,pages,theme,cb);
  };
}
/* and the council remembers it */
rc(['Warden Ruddock'],'rrud',()=>!!A5().rudBrand&&!!k3('brandFate'),['(Ruddock does not look at Brand. He looks at the beam in his head, and then, briefly, at Brand.)','"I have scratched or not scratched what I decided. I will say this: he is welcome to the wall."']);
rc(['Little Poppy'],'rfather',()=>!!A5().father,['(Poppy has something new in her bag. A grey cloak, folded very small.)','"Papa gave me this. He says it was the one decent thing he took. I do not know what to do with it. I am keeping it in case."']);

/* Poppy's last quiet hour knows what became of her father */
{
  const _b=BX.b19;
  BX.b19=function(k,next){
    const f=A5().father;
    if(!f) return _b(k,next);
    A5().poppyEnd={home:'letter',surrender:'told',hands:'carry'}[f];
    const L={
      home:['(Poppy is sitting between two ducks, one of whom is wearing a boot that is too big for him. He is holding her hand and is plainly trying not to cry.)','"He came home. He says he does not know how to be home. I told him nobody does. You only do it."'],
      surrender:['(Poppy is holding Halbeak\'s hand, which Halbeak is clearly not used to.)','"They have a plan for Papa. Not a punishment. A room, and a lamp, and someone to ask him questions. Halbeak says that is how it begins, with a room."'],
      hands:['(Poppy is at the far edge of the firelight with a boot beside her, and her knees up.)','"He went back. He said he would be at the Tree. He did not say whether he would be with us or with them."','She is holding it very well. It is the most terrible thing about her.']}[f];
    say('Little Poppy',L,()=>{ next(); });
  };
}
