'use strict';
/* ===== HOSTED SCENES: the story's outdoor places, laid onto the world map =====
   The Thorn Road, the Singing Stream, the Keeper's Shrine, the Lantern Road, the Gates, the Ash Maze and the Ring
   used to be rooms: you pressed Z on a post, the screen cut away, and you played them in a box.
   Now they are real places. While their chapter is open the scene's tiles are laid onto the world map (mirrored if
   that suits the road), joined to the nearest road or gate by a path, and you walk in on your own feet.

   How it works (see also the host helpers at the top of s2sx.js):
   - a REGION is a scene (SX.defs[id]) pinned to a rectangle of the world: x0,y0 (tile), flipped or not.
   - the scene keeps its own local coordinates; the player's g.px/g.py stay in world coordinates.
   - tiles: genTile is wrapped so the region's cells are world tiles (trees, grass, ash, water...), and solidTile asks
     the scene instead (thorns, boulders, gates and so on are dynamic).
   - things (objects, ducks, guards, the follower) are drawn into the world's depth-sorted draw list.
   - darkness, the detection bar and the timer are drawn as screen overlays.
   - walking onto a region starts the scene exactly as sxEnter would; walking off (or the chapter closing) ends it.
   Interiors (the castle rooms, the cellar, the cottage, the dreams...) are still rooms. */

const HOST={regs:[],byId:{},S:{},on:[],key:'',cur:null,vis:[],natural:false,story:null,checked:false};

function hostReg(r){
  const def=SX.defs[r.id];
  if(!def){ console.warn('hostReg: no scene',r.id); return r; }
  r.w=def.rows[0].length; r.h=def.rows.length; r.def=def;
  HOST.regs.push(r); HOST.byId[r.id]=r; return r;
}
function hostObj(r){ return {x0:r.x0,y0:r.y0,w:r.w,h:r.h,flip:!!r.flip,exitOff:r.exitOff||[]}; }
function hostIn(r,x,y){ return x>=r.x0&&x<r.x0+r.w&&y>=r.y0&&y<r.y0+r.h; }
function hostLT(r,x,y){ return {tx:r.flip?r.w-1-(x-r.x0):x-r.x0, ty:y-r.y0}; }
function hostWorldTile(r,lx,ly){ return {x:r.flip?r.x0+r.w-1-lx:r.x0+lx, y:r.y0+ly}; }
function hostGetS(r){
  if(!g.story) return null;
  let S=HOST.S[r.id];
  if(!S||S.def!==r.def){ S=HOST.S[r.id]=sxMake(r.def,hostObj(r)); }
  return S;
}
/* the active-region lookup for one world tile: {r,S,tx,ty} or null */
function hostAt(x,y){
  for(const r of HOST.on){ if(hostIn(r,x,y)){ const S=hostGetS(r); if(!S) return null; const l=hostLT(r,x,y); return {r:r,S:S,tx:l.tx,ty:l.ty}; } }
  return null;
}

/* ---------- which regions exist right now ---------- */
function hostChap(){ const q=g.story&&g.story.s2; return q?q:null; }
function hostSync(){
  if(HOST.story!==g.story){ HOST.story=g.story; HOST.S={}; HOST.cur=null; HOST.key=''; HOST.on=[]; HOST.checked=false; if(SX.S&&SX.S.host) SX.S=null; tileCache.clear(); }
  const on=[];
  if(g.story&&g.story.s2){ for(const r of HOST.regs){ let ok=false; try{ ok=!!r.when(); }catch(e){ ok=false; } if(ok) on.push(r); } }
  const key=on.map(r=>r.id).join(',');
  if(key===HOST.key) return;
  const old=HOST.on; HOST.key=key; HOST.on=on;
  tileCache.clear();
  /* regions that closed: forget their scene, and if you were standing in one, lead you to a free place */
  for(const r of old){ if(on.indexOf(r)<0){ delete HOST.S[r.id]; } }
  if(HOST.cur&&on.indexOf(HOST.cur.r)<0){
    const r=HOST.cur.r; HOST.cur=null; if(SX.S&&SX.S.host) SX.S=null; hudCache.obj=null;
    hostEject(r);
  } else {
    /* standing in the cell of a region that has just closed (e.g. the moment a chapter ends) */
    for(const r of old){ if(on.indexOf(r)<0&&hostIn(r,Math.floor(g.px/TS),Math.floor((g.py-2)/TS))) hostEject(r); }
  }
}
function hostEject(r){
  const h=r.home||[Math.floor(g.px/TS),Math.floor(g.py/TS)];
  const sp=snapFree(h[0],h[1],6);
  g.px=(sp[0]+0.5)*TS; g.py=(sp[1]+0.95)*TS; g.camX=g.px; g.camY=g.py-10; fade(0.6);
}

/* ---------- tiles ---------- */
const HOSTTH={
  wood:{wall:()=>T.TREE},
  ash:{wall:()=>KCHAR},
  dream:{wall:()=>KCHAR}
};
function hostWallTile(r){ return (HOSTTH[r.def.theme]||HOSTTH.wood).wall(); }
function hostFloorTile(r,x,y,ch){
  const th=r.def.theme;
  if(r.def.exits&&r.def.exits[ch]) return th==='wood'?T.PATH:KASH;
  if(th==='ash'||th==='dream') return KASH;
  const h=hash(x,y,8121);
  if(h<0.035) return T.FLOWER;
  if(h<0.065) return T.MUSH;
  return T.GRASS;
}
function hostBaseTile(r,x,y){
  const l=hostLT(r,x,y), ch=r.def.rows[l.ty][l.tx];
  if(ch==='#'||ch===' ') return hostWallTile(r);
  if(ch==='~') return T.WATER;
  return hostFloorTile(r,x,y,ch);
}
function hostTileAt(x,y){
  const on=HOST.on; if(!on.length) return -1;
  for(let i=0;i<on.length;i++){ const r=on[i]; if(hostIn(r,x,y)) return hostBaseTile(r,x,y); }
  for(let i=0;i<on.length;i++){
    const r=on[i];
    if(r.paths) for(const p of r.paths) if(x>=p[0]&&x<=p[2]&&y>=p[1]&&y<=p[3]) return T.PATH;
    if(r.open) for(const o of r.open) if(o[0]===x&&o[1]===y) return o[2]!==undefined?o[2]:T.COBBLE;
  }
  return -1;
}
{
  const _gen=genTile;
  genTile=function(x,y){ const t=hostTileAt(x,y); if(t>=0) return t; return _gen(x,y); };
  const _solid=solidTile;
  solidTile=function(tx,ty){
    if(HOST.on.length){ const h=hostAt(tx,ty); if(h) return sxSolid(h.S,h.tx,h.ty); }
    return _solid(tx,ty);
  };
  const _blocked=blockedAt;
  blockedAt=function(x,y){
    if(_blocked(x,y)) return true;
    const c=HOST.cur;
    if(c){ const S=c.S; for(const n of S.npcs){ if(n.when&&!n.when(S)) continue; if(Math.abs(sxToWX(S,n.x)-x)<11&&Math.abs(sxToWY(S,n.y)-y)<7) return true; } }
    return false;
  };
}

/* the Hollow Wood's shifting-glades puzzle (chapter 2) shares this ground; it is long over by the time these places open */
{
  const _wu=woodUpdate;
  woodUpdate=function(dt){ hostSync(); if(HOST.on.length) return; _wu(dt); };
}

/* ---------- entering and leaving ---------- */
function hostSwitch(r,S){ HOST.cur={r:r,S:S}; SX.S=S; hudCache.obj=null; }
/* called by sxEnter: returns true when the scene is hosted (and so has been started here) */
function sxHostEnter(id,tx,ty,dir){
  if(!g.story) return false;
  hostSync();
  const r=HOST.byId[id]; if(!r||HOST.on.indexOf(r)<0) return false;
  const def=r.def, S=(HOST.natural&&HOST.S[id])||sxMake(def,hostObj(r));
  if(HOST.natural){ S.det=0; S.caught=0; }
  HOST.S[id]=S; hostSwitch(r,S); g.target=null;
  if(!HOST.natural){
    /* the story put you here (a chapter beginning, a way home): go to the scene's start */
    const st=def.start||[1,1], sx0=tx!==undefined?tx:st[0], sy0=ty!==undefined?ty:st[1];
    sxPlace(S,(sx0+0.5)*TS,(sy0+0.95)*TS,dir||st[2]||'down'); fade(0.5); quack();
    g.camX=g.px; g.camY=g.py-10;
  }
  const lx=sxLX(S), ly=sxLY(S);
  S.check=[Math.floor(lx/TS),Math.floor((ly-2)/TS)];
  if(S.follow){ S.follow.x=lx; S.follow.y=ly+10; S.trail=[]; for(let i=0;i<14;i++) S.trail.push({x:lx,y:ly+i}); }
  if(def.name) toast(def.name,2800);
  if(r.enter) r.enter(S);
  if(def.onEnter) def.onEnter(S);
  return true;
}
/* called by sxLeave: a story teleport (wx,wy given) or just letting the scene go */
function sxHostLeave(S,wx,wy){
  const r=HOST.byId[S.id];
  HOST.cur=null; SX.S=null; g.target=null; hudCache.obj=null;
  /* the story's 'leave' teleports are ignored: you are already outdoors. When the chapter closes, hostSync leads you home. */
  if(S.def.onLeave) S.def.onLeave();
}
function hostWalkOff(){
  const c=HOST.cur; if(!c) return;
  HOST.cur=null; SX.S=null; g.target=null; hudCache.obj=null;
  if(c.S.def.onLeave) c.S.def.onLeave();
}

/* ---------- per frame ---------- */
function hostUpdate(dt){
  if(!g.story||g.mode==='title') return;
  hostSync();
  if(!HOST.checked&&g.mode==='play'){
    HOST.checked=true;
    if(!HOST.cur){ const tx=Math.floor(g.px/TS), ty=Math.floor((g.py-2)/TS); if(!hostAt(tx,ty)&&blockedAt(g.px,g.py)){ const sp=snapFree(tx,ty,6); g.px=(sp[0]+0.5)*TS; g.py=(sp[1]+0.95)*TS; } }
  }
  if(g.scene!=='world'){ if(HOST.cur) hostWalkOff(); return; }
  const tx=Math.floor(g.px/TS), ty=Math.floor((g.py-2)/TS);
  let r=null; for(const q of HOST.on) if(hostIn(q,tx,ty)) r=q;
  if(HOST.cur&&HOST.cur.r!==r) hostWalkOff();
  if(r&&!HOST.cur&&g.mode==='play'){
    HOST.natural=true;
    try{ sxEnter(r.id); }finally{ HOST.natural=false; }
  }
  if(HOST.cur) sxUpdate(dt);
}
{
  const _su=storyUpdate;
  storyUpdate=function(dt){
    if(HOST.cur&&g.scene==='world'){ hostUpdate(dt); return; }   /* inside a place: it runs, the rest of the story waits, as in a room */
    _su(dt); hostUpdate(dt);
  };
  const _ft=findTarget;
  findTarget=function(){
    const c=HOST.cur;
    if(c&&g.scene==='world'){
      sxFind();
      const t=g.target;
      if(t&&t.k==='sx'){ t.x=sxToWX(c.S,t.x); t.y=sxToWY(c.S,t.y); }
      return;
    }
    _ft();
  };
  const _it=interact;
  interact=function(){
    const tg=g.target;
    if(HOST.cur&&g.scene==='world'&&tg&&tg.k==='sx'){ quack(); sxUse(tg); return; }
    _it();
  };
  const _an=areaName;
  areaName=function(){ if(HOST.cur&&g.scene==='world') return HOST.cur.S.def.area||HOST.cur.S.def.name||_an(); return _an(); };
}

/* ---------- drawing: things go into the world's sorted list ---------- */
function hostXf(c,r){
  c.save();
  if(r.flip){ c.translate((r.x0+r.w)*TS,r.y0*TS); c.scale(-1,1); } else c.translate(r.x0*TS,r.y0*TS);
}
function hostCollect(c,objs,x0,y0,x1,y1,time){
  HOST.vis.length=0;
  if(!HOST.on.length||!g.story) return;
  for(const r of HOST.on){
    if(r.x0>x1||r.x0+r.w-1<x0||r.y0>y1||r.y0+r.h-1<y0) continue;
    const S=hostGetS(r); if(!S) continue;
    HOST.vis.push({r:r,S:S});
    const ax=Math.max(x0,r.x0), bx=Math.min(x1,r.x0+r.w-1), ay=Math.max(y0,r.y0), by=Math.min(y1,r.y0+r.h-1);
    objs.push({y:-1e12,k:'fn',f:()=>hostDrawUnder(c,r,S,ax,ay,bx,by,time)});
    for(let wy=ay;wy<=by;wy++) for(let wx=ax;wx<=bx;wx++){
      const l=hostLT(r,wx,wy), o=sxObjAt(S,l.tx,l.ty); if(!o) continue;
      const fn=SXG[o.glyph||'none']; if(!fn) continue;
      objs.push({y:wy*TS+(o.sortY||TS),k:'fn',f:()=>{ hostXf(c,r); fn(c,l.tx*TS,l.ty*TS,time,o,S); c.restore(); }});
    }
    for(const n of S.npcs){
      if(n.when&&!n.when(S)) continue;
      objs.push({y:sxToWY(S,n.y),k:'fn',f:()=>{
        hostXf(c,r); drawDuck(c,n.x,n.y,n.dir,n.phase,n.moving,n.pal,{head:n.acc.head,neck:n.acc.neck,scale:n.scale}); c.restore();
        if(n.mark&&g.mode==='play'){ const m=typeof n.mark==='function'?n.mark(S):n.mark; if(m) drawMark(c,sxToWX(S,n.x),sxToWY(S,n.y)-34,time,m,'#ffd166'); }
      }});
    }
    for(const gd of S.guards){
      if(gd.off&&gd.off(S)) continue;
      objs.push({y:sxToWY(S,gd.y),k:'fn',f:()=>{
        hostXf(c,r); drawDuck(c,gd.x,gd.y,gd.dir,gd.phase,gd.moving,gd.pal,{head:gd.head,neck:null}); c.restore();
        if(gd.alert>0.05){ c.fillStyle='rgba(255,60,60,'+Math.min(1,gd.alert+0.2).toFixed(2)+')'; c.font='700 14px Georgia,serif'; c.textAlign='center'; c.fillText('!',sxToWX(S,gd.x),sxToWY(S,gd.y)-34); c.textAlign='left'; }
      }});
    }
    if(S.follow){ const f=S.follow; objs.push({y:sxToWY(S,f.y),k:'fn',f:()=>{ hostXf(c,r); drawDuck(c,f.x,f.y,f.dir,f.phase,f.moving,f.pal,{head:f.head,scale:f.scale}); c.restore(); }}); }
    objs.push({y:1e12,k:'fn',f:()=>hostDrawOver(c,r,S,time)});
  }
}
/* floor dressing that the plain world tiles do not carry: shade, ice, carpet, gates, the way on */
function hostDrawUnder(c,r,S,ax,ay,bx,by,time){
  hostXf(c,r);
  const def=S.def;
  for(let wy=ay;wy<=by;wy++) for(let wx=ax;wx<=bx;wx++){
    const l=hostLT(r,wx,wy), ch=sxCh(S,l.tx,l.ty), px=l.tx*TS, py=l.ty*TS;
    if(ch===',') rect(c,px,py,TS,TS,'rgba(0,0,10,0.35)');
    else if(ch==='i'){ rect(c,px,py,TS,TS,'#bfe3f2'); rect(c,px+4,py+6,10,2,'rgba(255,255,255,0.7)'); rect(c,px+16,py+20,9,2,'rgba(255,255,255,0.6)'); }
    else if(ch==='r'){ rect(c,px+4,py,TS-8,TS,def.carpet||'#7a2a3a'); }
    else if(ch==='+'){ rect(c,px,py,TS,TS,'#2a2a32'); for(let i=0;i<5;i++) rect(c,px+3+i*6,py+2,3,TS-4,'#8a8a96'); rect(c,px,py+10,TS,3,'#6a6a76'); }
    else if(def.exits&&def.exits[ch]&&sxExitOn(S,ch)){
      const e=def.exits[ch], a=0.5+0.25*Math.sin(time*3);
      rect(c,px+3,py+5,TS-6,TS-10,e.col||'#c9a24a'); c.globalAlpha=1-a*0.4; rect(c,px+3,py+5,TS-6,2,'rgba(255,255,255,0.5)'); c.globalAlpha=1;
    }
  }
  c.restore();
}
/* the watchers' cones and the seeking beetle, over everything in the place */
function hostDrawOver(c,r,S,time){
  hostXf(c,r);
  for(const gd of S.guards){
    if(gd.off&&gd.off(S)) continue;
    const rng=gd.range*TS*(S.veil>0?0.3:1), half=gd.fov*Math.PI/360, a=Math.min(1,gd.alert);
    const x0=gd.x, y0=gd.y-8;
    c.fillStyle='rgba(255,'+Math.round(220-160*a)+','+Math.round(80-60*a)+','+(0.10+0.2*a).toFixed(2)+')';
    c.beginPath(); c.moveTo(x0,y0);
    for(let i=0;i<=10;i++){
      const ang=gd.face-half+(half*2)*i/10; let d=0;
      for(;d<rng;d+=6){ if(sxSight(S,Math.floor((x0+Math.cos(ang)*d)/TS),Math.floor((y0+Math.sin(ang)*d)/TS))) break; }
      c.lineTo(x0+Math.cos(ang)*d,y0+Math.sin(ang)*d);
    }
    c.closePath(); c.fill();
  }
  c.restore();
  if(S.seekT>0&&S.seekTo&&HOST.cur&&HOST.cur.S===S){
    const wx=sxToWX(S,S.seekTo[0]*TS+16), wy=sxToWY(S,S.seekTo[1]*TS+16), a=Math.atan2(wy-(g.py-10),wx-g.px);
    for(let i=1;i<=5;i++) circ(c,g.px+Math.cos(a)*i*14,g.py-10+Math.sin(a)*i*14,2.2,'rgba(122,255,200,'+(0.9-i*0.12).toFixed(2)+')');
  }
}

/* ---------- darkness, and the on-screen bar and timer ---------- */
function hostScreen(wx,wy,kd){ return [(wx-view.ox)*kd,(wy-view.oy)*kd]; }
function hostDarkPass(c,W,H,kd){
  const vis=HOST.vis; if(!vis.length) return;
  const dark=vis.filter(v=>v.S.def.dark);
  if(dark.length){
    if(!SX.dark) SX.dark=document.createElement('canvas');
    const dc=SX.dark; if(dc.width!==W||dc.height!==H){ dc.width=W; dc.height=H; }
    const d2=dc.getContext('2d'); d2.setTransform(1,0,0,1,0,0); d2.globalCompositeOperation='source-over'; d2.clearRect(0,0,W,H);
    for(const v of dark){
      const r=v.r, a=v.S.def.dark===true?0.9:v.S.def.dark;
      const s0=hostScreen(r.x0*TS,r.y0*TS,kd), s1=hostScreen((r.x0+r.w)*TS,(r.y0+r.h)*TS,kd);
      d2.fillStyle='rgba(3,3,14,'+a+')'; d2.fillRect(Math.floor(s0[0]),Math.floor(s0[1]),Math.ceil(s1[0]-s0[0]),Math.ceil(s1[1]-s0[1]));
    }
    d2.globalCompositeOperation='destination-out';
    const punch=(wx,wy,rad)=>{
      const p=hostScreen(wx,wy,kd), rr=rad*kd; if(p[0]+rr<0||p[1]+rr<0||p[0]-rr>W||p[1]-rr>H) return;
      const gr=d2.createRadialGradient(p[0],p[1],rr*0.2,p[0],p[1],rr); gr.addColorStop(0,'rgba(0,0,0,1)'); gr.addColorStop(1,'rgba(0,0,0,0)');
      d2.fillStyle=gr; d2.beginPath(); d2.arc(p[0],p[1],rr,0,6.3); d2.fill();
    };
    for(const v of dark){
      const S=v.S, r=v.r, def=S.def, inside=HOST.cur&&HOST.cur.S===S;
      if(inside) punch(g.px,g.py-10,(def.lightR||80)+(S.lumen>0?70:0));
      for(let ly=0;ly<r.h;ly++) for(let lx=0;lx<r.w;lx++){
        const o=sxObjAt(S,lx,ly); if(o&&o.light){ const on=typeof o.light==='function'?o.light(S):o.light; if(on) punch(sxToWX(S,(lx+0.5)*TS),sxToWY(S,(ly+0.5)*TS),o.lightR||60); }
      }
      for(const l of (def.lights||[])) punch(sxToWX(S,(l.tx+0.5)*TS),sxToWY(S,(l.ty+0.5)*TS),l.r||70);
      if(S.follow) punch(sxToWX(S,S.follow.x),sxToWY(S,S.follow.y-10),34);
    }
    c.setTransform(1,0,0,1,0,0); c.drawImage(dc,0,0);
  }
  const cur=HOST.cur;
  if(cur){
    const S=cur.S;
    if(S.det>0.03){ const w=120*kd/2, h=6; c.fillStyle='rgba(0,0,0,0.55)'; c.fillRect(W/2-w/2-1,12,w+2,h+2); c.fillStyle='rgb(255,'+Math.round(200-170*S.det)+',60)'; c.fillRect(W/2-w/2,13,w*S.det,h); }
    if(S.timer){ c.font='700 '+Math.round(11*kd/2+7)+'px ui-monospace,monospace'; c.textAlign='center'; const m=Math.floor(S.timer.t/60), s=Math.ceil(S.timer.t%60); c.fillStyle=S.timer.t<10?'#ff6a5a':'#fff3d4'; c.fillText((S.timer.label||'')+' '+m+':'+(s<10?'0':'')+(s===60?'59':s),W/2,36); c.textAlign='left'; }
  }
}
{
  const _dn=drawNight;
  drawNight=function(c,W,H,kd){ _dn(c,W,H,kd); try{ hostDarkPass(c,W,H,kd); }catch(e){ console.error(e); } };
}

/* ---------- where is it? (for the hints at the bottom of the screen) ---------- */
function hostWhere(wx,wy){
  if(g.scene!=='world') return '';
  const dx=wx+0.5-g.px/TS, dy=wy+0.5-g.py/TS, dist=Math.hypot(dx,dy);
  if(dist<10) return ' (right here)';
  const names=['east','south-east','south','south-west','west','north-west','north','north-east'];
  const dir=names[(Math.round(Math.atan2(dy,dx)/(Math.PI/4))+8)%8];
  return ' (about '+(Math.round(dist/5)*5)+' tiles <b>'+dir+'</b> of you)';
}

/* =====================================================================
   THE PLACES
   (world tile coordinates; Emberwick's south gate is at about 266,-1148)
   ===================================================================== */
const _HQ=()=>{ const q=g.story&&g.story.s2; return q||{ch:'',step:0}; };
const _HAT=(id,a,b)=>{ const q=_HQ(); if(q.ch!==id) return false; if(a===undefined) return true; return q.step>=a&&q.step<=(b===undefined?a:b); };

/* The Wild Art: down the Ember Road from Emberwick's south gate, then the pale-pebble shrine path east */
const WILD_ENTRY=[266,-1138];
hostReg({id:'ws1',x0:268,y0:-1134,when:()=>_HAT('c6r',0,4),exitOff:['D','<','>'],home:[266,-1136],
  paths:[[265,-1137,266,-1131],[267,-1131,267,-1131]],
  enter:S=>{ if(_HAT('c6r',0)) s2set(1); }});
hostReg({id:'ws2',x0:291,y0:-1134,when:()=>_HAT('c6r',0,4),exitOff:['D','<','>'],home:[266,-1136],
  enter:S=>{ if(_HAT('c6r',0,1)) s2set(2); }});
hostReg({id:'ws3',x0:313,y0:-1134,when:()=>_HAT('c6r',0,4),exitOff:['D','<','>','H'],home:[266,-1136],
  enter:S=>{ if(_HAT('c6r',0,2)) s2set(3); }});

/* The Lantern Road: out of Emberwick's west gate and away west, mirrored so the road runs the way it should */
const LANT_ENTRY=[231,-1177];
const LANT_OPEN=[[230,-1178],[230,-1177],[230,-1176]];
hostReg({id:'lr1',x0:206,y0:-1181,flip:true,when:()=>_HAT('c15r',0,1),exitOff:['D','<','>'],home:[232,-1177],open:LANT_OPEN,
  enter:S=>{ if(_HAT('c15r',0)) s2set(1); }});
hostReg({id:'lr2',x0:182,y0:-1181,flip:true,when:()=>_HAT('c15r',0,1),exitOff:['D','<','>'],home:[232,-1177]});
hostReg({id:'lr3',x0:162,y0:-1181,flip:true,when:()=>_HAT('c15r',0,1),exitOff:['D','<','>'],home:[232,-1177]});

/* The Burnt Wood's edge: the Gate of Ash (or of Gold) -> the Ash Maze -> the Ring at the Old Tree.
   An ash path leaves the west bridge road and runs north along the moat. */
const BW_ENTRY=[28,-1057];
const BW_PATH=[[27,-1057,28,-1003],[29,-1057,56,-1057]];
hostReg({id:'bgR',x0:30,y0:-1062,when:()=>_HAT('c16r'),exitOff:['D'],home:[56,-1057],paths:BW_PATH});
hostReg({id:'bgC',x0:30,y0:-1062,when:()=>_HAT('c16c'),exitOff:['D'],home:[56,-1057],paths:BW_PATH});
hostReg({id:'bw1',x0:57,y0:-1063,when:()=>_HAT('c17',0,1),exitOff:['D'],home:[30,-1060],paths:BW_PATH,
  enter:S=>{ if(_HAT('c17',0)) s2set(1); }});
hostReg({id:'wardsc',x0:19,y0:-1070,when:()=>_HAT('c19'),exitOff:[],home:[30,-1060]});
